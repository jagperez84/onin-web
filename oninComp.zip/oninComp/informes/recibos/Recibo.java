package informes.recibos;

import java.io.File;
import java.util.HashMap;
import net.sf.jasperreports.engine.JREmptyDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.view.JasperViewer;
import net.sf.jasperreports.engine.util.JRLoader;

public class Recibo {
    
    public static String ruta = "C:/Toldos/Temp";

    public static void imprimirRecibo (HashMap parameters){

        JasperReport jasperReportMaestro = null;
        JasperReport jasperReportSubreporte1 = null;
        
        jasperReportMaestro = CargarPlantilla(".\\src\\informes\\recibos\\Recibos.jrxml", ".\\src\\informes\\recibos\\Recibos.jasper");
        jasperReportSubreporte1  = CargarPlantilla(".\\src\\informes\\recibos\\Vencimiento.jrxml", ".\\src\\informes\\recibos\\Vencimiento.jasper");
        
        parameters.put("reportVencimiento", jasperReportSubreporte1);
        
        try {
            JasperPrint print = JasperFillManager.fillReport(jasperReportMaestro, parameters, new JREmptyDataSource());
            JasperViewer.viewReport(print, false);
        } catch (JRException e) {
            System.out.println("Error");
        }
    }
    
    public static JasperReport CargarPlantilla(String sPlantillaFuente, String sPlantillaCompilada){

        JasperReport objetoJasperReport = null;
        File informeCompilado = null;
        informeCompilado = new File(sPlantillaCompilada);

        try {
            System.out.println("Cargando el fichero compilando.");
            objetoJasperReport = (JasperReport) JRLoader.loadObject(informeCompilado);
        } catch (JRException e) {
            System.out.println("JRException: ");
            e.printStackTrace();
            try {
                System.out.println("Compilando fuentes.");
                JasperCompileManager.compileReportToFile(sPlantillaFuente, sPlantillaCompilada);
                objetoJasperReport = (JasperReport) JRLoader.loadObject(informeCompilado);
            } catch (JRException f) {
               System.out.println("Compilando por segunda vez.");
                try {
                    objetoJasperReport = JasperCompileManager.compileReport(sPlantillaFuente);
                } catch (JRException e1) {
                    System.out.println("No se ha podido obtener el informe: ");
                    e1.printStackTrace();
                }
            }
        }
        return objetoJasperReport;
    }
}
