package informes.confeccionLonasTotal;

import java.io.ByteArrayInputStream;

public class LineaConfeccionTotal {
    
    private ByteArrayInputStream imagenConfeccion;
    private String contadorLinea;
    private String codigo;
    private String cant;
    private String medidaDac;
    private String medidaArticulo;
    private String numeroDoc;
    private String descInterna;
    private String articulos;
    private String descripcionDAC;
    private String descripcionArticulo;
    private String corte;
    private String dato;
    private String cantidad;
    private String codigoToldo;
    
    public LineaConfeccionTotal(){
    
    }

    public ByteArrayInputStream getImagenConfeccion() {
        return imagenConfeccion;
    }

    public void setImagenConfeccion(ByteArrayInputStream imagenConfeccion) {
        this.imagenConfeccion = imagenConfeccion;
    }

    public String getCant() {
        return cant;
    }

    public void setCant(String cant) {
        this.cant = cant;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getContadorLinea() {
        return contadorLinea;
    }

    public void setContadorLinea(String contadorLinea) {
        this.contadorLinea = contadorLinea;
    }

    public String getNumeroDoc() {
        return numeroDoc;
    }

    public void setNumeroDoc(String numeroDoc) {
        this.numeroDoc = numeroDoc;
    }

    public String getDescInterna() {
        return descInterna;
    }

    public void setDescInterna(String descToldo) {
        this.descInterna = descToldo;
    }

    public String getArticulos() {
        return articulos;
    }

    public void setArticulos(String articulos) {
        this.articulos = articulos;
    }

    public String getCorte() {
        return corte;
    }

    public void setCorte(String corte) {
        this.corte = corte;
    }

    public String getCantidad() {
        return cantidad;
    }

    public void setCantidad(String cantidad) {
        this.cantidad = cantidad;
    }

    public String getCodigoToldo() {
        return codigoToldo;
    }

    public void setCodigoToldo(String codigoToldo) {
        this.codigoToldo = codigoToldo;
    }

    public String getDato() {
        return dato;
    }

    public void setDato(String dato) {
        this.dato = dato;
    }

    public String getDescripcionArticulo() {
        return descripcionArticulo;
    }

    public void setDescripcionArticulo(String descripcionArticulo) {
        this.descripcionArticulo = descripcionArticulo;
    }

    public String getDescripcionDAC() {
        return descripcionDAC;
    }

    public void setDescripcionDAC(String descripcionDAC) {
        this.descripcionDAC = descripcionDAC;
    }

    public String getMedidaArticulo() {
        return medidaArticulo;
    }

    public void setMedidaArticulo(String medidaArticulo) {
        this.medidaArticulo = medidaArticulo;
    }

    public String getMedidaDac() {
        return medidaDac;
    }

    public void setMedidaDac(String medidaDac) {
        this.medidaDac = medidaDac;
    }
    
}
