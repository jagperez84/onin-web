package informes.hojaTrabajo;

import java.io.File;
import java.util.HashMap;
import net.sf.jasperreports.engine.JREmptyDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.view.JasperViewer;
import net.sf.jasperreports.engine.util.JRLoader;

/**
 *
 * @author Tony
 */

public class HojaTrabajo {
    
    public static String ruta = "C:/Toldos/Temp";

    public static void imprimirHojaTrabajo (HashMap parameters){

        JasperReport jasperReportMaestro = null;
        JasperReport jasperReportSubreporte1 = null;
        JasperReport jasperReportSubreporte2 = null;
        
        jasperReportMaestro = CargarPlantilla(".\\src\\informes\\hojaTrabajo\\HojaTrabajo.jrxml", ".\\src\\informes\\hojaTrabajo\\HojaTrabajo.jasper");
        jasperReportSubreporte1  = CargarPlantilla(".\\src\\informes\\hojaTrabajo\\DatosHojaTrabajo.jrxml", ".\\src\\informes\\hojaTrabajo\\DatosHojaTrabajo.jasper");
        jasperReportSubreporte2  = CargarPlantilla(".\\src\\informes\\hojaTrabajo\\LineaHojaTrabajo.jrxml", ".\\src\\informes\\hojaTrabajo\\LineaHojaTrabajo.jasper");
        
        parameters.put("reportDatosHojaTrabajo", jasperReportSubreporte1);
        parameters.put("reportLineaHojaTrabajo", jasperReportSubreporte2);
        
        try {
            JasperPrint print = JasperFillManager.fillReport(jasperReportMaestro, parameters, new JREmptyDataSource());
            JasperViewer.viewReport(print, false);
        } catch (JRException e) {
            System.out.println("Error");
        }
    }
    
    public static JasperReport CargarPlantilla(String sPlantillaFuente, String sPlantillaCompilada){

        JasperReport objetoJasperReport = null;
        File informeCompilado = null;
        informeCompilado = new File(sPlantillaCompilada);

        try {
            System.out.println("Cargando el fichero compilando.");
            objetoJasperReport = (JasperReport) JRLoader.loadObject(informeCompilado);
        } catch (JRException e) {
            System.out.println("JRException: ");
            e.printStackTrace();
            try {
                System.out.println("Compilando fuentes.");
                JasperCompileManager.compileReportToFile(sPlantillaFuente, sPlantillaCompilada);
                objetoJasperReport = (JasperReport) JRLoader.loadObject(informeCompilado);
            } catch (JRException f) {
               System.out.println("Compilando por segunda vez.");
                try {
                    objetoJasperReport = JasperCompileManager.compileReport(sPlantillaFuente);
                } catch (JRException e1) {
                    System.out.println("No se ha podido obtener el informe: ");
                    e1.printStackTrace();
                }
            }
        }
        return objetoJasperReport;
    }
}
