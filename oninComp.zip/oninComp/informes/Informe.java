/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package informes;

import java.io.File;
import java.util.HashMap;
import net.sf.jasperreports.engine.JREmptyDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.view.JasperViewer;
import net.sf.jasperreports.engine.util.JRLoader;

/**
 *
 * @author Tony
 */
public class Informe {
    
    public static String ruta = "C:/Toldos/Temp";

    public static void imprimirPresupuesto (HashMap parameters){

        JasperReport jasperReportMaestro = null;
        JasperReport jasperReportSubreporte1 = null;
        JasperReport jasperReportSubreporte2 = null;
        JasperReport jasperReportSubreporte3 = null;
        
        jasperReportMaestro = CargarPlantilla(".\\src\\informes\\Presupuesto.jrxml", ".\\src\\informes\\Presupuesto.jasper");
        jasperReportSubreporte1  = CargarPlantilla(".\\src\\informes\\LineaPresupuesto.jrxml", ".\\src\\informes\\LineaPresupuesto.jasper");
        jasperReportSubreporte2  = CargarPlantilla(".\\src\\informes\\PrecioPresupuesto.jrxml", ".\\src\\informes\\PrecioPresupuesto.jasper");
        jasperReportSubreporte3  = CargarPlantilla(".\\src\\informes\\FormaPago.jrxml", ".\\src\\informes\\FormaPago.jasper");
        
        parameters.put("reportLineaPresupuesto", jasperReportSubreporte1);
        parameters.put("reportPrecioPresupuesto", jasperReportSubreporte2);
        parameters.put("reportFormaPago", jasperReportSubreporte3);
        
        try {
            JasperPrint print = JasperFillManager.fillReport(jasperReportMaestro, parameters, new JREmptyDataSource());
            JasperViewer.viewReport(print, false);
        } catch (JRException e) {
            e.printStackTrace();
        }
    }
    
    public static String crearPresupuestoEmail (HashMap parameters){

        String rutaPdf;
        JasperReport jasperReportMaestro = null;
        JasperReport jasperReportSubreporte1 = null;
        JasperReport jasperReportSubreporte2 = null;
        JasperReport jasperReportSubreporte3 = null;
        
        jasperReportMaestro = CargarPlantilla(".\\src\\informes\\Presupuesto.jrxml", ".\\src\\informes\\Presupuesto.jasper");
        jasperReportSubreporte1  = CargarPlantilla(".\\src\\informes\\LineaPresupuesto.jrxml", ".\\src\\informes\\LineaPresupuesto.jasper");
        jasperReportSubreporte2  = CargarPlantilla(".\\src\\informes\\PrecioPresupuesto.jrxml", ".\\src\\informes\\PrecioPresupuesto.jasper");
        jasperReportSubreporte3  = CargarPlantilla(".\\src\\informes\\FormaPago.jrxml", ".\\src\\informes\\FormaPago.jasper");
        
        parameters.put("reportLineaPresupuesto", jasperReportSubreporte1);
        parameters.put("reportPrecioPresupuesto", jasperReportSubreporte2);
        parameters.put("reportFormaPago", jasperReportSubreporte3);
        
        String numero = (String) parameters.get("numero");
        numero = numero.replace("\\", "_");
        numero = numero.replace("/" , "_");
        String fecha = (String) parameters.get("fecha");
        fecha = fecha.replace("/", "_");
        fecha = fecha.replace("\\", "_");
        rutaPdf = ruta + "/" + fecha + numero + ".pdf";

        
        try {
            JasperPrint print = JasperFillManager.fillReport(jasperReportMaestro, parameters, new JREmptyDataSource());
            File dirTemp = new File(ruta);
            if(!dirTemp.exists()){
                dirTemp.mkdirs();
            }
            JasperExportManager.exportReportToPdfFile(print, rutaPdf);
        } catch (JRException e) {
            e.printStackTrace();
        }
        
        return rutaPdf;
    }
    
    public static void guardarPresupuesto (HashMap parameters, String fichero){

        JasperReport jasperReportMaestro = null;
        JasperReport jasperReportSubreporte1 = null;
        JasperReport jasperReportSubreporte2 = null;
        JasperReport jasperReportSubreporte3 = null;
        
        jasperReportMaestro = CargarPlantilla(".\\src\\informes\\Presupuesto.jrxml", ".\\src\\informes\\Presupuesto.jasper");
        
        
        
        jasperReportSubreporte1  = CargarPlantilla(".\\src\\informes\\LineaPresupuesto.jrxml", ".\\src\\informes\\LineaPresupuesto.jasper");
        jasperReportSubreporte2  = CargarPlantilla(".\\src\\informes\\PrecioPresupuesto.jrxml", ".\\src\\informes\\PrecioPresupuesto.jasper");
        jasperReportSubreporte3  = CargarPlantilla(".\\src\\informes\\FormaPago.jrxml", ".\\src\\informes\\FormaPago.jasper");
        
        parameters.put("reportLineaPresupuesto", jasperReportSubreporte1);
        parameters.put("reportPrecioPresupuesto", jasperReportSubreporte2);
        parameters.put("reportFormaPago", jasperReportSubreporte3);
        
        try {
            JasperPrint print = JasperFillManager.fillReport(jasperReportMaestro, parameters, new JREmptyDataSource());
            File fich = new File (fichero);
            File dirTemp = new File(ruta);
            if(!dirTemp.exists()){
                dirTemp.mkdirs();
            }
            File f = new File(fichero);
            JasperExportManager.exportReportToPdfFile(print, fichero);
        } catch (JRException e) {
            e.printStackTrace();
        }
    }


    public static JasperReport CargarPlantilla(String sPlantillaFuente, String sPlantillaCompilada){

        JasperReport objetoJasperReport = null;
        File informeCompilado = null;
        informeCompilado = new File(sPlantillaCompilada);

        try {
            objetoJasperReport = (JasperReport) JRLoader.loadObject(informeCompilado);
        } catch (JRException e) {
            e.printStackTrace();
            try {
                JasperCompileManager.compileReportToFile(sPlantillaFuente, sPlantillaCompilada);
                objetoJasperReport = (JasperReport) JRLoader.loadObject(informeCompilado);
            } catch (JRException f) {
                try {
                    objetoJasperReport = JasperCompileManager.compileReport(sPlantillaFuente);
                } catch (JRException e1) {
                    e1.printStackTrace();
                }
            }
        }
        return objetoJasperReport;
    }
}
