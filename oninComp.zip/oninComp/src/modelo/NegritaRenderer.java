package modelo;

import com.lowagie.text.Font;
import java.awt.Color;  
import java.awt.Component;  
import java.util.List;
import javax.swing.table.DefaultTableCellRenderer;  
import javax.swing.*; 

public class NegritaRenderer  extends DefaultTableCellRenderer {
    private List<Integer> listaUno;

    public NegritaRenderer(List<Integer> listaUno) {
        setOpaque(true);
        this.listaUno = listaUno;
    }

    @Override
    public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
        setValue(value);
        
        if(listaUno.contains(row)) {               
            setFont(table.getFont().deriveFont(Font.BOLD));
        } else {
            setFont(table.getFont());
        }
        
        if(isSelected) {
            super.setForeground(table.getSelectionForeground());
            super.setBackground(table.getSelectionBackground());
        } else {
            super.setForeground(Color.black);
            super.setBackground(Color.white);
        }
        return this;
    }
}