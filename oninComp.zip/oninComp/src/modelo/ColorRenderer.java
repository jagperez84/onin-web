package modelo;

import java.awt.Color;  
import java.awt.Component;  
import java.util.List;
import javax.swing.table.DefaultTableCellRenderer;  
import javax.swing.*; 

public class ColorRenderer  extends DefaultTableCellRenderer {
    private Color currColor = Color.white;
    private List<Integer> listaUno;
    private List<Integer> listaDos;
    private Color colorUno;
    private Color colorDos;

    public ColorRenderer(List<Integer> listaUno, Color colorUno, List<Integer> listaDos, Color colorDos) {
        setOpaque(true);
        this.listaUno = listaUno;
        this.listaDos = listaDos;
        this.colorUno = colorUno;
        this.colorDos = colorDos;
    }

    @Override
    public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {

        if(listaUno.contains(row)) {               
            currColor = colorUno;
        } else if(listaDos.contains(row)) {               
            currColor = colorDos;
        } else {
            currColor = Color.white;
        }
        
        if(isSelected) {
            super.setForeground(table.getSelectionForeground());
            super.setBackground(table.getSelectionBackground());
        } else {
            super.setForeground(Color.black);
            super.setBackground(currColor);
        } 
        setFont(table.getFont());
        setValue(value);
        return this;
    }
}