package modelo;

import javax.swing.table.DefaultTableModel;

public class ModeloDesp extends DefaultTableModel {

    public ModeloDesp() {
        super();
    }

    @Override
    public boolean isCellEditable(int rowIndex, int columnIndex) {
        if (columnIndex == 9) {
            return true;
        } else {
            return false;
        }
    }
}
