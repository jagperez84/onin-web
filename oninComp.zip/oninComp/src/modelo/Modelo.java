package modelo;

import javax.swing.table.DefaultTableModel;

public class Modelo extends DefaultTableModel {

    public Modelo() {
        super();
    }

    @Override
    public boolean isCellEditable(int rowIndex, int columnIndex) {
		return false;
    }
}