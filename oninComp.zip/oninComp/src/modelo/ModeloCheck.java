package modelo;

import java.util.ArrayList;
import java.util.List;
import javax.swing.table.DefaultTableModel;

public class ModeloCheck extends DefaultTableModel {
    private int indexPagado;
    private int indexCantidad;
    private List listaIndex;

    public ModeloCheck(int indexPagado) {
        super();
        this.listaIndex = new ArrayList();
        this.listaIndex.add(indexPagado);
        this.indexPagado = indexPagado;
    }

     public ModeloCheck(int indexPagado, int indexCantidad) {
        super();
        this.listaIndex = new ArrayList();
        this.listaIndex.add(indexPagado);
        this.indexPagado = indexPagado;
        this.indexCantidad = indexCantidad;
    }
    
    public ModeloCheck(List listaIndex, int indexPagado){
        super();
        this.listaIndex = listaIndex;
        this.indexPagado = indexPagado;
    }

    @Override
    public boolean isCellEditable(int rowIndex, int columnIndex) {
        if (indexCantidad == 0){
			if(indexPagado != columnIndex){
				return false;
			} else {
				return true;
			}
        }else {
			//Establecemos el campo cantidad como editable
			if(indexPagado != columnIndex && indexCantidad != columnIndex){
				return false;
			} else {
				return true;
			}
        }
    }

    public Class getColumnClass(int columnIndex) {
        if (listaIndex.contains(columnIndex)) {
            return Boolean.class;
        } else {
            return super.getColumnClass(columnIndex);
        }
     }
}
