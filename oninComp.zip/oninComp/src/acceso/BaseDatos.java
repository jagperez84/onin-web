package acceso;

import bean.*;
import gui.LogMasivoProgreso;
import gui.NuevaLineaCompra;
import gui.NuevaLineaCorteDeLona;
import gui.NuevaLineaCorteDePerfil;
import gui.NuevaLineaPresupuesto;
import gui.RellenarDac;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.SortedSet;
import java.util.TreeSet;
import javax.swing.JPanel;
import org.apache.log4j.Logger;
import org.hibernate.Session;
import util.Constantes;
import util.HibernateUtil;
import auxiliar.DesUnidades;
import auxiliar.RellenarDacBean;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;
import util.Util;

public class BaseDatos {

    private static Logger log = Logger.getLogger(BaseDatos.class);

    public BaseDatos() {}

    /********************
     **Méodos generales**
     ********************/
    public static boolean insertarElemento(Object o) {
        boolean res = true;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            session.save(o);
        } catch (Exception e) {

            res = false;
            session.getTransaction().rollback();
            e.printStackTrace();
        } finally {
            try {
                if (session.isOpen() && session.getTransaction().isActive()) {
                    session.getTransaction().commit();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
                res = false;
                session.getTransaction().rollback();
            }
            return res;
        }
    }

    public static boolean modificarElemento(Object o) {
        boolean res = true;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            session.update(o);
        } catch (Exception e) {
            e.printStackTrace();
            res = false;
            session.getTransaction().rollback();
        } finally {
            try {
                if (session.isOpen() && session.getTransaction().isActive()) {
                    session.getTransaction().commit();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
                res = false;
                session.getTransaction().rollback();
            }
            return res;
        }
    }

    public static boolean insertarOmodificarElemento(Object o) {
        boolean res = true;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            session.saveOrUpdate(o);
        } catch (Exception e) {
            res = false;
            session.getTransaction().rollback();
        } finally {
            try {
                if (session.isOpen() && session.getTransaction().isActive()) {
                    session.getTransaction().commit();
                }
            } catch (Exception ex) {
                res = false;
                session.getTransaction().rollback();
            }
            return res;
        }
    }

    public static Object obtenerElemento(Class clazz, Integer iid) {
        Object res = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            res = session.load(clazz, iid);
        } catch (Exception e) {
            res = null;
            session.getTransaction().rollback();
        } finally {
            try {
                if (session.isOpen() && session.getTransaction().isActive()) {
                    session.getTransaction().commit();
                }
            } catch (Exception ex) {
                res = null;
                session.getTransaction().rollback();
            }
            return res;
        }
    }

    public static boolean eliminarElemento(Class clazz, Integer iid) {

        boolean res = true;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            Object o = session.load(clazz, iid);
            session.delete(o);
        } catch (Exception e) {
            res = false;
            session.getTransaction().rollback();
        } finally {
            if (session.isOpen() && session.getTransaction().isActive()) {
                try {
                    session.getTransaction().commit();
                } catch (Exception ex) {
                    res = false;
                }
            }
            return res;
        }
    }

    /*******************************
     * Métodos de la clase Colores * 
	 *******************************/
    public static List getListaColores() {
        List lcolores = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lcolores = session.createQuery("from Colores").list();
        } catch (Exception e) {
            lcolores = null;
        }
        return lcolores;
    }

    public static Colores obtenerColorPorDescripcion(String descripcion) {
        Colores res = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            List lcolores = session.createQuery("from Colores where descripcion = '" + descripcion + "'").list();
            if (lcolores.size() >= 1) {
                res = (Colores) lcolores.get(0);
            } else {
                res = null;
            }
        } catch (Exception e) {
            res = null;
        }
        return res;
    }

    public static Colores obtenerColorPorIid(Integer iid) {
        Colores res = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            List lcolores = session.createQuery("from Colores where iid = " + iid).list();
            if (lcolores.size() >= 1) {
                res = (Colores) lcolores.get(0);
            } else {
                res = null;
            }
        } catch (Exception e) {
            res = null;
        }
        return res;
    }

    public static Colores obtenerColor(String codigo) {
        Colores res = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            List lcolores = session.createQuery("from Colores where cod_color='" + codigo + "'").list();
            if (lcolores.size() >= 1) {
                res = ((Colores) lcolores.get(0));
            } else {
                res = null;
            }
        } catch (Exception e) {
            res = null;
        }
        return res;
    }

    public static List obtenerCodigoColores() {
        List lcolores = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lcolores = session.createQuery("select cod_color from Colores").list();
        } catch (Exception e) {
            lcolores = null;
        }
        return lcolores;
    }

    public static List busquedaRapidaColores(String codigo) {
        List lcolores = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lcolores = session.createQuery("from Colores where cod_color like '%" + codigo + "%'").list();
        } catch (Exception e) {
            lcolores = null;
        }
        return lcolores;
    }

    /*******************************
     * Métodos de la clase Almacen *
	 *******************************/
    public static List getListaAlmacenes() {
        List lalmacenes = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lalmacenes = session.createQuery("from Almacen").list();
        } catch (Exception e) {
            lalmacenes = null;
        }
        return lalmacenes;
    }

    public static Almacen obtenerAlmacenById(Integer iid) {
        Almacen res = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            List lAlmacenes = session.createQuery("from Almacen where iid = " + iid).list();
            if (lAlmacenes.size() >= 1) {
                res = (Almacen) lAlmacenes.get(0);
            } else {
                res = null;
            }
        } catch (Exception e) {
            res = null;
        }
        return res;
    }

    public static Almacen obtenerAlmacenPorDescripcion(String descripcion) {
        Almacen res = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            List lAlmacenes = session.createQuery("from Almacen where descripcion = '" + descripcion + "'").list();
            if (lAlmacenes.size() >= 1) {
                res = (Almacen) lAlmacenes.get(0);
            } else {
                res = null;
            }
        } catch (Exception e) {
            res = null;
        }
        return res;
    }

    public static Almacen obtenerAlmacen(String nombre) {
        Almacen res = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            List lAlmacenes = session.createQuery("from Almacen where nombre='" + nombre + "'").list();
            if (lAlmacenes.size() >= 1) {
                res = ((Almacen) lAlmacenes.get(0));
            } else {
                res = null;
            }
        } catch (Exception e) {
            res = null;
        }
        return res;
    }

    public static List busquedaRapidaAlmacen(String nombre) {
        List lAlmacenes = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lAlmacenes = session.createQuery("from Almacen where nombre like '%" + nombre + "%'").list();
        } catch (Exception e) {
            lAlmacenes = null;
        }
        return lAlmacenes;
    }

    /*********************************************
     * Métodos de la clase TipoMovimientoAlmacen *
     *********************************************/
    public static List getListaTipoMovimientoAlmacen() {
        log.info("Se ha entrado a la clase: BaseDatos, método: getListaTipoMovimientoAlmacen");
        List lista = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lista = session.createQuery("from TipoMovimientoAlmacen").list();
        } catch (Exception e) {
            log.error("Se ha producido una excepción en la clase: BaseDatos, método: getListaTipoMovimientoAlmacen");
            lista = null;
        }
        return lista;
    }

    public static TipoMovimientoAlmacen obtenerTipoMovimientoAlmacen(String nombre) {
        TipoMovimientoAlmacen res = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            List lAlmacenes = session.createQuery("from TipoMovimientoAlmacen where nombre='" + nombre + "'").list();
            if (lAlmacenes.size() >= 1) {
                res = ((TipoMovimientoAlmacen) lAlmacenes.get(0));
            } else {
                res = null;
            }
        } catch (Exception e) {
            res = null;
        }
        return res;
    }

    public static List busquedaRapidaTipoMovimientoAlmacen(String nombre) {
        List lista = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lista = session.createQuery("from TipoMovimientoAlmacen where nombre like '%" + nombre + "%'").list();
        } catch (Exception e) {
            lista = null;
        }
        return lista;
    }

    /******************************
     * Métodos de la clase Moneda *
	 ******************************/
    public static List getListaMonedas() {
        List lmonedas = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lmonedas = session.createQuery("from Moneda").list();
        } catch (Exception e) {
            lmonedas = null;
        }
        return lmonedas;
    }

    public static Moneda obtenerMonedaByIid(Integer iid) {
        Moneda res = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            List lmonedas = session.createQuery("from Moneda where iid = " + iid).list();
            if (lmonedas.size() >= 1) {
                res = ((Moneda) lmonedas.get(0));
            } else {
                res = null;
            }
        } catch (Exception e) {
            res = null;
        }
        return res;
    }

    public static Moneda obtenerMoneda(String codigo) {
        Moneda res = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            List lmonedas = session.createQuery("from Moneda where codigo = '" + codigo + "'").list();
            if (lmonedas.size() >= 1) {
                res = ((Moneda) lmonedas.get(0));
            } else {
                res = null;
            }
        } catch (Exception e) {
            res = null;
        }
        return res;
    }

    public static Moneda obtenerMonedaNombre(String nombre) {
        Moneda res = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            List lmonedas = session.createQuery("from Moneda where nombre='" + nombre + "'").list();
            if (lmonedas.size() >= 1) {
                res = ((Moneda) lmonedas.get(0));
            } else {
                res = null;
            }
        } catch (Exception e) {
            res = null;
        }
        return res;
    }

    public static List obtenerNombreMoneda() {
        List lmonedas = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lmonedas = session.createQuery("select nombre from Moneda").list();
        } catch (Exception e) {
            lmonedas = null;
        }
        return lmonedas;
    }

    /************************************
     * Métodos de la clase UnidadMedida *
	 ************************************/
    public static List getListaUnidadMedidas() {
        List lart = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lart = session.createQuery("from UnidadMedida").list();
        } catch (Exception e) {
            lart = null;
        }
        return lart;
    }

    public static UnidadMedida obtenerUnidadMedidaNombre(String nombre) {
        UnidadMedida res = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            List lunidadmedidas = session.createQuery("from UnidadMedida where nombre = '" + nombre + "'").list();
            if (lunidadmedidas.size() >= 1) {
                res = ((UnidadMedida) lunidadmedidas.get(0));
            } else {
                res = null;
            }
        } catch (Exception e) {
            res = null;
        }
        return res;
    }

    public static UnidadMedida obtenerUnidadMedidaCodigo(String codigo) {
        UnidadMedida res = null;

        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            List lunidadmedidas = session.createQuery("from UnidadMedida where cod_unidad_medida='" + codigo + "'").list();
            if (lunidadmedidas.size() >= 1) {
                res = ((UnidadMedida) lunidadmedidas.get(0));
            } else {
                res = null;
            }
        } catch (Exception e) {
            res = null;
        }
        return res;
    }

    public static List obtenerNombreUnidadMedida() {
        List lunidadmedida = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lunidadmedida = session.createQuery("select nombre from UnidadMedida").list();
        } catch (Exception e) {
            lunidadmedida = null;
        }
        return lunidadmedida;
    }

    public static List busquedaRapidaUnidadMedidaCodigo(String codigo) {
        List lum = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lum = session.createQuery("from UnidadMedida where cod_unidad_medida like '%" + codigo + "%' order by iid").list();
        } catch (Exception e) {
            lum = null;
        }
        return lum;
    }

    public static List busquedaRapidaUnidadMedidaMagnitud(String magnitud) {
        List lum = null;
        List lres = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            String consulta = "select um.iid "
                    + "from UnidadMedida um "
                    + "inner join um.magnitud as mg "
                    + "where mg.nombre like '%" + magnitud + "%' order by um.iid";
            lum = session.createQuery(consulta).list();
            if (lum != null) {
                lres = new ArrayList();
                UnidadMedida um;
                for (Iterator it = lum.iterator(); it.hasNext();) {
                    um = BaseDatos.obtenerUnidadMedidaIid((Integer) it.next());
                    lres.add(um);
                }

            }
        } catch (Exception e) {
            lres = null;
        }
        return lres;
    }

    public static UnidadMedida obtenerUnidadMedidaIid(Integer iid) {
        UnidadMedida res = null;

        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            List lunidadmedidas = session.createQuery("from UnidadMedida where iid=" + iid).list();
            if (lunidadmedidas.size() >= 1) {
                res = ((UnidadMedida) lunidadmedidas.get(0));
            } else {
                res = null;
            }
        } catch (Exception e) {
            res = null;
        }
        return res;
    }

    public static UnidadMedida obtenerUnidadMedidaIid(Integer iid, Session session) {
        UnidadMedida res = null;

        try {
            List lunidadmedidas = session.createQuery("from UnidadMedida where iid = " + iid).list();
            if (lunidadmedidas.size() >= 1) {
                res = ((UnidadMedida) lunidadmedidas.get(0));
            } else {
                res = null;
            }
        } catch (Exception e) {
            res = null;
        }
        return res;
    }

    /******************************
     * Métodos de la clase Medida *
	 ******************************/
    public static List getListaMedidas() {
        List lmedidas = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lmedidas = session.createQuery("from Medida").list();
        } catch (Exception e) {
            lmedidas = null;
        }
        return lmedidas;
    }

    public static Medida obtenerMedida(String medida) {
        Medida res = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            List lmedidas = session.createQuery("from Medida where medida = '" + medida + "'").list();
            if (lmedidas.size() >= 1) {
                res = ((Medida) lmedidas.get(0));
            } else {
                res = null;
            }
        } catch (Exception e) {
            res = null;
        }
        return res;
    }

    public static List obtenerMedidaMedidas() {
        List lmedidas = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lmedidas = session.createQuery("select medida from Medida").list();
        } catch (Exception e) {
            lmedidas = null;
        }

        return lmedidas;
    }

    /************************************
     * Métodos de la clase FamiliaVenta *
	 ************************************/
    public static List getListaFamiliaVentas(Empresa em) {
        List lfamiliaventas = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lfamiliaventas = session.createQuery("from FamiliaVenta where iid_empresa = " + em.getIid()).list();
        } catch (Exception e) {
            lfamiliaventas = null;
        }
        return lfamiliaventas;
    }

    public static FamiliaVenta obtenerFamiliaVentaPorIid(Integer iid) {
        FamiliaVenta res = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            List lFamiliaVenta = session.createQuery("from FamiliaVenta where iid = " + iid).list();
            if (lFamiliaVenta.size() >= 1) {
                res = ((FamiliaVenta) lFamiliaVenta.get(0));
            } else {
                res = null;
            }
        } catch (Exception e) {
            e.printStackTrace();
            res = null;
        }
        return res;
    }

    public static FamiliaVenta obtenerFamiliaVentaPorIidBD(Integer iid, Session session) {
        FamiliaVenta res = null;

        session.beginTransaction();
        try {
            List lFamiliaVenta = session.createQuery("from FamiliaVenta where iid = " + iid).list();
            if (lFamiliaVenta.size() >= 1) {
                res = ((FamiliaVenta) lFamiliaVenta.get(0));
            } else {
                res = null;
            }
        } catch (Exception e) {
            res = null;
        }
        return res;
    }

    public static List obtenerCodFamiliaVentas() {
        List lfamiliav = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lfamiliav = session.createQuery("select cod_familia from FamiliaVenta").list();
        } catch (Exception e) {
            lfamiliav = null;
        }
        return lfamiliav;
    }

    public static FamiliaVenta obtenerFamiliaVenta(String codigo, Integer iidEmpresa) {
        FamiliaVenta res = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            List lfamiliaventas = session.createQuery("from FamiliaVenta where cod_familia='" + codigo + "' and (iid_empresa is null or iid_empresa = " + iidEmpresa + ")").list();
            if (lfamiliaventas.size() >= 1) {
                res = ((FamiliaVenta) lfamiliaventas.get(0));
            } else {
                res = null;
            }
        } catch (Exception e) {
            res = null;
            session.getTransaction().rollback();
        } finally {
            if (session.isOpen() && session.getTransaction().isActive()) {
                session.getTransaction().commit();
            }
        }

        return res;
    }

    public static FamiliaVenta obtenerFamiliaVentaPorNombre(Empresa em, String nombre) {
        FamiliaVenta res = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            List lfamiliaventas = session.createQuery("from FamiliaVenta where iid_empresa = " + em.getIid() + " AND nombre = '" + nombre + "'").list();
            if (lfamiliaventas.size() >= 1) {
                res = ((FamiliaVenta) lfamiliaventas.get(0));
            } else {
                res = null;
            }
        } catch (Exception e) {
            res = null;
        }

        return res;
    }

    public static List busquedaRapidaFamiliaVentasCodigo(String codigo, Empresa em) {
        List lfv = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lfv = session.createQuery("from FamiliaVenta where cod_familia like '%" + codigo + "%' AND iid_empresa = " + em.getIid()).list();
        } catch (Exception e) {
            lfv = null;
        }
        return lfv;
    }

    public static List busquedaRapidaFamiliaVentasNombre(String nombre, Empresa em) {
        List lfv = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            String consulta = "from FamiliaVenta where nombre like '%" + nombre + "%' AND iid_empresa = " + em.getIid();
            lfv = session.createQuery(consulta).list();
        } catch (Exception e) {
            lfv = null;
        }
        return lfv;
    }

    public static boolean insertarFamiliaVenta(FamiliaVenta fv, List listaMedidas, List listaColores, List lp) {
        boolean res = true;

        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        
        try {
            Integer iidFV = (Integer) session.save(fv);
            fv.setIid(iidFV);

            Iterator iter = listaMedidas.iterator();
            MedidasFamiliaVenta m;

            while (iter.hasNext()) {
                m = (MedidasFamiliaVenta) iter.next();
                m.setIid_fam_venta(fv);
                session.save(m);
            }

            if (listaColores != null) {
                Iterator iterC = listaColores.iterator();
                colorFamilia cF;
                while (iterC.hasNext()) {
                    cF = (colorFamilia) iterC.next();
                    cF.setIidFamilia(iidFV);
                    session.save(cF);
                }
            }

            if (lp != null) {
                Iterator iterP = lp.iterator();
                precioFamilia cP;
                while (iterP.hasNext()) {
                    cP = (precioFamilia) iterP.next();
                    cP.setIidFamilia(iidFV);
                    session.save(cP);
                }
            }

        } catch (Exception e) {
            res = false;
            session.getTransaction().rollback();
            e.printStackTrace();
        } finally {
            if (session.isOpen() && session.getTransaction().isActive()) {
                session.getTransaction().commit();
            }
        }

        return res;
    }

    public static boolean modificarFamiliaVenta(FamiliaVenta fv, List listaMedidas, List listaColores, Integer empresa, List lp) {
        boolean res = true;

        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            session.update(fv);
            List listaMedidasBBDD = session.createQuery("from MedidasFamiliaVenta where iid_fam_venta.iid = " + fv.getIid()).list();
            int indiceMedidasBBDD = 0;
            int contadorMedida = 0;
            Iterator iter = listaMedidas.iterator();
            MedidasFamiliaVenta m, temp;
            while (iter.hasNext()) {
                m = (MedidasFamiliaVenta) iter.next();

                if (indiceMedidasBBDD + 1 > listaMedidasBBDD.size()) {
                    temp = new MedidasFamiliaVenta();
                } else {
                    temp = (MedidasFamiliaVenta) listaMedidasBBDD.get(contadorMedida);
                    contadorMedida++;
                }

                temp.setIid_fam_venta(fv);
                temp.setMedida1(m.getMedida1());
                temp.setMedida2(m.getMedida2());
                temp.setMedida3(m.getMedida3());
                temp.setMedida4(m.getMedida4());
                temp.setMedida5(m.getMedida5());

                if (indiceMedidasBBDD + 1 > listaMedidasBBDD.size()) {
                    session.save(temp);
                } else {
                    indiceMedidasBBDD++;
                    session.update(temp);
                }

            }
            Object o;
            for (int i = indiceMedidasBBDD; i < listaMedidasBBDD.size(); i++) {
                m = (MedidasFamiliaVenta) listaMedidasBBDD.get(i);
                o = session.load(MedidasFamiliaVenta.class, m.getIid());
                session.delete(o);
            }

            //Colores
            List listaColoresBBDD = session.createQuery("from colorFamilia where iidFamilia = " + fv.getIid() + "and iidEmpresa = " + empresa).list();
            int indiceColorBBDD = 0;
            int contadorColor = 0;
            Iterator iterC = listaColores.iterator();
            colorFamilia cf, tempC;
            while (iterC.hasNext()) {
                cf = (colorFamilia) iterC.next();

                if (indiceColorBBDD + 1 > listaColoresBBDD.size()) {
                    tempC = new colorFamilia();
                } else {
                    tempC = (colorFamilia) listaColoresBBDD.get(contadorColor);
                    contadorColor++;
                }

                tempC.setIidFamilia(fv.getIid());
                tempC.setIidColor(cf.getIidColor());
                tempC.setIidEmpresa(empresa);


                if (indiceColorBBDD + 1 > listaColoresBBDD.size()) {
                    session.save(tempC);
                } else {
                    indiceColorBBDD++;
                    session.update(tempC);
                }

            }

            //Lista de precios por Color
            precioFamilia pf = new precioFamilia();
            for (int i = 0; i < lp.size(); i++) {
                pf = (precioFamilia) lp.get(i);
                if (pf.getIid() != null){
                    session.update(pf);
                }else{
                   session.save(pf);     
                }            
            }

            Object oC;

            for (int i = indiceColorBBDD; i < listaColoresBBDD.size(); i++) {
                cf = (colorFamilia) listaColoresBBDD.get(i);
                oC = session.load(colorFamilia.class, cf.getIid());
                session.delete(oC);
            }


        } catch (Exception e) {
            e.printStackTrace();
            res = false;
            session.getTransaction().rollback();
        } finally {
            if (session.isOpen() && session.getTransaction().isActive()) {
                session.getTransaction().commit();
            }
        }

        return res;
    }

    public static boolean eliminarFamiliaVentas(Integer iidFamVenta) {
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        boolean res = true;
        try {
            String consultaMedida = "delete from MedidasFamiliaVenta where iid_fam_venta.iid = " + iidFamVenta;
            String consultaFamVenta = "delete from FamiliaVenta where iid = " + iidFamVenta;

            session.createQuery(consultaMedida).executeUpdate();
            session.createQuery(consultaFamVenta).executeUpdate();

        } catch (Exception ex) {
            ex.printStackTrace();
            session.getTransaction().rollback();
            res = false;
        } finally {
            if (session.isOpen() && session.getTransaction().isActive()) {
                session.getTransaction().commit();
            }
        }
        return res;
    }

    /***********************************
     * Métodos de la clase TipoControl *
	 ***********************************/
    public static List getListaTipoControl() {
        List ltipocontrol = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            ltipocontrol = session.createQuery("from TipoControl").list();
        } catch (Exception e) {
            ltipocontrol = null;
        }
        return ltipocontrol;
    }

    public static TipoControl obtenerTipoControl(String codigo) {
        TipoControl tc = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            List ltipocontrol = session.createQuery("from TipoControl where codigo = '" + codigo + "'").list();
            if (ltipocontrol.size() >= 1) {
                tc = ((TipoControl) ltipocontrol.get(0));
            } else {
                tc = null;
            }
        } catch (Exception e) {
            tc = null;
        }

        return tc;
    }

    public static TipoControl obtenerTipoControlPorIid(Integer iid) {
        TipoControl tc = null;

        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            List ltipocontrol = session.createQuery("from TipoControl where iid = " + iid).list();
            if (ltipocontrol.size() >= 1) {
                tc = ((TipoControl) ltipocontrol.get(0));
            } else {
                tc = null;
            }
        } catch (Exception e) {
            tc = null;
        }

        return tc;
    }

    public static TipoControl obtenerTipoControlPorIidBD(Integer iid, Session session) {
        TipoControl tc = null;
        session.beginTransaction();
        try {
            List ltipocontrol = session.createQuery("from TipoControl where iid = " + iid).list();
            if (ltipocontrol.size() >= 1) {
                tc = ((TipoControl) ltipocontrol.get(0));
            } else {
                tc = null;
            }
        } catch (Exception e) {
            tc = null;
            session.getTransaction().rollback();
        }

        return tc;
    }

    public static TipoControl obtenerTipoControlPorNombre(String nombre) {
        TipoControl tc = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            List ltipocontrol = session.createQuery("from TipoControl where nombre = '" + nombre + "'").list();
            if (ltipocontrol.size() >= 1) {
                tc = ((TipoControl) ltipocontrol.get(0));
            } else {
                tc = null;
            }
        } catch (Exception e) {
            tc = null;
        }
        return tc;
    }

    public static List busquedaRapidaTipoControlPorNombre(String nombre) {
        List ltc = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            ltc = session.createQuery("from TipoControl where nombre like '%" + nombre + "%'").list();
        } catch (Exception e) {
            ltc = null;
        }
        return ltc;
    }

    public static List busquedaRapidaTipoControlPorCodigo(String codigo) {
        List ltc = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            ltc = session.createQuery("from TipoControl where codigo like '%" + codigo + "%'").list();
        } catch (Exception e) {
            ltc = null;
        }
        return ltc;
    }

    public static List busquedaRapidaTipoControlPorTipoMedida(String nombreTipoMedida) {
        List ltc = null;
        List lres = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            String consulta = "select tc.codigo "
                    + "from TipoControl tc "
                    + "inner join tc.iid_tipo_medida as tm "
                    + "where tm.nombre like '%" + nombreTipoMedida + "%'";
            ltc = session.createQuery(consulta).list();

            if (ltc != null) {
                lres = new ArrayList();
                TipoControl tc;
                for (Iterator it = ltc.iterator(); it.hasNext();) {
                    tc = BaseDatos.obtenerTipoControl((String) it.next());
                    lres.add(tc);
                }
            }
        } catch (Exception e) {
            ltc = null;
        }
        return lres;
    }

    /*******************************
     * Métodos de la clase Empresa *
     *******************************/
    
    public static boolean crearEmpresa(Empresa e) {
        boolean resultado = true;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        
        try {
            Integer iidEmpresa = (Integer) session.save(e);
            e.setIid(iidEmpresa);

            String anioActual = new SimpleDateFormat("yyyy").format(new Date());
            
            Metadata metaData = new Metadata("numPedidoF", "1", e);
            session.save(metaData);
            
            metaData = new Metadata("anioPedidoF", anioActual, e);
            session.save(metaData);
            
            metaData = new Metadata("numAlbaranF", "1", e);
            session.save(metaData);
            
            metaData = new Metadata("anioAlbaranF", anioActual, e);
            session.save(metaData);
            
            metaData = new Metadata("numFacturaF", "1", e);
            session.save(metaData);
            
            metaData = new Metadata("anioFacturaF", anioActual, e);
            session.save(metaData);
            
            metaData = new Metadata("numMedicion", "1", e);
            session.save(metaData);
            
            metaData = new Metadata("anioMedicion", anioActual, e);
            session.save(metaData);
            
            metaData = new Metadata("numFactura", "1", e);
            session.save(metaData);
            
            metaData = new Metadata("anioFactura", anioActual, e);
            session.save(metaData);
            
            metaData = new Metadata("numPresupuesto", "1", e);
            session.save(metaData);
            
            metaData = new Metadata("anioPresupuesto", anioActual, e);
            session.save(metaData);
            
            metaData = new Metadata("numPedido", "1", e);
            session.save(metaData);
            
            metaData = new Metadata("anioPedido", anioActual, e);
            session.save(metaData);
            
            metaData = new Metadata("numAlbaran", "1", e);
            session.save(metaData);
            
            metaData = new Metadata("anioAlbaran", anioActual, e);
            session.save(metaData);
            
            metaData = new Metadata("numAlbaranB", "1", e);
            session.save(metaData);
            
            metaData = new Metadata("anioAlbaranB", anioActual, e);
            session.save(metaData);

        } catch (Exception ex) {
            resultado = false;
            session.getTransaction().rollback();
            log.error("Se ha producido un error al crear la empresa ", ex);
        } finally {
            try {
                if (session.isOpen() && session.getTransaction().isActive()) {
                    session.getTransaction().commit();
                }
            } catch (Exception ex) {
                resultado = false;
                session.getTransaction().rollback();
            }
            return resultado;
        }
    }
    
    public static List getListaEmpresas() {
        List lempresas = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lempresas = session.createQuery("from Empresa").list();
        } catch (Exception e) {
            lempresas = null;
        }
        return lempresas;
    }

    public static Empresa obtenerEmpresa(String codigo) {
        Empresa res = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            List lempresas = session.createQuery("from Empresa where cod_empresa='" + codigo + "'").list();
            if (lempresas.size() >= 1) {
                res = ((Empresa) lempresas.get(0));
            } else {
                res = null;
            }
        } catch (Exception e) {
            res = null;
        }
        return res;
    }

    public static Interlocutor obtenerInterlocutor(Empresa eH, Empresa eM) {
        Interlocutor res = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            List lempresas = session.createQuery("from Interlocutor where empresaMadre= " + eM.getIid() + " and empresaHija = " + eH.getIid()).list();
            if (lempresas.size() >= 1) {
                res = ((Interlocutor) lempresas.get(0));
            } else {
                res = null;
            }
        } catch (Exception e) {
            res = null;
        }
        return res;
    }

    public static List obtenerInterFormulas(Interlocutor i) {
        List res = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            List lformulas = session.createQuery("from InterlocutorFamiliaVenta where interlocutor= " + i.getIid()).list();
            if (lformulas.size() >= 1) {
                res = lformulas;
            } else {
                res = null;
            }
        } catch (Exception e) {
            res = null;
        }
        return res;
    }

    public static Empresa obtenerEmpresaPorIid(Integer iid) {
        Empresa res = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            List lempresas = session.createQuery("from Empresa where iid = " + iid).list();
            if (lempresas.size() >= 1) {
                res = ((Empresa) lempresas.get(0));
            } else {
                res = null;
            }
        } catch (Exception e) {
            res = null;
        }
        return res;
    }

    public static Empresa obtenerEmpresaDesc(String descEmpresa) {
        Empresa res = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            List lempresas = session.createQuery("from Empresa where desc_empresa = '" + descEmpresa + "'").list();
            if (lempresas.size() >= 1) {
                res = ((Empresa) lempresas.get(0));
            } else {
                res = null;
            }
        } catch (Exception e) {
            res = null;
        } 
        return res;
    }

    public static List busquedaRapidaEmpresas(String descripcion) {
        List lempresas = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lempresas = session.createQuery("from Empresa where desc_empresa like '%" + descripcion + "%'").list();
        } catch (Exception e) {
            lempresas = null;
        }
        return lempresas;
    }

    public static List obtenerDescEmpresas() {
        List ldescempresas = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            ldescempresas = session.createQuery("select desc_empresa from Empresa").list();
        } catch (Exception e) {
            ldescempresas = null;
        }
        return ldescempresas;
    }

    /********************************
     * Métodos de la clase Articulo *
	 ********************************/
    public static List getListaArticulos(Integer iidEmpresa) {
        List lart = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lart = session.createQuery("from Articulo where iid_empresa = " + iidEmpresa).list();
        } catch (Exception e) {
            e.printStackTrace();
            lart = null;
        }
        return lart;
    }

    public static List getListaArticulosLonas(Integer iidEmpresa) {
        List lart = null;
        List listaArticulos = new ArrayList();
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            String consulta = "select arti.iid, arti.des_inf, arti.cod_articulo, arti.iid_fam_venta"
                    + " from Articulo arti"
                    + " inner join arti.iid_fam_venta as fv "
                    + " where fv.iid_empresa = " + iidEmpresa
                    + " and fv.confeccionable = true";

            lart = session.createQuery(consulta).list();
            if (lart != null) {
                Iterator iter = lart.iterator();
                Articulo articuloTemp;
                Object[] elemento;
                while (iter.hasNext()) {
                    elemento = (Object[]) iter.next();
                    articuloTemp = new Articulo();
                    articuloTemp.setIid((Integer) elemento[0]);
                    articuloTemp.setDes_inf((String) elemento[1]);
                    articuloTemp.setCod_articulo((String) elemento[2]);
                    articuloTemp.setIid_fam_venta((FamiliaVenta) elemento[3]);
                    listaArticulos.add(articuloTemp);
                }
            }

        } catch (Exception e) {
            listaArticulos = null;
        }
        return listaArticulos;
    }

    public static List getListaArticulosPerfiles(Integer iidEmpresa) {
        List lart = null;
        List listaArticulos = new ArrayList();
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            String consulta = "select arti.iid, arti.des_inf, arti.cod_articulo, arti.iid_fam_venta"
                    + " from Articulo arti"
                    + " inner join arti.iid_fam_venta as fv "
                    + " where fv.iid_empresa = " + iidEmpresa
                    + " and fv.recortable = true";

            lart = session.createQuery(consulta).list();
            if (lart != null) {
                Iterator iter = lart.iterator();
                Articulo articuloTemp;
                Object[] elemento;
                while (iter.hasNext()) {
                    elemento = (Object[]) iter.next();
                    articuloTemp = new Articulo();
                    articuloTemp.setIid((Integer) elemento[0]);
                    articuloTemp.setDes_inf((String) elemento[1]);
                    articuloTemp.setCod_articulo((String) elemento[2]);
                    articuloTemp.setIid_fam_venta((FamiliaVenta) elemento[3]);
                    listaArticulos.add(articuloTemp);
                }
            }

        } catch (Exception e) {
            listaArticulos = null;
        }
        return listaArticulos;
    }

    public static List getListaArticulosSeleccionDACTodos(Integer iidEmpresa) {
        List lart = null;
        List listaArticulos = new ArrayList();
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            String consulta = "select arti.iid, arti.des_inf, arti.cod_articulo, arti.iid_fam_venta"
                    + " from Articulo arti"
                    + " inner join arti.iid_fam_venta as fv "
                    + " where fv.iid_empresa = " + iidEmpresa;

            lart = session.createQuery(consulta).list();
            if (lart != null) {
                Iterator iter = lart.iterator();
                Articulo articuloTemp;
                Object[] elemento;
                while (iter.hasNext()) {
                    elemento = (Object[]) iter.next();
                    articuloTemp = new Articulo();
                    articuloTemp.setIid((Integer) elemento[0]);
                    articuloTemp.setDes_inf((String) elemento[1]);
                    articuloTemp.setCod_articulo((String) elemento[2]);
                    articuloTemp.setIid_fam_venta((FamiliaVenta) elemento[3]);
                    listaArticulos.add(articuloTemp);
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
            listaArticulos = null;
        }
        return listaArticulos;
    }

    public static List getListaArticulosSeleccionDAC(Integer iidEmpresa) {
        List lart = null;
        List listaArticulos = new ArrayList();
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            String consulta = "select arti.iid, arti.des_inf, arti.cod_articulo, arti.iid_fam_venta"
                    + " from Articulo arti"
                    + " inner join arti.iid_fam_venta as fv "
                    + " where fv.iid_empresa = " + iidEmpresa
                    + " and (fv.confeccionable = false or fv.confeccionable is null) "
                    + " and (fv.recortable = false or fv.recortable is null)";

            lart = session.createQuery(consulta).list();
            if (lart != null) {
                Iterator iter = lart.iterator();
                Articulo articuloTemp;
                Object[] elemento;
                while (iter.hasNext()) {
                    elemento = (Object[]) iter.next();
                    articuloTemp = new Articulo();
                    articuloTemp.setIid((Integer) elemento[0]);
                    articuloTemp.setDes_inf((String) elemento[1]);
                    articuloTemp.setCod_articulo((String) elemento[2]);
                    articuloTemp.setIid_fam_venta((FamiliaVenta) elemento[3]);
                    listaArticulos.add(articuloTemp);
                }
            }

        } catch (Exception e) {
            listaArticulos = null;
        }
        return listaArticulos;
    }

    public static List getListaArticulosSimples(Integer iidEmpresa) {
        //Obtiene todos los artículos que no sea DAC
        List lart = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lart = session.createQuery("from Articulo where iid_empresa = " + iidEmpresa + " and iid_fam_venta != 6").list();
        } catch (Exception e) {
            lart = null;
        }
        return lart;
    }

    public static List obtenerCodigoArticulo() {
        List res = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            res = session.createQuery("select distinct(cod_articulo) from Articulo").list();
        } catch (Exception e) {
            res = null;
        }
        return res;
    }

    public static Articulo obtenerArticulo(String codigo, Integer iidEmpresa) {
        Articulo res = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            List larticulos = session.createQuery("from Articulo where cod_articulo='" + codigo + "' AND iid_empresa = " + iidEmpresa).list();
            if (larticulos.size() >= 1) {
                res = ((Articulo) larticulos.get(0));
            } else {
                res = null;
            }
        } catch (Exception e) {
            res = null;
        }
        return res;
    }

    public static Articulo obtenerArticuloPorIid(Integer iid) {
        Articulo res = null;

        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            List larticulos = session.createQuery("from Articulo where iid = " + iid).list();
            if (larticulos.size() >= 1) {
                res = ((Articulo) larticulos.get(0));
            } else {
                res = null;
            }
        } catch (Exception e) {
            res = null;
        }
        return res;
    }

    public static EstadoDocumento obtenerEstadoPorIid(Integer iid) {
        EstadoDocumento res = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            List larticulos = session.createQuery("from EstadoDocumento where iid = " + iid).list();
            if (larticulos.size() >= 1) {
                res = ((EstadoDocumento) larticulos.get(0));
            } else {
                res = null;
            }
        } catch (Exception e) {
            res = null;
        }
        return res;
    }

    public static List busquedaRapidaArticuloPorDescripcion(String desc, Integer iidEmpresa) {
        List larticulos = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            larticulos = session.createQuery("from Articulo where des_inf like '%" + desc + "%' AND iid_empresa = " + iidEmpresa).list();
        } catch (Exception e) {
            larticulos = null;
        }
        return larticulos;
    }

    public static List busquedaRapidaArticuloPorDescripcionLonas(String desc, Integer iidEmpresa) {
        List larticulos = new ArrayList();
        List lart = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            String consulta = "select arti.iid, arti.des_inf, arti.cod_articulo, arti.iid_fam_venta"
                    + " from Articulo arti"
                    + " inner join arti.iid_fam_venta as fv "
                    + " where fv.iid_empresa = " + iidEmpresa
                    + " and fv.confeccionable = true "
                    + " and arti.des_inf like '%" + desc + "%'";
            lart = session.createQuery(consulta).list();
            if (lart != null) {
                Iterator iter = lart.iterator();
                Articulo articuloTemp;
                Object[] elemento;
                while (iter.hasNext()) {
                    elemento = (Object[]) iter.next();
                    articuloTemp = new Articulo();
                    articuloTemp.setIid((Integer) elemento[0]);
                    articuloTemp.setDes_inf((String) elemento[1]);
                    articuloTemp.setCod_articulo((String) elemento[2]);
                    articuloTemp.setIid_fam_venta((FamiliaVenta) elemento[3]);
                    larticulos.add(articuloTemp);
                }
            }
        } catch (Exception e) {
            larticulos = null;
        }
        return larticulos;
    }

    public static List busquedaRapidaArticuloPorDescripcionPerfiles(String desc, Integer iidEmpresa) {
        List larticulos = new ArrayList();
        List lart = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            String consulta = "select arti.iid, arti.des_inf, arti.cod_articulo, arti.iid_fam_venta"
                    + " from Articulo arti"
                    + " inner join arti.iid_fam_venta as fv "
                    + " where fv.iid_empresa = " + iidEmpresa
                    + " and fv.recortable = true "
                    + " and arti.des_inf like '%" + desc + "%'";
            lart = session.createQuery(consulta).list();
            if (lart != null) {
                Iterator iter = lart.iterator();
                Articulo articuloTemp;
                Object[] elemento;
                while (iter.hasNext()) {
                    elemento = (Object[]) iter.next();
                    articuloTemp = new Articulo();
                    articuloTemp.setIid((Integer) elemento[0]);
                    articuloTemp.setDes_inf((String) elemento[1]);
                    articuloTemp.setCod_articulo((String) elemento[2]);
                    articuloTemp.setIid_fam_venta((FamiliaVenta) elemento[3]);
                    larticulos.add(articuloTemp);
                }
            }
        } catch (Exception e) {
            larticulos = null;
        }
        return larticulos;
    }

    public static List busquedaRapidaArticuloPorDescripcionSeleccionDac(String desc, Integer iidEmpresa) {
        List larticulos = new ArrayList();
        List lart = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            String consulta = "select arti.iid, arti.des_inf, arti.cod_articulo, arti.iid_fam_venta"
                    + " from Articulo arti"
                    + " inner join arti.iid_fam_venta as fv "
                    + " where fv.iid_empresa = " + iidEmpresa
                    + " and (fv.confeccionable = false or fv.confeccionable is null) "
                    + " and (fv.recortable = false or fv.recortable is null)"
                    + " and arti.des_inf like '%" + desc + "%'";
            lart = session.createQuery(consulta).list();
            if (lart != null) {
                Iterator iter = lart.iterator();
                Articulo articuloTemp;
                Object[] elemento;
                while (iter.hasNext()) {
                    elemento = (Object[]) iter.next();
                    articuloTemp = new Articulo();
                    articuloTemp.setIid((Integer) elemento[0]);
                    articuloTemp.setDes_inf((String) elemento[1]);
                    articuloTemp.setCod_articulo((String) elemento[2]);
                    articuloTemp.setIid_fam_venta((FamiliaVenta) elemento[3]);
                    larticulos.add(articuloTemp);
                }
            }
        } catch (Exception e) {
            larticulos = null;
        }
        return larticulos;
    }

    public static List busquedaRapidaArticuloPorDescripcionSeleccionDacTodos(String desc, Integer iidEmpresa) {
        List larticulos = new ArrayList();
        List lart = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            String consulta = "select arti.iid, arti.des_inf, arti.cod_articulo, arti.iid_fam_venta"
                    + " from Articulo arti"
                    + " inner join arti.iid_fam_venta as fv "
                    + " where fv.iid_empresa = " + iidEmpresa
                    + " and arti.des_inf like '%" + desc + "%'";
            lart = session.createQuery(consulta).list();
            if (lart != null) {
                Iterator iter = lart.iterator();
                Articulo articuloTemp;
                Object[] elemento;
                while (iter.hasNext()) {
                    elemento = (Object[]) iter.next();
                    articuloTemp = new Articulo();
                    articuloTemp.setIid((Integer) elemento[0]);
                    articuloTemp.setDes_inf((String) elemento[1]);
                    articuloTemp.setCod_articulo((String) elemento[2]);
                    articuloTemp.setIid_fam_venta((FamiliaVenta) elemento[3]);
                    larticulos.add(articuloTemp);
                }
            }
        } catch (Exception e) {
            larticulos = null;
        }
        return larticulos;
    }

    public static List busquedaRapidaArticuloPorCodigoLonas(String codigo, Integer iidEmpresa) {
        List larticulos = new ArrayList();
        List lart = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            String consulta = "select arti.iid, arti.des_inf, arti.cod_articulo, arti.iid_fam_venta"
                    + " from Articulo arti"
                    + " inner join arti.iid_fam_venta as fv "
                    + " where fv.iid_empresa = " + iidEmpresa
                    + " and fv.confeccionable = true "
                    + " and arti.cod_articulo like '%" + codigo + "%'";
            lart = session.createQuery(consulta).list();
            if (lart != null) {
                Iterator iter = lart.iterator();
                Articulo articuloTemp;
                Object[] elemento;
                while (iter.hasNext()) {
                    elemento = (Object[]) iter.next();
                    articuloTemp = new Articulo();
                    articuloTemp.setIid((Integer) elemento[0]);
                    articuloTemp.setDes_inf((String) elemento[1]);
                    articuloTemp.setCod_articulo((String) elemento[2]);
                    articuloTemp.setIid_fam_venta((FamiliaVenta) elemento[3]);
                    larticulos.add(articuloTemp);
                }
            }
        } catch (Exception e) {
            larticulos = null;
        }
        return larticulos;
    }

    public static List busquedaRapidaArticuloPorCodigoPerfiles(String codigo, Integer iidEmpresa) {
        List larticulos = new ArrayList();
        List lart = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            String consulta = "select arti.iid, arti.des_inf, arti.cod_articulo, arti.iid_fam_venta"
                    + " from Articulo arti"
                    + " inner join arti.iid_fam_venta as fv "
                    + " where fv.iid_empresa = " + iidEmpresa
                    + " and fv.recortable = true "
                    + " and arti.cod_articulo like '%" + codigo + "%'";
            lart = session.createQuery(consulta).list();
            if (lart != null) {
                Iterator iter = lart.iterator();
                Articulo articuloTemp;
                Object[] elemento;
                while (iter.hasNext()) {
                    elemento = (Object[]) iter.next();
                    articuloTemp = new Articulo();
                    articuloTemp.setIid((Integer) elemento[0]);
                    articuloTemp.setDes_inf((String) elemento[1]);
                    articuloTemp.setCod_articulo((String) elemento[2]);
                    articuloTemp.setIid_fam_venta((FamiliaVenta) elemento[3]);
                    larticulos.add(articuloTemp);
                }
            }
        } catch (Exception e) {
            larticulos = null;
        }
        return larticulos;
    }

    public static List busquedaRapidaArticuloPorCodigoSeleccionDac(String codigo, Integer iidEmpresa) {
        List larticulos = new ArrayList();
        List lart = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            String consulta = "select arti.iid, arti.des_inf, arti.cod_articulo, arti.iid_fam_venta"
                    + " from Articulo arti"
                    + " inner join arti.iid_fam_venta as fv "
                    + " where fv.iid_empresa = " + iidEmpresa
                    + " and (fv.confeccionable = false or fv.confeccionable is null) "
                    + " and (fv.recortable = false or fv.recortable is null)"
                    + " and arti.cod_articulo like '%" + codigo + "%'";
            lart = session.createQuery(consulta).list();
            if (lart != null) {
                Iterator iter = lart.iterator();
                Articulo articuloTemp;
                Object[] elemento;
                while (iter.hasNext()) {
                    elemento = (Object[]) iter.next();
                    articuloTemp = new Articulo();
                    articuloTemp.setIid((Integer) elemento[0]);
                    articuloTemp.setDes_inf((String) elemento[1]);
                    articuloTemp.setCod_articulo((String) elemento[2]);
                    articuloTemp.setIid_fam_venta((FamiliaVenta) elemento[3]);
                    larticulos.add(articuloTemp);
                }
            }
        } catch (Exception e) {
            larticulos = null;
        }
        return larticulos;
    }

    public static List busquedaRapidaArticuloPorCodigoSeleccionDacTodos(String codigo, Integer iidEmpresa) {
        List larticulos = new ArrayList();
        List lart = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            String consulta = "select arti.iid, arti.des_inf, arti.cod_articulo, arti.iid_fam_venta"
                    + " from Articulo arti"
                    + " inner join arti.iid_fam_venta as fv "
                    + " where fv.iid_empresa = " + iidEmpresa
                    + " and arti.cod_articulo like '%" + codigo + "%'";
            lart = session.createQuery(consulta).list();
            if (lart != null) {
                Iterator iter = lart.iterator();
                Articulo articuloTemp;
                Object[] elemento;
                while (iter.hasNext()) {
                    elemento = (Object[]) iter.next();
                    articuloTemp = new Articulo();
                    articuloTemp.setIid((Integer) elemento[0]);
                    articuloTemp.setDes_inf((String) elemento[1]);
                    articuloTemp.setCod_articulo((String) elemento[2]);
                    articuloTemp.setIid_fam_venta((FamiliaVenta) elemento[3]);
                    larticulos.add(articuloTemp);
                }
            }
        } catch (Exception e) {
            larticulos = null;
        }
        return larticulos;
    }

    public static List busquedaRapidaArticuloPorFamiliaLonas(String familia, Integer iidEmpresa) {
        List larticulos = new ArrayList();
        List lart = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            String consulta = "select arti.iid, arti.des_inf, arti.cod_articulo, arti.iid_fam_venta"
                    + " from Articulo arti"
                    + " inner join arti.iid_fam_venta as fv "
                    + " where fv.iid_empresa = " + iidEmpresa
                    + " and fv.confeccionable = true "
                    + " and fv.nombre like '%" + familia + "%' ";
            lart = session.createQuery(consulta).list();
            if (lart != null) {
                Iterator iter = lart.iterator();
                Articulo articuloTemp;
                Object[] elemento;
                while (iter.hasNext()) {
                    elemento = (Object[]) iter.next();
                    articuloTemp = new Articulo();
                    articuloTemp.setIid((Integer) elemento[0]);
                    articuloTemp.setDes_inf((String) elemento[1]);
                    articuloTemp.setCod_articulo((String) elemento[2]);
                    articuloTemp.setIid_fam_venta((FamiliaVenta) elemento[3]);
                    larticulos.add(articuloTemp);
                }
            }
        } catch (Exception e) {
            larticulos = null;
        }
        return larticulos;
    }

    public static List busquedaRapidaArticuloPorFamiliaPerfiles(String familia, Integer iidEmpresa) {
        List larticulos = new ArrayList();
        List lart = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            String consulta = "select arti.iid, arti.des_inf, arti.cod_articulo, arti.iid_fam_venta"
                    + " from Articulo arti"
                    + " inner join arti.iid_fam_venta as fv "
                    + " where fv.iid_empresa = " + iidEmpresa
                    + " and fv.recortable = true "
                    + " and fv.nombre like '%" + familia + "%' ";
            lart = session.createQuery(consulta).list();
            if (lart != null) {
                Iterator iter = lart.iterator();
                Articulo articuloTemp;
                Object[] elemento;
                while (iter.hasNext()) {
                    elemento = (Object[]) iter.next();
                    articuloTemp = new Articulo();
                    articuloTemp.setIid((Integer) elemento[0]);
                    articuloTemp.setDes_inf((String) elemento[1]);
                    articuloTemp.setCod_articulo((String) elemento[2]);
                    articuloTemp.setIid_fam_venta((FamiliaVenta) elemento[3]);
                    larticulos.add(articuloTemp);
                }
            }
        } catch (Exception e) {
            larticulos = null;
        }
        return larticulos;
    }

    public static List busquedaRapidaArticuloPorFamiliaSeleccionDac(String familia, Integer iidEmpresa) {
        List larticulos = new ArrayList();
        List lart = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            String consulta = "select arti.iid, arti.des_inf, arti.cod_articulo, arti.iid_fam_venta"
                    + " from Articulo arti"
                    + " inner join arti.iid_fam_venta as fv "
                    + " where fv.iid_empresa = " + iidEmpresa
                    + " and (fv.confeccionable = false or fv.confeccionable is null) "
                    + " and (fv.recortable = false or fv.recortable is null)"
                    + " and fv.nombre like '%" + familia + "%' ";
            lart = session.createQuery(consulta).list();
            if (lart != null) {
                Iterator iter = lart.iterator();
                Articulo articuloTemp;
                Object[] elemento;
                while (iter.hasNext()) {
                    elemento = (Object[]) iter.next();
                    articuloTemp = new Articulo();
                    articuloTemp.setIid((Integer) elemento[0]);
                    articuloTemp.setDes_inf((String) elemento[1]);
                    articuloTemp.setCod_articulo((String) elemento[2]);
                    articuloTemp.setIid_fam_venta((FamiliaVenta) elemento[3]);
                    larticulos.add(articuloTemp);
                }
            }
        } catch (Exception e) {
            larticulos = null;
        }
        return larticulos;
    }

    public static List busquedaRapidaArticuloPorFamiliaSeleccionDacTodos(String familia, Integer iidEmpresa) {
        List larticulos = new ArrayList();
        List lart = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            String consulta = "select arti.iid, arti.des_inf, arti.cod_articulo, arti.iid_fam_venta"
                    + " from Articulo arti"
                    + " inner join arti.iid_fam_venta as fv "
                    + " where fv.iid_empresa = " + iidEmpresa
                    + " and fv.nombre like '%" + familia + "%' ";
            lart = session.createQuery(consulta).list();
            if (lart != null) {
                Iterator iter = lart.iterator();
                Articulo articuloTemp;
                Object[] elemento;
                while (iter.hasNext()) {
                    elemento = (Object[]) iter.next();
                    articuloTemp = new Articulo();
                    articuloTemp.setIid((Integer) elemento[0]);
                    articuloTemp.setDes_inf((String) elemento[1]);
                    articuloTemp.setCod_articulo((String) elemento[2]);
                    articuloTemp.setIid_fam_venta((FamiliaVenta) elemento[3]);
                    larticulos.add(articuloTemp);
                }
            }
        } catch (Exception e) {
            larticulos = null;
        }
        return larticulos;
    }

    public static List busquedaRapidaArticuloPorDescripcionPorProveedor(String desc, Integer iidEmpresa, Integer iidProveedor) {
        List larticulos = null;
        List laac = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            String consulta = "select ar.iid "
                    + "from AgenteArticuloCodigo aac "
                    + "inner join aac.iid_articulo as ar "
                    + "where ar.des_inf like '%" + desc + "%' "
                    + "AND ar.iid_empresa = " + iidEmpresa + " "
                    + "and aac.iid_agente = " + iidProveedor;

            laac = session.createQuery(consulta).list();

            larticulos = new ArrayList();
            if (laac != null) {
                Iterator it = laac.iterator();
                Integer iid_articulo;
                while (it.hasNext()) {
                    iid_articulo = (Integer) it.next();
                    larticulos.add(BaseDatos.obtenerArticuloPorIid(iid_articulo));
                }
            }
        } catch (Exception e) {
            larticulos = null;
        }
        return larticulos;
    }

    public static List busquedaRapidaArticuloPorCodigo(String codigo, Integer iidEmpresa) {
        List larticulos = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            larticulos = session.createQuery("from Articulo where cod_articulo like '%" + codigo + "%' AND iid_empresa = " + iidEmpresa).list();
        } catch (Exception e) {
            larticulos = null;
        }
        return larticulos;
    }

    public static List busquedaRapidaArticuloPorCodigoPorProveedor(String codigo, Integer iidEmpresa, Integer iidProveedor) {
        List larticulos = null;
        List laac = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            String consulta = "select ar.iid "
                    + "from AgenteArticuloCodigo aac "
                    + "inner join aac.iid_articulo as ar "
                    + "where ar.cod_articulo like '%" + codigo + "%' "
                    + "AND ar.iid_empresa = " + iidEmpresa + " "
                    + "and aac.iid_agente = " + iidProveedor;
            laac = session.createQuery(consulta).list();

            larticulos = new ArrayList();
            if (laac != null) {
                Iterator it = laac.iterator();
                Integer iid_articulo;
                while (it.hasNext()) {
                    iid_articulo = (Integer) it.next();
                    larticulos.add(BaseDatos.obtenerArticuloPorIid(iid_articulo));
                }
            }
        } catch (Exception e) {
            larticulos = null;
        }
        return larticulos;
    }

    public static List busquedaRapidaArticuloPorTipoProducto(String tp, Integer iidEmpresa) {
        List larticulos = null;
        List lres = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            String consulta = "select ar.iid "
                    + "from Articulo ar "
                    + "inner join ar.cod_tipo_pro as tp "
                    + "where tp.descripcion like '%" + tp + "%' "
                    + "and ar.iid_empresa = " + iidEmpresa;
            larticulos = session.createQuery(consulta).list();
            if (larticulos != null) {
                lres = new ArrayList();
                Articulo ar;
                for (Iterator it = larticulos.iterator(); it.hasNext();) {
                    ar = BaseDatos.obtenerArticuloPorIid((Integer) it.next());
                    lres.add(ar);
                }
            }
        } catch (Exception e) {
            lres = null;
        }
        return lres;
    }
    
    public static List busquedaRapidaArticuloPorFamilia(String familia, Integer iidEmpresa) {
        List larticulos = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            String consulta = "select ar "
                    + "from Articulo ar "
                    + "inner join ar.iid_fam_venta as fv "
                    + "where fv.nombre like '%" + familia + "%' "
                    + "and ar.iid_empresa = " + iidEmpresa;
            larticulos = session.createQuery(consulta).list();
        } catch (Exception ex) {
            log.error("Error en método busquedaRapidaArticuloPorFamilia ", ex);
            larticulos = null;
        }
        return larticulos;
    }

    public static List busquedaRapidaArticuloPorFamiliaPorProveedor(String familia, Integer iidEmpresa, Integer iidProveedor) {
        List larticulos = null;
        List lres = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            String consulta = "select ar.iid "
                    + "from AgenteArticuloCodigo aac "
                    + "inner join aac.iid_articulo as ar "
                    + "inner join ar.iid_fam_venta as fv "
                    + "where fv.cod_familia like '%" + familia + "%' "
                    + "and ar.iid_empresa = " + iidEmpresa
                    + " and aac.iid_agente = " + iidProveedor;
            larticulos = session.createQuery(consulta).list();
            if (larticulos != null) {
                lres = new ArrayList();
                Articulo ar;
                for (Iterator it = larticulos.iterator(); it.hasNext();) {
                    ar = BaseDatos.obtenerArticuloPorIid((Integer) it.next());
                    lres.add(ar);
                }
            }
        } catch (Exception e) {
            lres = null;
        }
        return lres;
    }
    
    public static boolean insertarArticulo(Articulo ar, List<Caracteristica> lcar, List<Escalado> lesc, List<MovimientoAlmacen> lmov, List<Existencia> lex, List<ArticuloDescuento> lDescuento, List<AgenteArticulo> listaAgenteArticulo, List<AgenteArticuloCodigo> listaAgenteArticuloCodigo,List lp,String accion, String usuario) {
        return insertarArticulo(ar, lcar, lesc, lmov, lex, lDescuento, listaAgenteArticulo, listaAgenteArticuloCodigo, lp, accion, usuario, null);
    }

    public static boolean insertarArticulo(Articulo ar, List<Caracteristica> lcar, List<Escalado> lesc, List<MovimientoAlmacen> lmov, List<Existencia> lex, List<ArticuloDescuento> lDescuento, List<AgenteArticulo> listaAgenteArticulo, List<AgenteArticuloCodigo> listaAgenteArticuloCodigo,List lp,String accion, String usuario, LogMasivoProgreso lmp) {
        boolean res = true;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {

            //Guardamos el articulo
            Integer idArticulo = (Integer) session.save(ar);
            ar.setIid(idArticulo);
            if(lmp != null){
                lmp.insertarLinea("Insertardo artículo " + ar.getCod_articulo());
            }

            //Guardamos las caracteristicas
            HashMap mapCar = new HashMap();
            Iterator carIterator = lcar.iterator();
            Caracteristica car;
            Integer idCaracteristica;

            while (carIterator.hasNext()) {
                car = (Caracteristica) carIterator.next();
                car.setIid_articulo(ar);
                idCaracteristica = (Integer) session.save(car);
                if(lmp != null){
                    lmp.insertarLinea("Insertardo artículo " + ar.getCod_articulo() + " - característica " + car.getIid_color().getCod_color());
                }
                car.setIid(idCaracteristica);
                mapCar.put(car.getIid_color().getCod_color(), car);
            }

            //Guardamos los escalados
            if (lesc != null && lesc.size() > 0) {
                Escalado esc;
                Iterator escIterator = lesc.iterator();
                while (escIterator.hasNext()) {
                    esc = (Escalado) escIterator.next();
                    esc.setArticulo(ar);
                    car = esc.getCaracteristica();
                    if (car != null) {
                        car = (Caracteristica) mapCar.get(car.getIid_color().getCod_color());
                        esc.setCaracteristica(car);
                    }
                    session.save(esc);
                }
            }

            //Guardamos los movimientos
            if (lmov != null && lmov.size() > 0) {
                MovimientoAlmacen mov;
                Iterator movIterator = lmov.iterator();
                while (movIterator.hasNext()) {
                    mov = (MovimientoAlmacen) movIterator.next();
                    mov.setArticulo(ar);
                    car = mov.getCaracteristica();
                    if (car != null) {
                        car = (Caracteristica) mapCar.get(car.getIid_color().getCod_color());
                        mov.setCaracteristica(car);
                    }
                    session.save(mov);
                }
            }
            
            //Guardamos precio
            Iterator ilp = lp.iterator();
            while (ilp.hasNext()){
                Precios p = (Precios) ilp.next();
                p.setIid_art(ar);
                p.setUsuario(usuario);
                p.setAccion(accion);
                session.save(p);
            
            }

            //Guardamos las existencias
            if (lex != null && lex.size() > 0) {
                Existencia ex;
                Iterator exIterator = lex.iterator();
                while (exIterator.hasNext()) {
                    ex = (Existencia) exIterator.next();
                    ex.setArticulo(ar);
                    car = ex.getCaracteristica();
                    if (car != null) {
                        car = (Caracteristica) mapCar.get(car.getIid_color().getCod_color());
                        ex.setCaracteristica(car);
                    }
                    session.save(ex);
                }
            }

            //Guardamos los descuentos
            if (lDescuento != null && lDescuento.size() > 0) {
                ArticuloDescuento ad;
                Iterator escArticuloDescuento = lDescuento.iterator();
                while (escArticuloDescuento.hasNext()) {
                    ad = (ArticuloDescuento) escArticuloDescuento.next();
                    ad.setArticulo(ar);
                    session.save(ad);
                }
           }

            //Guardamos los agentesArticulos
            if (listaAgenteArticulo != null && listaAgenteArticulo.size() > 0) {
                AgenteArticulo aa;
                Iterator it = listaAgenteArticulo.iterator();
                while (it.hasNext()) {
                    aa = (AgenteArticulo) it.next();
                    aa.setIid_articulo(ar);
                    session.save(aa);
                }
            }

            //Guardamos los agentesArticulosCodigo
            if (listaAgenteArticuloCodigo != null && listaAgenteArticuloCodigo.size() > 0) {
                AgenteArticuloCodigo aac;
                Iterator it = listaAgenteArticuloCodigo.iterator();
                while (it.hasNext()) {
                    aac = (AgenteArticuloCodigo) it.next();
                    aac.setIid_articulo(ar);
                    session.save(aac);
                }
            }

        } catch (Exception e) {
            res = false;
            session.getTransaction().rollback();
        } finally {
            try {
                if (session.isOpen() && session.getTransaction().isActive()) {
                    session.getTransaction().commit();
                }
            } catch (Exception ex) {
                res = false;
                session.getTransaction().rollback();
            }
            return res;
        }
    }

    public static void limpiarArticulosUsados(String nombreUsuario) {
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            String updateUso = "Update Articulo set enUso = '' where enUso = '" + nombreUsuario + "'";
            session.createQuery(updateUso).executeUpdate();
        } catch (Exception e) {
            session.getTransaction().rollback();
        } finally {
            try {
                if (session.isOpen() && session.getTransaction().isActive()) {
                    session.getTransaction().commit();
                }
            } catch (Exception ex) {
                session.getTransaction().rollback();
            }
        }
    }

    public static boolean desUsarArticulo(Integer codigoArticulo) {
        boolean res = true;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            session.createQuery("Update Articulo set enUso = '' where iid = " + codigoArticulo).executeUpdate();
        } catch (Exception e) {
            res = false;
            session.getTransaction().rollback();
        } finally {
            try {
                if (session.isOpen() && session.getTransaction().isActive()) {
                    session.getTransaction().commit();
                }
            } catch (Exception ex) {
                res = false;
                session.getTransaction().rollback();
            }
            return res;
        }
    }

    public static boolean modificarArticulo(Articulo ar, List<Caracteristica> lcar, List<Escalado> lesc, List<MovimientoAlmacen> lmov, List<MovimientoAlmacen> lmovBorrados, List<MovimientoAlmacen> lmovCreados, boolean actualizarMovExistencias, List<ArticuloDescuento> lDescuento, List<AgenteArticulo> lAgenteArticulo, List<AgenteArticuloCodigo> lAgenteArticuloCodigo, List lp,String accion, String usuario) {
        boolean res = true;
        
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.clear();
        session.beginTransaction();
        try {

            String scaracteristicas = "";
            String sescalados = "";
            String sMovimientosBorrados = "";
            String sDescuentos = "";
            boolean hayCaracteristicas = false;
            boolean hayEscalados = false;
            MovimientoAlmacen mov;
            Iterator movIterator;

            //Guardamos el artículo
            session.update(ar);

            //CaracterisitcasBBDD
            HashMap mapCar = new HashMap();
            Iterator carIterator = lcar.iterator();
            Caracteristica car;
            int contadorCaracteristica = 0;
            int indiceCaracteristicaBBDD = 0;
            Caracteristica carTemp;
            Integer idCaracteristica;
            List<Caracteristica> listaCaracterisitcaBBDD = session.createQuery("from Caracteristica where iid_articulo.iid = " + ar.getIid()).list();

            //Guardamos las caracterÃ­sticas
            while (carIterator.hasNext()) {
                carTemp = (Caracteristica) carIterator.next();
                carTemp.setIid_articulo(ar);

                if (indiceCaracteristicaBBDD + 1 > listaCaracterisitcaBBDD.size()) {
                    car = new Caracteristica();
                } else {
                    car = (Caracteristica) listaCaracterisitcaBBDD.get(contadorCaracteristica);
                    contadorCaracteristica++;
                }

                car.setCantidad_stock_minimo(carTemp.getCantidad_stock_minimo());
                car.setCond_pedir(carTemp.getCond_pedir());
                car.setEscalado(carTemp.getEscalado());
                car.setIid_articulo(ar);
                car.setIid_color(carTemp.getIid_color());
                car.setIid_empresa(carTemp.getIid_empresa());
                car.setPtc(carTemp.getPtc());
                car.setPvp(carTemp.getPvp());
                car.setStock_max(carTemp.getStock_max());
                car.setStock_min(carTemp.getStock_min());
                car.setUpc(carTemp.getUpc());
                car.setPrecioIncremento(carTemp.getPrecioIncremento());

                if (indiceCaracteristicaBBDD + 1 > listaCaracterisitcaBBDD.size()) {
                    idCaracteristica = (Integer) session.save(car);
                } else {
                    idCaracteristica = car.getIid();
                    indiceCaracteristicaBBDD++;
                    session.update(car);
                }

                scaracteristicas += car.getIid() + ",";
                mapCar.put(car.getIid_color().getCod_color(), car);
            }
            hayCaracteristicas = mapCar.size() > 0;

            //AgentesArticulosBBDD
            Iterator aaIterator = lAgenteArticulo.iterator();
            AgenteArticulo aa;
            int contadorAa = 0;
            int indiceAaBBDD = 0;
            AgenteArticulo aaTemp;
            Integer idAa;
            List<AgenteArticulo> listaAaBBDD = session.createQuery("from AgenteArticulo where iid_articulo.iid = " + ar.getIid()).list();

            //Guardamos los AgentesArticulos
            while (aaIterator.hasNext()) {
                aaTemp = (AgenteArticulo) aaIterator.next();
                aaTemp.setIid_articulo(ar);

                if (indiceAaBBDD + 1 > listaAaBBDD.size()) {
                    aa = new AgenteArticulo();
                } else {
                    aa = (AgenteArticulo) listaAaBBDD.get(contadorAa);
                    contadorAa++;
                }

                aa.setIid_agente(aaTemp.getIid_agente());
                aa.setIid_articulo(ar);

                car = aaTemp.getIid_caracteristica();
                if (car != null) {
                    car = (Caracteristica) mapCar.get(car.getIid_color().getCod_color());
                }
                aa.setIid_caracteristica(car);
                aa.setIid_empresa(aaTemp.getIid_empresa());
                aa.setPlazo_entrega(aaTemp.getPlazo_entrega());
                aa.setPrecio(aaTemp.getPrecio());
                aa.setReferencia(aaTemp.getReferencia());

                if (indiceAaBBDD + 1 > listaAaBBDD.size()) {
                    session.save(aa);
                } else {
                    indiceAaBBDD++;
                    session.update(aa);
                }
            }

            //AgentesArticulosCodigoBBDD
            Iterator aacIterator = lAgenteArticuloCodigo.iterator();
            AgenteArticuloCodigo aac;
            int contadorAac = 0;
            int indiceAacBBDD = 0;
            AgenteArticuloCodigo aacTemp;
            Integer idAac;
            List<AgenteArticuloCodigo> listaAacBBDD = session.createQuery("from AgenteArticuloCodigo where iid_articulo.iid = " + ar.getIid()).list();

            //Guardamos los AgentesArticuloCodigo
            while (aacIterator.hasNext()) {
                aacTemp = (AgenteArticuloCodigo) aacIterator.next();
                aacTemp.setIid_articulo(ar);

                if (indiceAacBBDD + 1 > listaAacBBDD.size()) {
                    aac = new AgenteArticuloCodigo();
                } else {
                    aac = (AgenteArticuloCodigo) listaAacBBDD.get(contadorAac);
                    contadorAac++;
                }

                aac.setCheckDto(aacTemp.getCheckDto());
                aac.setDescuento(aacTemp.getDescuento());
                aac.setCodigo(aacTemp.getCodigo());
                aac.setDescripcion(aacTemp.getDescripcion());
                aac.setIid_agente(aacTemp.getIid_agente());
                aac.setIid_articulo(ar);
                aac.setPrecio(aacTemp.getPrecio());
                aac.setTipoPrecio(aacTemp.getTipoPrecio());
                aac.setIid_color(aacTemp.getIid_color());

                if (indiceAacBBDD + 1 > listaAacBBDD.size()) {
                    session.save(aac);
                } else {
                    indiceAacBBDD++;
                    session.update(aac);
                }
            }
            
            //Guardamos el precio
            Iterator itP = lp.iterator();
            Precios pT = new Precios();
                 
            while (itP.hasNext()) {
                pT = (Precios) itP.next();
                    pT.setUsuario(usuario);
                    pT.setAccion(accion);
                    session.save(pT);
            }

            //Guardamos los descuentos
            Iterator desIterator = lDescuento.iterator();
            ArticuloDescuento ad;
            Integer idArticuloDescuento;
            while (desIterator.hasNext()) {
                ad = (ArticuloDescuento) desIterator.next();
                ad.setArticulo(ar);
                if (ad.getIid() == null) {
                    idArticuloDescuento = (Integer) session.save(ad);
                    ad.setIid(idArticuloDescuento);
                } else {
                    session.update(ad);
                }
                sDescuentos += ad.getIid() + ",";
            }

            //Guardamos los escalados
            Integer iidEscalado;
            if (lesc != null && lesc.size() > 0) {
                hayEscalados = true;
                Escalado esc;
                Iterator escIterator = lesc.iterator();
                while (escIterator.hasNext()) {
                    esc = (Escalado) escIterator.next();
                    esc.setArticulo(ar);
                    car = esc.getCaracteristica();
                    if (car != null) {
                        car = (Caracteristica) mapCar.get(car.getIid_color().getCod_color());
                        esc.setCaracteristica(car);
                    }

                    if (esc.getIid() != null) {
                        session.update(esc);
                    } else {
                        iidEscalado = (Integer) session.save(esc);
                        esc.setIid(iidEscalado);
                    }
                    sescalados += esc.getIid() + ",";
                }
            }

            if (actualizarMovExistencias) {
                car = lcar.get(0);
                car = (Caracteristica) mapCar.get(car.getIid_color().getCod_color());
                String consultaMovimientos = "Update MovimientoAlmacen set caracteristica = " + car.getIid() + " where caracteristica is null AND articulo.iid = " + ar.getIid();
                String consultaExistencias = "Update Existencia set caracteristica = " + car.getIid() + " where caracteristica is null AND articulo.iid = " + ar.getIid();
                session.createQuery(consultaMovimientos).executeUpdate();
                session.createQuery(consultaExistencias).executeUpdate();
            }

            //Borramos los movimientos que se hayan eliminados
            if (lmovBorrados != null && lmovBorrados.size() > 0) {
                movIterator = lmovBorrados.iterator();
                while (movIterator.hasNext()) {
                    mov = (MovimientoAlmacen) movIterator.next();
                    if (mov.getIid() != null) {
                        sMovimientosBorrados += mov.getIid() + ",";
                        session.delete(mov);

                        //Aquí­ hay que actualizar las existencias de este movimiento
                        Existencia ex;
                        String queryEx = sExistencia(mov);
                        List lExistencias = session.createQuery(queryEx).list();
                        if (lExistencias.size() >= 1) {
                            //Si la lista no estÃ¡ vacÃ­a se devuelve primer elemento
                            ex = ((Existencia) lExistencias.get(0));
                            ex.setExistencia(ex.getExistencia() - mov.getCantidad());
                            session.update(ex);

                        }
                    }
                }
            }

            //Actualizamos las existencias de los movimientos que se hayan creado/actualizado
            if (lmovCreados != null && lmovCreados.size() > 0) {
                movIterator = lmovCreados.iterator();
                MovimientoAlmacen movAntiguo;
                Existencia ex;
                while (movIterator.hasNext()) {
                    mov = (MovimientoAlmacen) movIterator.next();
                    if (!lmovBorrados.contains(mov)) {
                        car = mov.getCaracteristica();
                        if (car != null) {
                            car = (Caracteristica) mapCar.get(car.getIid_color().getCod_color());
                            mov.setCaracteristica(car);
                        }

                        Float cantidadAntigua = mov.getCantidad();
                        String query = sMovimientoAlmacen(mov);
                        String queryExistencia = sExistencia(mov);
                        MovimientoAlmacen maBBDD;
                        List lMovimientosAlmacen = session.createQuery(query).list();
                        List lExistencias = session.createQuery(queryExistencia).list();
                        if (lMovimientosAlmacen.size() >= 1) {
                            //Se ha de actualizar el movimiento y modificar la existencia
                            maBBDD = ((MovimientoAlmacen) lMovimientosAlmacen.get(0));
                            cantidadAntigua -= maBBDD.getCantidad();
                            maBBDD.setIniciarMedidas(mov.isIniciarMedidas());
                            maBBDD.setPrecio(mov.getPrecio());
                            maBBDD.setTipoMovimiento(mov.getTipoMovimiento());
                            maBBDD.setValoracionPrecio(mov.getValoracionPrecio());
                            maBBDD.setCantidad(mov.getCantidad());
                            session.update(maBBDD);
                        } else {
                            // Se ha de aÃ±adir el movimiento y modificar la existencia;
                            session.saveOrUpdate(mov);
                        }

                        if (lExistencias.size() > 0) {
                            ex = (Existencia) lExistencias.get(0);
                            ex.setExistencia(ex.getExistencia() + cantidadAntigua);
                            session.update(ex);
                        } else {
                            ex = new Existencia();
                            ex.setAlmacen(mov.getAlmacen());
                            ex.setArticulo(mov.getArticulo());
                            ex.setCantidad1(mov.getCantidad1());
                            ex.setCantidad2(mov.getCantidad2());
                            ex.setCantidad3(mov.getCantidad3());
                            ex.setCantidad4(mov.getCantidad4());
                            ex.setCantidad5(mov.getCantidad5());
                            ex.setCaracteristica(mov.getCaracteristica());
                            ex.setEmpresa(mov.getEmpresa());
                            ex.setExistencia(cantidadAntigua);
                            //Unidades 
                            ex.setUnidadMedida1(mov.getUnidadMedida1());
                            ex.setUnidadMedida2(mov.getUnidadMedida2());
                            ex.setUnidadMedida3(mov.getUnidadMedida3());
                            ex.setUnidadMedida4(mov.getUnidadMedida4());
                            ex.setUnidadMedida5(mov.getUnidadMedida5());
                            ex.setUnidadMedidaTotal(mov.getUnidadMedidaTotal());
                            session.save(ex);
                        }
                    }
                }
            }

            String caracteristicasIn = "";
            if (!scaracteristicas.equals("") && scaracteristicas.length() > 0) {
                caracteristicasIn = scaracteristicas.substring(0, scaracteristicas.length() - 1);
            }

            if (sescalados != null && !sescalados.equals("")) {
                String escaladosIn = sescalados.substring(0, sescalados.length() - 1);
                String deleteEscalados = "";
                if (!caracteristicasIn.equals("")) {
                    deleteEscalados = "delete from Escalado where articulo.iid = " + ar.getIid() + " and (iid not in (" + escaladosIn + ")" + "or caracteristica.iid not in (" + caracteristicasIn + "))";
                } else {
                    deleteEscalados = "delete from Escalado where articulo.iid = " + ar.getIid() + " and (iid not in (" + escaladosIn + "))";
                }
                session.createQuery(deleteEscalados).executeUpdate();
            } else if (lesc != null && lesc.size() == 0) {
                session.createQuery("delete from Escalado where articulo.iid = " + ar.getIid()).executeUpdate();
            }

            if (sMovimientosBorrados != null && !sMovimientosBorrados.equals("")) {
                String movimientosBorradosIn = sMovimientosBorrados.substring(0, sMovimientosBorrados.length() - 1);
                String deleteMovimientosBorrados = "delete from MovimientoAlmacen where articulo.iid = " + ar.getIid() + " and iid in (" + movimientosBorradosIn + ")";
                session.createQuery(deleteMovimientosBorrados);
            }

            Object o;

            if (listaCaracterisitcaBBDD != null) {
                for (int i = indiceCaracteristicaBBDD; i < listaCaracterisitcaBBDD.size(); i++) {
                    car = (Caracteristica) listaCaracterisitcaBBDD.get(i);
                    o = session.load(Caracteristica.class, car.getIid());
                    session.delete(o);
                }
            }

            if (listaAaBBDD != null) {
                for (int i = indiceAaBBDD; i < listaAaBBDD.size(); i++) {
                    aa = (AgenteArticulo) listaAaBBDD.get(i);
                    o = session.load(AgenteArticulo.class, aa.getIid());
                    session.delete(o);
                }
            }

            if (listaAacBBDD != null) {
                for (int i = indiceAacBBDD; i < listaAacBBDD.size(); i++) {
                    aac = (AgenteArticuloCodigo) listaAacBBDD.get(i);
                    o = session.load(AgenteArticuloCodigo.class, aac.getIid());
                    session.delete(o);
                }
            }

            String descuentosIn = "";
            if (!sDescuentos.equals("") && sDescuentos.length() > 0) {
                descuentosIn = sDescuentos.substring(0, sDescuentos.length() - 1);
            }

            String deleteDescuentos;
            if (!descuentosIn.equals("")) {
                deleteDescuentos = "delete from ArticuloDescuento where articulo = " + ar.getIid() + " and iid not in (" + descuentosIn + ")";
                session.createQuery(deleteDescuentos).executeUpdate();
            }

            //String deleteExistencias = "delete from Existencia where existencia = 0";
            //session.createQuery(deleteExistencias).executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
            res = false;
            session.getTransaction().rollback();
            session.update(ar);
        } finally {
            try {
                if (session.isOpen() && session.getTransaction().isActive()) {
                    session.getTransaction().commit();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
                res = false;
                session.getTransaction().rollback();
            }
            return res;
        }
    }

    public static Float obtenerPrecioEscalado(Integer iidArticulo, Integer iidCaracteristica, Integer dim1, Integer dim2) {
        Float res = 0F;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            String query = "From Escalado where articulo.iid = " + iidArticulo;

            if (iidCaracteristica != null) {
                query += " and caracteristica.iid = " + iidCaracteristica;
            } else {
                query += " and caracteristica is null";
            }

            query += " and dimension1 >= " + dim1 + " and dimension2 >= " + dim2 + " order by dimension1, dimension2";

            List listaEscalado = session.createQuery(query).list();
            if (listaEscalado != null && listaEscalado.size() > 0) {
                Escalado esc = (Escalado) listaEscalado.get(0);
                res = esc.getPrecio();
            }

        } catch (Exception e) {
            res = 0F;
        }
        return res;
    }
	
	public static Float obtenerPrecioEscalado(Session session, Integer iidArticulo, Integer iidCaracteristica, Integer dim1, Integer dim2) {
        Float res = 0F;
        String query = "From Escalado where articulo.iid = " + iidArticulo;
        if (iidCaracteristica != null) {
            query += " and caracteristica.iid = " + iidCaracteristica;
        } else {
            query += " and caracteristica is null";
        }
        query += " and dimension1 >= " + dim1 + " and dimension2 >= " + dim2 + " order by dimension1, dimension2";

        List listaEscalado = session.createQuery(query).list();
        if (listaEscalado != null && listaEscalado.size() > 0) {
            res = ((Escalado) listaEscalado.get(0)).getPrecio();
        }

        return res ;
    }

    /**********************************
     * Métodos de la clase TipoMedida *
	 **********************************/
    public static List getListaTipoMedidas() {
        List ltipomedidas = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            ltipomedidas = session.createQuery("from TipoMedida").list();
        } catch (Exception e) {
            ltipomedidas = null;
        }
        return ltipomedidas;
    }

    public static TipoMedida obtenerTipoMedidaByIid(Integer iid) {
        TipoMedida res = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            List ltipomedidas = session.createQuery("from TipoMedida where iid =" + iid).list();
            if (ltipomedidas.size() >= 1) {
                res = ((TipoMedida) ltipomedidas.get(0));
            } else {
                res = null;
            }
        } catch (Exception e) {
            res = null;
        }
        return res;
    }

    public static TipoMedida obtenerTipoMedidaByIidBD(Integer iid, Session session) {
        TipoMedida res = null;
        session.beginTransaction();
        try {
            List ltipomedidas = session.createQuery("from TipoMedida where iid =" + iid).list();
            if (ltipomedidas.size() >= 1) {
                res = ((TipoMedida) ltipomedidas.get(0));
            } else {
                res = null;
            }
        } catch (Exception e) {
            res = null;
        }
        return res;
    }

    public static TipoMedida obtenerTipoMedida(String codigo) {
        TipoMedida res = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            List ltipomedidas = session.createQuery("from TipoMedida where codigo ='" + codigo + "'").list();
            if (ltipomedidas.size() >= 1) {
                res = ((TipoMedida) ltipomedidas.get(0));
            } else {
                res = null;
            }
        } catch (Exception e) {
            res = null;
        }
        return res;
    }

    public static TipoMedida obtenerTipoMedidaPorNombre(String nombre) {
        TipoMedida res = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            List ltipomedidas = session.createQuery("from TipoMedida where nombre ='" + nombre + "'").list();
            if (ltipomedidas.size() >= 1) {
                res = ((TipoMedida) ltipomedidas.get(0));
            } else {
                res = null;
            }
        } catch (Exception e) {
            res = null;
        }
        return res;
    }

    public static List busquedaRapidaTipoMedidaPorCodigo(String codigo) {
        List ltipomedidas = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            ltipomedidas = session.createQuery("from TipoMedida where codigo like '%" + codigo + "%'").list();
        } catch (Exception e) {
            ltipomedidas = null;
        }
        return ltipomedidas;
    }

    public static List busquedaRapidaTipoMedidaPorNombre(String nombre) {
        List ltipomedidas = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            ltipomedidas = session.createQuery("from TipoMedida where nombre like '%" + nombre + "%'").list();
        } catch (Exception e) {
            ltipomedidas = null;
        }
        return ltipomedidas;
    }

    /*******************************
     * Métodos de la clase Agentes *
	 *******************************/
    public static Agentes obtenerAgenteByIid(Integer iid) {
        Agentes res = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            List lagentes = session.createQuery("from Agentes where iid = " + iid).list();
            if (lagentes.size() >= 1) {
                res = ((Agentes) lagentes.get(0));
            } else {
                res = null;
            }
        } catch (Exception e) {
            res = null;
        }
        return res;
    }

    public static List getListaAgentes(Integer iidEmpresa) {
        List lagentes = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lagentes = session.createQuery("from Agentes where iid_empresa = " + iidEmpresa).list();
        } catch (Exception e) {
            lagentes = null;
        }
        return lagentes;
    }

    public static List getListaAgentesReducido(Integer iidEmpresa) {
        List lagentes = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            String consulta = "select agen.nombre_comercial, agen.cod_agente, agen.nombre_fiscal, tiag.descripcion, agen.direccion, agen.poblacion, agen.provincia, agen.pais, agen.telefono, agen.telefono2, agen.telefono3, agen.fax, agen.email, agen.cif_nif "
                    + " from Agentes agen, TipoAgente tiag "
                    + " where agen.tipo_agente = tiag "
                    + " and agen.iid_empresa.iid=" + iidEmpresa;
            lagentes = session.createQuery(consulta).list();
        } catch (Exception e) {
            lagentes = null;
        }
        return lagentes;
    }

    public static List getListaClientes(Empresa em) {
        List lagentes = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lagentes = session.createQuery("from Agentes where tipo_agente in ('CL' , 'PC') and iid_empresa.iid=" + em.getIid()).list();
        } catch (Exception e) {
            lagentes = null;
        }
        return lagentes;
    }

    public static List getListaClientesReducido(Integer iidEmpresa) {
        List lagentes = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lagentes = session.createQuery("select nombre_comercial, cod_agente, nombre_fiscal, direccion, poblacion, provincia, pais, telefono, telefono2, telefono3, fax, email, cif_nif, iid from Agentes where tipo_agente in ('CL' , 'PC') and iid_empresa.iid=" + iidEmpresa).list();
        } catch (Exception e) {
            lagentes = null;
        }
        return lagentes;
    }

    public static List getListaClientesReducidoSinInterlocutores(Integer iidEmpresa) {
        List lagentes = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lagentes = session.createQuery("select nombre_comercial, cod_agente, nombre_fiscal, direccion, poblacion, provincia, pais, telefono, telefono2, telefono3, fax, email, cif_nif from Agentes where tipo_agente in ('CL' , 'PC') and iid_empresa.iid=" + iidEmpresa + " and iid not in (select iidCliente from Interlocutor)").list();
        } catch (Exception e) {
            lagentes = null;
        }
        return lagentes;
    }

    public static List getListaProveedoresReducido(Integer iidEmpresa) {
        List lagentes = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lagentes = session.createQuery("select nombre_comercial, cod_agente, nombre_fiscal, direccion, poblacion, provincia, pais, telefono, telefono2, telefono3, fax, email, cif_nif, iid  from Agentes where tipo_agente in ('PR' , 'PC') and iid_empresa.iid=" + iidEmpresa).list();
        } catch (Exception e) {
            lagentes = null;
        }
        return lagentes;
    }

    public static List getListaProveedores(Empresa em) {
        List lagentes = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lagentes = session.createQuery("from Agentes where tipo_agente in ('PC' , 'PR') and iid_empresa.iid=" + em.getIid()).list();
        } catch (Exception e) {
            lagentes = null;
        }
        return lagentes;
    }

    public static List obtenerNombreComercialProveedor(Empresa em) {
        List listanombreprov = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            listanombreprov = session.createQuery("select nombre_comercial from Agentes where tipo_agente not like 'CL' " + "and iid_empresa=" + em.getIid()).list();
        } catch (Exception e) {
            listanombreprov = null;
        }
        return listanombreprov;
    }

    public static Agentes obtenerAgenteNombreComercial(String nombrecomercial, Empresa em) {
        Agentes res = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            List lagentes = session.createQuery("from Agentes where nombre_comercial='" + nombrecomercial + "' and tipo_agente in ('CL', 'PC') and iid_empresa = " + em.getIid()).list();
            if (lagentes.size() >= 1) {
                res = ((Agentes) lagentes.get(0));
            } else {
                res = null;
            }
        } catch (Exception e) {
            res = null;
        }
        return res;
    }

    public static Agentes obtenerAgentePorEmpresaYCodigo(Integer iidEmpresa, String codigo) {
        Agentes res = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            List lagentes = session.createQuery("from Agentes where cod_agente ='" + codigo + "' and iid_empresa = " + iidEmpresa).list();
            if (lagentes.size() >= 1) {
                res = ((Agentes) lagentes.get(0));
            } else {
                res = null;
            }
        } catch (Exception e) {
            res = null;
        }
        return res;
    }

    public static Object[] obtenerAgentePorEmpresaYCodigoPresupuestoReducido(Integer iidEmpresa, String codigo) {
        Object[] res = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            List lagentes = session.createQuery("select observaciones, iid, exento_iva from Agentes where cod_agente ='" + codigo + "' and iid_empresa = " + iidEmpresa).list();
            if (lagentes.size() >= 1) {
                Object[] aux = (Object[]) lagentes.get(0);
                res = new Object[4];
                res[0] = aux[0];
                res[1] = aux[1];
                res[2] = aux[2];
                res[3] = aux[1];

                String queryIva = "From Iva where iid in (select iva.iid from Agentes where iid = " + (Integer) res[1] + ")";
                List lIva = session.createQuery(queryIva).list();
                if (lIva != null && lIva.size() > 0) {
                    res[1] = (Iva) lIva.get(0);
                } else {
                    res[1] = null;
                }
            } else {
                res = null;
            }
        } catch (Exception e) {
            res = null;
        }
        return res;
    }

    public static Object[] obtenerAgentePorEmpresaYCodigoReducido(Integer iidEmpresa, String codigo) {
        Object[] res = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            List lagentes = session.createQuery("select nombre_comercial, diaCobro1, diaCobro2, diaCobro3 from Agentes where cod_agente ='" + codigo + "' and iid_empresa = " + iidEmpresa).list();
            if (lagentes.size() >= 1) {
                res = (Object[]) lagentes.get(0);
            } else {
                res = null;
            }
        } catch (Exception e) {
            res = null;
        }
        return res;
    }

    public static Agentes obtenerProveedorNombreComercial(String nombrecomercial, Empresa em) {
        Agentes res = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            List lagentes = session.createQuery("from Agentes where nombre_comercial='" + nombrecomercial + "' and tipo_agente in ('PR', 'PC') and iid_empresa = " + em.getIid()).list();
            if (lagentes.size() >= 1) {
                res = ((Agentes) lagentes.get(0));
            } else {
                res = null;
            }
        } catch (Exception e) {
            res = null;
        }
        return res;
    }

    public static Agentes obtenerAgentesCif(String cif_nif, Empresa em) {
        Agentes res = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            List lagentes = session.createQuery("from Agentes where cif_nif ='" + cif_nif + "' and iid_empresa = " + em.getIid()).list();
            if (lagentes.size() >= 1) {
                res = (Agentes) lagentes.get(0);
            } else {
                res = null;
            }
        } catch (Exception e) {
            res = null;
        }
        return res;
    }

    public static Agentes obtenerProveedorHabitual(String nombreComercial, Empresa em) {
        Agentes res = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            List lagentes = session.createQuery("from Agentes where nombre_comercial ='" + nombreComercial + "' and tipo_agente in ('PR', 'PC') and iid_empresa = " + em.getIid()).list();
            if (lagentes.size() >= 1) {
                res = (Agentes) lagentes.get(0);
            } else {
                res = null;
            }
        } catch (Exception e) {
            res = null;
        }
        return res;
    }

    public static Agentes obtenerAgentesPorCodigo(String codigo, String tipo, Empresa em) {
        Agentes res = null;
        String cadena = null;

        if (tipo.equals("cli")) {
            cadena = "' and tipo_agente in ('CL' , 'PC')";
        } else if (tipo.equals("prov")) {
            cadena = "' and tipo_agente in ('PR', 'PC')";
        } else if (tipo.equals("")) {
            cadena = " '";
        }
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            List lagentes = session.createQuery("from Agentes where cod_agente ='" + codigo + cadena + " and iid_empresa = " + em.getIid()).list();
            if (lagentes.size() >= 1) {
                res = (Agentes) lagentes.get(0);
            } else {
                res = null;
            }
        } catch (Exception e) {
            res = null;
        }
        return res;
    }

    public static Object[] obtenerAgentesPorCodigoReducido(String codigo, String tipo, Empresa em) {
        Object[] res;
        String cadena = null;
        if (tipo.equals("cli")) {
            cadena = "' and tipo_agente in ('CL' , 'PC')";
        } else if (tipo.equals("prov")) {
            cadena = "' and tipo_agente in ('PR', 'PC')";
        } else if (tipo.equals("")) {
            cadena = " '";
        }

        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            List lagentes = session.createQuery("select diaCobro1, diaCobro2, diaCobro3 from Agentes where cod_agente ='" + codigo + cadena + " and iid_empresa = " + em.getIid()).list();
            if (lagentes.size() >= 1) {
                res = (Object[]) lagentes.get(0);
            } else {
                res = null;
            }
        } catch (Exception e) {
            res = null;
        }
        return res;
    }

    public static List busquedaRapidaClientesPorNombreComercial(String nombre, Empresa em) {
        List lagentes = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lagentes = session.createQuery("from Agentes where nombre_comercial like '%" + nombre + "%' and tipo_agente in ('CL', 'PC')" + " and iid_empresa = " + em.getIid()).list();
        } catch (Exception e) {
            lagentes = null;
        }
        return lagentes;
    }

    public static List busquedaRapidaProveedoresPorNombreComercial(String nombre, Empresa em) {
        List lagentes = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lagentes = session.createQuery("from Agentes where nombre_comercial like '%" + nombre + "%' and tipo_agente in ('PR', 'PC') and iid_empresa = " + em.getIid()).list();
        } catch (Exception e) {
            lagentes = null;
        }
        return lagentes;
    }

    public static List busquedaRapidaAgentesPorNombreComercial(String nombre, String tipo, Integer iidEmpresa) {
        List lagentes = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            String consulta = "from Agentes where nombre_comercial like '%" + nombre + "%'";
            if (tipo.equals("cli")) {
                consulta += " and tipo_agente in ('CL', 'PC')";
            } else if (tipo.equals("prov")) {
                consulta += " and tipo_agente in ('PR', 'PC')";
            }
            consulta += "and iid_empresa = " + iidEmpresa;
            lagentes = session.createQuery(consulta).list();
        } catch (Exception e) {
            lagentes = null;
        }
        return lagentes;
    }

    public static List busquedaRapidaAgentesPorNombreComercialReducido(String nombre, String tipo, Integer iidEmpresa) {
        List lagentes = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            String consulta = "select nombre_comercial, cod_agente, nombre_fiscal, direccion, poblacion, provincia, pais, telefono, telefono2, telefono3, fax, email, cif_nif "
                    + " from Agentes where iid_empresa = " + iidEmpresa
                    + " and nombre_comercial like '%" + nombre + "%'";
            if (tipo.equals("cli")) {
                consulta += " and tipo_agente in ('CL', 'PC')";
            } else if (tipo.equals("prov")) {
                consulta += " and tipo_agente in ('PR', 'PC')";
            }
            lagentes = session.createQuery(consulta).list();
        } catch (Exception e) {
            lagentes = null;
        }
        return lagentes;
    }

    public static Object[] obtenerAgenteByIdReducido(Integer iid) {
        List lagentes = null;
        Object[] res = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            String consulta = "select ag.nombre_comercial, ag.cod_agente, ag.nombre_fiscal, ag.direccion, ag.poblacion, ag.provincia, ag.pais, ag.telefono, ag.telefono2, ag.telefono3, ag.fax, ag.email, ag.cif_nif, ag.codigo_postal, ag.exento_iva, ag.iid, ag.iid, ag.terceros from Agentes ag where ag.iid = " + iid;
            lagentes = session.createQuery(consulta).list();

            if (lagentes != null && lagentes.size() > 0) {
                res = (Object[]) lagentes.get(0);

                String queryIva = "From Iva where iid in (select iva.iid from Agentes where iid = " + (Integer) res[15] + ")";
                List lIva = session.createQuery(queryIva).list();
                if (lIva != null && lIva.size() > 0) {
                    res[15] = (Iva) lIva.get(0);
                } else {
                    res[15] = null;
                }

                String queryFp = "From FormaPago where iid in (select formaPago.iid from Agentes where iid = " + (Integer) res[16] + ")";
                List lFp = session.createQuery(queryFp).list();
                if (lFp != null && lFp.size() > 0) {
                    res[16] = (FormaPago) lFp.get(0);
                } else {
                    res[16] = null;
                }

            }
        } catch (Exception e) {
            res = null;
        }
        return res;
    }

    public static List busquedaRapidaAgentesPorNombreComercialReducidoTipoAgente(String nombre, String tipo, Integer iidEmpresa) {
        List lagentes = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            String consulta = "select agen.nombre_comercial, agen.cod_agente, agen.nombre_fiscal, tiag.descripcion, agen.direccion, agen.poblacion, agen.provincia, agen.pais, agen.telefono, agen.telefono2, agen.telefono3, agen.fax, agen.email, agen.cif_nif "
                    + " from Agentes agen, TipoAgente tiag "
                    + " where iid_empresa = " + iidEmpresa
                    + " and agen.tipo_agente = tiag "
                    + " and nombre_comercial like '%" + nombre + "%'";
            if (tipo.equals("cli")) {
                consulta += " and tipo_agente in ('CL', 'PC')";
            } else if (tipo.equals("prov")) {
                consulta += " and tipo_agente in ('PR', 'PC')";
            }
            lagentes = session.createQuery(consulta).list();
        } catch (Exception e) {
            lagentes = null;
        }
        return lagentes;
    }

    public static List busquedaRapidaClientesPorNombreFiscal(String nombre, String tipo, Integer iidEmpresa) {
        List lagentes = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            String consulta = "from Agentes where nombre_fiscal like '%" + nombre + "%'";
            if (tipo.equals("cli")) {
                consulta += " and tipo_agente in ('CL', 'PC')";
            } else if (tipo.equals("prov")) {
                consulta += " and tipo_agente in ('PR', 'PC')";
            }
            consulta += "and iid_empresa = " + iidEmpresa;
            lagentes = session.createQuery(consulta).list();
        } catch (Exception e) {
            lagentes = null;
        }
        return lagentes;
    }

    public static List busquedaRapidaClientesPorNombreFiscalReducido(String nombre, String tipo, Integer iidEmpresa) {
        List lagentes = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            String consulta = "select nombre_comercial, cod_agente, nombre_fiscal, direccion, poblacion, provincia, pais, telefono, telefono2, telefono3, fax, email, cif_nif "
                    + " from Agentes where iid_empresa = " + iidEmpresa
                    + " and nombre_fiscal like '%" + nombre + "%'";
            if (tipo.equals("cli")) {
                consulta += " and tipo_agente in ('CL', 'PC')";
            } else if (tipo.equals("prov")) {
                consulta += " and tipo_agente in ('PR', 'PC')";
            }
            lagentes = session.createQuery(consulta).list();
        } catch (Exception e) {
            lagentes = null;
        }
        return lagentes;
    }

    public static List busquedaRapidaClientesPorNombreFiscalReducidoTipoAgente(String nombre, String tipo, Integer iidEmpresa) {
        List lagentes = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            String consulta = "select agen.nombre_comercial, agen.cod_agente, agen.nombre_fiscal, tiag.descripcion, agen.direccion, agen.poblacion, agen.provincia, agen.pais, agen.telefono, agen.telefono2, agen.telefono3, agen.fax, agen.email, agen.cif_nif "
                    + " from Agentes agen, TipoAgente tiag "
                    + " where iid_empresa = " + iidEmpresa
                    + " and agen.tipo_agente = tiag "
                    + " and nombre_fiscal like '%" + nombre + "%'";
            if (tipo.equals("cli")) {
                consulta += " and tipo_agente in ('CL', 'PC')";
            } else if (tipo.equals("prov")) {
                consulta += " and tipo_agente in ('PR', 'PC')";
            }
            lagentes = session.createQuery(consulta).list();
        } catch (Exception e) {
            lagentes = null;
        }
        return lagentes;
    }

    public static List busquedaRapidaClientesPorCodigo(String codigo, String tipo, Integer iidEmpresa) {
        List lagentes = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            String consulta = "from Agentes where cod_agente like '%" + codigo + "%'";
            if (tipo.equals("cli")) {
                consulta += " and tipo_agente in ('CL', 'PC')";
            } else if (tipo.equals("prov")) {
                consulta += " and tipo_agente in ('PR', 'PC')";
            }
            consulta += " and iid_empresa = " + iidEmpresa;

            lagentes = session.createQuery(consulta).list();
        } catch (Exception e) {
            lagentes = null;
        }
        return lagentes;
    }

    public static List busquedaRapidaClientesPorCodigoReducido(String codigo, String tipo, Integer iidEmpresa) {
        List lagentes = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            String consulta = "select nombre_comercial, cod_agente, nombre_fiscal, direccion, poblacion, provincia, pais, telefono, telefono2, telefono3, fax, email, cif_nif "
                    + " from Agentes where iid_empresa = " + iidEmpresa
                    + " and cod_agente like '%" + codigo + "%'";
            if (tipo.equals("cli")) {
                consulta += " and tipo_agente in ('CL', 'PC')";
            } else if (tipo.equals("prov")) {
                consulta += " and tipo_agente in ('PR', 'PC')";
            }

            lagentes = session.createQuery(consulta).list();
        } catch (Exception e) {
            lagentes = null;
        }
        return lagentes;
    }

    public static List busquedaRapidaClientesPorCodigoReducidoTipoAgente(String codigo, String tipo, Integer iidEmpresa) {
        List lagentes = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            String consulta = "select agen.nombre_comercial, agen.cod_agente, agen.nombre_fiscal, tiag.descripcion, agen.direccion, agen.poblacion, agen.provincia, agen.pais, agen.telefono, agen.telefono2, agen.telefono3, agen.fax, agen.email, agen.cif_nif "
                    + " from Agentes agen, TipoAgente tiag "
                    + " where iid_empresa = " + iidEmpresa
                    + " and agen.tipo_agente = tiag "
                    + " and cod_agente like '%" + codigo + "%'";
            if (tipo.equals("cli")) {
                consulta += " and tipo_agente in ('CL', 'PC')";
            } else if (tipo.equals("prov")) {
                consulta += " and tipo_agente in ('PR', 'PC')";
            }
            lagentes = session.createQuery(consulta).list();
        } catch (Exception e) {
            lagentes = null;
        }
        return lagentes;
    }

    public static List busquedaRapidaAgentesPorNombreComercial(String nombre) {
        List lagentes = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lagentes = session.createQuery("from Agentes where nombre_comercial like '%" + nombre + "%'").list();
        } catch (Exception e) {
            lagentes = null;
        }
        return lagentes;
    }

    public static List busquedaRapidaClientesPorCodigo(String codigo) {
        List lagentes = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lagentes = session.createQuery("from Agentes where cod_agente like '%" + codigo + "%' and tipo_agente in ('CL', 'PC')").list();
        } catch (Exception e) {
            lagentes = null;
        }
        return lagentes;
    }

    public static List busquedaRapidaAgentesPorCodigo(String codigo) {
        List lagentes = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lagentes = session.createQuery("from Agentes where cod_agente like '%" + codigo + "%'").list();
        } catch (Exception e) {
            lagentes = null;
        }
        return lagentes;
    }

    public static List busquedaRapidaProveedoresPorCodigo(String codigo) {
        List lagentes = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lagentes = session.createQuery("from Agentes where cod_agente like '%" + codigo + "%' and tipo_agente in ('PR', 'PC')").list();
        } catch (Exception e) {
            lagentes = null;
        }
        return lagentes;
    }

    public static List busquedaRapidaClientesPorTelefono(String tlf) {
        List lagentes = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lagentes = session.createQuery("from Agentes where (telefono like '%" + tlf + "%' or telefono2 like '%" + tlf + "%')and tipo_agente in ('CL', 'PC')").list();
        } catch (Exception e) {
            lagentes = null;
        }
        return lagentes;
    }

    public static List busquedaRapidaClientesPorTelefono(String tlf, String tipo, Integer iidEmpresa) {
        List lagentes = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            String consulta = "from Agentes where (telefono like '%" + tlf + "%' or telefono2 like '%" + tlf + "%')";
            if (tipo.equals("cli")) {
                consulta += " and tipo_agente in ('CL', 'PC')";
            } else if (tipo.equals("prov")) {
                consulta += " and tipo_agente in ('PR', 'PC')";
            }
            consulta += " and iid_empresa = " + iidEmpresa;
            lagentes = session.createQuery(consulta).list();
        } catch (Exception e) {
            lagentes = null;
        }
        return lagentes;
    }

    public static List busquedaRapidaClientesPorTelefonoReducido(String tlf, String tipo, Integer iidEmpresa) {
        List lagentes = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            String consulta = "select nombre_comercial, cod_agente, nombre_fiscal, direccion, poblacion, provincia, pais, telefono, telefono2, telefono3, fax, email, cif_nif "
                    + " from Agentes where iid_empresa = " + iidEmpresa
                    + " and (telefono like '%" + tlf + "%' or telefono2 like '%" + tlf + "%')";
            if (tipo.equals("cli")) {
                consulta += " and tipo_agente in ('CL', 'PC')";
            } else if (tipo.equals("prov")) {
                consulta += " and tipo_agente in ('PR', 'PC')";
            }
            lagentes = session.createQuery(consulta).list();
        } catch (Exception e) {
            lagentes = null;
        }
        return lagentes;
    }

    public static List busquedaRapidaClientesPorTelefonoReducidoTipoAgente(String tlf, String tipo, Integer iidEmpresa) {
        List lagentes = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            String consulta = "select agen.nombre_comercial, agen.cod_agente, agen.nombre_fiscal, tiag.descripcion, agen.direccion, agen.poblacion, agen.provincia, agen.pais, agen.telefono, agen.telefono2, agen.telefono3, agen.fax, agen.email, agen.cif_nif "
                    + " from Agentes agen, TipoAgente tiag "
                    + " where iid_empresa = " + iidEmpresa
                    + " and agen.tipo_agente = tiag "
                    + " and (telefono like '%" + tlf + "%' or telefono2 like '%" + tlf + "%')";
            if (tipo.equals("cli")) {
                consulta += " and tipo_agente in ('CL', 'PC')";
            } else if (tipo.equals("prov")) {
                consulta += " and tipo_agente in ('PR', 'PC')";
            }
            lagentes = session.createQuery(consulta).list();
        } catch (Exception e) {
            lagentes = null;
        }
        return lagentes;
    }

    public static List busquedaRapidaClientesPorDireccion(String direccion) {
        List lagentes = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lagentes = session.createQuery("from Agentes where direccion like '%" + direccion + "%' and tipo_agente in ('CL', 'PC')").list();
        } catch (Exception e) {
            lagentes = null;
        }
        return lagentes;
    }

    public static List busquedaRapidaClientesPorDireccion(String direccion, String tipo, Integer iidEmpresa) {
        List lagentes = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            String consulta = "from Agentes where direccion like '%" + direccion + "%'";
            if (tipo.equals("cli")) {
                consulta += " and tipo_agente in ('CL', 'PC')";
            } else if (tipo.equals("prov")) {
                consulta += " and tipo_agente in ('PR', 'PC')";
            }
            consulta += " and iid_empresa = " + iidEmpresa;

            lagentes = session.createQuery(consulta).list();
        } catch (Exception e) {
            lagentes = null;
        }
        return lagentes;
    }

    public static List busquedaRapidaClientesPorDireccionReducida(String direccion, String tipo, Integer iidEmpresa) {
        List lagentes = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            String consulta = "select nombre_comercial, cod_agente, nombre_fiscal, direccion, poblacion, provincia, pais, telefono, telefono2, telefono3, fax, email, cif_nif "
                    + " from Agentes where iid_empresa = " + iidEmpresa
                    + " and direccion like '%" + direccion + "%'";
            if (tipo.equals("cli")) {
                consulta += " and tipo_agente in ('CL', 'PC')";
            } else if (tipo.equals("prov")) {
                consulta += " and tipo_agente in ('PR', 'PC')";
            }

            lagentes = session.createQuery(consulta).list();
        } catch (Exception e) {
            lagentes = null;
        }
        return lagentes;
    }

    public static List busquedaRapidaClientesPorDireccionReducidaTipoAgente(String direccion, String tipo, Integer iidEmpresa) {
        List lagentes = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            String consulta = "select agen.nombre_comercial, agen.cod_agente, agen.nombre_fiscal, tiag.descripcion, agen.direccion, agen.poblacion, agen.provincia, agen.pais, agen.telefono, agen.telefono2, agen.telefono3, agen.fax, agen.email, agen.cif_nif "
                    + " from Agentes agen, TipoAgente tiag "
                    + " where iid_empresa = " + iidEmpresa
                    + " and agen.tipo_agente = tiag "
                    + " and direccion like '%" + direccion + "%'";
            if (tipo.equals("cli")) {
                consulta += " and tipo_agente in ('CL', 'PC')";
            } else if (tipo.equals("prov")) {
                consulta += " and tipo_agente in ('PR', 'PC')";
            }

            lagentes = session.createQuery(consulta).list();
        } catch (Exception e) {
            lagentes = null;
        }
        return lagentes;
    }

    public static List busquedaRapidaAgentesPorTelefono(String tlf) {
        List lagentes = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lagentes = session.createQuery("from Agentes where telefono like '%" + tlf + "%'").list();
        } catch (Exception e) {
            lagentes = null;
        }
        return lagentes;
    }

    public static List busquedaRapidaAgentesPorDireccion(String direccion) {
        List lagentes = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lagentes = session.createQuery("from Agentes where direccion like '%" + direccion + "%'").list();
        } catch (Exception e) {
            lagentes = null;
        }
        return lagentes;
    }

    public static List busquedaRapidaProveedoresPorTelefono(String tlf) {
        List lagentes = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lagentes = session.createQuery("from Agentes where telefono like '%" + tlf + "%' and tipo_agente in ('PR', 'PC')").list();
        } catch (Exception e) {
            lagentes = null;
        }
        return lagentes;
    }

    public static List busquedaRapidaProveedoresPorDireccion(String direccion) {
        List lagentes = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lagentes = session.createQuery("from Agentes where direccion like '%" + direccion + "%' and tipo_agente in ('PR', 'PC')").list();
        } catch (Exception e) {
            lagentes = null;
        }
        return lagentes;
    }

    public static List busquedaRapidaClientesPorNombreFiscal(String nombre) {
        List lagentes = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lagentes = session.createQuery("from Agentes where nombre_fiscal like '%" + nombre + "%' and tipo_agente in ('CL', 'PC')").list();
        } catch (Exception e) {
            lagentes = null;
        }
        return lagentes;
    }

    public static List busquedaRapidaAgentesPorNombreFiscal(String nombre) {
        List lagentes = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lagentes = session.createQuery("from Agentes where nombre_fiscal like '%" + nombre + "%'").list();
        } catch (Exception e) {
            lagentes = null;
        }
        return lagentes;
    }

    public static List busquedaRapidaProveedoresPorNombreFiscal(String nombre) {
        List lagentes = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lagentes = session.createQuery("from Agentes where nombre_fiscal like '%" + nombre + "%' and tipo_agente in ('PR', 'PC')").list();
        } catch (Exception e) {
            lagentes = null;
        }
        return lagentes;
    }

    public static TipoAgente obtenerTipoAgente(String descripcion) {
        TipoAgente res = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            List lta = session.createQuery("from TipoAgente where descripcion like '" + descripcion + "'").list();
            if (lta.size() >= 1) {
                res = ((TipoAgente) lta.get(0));
            } else {
                res = null;
            }
        } catch (Exception e) {
            res = null;
        }
        return res;
    }

    /************************************
     * Métodos de la clase TipoProducto *
	 ************************************/
    public static TipoProducto obtenerTipoProductoDesc(String desc) {
        TipoProducto res = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            List ltipoprod = session.createQuery("from TipoProducto where descripcion like '" + desc + "'").list();
            if (ltipoprod.size() >= 1) {
                res = ((TipoProducto) ltipoprod.get(0));
            } else {
                res = null;
            }
        } catch (Exception e) {
            res = null;
        }
        return res;
    }

    public static List obtenerDescTipoPro() {
        List ldesctp = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            ldesctp = session.createQuery("select descripcion from TipoProducto").list();
        } catch (Exception e) {
            ldesctp = null;
        }
        return ldesctp;
    }

    /**************************************
     * Métodos de la clase Característica *
     **************************************/
    public static boolean insertarCaracteristica(Caracteristica car, boolean hayCaracteristicas) {
        boolean res = true;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            session.save(car);
            if (!hayCaracteristicas) {
                String consultaCaracteristicas = "Update Escalado set caracteristica = " + car.getIid() + " where caracteristica is null and articulo.iid = " + car.getIid_articulo().getIid();
                String consultaMovimientos = "Update MovimientoAlmacen set caracteristica = " + car.getIid() + " where caracteristica is null AND articulo.iid = " + car.getIid_articulo().getIid();
                String consultaExistencias = "Update Existencia set caracteristica = " + car.getIid() + " where caracteristica is null AND articulo.iid = " + car.getIid_articulo().getIid();
                String consultaArticulos = "Update Articulo set ESCALADO_CARACTERISTICA = " + car.getIid_articulo().getEscalado() + ", ESCALADO = 0 where iid = " + car.getIid_articulo().getIid();

                session.createQuery(consultaCaracteristicas).executeUpdate();
                session.createQuery(consultaMovimientos).executeUpdate();
                session.createQuery(consultaExistencias).executeUpdate();
                session.createQuery(consultaArticulos).executeUpdate();
            }
        } catch (Exception e) {
            res = false;
            session.getTransaction().rollback();
        } finally {
            if (session.isOpen() && session.getTransaction().isActive()) {
                session.getTransaction().commit();
            }
            return res;
        }
    }

    public static List getListaColoresArticulo(Empresa e, Articulo ar) {
        List lcarAux = null;
        List lcar = null;
        Colores c = new Colores();
        Integer i = 0;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lcarAux = session.createQuery("select iid_color from Caracteristica where iid_empresa = " + e.getIid() + " AND iid_articulo = " + ar.getIid()).list();
            lcar = new ArrayList();
            for (Iterator it = lcarAux.iterator(); it.hasNext();) {
                c = (Colores) it.next();
                lcar.add(BaseDatos.obtenerColorPorIid(c.getIid()).getCod_color());
            }

        } catch (Exception ex) {
            lcar = null;
        }
        return lcar;
    }

    public static List getListaCaracteristicas(Empresa e, Articulo ar) {
        List lcar = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lcar = session.createQuery("from Caracteristica where iid_empresa = " + e.getIid() + " AND iid_articulo = " + ar.getIid()).list();
        } catch (Exception ex) {
            lcar = null;
        }
        return lcar;
    }

    public static Caracteristica obtenerCaracteristica(Articulo ar, Empresa em, Colores c) {
        Caracteristica res = null;
        String consulta;

        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            consulta = "from Caracteristica where iid_articulo =" + ar.getIid() + " AND iid_empresa = " + em.getIid();
            if (c != null) {
                consulta += " AND iid_color = " + c.getIid();
            } else {
                consulta += " AND iid_color is null";
            }
            List lcaracteristicas = session.createQuery(consulta).list();
            if (lcaracteristicas.size() >= 1) {
                res = ((Caracteristica) lcaracteristicas.get(0));
            } else {
                res = null;
            }
        } catch (Exception e) {
            res = null;
        }
        return res;
    }

    /**********************************
     * Métodos de la clase TipoAgente *
	 *********************************/
    public static List getListaTipoAgentes() {
        List ltipoagentes = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            ltipoagentes = session.createQuery("from TipoAgente").list();
        } catch (Exception e) {
            ltipoagentes = null;
        }
        return ltipoagentes;
    }

    /************************************
     * Métodos de la clase TipoProducto *
	 ************************************/
    public static List getListaTipoProductos() {
        List ltp = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            ltp = session.createQuery("from TipoProducto").list();
        } catch (Exception e) {
            ltp = null;
        }
        return ltp;
    }

    public static List getListaTipoProductos(Empresa em) {
        List ltp = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            ltp = session.createQuery("from TipoProducto where iid_empresa = " + em.getIid()).list();
        } catch (Exception e) {
            ltp = null;
        }
        return ltp;
    }

    public static List busquedaRapidaTipoProductosPorDescripcion(String descripcion, Empresa em) {
        List ltp = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            ltp = session.createQuery("from TipoProducto where descripcion like '%" + descripcion + "%' AND iid_empresa = " + em.getIid()).list();
        } catch (Exception e) {
            ltp = null;
        }
        return ltp;
    }

    public static List busquedaRapidaTipoProductosPorCodigo(String codigo, Empresa em) {
        List ltp = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            ltp = session.createQuery("from TipoProducto where cod_tipo like '%" + codigo + "%' AND iid_empresa = " + em.getIid()).list();
        } catch (Exception e) {
            ltp = null;
        }
        return ltp;
    }

    public static TipoProducto obtenerTipoProducto(Empresa em, String codigo) {
        TipoProducto tp = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            List ltp = session.createQuery("from TipoProducto where iid_empresa = " + em.getIid() + "AND cod_tipo =  '" + codigo + "'").list();
            if (ltp.size() >= 1) {
                tp = (TipoProducto) ltp.get(0);
            }
        } catch (Exception e) {
            tp = null;
        }
        return tp;
    }

    /**************************************
     * Métodos de la clase AgenteArticulo *
     **************************************/
    public static List getListaAgenteArticulo(Empresa e, Articulo ar) {
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        List laa = null;
        try {
            laa = session.createQuery("from AgenteArticulo where iid_articulo = " + ar.getIid() + " AND iid_empresa = " + e.getIid()).list();
        } catch (Exception ex) {
            laa = null;
        }
        return laa;
    }

    public static List busquedaRapidaAgenteArticuloPorAgente(String agente, Empresa e, Articulo ar) {
        List laa = null;
        List lres = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            String consulta = "from AgenteArticulo aa "
                    + "inner join aa.iid_agente as ag "
                    + "where ag.nombre_comercial like '%" + agente + "%' "
                    + "and aa.iid_articulo = " + ar.getIid()
                    + " and aa.iid_empresa = " + e.getIid();
            laa = session.createQuery(consulta).list();
            if (laa != null) {
                lres = new ArrayList();
                AgenteArticulo aa;
                Object[] tmp;
                Iterator it;
                for (it = laa.iterator(); it.hasNext();) {
                    tmp = new Object[2];
                    tmp = (Object[]) it.next();
                    aa = (AgenteArticulo) tmp[0];
                    lres.add(aa);
                }
            }
        } catch (Exception ex) {
            lres = null;
        }
        return lres;
    }

    public static List busquedaRapidaAgenteArticuloPorCaracteristica(String colorCaracteristica, Empresa e, Articulo ar) {
        List laa = null;
        List lres = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            String consulta = "from AgenteArticulo aa "
                    + "inner join aa.iid_caracteristica as car "
                    + "inner join car.iid_color as col "
                    + "where aa.iid_articulo = " + ar.getIid()
                    + " and aa.iid_empresa = " + e.getIid()
                    + " and col.descripcion like '%" + colorCaracteristica + "%'";
            laa = session.createQuery(consulta).list();
            if (laa != null) {
                lres = new ArrayList();
                AgenteArticulo aa;
                Iterator it;
                Object[] tmp;
                for (it = laa.iterator(); it.hasNext();) {
                    tmp = new Object[3];
                    tmp = (Object[]) it.next();
                    aa = (AgenteArticulo) tmp[0];
                    lres.add(aa);
                }
            }
        } catch (Exception ex) {
            lres = null;
        }
        return lres;
    }

    public static AgenteArticulo obtenerAgenteArticulo(Empresa e, Articulo ar, Agentes proveedor, Colores c, Caracteristica car) {
        List laa = null;
        AgenteArticulo aa = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            String consulta = "from AgenteArticulo aa"
                    + " where aa.iid_articulo = " + ar.getIid()
                    + " AND aa.iid_agente = " + proveedor.getIid()
                    + " AND aa.iid_empresa = " + e.getIid()
                    + " AND aa.iid_caracteristica = " + car.getIid();
            if (c != null) {
                consulta += " AND aa.iid_caracteristica.iid_color = " + c.getIid();
            }

            laa = session.createQuery(consulta).list();
            if (laa != null && laa.size() > 0) {
                aa = (AgenteArticulo) laa.get(0);
            }
        } catch (Exception ex) {
            aa = null;
        } 
        return aa;
    }
	
    /**
     * ******************************************
     * Métodos de la clase AgenteArticuloCodigo *
     * ******************************************
     */
    public static AgenteArticuloCodigo obtenerArticuloporProveedor(Integer iidEmpresa, Integer iidAgente, Integer iidArticulo) {
        AgenteArticuloCodigo res = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            List larticulos = session.createQuery("from AgenteArticuloCodigo where iid_empresa= " + iidEmpresa + " iid_agente = " + iidAgente + " iid_articulo = " + iidArticulo).list();
            if (larticulos.size() >= 1) {
                res = ((AgenteArticuloCodigo) larticulos.get(0));
            } 
        } catch (Exception e) {
            res = null;
        }
        return res;
    }

    public static List getListaAgenteArticuloCodigo(Integer iidArticulo) {
        List laac = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            laac = session.createQuery("from AgenteArticuloCodigo where iid_articulo = " + iidArticulo).list();
        } catch (Exception e) {
            laac = null;
        }
        return laac;
    }

    public static List getListaAgenteCarCodigo(Integer iidCaracteristica) {
        List laac = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            laac = session.createQuery("from AgenteArticuloCodigo where iid_caracteristica = " + iidCaracteristica).list();
        } catch (Exception e) {
            laac = null;
        }
        return laac;
    }

    public static List getListaArticulosAgenteArticuloCodigo(Integer iidProveedor, Integer iidEmpresa) {
        List la = null;
        List laac = null;
        AgenteArticuloCodigo aac;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            laac = session.createQuery("from AgenteArticuloCodigo where iid_agente = " + iidProveedor + " and iid_articulo.iid_empresa = " + iidEmpresa).list();
            la = new ArrayList();
            if (laac != null) {
                Iterator it = laac.iterator();
                while (it.hasNext()) {
                    aac = (AgenteArticuloCodigo) it.next();
                    la.add(aac.getIid_articulo());
                }
            }
        } catch (Exception e) {
            la = null;
        }
        return la;
    }

    public static List busquedaRapidaAgenteArticuloCodigoPorCodigo(String codigo, Articulo ar) {
        List laac = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            laac = session.createQuery("from AgenteArticuloCodigo where codigo like '%" + codigo + "%' AND iid_articulo = " + ar.getIid()).list();
        } catch (Exception e) {
            laac = null;
        }
        return laac;
    }

    public static List busquedaRapidaAgenteArticuloCodigoPorAgente(String proveedor, Articulo ar) {
        List laac = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            String consulta = "from AgenteArticuloCodigo aac "
                    + "inner join aac.iid_agente as ag "
                    + "where ag.nombre_comercial like '%" + proveedor + "%' "
                    + "and aac.iid_articulo = " + ar.getIid();
            laac = session.createQuery(consulta).list();

            if (laac != null) {
                List lres = new ArrayList();
                AgenteArticuloCodigo aac;
                Object[] tmp;
                Iterator it;
                for (it = laac.iterator(); it.hasNext();) {
                    tmp = new Object[2];
                    tmp = (Object[]) it.next();
                    aac = (AgenteArticuloCodigo) tmp[0];
                    lres.add(aac);
                }
                laac = lres;
            }
        } catch (Exception e) {
            laac = null;
        }
        return laac;
    }

    public static AgenteArticuloCodigo obtenerAgenteArticuloCodigoPorAgente(Articulo ar, Agentes a) {
        AgenteArticuloCodigo res = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            List lAgentesArticuloCodigo = session.createQuery("from AgenteArticuloCodigo where iid_articulo = " + ar.getIid() + " and iid_agente =" + a.getIid()).list();
            if (lAgentesArticuloCodigo.size() >= 1) {
                res = (AgenteArticuloCodigo) lAgentesArticuloCodigo.get(0);
            }
        } catch (Exception e) {
            res = null;
        }
        return res;
    }

    public static AgenteArticuloCodigo obtenerAgenteArticuloCodigoPorColor(Articulo ar, Agentes a, Integer c) {
        AgenteArticuloCodigo res = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            List lAgentesArticuloCodigo = session.createQuery("from AgenteArticuloCodigo where iid_articulo = " + ar.getIid() + " and iid_color = " + c + " and iid_agente =" + a.getIid()).list();
            if (lAgentesArticuloCodigo.size() >= 1) {
                res = (AgenteArticuloCodigo) lAgentesArticuloCodigo.get(0);
            }
        } catch (Exception e) {
            res = null;
        }
        return res;
    }

    /*******************************
     * Métodos de la clase Usuario *
	 *******************************/
    public static List obtenerListaUsuarios() {
        List luser = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            luser = session.createQuery("from Usuario").list();
        } catch (Exception e) {
            luser = null;
        }
        return luser;
    }

    public static List getListaUsuarios() {
        List lusuarios = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lusuarios = session.createQuery("from Usuario").list();
        } catch (Exception e) {
            lusuarios = null;
        }
        return lusuarios;
    }

    public static Usuario obtenerUsuarioNombre(String nombre) {
        List lu = null;
        Usuario u = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            String consulta = "from Usuario where nombre = '" + nombre + "'";
            lu = session.createQuery(consulta).list();
            if (lu != null && lu.size() > 0) {
                u = (Usuario) lu.get(0);
            }
        } catch (Exception e) {
            u = null;
        }
		return u;
    }

    public static List<Usuario> obtenerUsuarioTipo(String tipo) {
        List lu = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lu = session.createQuery("from Usuario where tipo = '" + tipo + "'").list();
        } catch (Exception e) {
            lu = null;
        }
		return lu;
    }

    public static List<Usuario> obtenerUsuariosMensajes() {
        List lu = null;
        Usuario u = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lu = session.createQuery("from Usuario where tipo = 'Oficina' or tipo = 'Administrador'").list();
        } catch (Exception e) {
            lu = null;
        }
		return lu;
    }

    public static boolean eliminarUsuario(Usuario u) {
        boolean res = true;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            session.delete(u);
        } catch (Exception e) {
            res = false;
            session.getTransaction().rollback();
        } finally {
            if (session.isOpen() && session.getTransaction().isActive()) {
                session.getTransaction().commit();
            }
            return res;
        }
    }

    public static Usuario obtenerUsuario(String nombre, String contrasenha) {
        List lu = null;
        Usuario u = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            String consulta = "from Usuario where nombre = '" + nombre + "' AND contrasenha = '" + contrasenha + "'";
            lu = session.createQuery(consulta).list();
            if (lu != null && lu.size() > 0) {
                u = (Usuario) lu.get(0);
            }

        } catch (Exception e) {
            u = null;
        }
		return u;
    }

    /********************************
     * Métodos de la clase Magnitud *
	 ********************************/
    public static List getListaMagnitud() {
        List lmagnitudes = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lmagnitudes = session.createQuery("from Magnitud").list();
        } catch (Exception e) {
            lmagnitudes = null;
        }
        return lmagnitudes;
    }

    public static Magnitud obtenerMagnitud(String codigo) {
        Magnitud res = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            List lmagnitudes = session.createQuery("from Magnitud where codigo='" + codigo + "'").list();
            if (lmagnitudes.size() >= 1) {
                res = ((Magnitud) lmagnitudes.get(0));
            }
        } catch (Exception e) {
            res = null;
            session.getTransaction().rollback();
        }
        return res;
    }

    public static Magnitud obtenerMagnitud(String codigo, Session session) {
        Magnitud res = null;
        try {
            List lmagnitudes = session.createQuery("from Magnitud where codigo='" + codigo + "'").list();
            if (lmagnitudes.size() >= 1) {
                res = ((Magnitud) lmagnitudes.get(0));
            } else {
                res = null;
            }
        } catch (Exception e) {
            res = null;
        }
        return res;
    }

    public static Magnitud obtenerMagnitudPorNombre(String nombre) {
        Magnitud res = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            List lmagnitudes = session.createQuery("from Magnitud where nombre='" + nombre + "'").list();
            if (lmagnitudes.size() >= 1) {
                res = ((Magnitud) lmagnitudes.get(0));
            }
        } catch (Exception e) {
            res = null;
        }
        return res;
    }

    public static List busquedaRapidaMagnitudes(String codigo) {
        List lmagnitudes = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lmagnitudes = session.createQuery("from Magnitud where codigo like '%" + codigo + "%'").list();
        } catch (Exception e) {
            lmagnitudes = null;
        }
        return lmagnitudes;
    }

    /***************************************
     * Métodos de la clase EstadoDocumento *
     ***************************************/
    public static List getListaEstadoDocumento(String tipoDoc) {
        List ld = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            ld = session.createQuery("from EstadoDocumento where iid_tipo_documento = '" + tipoDoc + "'").list();
        } catch (Exception e) {
            ld = null;
        }
        return ld;
    }

    public static EstadoDocumento obtenerEstadoDocumentoPorDesc(String descripcion) {
        EstadoDocumento res = null;

        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            List lestados = session.createQuery("from EstadoDocumento where descripcion='" + descripcion + "'").list();
            if (lestados.size() >= 1) {
                res = ((EstadoDocumento) lestados.get(0));
            }
        } catch (Exception e) {
            res = null;
        }
        return res;
    }

    /*********************************
     * Métodos de la clase FormaPago *
	 *********************************/
    public static List getListaFormaPago() {
        List lfp = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lfp = session.createQuery("from FormaPago").list();
        } catch (Exception e) {
            lfp = null;
        }
        return lfp;
    }

    public static FormaPago obtenerFormaPago(String codigo) {
        FormaPago res = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            List lfp = session.createQuery("from FormaPago where codigo='" + codigo + "'").list();
            if (lfp.size() >= 1) {
                res = ((FormaPago) lfp.get(0));
            }
        } catch (Exception e) {
            res = null;
        }
        return res;
    }

    public static FormaPago obtenerFormaPagoPorIid(Integer iid) {
        FormaPago res = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            List lfp = session.createQuery("from FormaPago where iid =" + iid).list();
            if (lfp.size() >= 1) {
                res = ((FormaPago) lfp.get(0));
            }
        } catch (Exception e) {
            res = null;
        }

        return res;
    }

    public static List getListaFormaPago2() {
        List lfp2 = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lfp2 = session.createQuery("from FormaPago2").list();
        } catch (Exception e) {
            lfp2 = null;
        }
        return lfp2;
    }

    public static FormaPago2 obtenerFormaPago2(Integer iid) {
        FormaPago2 res = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            List lfp = session.createQuery("from FormaPago2 where iid=" + iid).list();
            if (lfp.size() >= 1) {
                res = ((FormaPago2) lfp.get(0));
            }
        } catch (Exception e) {
            res = null;
        }
        return res;
    }

    public static Object[] obtenerFormaPago2Reducido(Integer iid) {
        Object[] res = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            String query = "select numplazosadelantados, numplazosvencimiento, tipodecalculo, "
                    + "fechaPlazo1, cobrado1, fechaPlazo2, cobrado2, fechaPlazo3, cobrado3, fechaPlazo4, cobrado4, fechaPlazo5, cobrado5,  "
                    + "fechaPlazo6, cobrado6, fechaPlazo7, cobrado7, fechaPlazo8, cobrado8, fechaPlazo9, cobrado9, fechaPlazo10, cobrado10, "
                    + "plazovm1 , cobradoVencimiento1, plazovm2 , cobradoVencimiento2, plazovm3, cobradoVencimiento3, plazovm4 , cobradoVencimiento4, plazovm5 , cobradoVencimiento5,  "
                    + "plazovm6 , cobradoVencimiento6, plazovm7 , cobradoVencimiento7, plazovm8 , cobradoVencimiento8, plazovm9 , cobradoVencimiento9, plazovm10, cobradoVencimiento10 "
                    + "from FormaPago2 where iid=" + iid;
            List lfp = session.createQuery(query).list();
            if (lfp.size() >= 1) {
                res = ((Object[]) lfp.get(0));
            }
        } catch (Exception e) {
            res = null;
        }
        return res;
    }

    public static FormaPago2 obtenerFormaPago2porCod(String cod) {
        FormaPago2 res = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            List lfp = session.createQuery("from FormaPago2 where codigo='" + cod + "'").list();
            if (lfp.size() >= 1) {
                res = ((FormaPago2) lfp.get(0));
            }
        } catch (Exception e) {
            res = null;
        }
        return res;
    }

    /**********************************
     * Métodos de la clase TipoRecibo *
	 **********************************/
    public static List getListaTipoRecibo() {
        List ltr = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            ltr = session.createQuery("from TipoRecibo").list();
        } catch (Exception e) {
            ltr = null;
        }
        return ltr;
    }

    public static TipoRecibo obtenerTipoReciboPorDesc(String descripcion) {
        TipoRecibo res = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            List ltr = session.createQuery("from TipoRecibo where descripcion='" + descripcion + "'").list();
            if (ltr.size() >= 1) {
                res = ((TipoRecibo) ltr.get(0));
            }
        } catch (Exception e) {
            res = null;
        }
        return res;
    }

    public static TipoRecibo obtenerTipoReciboPorCodigo(String codigo) {
        TipoRecibo res = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            List ltr = session.createQuery("from TipoRecibo where codigo='" + codigo + "'").list();
            if (ltr.size() >= 1) {
                res = ((TipoRecibo) ltr.get(0));
            }
        } catch (Exception e) {
            res = null;
        }
        return res;
    }

    /***********************************
     * Métodos de la clase Presupuesto *
	 ***********************************/
    public static List getListaFormasPagosDesdeDocumentosFinalesReducidos(Integer iidEmpresa, String flujo) {
        List lp = null;
        String consulta = null;
        if (flujo.equals("V")) {
            consulta = " and ( clase_documento = 1 or clase_documento = 2 or clase_documento = 3 or clase_documento = 4 or clase_documento = 5 )";
        } else if (flujo.equals("C")) {
            consulta = " and ( clase_documento = 6 or clase_documento = 7 or clase_documento = 8 )";
        }

        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            String query = "select presu.numero, presu.nombreCliente, cldo.descripcion, presu.importe_total, presu.fp.iid, presu.fecha, presu.codigoCliente"
                    + " From Presupuesto presu, ClaseDocumento cldo "
                    + " where presu.clase_documento = cldo.id"
                    + " and presu.iid not in (select iidOrigen from Conversion) "
                    + " and empresa =" + iidEmpresa + consulta;
            lp = session.createQuery(query).list();
        } catch (Exception ex) {
            lp = null;
        }
        return lp;
    }

    public static List getListaFormasPagosDesdeDocumentosFinalesNumeroReducido(Integer iidEmpresa, String numero, String flujo) {
        List lp = null;
        String consulta = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            if (flujo.equals("V")) {
                consulta = " and ( clase_documento = 1 or clase_documento = 2 or clase_documento = 3 or clase_documento = 4 or clase_documento = 5 )";
            } else if (flujo.equals("C")) {
                consulta = " and ( clase_documento = 6 or clase_documento = 7 or clase_documento = 8 )";
            }
            String query = "select presu.numero, presu.nombreCliente, cldo.descripcion, presu.importe_total, presu.fp.iid, presu.fecha, presu.codigoCliente"
                    + " From Presupuesto presu, ClaseDocumento cldo "
                    + " where presu.clase_documento = cldo.id"
                    + " and presu.iid not in (select iidOrigen from Conversion) "
                    + " and empresa =" + iidEmpresa + consulta
                    + " and numero like '%" + numero + "%'";
            lp = session.createQuery(query).list();
        } catch (Exception ex) {
            lp = null;
        }
        return lp;
    }

    public static List getListaFormasPagosDesdeDocumentosFinalesTipoDocumentoReducido(Integer iidEmpresa, String tipoDocumento, String flujo) {
        List lp = null;
        String consulta = null;
        if (flujo.equals("V")) {
            consulta = " and ( clase_documento = 1 or clase_documento = 2 or clase_documento = 3 or clase_documento = 4 or clase_documento = 5 )";
        } else if (flujo.equals("C")) {
            consulta = " and ( clase_documento = 6 or clase_documento = 7 or clase_documento = 8 )";
        }

        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            String query = "select presu.numero, presu.nombreCliente, cldo.descripcion, presu.importe_total, presu.fp.iid, presu.fecha, presu.codigoCliente"
                    + " From Presupuesto presu, ClaseDocumento cldo "
                    + " where presu.clase_documento = cldo.id"
                    + " and presu.iid not in (select iidOrigen from Conversion) "
                    + " and empresa =" + iidEmpresa + consulta
                    + " and cldo.descripcion like '%" + tipoDocumento + "%'";
            lp = session.createQuery(query).list();
        } catch (Exception ex) {
            lp = null;
        }
        return lp;
    }

    public static List getListaPendientes(Usuario u, Integer em, Integer cd) {
        List lp = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            //Dependiendo del tipo de usuario buscamos por un tipo u otro
            if (u.getTipo().equals(Constantes.USUARIO_CONFECCION)) {
                lp = session.createQuery("from Presupuesto where confeccionado = 0 and instalado = 0 and empresa = " + em + " and clase_documento = " + cd + " order by fecha_entrega desc").list();
            } else if (u.getTipo().equals(Constantes.USUARIO_TALLER)) {
                lp = session.createQuery("from Presupuesto where fabricado = 0 and instalado = 0 and empresa = " + em + " and clase_documento = " + cd + " order by fecha_entrega desc").list();
            } else {
                lp = session.createQuery("from Presupuesto where empresa = " + em + " and instalado = 0 and clase_documento = " + cd + " order by fecha_entrega desc").list();
            }
        } catch (Exception e) {
            lp = null;
        }
        return lp;
    }

    public static List getListaEntregas(Integer em, Long fechaEntrega) {
        List lp = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lp = session.createQuery("from Presupuesto where empresa = " + em + " and fechaEntrega = " + fechaEntrega ).list();
        } catch (Exception e) {
            lp = null;
        }
        return lp;
    }

    public static List getListaPresupuestoByIdAgente(String codigoCliente, Integer em) {
        List lp = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lp = session.createQuery("from Presupuesto where codigo_cliente ='" + codigoCliente + "'" + " and empresa = " + em).list();
        } catch (Exception e) {
            lp = null;
        }
        return lp;
    }

    public static List getListaPresupuestoByIdAgenteReducido(String codigoCliente, Integer iidEmpresa) {
        List lp = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            String consulta = "select cd.descripcion, p.numero, p.serie, p.fecha, p.importe_total, ed.descripcion"
                    + " from Presupuesto p, ClaseDocumento cd, EstadoDocumento ed "
                    + " where codigo_cliente ='" + codigoCliente + "'"
                    + " and p.empresa = " + iidEmpresa
                    + " and p.clase_documento = cd"
                    + " and p.estado = ed";
            lp = session.createQuery(consulta).list();
        } catch (Exception e) {
            lp = null;
        }
        return lp;
    }

    public static List getListaPresupuestoByIdAgenteyFecha(String codigoCliente, String fecha) {
        List lp = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lp = session.createQuery("from Presupuesto where fecha like '%" + fecha + "%' and codigo_cliente ='" + codigoCliente + "'").list();
        } catch (Exception e) {
            lp = null;
        }
        return lp;
    }

    public static List getListaPresupuestoByIdAgenteyClase(String codigoCliente, Integer cd) {
        List lp = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            String consulta = "select cd.descripcion, p.numero, p.serie, p.fecha, p.importe_total, ed.descripcion"
                    + " from Presupuesto p, ClaseDocumento cd, EstadoDocumento ed "
                    + " where codigo_cliente ='" + codigoCliente + "'"
                    + " and p.clase_documento = cd "
                    + " and p.clase_documento = " + cd
                    + " and p.estado = ed";

            lp = session.createQuery(consulta).list();
        } catch (Exception e) {
            lp = null;
        }
        return lp;
    }

    public static List getListaPresupuestoByIdAgenteyClaseyFecha(String codigoCliente, ClaseDocumento cd, Long finicio, Long ffin) {
        List lp = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lp = session.createQuery("from Presupuesto where fecha <= " + ffin + " and fecha >= " + finicio + " and codigo_cliente ='" + codigoCliente + "' and clase_documento = " + cd.getIid()).list();
        } catch (Exception e) {
            lp = null;
        }
        return lp;
    }
	
    public static List getListaFacturas(Integer empresaIid){
        List lp = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            String consulta = "select p " +
                    "from Presupuesto p "
                    + "inner join p.clase_documento as cd "
                    + "where p.empresa = " + empresaIid
                    + " and (cd.descripcion = '" + Constantes.FACTURA + "' OR cd.descripcion = '" + Constantes.FACTURAA + "')";
            lp = session.createQuery(consulta).list();
        } catch (Exception e) {
            lp = null;
        }
        return lp;
    }
    
    public static List getListaPresupuesto(Integer empresaIid, Integer claseDocumento) {
        List lp = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lp = session.createQuery("from Presupuesto where empresa = " + empresaIid + " and clase_documento = " + claseDocumento).list();
        } catch (Exception e) {
            lp = null;
        }
        return lp;
    }
    
    public static List getListaPedidosCPendientes(Integer empresaIid) {
        List lp = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lp = session.createQuery("from Presupuesto where empresa = " + empresaIid + " and clase_documento = 6 and estado != 13" ).list();
        } catch (Exception e) {
            lp = null;
        }
        return lp;
    }

    public static List getListaPresupuestoCliente(Integer empresaIid, Integer claseDocumento, String cliente) {
        List lp = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lp = session.createQuery("from Presupuesto where empresa =" + empresaIid + " and clase_documento =" + claseDocumento + " and codigoCliente ='" + cliente + "'").list();
        } catch (Exception e) {
            lp = null;
        }
        return lp;
    }

    public static Presupuesto presupuestoConvertido(Integer iidPresupuesto) {
        Presupuesto res = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            String consulta = "from Presupuesto where convertido = 1 and documento = " + iidPresupuesto;
            List lp = session.createQuery(consulta).list();
            if (lp.size() >= 1) {
                res = (Presupuesto) lp.get(0);
            }
        } catch (Exception e) {
            res = null;
        }

        return res;
    }

    public static Presupuesto obtenerPresupuesto(Integer iid) {
        Presupuesto res = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            List lp = session.createQuery("from Presupuesto where iid = " + iid).list();
            if (lp.size() >= 1) {
                res = ((Presupuesto) lp.get(0));
            }
        } catch (Exception e) {
            res = null;
        }
        return res;
    }

    public static Medicion obtenerMedicion(Integer iid) {
        Medicion res = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            List lp = session.createQuery("from Medicion where iid = " + iid).list();
            if (lp.size() >= 1) {
                res = ((Medicion) lp.get(0));
            }
        } catch (Exception e) {
            res = null;
        }
        return res;
    }

    public static List obtenerRangoPresupuesto(Integer iidIni, Integer iidFinal, Integer em, Integer cd, String codCli) {
        List res = null;

        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            List lp = session.createQuery("from Presupuesto where iid>=" + iidIni + " and iid <=" + iidFinal + " and empresa=" + em + " and clase_documento=" + cd + " and codigoCliente='" + codCli + "'").list();
            if (lp.size() >= 1) {
                res = lp;
            }
        } catch (Exception e) {
            res = null;
        }
        return res;
    }

    public static Presupuesto obtenerPresupuestoPorNumero(String numero, Integer em, Integer cd) {
        Presupuesto res = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            List lp = session.createQuery("from Presupuesto where numero='" + numero + "' and empresa = " + em + " and clase_documento = " + cd).list();
            if (lp.size() > 0) {
                res = ((Presupuesto) lp.get(0));
            }
        } catch (Exception e) {
            res = null;
        }
        return res;
    }

    public static Medicion obtenerMedicionPorNumero(String numero) {
        Medicion res = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            List lp = session.createQuery("from Medicion where numero='" + numero + "'").list();
            if (lp.size() > 0) {
                res = ((Medicion) lp.get(0));
            } else {
                res = null;
            }
        } catch (Exception e) {
            res = null;
        }
        return res;
    }

    public static Presupuesto obtenerPresupuestoPorNumeroPorClaseDocumento(String numero, String claseDocumento, Empresa em) {
        List lp = null;
        Presupuesto res = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            String consulta = "select p.iid from Presupuesto p "
                    + "inner join p.clase_documento as cd "
                    + "where p.numero like '" + numero + "' "
                    + "and empresa = " + em.getIid()
                    + " and cd.descripcion like '" + claseDocumento + "'";
            lp = session.createQuery(consulta).list();
            if (lp.size() > 0) {
                Integer iidPresupuesto = (Integer) lp.get(0);
                res = obtenerPresupuesto(iidPresupuesto);
            }
        } catch (Exception e) {
            res = null;
        }
        return res;
    }

    public static Presupuesto obtenerPresupuestoPorNumeroPorClaseDocumento(String numero, String claseDocumento, Empresa em, Integer inter) {
        List lp = null;
        Presupuesto res = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            String consulta = "";
            if (!claseDocumento.equals(Constantes.PEDIDOC)){
				consulta = "select p.iid from Presupuesto p "
                    + "inner join p.clase_documento as cd "
                    + "where p.numero like '" + numero + "' "
                    + "and empresa = " + em.getIid()
                    + " and iid_interlocutor = " + inter
                    + " and cd.descripcion like '" + claseDocumento + "'";
            } else {
				consulta = "select p.iid from Presupuesto p "
                    + "inner join p.clase_documento as cd "
                    + "where p.numero like '" + numero + "' "
                    + "and empresa = " + em.getIid()
                    + " and cd.descripcion like '" + claseDocumento + "'";
            }
            lp = session.createQuery(consulta).list();
            if (lp.size() > 0) {
                Integer iidPresupuesto = (Integer) lp.get(0);
                res = obtenerPresupuesto(iidPresupuesto);
            }
        } catch (Exception e) {
            res = null;
        }
        return res;
    }

    public static Presupuesto obtenerPresupuestoPorNumeroPorClaseDocumentoIid(String numero, Integer claseDocumento, Empresa em) {
        List lp = null;
        Presupuesto res = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            String consulta = "select p.iid from Presupuesto p "
                    + "where p.numero like '" + numero + "' "
                    + "and empresa = " + em.getIid()
                    + " and p.clase_documento = " + claseDocumento;
            lp = session.createQuery(consulta).list();
            if (lp.size() > 0) {
                Integer iidPresupuesto = (Integer) lp.get(0);
                res = obtenerPresupuesto(iidPresupuesto);
            }
        } catch (Exception e) {
            res = null;
        }
        return res;
    }

    public static List busquedaRapidaPresupuestoPorNombreComercial(String nombreComercial, Integer claseDocumento) {
        List lp = null;
        List lres = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            String consulta = "select p.iid "
                    + "from Presupuesto p "
                    + "inner join p.cliente as cl "
                    + "where cl.nombre_comercial like '%" + nombreComercial + "%' "
                    + "and p.clase_documento.iid = " + claseDocumento;
            lp = session.createQuery(consulta).list();
            if (lp != null) {
                lres = new ArrayList();
                Presupuesto p;
                for (Iterator it = lp.iterator(); it.hasNext();) {
                    p = BaseDatos.obtenerPresupuesto((Integer) it.next());
                    lres.add(p);
                }
            }
        } catch (Exception e) {
            lres = null;
        }
        return lres;
    }

    public static List busquedaCompuestaPresupuesto(Empresa em, String nombreComercial, String numero, String referencia,
        String direccion, Integer claseDocumento, Long fInicio, Long fFin, Integer inter) {
        List lp = null;
        List lres = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            String consulta;
            if (inter != 0) {
                consulta = "select p.iid "
                        + "from Presupuesto p "
                        + "where p.empresa = " + em.getIid()
                        + " and fecha >= " + fInicio + " and fecha <= " + fFin
                        + " and p.nombreCliente like '%" + nombreComercial + "%'"
                        + " and p.clase_documento.iid = " + claseDocumento
                        + " and p.numero like '%" + numero + "%'"
                        + " and p.referencia like '%" + referencia + "%'"
                        + " and p.domicilioCliente like '%" + direccion + "%'"
                        + " and p.interlocutor = " + inter;
            } else {
                consulta = "select p.iid "
                        + "from Presupuesto p "
                        + "where p.empresa = " + em.getIid()
                        + " and fecha >= " + fInicio + " and fecha <= " + fFin
                        + " and p.nombreCliente like '%" + nombreComercial + "%'"
                        + " and p.clase_documento.iid = " + claseDocumento
                        + " and p.numero like '%" + numero + "%'"
                        + " and p.referencia like '%" + referencia + "%'"
                        + " and p.domicilioCliente like '%" + direccion + "%'";
            }
            lp = session.createQuery(consulta).list();
            if (lp != null) {
                lres = new ArrayList();
                Presupuesto p;
                for (Iterator it = lp.iterator(); it.hasNext();) {
                    p = BaseDatos.obtenerPresupuesto((Integer) it.next());
                    lres.add(p);
                }
            }
        } catch (Exception e) {
            lres = null;
        }
        return lres;
    }

    public static List busquedaRapidaPresupuestoPorNombreFiscal(String nombreFiscal, Integer claseDocumento, Empresa em) {
        List lp = null;
        List lres = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            String consulta = "select p.iid "
                    + "from Presupuesto p "
                    + "inner join p.cliente as cl "
                    + "where cl.nombre_fiscal like '%" + nombreFiscal + "%' "
                    + "and empresa = " + em.getIid()
                    + " and p.clase_documento.iid = " + claseDocumento;
            lp = session.createQuery(consulta).list();
            if (lp != null) {
                lres = new ArrayList();
                Presupuesto p;
                for (Iterator it = lp.iterator(); it.hasNext();) {
                    p = BaseDatos.obtenerPresupuesto((Integer) it.next());
                    lres.add(p);
                }
            }
        } catch (Exception e) {
            lres = null;
        }
        return lres;
    }

    public static List busquedaRapidaPresupuestoPorFecha(String fecha, Integer claseDocumento) {
        List lp = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lp = session.createQuery("select p.nombre_cliente, p.numero, p.referencia,"
                    + " p.fecha, p.importe_total,p.estado, p.domicilio_cliente, p.localidad_cliente "
                    + "from Presupuesto p where fecha like '%" + fecha + "%' and p.clase_documento.iid = " + claseDocumento).list();
        } catch (Exception e) {
            lp = null;
        }
        return lp;
    }

    public static List busquedaRapidaPresupuestoPorNumero(String numero, Integer claseDocumento) {
        List lp = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lp = session.createQuery("from Presupuesto p where numero like '%" + numero + "%' and p.clase_documento.iid = " + claseDocumento).list();
        } catch (Exception e) {
            lp = null;
        }
        return lp;
    }

    public static List busquedaRapidaPresupuestoPorSerie(String serie, Integer claseDocumento) {
        List lp = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lp = session.createQuery("from Presupuesto p where serie like '%" + serie + "%' and p.clase_documento.iid = " + claseDocumento).list();
        } catch (Exception e) {
            lp = null;
        }
        return lp;
    }

    public static List busquedaRapidaPresupuestoPorEstado(String estado, Integer claseDocumento) {
        List lp = null;
        List lres = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            String consulta = "select p.iid "
                    + "from Presupuesto p "
                    + "inner join p.estado as e "
                    + "where e.descripcion like '%" + estado + "%' "
                    + "and p.clase_documento.iid = " + claseDocumento;
            lp = session.createQuery(consulta).list();
            if (lp != null) {
                lres = new ArrayList();
                Presupuesto p;
                for (Iterator it = lp.iterator(); it.hasNext();) {
                    p = BaseDatos.obtenerPresupuesto((Integer) it.next());
                    lres.add(p);
                }
            }
        } catch (Exception e) {
            lres = null;
        }
        return lres;
    }

    public static List busquedaRapidaDocumentosPorDireccion(String direccion, Integer empresa, Integer claseDocumento) {
        List lp = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lp = session.createQuery("from Presupuesto where empresa.iid = " + empresa + " and clase_documento.iid = " + claseDocumento + " and domicilioCliente like '%" + direccion + "%'").list();
        } catch (Exception e) {
            lp = null;
        }
        return lp;
    }

    public static List busquedaRapidaDocumentosPorDireccionYAgente(String direccion, Integer empresa, Integer claseDocumento, String codigoAgente) {
        List lp = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            String sql;
            if (codigoAgente == null) {
                sql = "from Presupuesto where empresa.iid = " + empresa + " and clase_documento.iid = " + claseDocumento + " and domicilioCliente like '%" + direccion + "%'";
            } else {
                sql = "from Presupuesto where empresa.iid = " + empresa + " and clase_documento.iid = " + claseDocumento + " and domicilioCliente like '%" + direccion + "%'" + " and codigoCliente ='" + codigoAgente + "'";
            }
            lp = session.createQuery(sql).list();
        } catch (Exception e) {
            lp = null;
        }
        return lp;
    }

    public static List busquedaRapidaDocumentoPorNombreComercial(String nombre, Integer claseDocumento, Integer empresa) {
        List lp = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lp = session.createQuery("from Presupuesto p where nombreCliente like '%" + nombre + "%' and p.clase_documento.iid = " + claseDocumento + " and p.empresa.iid = " + empresa).list();
        } catch (Exception e) {
            lp = null;
        }
        return lp;
    }

    public static List busquedaRapidaDocumentoPorNombreComercialYAgente(String nombre, Integer claseDocumento, Integer empresa, String codigoAgente) {
        List lp = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            String sql;
            if (codigoAgente == null) {
                sql = "from Presupuesto p where nombreCliente like '%" + nombre + "%' and p.clase_documento.iid = " + claseDocumento + " and p.empresa.iid = " + empresa;
            } else {
                sql = "from Presupuesto p where nombreCliente like '%" + nombre + "%' and p.clase_documento.iid = " + claseDocumento + " and p.empresa.iid = " + empresa + " and codigoCliente ='" + codigoAgente + "'";
            }
            lp = session.createQuery(sql).list();
        } catch (Exception e) {
            lp = null;
        }
        return lp;
    }

    public static List busquedaRapidaDocumentoPorNumero(String numero, Integer claseDocumento, Integer empresa) {
        List lp = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lp = session.createQuery("from Presupuesto p where numero like '%" + numero + "%' and p.clase_documento.iid = " + claseDocumento + " and p.empresa.iid = " + empresa).list();
        } catch (Exception e) {
            lp = null;
        }
        return lp;
    }

    public static List busquedaRapidaDocumentoPorNumeroYAgente(String numero, Integer claseDocumento, Integer empresa, String codigoAgente) {
        List lp = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            String sql;
            if (codigoAgente == null) {
                sql = "from Presupuesto p where numero like '%" + numero + "%' and p.clase_documento.iid = " + claseDocumento + " and p.empresa.iid = " + empresa;
            } else {
                sql = "from Presupuesto p where numero like '%" + numero + "%' and p.clase_documento.iid = " + claseDocumento + " and p.empresa.iid = " + empresa + " and codigoCliente ='" + codigoAgente + "'";
            }
            lp = session.createQuery(sql).list();
        } catch (Exception e) {
            lp = null;
        }
        return lp;
    }

    public static List busquedaRapidaDocumentoPorFecha(String numero, Integer claseDocumento, Integer empresa) {
        List lp = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lp = session.createQuery("from Presupuesto p where fecha like '%" + numero + "%' and p.clase_documento.iid = " + claseDocumento + " and p.empresa.iid = " + empresa).list();
        } catch (Exception e) {
            lp = null;
        }
        return lp;
    }

    public static List busquedaRapidaDocumentoPorFechaEntrega(String numero, Integer claseDocumento, Integer empresa) {
        List lp = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lp = session.createQuery("from Presupuesto p where fechaEntrega like '%" + numero + "%' and p.clase_documento.iid = " + claseDocumento + " and p.empresa.iid = " + empresa).list();
        } catch (Exception e) {
            lp = null;
        }
        return lp;
    }

    public static List busquedaRapidaDocumentoPorEstado(String estado, Integer claseDocumento, Integer empresa) {
        List lp = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            List listaIds = null;
            String consulta = "select p.iid from Presupuesto p "
                    + "inner join p.estado as e "
                    + "where e.descripcion like '%" + estado + "%' "
                    + "and p.clase_documento.iid = " + claseDocumento
                    + " and p.empresa.iid = " + empresa;
            listaIds = session.createQuery(consulta).list();
            Iterator iter = listaIds.iterator();
            Presupuesto temp;
            lp = new ArrayList<Presupuesto>();
            while (iter.hasNext()) {
                temp = BaseDatos.obtenerPresupuesto((Integer) iter.next());
                lp.add(temp);
            }
        } catch (Exception e) {
            lp = null;
        }
        return lp;
    }

    public static List busquedaRapidaDocumentoPorReferencia(String referencia, Integer claseDocumento, Integer empresa) {
        List lp = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lp = session.createQuery("from Presupuesto p where referencia like '%" + referencia + "%' and p.clase_documento.iid = " + claseDocumento + " and p.empresa.iid = " + empresa).list();
        } catch (Exception e) {
            lp = null;
            session.getTransaction().rollback();
        } finally {
            if (session.isOpen() && session.getTransaction().isActive()) {
                session.getTransaction().commit();
            }
        return lp;
        }
    }

    public static List busquedaRapidaDocumentoPorReferenciaYAgente(String referencia, Integer claseDocumento, Integer empresa, String codigoAgente) {
        List lp = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            String sql;
            if (codigoAgente == null) {
                sql = "from Presupuesto p where referencia like '%" + referencia + "%' and p.clase_documento.iid = " + claseDocumento + " and p.empresa.iid = " + empresa;
            } else {
                sql = "from Presupuesto p where referencia like '%" + referencia + "%' and p.clase_documento.iid = " + claseDocumento + " and p.empresa.iid = " + empresa + " and codigoCliente ='" + codigoAgente + "'";
            }
            lp = session.createQuery(sql).list();
        } catch (Exception e) {
            lp = null;
        }
        return lp;
    }

    public static boolean eliminarPresupuesto(Integer iid) {
        boolean res = true;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            session.createQuery("delete from MovimientoAlmacen where presupuesto.iid = " + iid).executeUpdate();
            session.createQuery("delete from Montaje where iidPedido = " + iid).executeUpdate();

            List movimientoPresupuesto = session.createQuery("from MovimientoPresupuesto where presupuesto.iid = " + iid).list();
            Iterator iterMP = movimientoPresupuesto.iterator();
            MovimientoPresupuesto mp;
            Existencia ex;
            Existencia exR;
            LineaCorteLona lcl;
            LineaCortePerfil lcp;
            Object o;
            
            while (iterMP.hasNext()) {
                mp = (MovimientoPresupuesto) iterMP.next();
                lcl = mp.getLineaCorteLona();
                if (lcl != null) {
                    //Se trata de un corte de lona
                    if (lcl.getTipoCorteLona().equals(Constantes.TIPO_CORTE_DEGRADEE)) {
                        ex = mp.getExistencia();
                        ex.setCantidad1(mp.getMedida2() + ex.getCantidad1());
                        session.saveOrUpdate(ex);
                    } else {
                        if (mp.getExistenciaResto() == null) {
                            ex = mp.getExistencia();
                            if (ex != null && (ex.getEsResto() == null || !ex.getEsResto()) && (ex.getEstaUsado() == null || !ex.getEstaUsado())) {
                                ex.setCantidad1(mp.getMedida1() + ex.getCantidad1());
                                session.saveOrUpdate(ex);
                            } else if ((ex.getEsResto() != null && ex.getEsResto()) && (ex.getEstaUsado() != null && ex.getEstaUsado())) {
                                ex.setEstaUsado(false);
                                session.saveOrUpdate(ex);
                            }
                        } else {
                            ex = mp.getExistencia();
                            if (ex != null) {
                                ex.setCantidad1(mp.getMedida1() + ex.getCantidad1());
                                exR = mp.getExistenciaResto();
                                session.delete(exR);
                                session.saveOrUpdate(ex);
                            }
                        }
                    }
                } else if (mp.getLineaCortePerfil() != null) {
                    //Se trata de un corte de perfil
                    lcp = mp.getLineaCortePerfil();
                    ex = mp.getExistencia();
                    ex.setCantidad1(mp.getMedida1() + ex.getCantidad1());
                    session.saveOrUpdate(ex);
                } else {
                    ex = mp.getExistencia();
                    ex.setExistencia(mp.getMedida1() + ex.getExistencia());
                    session.saveOrUpdate(ex);
                }
            }

            session.createQuery("delete from MovimientoPresupuesto where presupuesto.iid = " + iid).executeUpdate();
            session.createQuery("delete from LineaCorteLona where presupuesto.iid = " + iid).executeUpdate();
            session.createQuery("delete from LineaCortePerfil where presupuesto.iid = " + iid).executeUpdate();
            session.createQuery("delete from LineaPresupuesto where presupuesto_iid = " + iid).executeUpdate();

            List listaDespiece = session.createQuery("from DespiecePresupuesto where dacPresupuesto.presupuesto.iid = " + iid).list();
            Iterator it = listaDespiece.iterator();
            DespiecePresupuesto despp;
            while (it.hasNext()) {
                despp = (DespiecePresupuesto) it.next();
                o = session.load(DespiecePresupuesto.class, despp.getIid());
                session.delete(o);
            }

            List listaTemp;
            List dacPresupuesto = session.createQuery("from DacPresupuesto where presupuesto.iid = " + iid).list();
            it = dacPresupuesto.iterator();
            DacPresupuesto dp;
            while (it.hasNext()) {
                dp = (DacPresupuesto) it.next();
                session.createQuery("delete from SeleccionPresupuesto where dacPresupuesto.iid = " + dp.getIid()).executeUpdate();
                session.createQuery("delete from VariablePresupuesto where dacPresupuesto.iid = " + dp.getIid()).executeUpdate();
                o = session.load(DacPresupuesto.class, dp.getIid());
                session.delete(o);
            }
            
            session.createQuery("delete from Conversion where iidOrigen = " + iid).executeUpdate();

            listaTemp = session.createQuery("from Conversion where iidDestino = " + iid).list();
            Conversion cv;
            it = listaTemp.iterator();
            StringBuffer queryBuffer = new StringBuffer();
            boolean hayPrimero = false;
            while (it.hasNext()) {
                cv = (Conversion) it.next();
                if (hayPrimero) {
                    queryBuffer.append(", " + cv.getIidOrigen());
                } else {
                    queryBuffer.append("" + cv.getIidOrigen());
                    hayPrimero = true;
                }
            }

            Presupuesto pp;
            if (hayPrimero) {
                String query = "From Presupuesto where iid in (" + queryBuffer.toString() + ")";
                listaTemp = session.createQuery(query).list();
                it = listaTemp.iterator();
                while (it.hasNext()) {
                    pp = (Presupuesto) it.next();
                    pp.setConvertido(false);
                    session.update(pp);
                }
            }

            session.createQuery("delete from Conversion where iidDestino = " + iid).executeUpdate();

            Integer iidFp2 = null;
            listaTemp = session.createQuery("from Presupuesto where iid = " + iid).list();
            if (listaTemp != null && listaTemp.size() > 0) {
                it = listaTemp.iterator();
                pp = (Presupuesto) it.next();
                iidFp2 = pp.getFp().getIid();
            }

            o = session.load(Presupuesto.class, iid);
            session.delete(o);

            listaTemp = session.createQuery("From Presupuesto where fp.iid = " + iidFp2).list();
            List listaTemp2 = session.createQuery("From PresupuestoHistorico where fp.iid = " + iidFp2).list();

            if ((listaTemp == null || listaTemp.size() == 0) && (listaTemp2 == null || listaTemp2.size() == 0)) {
                session.createQuery("delete from FormaPago2 where iid = " + iidFp2).executeUpdate();
            }
        } catch (Exception ex) {
            log.error("Se ha producido una excepción en el método eliminarPresupuesto ", ex);
            ex.printStackTrace();
            res = false;
            session.getTransaction().rollback();
        } finally {
            if (session.isOpen() && session.getTransaction().isActive()) {
                try {
                    session.getTransaction().commit();
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        }

        return res;
    }

    public static boolean guardarDocumento(Presupuesto p, FormaPago2 fp2, Integer cod_fp2, FormaPago2 fp2_aux, List listaArticulos, boolean crear, ClaseDocumento cd, HashMap rellenarDacMap) {
        boolean res = true;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        Integer iidPrespuesto;
        try {
            if (fp2 != null) {
                if (cod_fp2 != -1) {
                    fp2.setIid(cod_fp2);
                    session.saveOrUpdate(fp2);
                } else {
                    session.saveOrUpdate(fp2);
                }
            } else {
                if (cod_fp2 != -1) {
                    Object o = session.load(FormaPago2.class, cod_fp2);
                    session.delete(o);
                }
            }
            p.setFp(fp2);

            if (crear) {
                p.setDesde_presupuesto(false);
                Metadata num = null;
                Metadata anio = null;
                String numeroDocumento = "";
                String anioDocumento = "";

                if (cd.getDescripcion().equals(Constantes.ALBARAN)) {
                    numeroDocumento = "numAlbaran";
                    anioDocumento = "anioAlbaran";
                } else if (cd.getDescripcion().equals(Constantes.FACTURA)) {
                    numeroDocumento = "numFactura";
                    anioDocumento = "anioFactura";
                } else if (cd.getDescripcion().equals(Constantes.PRESUPUESTO)) {
                    numeroDocumento = "numPresupuesto";
                    anioDocumento = "anioPresupuesto";
                } else if (cd.getDescripcion().equals(Constantes.PEDIDO)) {
                    numeroDocumento = "numPedido";
                    anioDocumento = "anioPedido";
                } else if (cd.getDescripcion().equals(Constantes.PEDIDOC)) {
                    numeroDocumento = "numPedidoF";
                    anioDocumento = "anioPedidoF";
                } else if (cd.getDescripcion().equals(Constantes.ALBARANC)) {
                    numeroDocumento = "numAlbaranF";
                    anioDocumento = "anioAlbaranF";
                }

                List listaMetadataNum = session.createQuery("from Metadata where nombre='" + numeroDocumento + "' and iid_empresa = " + p.getEmpresa().getIid()).list();
                if (listaMetadataNum.size() >= 1) {
                    num = ((Metadata) listaMetadataNum.get(0));
                }
                
                List listaMetadataAnio = session.createQuery("from Metadata where nombre='" + anioDocumento + "' and iid_empresa = " + p.getEmpresa().getIid()).list();
                if (listaMetadataAnio.size() >= 1) {
                    anio = ((Metadata) listaMetadataAnio.get(0));
                }

                String numero;

                String numPresupuestoS = num.getValor();
                int numPresupuestoI = Integer.valueOf(numPresupuestoS);

                num.setValor(String.valueOf(numPresupuestoI + 1));
                numero = anio.getValor() + "/" + num.getValor();

                session.update(num);

                p.setNumero(numero);
                p.setConvertido(false);

                iidPrespuesto = (Integer) session.save(p);

            } else {
                iidPrespuesto = p.getIid();
                session.update(p);
            }

            Iterator iter;
            Articulo a;
            NuevaLineaPresupuesto nlip = null;
            NuevaLineaCompra nlic = null;
            LineaPresupuesto lip;
            Integer iidLineaPresupuesto;
            int indiceLineaPresupuestoBBDD = 0;
            int contadorLineaPresupuesto = 0;
            List listaAccionesActualizarCortes = new ArrayList();
            List<Integer> listaIidMantener = new ArrayList<Integer>();
            List<Integer> listaIidTotalesBBDD = new ArrayList<Integer>();
            Integer iidAux;
            HashMap<Integer, Integer> mapCambioCorteLona = new HashMap<Integer, Integer>();

            List listaLineaPresupuesto = session.createQuery("from LineaPresupuesto where presupuesto_iid = " + p.getIid()).list();
            iter = listaArticulos.iterator();
            //Documento de compras
            if (cd.getDescripcion().equals(Constantes.PEDIDOC) || cd.getDescripcion().equals(Constantes.ALBARANC)) {
                while (iter.hasNext()) {
                    nlic = (NuevaLineaCompra) iter.next();
                    if (nlic.getIid() != null) {
                        listaIidMantener.add(nlic.getIid());
                    }
                }
            } else {
                while (iter.hasNext()) {
                    nlip = (NuevaLineaPresupuesto) iter.next();
                    if (nlip.getIid() != null) {
                        listaIidMantener.add(nlip.getIid());
                    }
                }
            }

            iter = listaLineaPresupuesto.iterator();
            while (iter.hasNext()) {
                lip = (LineaPresupuesto) iter.next();
                listaIidTotalesBBDD.add(lip.getIid());
            }

            iter = listaIidMantener.iterator();
            while (iter.hasNext()) {
                iidAux = (Integer) iter.next();
                listaIidTotalesBBDD.remove(iidAux);
            }

            if (listaIidTotalesBBDD != null && listaIidTotalesBBDD.size() > 0) {
                List movimientoPresupuesto;
                Iterator iterN;
                MovimientoPresupuesto mp;
                Existencia ex;
                Existencia exR;
                String consultaMovimiento;
                List<MovimientoPresupuesto> lAux;
                iter = listaIidTotalesBBDD.iterator();
                while (iter.hasNext()) {
                    iidAux = (Integer) iter.next();

                    consultaMovimiento = "select mp.iid from MovimientoPresupuesto mp inner join mp.lineaCorteLona as lcl where lcl.lineaPresupuesto = " + iidAux;
                    movimientoPresupuesto = session.createQuery(consultaMovimiento).list();
                    if (movimientoPresupuesto != null && movimientoPresupuesto.size() > 0) {
                        for (iterN = movimientoPresupuesto.iterator(); iterN.hasNext();) {
                            lAux = session.createQuery("From MovimientoPresupuesto where iid = " + (Integer) iterN.next()).list();
                            if (lAux != null && lAux.size() > 0) {
                                mp = (MovimientoPresupuesto) lAux.get(0);
                                if (mp.getExistenciaResto() == null) {
                                    ex = mp.getExistencia();
                                    if (ex != null) {
                                        ex.setCantidad1(mp.getMedida1() + ex.getCantidad1());
                                        session.saveOrUpdate(ex);
                                    }
                                } else {
                                    ex = mp.getExistencia();
                                    if (ex != null) {
                                        ex.setCantidad1(mp.getMedida1() + ex.getCantidad1());
                                        exR = mp.getExistenciaResto();
                                        session.delete(exR);
                                        session.saveOrUpdate(ex);
                                    }
                                }

                            }
                        }

                        for (iterN = movimientoPresupuesto.iterator(); iterN.hasNext();) {
                            session.createQuery("delete from MovimientoPresupuesto where iid = " + (Integer) iterN.next()).executeUpdate();
                        }
                        session.createQuery("delete from LineaCorteLona where lineaPresupuesto = " + iidAux).executeUpdate();
                    }
                }
            }

            listaIidMantener.clear();

            iter = listaArticulos.iterator();

            while (iter.hasNext()) {
                //Documento de compras
                if (cd.getDescripcion().equals(Constantes.PEDIDOC) || cd.getDescripcion().equals(Constantes.ALBARANC)) {
                    nlic = (NuevaLineaCompra) iter.next();
                    a = nlic.getArticulo();
                } else {
                    nlip = (NuevaLineaPresupuesto) iter.next();
                    a = nlip.getArticulo();
                }

                if (a != null) {
                    //Si es un articulo
                    if (indiceLineaPresupuestoBBDD + 1 > listaLineaPresupuesto.size()) {
                        lip = new LineaPresupuesto();
                    } else {
                        lip = (LineaPresupuesto) listaLineaPresupuesto.get(contadorLineaPresupuesto);
                        contadorLineaPresupuesto++;
                    }

                    if (nlip != null) {
                        //VENTA
                        FamiliaVenta fv = BaseDatos.obtenerFamiliaVentaPorIidBD(a.getIid_fam_venta().getIid(), session);
                        TipoControl tc = BaseDatos.obtenerTipoControlPorIidBD(fv.getIid_tipo_control().getIid(), session);
                        TipoMedida tm = BaseDatos.obtenerTipoMedidaByIidBD(tc.getIid_tipo_medida().getIid(), session);

                        lip.setArticulo_iid(a);
                        lip.setCaracteristica(nlip.getCaracteristica());
                        lip.setNummedidas(tm.getNum_dimensiones());
                        lip.setCodigo(nlip.getCodigo());
                        lip.setPrecio(nlip.getPrecio());

                        if (nlip.getManual()) {
                            lip.setManual("S");
                        } else {
                            lip.setManual("N");
                        }

                        lip.setPresupuesto_iid(p);
                        lip.setDescuento(nlip.getDescuento());
                        lip.setCantidad(nlip.getCantidad());
                        lip.setMedida1(nlip.getMedida1());
                        lip.setMedida2(nlip.getMedida2());
                        lip.setMedida3(nlip.getMedida3());
                        lip.setMedida4(nlip.getMedida4());
                        lip.setMedida5(nlip.getMedida5());
                        lip.setMedidares(nlip.getMedidares());
                        lip.setDescripcion(nlip.getDescripcion());
                        lip.setPrecioArticulo(nlip.getPrecioArticulo());
                        lip.setImporte(nlip.getImporte());

                    } else if (nlic != null) {
                        //COMPRAS                     
                        FamiliaVenta fv = BaseDatos.obtenerFamiliaVentaPorIidBD(a.getIid_fam_venta().getIid(), session);
                        TipoControl tc = BaseDatos.obtenerTipoControlPorIidBD(fv.getIid_tipo_control().getIid(), session);
                        TipoMedida tm = BaseDatos.obtenerTipoMedidaByIidBD(tc.getIid_tipo_medida().getIid(), session);

                        lip.setArticulo_iid(a);
                        lip.setCaracteristica(nlic.getCaracteristica());
                        lip.setNummedidas(tm.getNum_dimensiones());
                        lip.setCodigo(nlic.getCodigo());
                        lip.setPrecio(nlic.getPrecio());
                        lip.setPresupuesto_iid(p);
                        lip.setDescuento(nlic.getDescuento());
                        lip.setCantidad(nlic.getCantidad());
                        lip.setMedida1(nlic.getMedida1());
                        lip.setMedida2(nlic.getMedida2());
                        lip.setMedida3(nlic.getMedida3());
                        lip.setMedida4(nlic.getMedida4());
                        lip.setMedida5(nlic.getMedida5());
                        lip.setMedidares(nlic.getMedidares());
                        lip.setDescripcion(nlic.getDescripcion());
                        lip.setPrecioArticulo(nlic.getPrecioArticulo());
                        lip.setImporte(nlic.getImporte());
                    }

                    lip.setLineaArticulo(true);
                    //VENTAS
                    if (nlip != null) {
                        if (indiceLineaPresupuestoBBDD + 1 > listaLineaPresupuesto.size()) {
                            iidLineaPresupuesto = (Integer) session.save(lip);
                            if (iidLineaPresupuesto != null && nlip.getIid() != null) {
                                mapCambioCorteLona.put(nlip.getIid(), iidLineaPresupuesto);
                            }
                            nlip.setIid(iidLineaPresupuesto);
                        } else {
                            iidLineaPresupuesto = lip.getIid();
                            indiceLineaPresupuestoBBDD++;
                            if (lip.getIid() != null && nlip.getIid() != null) {
                                mapCambioCorteLona.put(nlip.getIid(), lip.getIid());
                            }
                            session.update(lip);
                            nlip.setIid(iidLineaPresupuesto);
                        }
                    } else if (nlic != null) {
                        //COMPRAS
                        if (indiceLineaPresupuestoBBDD + 1 > listaLineaPresupuesto.size()) {
                            iidLineaPresupuesto = (Integer) session.save(lip);
                            if (iidLineaPresupuesto != null && nlic.getIid() != null) {
                                mapCambioCorteLona.put(nlic.getIid(), iidLineaPresupuesto);
                            }
                            nlic.setIid(iidLineaPresupuesto);
                        } else {
                            iidLineaPresupuesto = lip.getIid();
                            indiceLineaPresupuestoBBDD++;
                            if (lip.getIid() != null && nlic.getIid() != null) {
                                mapCambioCorteLona.put(nlic.getIid(), lip.getIid());
                            }
                            session.update(lip);
                            nlic.setIid(iidLineaPresupuesto);
                        }
                    }
                } else if ((nlip != null) && (!nlip.isLineaArticulo() && nlip.getDescripcion() != null && !nlip.getDescripcion().equals("")) || ((nlic != null) && (!nlic.isLineaArticulo() && nlic.getDescripcion() != null && !nlic.getDescripcion().equals("")))) {
                    //Si no se trata de un articulo
                    if (indiceLineaPresupuestoBBDD + 1 > listaLineaPresupuesto.size()) {
                        lip = new LineaPresupuesto();
                    } else {
                        lip = (LineaPresupuesto) listaLineaPresupuesto.get(contadorLineaPresupuesto);
                        contadorLineaPresupuesto++;
                    }

                    lip.setArticulo_iid(null);
                    lip.setCaracteristica(null);
                    lip.setNummedidas(null);
                    lip.setCodigo(nlip.getCodigo());
                    lip.setPrecio(null);
                    lip.setPresupuesto_iid(p);
                    lip.setDescuento(null);
                    lip.setCantidad(null);
                    lip.setMedida1(null);
                    lip.setMedida2(null);
                    lip.setMedida3(null);
                    lip.setMedida4(null);
                    lip.setMedida5(null);
                    lip.setMedidares(null);
                    lip.setPrecioArticulo(null);
                    lip.setLineaArticulo(false);
					
                    //VENTAS
                    if (nlip != null) {
                        lip.setDescripcion(nlip.getDescripcion());

                        if (indiceLineaPresupuestoBBDD + 1 > listaLineaPresupuesto.size()) {
                            iidLineaPresupuesto = (Integer) session.save(lip);
                            if (lip.getIid() != null && nlip.getIid() != null) {
                                mapCambioCorteLona.put(nlip.getIid(), iidLineaPresupuesto);
                            }
                            nlip.setIid(iidLineaPresupuesto);

                        } else {
                            iidLineaPresupuesto = lip.getIid();
                            indiceLineaPresupuestoBBDD++;
                            if (lip.getIid() != null && nlip.getIid() != null) {
                                mapCambioCorteLona.put(nlip.getIid(), lip.getIid());
                            }
                            session.update(lip);
                            nlip.setIid(iidLineaPresupuesto);
                        }
                        //COMPRAS
                    } else if (nlic != null) {
                        lip.setDescripcion(nlip.getDescripcion());
                        if (indiceLineaPresupuestoBBDD + 1 > listaLineaPresupuesto.size()) {
                            iidLineaPresupuesto = (Integer) session.save(lip);
                            if (lip.getIid() != null && nlip.getIid() != null) {
                                mapCambioCorteLona.put(nlip.getIid(), iidLineaPresupuesto);
                            }
                            nlip.setIid(iidLineaPresupuesto);
                        } else {
                            iidLineaPresupuesto = lip.getIid();
                            indiceLineaPresupuestoBBDD++;
                            if (lip.getIid() != null && nlip.getIid() != null) {
                                mapCambioCorteLona.put(nlip.getIid(), lip.getIid());
                            }
                            session.update(lip);
                            nlip.setIid(iidLineaPresupuesto);
                        }
                    }
                }
            }

            //hay que recorrer la lista de cortes de lonas e ir cambiado las referencias a las lineas presupuesto
            List listaCorteLona = session.createQuery("From LineaCorteLona where presupuesto = " + p.getIid()).list();
            Iterator iterN = listaCorteLona.iterator();
            LineaCorteLona lcl;
           
            List listaAuxiliar;
            while (iterN.hasNext()) {
                lcl = (LineaCorteLona) iterN.next();
                listaAuxiliar = session.createQuery("From LineaPresupuesto where iid = " + mapCambioCorteLona.get(lcl.getLineaPresupuesto().getIid())).list();
                if (listaAuxiliar != null && listaAuxiliar.size() > 0) {
                    lcl.setLineaPresupuesto((LineaPresupuesto) listaAuxiliar.get(0));
                }
            }


            listaAccionesActualizarCortes.clear();

            //Hay que guardar los dac rellenos
            String sDacPresupuesto = "";

            Integer clave;
            RellenarDac rdac;
            Dac dac;
            DacPresupuesto dp;
            DespiecePresupuesto despiecePresupuesto;

            Integer iidDacPresupuesto;
            Integer iidVariablePresupuesto;
            Integer iidDespiecePresupuesto;
            Integer iidSeleccionPresupuesto;
            int indiceDacPresupuestoBBDD = 0;
            int indiceDespiecePresupuestoBBDD = 0;
            int indiceSeleccionPresupuestoBBDD = 0;
            int indiceVariablePresupuestoBBDD = 0;
            int contador = 0;
            int contadorDespiece = 0;
            int contadorVariable = 0;
            int contadorSeleccion = 0;
            List<Despiece> listaDespiece;
            List listaVariables;
            List listaSeleccion;
            Iterator despieceIterator;
            Despiece despiece;
            Variable vTemp;
            Seleccion sTemp;
            VariablePresupuesto vp;
            SeleccionPresupuesto sp;
            HashMap<String, VariablePresupuesto> mapVar = null;
            HashMap<Integer, Integer> mapDespiecePresupuesto = null;
            List listaDacPresupuesto = session.createQuery("from DacPresupuesto where presupuesto.iid = " + iidPrespuesto).list();
            List listaDespiecePresupuesto = session.createQuery("from DespiecePresupuesto where dacPresupuesto.presupuesto.iid = " + iidPrespuesto).list();
            List listaVariablePresupuesto = session.createQuery("from VariablePresupuesto where dacPresupuesto.presupuesto.iid = " + iidPrespuesto).list();
            List listaSeleccionPresupuesto = session.createQuery("from SeleccionPresupuesto where dacPresupuesto.presupuesto.iid = " + iidPrespuesto).list();

            //AñADIR CHEQUEO PARA COMPROBAR TIPO DE DOCUMENTO
            if (rellenarDacMap != null) {
                for (Iterator it = rellenarDacMap.keySet().iterator(); it.hasNext();) {
                    clave = (Integer) it.next();
                    rdac = (RellenarDac) rellenarDacMap.get(clave);
                    dac = rdac.getDacBase();

                    if (mapVar != null) {
                        mapVar.clear();
                    } else {
                        mapVar = new HashMap<String, VariablePresupuesto>();
                    }

                    if (mapDespiecePresupuesto != null) {
                        mapDespiecePresupuesto.clear();
                    } else {
                        mapDespiecePresupuesto = new HashMap<Integer, Integer>();
                    }

                    if (indiceDacPresupuestoBBDD + 1 > listaDacPresupuesto.size()) {
                        dp = new DacPresupuesto();
                    } else {
                        dp = (DacPresupuesto) listaDacPresupuesto.get(contador);
                        contador++;
                    }

                    mapCambioCorteLona.clear();

                    dp.setArticulo(dac.getArticulo());
                    dp.setCaccesorios(dac.getCaccesorios());
                    dp.setCantidad(dac.getCantidad());
                    dp.setClacado(dac.getClacado());
                    dp.setDac(dac);
                    dp.setMedida1(dac.getMedida1());
                    dp.setMedida2(dac.getMedida2());
                    dp.setMedida3(dac.getMedida3());
                    dp.setMedida4(dac.getMedida4());
                    dp.setMedida5(dac.getMedida5());
                    dp.setPresupuesto(p);
                    dp.setCodigo(clave);

                    if (indiceDacPresupuestoBBDD + 1 > listaDacPresupuesto.size()) {
                        iidDacPresupuesto = (Integer) session.save(dp);
                    } else {
                        iidDacPresupuesto = dp.getIid();
                        indiceDacPresupuestoBBDD++;
                        session.update(dp);
                    }

                    listaDespiece = rdac.getListaDespiece();
                    listaVariables = rdac.getListaVbles();
                    listaSeleccion = rdac.getListaSeleccion();
                    despieceIterator = listaDespiece.iterator();

                    while (despieceIterator.hasNext()) {
                        despiece = (Despiece) despieceIterator.next();

                        if (indiceDespiecePresupuestoBBDD + 1 > listaDespiecePresupuesto.size()) {
                            despiecePresupuesto = new DespiecePresupuesto();
                        } else {
                            despiecePresupuesto = (DespiecePresupuesto) listaDespiecePresupuesto.get(contadorDespiece);
                            contadorDespiece++;
                        }

                        despiecePresupuesto.setArticulo(despiece.getArticulo());
                        despiecePresupuesto.setColor(despiece.getColor());
                        despiecePresupuesto.setDacPresupuesto(dp);
                        despiecePresupuesto.setFormulaCantidad(despiece.getFormulaCantidad());
                        despiecePresupuesto.setFormulaMedida1(despiece.getFormulaMedida1());
                        despiecePresupuesto.setFormulaMedida2(despiece.getFormulaMedida2());
                        despiecePresupuesto.setFormulaMedida3(despiece.getFormulaMedida3());
                        despiecePresupuesto.setFormulaMedida4(despiece.getFormulaMedida4());
                        despiecePresupuesto.setFormulaMedida5(despiece.getFormulaMedida5());
                        despiecePresupuesto.setAnadirIncremento(despiece.getAnadirIncremento());
                        despiecePresupuesto.setAnadirPvp(despiece.getAnadirPvp());
                        despiecePresupuesto.setArticuloBase(despiece.getArticuloBase());
                        despiecePresupuesto.setOrden(despiece.getOrden());
                        despiecePresupuesto.setRedondeo(despiece.getRedondeo());
                        despiecePresupuesto.setTipoArticulo(despiece.getTipoArticulo());
                        despiecePresupuesto.setCaracteristica(despiece.getCaracteristica());
                        despiecePresupuesto.setManual(despiece.getManual());

                        //precio despiece
                        if (despiece != null && (despiece.getPrecio() != null && despiece.getPrecio() != 0)) {
                            despiecePresupuesto.setPrecio(despiece.getPrecio());
                        }

                        if (indiceDespiecePresupuestoBBDD + 1 > listaDespiecePresupuesto.size()) {
                            iidDespiecePresupuesto = (Integer) session.save(despiecePresupuesto);
                            if (iidDespiecePresupuesto != null && despiece.getIidInicial() != null) {
                                mapCambioCorteLona.put(despiece.getIidInicial(), iidDespiecePresupuesto);
                            }
                        } else {
                            iidDespiecePresupuesto = despiecePresupuesto.getIid();
                            indiceDespiecePresupuestoBBDD++;
                            if (despiecePresupuesto.getIid() != null && despiece.getIidInicial() != null) {
                                mapCambioCorteLona.put(despiece.getIidInicial(), iidDespiecePresupuesto);
                            }
                            session.update(despiecePresupuesto);
                        }
                        despiece.setIidInicial(iidDespiecePresupuesto);
                    }

                    //hay que recorrer la lista de cortes de lonas e ir cambiado las referencias a los despieces
                    listaCorteLona = session.createQuery("From LineaCorteLona where presupuesto = " + p.getIid()).list();
                    iterN = listaCorteLona.iterator();
                    while (iterN.hasNext()) {
                        lcl = (LineaCorteLona) iterN.next();
                        if (lcl.getEsDespiece() != null && lcl.getDespiece() != null) {
                            listaAuxiliar = session.createQuery("From DespiecePresupuesto where iid = " + mapCambioCorteLona.get(lcl.getDespiece().getIid())).list();
                            if (listaAuxiliar != null && listaAuxiliar.size() > 0) {
                                lcl.setDespiece((DespiecePresupuesto) listaAuxiliar.get(0));
                            }
                        }
                    }

                    //Hay que almacenar la lista de Vbles
                    Iterator iterV = listaVariables.iterator();

                    while (iterV.hasNext()) {
                        vTemp = (Variable) iterV.next();

                        if (indiceVariablePresupuestoBBDD + 1 > listaVariablePresupuesto.size()) {
                            vp = new VariablePresupuesto();
                        } else {
                            vp = (VariablePresupuesto) listaVariablePresupuesto.get(contadorVariable);
                            contadorVariable++;
                        }

                        vp.setActivarMaximo(vTemp.getActivarMaximo());
                        vp.setActivarMinimo(vTemp.getActivarMinimo());
                        vp.setActivarPeticion(vTemp.getActivarPeticion());
                        vp.setCondicion(vTemp.getCondicion());
                        vp.setDac(vTemp.getDac());
                        vp.setEditarResultadoFormula(vTemp.getEditarResultadoFormula());
                        vp.setFormula(vTemp.getFormula());
                        vp.setNombre(vTemp.getNombre());
                        vp.setTipo(vTemp.getTipo());
                        vp.setTipoToldo(vTemp.getTipoToldo());
                        vp.setValor(vTemp.getValor());
                        vp.setValorMaximo(vTemp.getValorMaximo());
                        vp.setValorMinimo(vTemp.getValorMinimo());
                        vp.setDacPresupuesto(dp);
                        vp.setDac(vTemp.getDac());
                        if (indiceVariablePresupuestoBBDD + 1 > listaVariablePresupuesto.size()) {
                            iidVariablePresupuesto = (Integer) session.save(vp);
                            vp.setIid(iidVariablePresupuesto);
                        } else {
                            iidVariablePresupuesto = vp.getIid();
                            indiceVariablePresupuestoBBDD++;
                            session.update(vp);
                        }
                        mapVar.put(vp.getNombre(), vp);
                    }

                    //Hay que almacenar la lista de seleccion
                    Iterator iterS = listaSeleccion.iterator();

                    while (iterS.hasNext()) {
                        sTemp = (Seleccion) iterS.next();

                        if (indiceSeleccionPresupuestoBBDD + 1 > listaSeleccionPresupuesto.size()) {
                            sp = new SeleccionPresupuesto();
                        } else {
                            sp = (SeleccionPresupuesto) listaSeleccionPresupuesto.get(contadorSeleccion);
                            contadorSeleccion++;
                        }

                        sp.setCondicion(sTemp.getCondicion());
                        sp.setDacPresupuesto(dp);
                        sp.setNombre(sTemp.getNombre());
                        sp.setSeleccionada(sTemp.getSeleccionada());
                        sp.setValor(sTemp.getValor());
                        sp.setVariablePresupuesto(mapVar.get(sTemp.getVariable().getNombre()));

                        if (indiceSeleccionPresupuestoBBDD + 1 > listaSeleccionPresupuesto.size()) {
                            iidSeleccionPresupuesto = (Integer) session.save(sp);
                        } else {
                            iidSeleccionPresupuesto = sp.getIid();
                            indiceSeleccionPresupuestoBBDD++;
                            session.update(sp);
                        }
                    }
                }
            }
            
            Object o;
            if (listaLineaPresupuesto != null) {
                for (int i = indiceLineaPresupuestoBBDD; i < listaLineaPresupuesto.size(); i++) {
                    lip = (LineaPresupuesto) listaLineaPresupuesto.get(i);
                    o = session.load(LineaPresupuesto.class, lip.getIid());
                    session.delete(o);
                }
            }

            if (listaDespiecePresupuesto != null) {
                for (int i = indiceDespiecePresupuestoBBDD; i < listaDespiecePresupuesto.size(); i++) {
                    despiecePresupuesto = (DespiecePresupuesto) listaDespiecePresupuesto.get(i);
                    o = session.load(DespiecePresupuesto.class, despiecePresupuesto.getIid());
                    session.delete(o);
                }
            }

            if (listaSeleccionPresupuesto != null) {
                for (int i = indiceSeleccionPresupuestoBBDD; i < listaSeleccionPresupuesto.size(); i++) {
                    sp = (SeleccionPresupuesto) listaSeleccionPresupuesto.get(i);
                    o = session.load(SeleccionPresupuesto.class, sp.getIid());
                    session.delete(o);
                }
            }

            if (listaVariablePresupuesto != null) {
                for (int i = indiceVariablePresupuestoBBDD; i < listaVariablePresupuesto.size(); i++) {
                    vp = (VariablePresupuesto) listaVariablePresupuesto.get(i);
                    o = session.load(VariablePresupuesto.class, vp.getIid());
                    session.delete(o);
                }
            }

            if (listaDacPresupuesto != null) {
                for (int i = indiceDacPresupuestoBBDD; i < listaDacPresupuesto.size(); i++) {
                    dp = (DacPresupuesto) listaDacPresupuesto.get(i);
                    o = session.load(DacPresupuesto.class, dp.getIid());
                    session.delete(o);
                }
            }

            //Actualizar estado de montaje  
            //Obtenemos el montaje
            List<Montaje> lm = session.createQuery("from Montaje where iidPedido = " + p.getIid()).list();
            if (lm != null && lm.size() > 0) {
                Montaje m = (Montaje) lm.get(0);
                if (p.getInstalado()) {
                    m.setMontado("S");
                } else {
                    m.setMontado("N");
                }
                session.update(m);
            }

        } catch (Exception ex) {
            ex.printStackTrace();
            res = false;
            session.getTransaction().rollback();
        } finally {
            if (session.isOpen() && session.getTransaction().isActive()) {
                session.getTransaction().commit();
            }
        }

        return res;
    }

    /********************
     * LineaPresupuesto *
     ********************/
    public static List getListaLineaPresupuesto(Integer presupuestoIid) {
        List lp = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lp = session.createQuery("from LineaPresupuesto where presupuesto_iid = " + presupuestoIid).list();
        } catch (Exception e) {
            lp = null;
        }
        return lp;
    }

    public static LineaPresupuesto obtenerLineaPresupuestoByPresupuestoCodigo(Integer iidPresupuesto, Integer codigo) {
        List lp = null;
        LineaPresupuesto res = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lp = session.createQuery("from LineaPresupuesto where presupuesto_iid = " + iidPresupuesto + " and codigo = " + codigo).list();
            if (lp != null && lp.size() > 0) {
                res = (LineaPresupuesto) lp.get(0);
            }
        } catch (Exception e) {
            res = null;
        }
        return res;
    }

    public static LineaPresupuesto getLineaPresupuesto(Integer Iid) {
        LineaPresupuesto lp = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            List lineas = session.createQuery("from LineaPresupuesto where iid = " + Iid).list();
            if (lineas.size() >= 1) {
                lp = ((LineaPresupuesto) lineas.get(0));
            } 
        } catch (Exception e) {
            lp = null;
        }
        return lp;
    }

    /********************
     * CLASE_DOCUMENTOS *
	 ********************/
    public static List getListaClaseDocumentos() {
        List lcd = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lcd = session.createQuery("from ClaseDocumento").list();
        } catch (Exception e) {
            lcd = null;
        }
        return lcd;
    }

    public static ClaseDocumento getClaseDocumentosByDescripcion(String descripcion) {
        List lcd = null;
        ClaseDocumento res = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lcd = session.createQuery("from ClaseDocumento where descripcion = '" + descripcion + "'").list();
            if (lcd != null && lcd.size() > 0) {
                res = (ClaseDocumento) lcd.get(0);
            }
        } catch (Exception e) {
            lcd = null;
        }
        return res;
    }

    public static ClaseDocumento getClaseDocumentosByIid(Integer iidCd) {
        List lcd = null;
        ClaseDocumento res = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lcd = session.createQuery("from ClaseDocumento where iid = " + iidCd).list();
            if (lcd != null && lcd.size() > 0) {
                res = (ClaseDocumento) lcd.get(0);
            }
        } catch (Exception e) {
            res = null;
        }
        return res;
    }

    /*****************************
     * Medidas Familia De Ventas *
     *****************************/
    public static List getListaMedidasFamiliaVenta(Integer iidFamVenta) {
        List lmfv = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lmfv = session.createQuery("from MedidasFamiliaVenta where iid_fam_venta = " + iidFamVenta).list();
        } catch (Exception e) {
            lmfv = null;
        }
        return lmfv;
    }

    public static MedidasFamiliaVenta obtenerMedidasFamiliaVentaPorMedida(Integer iidFamVenta, int numMedidas, String medida1, String medida2, String medida3, String medida4, String medida5) {
        MedidasFamiliaVenta res = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            String consulta = "from MedidasFamiliaVenta ";
            if (numMedidas == 1) {
                consulta += "where medida1 =" + medida1;
            } else if (numMedidas == 2) {
                consulta += "where medida1 =" + medida1 + " and medida2 =" + medida2;
            } else if (numMedidas == 3) {
                consulta += "where medida1 =" + medida1 + " and medida2 =" + medida2 + " and medida3 =" + medida3;
            } else if (numMedidas == 4) {
                consulta += "where medida1 =" + medida1 + " and medida2 =" + medida2 + " and medida3 =" + medida3 + " and medida4 =" + medida4;
            } else if (numMedidas == 5) {
                consulta += "where medida1 =" + medida1 + " and medida2 =" + medida2 + " and medida3 =" + medida3 + " and medida4 =" + medida4 + " and medida5 =" + medida5;
            }
            List lm = session.createQuery(consulta).list();
            if (lm.size() >= 1) {
                res = ((MedidasFamiliaVenta) lm.get(0));
            }
        } catch (Exception e) {
            res = null;
        }

        return res;
    }

    /************
     * Metadata *
     ************/
    public static Metadata obtenerMetadaPorNombre(String nombre, Integer idEmpresa) {
        Metadata res = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            List lp = session.createQuery("from Metadata where nombre='" + nombre + "' and iid_empresa=" + idEmpresa).list();
            if (lp.size() >= 1) {
                res = ((Metadata) lp.get(0));
            }
        } catch (Exception e) {
            res = null;
        } 

        return res;
    }

    public static boolean actualizarMetadata(String anyoActual) {
        boolean res = true;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            List listaMetadata = session.createQuery("from Metadata").list();
            Iterator it = listaMetadata.iterator();
            Metadata metaData;
            while (it.hasNext()) {
                metaData = (Metadata) it.next();
                if (metaData.getNombre().startsWith("anio")) {
                    metaData.setValor(anyoActual);
                } else if (metaData.getNombre().startsWith("num")) {
                    metaData.setValor("1");
                }
                session.update(metaData);
            }
        } catch (Exception e) {
            res = false;
            session.getTransaction().rollback();
        } finally {
            if (session.isOpen() && session.getTransaction().isActive()) {
                session.getTransaction().commit();
            }
        }

        return res;
    }

    /****************
     ** Inventario **
     ****************/
    public static List getListaClaseInventario() {
        List lci = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        log.info("Se ha entrado a la clase: BaseDatos, método: getListaClaseInventario");
        try {
            lci = session.createQuery("from ClaseInventario").list();
        } catch (Exception e) {
            log.error("Se ha producido una excepción en la clase: BaseDatos, método: getListaClaseInventario");
            lci = null;
        }
        return lci;
    }

    public static ClaseInventario obtenerClaseInventarioPorNombre(String nombre) {
        ClaseInventario res = null;
        log.info("Se ha entrado a la clase: BaseDatos, método: obtenerClaseInventarioPorNombre");
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            List lClaseInventario = session.createQuery("from ClaseInventario where nombre = '" + nombre + "'").list();
            if (lClaseInventario.size() >= 1) {
                res = ((ClaseInventario) lClaseInventario.get(0));
            }
        } catch (Exception e) {
            log.error("Se ha producido una excepción en la clase: BaseDatos, método: getListaClaseInventario");
            res = null;
        }
        return res;
    }

    public static List getListaTipoInventario() {
        List lti = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lti = session.createQuery("from TipoInventario").list();
        } catch (Exception e) {
            lti = null;
        }
        return lti;
    }

    public static TipoInventario obtenerTipoInventarioPorNombre(String nombre) {
        TipoInventario res = null;
        log.info("Se ha entrado a la clase: BaseDatos, mÃ©todo: obtenerTipoInventarioPorNombre");
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            List lTipoInventario = session.createQuery("from TipoInventario where nombre = '" + nombre + "'").list();
            if (lTipoInventario.size() >= 1) {
                res = ((TipoInventario) lTipoInventario.get(0));
            }
        } catch (Exception e) {
            log.error("Se ha producido una excepciÃ³n en la clase: BaseDatos, mÃ©todo: obtenerTipoInventarioPorNombre");
            res = null;
        }
        return res;
    }

    /*************************
     ** Movimientos Almacén **
     *************************/
    public static boolean elimnarMovimientoAlmacen(MovimientoAlmacen ma) {
        boolean res = true;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            Object o = session.load(MovimientoAlmacen.class, ma.getIid());
            if (o != null) {
                Existencia ex;
                String queryEx = sExistencia(ma);
                List lExistencias = session.createQuery(queryEx).list();
                if (lExistencias.size() >= 1) {
                    ex = ((Existencia) lExistencias.get(0));
                } else {
                    ex = null;
                }

                if (ex != null) {
                    ex.setExistencia(ex.getExistencia() - ma.getCantidad());
                    if (ex.getExistencia() == 0F) {
                        //Si no quedan existencias se borra
                        session.delete(ex);
                    } else {
                        //En otro caso se actualiza
                        session.update(ex);
                    }
                }
            }
            session.delete(o);
        } catch (Exception e) {
            res = false;
            session.getTransaction().rollback();
        } finally {
            if (session.isOpen() && session.getTransaction().isActive()) {
                session.getTransaction().commit();
            }
            return res;
        }
    }

    public static boolean elimnarMovimientoAlmacenDocumento(Presupuesto p) {
        boolean res = true;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            String consultaMovimientoAlmacen = "delete from MovimientoAlmacen where presupuesto.iid = " + p.getIid();
            session.createQuery(consultaMovimientoAlmacen);
        } catch (Exception e) {
            res = false;
            session.getTransaction().rollback();
        } finally {
            if (session.isOpen() && session.getTransaction().isActive()) {
                session.getTransaction().commit();
            }
            return res;
        }
    }

    public static List getListaMovimientosAlmacen() {
        List lti = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lti = session.createQuery("from MovimientoAlmacen").list();
        } catch (Exception e) {
            lti = null;
        }
        return lti;
    }
    
    public static List<MovimientoAlmacen> getListaMovimientosAlmacenPorConcepto(Integer iidEmpresa, String concepto){
        List<MovimientoAlmacen> lti = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            String query = "from MovimientoAlmacen where empresa.iid = " + iidEmpresa + " and concepto like '%" + concepto + "%'";
            lti = session.createQuery(query).list();
        } catch (Exception e) {
            log.error("Error en el mÃ©todo getListaMovimientosAlmacenPorConcepto", e);
            lti = null;
        }
        return lti;
    }
    
    public static MovimientoAlmacen getMovimientoAlmacenByIid(Integer iid){
        MovimientoAlmacen m = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            List<MovimientoAlmacen> lti = session.createQuery("from MovimientoAlmacen where iid = " + iid).list();
            if(lti != null && lti.size() > 0){
                m = lti.get(0);
            }
        } catch (Exception e) {
            log.error("Error en el método getMovimientoAlmacenByIid", e);
            m = null;
        }
        return m;
    }
    
    public static List<MovimientoAlmacen> getListaMovimientosAlmacenPorArticulo(Integer iidEmpresa, String articulo){
        List<MovimientoAlmacen> lti = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            String query = "select ma.iid "
                    + "from MovimientoAlmacen ma "
                    + "inner join ma.articulo as ar "
                    + "where ma.empresa.iid = " + iidEmpresa
                    + " and ar.cod_articulo like '%" + articulo + "%'";
            List lp = session.createQuery(query).list();
            if (lp != null) {
                lti = new ArrayList<MovimientoAlmacen>();
                MovimientoAlmacen ma;
                for (Iterator it = lp.iterator(); it.hasNext();) {
                    ma = BaseDatos.getMovimientoAlmacenByIid((Integer) it.next());
                    lti.add(ma);
                }
            } else {
                lti = new ArrayList<MovimientoAlmacen>();
            }
        } catch (Exception e) {
            log.error("Error en el método getListaMovimientosAlmacenPorArticulo", e);
            lti = null;
        }
        return lti;
    }

    public static List getListaMovimientosAlmacen(Integer iidEmpresa) {
        List lti = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lti = session.createQuery("from MovimientoAlmacen where empresa.iid = " + iidEmpresa).list();
        } catch (Exception e) {
            lti = null;
        }
        return lti;
    }
    
    public static List getListaMovimientosAlmacenporDoc(Integer presupuesto) {
        List lti = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            String query;
            query = "from MovimientoAlmacen where presupuesto.iid = " + presupuesto;
            lti = session.createQuery(query).list();
        } catch (Exception e) {
            lti = null;
        }
        return lti;
    }

    public static List getListaMovimientosAlmacenFiltrados(Articulo a, Empresa em) {
        List lmaf = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        String query = "From MovimientoAlmacen where empresa.iid = " + em.getIid() + " and articulo.iid = " + a.getIid();
        try {
            lmaf = session.createQuery(query).list();
        } catch (Exception e) {
            log.error("Se ha producido una excepción en la clase: BaseDatos, método: getListaMovimientosAlmacenFiltrados");
            lmaf = null;
        }
        return lmaf;
    }

    public static MovimientoAlmacen obtenerMovimientoAlmacenCompleto(MovimientoAlmacen ma) {
        MovimientoAlmacen res = null;
        log.info("Se ha entrado a la clase: BaseDatos, método: obtenerMovimientoAlmacenCompleto");
        String query = BaseDatos.sMovimientoAlmacenEntradaSalida(ma);
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            List lMovimientosAlmacen = session.createQuery(query).list();
            if (lMovimientosAlmacen.size() >= 1) {
                res = ((MovimientoAlmacen) lMovimientosAlmacen.get(0));
            }
        } catch (Exception e) {
            log.error("Se ha producido una excepciÃ³n en la clase: BaseDatos, mÃ©todo: obtenerMovimientoAlmacenCompleto");
            res = null;
        }
        return res;
    }

    private static String sMovimientoAlmacen(MovimientoAlmacen ma) {
        String query = "From MovimientoAlmacen where fecha like '" + ma.getFecha() + "'"
                + " and concepto like '" + ma.getConcepto() + "' "
                + " and almacen = " + ma.getAlmacen().getIid()
                + " and articulo = " + ma.getArticulo().getIid()
                + " and empresa = " + ma.getEmpresa().getIid()
                + " and tipoMovimiento = " + ma.getTipoMovimiento().getIid();
        if (ma.getCaracteristica() == null) {
            query += " and caracteristica is null ";
        } else {
            query += " and caracteristica = " + ma.getCaracteristica().getIid();
        }

        if (ma.getCantidad1() != null) {
            query += " and (abs(cantidad1 - " + ma.getCantidad1() + ") < " + Constantes.THRESHOLD + ")";
        }

        if (ma.getCantidad2() != null) {
            query += " and (abs(cantidad2 - " + ma.getCantidad2() + ") < " + Constantes.THRESHOLD + ")";
        }

        if (ma.getCantidad3() != null) {
            query += " and (abs(cantidad3 - " + ma.getCantidad3() + ") < " + Constantes.THRESHOLD + ")";
        }

        if (ma.getCantidad4() != null) {
            query += " and (abs(cantidad4 - " + ma.getCantidad4() + ") < " + Constantes.THRESHOLD + ")";
        }

        if (ma.getCantidad5() != null) {
            query += " and (abs(cantidad5 - " + ma.getCantidad5() + ") < " + Constantes.THRESHOLD + ")";
        }

        return query;
    }

    private static String sMovimientoAlmacenEntradaSalida(MovimientoAlmacen ma) {
        String query = sMovimientoAlmacen(ma);
        query += " and tipoMovimiento = " + ma.getTipoMovimiento().getIid();

        if (ma.getCantidad() != null) {
            query += " and (abs(cantidad - " + ma.getCantidad() + ") < " + Constantes.THRESHOLD + ")";
        }
        if (ma.getPrecio() != null) {
            query += " and (abs(precio - " + ma.getPrecio() + ") < " + Constantes.THRESHOLD + ")";
        }
        if (ma.getValoracionPrecio() != null && !ma.getValoracionPrecio().equals("")) {
            query += " and valoracionPrecio like '%" + ma.getValoracionPrecio() + "%'";
        }
        return query;
    }

    public static boolean insertarMovimientoExistencia(MovimientoAlmacen ma) {
        boolean ok = true;
        MovimientoAlmacen maBBDD = null;
        Existencia ex;
        Float cantidadAntigua = ma.getCantidad();
        log.info("Se ha entrado a la clase: BaseDatos, mÃ©todo: insertarMovimientoExistencia");
        String query = sMovimientoAlmacen(ma);
        String queryExistencia = sExistencia(ma);
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            List lMovimientosAlmacen = session.createQuery(query).list();
            List lExistencias = session.createQuery(queryExistencia).list();
            if (lMovimientosAlmacen.size() >= 1) {
                //Se ha de actualizar el movimiento y modificar la existencia
                maBBDD = ((MovimientoAlmacen) lMovimientosAlmacen.get(0));
                cantidadAntigua -= maBBDD.getCantidad();
                maBBDD.setIniciarMedidas(ma.isIniciarMedidas());
                maBBDD.setPrecio(ma.getPrecio());
                maBBDD.setTipoMovimiento(ma.getTipoMovimiento());
                maBBDD.setValoracionPrecio(ma.getValoracionPrecio());
                maBBDD.setCantidad(ma.getCantidad());
                
                if(ma.getUnidadMedida1()!=null){
                    maBBDD.setUnidadMedida1(ma.getUnidadMedida1());
                }
                if(ma.getUnidadMedida2()!=null){
                    maBBDD.setUnidadMedida2(ma.getUnidadMedida2());
                }
                if(ma.getUnidadMedida3()!=null){
                    maBBDD.setUnidadMedida3(ma.getUnidadMedida3());
                }
                if(ma.getUnidadMedida4()!=null){
                    maBBDD.setUnidadMedida4(ma.getUnidadMedida4());
                }
                if(ma.getUnidadMedida5()!=null){
                    maBBDD.setUnidadMedida5(ma.getUnidadMedida5());
                }
                
                session.update(maBBDD);
            } else {
                // Se ha de añadir el movimiento y modificar la existencia;
                session.save(ma);
            }

            if (lExistencias.size() > 0) {
                ex = (Existencia) lExistencias.get(0);
                ex.setExistencia(ex.getExistencia() + cantidadAntigua);
                session.update(ex);
            } else {
                ex = new Existencia();
                ex.setAlmacen(ma.getAlmacen());
                ex.setArticulo(ma.getArticulo());
                ex.setCantidad1(ma.getCantidad1());
                ex.setCantidad2(ma.getCantidad2());
                ex.setCantidad3(ma.getCantidad3());
                ex.setCantidad4(ma.getCantidad4());
                ex.setCantidad5(ma.getCantidad5());
                ex.setCaracteristica(ma.getCaracteristica());
                ex.setEmpresa(ma.getEmpresa());
                ex.setExistencia(cantidadAntigua);
                
                if(ma.getUnidadMedida1()!=null){
                    ex.setUnidadMedida1(ma.getUnidadMedida1());
                }
                if(ma.getUnidadMedida2()!=null){
                    ex.setUnidadMedida2(ma.getUnidadMedida2());
                }
                if(ma.getUnidadMedida3()!=null){
                    ex.setUnidadMedida3(ma.getUnidadMedida3());
                }
                if(ma.getUnidadMedida4()!=null){
                    ex.setUnidadMedida4(ma.getUnidadMedida4());
                }
                if(ma.getUnidadMedida5()!=null){
                    ex.setUnidadMedida5(ma.getUnidadMedida5());
                }
                session.save(ex);
            }
        } catch (Exception e) {
            log.error("Se ha producido una excepción en la clase: BaseDatos, método: obtenerMovimientoAlmacenCompleto");
            ok = false;
            session.getTransaction().rollback();
        } finally {
            if (session.isOpen() && session.getTransaction().isActive()) {
                session.getTransaction().commit();
            }
        }
        return ok;
    }
	
	public static void insertarMovimientoExistenciaSession(MovimientoAlmacen ma, Session session) throws Exception {

        MovimientoAlmacen maBBDD = null;
        Existencia ex;
        Float cantidadAntigua = ma.getCantidad();

        String query = sMovimientoAlmacen(ma);
        String queryExistencia = sExistencia(ma);

        try{
            List lMovimientosAlmacen = session.createQuery(query).list();
            List lExistencias = session.createQuery(queryExistencia).list();
            if (lMovimientosAlmacen.size() >= 1) {
                //Se ha de actualizar el movimiento y modificar la existencia
                maBBDD = ((MovimientoAlmacen) lMovimientosAlmacen.get(0));
                cantidadAntigua -= maBBDD.getCantidad();
                maBBDD.setIniciarMedidas(ma.isIniciarMedidas());
                maBBDD.setPrecio(ma.getPrecio());
                maBBDD.setTipoMovimiento(ma.getTipoMovimiento());
                maBBDD.setValoracionPrecio(ma.getValoracionPrecio());
                maBBDD.setCantidad(ma.getCantidad());
                
                if(ma.getUnidadMedida1()!=null){
                    maBBDD.setUnidadMedida1(ma.getUnidadMedida1());
                }
                if(ma.getUnidadMedida2()!=null){
                    maBBDD.setUnidadMedida2(ma.getUnidadMedida2());
                }
                if(ma.getUnidadMedida3()!=null){
                    maBBDD.setUnidadMedida3(ma.getUnidadMedida3());
                }
                if(ma.getUnidadMedida4()!=null){
                    maBBDD.setUnidadMedida4(ma.getUnidadMedida4());
                }
                if(ma.getUnidadMedida5()!=null){
                    maBBDD.setUnidadMedida5(ma.getUnidadMedida5());
                }
                
                session.update(maBBDD);
            } else {
                // Se ha de añadir el movimiento y modificar la existencia;
                session.save(ma);
            }

            if (lExistencias.size() > 0) {
                ex = (Existencia) lExistencias.get(0);
                ex.setExistencia(ex.getExistencia() + cantidadAntigua);
                session.update(ex);
            } else {
                ex = new Existencia();
                ex.setAlmacen(ma.getAlmacen());
                ex.setArticulo(ma.getArticulo());
                ex.setCantidad1(ma.getCantidad1());
                ex.setCantidad2(ma.getCantidad2());
                ex.setCantidad3(ma.getCantidad3());
                ex.setCantidad4(ma.getCantidad4());
                ex.setCantidad5(ma.getCantidad5());
                ex.setCaracteristica(ma.getCaracteristica());
                ex.setEmpresa(ma.getEmpresa());
                ex.setExistencia(cantidadAntigua);
                
                if(ma.getUnidadMedida1()!=null){
                    ex.setUnidadMedida1(ma.getUnidadMedida1());
                }
                if(ma.getUnidadMedida2()!=null){
                    ex.setUnidadMedida2(ma.getUnidadMedida2());
                }
                if(ma.getUnidadMedida3()!=null){
                    ex.setUnidadMedida3(ma.getUnidadMedida3());
                }
                if(ma.getUnidadMedida4()!=null){
                    ex.setUnidadMedida4(ma.getUnidadMedida4());
                }
                if(ma.getUnidadMedida5()!=null){
                    ex.setUnidadMedida5(ma.getUnidadMedida5());
                }

                session.save(ex);
            }
        } catch (Exception e) {
            log.error("Se ha producido una excepcion en la clase: BaseDatos, metodo: insertarMovimientoExistenciaSession ", e);
            throw e;
        }
    }

    public static boolean modificarMovimientoExistencia(MovimientoAlmacen mvaNuevo, MovimientoAlmacen mvaAntiguo) {
        //1.- Hay que borrar las existencias del movimientoAntiguo;
        //2.- Hay que crear las existencias del movimientoNuevo;
        //3.- Hay que modificar el movimentoNuevo
        boolean ok;

        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();

        try {
            ok = true;
            MovimientoAlmacen maBBDD = null;
            Existencia ex;
            Float cantidadAntigua = mvaAntiguo.getCantidad();

            log.info("Se ha entrado a la clase: BaseDatos, mÃ©todo: modificarMovimientoExistencia");

            String query = sMovimientoAlmacen(mvaAntiguo);
            String queryExistencia = sExistencia(mvaAntiguo);

            //Se actualizan los movimientos "Antiguos"
            List lmaAntiguo = session.createQuery(query).list();
            if (lmaAntiguo != null && lmaAntiguo.size() > 0) {
                MovimientoAlmacen movBBDD;
                maBBDD = (MovimientoAlmacen) lmaAntiguo.get(0);
                maBBDD.setCantidad(maBBDD.getCantidad() - cantidadAntigua);
                session.delete(maBBDD);
            }
            //Se actualizan las existencias "Antiguas"
            List lExistenciaAntiguo = session.createQuery(queryExistencia).list();
            if (lExistenciaAntiguo != null && lExistenciaAntiguo.size() > 0) {
                Existencia exBBDD;
                exBBDD = (Existencia) lExistenciaAntiguo.get(0);
                exBBDD.setExistencia(exBBDD.getExistencia() - cantidadAntigua);
                if (exBBDD.getExistencia() != 0) {
                    //Si quedan existencias se modifica la existencia
                    session.update(exBBDD);
                } else {
                    //Si no quedan existencias se borra
                    session.delete(exBBDD);
                }
            }

            //Ahora viene ya lo nuevo
            String queryNueva = sMovimientoAlmacen(mvaNuevo);
            String queryExistenciaNueva = sExistencia(mvaNuevo);

            List lMovimientosAlmacen = session.createQuery(queryNueva).list();
            List lExistencias = session.createQuery(queryExistenciaNueva).list();
            if (lMovimientosAlmacen.size() >= 1) {
                //Se ha de actualizar el movimiento y modificar la existencia
                maBBDD = ((MovimientoAlmacen) lMovimientosAlmacen.get(0));
                cantidadAntigua -= maBBDD.getCantidad();
                maBBDD.setIniciarMedidas(mvaNuevo.isIniciarMedidas());
                maBBDD.setPrecio(mvaNuevo.getPrecio());
                maBBDD.setTipoMovimiento(mvaNuevo.getTipoMovimiento());
                maBBDD.setValoracionPrecio(mvaNuevo.getValoracionPrecio());
                maBBDD.setCantidad(mvaNuevo.getCantidad());
                session.update(maBBDD);
            } else {
                // Se ha de aÃ±adir el movimiento y modificar la existencia;
                session.save(mvaNuevo);
            }

            if (lExistencias.size() > 0) {
                ex = (Existencia) lExistencias.get(0);
                ex.setExistencia(ex.getExistencia() + cantidadAntigua);
                session.update(ex);
            } else {
                ex = new Existencia();
                ex.setAlmacen(mvaNuevo.getAlmacen());
                ex.setArticulo(mvaNuevo.getArticulo());
                ex.setCantidad1(mvaNuevo.getCantidad1());
                ex.setCantidad2(mvaNuevo.getCantidad2());
                ex.setCantidad3(mvaNuevo.getCantidad3());
                ex.setCantidad4(mvaNuevo.getCantidad4());
                ex.setCantidad5(mvaNuevo.getCantidad5());
                ex.setCaracteristica(mvaNuevo.getCaracteristica());
                ex.setEmpresa(mvaNuevo.getEmpresa());
                ex.setExistencia(cantidadAntigua);
                session.save(ex);
            }
        } catch (Exception e) {
            ok = false;
            session.getTransaction().rollback();
        } finally {
            if (session.isOpen() && session.getTransaction().isActive()) {
                session.getTransaction().commit();
            }
        }

        return ok;
    }

    /*****************
     ** Existencias **
     *****************/
    public static List getListaExistencias(Articulo ar) {

        log.info("Se ha entrado a la clase: BaseDatos, método: getListaExistencias");
        List<Existencia> lRes = null;
        List le = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        String query = "select  almacen.iid, caracteristica.iid, sum(existencia), cantidad1, cantidad2, cantidad3, cantidad4, cantidad5 from Existencia exi where articulo.iid = " + ar.getIid() + " and (esta_usado is null or esta_usado = 0)  group by almacen.iid, caracteristica.iid, cantidad1, cantidad2 order by cantidad1, cantidad2";
        try {
            le = session.createQuery(query).list();
            if (le != null && le.size() > 0) {
                lRes = new ArrayList<Existencia>();
                Iterator iter = le.iterator();
                Object[] temp;
                Existencia ex;
                List lista;
                Integer iidAlmacen;
                Integer iidCaracteristica;

                while (iter.hasNext()) {
                    temp = (Object[]) iter.next();
                    ex = new Existencia();
                    ex.setArticulo(ar);
                    iidAlmacen = (Integer) temp[0];
                    iidCaracteristica = (Integer) temp[1];
                    if (iidAlmacen != null) {
                        lista = session.createQuery("from Almacen where iid = " + iidAlmacen).list();
                        if (lista != null && lista.size() >= 1) {
                            ex.setAlmacen((Almacen) lista.get(0));
                        }
                    }

                    if (iidCaracteristica != null) {
                        lista = session.createQuery("from Caracteristica where iid = " + iidCaracteristica).list();
                        if (lista != null && lista.size() >= 1) {
                            ex.setCaracteristica((Caracteristica) lista.get(0));
                        }
                    }
                    ex.setExistencia((Float) new Float(temp[2].toString()));
                    ex.setCantidad1((Float) temp[3]);
                    ex.setCantidad2((Float) temp[4]);
                    ex.setCantidad3((Float) temp[5]);
                    ex.setCantidad4((Float) temp[6]);
                    ex.setCantidad5((Float) temp[7]);
                    lRes.add(ex);
                }
            }
            else {
                lRes = le;
            }
        } catch (Exception e) {
            log.error("Se ha producido una excepción en la clase: BaseDatos, método: getListaExistencias");
            lRes = null;
            session.getTransaction().rollback();
        } finally {
            if (session.isOpen() && session.getTransaction().isActive()) {
                session.getTransaction().commit();
            }
        }
        return lRes;
    }

    public static List getListaExistencias(Articulo ar, Almacen al) {
        log.info("Se ha entrado a la clase: BaseDatos, método: getListaExistencias");
        List le = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        String query = "From Existencia where articulo.iid = " + ar.getIid();
        if (al != null) {
            query += " and almacen.iid = " + al.getIid();
        }
        try {
            le = session.createQuery(query).list();
        } catch (Exception e) {
            log.error("Se ha producido una excepción en la clase: BaseDatos, método: getListaExistencias");
            le = null;
        }
        return le;
    }

    public static List getListaExistencias(Articulo ar, Integer iidCaracteristica, Almacen al) {
        log.info("Se ha entrado a la clase: BaseDatos, método: getListaExistencias");
        List le = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        String query = "From Existencia where articulo.iid = " + ar.getIid() + " and caracteristica.iid = " + iidCaracteristica + " and existencia > 0";
        if (al != null) {
            query += " and almacen.iid = " + al.getIid();
        }
        query += " and (esResto is null or esResto = 0)";
        try {
            le = session.createQuery(query).list();
        } catch (Exception e) {
            log.error("Se ha producido una excepción en la clase: BaseDatos, método: getListaExistencias");
            le = null;
        }
        return le;
    }

    public static List getListaExistencias(Articulo ar, Integer iidCaracteristica, Almacen al, Float ancho, Float alto) {
        log.info("Se ha entrado a la clase: BaseDatos, método: getListaExistencias");
        List le = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        String query = "From Existencia where articulo.iid = " + ar.getIid() + " and caracteristica.iid = " + iidCaracteristica + " and existencia > 0 and cantidad2 = " + ancho;

        if (alto != null) {
            query += "and cantidad1 >= " + alto;
        }

        if (al != null) {
            query += " and almacen.iid = " + al.getIid();
        }

        try {
            le = session.createQuery(query).list();
        } catch (Exception e) {
            log.error("Se ha producido una excepción en la clase: BaseDatos, método: getListaExistencias");
            le = null;
        }
        return le;
    }

    public static Existencia getExistenciaByIid(Integer iid) {
        Existencia res = null;
        String query = "From Existencia where iid = " + iid;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            List lExistencias = session.createQuery(query).list();
            if (lExistencias.size() >= 1) {
                res = ((Existencia) lExistencias.get(0));
            }
        } catch (Exception e) {
            res = null;
        }
        return res;
    }

    public static Existencia getExistencia(MovimientoAlmacen mva) {
        Existencia res = null;
        log.info("Se ha entrado a la clase: BaseDatos, método: getExistencia");
        String query = sExistencia(mva);
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            List lExistencias = session.createQuery(query).list();
            if (lExistencias.size() >= 1) {
                res = ((Existencia) lExistencias.get(0));
            }
        } catch (Exception e) {
            log.error("Se ha producido una excepciÃ³n en la clase: BaseDatos, mÃ©todo: getExistencia");
            res = null;
        }
        return res;
    }

    private static String sExistencia(MovimientoAlmacen mva) {
        String query = "From Existencia where almacen.iid = " + mva.getAlmacen().getIid()
                + " and articulo.iid = " + mva.getArticulo().getIid()
                + " and empresa.iid = " + mva.getEmpresa().getIid();

        if (mva.getCaracteristica() == null) {
            query += " and caracteristica is null ";
        } else {
            query += " and caracteristica.iid = " + mva.getCaracteristica().getIid();
        }

        if (mva.getCantidad1() != null) {
            query += " and cantidad1 =" + mva.getCantidad1();
        }

        if (mva.getCantidad2() != null) {
            query += " and cantidad2 =" + mva.getCantidad2();
        }

        if (mva.getCantidad3() != null) {
            query += " and cantidad3 =" + mva.getCantidad3();
        }

        if (mva.getCantidad4() != null) {
            query += " and cantidad4 =" + mva.getCantidad4();
        }

        if (mva.getCantidad5() != null) {
            query += " and cantidad5 =" + mva.getCantidad5();
        }

        return query;
    }

    public static Float getExistenciaCaracteristica(Articulo iidArticulo, Integer iidCarac) {
        Float res = null;
        Float totalCar = 0.0F;
        Float totalArt = 0.0F;

        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            List lp = session.createQuery("from Existencia where articulo=" + iidArticulo.getIid() + " and caracteristica=" + iidCarac).list();
            if (lp.size() >= 1) {
                Integer i = null;
                Existencia existen;

                //Unidad medida de artículo (como mostramos en la lista)
                UnidadMedida um = BaseDatos.obtenerUnidadMedidaIid(iidArticulo.getIid_unidad_medida().getIid(), session);
                //Unidad de medida del movimiento
                Magnitud m = BaseDatos.obtenerMagnitud(um.getMagnitud().getCodigo(), session);

                for (i = 0; i < lp.size(); i++) {
                    existen = ((Existencia) lp.get(i));
                    UnidadMedida umM = new UnidadMedida();
                    if (existen.getUnidadMedidaTotal() != null) {
                        umM = BaseDatos.obtenerUnidadMedidaIid(existen.getUnidadMedidaTotal().getIid(), session);
                    } else {
                        umM = um;
                    }
                    //Calculamos la existencia segÃºn el tipo de control y la unidad de medida
                    //Obtenemos la magnitud y realizamos la operación                  

                    if (m.getCodigo().equals("U") || m.getCodigo().equals("u")) {
                        totalCar = existen.getExistencia();
                        totalArt = totalArt + totalCar;
                    } else if (m.getCodigo().equals("L") || m.getCodigo().equals("l")) {
                        //Obtenemos la medida de la cantidad 1
                        UnidadMedida unC1 = BaseDatos.obtenerUnidadMedidaIid(existen.getUnidadMedida1().getIid(), session);
                        totalCar = (existen.getCantidad1() * (unC1.getEquivalencia_unidad_base() / um.getEquivalencia_unidad_base())) * existen.getExistencia();
                        totalArt = totalArt + totalCar;
                    } else if (m.getCodigo().equals("S") || m.getCodigo().equals("s")) {
                        //Obtenemos la medida de la cantidad 1 (Será igual que la 2)
                        totalCar = ((existen.getCantidad1() * existen.getCantidad2()) / 10000) * existen.getExistencia();
                        totalArt = totalArt + totalCar;
                    }
                }
                return totalArt;
            } else {
                return totalArt;
            }
        } catch (Exception e) {
            res = null;
            session.getTransaction().rollback();
        } finally {
            if (session.isOpen() && session.getTransaction().isActive()) {
                session.getTransaction().commit();
            }
        }

        return res;
    }

    /***********
     *PEDIDOS **
	************/
    public static Pedido obtenerPedido(Integer iid) {
        Pedido res = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            List lp = session.createQuery("from Pedido where iid=" + iid).list();
            if (lp.size() >= 1) {
                res = ((Pedido) lp.get(0));
            }
        } catch (Exception e) {
            res = null;
        }
        return res;
    }

    public static List busquedaRapidaPedidoPorNombreComercial(String nombreComercial) {
        List lp = null;
        List lres = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            String consulta = "select p.iid "
                    + "from Pedido p "
                    + "inner join p.proveedor as pr "
                    + "where pr.nombre_comercial like '%" + nombreComercial + "%'";
            lp = session.createQuery(consulta).list();
            if (lp != null) {
                lres = new ArrayList();
                Pedido p;
                for (Iterator it = lp.iterator(); it.hasNext();) {
                    p = BaseDatos.obtenerPedido((Integer) it.next());
                    lres.add(p);
                }
            }
        } catch (Exception e) {
            lres = null;
        }
        return lres;
    }

    public static List getListaPedido(Integer empresaIid) {
        List lp = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lp = session.createQuery("from Pedido where empresa = " + empresaIid).list();
        } catch (Exception e) {
            lp = null;
        }
        return lp;
    }

    public static List busquedaRapidaPedidoPorNombreFiscal(String nombreFiscal) {
        List lp = null;
        List lres = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            String consulta = "select p.iid "
                    + "from Pedido p "
                    + "inner join p.proveedor as pr "
                    + "where pr.nombre_fiscal like '%" + nombreFiscal + "%'";
            lp = session.createQuery(consulta).list();
            if (lp != null) {
                lres = new ArrayList();
                Pedido p;
                for (Iterator it = lp.iterator(); it.hasNext();) {
                    p = BaseDatos.obtenerPedido((Integer) it.next());
                    lres.add(p);
                }
            }
        } catch (Exception e) {
            lres = null;
        }
        return lres;
    }

    public static List busquedaRapidaPedidoPorFecha(String fecha) {
        List lp = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lp = session.createQuery("from Pedido p where fecha like '%" + fecha + "%'").list();
        } catch (Exception e) {
            lp = null;
        }
        return lp;
    }

    public static List busquedaRapidaPedidoPorNumero(String numero) {
        List lp = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lp = session.createQuery("from Pedido p where numero like '%" + numero + "%'").list();
        } catch (Exception e) {
            lp = null;
        } 
        return lp;
    }

    public static Pedido obtenerPedidoPorNumero(String numero) {
        Pedido res = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            List lp = session.createQuery("from Pedido where numero='" + numero + "'").list();
            if (lp.size() >= 1) {
                res = ((Pedido) lp.get(0));
            }
        } catch (Exception e) {
            res = null;
        }
        return res;
    }

    public static List getListaLineaPedido(Integer pedidoIid) {
        List lp = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lp = session.createQuery("from LineaPedido where pedido = " + pedidoIid).list();
        } catch (Exception e) {
            lp = null;
        }
        return lp;
    }

    /*******
     * IVA *
     *******/
    public static List getListaIva() {
        List lIva = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lIva = session.createQuery("from Iva").list();
        } catch (Exception e) {
            lIva = null;
        }
        return lIva;
    }

    public static List busquedaRapidaIva(String tipo) {
        List lIva = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lIva = session.createQuery("from Iva where tipo like '%" + tipo + "%'").list();
        } catch (Exception e) {
            lIva = null;
        }
        return lIva;
    }

    public static Iva obtenerIvaPorTipo(Integer tipo) {
        Iva res = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            List lIva = session.createQuery("from Iva where tipo = " + tipo).list();
            if (lIva.size() >= 1) {
                res = (Iva) lIva.get(0);
            }
        } catch (Exception e) {
            res = null;
        }
        return res;
    }

    public static Iva obtenerIvaPorIid(Integer iid) {
        Iva res = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            List lIva = session.createQuery("from Iva where iid = " + iid).list();
            if (lIva.size() >= 1) {
                res = (Iva) lIva.get(0);
            } else {
                res = null;
            }
        } catch (Exception e) {
            res = null;
        }
        return res;
    }

    public static Iva obtenerIvaPorPorcentaje(String porcentaje) {
        Iva res = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            List lIva = session.createQuery("from Iva where porcentaje = " + porcentaje).list();
            if (lIva.size() >= 1) {
                res = (Iva) lIva.get(0);
            }
        } catch (Exception e) {
            res = null;
        }
        return res;
    }

    /*************
     * Escalados *
     *************/
    public static Escalado obtenerEscalado(Integer codigoArticulo, Integer codigoCaracteristica, Integer iMedida1, Integer iMedida2) {
        Escalado res = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            String caracteristica = "";
            if (codigoCaracteristica != null) {
                caracteristica = " caracteristica.iid = " + codigoCaracteristica;
            } else {
                caracteristica = " caracteristica is null ";
            }
            String consulta = "from Escalado where " + caracteristica + " and articulo.iid = " + codigoArticulo + " and dimension1 = " + iMedida1 + " and dimension2 = " + iMedida2;
            List lres = session.createQuery(consulta).list();

            if (lres.size() >= 1) {
                res = ((Escalado) lres.get(0));
            }
        } catch (Exception e) {
            res = null;
        }
        return res;
    }

    public static List getListaEscalados(Integer codArticulo, Integer codCaracteristica) {
        List lres = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            String caracteristica = "";
            if (codCaracteristica != null) {
                caracteristica = " caracteristica.iid = " + codCaracteristica;
            } else {
                caracteristica = " caracteristica is null ";
            }
            String consulta = "from Escalado where " + caracteristica + " and articulo.iid = " + codArticulo;
            lres = session.createQuery(consulta).list();
        } catch (Exception ex) {
            lres = null;
        }
        return lres;
    }

    public static List getListaEscalados(Integer codArticulo) {
        List lres = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            String consulta = "from Escalado where articulo.iid = " + codArticulo;
            lres = session.createQuery(consulta).list();
        } catch (Exception ex) {
            lres = null;
            session.getTransaction().rollback();
        } finally {
            if (session.isOpen() && session.getTransaction().isActive()) {
                session.getTransaction().commit();
            }
        }
        return lres;
    }

    public static void eliminarEscalados(Integer codigoArticulo) {
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            String consulta = "delete from Escalado where articulo.iid = " + codigoArticulo;
            session.createQuery(consulta).executeUpdate();
        } catch (Exception ex) {
            session.getTransaction().rollback();
        } finally {
            if (session.isOpen() && session.getTransaction().isActive()) {
                session.getTransaction().commit();
            }
        }
    }

    public static void actualizarArticulosCaracteristicas(Integer codigoArticulo, Integer codigoCaracteristica) {
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            String consultaCaracteristicas = "Update Escalado set caracteristica = " + codigoCaracteristica + " where caracteristica is null and articulo.iid = " + codigoArticulo;
            String consultaMovimientos = "Update MovimientoAlmacen set caracteristica = " + codigoCaracteristica + " where caracteristica is null AND articulo.iid = " + codigoArticulo;
            String consultaExistencias = "Update Existencia set caracteristica = " + codigoCaracteristica + " where caracteristica is null AND articulo.iid = " + codigoArticulo;

            session.createQuery(consultaCaracteristicas).executeUpdate();
            session.createQuery(consultaMovimientos).executeUpdate();
            session.createQuery(consultaExistencias).executeUpdate();
        } catch (Exception ex) {
            ex.printStackTrace();
            session.getTransaction().rollback();
        } finally {
            if (session.isOpen() && session.getTransaction().isActive()) {
                session.getTransaction().commit();
            }
        }
    }

    public static boolean eliminarArticulo(Integer codigoArticulo) {
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        boolean res = true;
        try {
            String consultaArticuloDescuento = "delete from ArticuloDescuento where articulo = " + codigoArticulo;
            String consultaPresupuesto = "delete from Presupuesto where iid in (select presupuesto_iid.iid from LineaPresupuesto where articulo_iid.iid = " + codigoArticulo + ")";
            String consultaAgenteArticulo = "delete from AgenteArticulo where iid_articulo.iid = " + codigoArticulo;
            String consultaAgenteArticuloCodigo = "delete from AgenteArticuloCodigo where iid_articulo.iid = " + codigoArticulo;
            String consultaLineaPresupuesto = "delete from LineaPresupuesto where articulo_iid.iid = " + codigoArticulo;
            String consultaMovimientoAlmacen = "delete from MovimientoAlmacen where articulo.iid = " + codigoArticulo;
            String consultaExistencia = "delete from Existencia where articulo.iid = " + codigoArticulo;
            String consultaEscalado = "delete from Escalado where articulo.iid = " + codigoArticulo;
            String consultaCaracteristica = "delete from Caracteristica where iid_articulo.iid = " + codigoArticulo;
            String consultaArticulo = "delete from Articulo where iid = " + codigoArticulo;

            session.createQuery(consultaArticuloDescuento).executeUpdate();
            session.createQuery(consultaAgenteArticulo).executeUpdate();
            session.createQuery(consultaAgenteArticuloCodigo).executeUpdate();
            session.createQuery(consultaLineaPresupuesto).executeUpdate();
            session.createQuery(consultaMovimientoAlmacen).executeUpdate();
            session.createQuery(consultaPresupuesto).executeUpdate();
            session.createQuery(consultaExistencia).executeUpdate();
            session.createQuery(consultaEscalado).executeUpdate();
            session.createQuery(consultaCaracteristica).executeUpdate();
            session.createQuery(consultaArticulo).executeUpdate();
        } catch (Exception ex) {
            session.getTransaction().rollback();
            res = false;
        } finally {
            if (session.isOpen() && session.getTransaction().isActive()) {
                session.getTransaction().commit();
            }
        }
        return res;
    }

    public static List getRegistroAcciones(String u, String a, String f1, String f2, String em) {
        List lRegistro = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            String consulta = "from Auditoria where empresa = '" + em + "'";
            if (u != null && !u.equals("") && !u.equals(Constantes.VACIO)) {
                consulta += " and usuario = '" + u + "'";
            }
            if (a != null && !a.equals("") && !a.equals(Constantes.VACIO)) {
                consulta += " and accion = '" + a + "'";
            }
            if (f1 != null && !f1.equals("")) {
                consulta += " and str_to_date(fecha, '%d/%m/%Y') >= str_to_date('" + f1 + "', '%d/%m/%Y')";
            }
            if (f2 != null && !f2.equals("")) {
                consulta += " and str_to_date(fecha, '%d/%m/%Y') <= str_to_date('" + f2 + "', '%d/%m/%Y')";
            }

            lRegistro = (List) session.createQuery(consulta).list();
        } catch (Exception e) {
            lRegistro = null;
        }
        return lRegistro;
    }

    public static List getRecuperarAcciones() {
        List lmovimientos = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lmovimientos = (List) session.createQuery("Select Distinct(accion) from Auditoria").list();
        } catch (Exception e) {
            lmovimientos = null;
        }
        return lmovimientos;
    }

    /*********************************
     * Métodos de la clase Comercial *
	 *********************************/
    public static List getListaComerciales() {
        List lcomerciales = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lcomerciales = (List) session.createQuery("from Comercial").list();
        } catch (Exception e) {
            lcomerciales = null;
        }
        return lcomerciales;
    }

    public static Comercial obtenerComercialPorCodigo(String codigo) {
        Comercial res = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            List lComercial = session.createQuery("from Comercial where codigo like '%" + codigo + "%'").list();
            if (lComercial.size() >= 1) {
                res = (Comercial) lComercial.get(0);
            }
        } catch (Exception e) {
            res = null;
        }
        return res;
    }

    public static Comercial obtenerComercialPorNombre(String nombre) {
        Comercial res = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            List lComercial = session.createQuery("from Comercial where nombre like '%" + nombre + "%'").list();
            if (lComercial.size() >= 1) {
                res = (Comercial) lComercial.get(0);
            } 
        } catch (Exception e) {
            res = null;
        }
        return res;
    }

    public static Comercial obtenerComercialPorIid(Integer iid) {
        Comercial res = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            List lComercial = session.createQuery("from Comercial where iid = " + iid).list();
            if (lComercial.size() >= 1) {
                res = (Comercial) lComercial.get(0);
            }
        } catch (Exception e) {
            res = null;
        }
        return res;
    }

    public static List busquedaRapidaComercialPorCodigo(String codigo) {
        List lComerciales = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lComerciales = session.createQuery("from Comercial where codigo like '%" + codigo + "%'").list();
        } catch (Exception e) {
            lComerciales = null;
        }
        return lComerciales;
    }

    public static List busquedaRapidaComercialPorNombre(String nombre) {
        List lComerciales = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lComerciales = session.createQuery("from Comercial where nombre like '%" + nombre + "%'").list();
        } catch (Exception e) {
            lComerciales = null;
        }
        return lComerciales;
    }

    public static List busquedaRapidaComercialPorTelefono(String tlf) {
        List lComerciales = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lComerciales = session.createQuery("from Comercial where (telefono like '%" + tlf + "%' or telefono2 like '%" + tlf + "%')").list();
        } catch (Exception e) {
            lComerciales = null;
        }
        return lComerciales;
    }

    public static List getListaPresupuestoPorComercial(Integer comercial, Integer idEmpresa) {
        List lp = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lp = session.createQuery("from Presupuesto where comercial = " + comercial + " and empresa=" + idEmpresa).list();
        } catch (Exception e) {
            lp = null;
        }
        return lp;
    }

    public static List busquedaRapidaMontaje(String montador, String fecha, Boolean montado, Empresa empresa) {
        List lm = null;
        String em;
        Usuario u = BaseDatos.obtenerUsuarioNombre(montador);
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();

        if (montado) {
            em = "'N' or montado = 'S'";
        } else {
            em = "'N'";
        }

        try {
            if (!montador.equals("Todos")) {
                lm = session.createQuery("from Montaje where iidEmpresa = " + empresa.getIid() + " and montador = '" + u.getNombre() + "' and fechaEntrega like '%" + fecha + "%' and ( montado = " + em + " ) order by fechaEntrega").list();
            } else {
                lm = session.createQuery("from Montaje where iidEmpresa = " + empresa.getIid() + " and fechaEntrega like '%" + fecha + "%' and ( montado = " + em + " ) order by fechaEntrega").list();
            }
        } catch (Exception e) {
            lm = null;
        }
        return lm;
    }

    public static boolean documentoActualizarPagoComercial(String numeroDocumento, boolean pagadoComercial) {
        boolean res = true;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            String update = "Update Presupuesto set pagadoComercial = " + pagadoComercial + " where numero like '" + numeroDocumento + "'";
            session.createQuery(update).executeUpdate();
        } catch (Exception e) {
            res = false;
            session.getTransaction().rollback();
        } finally {
            try {
                if (session.isOpen() && session.getTransaction().isActive()) {
                    session.getTransaction().commit();
                }
            } catch (Exception ex) {
                res = false;
                session.getTransaction().rollback();
            }
            return res;
        }
    }

    public static List getListaPresupuestoByCifAgente(String cifAgente) {
        List lp = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lp = session.createQuery("from Presupuesto where cifCliente =" + cifAgente).list();
        } catch (Exception e) {
            lp = null;
        }
        return lp;
    }

    public static Caracteristica obtenerCaracteristicaPorIid(Integer iid) {
        Caracteristica res = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            List lCaracteristica = session.createQuery("from Caracteristica where iid = " + iid).list();
            if (lCaracteristica.size() >= 1) {
                res = (Caracteristica) lCaracteristica.get(0);
            }
        } catch (Exception e) {
            res = null;
        }
        return res;
    }

    /***************
     ** TipoToldo ** 
	 ***************/
    public static List getListaTipoToldo() {
        List ltt = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            ltt = session.createQuery("from TipoToldo").list();
        } catch (Exception e) {
            ltt = null;
        }
        return ltt;
    }

    public static TipoToldo obtenerTipoToldoPorCodigo(String codigo) {
        TipoToldo res = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            List ltt = session.createQuery("from TipoToldo where codigo = '" + codigo + "'").list();
            if (ltt.size() >= 1) {
                res = (TipoToldo) ltt.get(0);
            }
        } catch (Exception e) {
            res = null;
        }
        return res;
    }

    public static TipoToldo obtenerTipoToldoPorIid(Integer iid) {
        TipoToldo res = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            List ltt = session.createQuery("from TipoToldo where iid = " + iid).list();
            if (ltt.size() >= 1) {
                res = (TipoToldo) ltt.get(0);
            }
        } catch (Exception e) {
            res = null;
        }
        return res;
    }

    public static List busquedaRapidaTipoToldo(String codigo) {
        List lTipoToldo = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lTipoToldo = session.createQuery("from TipoToldo where codigo like '%" + codigo + "%'").list();
        } catch (Exception e) {
            lTipoToldo = null;
        }
        return lTipoToldo;
    }

    /**************************
     *** ArticuloDescuento ****
	 **************************/
    public static List getListaArticuloDescuento() {
        List lad = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lad = session.createQuery("from ArticuloDescuento").list();
        } catch (Exception e) {
            lad = null;
        }
        return lad;
    }

    public static List getListaArticuloDescuentoPorArticulo(Integer iidArticulo) {
        List lad = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lad = session.createQuery("from ArticuloDescuento where articulo = " + iidArticulo).list();
        } catch (Exception e) {
            lad = null;
        }
        return lad;
    }

    public static ArticuloDescuento obtenerArticuloDescuentoPorIid(Integer iid) {
        ArticuloDescuento res = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            List lad = session.createQuery("from ArticuloDescuento where iid = " + iid).list();
            if (lad.size() >= 1) {
                res = (ArticuloDescuento) lad.get(0);
            }
        } catch (Exception e) {
            res = null;
        }
        return res;
    }

    /******************
     *** Variables ****
	 ******************/
    public static List getListaVariables(Integer iidDac) {
        List lv = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lv = session.createQuery("from Variable where dac = " + iidDac + " order by iid").list();
        } catch (Exception e) {
            lv = null;
        }
        return lv;
    }

    public static Variable ObtenerVariableByDacByNombre(Integer iidDac, String nombre) {
        List lv = null;
        Variable v = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lv = session.createQuery("from Variable where dac = " + iidDac + " and nombre = '" + nombre + "'").list();
            if (lv != null && lv.size() > 0) {
                v = (Variable) lv.get(0);
            }
        } catch (Exception e) {
            v = null;
        }
        return v;
    }

    public static Variable obtenerVariableById(Integer iid) {
        Variable res = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            List<Variable> lv = session.createQuery("from Variable where iid =" + iid).list();
            if (lv != null && lv.size() > 0) {
                res = lv.get(0);
            }
        } catch (Exception e) {
            res = null;
        }
        return res;
    }

    /************
     **** DAC ***
	 ************/
    public static List getListaDac(Integer iidEmpresa) {
        List ld = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            ld = session.createQuery("from Dac where articulo.iid_empresa = " + iidEmpresa + " order by articulo.cod_articulo").list();
        } catch (Exception e) {
            ld = null;
        }
        return ld;
    }

    public static Dac obtenerDacById(Integer iid) {
        List ld = null;
        Dac res = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            ld = session.createQuery("from Dac where iid = " + iid).list();
            if (ld != null && ld.size() > 0) {
                res = (Dac) ld.get(0);
            }
        } catch (Exception e) {
            res = null;
        }
        return res;
    }

    public static boolean eliminarDac(Integer iidDac) {
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        boolean res = true;
        try {

            List listaTemp, listaTemp2;
            Iterator iter, iter2;
            Object o, o2;
            Variable v;
            Seleccion s;
            Despiece d;

            listaTemp = session.createQuery("from Variable where dac.iid = " + iidDac).list();
            iter = listaTemp.iterator();
            while (iter.hasNext()) {
                v = (Variable) iter.next();

                listaTemp2 = session.createQuery("from Seleccion where variable.iid = " + v.getIid()).list();
                iter2 = listaTemp2.iterator();
                while (iter2.hasNext()) {
                    s = (Seleccion) iter2.next();
                    o2 = session.load(Seleccion.class, s.getIid());
                    session.delete(o2);
                }

                o = session.load(Variable.class, v.getIid());
                session.delete(o);
            }

            listaTemp = session.createQuery("from Despiece where dac.iid = " + iidDac).list();
            iter = listaTemp.iterator();
            while (iter.hasNext()) {
                d = (Despiece) iter.next();
                o = session.load(Despiece.class, d.getIid());
                session.delete(o);
            }

            o = session.load(Dac.class, iidDac);
            session.delete(o);

        } catch (Exception ex) {
            ex.printStackTrace();
            session.getTransaction().rollback();
            res = false;
        } finally {
            if (session.isOpen() && session.getTransaction().isActive()) {
                session.getTransaction().commit();
            }
        }
        return res;
    }

    public static List busquedaRapidaDacPorCodigo(String codigoArticulo) {
        List ld = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            ld = session.createQuery("From Dac where articulo.cod_articulo like '%" + codigoArticulo + "%' order by articulo.cod_articulo").list();
        } catch (Exception e) {
            ld = null;
        }
        return ld;
    }

    public static Dac obtenerDacPorCodigoArticulo(String codigoArticulo, Integer iidEmpresa) {
        Dac res = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            String query = "From Dac where articulo.cod_articulo like '%" + codigoArticulo + "%' and articulo.iid_empresa = " + iidEmpresa;
            List listaDac = session.createQuery(query).list();
            if (listaDac != null && listaDac.size() > 0) {
                res = (Dac) listaDac.get(0);
            }

        } catch (Exception e) {
            res = null;
        }
        return res;
    }

    public static boolean insertarDAC(Dac dac, List<Variable> listaVariables, List<Seleccion> listaSeleccion, List<Despiece> listaDespiece) {
        boolean res = true;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            //Guardamos el artículo
            Integer idArticulo = (Integer) session.save(dac);
            dac.setIid(idArticulo);

            //Guardamos las variables
            HashMap<String, Variable> mapVar = new HashMap<String, Variable>();
            Iterator varIterator = listaVariables.iterator();
            Variable var;
            Integer iidVar;
            while (varIterator.hasNext()) {
                var = (Variable) varIterator.next();
                var.setDac(dac);
                iidVar = (Integer) session.save(var);
                var.setIid(iidVar);
                mapVar.put(var.getNombre(), var);
            }


            //Se guardan las vbles de selección
            Iterator selIterator = listaSeleccion.iterator();
            Seleccion sel;
            while (selIterator.hasNext()) {
                sel = (Seleccion) selIterator.next();
                var = (sel.getVariable());
                var = mapVar.get(var.getNombre());
                sel.setVariable(var);
                session.save(sel);
            }

            //Se guardan los despieces
            Iterator despIterator = listaDespiece.iterator();
            Despiece des;
            while (despIterator.hasNext()) {
                des = (Despiece) despIterator.next();
                des.setDac(dac);
                session.save(des);
            }

        } catch (Exception e) {
            res = false;
            session.getTransaction().rollback();
        } finally {
            try {
                if (session.isOpen() && session.getTransaction().isActive()) {
                    session.getTransaction().commit();
                }
            } catch (Exception ex) {
                res = false;
                session.getTransaction().rollback();
            }
            return res;
        }
    }

    public static boolean modificarDAC(Dac dac, List listaVariables, List listaSeleccion, List listaDespiece) {
        boolean res = true;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {

            String sVariables = "";
            String sSeleccion = "";
            String sDespiece = "";

            //Guardamos el artículo
            session.update(dac);

            //Guardamos las variables
            HashMap<String, Variable> mapVar = new HashMap<String, Variable>();
            Iterator varIterator = listaVariables.iterator();
            Variable var;
            Integer idVariable;
            while (varIterator.hasNext()) {
                var = (Variable) varIterator.next();
                var.setDac(dac);
                if (var.getIid() == null) {
                    idVariable = (Integer) session.save(var);
                    var.setIid(idVariable);
                } else {
                    session.update(var);
                }
                mapVar.put(var.getNombre(), var);
                sVariables += var.getIid() + ",";
            }

            Iterator selIterator = listaSeleccion.iterator();
            Seleccion sel;
            Integer idSeleccion;
            while (selIterator.hasNext()) {
                sel = (Seleccion) selIterator.next();
                var = (sel.getVariable());
                var = mapVar.get(var.getNombre());
                sel.setVariable(var);
                if (sel.getIid() == null) {
                    idSeleccion = (Integer) session.save(sel);
                    sel.setIid(idSeleccion);
                } else {
                    session.update(sel);
                }
                sSeleccion += sel.getIid() + ",";
            }

            Iterator despIterator = listaDespiece.iterator();
            Despiece desp;
            Integer idDespiece;
            while (despIterator.hasNext()) {
                desp = (Despiece) despIterator.next();
                desp.setDac(dac);
                if (desp.getIid() == null) {
                    idDespiece = (Integer) session.save(desp);
                    desp.setIid(idDespiece);
                } else {
                    session.update(desp);
                }
                sDespiece += desp.getIid() + ",";
            }

            String despieceIn = "";
            if (!sDespiece.equals("") && sDespiece.length() > 0) {
                despieceIn = sDespiece.substring(0, sDespiece.length() - 1);
            }

            String deleteDespiece;
            if (!despieceIn.equals("")) {
                deleteDespiece = "delete from Despiece where dac = " + dac.getIid() + " and iid not in (" + despieceIn + ")";
                session.createQuery(deleteDespiece).executeUpdate();
            }

            String seleccionIn = "";
            if (!sSeleccion.equals("") && sSeleccion.length() > 0) {
                seleccionIn = sSeleccion.substring(0, sSeleccion.length() - 1);
            }

            String variablesIn = "";
            if (!sVariables.equals("") && sVariables.length() > 0) {
                variablesIn = sVariables.substring(0, sVariables.length() - 1);
            }

            String deleteSeleccion = "";
            if (!seleccionIn.equals("")) {
                deleteSeleccion = "delete from Seleccion where variable in (" + variablesIn + ") and  iid not in (" + seleccionIn + ")";
                session.createQuery(deleteSeleccion).executeUpdate();
            }

            String deleteVariables;
            if (!variablesIn.equals("")) {
                deleteVariables = "delete from Variable where dac = " + dac.getIid() + " and iid not in (" + variablesIn + ")";
                session.createQuery(deleteVariables).executeUpdate();
            }

        } catch (Exception e) {
            res = false;
            e.printStackTrace();
            session.getTransaction().rollback();
        } finally {
            try {
                if (session.isOpen() && session.getTransaction().isActive()) {
                    session.getTransaction().commit();
                }
            } catch (Exception ex) {
                res = false;
                session.getTransaction().rollback();
            }
            return res;
        }
    }

    /***************
	 ** Seleccion **
     ***************/
    public static List getListaSeleccion(Integer iidDac) {
        List lv = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lv = session.createQuery("from Seleccion where variable.dac = " + iidDac).list();
        } catch (Exception e) {
            lv = null;
        }
        return lv;
    }

    public static List getListaSeleccionByIdVariable(Integer iidVble) {
        List lv = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lv = session.createQuery("from Seleccion where variable.iid = " + iidVble + " order by iid").list();
        } catch (Exception e) {
            lv = null;
        }
        return lv;
    }

    /*************
     ** Despice **
     *************/
    public static List getListaDespiece(Integer iidDac) {
        List lv = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lv = session.createQuery("from Despiece where dac = " + iidDac + " order by orden").list();
        } catch (Exception e) {
            lv = null;
        }
        return lv;
    }

    /***************
     ** Contactos **
     ***************/
    public static List getContactoAgente(Agentes iidAgente) {
        List lres = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lres = session.createQuery("from Contactos where iid_agente=" + iidAgente.getIid()).list();
            if (lres == null) {
                lres = new ArrayList<Contactos>();
            }
        } catch (Exception e) {
            lres = null;
        }
        return lres;
    }

    public static List getContactoAgenteReducido(Integer iidAgente) {
        List lres = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lres = session.createQuery("select nombre, apellidos, cargo, departamento, email, telefono, movil from Contactos where iid_agente=" + iidAgente).list();
            if (lres == null) {
                lres = new ArrayList();
            }
        } catch (Exception e) {
            lres = null;
        }
        return lres;
    }

    public static Contactos getContactoIid(Integer iid) {
        Contactos c = new Contactos();
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            List lp = (List) session.createQuery("from Contactos where iid=" + iid).list();
            if (lp.size() >= 1) {
                c = (Contactos) lp.get(0);
            }
        } catch (Exception e) {
            c = null;
        }
        return c;
    }

    public static boolean insertarAgente(Agentes a, List<Contactos> lcon, List<DescuentoClienteArticulo> listaDescuentoClienteArticulos, List<DescuentoClienteFamiliaVenta> listaDescuentoClientesFamiliaVentas,List<FormulaArticuloProv> listaFormulaArticulo, List<FormulaFamiliaProv> listaFormulaFamilia) {
        boolean res = true;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {

            //Guardamos el agente
            Integer idAgente = (Integer) session.save(a);
            a.setIid(idAgente);

            //Guardamos los contactos
            Iterator conIterator = lcon.iterator();
            Contactos con;

            while (conIterator.hasNext()) {
                con = (Contactos) conIterator.next();
                con.setIid_agente(a);
                session.save(con);
            }

            if (listaDescuentoClienteArticulos != null) {
                DescuentoClienteArticulo dtoArticuloTemp;
                Iterator iterDtoArticulo = listaDescuentoClienteArticulos.iterator();
                while (iterDtoArticulo.hasNext()) {
                    dtoArticuloTemp = (DescuentoClienteArticulo) iterDtoArticulo.next();
                    dtoArticuloTemp.setCliente(a);
                    session.save(dtoArticuloTemp);
                }
            }
            
            if (listaFormulaArticulo != null) {
                FormulaArticuloProv forArticuloTemp;
                Iterator iterForArticulo = listaFormulaArticulo.iterator();
                while (iterForArticulo.hasNext()) {
                    forArticuloTemp = (FormulaArticuloProv) iterForArticulo.next();
                    forArticuloTemp.setIidProveedor(a.getIid());
                    session.save(forArticuloTemp);
                }
            }            

            if (listaDescuentoClientesFamiliaVentas != null) {
                DescuentoClienteFamiliaVenta dtoFamiliaTemp;
                Iterator iterDtoFamilia = listaDescuentoClientesFamiliaVentas.iterator();
                while (iterDtoFamilia.hasNext()) {
                    dtoFamiliaTemp = (DescuentoClienteFamiliaVenta) iterDtoFamilia.next();
                    dtoFamiliaTemp.setCliente(a);
                    session.save(dtoFamiliaTemp);
                }
            }
            
            if (listaFormulaFamilia != null) {
                FormulaFamiliaProv forFamiliaTemp;
                Iterator iterForFamilia = listaFormulaFamilia.iterator();
                while (iterForFamilia.hasNext()) {
                    forFamiliaTemp = (FormulaFamiliaProv) iterForFamilia.next();
                    forFamiliaTemp.setIidProveedor(a.getIid());
                    session.save(forFamiliaTemp);
                }
            }            

        } catch (Exception e) {
            res = false;
            session.getTransaction().rollback();
        } finally {
            try {
                if (session.isOpen() && session.getTransaction().isActive()) {
                    session.getTransaction().commit();
                }
            } catch (Exception ex) {
                res = false;
                session.getTransaction().rollback();
            }
            return res;
        }
    }

    public static boolean modificarAgente(Agentes a, List<Contactos> lcon, List<DescuentoClienteArticulo> listaDescuentoClienteArticulos, List<DescuentoClienteFamiliaVenta> listaDescuentoClientesFamiliaVentas,List<FormulaArticuloProv> listaFormulaArticulo,List<FormulaFamiliaProv> listaFormulaFamilia){
        boolean res = true;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            //Guardamos el agente
            session.update(a);

            String sContactos = "";
            String sDtoArticulo = "";
            String sDtoFamilia = "";
            String sForArticulo = "";
            String sForFamilia = "";
            Iterator iter;

            if (lcon != null && lcon.size() > 0) {
                iter = lcon.iterator();
                Contactos con;
                Integer idContacto;
                while (iter.hasNext()) {
                    con = (Contactos) iter.next();
                    con.setIid_agente(a);
                    if (con.getIid() == null) {
                        idContacto = (Integer) session.save(con);
                        con.setIid(idContacto);
                    } else {
                        session.update(con);
                    }
                    sContactos += con.getIid() + ",";
                }
            }

            if (listaDescuentoClienteArticulos != null && listaDescuentoClienteArticulos.size() > 0) {
                iter = listaDescuentoClienteArticulos.iterator();
                DescuentoClienteArticulo dca;
                Integer idDtoArticulo;
                while (iter.hasNext()) {
                    dca = (DescuentoClienteArticulo) iter.next();
                    dca.setCliente(a);
                    if (dca.getIid() == null) {
                        idDtoArticulo = (Integer) session.save(dca);
                        dca.setIid(idDtoArticulo);
                    } else {
                        session.update(dca);
                    }
                    sDtoArticulo += dca.getIid() + ",";
                }
            }
            
            if (listaFormulaArticulo != null && listaFormulaArticulo.size() > 0) {
                iter = listaFormulaArticulo.iterator();
                FormulaArticuloProv dca;
                Integer idForArticulo;
                while (iter.hasNext()) {
                    dca = (FormulaArticuloProv) iter.next();
                    dca.setIidProveedor(a.getIid());

                    if (dca.getIid() == null) {
                        idForArticulo = (Integer) session.save(dca);
                        dca.setIid(idForArticulo);
                    } else {
                        session.update(dca);
                    }
                    sForArticulo += dca.getIid() + ",";
                }
            }

            if (listaDescuentoClientesFamiliaVentas != null && listaDescuentoClientesFamiliaVentas.size() > 0) {
                iter = listaDescuentoClientesFamiliaVentas.iterator();
                DescuentoClienteFamiliaVenta dcfv;
                Integer idDtoFamilia;
                while (iter.hasNext()) {
                    dcfv = (DescuentoClienteFamiliaVenta) iter.next();
                    dcfv.setCliente(a);
                    if (dcfv.getIid() == null) {
                        idDtoFamilia = (Integer) session.save(dcfv);
                        dcfv.setIid(idDtoFamilia);
                    } else {
                        session.update(dcfv);
                    }
                    sDtoFamilia += dcfv.getIid() + ",";
                }
            }
            
             if (listaFormulaFamilia != null && listaFormulaFamilia.size() > 0) {
                iter = listaFormulaFamilia.iterator();
                FormulaFamiliaProv dca;
                Integer idForFamilia;
                while (iter.hasNext()) {
                    dca = (FormulaFamiliaProv) iter.next();
                    dca.setIidProveedor(a.getIid());
                    if (dca.getIid() == null) {
                        idForFamilia = (Integer) session.save(dca);
                        dca.setIid(idForFamilia);
                    } else {
                        session.update(dca);
                    }
                    sForFamilia += dca.getIid() + ",";
                }
            }

            String sContactosIn = "";
            String sDtoArticulosIn = "";
            String sDtoFamiliasIn = "";
            String sForFamiliaIn = "";
            String sForArticuloIn = "";

            if (!sContactos.equals("") && sContactos.length() > 0) {
                sContactosIn = sContactos.substring(0, sContactos.length() - 1);
            }

            if (!sDtoArticulo.equals("") && sDtoArticulo.length() > 0) {
                sDtoArticulosIn = sDtoArticulo.substring(0, sDtoArticulo.length() - 1);
            }

            if (!sDtoFamilia.equals("") && sDtoFamilia.length() > 0) {
                sDtoFamiliasIn = sDtoFamilia.substring(0, sDtoFamilia.length() - 1);
            }
            
            
            if (!sForFamilia.equals("") && sForFamilia.length() > 0) {
                sForFamiliaIn = sForFamilia.substring(0, sForFamilia.length() - 1);
            }
            
            if (!sForArticulo.equals("") && sForArticulo.length() > 0) {
                sForArticuloIn = sForArticulo.substring(0, sForArticulo.length() - 1);
            }
            
            String deleteContactos;
            if (!sContactosIn.equals("")) {
                deleteContactos = "delete from Contactos where iid not in (" + sContactosIn + ") and iid_agente = " + a.getIid();
                session.createQuery(deleteContactos).executeUpdate();
            } else if (lcon.size() < 1) {
                deleteContactos = "delete from Contactos where iid_agente = " + a.getIid();
                session.createQuery(deleteContactos).executeUpdate();
            }

            String deleteDtoArticulos = "";
            if (!sDtoArticulosIn.equals("")) {
                deleteDtoArticulos = "delete from DescuentoClienteArticulo where iid not in (" + sDtoArticulosIn + ") and cliente = " + a.getIid();
                session.createQuery(deleteDtoArticulos).executeUpdate();
            } else if (listaDescuentoClienteArticulos.size() < 1) {
                deleteDtoArticulos = "delete from DescuentoClienteArticulo where cliente = " + a.getIid();
                session.createQuery(deleteDtoArticulos).executeUpdate();
            }

            String deleteDtoFamilia = "";
            if (!sDtoFamiliasIn.equals("")) {
                deleteDtoFamilia = "delete from DescuentoClienteFamiliaVenta where iid not in (" + sDtoFamiliasIn + ") and cliente = " + a.getIid();
                session.createQuery(deleteDtoFamilia).executeUpdate();
            } else if (listaDescuentoClientesFamiliaVentas.size() < 1) {
                deleteDtoFamilia = "delete from DescuentoClienteFamiliaVenta where cliente = " + a.getIid();
                session.createQuery(deleteDtoFamilia).executeUpdate();
            }
            
            String deleteForArticulo = "";
            if (!sForArticuloIn.equals("")) {
                deleteForArticulo = "delete from FormulaArticuloProv where iid not in (" + sForArticuloIn + ") and iidProveedor = " + a.getIid();
                session.createQuery(deleteForArticulo).executeUpdate();
            } else if (listaFormulaArticulo.size() < 1) {
                deleteForArticulo = "delete from FormulaArticuloProv where iidProveedor = " + a.getIid();
                session.createQuery(deleteForArticulo).executeUpdate();
            }
            
            String deleteForFamilia = "";
            if (!sForFamiliaIn.equals("")) {
                deleteForFamilia = "delete from FormulaFamiliaProv where iid not in (" + sForFamiliaIn + ") and iidProveedor = " + a.getIid();
                session.createQuery(deleteForFamilia).executeUpdate();
            } else if (listaFormulaFamilia.size() < 1) {
                deleteForFamilia = "delete from FormulaFamiliaProv where iidProveedor = " + a.getIid();
                session.createQuery(deleteForFamilia).executeUpdate();
            }
        } catch (Exception e) {
            res = false;
            session.getTransaction().rollback();
            session.update(a);
        } finally {
            try {
                if (session.isOpen() && session.getTransaction().isActive()) {
                    session.getTransaction().commit();
                }
            } catch (Exception ex) {
                res = false;
                session.getTransaction().rollback();
            }
            return res;
        }
    }

    /*****************************
     ** DescuentoClienteArticulo *
     *****************************/
    public static List obtenerDescuentosClienteArticulos(Integer idAgente) {
        List lres = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lres = session.createQuery("from DescuentoClienteArticulo where cliente.iid = " + idAgente).list();
            if (lres == null) {
                lres = new ArrayList();
            }
        } catch (Exception ex) {
            lres = null;
        }
        return lres;
    }
    
    
    public static List obtenerFormulaProvArticulo(Integer idAgente) {
        List lres = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lres = session.createQuery("from FormulaArticuloProv where iidProveedor = " + idAgente).list();
            if (lres == null) {
                lres = new ArrayList();
            }
        } catch (Exception ex) {
            lres = null;
        }
        return lres;
    }
    
    
    public static List obtenerFormulaProvFamilia(Integer idAgente) {
        List lres = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            String consulta = "from FormulaFamiliaProv where iidProveedor = " + idAgente;
            lres = session.createQuery(consulta).list();
            if (lres == null) {
                lres = new ArrayList();
            }
        } catch (Exception ex) {
            lres = null;
        }
        return lres;
    }
    
    public static FormulaArticuloProv obtenerFormulaProvArticulo(Integer idAgente, Integer iidArticulo) {
        FormulaArticuloProv res = null;
        List lista = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            String consulta = "from FormulaArticuloProv where iidProveedor = " + idAgente + " and iidArticulo = " + iidArticulo;
            lista = session.createQuery(consulta).list();
            if (lista != null && lista.size() > 0) {
                res = (FormulaArticuloProv) lista.get(0);
            }
        } catch (Exception ex) {
            res = null;
        }
        return res;
    }
    
    public static FormulaFamiliaProv obtenerFormulaProvFamilia(Integer idAgente, Integer iidFamilia) {
        FormulaFamiliaProv res = null;
        List lista = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            String consulta = "from FormulaFamiliaProv where iidProveedor = " + idAgente + " and iidFamilia = " + iidFamilia;
            lista = session.createQuery(consulta).list();
            if (lista != null && lista.size() > 0) {
                res = (FormulaFamiliaProv) lista.get(0);
            }
        } catch (Exception ex) {
            res = null;
        }
        return res;
    }   
    

    public static DescuentoClienteArticulo obtenerDescuentoClienteArticulo(Integer idAgente, Integer iidArticulo) {
        DescuentoClienteArticulo res = null;
        List lista = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            String consulta = "from DescuentoClienteArticulo where cliente.iid = " + idAgente + " and articulo.iid = " + iidArticulo;
            lista = session.createQuery(consulta).list();
            if (lista != null && lista.size() > 0) {
                res = (DescuentoClienteArticulo) lista.get(0);
            }
        } catch (Exception ex) {
            res = null;
        }
        return res;
    }

    /*********************************
     * DescuentoClienteFamiliaVenta **
     *********************************/
    public static List obtenerDescuentosClienteFamiliaVenta(Integer idCliente) {
        List lres = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lres = session.createQuery("from DescuentoClienteFamiliaVenta where cliente.iid = " + idCliente).list();
            if (lres == null) {
                lres = new ArrayList();
            }
        } catch (Exception ex) {
            lres = null;
        }
        return lres;
    }

    public static DescuentoClienteFamiliaVenta obtenerDescuentoClienteFamiliaVenta(Integer idAgente, Integer iidFamilia) {
        DescuentoClienteFamiliaVenta res = null;
        List lista = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            String consulta = "from DescuentoClienteFamiliaVenta where cliente.iid = " + idAgente + " and familiaVenta.iid = " + iidFamilia;
            lista = session.createQuery(consulta).list();
            if (lista != null && lista.size() > 0) {
                res = (DescuentoClienteFamiliaVenta) lista.get(0);
            }
        } catch (Exception ex) {
            res = null;
        }
        return res;
    }

    /************************
     * SeleccionPresupuesto *
     ************************/
    public static List getListaSeleccionPresupuestoByDacPresupuesto(Integer iidDacPresupuesto) {
        List lista = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lista = session.createQuery("from SeleccionPresupuesto where dacPresupuesto.iid = " + iidDacPresupuesto).list();
        } catch (Exception e) {
            lista = null;
        }
        return lista;
    }

    public static List getListaSeleccionPresupuestoByVariablePresupuesto(Integer iidVariablePresupuesto) {
        List lista = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lista = session.createQuery("from SeleccionPresupuesto where variablePresupuesto.iid = " + iidVariablePresupuesto).list();
        } catch (Exception e) {
            lista = null;
        }
        return lista;
    }

    /***********************
     * VariablePresupuesto *
     ***********************/
    public static List getListaVariablePresupuestoByDacPresupuesto(Integer iidDacPresupuesto) {
        List lista = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lista = session.createQuery("from VariablePresupuesto where dacPresupuesto.iid = " + iidDacPresupuesto).list();
        } catch (Exception e) {
            lista = null;
        }
        return lista;
    }

    public static VariablePresupuesto obtenerVariablePresupuestoById(Integer id) {
        VariablePresupuesto res = null;
        List lista = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            String consulta = "from VariablePresupuesto where iid = " + id;
            lista = session.createQuery(consulta).list();
            if (lista != null && lista.size() > 0) {
                res = (VariablePresupuesto) lista.get(0);
            }
        } catch (Exception ex) {
            res = null;
        } 
        return res;
    }

    /***********************
     * DespiecePresupuesto *
     ***********************/
    public static List getListaDespiecePresupuestoByDacPresupuesto(Integer iidDacPresupuesto) {
        List lista = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lista = session.createQuery("from DespiecePresupuesto where dacPresupuesto.iid = " + iidDacPresupuesto).list();
        } catch (Exception e) {
            lista = null;
        }
        return lista;
    }

    /******************
     * DacPresupuesto *
     ******************/
    public static List getlistaDacPresupuesto(Integer iidPresupuesto) {
        List lista = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lista = session.createQuery("from DacPresupuesto where presupuesto.iid = " + iidPresupuesto).list();
        } catch (Exception e) {
            lista = null;
        }
        return lista;
    }

    public static DacPresupuesto obtenerDacPresupuestoById(Integer id) {
        DacPresupuesto res = null;
        List lista = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lista = session.createQuery("from DacPresupuesto where iid = " + id).list();
            if (lista != null && lista.size() > 0) {
                res = (DacPresupuesto) lista.get(0);
            }
        } catch (Exception ex) {
            res = null;
        }
        return res;
    }

    /***************
     ** Historico **
     ***************/
    public static boolean eliminarPresupuestoHistorico(Integer iid) {
        boolean res = true;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            List listaLp = session.createQuery("from LineaPresupuestoHistorico where historico = " + iid).list();
            Iterator it = listaLp.iterator();
            LineaPresupuestoHistorico lp;
            Object o;
            Object o2;

            while (it.hasNext()) {
                lp = (LineaPresupuestoHistorico) it.next();
                o = session.load(LineaPresupuestoHistorico.class, lp.getIid());
                session.delete(o);
            }

            List listaDespiece = session.createQuery("from DespieceHistorico where dacHistorico.historico.iid = " + iid).list();
            it = listaDespiece.iterator();
            DespieceHistorico despp;
            while (it.hasNext()) {
                despp = (DespieceHistorico) it.next();
                o = session.load(DespieceHistorico.class, despp.getIid());
                session.delete(o);
            }

            List listaTemp;
            Iterator iter;
            SeleccionHistorico sp;
            VariableHistorico vp;
            List dacPresupuesto = session.createQuery("from DacHistorico where historico.iid = " + iid).list();
            it = dacPresupuesto.iterator();
            DacHistorico dp;
            while (it.hasNext()) {
                dp = (DacHistorico) it.next();

                listaTemp = session.createQuery("from SeleccionHistorico where dacHistorico.iid = " + dp.getIid()).list();
                iter = listaTemp.iterator();
                while (iter.hasNext()) {
                    sp = (SeleccionHistorico) iter.next();
                    o2 = session.load(SeleccionHistorico.class, sp.getIid());
                    session.delete(o2);
                }

                listaTemp = session.createQuery("from VariableHistorico where dacHistorico.iid = " + dp.getIid()).list();
                iter = listaTemp.iterator();
                while (iter.hasNext()) {
                    vp = (VariableHistorico) iter.next();
                    o2 = session.load(VariableHistorico.class, vp.getIid());
                    session.delete(o2);
                }

                o = session.load(DacHistorico.class, dp.getIid());
                session.delete(o);
            }

            Integer iidFp2 = null;
            PresupuestoHistorico hh;

            String consulta = "from PresupuestoHistorico where iid = " + iid;
            listaTemp = session.createQuery(consulta).list();
            if (listaTemp != null && listaTemp.size() > 0) {
                iter = listaTemp.iterator();
                hh = (PresupuestoHistorico) iter.next();
                iidFp2 = hh.getFp().getIid();
            }

            o = session.load(PresupuestoHistorico.class, iid);
            session.delete(o);

            consulta = "From Presupuesto where fp.iid = " + iidFp2;
            listaTemp = session.createQuery(consulta).list();

            consulta = "From PresupuestoHistorico where fp.iid = " + iidFp2;
            List listaTemp2 = session.createQuery(consulta).list();

            if ((listaTemp == null || listaTemp.size() == 0) && (listaTemp2 == null || listaTemp2.size() == 0)) {
                consulta = "delete from FormaPago2 where iid = " + iidFp2;
                session.createQuery(consulta).executeUpdate();
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            res = false;
            session.getTransaction().rollback();
        } finally {
            if (session.isOpen() && session.getTransaction().isActive()) {
                try {
                    session.getTransaction().commit();
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        }

        return res;
    }

    public static boolean pasarDocumentosToHistorico(Integer iidEmpresa, Integer iidClaseDocumento, String numeroDesde, String numeroHasta, String fechaDesde, String fechaHasta) {
        List lista = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        boolean operacionOK = true;
        try {
            String query = "from Presupuesto where empresa.iid = " + iidEmpresa + " and clase_documento.iid = " + iidClaseDocumento;

            if (fechaDesde != null && !fechaDesde.equals("") && fechaHasta != null && !fechaHasta.equals("")) {
                SimpleDateFormat formatoFecha = new SimpleDateFormat("dd/MM/yyyy");
                Date fd = formatoFecha.parse(fechaDesde);
                Date fh = formatoFecha.parse(fechaHasta);
                // query += " and str_to_date(fecha, '%d/%m/%Y') >= str_to_date('" + fechaDesde + "', '%d/%m/%Y') and str_to_date(fecha, '%d/%m/%Y') <= str_to_date('" + fechaHasta + "', '%d/%m/%Y')";
                query += " and fecha >= " + fd.getTime() + " and fecha <= " + fh.getTime();
            }

            if (numeroDesde != null && !numeroDesde.equals("") && numeroHasta != null && !numeroHasta.equals("")) {
                query += " and (substring(numero,6) >= " + numeroDesde + ") and (substring(numero,6) <= " + numeroHasta + ")";
            }

            System.out.println(query);

            lista = session.createQuery(query).list();
            if (lista == null) {
                lista = new ArrayList();
            }

            Integer iidHistorico;
            Presupuesto p;
            PresupuestoHistorico hp;

            Iterator ite;

            List listaLineaPresupuesto;
            Iterator iterLineaPresupuesto;
            LineaPresupuesto lp;
            LineaPresupuestoHistorico lph;
            Integer iidLineaPresupuestoHistorico;

            List listaDacPresupuesto;
            Iterator iterDacPresupuesto;
            DacPresupuesto dp;
            DacHistorico dh;
            Integer iidDacHistorico;

            List listaVarPresupuesto;
            Iterator iterVarPresupuesto;
            VariablePresupuesto vp;
            VariableHistorico vh;
            Integer iidVariableHistorico;

            List listaSeleccionPresupuesto;
            Iterator iterSeleccionPresupuesto;
            SeleccionPresupuesto sp;
            SeleccionHistorico sh;

            List listaDespiecePresupuesto;
            Iterator iterDespiecePresupuesto;
            DespiecePresupuesto despieceP;
            DespieceHistorico despieceH;

            ite = lista.iterator();
            while (ite.hasNext()) {
                p = (Presupuesto) ite.next();
                System.out.println("Numero: " + p.getNumero());
                hp = new PresupuestoHistorico(p);
                iidHistorico = (Integer) session.save(hp);
                hp.setIid(iidHistorico);

                //Guardamos las lineas de documentos.
                listaLineaPresupuesto = session.createQuery("from LineaPresupuesto where presupuesto_iid = " + p.getIid()).list();
                iterLineaPresupuesto = listaLineaPresupuesto.iterator();
                while (iterLineaPresupuesto.hasNext()) {
                    lp = (LineaPresupuesto) iterLineaPresupuesto.next();
                    lph = new LineaPresupuestoHistorico(lp);
                    lph.setHistorico(hp);
                    iidLineaPresupuestoHistorico = (Integer) session.save(lph);
                    lph.setIid(iidLineaPresupuestoHistorico);
                }

                //Guardamos dacpresupuesto
                listaDacPresupuesto = session.createQuery("from DacPresupuesto where presupuesto.iid = " + p.getIid()).list();
                iterDacPresupuesto = listaDacPresupuesto.iterator();
                while (iterDacPresupuesto.hasNext()) {
                    dp = (DacPresupuesto) iterDacPresupuesto.next();
                    dh = new DacHistorico(dp);
                    dh.setHistorico(hp);
                    iidDacHistorico = (Integer) session.save(dh);
                    dh.setIid(iidDacHistorico);

                    //Guardamos despiecepresupuesto
                    listaDespiecePresupuesto = session.createQuery("from DespiecePresupuesto where dacPresupuesto.iid = " + dp.getIid()).list();
                    iterDespiecePresupuesto = listaDespiecePresupuesto.iterator();
                    while (iterDespiecePresupuesto.hasNext()) {
                        despieceP = (DespiecePresupuesto) iterDespiecePresupuesto.next();
                        despieceH = new DespieceHistorico(despieceP);
                        despieceH.setDacHistorico(dh);
                        session.save(despieceH);
                    }

                    //Guardamos variablepresupuesto
                    listaVarPresupuesto = session.createQuery("from VariablePresupuesto where dacPresupuesto.iid = " + dp.getIid()).list();
                    iterVarPresupuesto = listaVarPresupuesto.iterator();
                    while (iterVarPresupuesto.hasNext()) {
                        vp = (VariablePresupuesto) iterVarPresupuesto.next();
                        vh = new VariableHistorico(vp);
                        vh.setDacHistorico(dh);
                        iidVariableHistorico = (Integer) session.save(vh);
                        vh.setIid(iidVariableHistorico);

                        //Guardamos seleccionpresupuesto
                        listaSeleccionPresupuesto = session.createQuery("from SeleccionPresupuesto where dacPresupuesto.iid = " + dp.getIid() + " and variablePresupuesto.iid = " + vp.getIid()).list();
                        iterSeleccionPresupuesto = listaSeleccionPresupuesto.iterator();
                        while (iterSeleccionPresupuesto.hasNext()) {
                            sp = (SeleccionPresupuesto) iterSeleccionPresupuesto.next();
                            sh = new SeleccionHistorico(sp);
                            sh.setDacHistorico(dh);
                            sh.setVariableHistorico(vh);
                            session.save(sh);
                        }

                    }
                }

                //Ahora se elimina todo lo referente al presupuesto
                List listaLp = session.createQuery("from LineaPresupuesto where presupuesto_iid = " + p.getIid()).list();
                Iterator it = listaLp.iterator();
                Object o;
                Object o2;

                while (it.hasNext()) {
                    lp = (LineaPresupuesto) it.next();
                    o = session.load(LineaPresupuesto.class, lp.getIid());
                    session.delete(o);
                }

                List listaDespiece = session.createQuery("from DespiecePresupuesto where dacPresupuesto.presupuesto.iid = " + p.getIid()).list();
                it = listaDespiece.iterator();
                DespiecePresupuesto despp;
                while (it.hasNext()) {
                    despp = (DespiecePresupuesto) it.next();
                    o = session.load(DespiecePresupuesto.class, despp.getIid());
                    session.delete(o);
                }

                List listaTemp;
                Iterator iter;
                List dacPresupuesto = session.createQuery("from DacPresupuesto where presupuesto.iid = " + p.getIid()).list();
                it = dacPresupuesto.iterator();
                while (it.hasNext()) {
                    dp = (DacPresupuesto) it.next();

                    listaTemp = session.createQuery("from SeleccionPresupuesto where dacPresupuesto.iid = " + dp.getIid()).list();
                    iter = listaTemp.iterator();
                    while (iter.hasNext()) {
                        sp = (SeleccionPresupuesto) iter.next();
                        o2 = session.load(SeleccionPresupuesto.class, sp.getIid());
                        session.delete(o2);
                    }

                    listaTemp = session.createQuery("from VariablePresupuesto where dacPresupuesto.iid = " + dp.getIid()).list();
                    iter = listaTemp.iterator();
                    while (iter.hasNext()) {
                        vp = (VariablePresupuesto) iter.next();
                        o2 = session.load(VariablePresupuesto.class, vp.getIid());
                        session.delete(o2);
                    }

                    o = session.load(DacPresupuesto.class, dp.getIid());
                    session.delete(o);
                }

                o = session.load(Presupuesto.class, p.getIid());
                session.delete(o);
            }

        } catch (Exception e) {
            e.printStackTrace();
            operacionOK = false;
            session.getTransaction().rollback();
        } finally {
            if (session.isOpen() && session.getTransaction().isActive()) {
                try {
                    session.getTransaction().commit();
                    operacionOK = true;
                } catch (Exception ex) {
                    operacionOK = false;
                }
            }
        }

        return operacionOK;
    }

    public static DacHistorico obtenerDacHistoricoById(Integer id) {

        DacHistorico res = null;
        List lista = null;

        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            String consulta = "from DacHistorico where iid = " + id;
            lista = session.createQuery(consulta).list();
            if (lista != null && lista.size() > 0) {
                res = (DacHistorico) lista.get(0);
            }
        } catch (Exception ex) {
            res = null;
            session.getTransaction().rollback();
        } finally {
            if (session.isOpen() && session.getTransaction().isActive()) {
                session.getTransaction().commit();
            }
        }
        return res;
    }

    public static VariableHistorico obtenerVariableHistoricoById(Integer id) {

        VariableHistorico res = null;
        List lista = null;

        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            String consulta = "from VariableHistorico where iid = " + id;
            lista = session.createQuery(consulta).list();
            if (lista != null && lista.size() > 0) {
                res = (VariableHistorico) lista.get(0);
            }
        } catch (Exception ex) {
            res = null;
            session.getTransaction().rollback();
        } finally {
            if (session.isOpen() && session.getTransaction().isActive()) {
                session.getTransaction().commit();
            }
        }
        return res;
    }

    public static List getListaPresupuestoHistorico(Integer empresaIid, Integer claseDocumento) {
        List lp = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lp = session.createQuery("from PresupuestoHistorico where empresa = " + empresaIid + " and clase_documento = " + claseDocumento).list();
        } catch (Exception e) {
            lp = null;
            session.getTransaction().rollback();
        } finally {
            if (session.isOpen() && session.getTransaction().isActive()) {
                session.getTransaction().commit();
            }
        }
        return lp;
    }

    public static List getListaLineaPresupuestoHistorico(Integer historicoIid) {
        List lp = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lp = session.createQuery("from LineaPresupuestoHistorico where historico = " + historicoIid).list();
        } catch (Exception e) {
            lp = null;
            session.getTransaction().rollback();
        } finally {
            if (session.isOpen() && session.getTransaction().isActive()) {
                session.getTransaction().commit();
            }
        }
        return lp;
    }

    public static PresupuestoHistorico obtenerPresupuestoHistorico(Integer iid) {
        PresupuestoHistorico res = null;

        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            List lp = session.createQuery("from PresupuestoHistorico where iid=" + iid).list();
            if (lp.size() >= 1) {
                res = ((PresupuestoHistorico) lp.get(0));
            } else {
                res = null;
            }
        } catch (Exception e) {
            res = null;
            session.getTransaction().rollback();
        } finally {
            if (session.isOpen() && session.getTransaction().isActive()) {
                session.getTransaction().commit();
            }
        }

        return res;
    }

    public static PresupuestoHistorico obtenerPresupuestoHistoricoPorNumeroPorClaseDocumento(String numero, String claseDocumento) {
        List lp = null;
        PresupuestoHistorico res = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            String consulta = "select p.iid from PresupuestoHistorico p "
                    + "inner join p.clase_documento as cd "
                    + "where p.numero like '" + numero + "' "
                    + "and cd.descripcion like '" + claseDocumento + "'";
            lp = session.createQuery(consulta).list();
            if (lp.size() > 0) {
                Integer iidPresupuesto = (Integer) lp.get(0);
                res = obtenerPresupuestoHistorico(iidPresupuesto);
            }
        } catch (Exception e) {
            res = null;
            session.getTransaction().rollback();
        } finally {
            if (session.isOpen() && session.getTransaction().isActive()) {
                session.getTransaction().commit();
            }
        }
        return res;
    }

    public static List busquedaRapidaDocumentoHistoricoPorNombreComercial(String nombre, Integer claseDocumento, Integer empresa) {
        List lp = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lp = session.createQuery("from PresupuestoHistorico p where nombreCliente like '%" + nombre + "%' and p.clase_documento.iid = " + claseDocumento + " and p.empresa.iid = " + empresa).list();
        } catch (Exception e) {
            lp = null;
            session.getTransaction().rollback();
        } finally {
            if (session.isOpen() && session.getTransaction().isActive()) {
                session.getTransaction().commit();
            }
        }
        return lp;
    }

    public static List busquedaRapidaDocumentoHistoricoPorNumero(String numero, Integer claseDocumento, Integer empresa) {
        List lp = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lp = session.createQuery("from PresupuestoHistorico p where numero like '%" + numero + "%' and p.clase_documento.iid = " + claseDocumento + " and p.empresa.iid = " + empresa).list();
        } catch (Exception e) {
            lp = null;
            session.getTransaction().rollback();
        } finally {
            if (session.isOpen() && session.getTransaction().isActive()) {
                session.getTransaction().commit();
            }
        }
        return lp;
    }

    public static List busquedaRapidaDocumentoHistoricoPorFecha(String numero, Integer claseDocumento, Integer empresa) {
        List lp = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lp = session.createQuery("from PresupuestoHistorico p where fecha like '%" + numero + "%' and p.clase_documento.iid = " + claseDocumento + " and p.empresa.iid = " + empresa).list();
        } catch (Exception e) {
            lp = null;
            session.getTransaction().rollback();
        } finally {
            if (session.isOpen() && session.getTransaction().isActive()) {
                session.getTransaction().commit();
            }
        }
        return lp;
    }

    public static List busquedaRapidaDocumentoHistoricoPorEstado(String estado, Integer claseDocumento, Integer empresa) {
        List lp = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            List listaIds = null;
            String consulta = "select p.iid from PresupuestoHistorico p "
                    + "inner join p.estado as e "
                    + "where e.descripcion like '%" + estado + "%' "
                    + "and p.clase_documento.iid = " + claseDocumento
                    + " and p.empresa.iid = " + empresa;

            listaIds = session.createQuery(consulta).list();
            Iterator iter = listaIds.iterator();
            PresupuestoHistorico temp;
            lp = new ArrayList<Presupuesto>();
            while (iter.hasNext()) {
                temp = BaseDatos.obtenerPresupuestoHistorico((Integer) iter.next());
                lp.add(temp);
            }

        } catch (Exception e) {
            lp = null;
            session.getTransaction().rollback();
        } finally {
            if (session.isOpen() && session.getTransaction().isActive()) {
                session.getTransaction().commit();
            }
        }
        return lp;
    }

    public static List busquedaRapidaDocumentosHistoricoPorDireccion(String direccion, Integer empresa, Integer claseDocumento) {
        List lp = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lp = session.createQuery("from PresupuestoHistorico p where domicilioCliente like '%" + direccion + "%' and p.clase_documento.iid = " + claseDocumento + " and p.empresa.iid = " + empresa).list();
        } catch (Exception e) {
            lp = null;
            session.getTransaction().rollback();
        } finally {
            if (session.isOpen() && session.getTransaction().isActive()) {
                session.getTransaction().commit();
            }
        }
        return lp;
    }

    public static List busquedaRapidaDocumentoHistoricoPorReferencia(String referencia, Integer claseDocumento, Integer empresa) {
        List lp = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lp = session.createQuery("from PresupuestoHistorico p where referencia like '%" + referencia + "%' and p.clase_documento.iid = " + claseDocumento + " and p.empresa.iid = " + empresa).list();
        } catch (Exception e) {
            lp = null;
            session.getTransaction().rollback();
        } finally {
            if (session.isOpen() && session.getTransaction().isActive()) {
                session.getTransaction().commit();
            }
        }
        return lp;
    }

    /*******************
     ** Corte de Lona **
     *******************/
    public static List<Existencia> getListaMovimientosRestos(Integer iidPresupuesto, Integer iidArticulo, Integer iidCaracteristica, Integer iidAlmacen, Float largo) {
        log.info("Se ha entrado a la clase: BaseDatos, método: getListaExistencias");
        List le = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        MovimientoPresupuesto mp;
        Existencia ex1;
        List<Integer> listaRestosDescartar = new ArrayList<Integer>();
        List<Integer> listaRestosNoDescartar = new ArrayList<Integer>();
        List movimientoPresupuesto = session.createQuery("from MovimientoPresupuesto where presupuesto.iid = " + iidPresupuesto).list();
        Iterator iterMP = movimientoPresupuesto.iterator();
        while (iterMP.hasNext()) {
            mp = (MovimientoPresupuesto) iterMP.next();
            ex1 = mp.getExistenciaResto();
            if (ex1 != null) {
                listaRestosDescartar.add(ex1.getIid());
            }

            ex1 = mp.getExistencia();
            if (ex1 != null) {
                listaRestosNoDescartar.add(ex1.getIid());
            }
        }

        String notIn = "";
        Integer iidEx;
        Iterator iter;
        int numElementos = 1;

        if (listaRestosDescartar != null && listaRestosDescartar.size() > 0) {
            notIn = " and iid not in (";
            numElementos = 1;
            iter = listaRestosDescartar.iterator();
            while (iter.hasNext()) {
                iidEx = (Integer) iter.next();
                if (numElementos < listaRestosDescartar.size()) {
                    notIn += iidEx + ",";
                } else {
                    notIn += iidEx;
                }
                numElementos++;
            }
            notIn += ")";
        }

        String in = "";
        if (listaRestosNoDescartar != null && listaRestosNoDescartar.size() > 0) {
            in = " iid in(";
            numElementos = 1;
            iter = listaRestosNoDescartar.iterator();
            while (iter.hasNext()) {
                iidEx = (Integer) iter.next();
                if (numElementos < listaRestosNoDescartar.size()) {
                    in += iidEx + ",";
                } else {
                    in += iidEx;
                }
                numElementos++;
            }
            in += ")";
        }

        String query = "From Existencia where articulo.iid = " + iidArticulo;
        query += " and almacen.iid = " + iidAlmacen;
        query += " and esResto = " + true;

        if (in.equals("")) {
            query += " and (estaUsado = false or (estaUsado is null))";
        } else {
            query += " and ((estaUsado = false or (estaUsado is null)) or ( " + in + "))";
        }
        query += " and cantidad1 >= " + largo;

        if (iidCaracteristica != null) {
            query += " and caracteristica.iid = " + iidCaracteristica;
        }

        if (!notIn.equals("")) {
            query += notIn;
        }

        try {
            le = session.createQuery(query).list();
        } catch (Exception e) {
            log.error("Se ha producido una excepción en la clase: BaseDatos, método: getListaExistencias");
            le = null;
            session.getTransaction().rollback();
        } finally {
            if (session.isOpen() && session.getTransaction().isActive()) {
                session.getTransaction().commit();
            }
        }
        return le;
    }

    public static List<Existencia> getListaMovimientosRestosSimulacion(Integer iidArticulo, Integer iidCaracteristica, Integer iidAlmacen, Float largo) {
        log.info("Se ha entrado a la clase: BaseDatos, método: getListaExistencias");
        List le = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        String query = "From Existencia where articulo.iid = " + iidArticulo;
        query += " and almacen.iid = " + iidAlmacen;
        query += " and esResto = " + true;
        query += " and (estaUsado = false or (estaUsado is null))";
        query += " and cantidad1 >= " + largo;

        if (iidCaracteristica != null) {
            query += " and caracteristica.iid = " + iidCaracteristica;
        }

        try {
            le = session.createQuery(query).list();
        } catch (Exception e) {
            log.error("Se ha producido una excepción en la clase: BaseDatos, método: getListaExistencias");
            le = null;
        }
        return le;
    }

    public static List<LineaCorteLona> getListaLineaCorteLona(Integer iidPresupuesto) {
        List llcl = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            llcl = session.createQuery("from LineaCorteLona where presupuesto = " + iidPresupuesto).list();
        } catch (Exception e) {
            llcl = null;
        }
        return llcl;
    }

    public static void eliminarDescuentoUnidadesByLineaPresupuesto(Integer iidLineaPresupuesto) {
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            List movimientoPresupuesto = session.createQuery("from MovimientoPresupuesto where lineaCorteLona is null and lineaCortePerfil is null and numRestos = " + iidLineaPresupuesto).list();
            Iterator iterMP = movimientoPresupuesto.iterator();
            MovimientoPresupuesto mp;
            Existencia ex;
            while (iterMP.hasNext()) {
                mp = (MovimientoPresupuesto) iterMP.next();
                ex = mp.getExistencia();
                ex.setExistencia(mp.getMedida1() + ex.getExistencia());
                session.saveOrUpdate(ex);
            }

            session.createQuery("delete from MovimientoPresupuesto where lineaCorteLona is null and lineaCortePerfil is null and numRestos = " + iidLineaPresupuesto).executeUpdate();
            session.createQuery("delete from MovimientoAlmacen where lineaCorteLona is null and lineaCortePerfil is null and lineaPresupuesto = " + iidLineaPresupuesto).executeUpdate();
        } catch (Exception ex) {
            session.getTransaction().rollback();
        } finally {
            if (session.isOpen() && session.getTransaction().isActive()) {
                session.getTransaction().commit();
            }
        }
    }

    public static void eliminarCorteLonaByLineaPresupuesto(Integer iidLineaPresupuesto) {
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            List<LineaCorteLona> llcl = session.createQuery("from LineaCorteLona where lineaPresupuesto = " + iidLineaPresupuesto).list();
            Iterator iter = llcl.iterator();
            String cadenaIID = "";
            LineaCorteLona lcl;
            while (iter.hasNext()) {
                lcl = (LineaCorteLona) iter.next();
                if (!cadenaIID.equals("")) {
                    cadenaIID += ",";
                }
                cadenaIID += lcl.getIid();
            }

            if (!cadenaIID.equals("")) {
                cadenaIID = "(" + cadenaIID + ")";
                List movimientoPresupuesto = session.createQuery("from MovimientoPresupuesto where lineaCorteLona.iid in " + cadenaIID).list();
                Iterator iterMP = movimientoPresupuesto.iterator();
                MovimientoPresupuesto mp;
                Existencia ex;
                Existencia exR;
                while (iterMP.hasNext()) {
                    mp = (MovimientoPresupuesto) iterMP.next();
                    lcl = mp.getLineaCorteLona();
                    if (lcl.getTipoCorteLona().equals(Constantes.TIPO_CORTE_DEGRADEE)) {
                        ex = mp.getExistencia();
                        ex.setCantidad1(mp.getMedida2() + ex.getCantidad1());
                        session.saveOrUpdate(ex);
                    } else {
                        if (mp.getExistenciaResto() == null) {
                            ex = mp.getExistencia();
                            if (ex != null && (ex.getEsResto() == null || !ex.getEsResto()) && (ex.getEstaUsado() == null || !ex.getEstaUsado())) {
                                ex.setCantidad1(mp.getMedida1() + ex.getCantidad1());
                                session.saveOrUpdate(ex);
                            } else if ((ex.getEsResto() != null && ex.getEsResto()) && (ex.getEstaUsado() != null && ex.getEstaUsado())) {
                                ex.setEstaUsado(false);
                                session.saveOrUpdate(ex);
                            }
                        } else {
                            ex = mp.getExistencia();
                            if (ex != null) {
                                ex.setCantidad1(mp.getMedida1() + ex.getCantidad1());
                                exR = mp.getExistenciaResto();
                                session.delete(exR);
                                mp.setExistenciaResto(null);
                                session.saveOrUpdate(ex);
                            }
                        }
                    }
                }

                session.createQuery("delete from MovimientoPresupuesto where lineaCorteLona.iid in " + cadenaIID).executeUpdate();
                session.createQuery("delete from MovimientoAlmacen where lineaCorteLona.iid in " + cadenaIID).executeUpdate();
                session.createQuery("delete from LineaCorteLona where iid in " + cadenaIID).executeUpdate();
            }
        } catch (Exception ex) {
            session.getTransaction().rollback();
        } finally {
            if (session.isOpen() && session.getTransaction().isActive()) {
                session.getTransaction().commit();
            }
        }
    }
    
    public static boolean eliminarCorteLonaByLineasPresupuesto(List<Integer> listaIidLineaPresupuesto) {
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        boolean res = true;
        try {
            String cadenaIdLinea = "";
            if(listaIidLineaPresupuesto != null && listaIidLineaPresupuesto.size() > 0){
                for(int i = 0; i < listaIidLineaPresupuesto.size(); i++){
                    if(cadenaIdLinea.equals("")){
                        cadenaIdLinea += listaIidLineaPresupuesto.get(i);
                    } else {
                         cadenaIdLinea += "," + listaIidLineaPresupuesto.get(i);
                    }
                }
            }
            cadenaIdLinea += ")";

            List<LineaCorteLona> llcl = session.createQuery("from LineaCorteLona where lineaPresupuesto in (" + cadenaIdLinea).list();
            Iterator iter = llcl.iterator();
            String cadenaIID = "";
            LineaCorteLona lcl;
            while (iter.hasNext()) {
                lcl = (LineaCorteLona) iter.next();
                if (!cadenaIID.equals("")) {
                    cadenaIID += ",";
                }

                cadenaIID += lcl.getIid();
            }

            if (!cadenaIID.equals("")) {
                cadenaIID = "(" + cadenaIID + ")";

                List movimientoPresupuesto = session.createQuery("from MovimientoPresupuesto where lineaCorteLona.iid in " + cadenaIID).list();
                Iterator iterMP = movimientoPresupuesto.iterator();
                MovimientoPresupuesto mp;
                Existencia ex;
                Existencia exR;
                while (iterMP.hasNext()) {
                    mp = (MovimientoPresupuesto) iterMP.next();
                    lcl = mp.getLineaCorteLona();
                    if (lcl.getTipoCorteLona().equals(Constantes.TIPO_CORTE_DEGRADEE)) {
                        ex = mp.getExistencia();
                        ex.setCantidad1(mp.getMedida2() + ex.getCantidad1());
                        session.saveOrUpdate(ex);
                    } else {
                        if (mp.getExistenciaResto() == null) {
                            ex = mp.getExistencia();
                            if (ex != null && (ex.getEsResto() == null || !ex.getEsResto()) && (ex.getEstaUsado() == null || !ex.getEstaUsado())) {
                                ex.setCantidad1(mp.getMedida1() + ex.getCantidad1());
                                session.saveOrUpdate(ex);
                            } else if ((ex.getEsResto() != null && ex.getEsResto()) && (ex.getEstaUsado() != null && ex.getEstaUsado())) {
                                ex.setEstaUsado(false);
                                session.saveOrUpdate(ex);
                            }
                        } else {
                            ex = mp.getExistencia();
                            if (ex != null) {
                                ex.setCantidad1(mp.getMedida1() + ex.getCantidad1());
                                exR = mp.getExistenciaResto();
                                session.delete(exR);
                                mp.setExistenciaResto(null);
                                session.saveOrUpdate(ex);
                            }
                        }
                    }
                }

                session.createQuery("delete from MovimientoPresupuesto where lineaCorteLona.iid in " + cadenaIID).executeUpdate();
                session.createQuery("delete from MovimientoAlmacen where lineaCorteLona.iid in " + cadenaIID).executeUpdate();
                session.createQuery("delete from LineaCorteLona where iid in " + cadenaIID).executeUpdate();
            }
        } catch (Exception ex) {
            session.getTransaction().rollback();
            res = false;
            log.error("Error al cortar lonas ", ex);
        } finally {
            if (session.isOpen() && session.getTransaction().isActive()) {
                try{
                    session.getTransaction().commit();
                } catch(Exception exx){
                    res = false;
                    log.error("Error al cortar lonas ", exx);
                }
            }
        }
        return res;
    }

    public static List<LineaCorteLona> getListaLineaCorteLonaByLineaPresupuesto(Integer iidLineaPresupuesto) {
        List llcl = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            llcl = session.createQuery("from LineaCorteLona where lineaPresupuesto = " + iidLineaPresupuesto).list();
        } catch (Exception e) {
            llcl = null;
        }
        return llcl;
    }

    public static boolean realizarCorteLona(Presupuesto p, JPanel panelCorteLona, int lonasMostradas) {
        boolean res = true;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            List<Integer> listaIidLonasSinCambios = new ArrayList<Integer>();
            NuevaLineaCorteDeLona nlcl;

            String notIn = "";
            for (int i = 0; i < lonasMostradas && res; i++) {
                nlcl = (NuevaLineaCorteDeLona) panelCorteLona.getComponent(i);
                if (nlcl.getIid() != null && !nlcl.getHayCambios()) {
                    listaIidLonasSinCambios.add(nlcl.getIid());
                }
            }
            if (listaIidLonasSinCambios != null && listaIidLonasSinCambios.size() > 0) {
                Iterator iter = listaIidLonasSinCambios.iterator();
                while (iter.hasNext()) {
                    if (notIn.equals("")) {
                        notIn += (Integer) iter.next();
                    } else {
                        notIn += "," + (Integer) iter.next();
                    }
                }
            }

            String notInLcl = "";
            String notInIid = "";

            if (!notIn.equals("")) {
                notInLcl = " and lineaCorteLona.iid not in (" + notIn + ")";
                notInIid = " and iid not in (" + notIn + ")";
            }

            List movimientoPresupuesto = session.createQuery("from MovimientoPresupuesto where lineaCorteLona is not null AND presupuesto.iid = " + p.getIid() + notInLcl).list();
            Iterator iterMP = movimientoPresupuesto.iterator();
            MovimientoPresupuesto mp;
            Existencia ex1;
            Existencia exR1;
            DespiecePresupuesto dp;
            List lDespiecePresupuesto;
            List<MovimientoAlmacen> listaMovimientoAlmacenBBDD = session.createQuery("from MovimientoAlmacen where presupuesto.iid = " + p.getIid() + notInLcl + " and ( lineaCortePerfil is null and lineaCorteLona is not null)").list();
            List<MovimientoPresupuesto> listaMovimientoPresupuestoBBDD = session.createQuery("from MovimientoPresupuesto where lineaCorteLona is not null AND presupuesto.iid = " + p.getIid() + notInLcl).list();
            List<LineaCorteLona> listaLineaCorteLonaBBDD = session.createQuery("from LineaCorteLona where presupuesto.iid = " + p.getIid() + notInIid).list();
            int indiceMovimientoAlmacenBBDD = 0;
            int contadorMovimientoAlmacen = 0;
            int indiceMovimientoPresupuestoBBDD = 0;
            int contadorMovimientoPresupuesto = 0;
            int indiceLineaCorteLonaBBDD = 0;
            int contadorLineaCorteLona = 0;
            MovimientoAlmacen ma;
            List<LineaPresupuesto> lp;

            String tipoCorte, queryExistencias;
            Float anchoSeleccionado, alto, ancho;
            HashMap<Float, List<Existencia>> mapaExistencias = new HashMap<Float, List<Existencia>>();
            List<Existencia> listaExistencias;
            boolean seguirBuscandoExistencia, esDespiece;
            Iterator iter, it;
            Existencia ex, existenciaResto, existenciaRestoUsada;
            LineaCorteLona lcl, lclTemp;
            List<Existencia> listaRestosUsados;
            Float restoMinimo = 0F;
            Articulo art;
            FamiliaVenta famV;
            int indiceRestos = 0;
            int tamListaRestosUsados;
            TipoMovimientoAlmacen tma = null;
            List lAlmacenes = null;

            while (iterMP.hasNext()) {
                mp = (MovimientoPresupuesto) iterMP.next();
                lclTemp = mp.getLineaCorteLona();
                if (lclTemp.getTipoCorteLona().equals(Constantes.TIPO_CORTE_DEGRADEE)) {
                    ex1 = mp.getExistencia();
                    ex1.setCantidad1(mp.getMedida2() + ex1.getCantidad1());
                    session.saveOrUpdate(ex1);
                } else {
                    if (mp.getExistenciaResto() == null) {
                        ex1 = mp.getExistencia();
                        if (ex1 != null && (ex1.getEsResto() == null || !ex1.getEsResto()) && (ex1.getEstaUsado() == null || !ex1.getEstaUsado())) {
                            ex1.setCantidad1(mp.getMedida1() + ex1.getCantidad1());
                            session.saveOrUpdate(ex1);
                        } else if ((ex1.getEsResto() != null && ex1.getEsResto()) && (ex1.getEstaUsado() != null && ex1.getEstaUsado())) {
                            ex1.setEstaUsado(false);
                            session.saveOrUpdate(ex1);
                        }
                    } else {
                        ex1 = mp.getExistencia();
                        if (ex1 != null) {
                            ex1.setCantidad1(mp.getMedida1() + ex1.getCantidad1());
                            exR1 = mp.getExistenciaResto();
                            session.delete(exR1);
                            mp.setExistenciaResto(null);
                            session.saveOrUpdate(mp);
                            session.saveOrUpdate(ex1);
                        }
                    }
                }
            }

            for (int i = 0; i < lonasMostradas && res; i++) {
                nlcl = (NuevaLineaCorteDeLona) panelCorteLona.getComponent(i);
                if (nlcl.getHayCambios()) {
                    tipoCorte = nlcl.getTipoCorteLona();
                    alto = nlcl.getAlto();
                    ancho = nlcl.getLinea();
                    anchoSeleccionado = nlcl.getAnchoSeleccionado();
                    listaRestosUsados = nlcl.getListaRestosUsados();

                    if (indiceLineaCorteLonaBBDD + 1 > listaLineaCorteLonaBBDD.size()) {
                        lcl = new LineaCorteLona();
                    } else {
                        lcl = (LineaCorteLona) listaLineaCorteLonaBBDD.get(contadorLineaCorteLona);
                        contadorLineaCorteLona++;
                    }

                    lcl.setAnchoSeleccionado(new Double(anchoSeleccionado.toString()));
                    lcl.setArticulo(nlcl.getArticulo());
                    lcl.setAutomatico(nlcl.getAutmomatico());
                    lcl.setCantidad(new Double(nlcl.getCantidad().toString()));
                    lcl.setCaracteristica(nlcl.getCaracteristica());
                    lcl.setCodigoLinea(nlcl.getCodigoLinea());
                    lcl.setDobladillo(new Double(nlcl.getDobladillo().toString()));
                    lcl.setLinea(new Double(nlcl.getLinea().toString()));
                    lcl.setPresupuesto(p);
                    lcl.setSalida(new Double(nlcl.getSalida().toString()));
                    lcl.setSolape(new Double(nlcl.getSolape().toString()));
                    lcl.setTipoCorteLona(tipoCorte);

                    lp = session.createQuery("from LineaPresupuesto where presupuesto_iid = " + p.getIid() + " and codigo = " + nlcl.getCodigoLinea()).list();
                    if (lp != null && lp.size() > 0) {
                        lcl.setLineaPresupuesto((LineaPresupuesto) lp.get(0));
                    }

                    esDespiece = nlcl.getEsDespiece();
                    lcl.setEsDespiece(esDespiece);
                    if (esDespiece) {
                        lDespiecePresupuesto = session.createQuery("from DespiecePresupuesto where dacPresupuesto.presupuesto = " + p.getIid() + " and dacPresupuesto.codigo = " + nlcl.getCodigoLinea() + " and orden = " + nlcl.getCorteLona().getIndiceElemento()).list();
                        if (lDespiecePresupuesto.size() >= 1) {
                            lcl.setDespiece((DespiecePresupuesto) lDespiecePresupuesto.get(0));
                        } else {
                            lcl.setDespiece(null);
                        }
                    }

                    if (indiceLineaCorteLonaBBDD + 1 > listaLineaCorteLonaBBDD.size()) {
                        session.save(lcl);
                    } else {
                        indiceLineaCorteLonaBBDD++;
                        session.update(lcl);
                    }

                    tamListaRestosUsados = 0;
                    if (nlcl.getAutmomatico()) {
                        if (listaRestosUsados != null) {
                            tamListaRestosUsados = listaRestosUsados.size();
                        }
                    }

                    mapaExistencias.clear();

                    if (tipoCorte.equals(Constantes.TIPO_CORTE_ASIMETRICO)) {

                        for (int z = 1; z <= lcl.getCantidad(); z++) {
                            seguirBuscandoExistencia = true;

                            listaExistencias = mapaExistencias.get(anchoSeleccionado);
                            if (listaExistencias == null) {
                                queryExistencias = "From Existencia where articulo.iid = " + nlcl.getArticulo().getIid() + " and existencia > 0";
                                if (nlcl.getCaracteristica() != null) {
                                    queryExistencias += " and caracteristica.iid = " + nlcl.getCaracteristica().getIid();
                                }
                                queryExistencias += " and existencia >= 1";
                                queryExistencias += " and cantidad1 >= " + alto;
                                queryExistencias += " and (abs(cantidad2 - " + anchoSeleccionado + ") < " + Constantes.THRESHOLD + ")";
                                queryExistencias += " and almacen.iid = " + p.getAlmacen().getIid();
                                queryExistencias += " and (esResto is null or esResto = 0)";
                                queryExistencias += " order by cantidad1";
                                listaExistencias = session.createQuery(queryExistencias).list();
                                mapaExistencias.put(anchoSeleccionado, listaExistencias);
                            }

                            for (int j = 0; j < nlcl.getNumPañosEnteros() && res; j++) {
                                ex = null;
                                iter = listaExistencias.iterator();
                                seguirBuscandoExistencia = true;
                                while (iter.hasNext() && seguirBuscandoExistencia) {
                                    ex = (Existencia) iter.next();
                                    if (ex.getCantidad1() >= matematico.Matematico.redondear2decimales(alto)) {
                                        seguirBuscandoExistencia = false;
                                    }
                                }

                                if (seguirBuscandoExistencia) {
                                    res = false;
                                } else {

                                    if (indiceMovimientoPresupuestoBBDD + 1 > listaMovimientoPresupuestoBBDD.size()) {
                                        mp = new MovimientoPresupuesto();
                                    } else {
                                        mp = (MovimientoPresupuesto) listaMovimientoPresupuestoBBDD.get(contadorMovimientoPresupuesto);
                                        contadorMovimientoPresupuesto++;
                                    }


                                    if (ex.getExistencia() > 1) {

                                        Existencia existenciaNueva = ex.clonar();
                                        existenciaNueva.setExistencia(1F);
                                        existenciaNueva.setCantidad1(ex.getCantidad1() - alto);
                                        session.save(existenciaNueva);
                                        listaExistencias.add(existenciaNueva);
                                        mp.setExistencia(existenciaNueva);

                                        ex.setExistencia(ex.getExistencia() - 1);
                                        session.saveOrUpdate(ex);

                                    } else {
                                        ex.setCantidad1(ex.getCantidad1() - alto);
                                        session.saveOrUpdate(ex);
                                        mp.setExistencia(ex);
                                    }

                                    FamiliaVenta fv = BaseDatos.obtenerFamiliaVentaPorIidBD(nlcl.getArticulo().getIid_fam_venta().getIid(), session);
                                    TipoControl tc = BaseDatos.obtenerTipoControlPorIidBD(fv.getIid_tipo_control().getIid(), session);

                                    mp.setAlmacen(p.getAlmacen());
                                    mp.setArticulo(nlcl.getArticulo());
                                    mp.setCaracteristica(nlcl.getCaracteristica());
                                    mp.setMedida1(alto);
                                    mp.setUnidadMedida1(tc.getUnidad1());
                                    mp.setMedida2(anchoSeleccionado);
                                    mp.setUnidadMedida2(tc.getUnidad2().getIid());
                                    mp.setPresupuesto(p);
                                    mp.setExistenciaResto(null);
                                    mp.setLineaCorteLona(lcl);
                                    mp.setNumRestos(0);

                                    UnidadMedida um =
                                            BaseDatos.obtenerUnidadMedidaIid(lcl.getArticulo().getIid_unidad_medida().getIid(), session);
                                    mp.setUnidadMedidaTotal(um);

                                    if (indiceMovimientoPresupuestoBBDD + 1 > listaMovimientoPresupuestoBBDD.size()) {
                                        session.save(mp);
                                    } else {
                                        indiceMovimientoPresupuestoBBDD++;
                                        session.update(mp);
                                    }
                                }
                                Collections.sort(listaExistencias);

                            }

                            //Se ha de crear un movimiento de almacen negativo del numero de panios enteros
                            if (indiceMovimientoAlmacenBBDD + 1 > listaMovimientoAlmacenBBDD.size()) {
                                ma = new MovimientoAlmacen();
                            } else {
                                ma = (MovimientoAlmacen) listaMovimientoAlmacenBBDD.get(contadorMovimientoAlmacen);
                                contadorMovimientoAlmacen++;
                            }
                            
                            FamiliaVenta fv = BaseDatos.obtenerFamiliaVentaPorIidBD(nlcl.getArticulo().getIid_fam_venta().getIid(), session);
                            TipoControl tc = BaseDatos.obtenerTipoControlPorIidBD(fv.getIid_tipo_control().getIid(), session);

                            ma.setAlmacen(p.getAlmacen());
                            ma.setArticulo(nlcl.getArticulo());
                            ma.setCantidad(1F);
                            ma.setCantidad1(nlcl.getAlto() * nlcl.getNumPañosEnteros());
                            ma.setUnidadMedida1(tc.getUnidad1());
                            ma.setCantidad2(nlcl.getAnchoSeleccionado());
                            ma.setUnidadMedida2(tc.getUnidad2().getIid());
                            ma.setCaracteristica(nlcl.getCaracteristica());
                            ma.setConcepto("Pedido de fabricaciÃ³n: " + p.getNumero());
                            ma.setEmpresa(p.getEmpresa());
                            
                            UnidadMedida um = BaseDatos.obtenerUnidadMedidaIid(lcl.getArticulo().getIid_unidad_medida().getIid(), session);
                                                 
                            ma.setUnidadMedidaTotal(um);
                            Date fecha = new Date(); // fecha y hora locales

                            ma.setFecha(fecha.getTime());

                            tma = null;
                            lAlmacenes = session.createQuery("from TipoMovimientoAlmacen where nombre='" + Constantes.SALIDA_FABRICACION + "'").list();
                            if (lAlmacenes.size() >= 1) {
                                tma = ((TipoMovimientoAlmacen) lAlmacenes.get(0));
                            }
                            ma.setTipoMovimiento(tma);

                            ma.setPresupuesto(p);
                            ma.setModificable(false);
                            ma.setLineaCorteLona(lcl);
                            if (indiceMovimientoAlmacenBBDD + 1 > listaMovimientoAlmacenBBDD.size()) {
                                session.save(ma);
                            } else {
                                indiceMovimientoAlmacenBBDD++;
                                session.update(ma);
                            }

                            if (nlcl.isHayRestos() && res) {

                                art = nlcl.getArticulo();
                                if (art.getRestoMinimo() != null) {
                                    restoMinimo = art.getRestoMinimo();
                                } else {
                                    famV = BaseDatos.obtenerFamiliaVentaPorIidBD(art.getIid_fam_venta().getIid(),session);
                                    if (famV.getRestoMinimo() != null) {
                                        restoMinimo = famV.getRestoMinimo();
                                    }
                                }

                                ex = null;
                                existenciaResto = null;

                                iter = listaExistencias.iterator();
                                seguirBuscandoExistencia = true;

                                if (!nlcl.getAutmomatico()) {
                                    while (iter.hasNext() && seguirBuscandoExistencia) {
                                        ex = (Existencia) iter.next();
                                        if (ex.getCantidad1() >= matematico.Matematico.redondear2decimales(alto)) {
                                            seguirBuscandoExistencia = false;
                                        }
                                    }
                                } else {
                                    seguirBuscandoExistencia = false;
                                }

                                if (seguirBuscandoExistencia) {
                                    res = false;
                                } else {
                                    if (indiceMovimientoPresupuestoBBDD + 1 > listaMovimientoPresupuestoBBDD.size()) {
                                        mp = new MovimientoPresupuesto();
                                    } else {
                                        mp = (MovimientoPresupuesto) listaMovimientoPresupuestoBBDD.get(contadorMovimientoPresupuesto);
                                        contadorMovimientoPresupuesto++;
                                    }

                                    if (indiceRestos < tamListaRestosUsados) {
                                        Existencia existenciaNueva = listaRestosUsados.get(indiceRestos);
                                        existenciaNueva.setEstaUsado(true);
                                        session.update(existenciaNueva);
                                        mp.setExistencia(existenciaNueva);
                                        mp.setNumRestos(0);
                                        indiceRestos++;

                                        if (indiceMovimientoAlmacenBBDD + 1 > listaMovimientoAlmacenBBDD.size()) {
                                            ma = new MovimientoAlmacen();
                                        } else {
                                            ma = (MovimientoAlmacen) listaMovimientoAlmacenBBDD.get(contadorMovimientoAlmacen);
                                            contadorMovimientoAlmacen++;
                                        }

                                        ma.setAlmacen(p.getAlmacen());
                                        ma.setArticulo(nlcl.getArticulo());
                                        ma.setCantidad(1F);
                                        ma.setCantidad1(nlcl.getAlto());
                                        ma.setUnidadMedida1(tc.getUnidad1());
                                        ma.setCantidad2(existenciaNueva.getCantidad2());
                                        ma.setUnidadMedida2(tc.getUnidad2().getIid());
                                        ma.setCaracteristica(nlcl.getCaracteristica());
                                        ma.setConcepto("Pedido de fabricaciÃ³n: " + p.getNumero());
                                        ma.setEmpresa(p.getEmpresa());
                                        ma.setUnidadMedidaTotal(um);
                                        fecha = new Date(); // fecha y hora locales

                                        ma.setFecha(fecha.getTime());

                                        tma = null;
                                        lAlmacenes = session.createQuery("from TipoMovimientoAlmacen where nombre='" + Constantes.SALIDA_FABRICACION + "'").list();
                                        if (lAlmacenes.size() >= 1) {
                                            tma = ((TipoMovimientoAlmacen) lAlmacenes.get(0));
                                        }
                                        ma.setTipoMovimiento(tma);
                                        ma.setPresupuesto(p);
                                        ma.setModificable(false);
                                        ma.setLineaCorteLona(lcl);
                                        if (indiceMovimientoAlmacenBBDD + 1 > listaMovimientoAlmacenBBDD.size()) {
                                            session.save(ma);
                                        } else {
                                            indiceMovimientoAlmacenBBDD++;
                                            session.update(ma);
                                        }
                                    } else if (ex.getExistencia() > 1) {

                                        Existencia existenciaNueva = ex.clonar();
                                        existenciaNueva.setExistencia(1F);
                                        existenciaNueva.setCantidad1(ex.getCantidad1() - alto);
                                        session.saveOrUpdate(existenciaNueva);
                                        mp.setExistencia(existenciaNueva);
                                        mp.setNumRestos(1);
                                        if ((anchoSeleccionado - nlcl.getRestoIzquierdo()) >= restoMinimo) {
                                            existenciaResto = existenciaNueva.clonar();
                                            existenciaResto.setExistencia(1F);
                                            existenciaResto.setCantidad1(alto);
                                            existenciaResto.setCantidad2(anchoSeleccionado - nlcl.getRestoIzquierdo());
                                            existenciaResto.setEstaUsado(false);
                                            session.save(existenciaResto);
                                        }

                                        listaExistencias.add(existenciaNueva);
                                        mp.setExistencia(existenciaNueva);
                                        ex.setExistencia(ex.getExistencia() - 1);
                                        session.saveOrUpdate(ex);

                                        //Se ha de crear un movimiento de almacen negativo del resto 
                                        if (indiceMovimientoAlmacenBBDD + 1 > listaMovimientoAlmacenBBDD.size()) {
                                            ma = new MovimientoAlmacen();
                                        } else {
                                            ma = (MovimientoAlmacen) listaMovimientoAlmacenBBDD.get(contadorMovimientoAlmacen);
                                            contadorMovimientoAlmacen++;
                                        }

                                        ma.setAlmacen(p.getAlmacen());
                                        ma.setArticulo(nlcl.getArticulo());
                                        ma.setCantidad(1F);
                                        ma.setCantidad1(nlcl.getAlto());
                                        ma.setUnidadMedida1(tc.getUnidad1());
                                        ma.setCantidad2(nlcl.getRestoIzquierdo());
                                        ma.setUnidadMedida2(tc.getUnidad2().getIid());
                                        ma.setCaracteristica(nlcl.getCaracteristica());
                                        ma.setConcepto("Pedido de fabricaciÃ³n: " + p.getNumero());
                                        ma.setEmpresa(p.getEmpresa());
                                        ma.setUnidadMedidaTotal(um);
                                        fecha = new Date(); // fecha y hora locales

                                        ma.setFecha(fecha.getTime());

                                        tma = null;
                                        lAlmacenes = session.createQuery("from TipoMovimientoAlmacen where nombre='" + Constantes.SALIDA_FABRICACION + "'").list();
                                        if (lAlmacenes.size() >= 1) {
                                            tma = ((TipoMovimientoAlmacen) lAlmacenes.get(0));
                                        }
                                        ma.setTipoMovimiento(tma);

                                        ma.setPresupuesto(p);
                                        ma.setModificable(false);
                                        ma.setLineaCorteLona(lcl);
                                        if (indiceMovimientoAlmacenBBDD + 1 > listaMovimientoAlmacenBBDD.size()) {
                                            session.save(ma);
                                        } else {
                                            indiceMovimientoAlmacenBBDD++;
                                            session.update(ma);
                                        }

                                    } else {
                                        ex.setCantidad1(ex.getCantidad1() - alto);
                                        session.saveOrUpdate(ex);
                                        mp.setExistencia(ex);
                                        mp.setNumRestos(1);
                                        if ((anchoSeleccionado - nlcl.getRestoIzquierdo()) >= restoMinimo) {
                                            existenciaResto = ex.clonar();
                                            existenciaResto.setExistencia(1F);
                                            existenciaResto.setCantidad1(alto);
                                            existenciaResto.setUnidadMedida1(tc.getUnidad1());
                                            existenciaResto.setCantidad2(anchoSeleccionado - nlcl.getRestoIzquierdo());
                                            existenciaResto.setUnidadMedida2(tc.getUnidad2().getIid());
                                            existenciaResto.setEsResto(true);
                                            existenciaResto.setEstaUsado(false);
                                            existenciaResto.setUnidadMedidaTotal(um);
                                            session.save(existenciaResto);
                                            
                                        }

                                        //Se ha de crear un movimiento de almacen negativo del resto 
                                        if (indiceMovimientoAlmacenBBDD + 1 > listaMovimientoAlmacenBBDD.size()) {
                                            ma = new MovimientoAlmacen();
                                        } else {
                                            ma = (MovimientoAlmacen) listaMovimientoAlmacenBBDD.get(contadorMovimientoAlmacen);
                                            contadorMovimientoAlmacen++;
                                        }

                                        ma.setAlmacen(p.getAlmacen());
                                        ma.setArticulo(nlcl.getArticulo());
                                        ma.setCantidad(1F);
                                        ma.setCantidad1(nlcl.getAlto());
                                        ma.setUnidadMedida1(tc.getUnidad1());
                                        ma.setCantidad2(nlcl.getRestoIzquierdo());
                                        ma.setUnidadMedida2(tc.getUnidad2().getIid());
                                        ma.setCaracteristica(nlcl.getCaracteristica());
                                        ma.setConcepto("Pedido de fabricaciÃ³n: " + p.getNumero());
                                        ma.setEmpresa(p.getEmpresa());
                                        ma.setUnidadMedidaTotal(um);
                                        fecha = new Date(); // fecha y hora locales

                                        ma.setFecha(fecha.getTime());

                                        tma = null;
                                        lAlmacenes = session.createQuery("from TipoMovimientoAlmacen where nombre='" + Constantes.SALIDA_FABRICACION + "'").list();
                                        if (lAlmacenes.size() >= 1) {
                                            tma = ((TipoMovimientoAlmacen) lAlmacenes.get(0));
                                        }
                                        ma.setTipoMovimiento(tma);

                                        ma.setPresupuesto(p);
                                        ma.setModificable(false);
                                        ma.setLineaCorteLona(lcl);
                                        if (indiceMovimientoAlmacenBBDD + 1 > listaMovimientoAlmacenBBDD.size()) {
                                            session.save(ma);
                                        } else {
                                            indiceMovimientoAlmacenBBDD++;
                                            session.update(ma);
                                        }
                                    }

                                    if (indiceMovimientoAlmacenBBDD + 1 > listaMovimientoAlmacenBBDD.size()) {
                                        ma = new MovimientoAlmacen();
                                    } else {
                                        ma = (MovimientoAlmacen) listaMovimientoAlmacenBBDD.get(contadorMovimientoAlmacen);
                                        contadorMovimientoAlmacen++;
                                    }
                                    ma.setAlmacen(p.getAlmacen());
                                    ma.setArticulo(nlcl.getArticulo());
                                    ma.setCantidad1(1F);
                                    ma.setCantidad1(nlcl.getAlto());
                                    ma.setUnidadMedida1(tc.getUnidad1());
                                    ma.setCantidad2(nlcl.getAnchoSeleccionado() - nlcl.getRestoIzquierdo());
                                    ma.setUnidadMedida2(tc.getUnidad2().getIid());
                                    ma.setCaracteristica(nlcl.getCaracteristica());
                                    ma.setConcepto("Resto de Lona");
                                    ma.setEmpresa(p.getEmpresa());
                                    ma.setUnidadMedidaTotal(um);
                                    fecha = new Date(); // fecha y hora locales

                                    ma.setFecha(fecha.getTime());

                                    tma = null;
                                    lAlmacenes = session.createQuery("from TipoMovimientoAlmacen where nombre='" + Constantes.TIPO_MOVIMIENTO_ALMACEN_RESTO + "'").list();
                                    if (lAlmacenes.size() >= 1) {
                                        tma = ((TipoMovimientoAlmacen) lAlmacenes.get(0));
                                    }
                                    ma.setTipoMovimiento(tma);
                                    ma.setPresupuesto(p);
                                    ma.setCantidad(1F);
                                    ma.setModificable(false);
                                    ma.setLineaCorteLona(lcl);
                                    if (indiceMovimientoAlmacenBBDD + 1 > listaMovimientoAlmacenBBDD.size()) {
                                        session.save(ma);
                                    } else {
                                        indiceMovimientoAlmacenBBDD++;
                                        session.update(ma);
                                    }
                                    
                                    mp.setAlmacen(p.getAlmacen());
                                    mp.setArticulo(nlcl.getArticulo());
                                    mp.setCaracteristica(nlcl.getCaracteristica());
                                    mp.setExistenciaResto(existenciaResto);
                                    mp.setMedida1(alto);
                                    mp.setUnidadMedida1(tc.getUnidad1());
                                    mp.setMedida2(nlcl.getRestoIzquierdo());
                                    mp.setUnidadMedida2(tc.getUnidad2().getIid());
                                    mp.setPresupuesto(p);
                                    mp.setLineaCorteLona(lcl);
                                   
                                    mp.setUnidadMedidaTotal(um);

                                    if (indiceMovimientoPresupuestoBBDD + 1 > listaMovimientoPresupuestoBBDD.size()) {
                                        session.save(mp);
                                    } else {
                                        indiceMovimientoPresupuestoBBDD++;
                                        session.update(mp);
                                    }
                                }
                            }
                        }
                    } else if (tipoCorte.equals(Constantes.TIPO_CORTE_RETAL_MAXI) || tipoCorte.equals(Constantes.TIPO_CORTE_RETAL_MINI)) {

                        for (int z = 1; z <= lcl.getCantidad(); z++) {
                            seguirBuscandoExistencia = true;

                            listaExistencias = mapaExistencias.get(anchoSeleccionado);
                            if (listaExistencias == null) {
                                queryExistencias = "From Existencia where articulo.iid = " + nlcl.getArticulo().getIid() + " and existencia > 0";
                                if (nlcl.getCaracteristica() != null) {
                                    queryExistencias += " and caracteristica.iid = " + nlcl.getCaracteristica().getIid();
                                }
                                queryExistencias += " and existencia >= 1";
                                queryExistencias += " and cantidad1 >= " + alto;
                                queryExistencias += " and (abs(cantidad2 - " + anchoSeleccionado + ") < " + Constantes.THRESHOLD + ")";
                                queryExistencias += " and almacen.iid = " + p.getAlmacen().getIid();
                                queryExistencias += " and (esResto is null or esResto = 0)";
                                queryExistencias += " order by cantidad1";
                                listaExistencias = session.createQuery(queryExistencias).list();
                                mapaExistencias.put(anchoSeleccionado, listaExistencias);
                            }

                            for (int j = 0; j < nlcl.getNumPañosEnteros() && res; j++) {
                                ex = null;
                                iter = listaExistencias.iterator();
                                seguirBuscandoExistencia = true;
                                while (iter.hasNext() && seguirBuscandoExistencia) {
                                    ex = (Existencia) iter.next();
                                    if (ex.getCantidad1() >= matematico.Matematico.redondear2decimales(alto)) {
                                        seguirBuscandoExistencia = false;
                                    }
                                }

                                if (seguirBuscandoExistencia) {
                                    res = false;
                                } else {

                                    if (indiceMovimientoPresupuestoBBDD + 1 > listaMovimientoPresupuestoBBDD.size()) {
                                        mp = new MovimientoPresupuesto();
                                    } else {
                                        mp = (MovimientoPresupuesto) listaMovimientoPresupuestoBBDD.get(contadorMovimientoPresupuesto);
                                        contadorMovimientoPresupuesto++;
                                    }

                                    if (ex.getExistencia() > 1) {

                                        Existencia existenciaNueva = ex.clonar();
                                        existenciaNueva.setExistencia(1F);
                                        existenciaNueva.setCantidad1(ex.getCantidad1() - alto);
                                        session.save(existenciaNueva);
                                        listaExistencias.add(existenciaNueva);
                                        mp.setExistencia(existenciaNueva);

                                        ex.setExistencia(ex.getExistencia() - 1);
                                        session.saveOrUpdate(ex);

                                    } else {
                                        ex.setCantidad1(ex.getCantidad1() - alto);
                                        session.saveOrUpdate(ex);
                                        mp.setExistencia(ex);
                                    }

                                    FamiliaVenta fv = BaseDatos.obtenerFamiliaVentaPorIidBD(nlcl.getArticulo().getIid_fam_venta().getIid(), session);
                                    TipoControl tc = BaseDatos.obtenerTipoControlPorIidBD(fv.getIid_tipo_control().getIid(), session);

                                    mp.setAlmacen(p.getAlmacen());
                                    mp.setArticulo(nlcl.getArticulo());
                                    mp.setCaracteristica(nlcl.getCaracteristica());
                                    mp.setMedida1(alto);
                                    mp.setUnidadMedida1(tc.getUnidad1());
                                    mp.setMedida2(anchoSeleccionado);
                                    mp.setUnidadMedida2(tc.getUnidad2().getIid());
                                    mp.setPresupuesto(p);
                                    mp.setExistenciaResto(null);
                                    mp.setLineaCorteLona(lcl);
                                    mp.setNumRestos(0);
                                    UnidadMedida um =
                                            BaseDatos.obtenerUnidadMedidaIid(lcl.getArticulo().getIid_unidad_medida().getIid(), session);
                                    mp.setUnidadMedidaTotal(um);

                                    if (indiceMovimientoPresupuestoBBDD + 1 > listaMovimientoPresupuestoBBDD.size()) {
                                        session.save(mp);
                                    } else {
                                        indiceMovimientoPresupuestoBBDD++;
                                        session.update(mp);
                                    }
                                }
                                Collections.sort(listaExistencias);

                            }

                            //Se ha de crear un movimiento de almacen negativo del numero de panios enteros
                            if (indiceMovimientoAlmacenBBDD + 1 > listaMovimientoAlmacenBBDD.size()) {
                                ma = new MovimientoAlmacen();
                            } else {
                                ma = (MovimientoAlmacen) listaMovimientoAlmacenBBDD.get(contadorMovimientoAlmacen);
                                contadorMovimientoAlmacen++;
                            }
                            
                            FamiliaVenta fv = BaseDatos.obtenerFamiliaVentaPorIidBD(nlcl.getArticulo().getIid_fam_venta().getIid(), session);
                            TipoControl tc = BaseDatos.obtenerTipoControlPorIidBD(fv.getIid_tipo_control().getIid(), session);

                            ma.setAlmacen(p.getAlmacen());
                            ma.setArticulo(nlcl.getArticulo());
                            ma.setCantidad(new Float(nlcl.getNumPañosEnteros()));
                            ma.setCantidad(1F);
                            ma.setCantidad1(nlcl.getAlto() * nlcl.getNumPañosEnteros());
                            ma.setUnidadMedida1(tc.getUnidad1());
                            ma.setCantidad2(nlcl.getAnchoSeleccionado());
                            ma.setUnidadMedida2(tc.getUnidad2().getIid());
                            ma.setCaracteristica(nlcl.getCaracteristica());
                            ma.setConcepto("Pedido de fabricaciÃ³n: " + p.getNumero());
                            ma.setEmpresa(p.getEmpresa());
                              Date fecha = new Date(); // fecha y hora locales
                            
                            UnidadMedida um =
                                          BaseDatos.obtenerUnidadMedidaIid(lcl.getArticulo().getIid_unidad_medida().getIid(), session);
                            ma.setUnidadMedidaTotal(um);             
                            ma.setFecha(fecha.getTime());

                            tma = null;
                            lAlmacenes = session.createQuery("from TipoMovimientoAlmacen where nombre='" + Constantes.SALIDA_FABRICACION + "'").list();
                            if (lAlmacenes.size() >= 1) {
                                tma = ((TipoMovimientoAlmacen) lAlmacenes.get(0));
                            }
                            ma.setTipoMovimiento(tma);

                            ma.setPresupuesto(p);
                            ma.setModificable(false);
                            ma.setLineaCorteLona(lcl);
                            if (indiceMovimientoAlmacenBBDD + 1 > listaMovimientoAlmacenBBDD.size()) {
                                session.save(ma);
                            } else {
                                indiceMovimientoAlmacenBBDD++;
                                session.update(ma);
                            }

                            if (nlcl.isHayRestos() && res && (2 * nlcl.getRestoIzquierdo()) > anchoSeleccionado) {

                                art = nlcl.getArticulo();
                                if (art.getRestoMinimo() != null) {
                                    restoMinimo = art.getRestoMinimo();
                                } else {
                                    famV = BaseDatos.obtenerFamiliaVentaPorIidBD(art.getIid_fam_venta().getIid(), session);
                                    if (famV.getRestoMinimo() != null) {
                                        restoMinimo = famV.getRestoMinimo();
                                    }
                                }

                                for (int k = 0; k < 2 && res; k++) {

                                    ex = null;
                                    iter = listaExistencias.iterator();
                                    seguirBuscandoExistencia = true;
                                    if (!nlcl.getAutmomatico() || indiceRestos >= tamListaRestosUsados) {
                                        while (iter.hasNext() && seguirBuscandoExistencia) {
                                            ex = (Existencia) iter.next();
                                            if (ex.getCantidad1() >= matematico.Matematico.redondear2decimales(alto)) {
                                                seguirBuscandoExistencia = false;
                                            }
                                        }
                                    } else {
                                        seguirBuscandoExistencia = false;
                                    }

                                    if (seguirBuscandoExistencia) {
                                        res = false;
                                    } else {

                                        if (indiceMovimientoPresupuestoBBDD + 1 > listaMovimientoPresupuestoBBDD.size()) {
                                            mp = new MovimientoPresupuesto();
                                        } else {
                                            mp = (MovimientoPresupuesto) listaMovimientoPresupuestoBBDD.get(contadorMovimientoPresupuesto);
                                            contadorMovimientoPresupuesto++;
                                        }

                                        existenciaResto = null;

                                        if (indiceRestos < tamListaRestosUsados) {
                                            Existencia existenciaNueva = listaRestosUsados.get(indiceRestos);
                                            existenciaNueva.setEstaUsado(true);
                                            session.update(existenciaNueva);
                                            mp.setExistencia(existenciaNueva);
                                            mp.setNumRestos(0);
                                            indiceRestos++;
                                        } else if (ex.getExistencia() > 1) {

                                            Existencia existenciaNueva = ex.clonar();
                                            existenciaNueva.setExistencia(1F);
                                            existenciaNueva.setCantidad1(ex.getCantidad1() - alto);
                                            session.saveOrUpdate(existenciaNueva);

                                            if ((anchoSeleccionado - nlcl.getRestoIzquierdo()) >= restoMinimo) {
                                                existenciaResto = existenciaNueva.clonar();
                                                existenciaResto.setExistencia(1F);
                                                existenciaResto.setCantidad1(alto);
                                                existenciaResto.setCantidad2(anchoSeleccionado - nlcl.getRestoIzquierdo());
                                                existenciaResto.setEstaUsado(false);
                                                session.save(existenciaResto);
                                            }

                                            listaExistencias.add(existenciaNueva);
                                            mp.setExistencia(existenciaNueva);
                                            ex.setExistencia(ex.getExistencia() - 1);
                                            session.saveOrUpdate(ex);

                                        } else {
                                            ex.setCantidad1(ex.getCantidad1() - alto);
                                            session.saveOrUpdate(ex);
                                            mp.setExistencia(ex);

                                            if ((anchoSeleccionado - nlcl.getRestoIzquierdo()) >= restoMinimo) {
                                                existenciaResto = ex.clonar();
                                                existenciaResto.setExistencia(1F);
                                                existenciaResto.setCantidad1(alto);
                                                existenciaResto.setUnidadMedida1(tc.getUnidad1());
                                                existenciaResto.setCantidad2(anchoSeleccionado - nlcl.getRestoIzquierdo());
                                                existenciaResto.setUnidadMedida2(tc.getUnidad2().getIid());
                                                existenciaResto.setEsResto(true);
                                                existenciaResto.setEstaUsado(false);
                                                existenciaResto.setUnidadMedidaTotal(um); 
                                                session.save(existenciaResto);
                                            }
                                        }

                                      
                                        mp.setAlmacen(p.getAlmacen());
                                        mp.setArticulo(nlcl.getArticulo());
                                        mp.setCaracteristica(nlcl.getCaracteristica());
                                        mp.setExistenciaResto(existenciaResto);
                                        mp.setMedida1(alto);
                                        mp.setUnidadMedida1(tc.getUnidad1());
                                        mp.setMedida2(nlcl.getRestoIzquierdo());
                                        mp.setUnidadMedida2(tc.getUnidad2().getIid());
                                        mp.setPresupuesto(p);
                                        mp.setLineaCorteLona(lcl);
                                        mp.setNumRestos(1);
                                       
                                        mp.setUnidadMedidaTotal(um);

                                        if (indiceMovimientoPresupuestoBBDD + 1 > listaMovimientoPresupuestoBBDD.size()) {
                                            session.save(mp);
                                        } else {
                                            indiceMovimientoPresupuestoBBDD++;
                                            session.update(mp);
                                        }

                                        if (indiceMovimientoAlmacenBBDD + 1 > listaMovimientoAlmacenBBDD.size()) {
                                            ma = new MovimientoAlmacen();
                                        } else {
                                            ma = (MovimientoAlmacen) listaMovimientoAlmacenBBDD.get(contadorMovimientoAlmacen);
                                            contadorMovimientoAlmacen++;
                                        }
                                        ma.setAlmacen(p.getAlmacen());
                                        ma.setArticulo(nlcl.getArticulo());
                                        ma.setCantidad1(1F);
                                        ma.setCantidad1(nlcl.getAlto());
                                        ma.setUnidadMedida1(tc.getUnidad1());
                                        ma.setCantidad2(nlcl.getAnchoSeleccionado() - nlcl.getRestoIzquierdo());
                                        ma.setUnidadMedida2(tc.getUnidad2().getIid());
                                        ma.setCaracteristica(nlcl.getCaracteristica());
                                        ma.setConcepto("Resto de Lona");
                                        ma.setEmpresa(p.getEmpresa());
                                        ma.setUnidadMedidaTotal(um);
                                        fecha = new Date(); // fecha y hora locales

                                        ma.setFecha(fecha.getTime());

                                        tma = null;
                                        lAlmacenes = session.createQuery("from TipoMovimientoAlmacen where nombre='" + Constantes.TIPO_MOVIMIENTO_ALMACEN_RESTO + "'").list();
                                        if (lAlmacenes.size() >= 1) {
                                            tma = ((TipoMovimientoAlmacen) lAlmacenes.get(0));
                                        }
                                        ma.setTipoMovimiento(tma);
                                        ma.setPresupuesto(p);
                                        ma.setCantidad(1F);
                                        ma.setModificable(false);
                                        ma.setLineaCorteLona(lcl);
                                        if (indiceMovimientoAlmacenBBDD + 1 > listaMovimientoAlmacenBBDD.size()) {
                                            session.save(ma);
                                        } else {
                                            indiceMovimientoAlmacenBBDD++;
                                            session.update(ma);
                                        }

                                        //Se ha de crear un movimiento de almacen negativo del resto 
                                        if (indiceMovimientoAlmacenBBDD + 1 > listaMovimientoAlmacenBBDD.size()) {
                                            ma = new MovimientoAlmacen();
                                        } else {
                                            ma = (MovimientoAlmacen) listaMovimientoAlmacenBBDD.get(contadorMovimientoAlmacen);
                                            contadorMovimientoAlmacen++;
                                        }

                                        ma.setAlmacen(p.getAlmacen());
                                        ma.setArticulo(nlcl.getArticulo());
                                        ma.setCantidad(1F);
                                        ma.setCantidad1(nlcl.getAlto());
                                        ma.setUnidadMedida1(tc.getUnidad1());
                                        ma.setCantidad2(nlcl.getRestoIzquierdo());
                                        ma.setUnidadMedida2(tc.getUnidad2().getIid());
                                        ma.setCaracteristica(nlcl.getCaracteristica());
                                        ma.setConcepto("Pedido de fabricaciÃ³n: " + p.getNumero());
                                        ma.setEmpresa(p.getEmpresa());
                                        fecha = new Date(); // fecha y hora locales

                                        ma.setFecha(fecha.getTime());
                                        ma.setUnidadMedidaTotal(um);

                                        tma = null;
                                        lAlmacenes = session.createQuery("from TipoMovimientoAlmacen where nombre='" + Constantes.SALIDA_FABRICACION + "'").list();
                                        if (lAlmacenes.size() >= 1) {
                                            tma = ((TipoMovimientoAlmacen) lAlmacenes.get(0));
                                        }
                                        ma.setTipoMovimiento(tma);

                                        ma.setPresupuesto(p);
                                        ma.setModificable(false);
                                        ma.setLineaCorteLona(lcl);
                                        if (indiceMovimientoAlmacenBBDD + 1 > listaMovimientoAlmacenBBDD.size()) {
                                            session.save(ma);
                                        } else {
                                            indiceMovimientoAlmacenBBDD++;
                                            session.update(ma);
                                        }
                                    }
                                }
                            } else if (nlcl.isHayRestos() && res && (2 * nlcl.getRestoIzquierdo()) <= anchoSeleccionado) {

                                art = nlcl.getArticulo();
                                if (art.getRestoMinimo() != null) {
                                    restoMinimo = art.getRestoMinimo();
                                } else {
                                    famV = obtenerFamiliaVentaPorIidBD(art.getIid_fam_venta().getIid(), session);
                                    if (famV.getRestoMinimo() != null) {
                                        restoMinimo = famV.getRestoMinimo();
                                    }
                                }

                                if (nlcl.getAutmomatico() && indiceRestos < tamListaRestosUsados) {

                                    if (indiceMovimientoPresupuestoBBDD + 1 > listaMovimientoPresupuestoBBDD.size()) {
                                        mp = new MovimientoPresupuesto();
                                    } else {
                                        mp = (MovimientoPresupuesto) listaMovimientoPresupuestoBBDD.get(contadorMovimientoPresupuesto);
                                        contadorMovimientoPresupuesto++;
                                    }

                                    existenciaResto = null;

                                    Existencia existenciaNueva = listaRestosUsados.get(indiceRestos);
                                    existenciaNueva.setEstaUsado(true);
                                    session.update(existenciaNueva);
                                    mp.setExistencia(existenciaNueva);
                                    mp.setNumRestos(0);
                                    indiceRestos++;

                                   
                                    mp.setAlmacen(p.getAlmacen());
                                    mp.setArticulo(nlcl.getArticulo());
                                    mp.setCaracteristica(nlcl.getCaracteristica());
                                    mp.setExistenciaResto(existenciaResto);
                                    mp.setMedida1(alto);
                                    mp.setUnidadMedida1(tc.getUnidad1());
                                    mp.setMedida2(nlcl.getRestoIzquierdo());
                                    mp.setUnidadMedida2(tc.getUnidad2().getIid());
                                    mp.setPresupuesto(p);
                                    mp.setLineaCorteLona(lcl);
                                    mp.setNumRestos(1);
                                 
                                    mp.setUnidadMedidaTotal(um);

                                    if (indiceMovimientoPresupuestoBBDD + 1 > listaMovimientoPresupuestoBBDD.size()) {
                                        session.save(mp);
                                    } else {
                                        indiceMovimientoPresupuestoBBDD++;
                                        session.update(mp);
                                    }

                                    if (indiceMovimientoAlmacenBBDD + 1 > listaMovimientoAlmacenBBDD.size()) {
                                        ma = new MovimientoAlmacen();
                                    } else {
                                        ma = (MovimientoAlmacen) listaMovimientoAlmacenBBDD.get(contadorMovimientoAlmacen);
                                        contadorMovimientoAlmacen++;
                                    }
                                    ma.setAlmacen(p.getAlmacen());
                                    ma.setArticulo(nlcl.getArticulo());
                                    ma.setCantidad1(1F);
                                    ma.setCantidad1(nlcl.getAlto());
                                    ma.setUnidadMedida1(tc.getUnidad1());
                                    ma.setCantidad2(nlcl.getAnchoSeleccionado() - nlcl.getRestoIzquierdo());
                                    ma.setUnidadMedida2(tc.getUnidad2().getIid());
                                    ma.setCaracteristica(nlcl.getCaracteristica());
                                    ma.setConcepto("Resto de Lona");
                                    ma.setEmpresa(p.getEmpresa());
                                    ma.setUnidadMedidaTotal(um);
                                    fecha = new Date(); // fecha y hora locales

                                    ma.setFecha(fecha.getTime());

                                    tma = null;
                                    lAlmacenes = session.createQuery("from TipoMovimientoAlmacen where nombre='" + Constantes.TIPO_MOVIMIENTO_ALMACEN_RESTO + "'").list();
                                    if (lAlmacenes.size() >= 1) {
                                        tma = ((TipoMovimientoAlmacen) lAlmacenes.get(0));
                                    }
                                    ma.setTipoMovimiento(tma);
                                    ma.setPresupuesto(p);
                                    ma.setCantidad(1F);
                                    ma.setModificable(false);
                                    ma.setLineaCorteLona(lcl);
                                    if (indiceMovimientoAlmacenBBDD + 1 > listaMovimientoAlmacenBBDD.size()) {
                                        session.save(ma);
                                    } else {
                                        indiceMovimientoAlmacenBBDD++;
                                        session.update(ma);
                                    }


                                    //Se ha de crear un movimiento de almacen negativo del resto 
                                    if (indiceMovimientoAlmacenBBDD + 1 > listaMovimientoAlmacenBBDD.size()) {
                                        ma = new MovimientoAlmacen();
                                    } else {
                                        ma = (MovimientoAlmacen) listaMovimientoAlmacenBBDD.get(contadorMovimientoAlmacen);
                                        contadorMovimientoAlmacen++;
                                    }

                                    ma.setAlmacen(p.getAlmacen());
                                    ma.setArticulo(nlcl.getArticulo());
                                    ma.setCantidad(1F);
                                    ma.setCantidad1(nlcl.getAlto());
                                    ma.setUnidadMedida1(tc.getUnidad1());
                                    ma.setCantidad2(nlcl.getRestoIzquierdo());
                                    ma.setUnidadMedida2(tc.getUnidad2().getIid());
                                    ma.setCaracteristica(nlcl.getCaracteristica());
                                    ma.setConcepto("Pedido de fabricaciÃ³n: " + p.getNumero());
                                    ma.setEmpresa(p.getEmpresa());
                                    ma.setUnidadMedidaTotal(um);
                                    fecha = new Date(); // fecha y hora locales

                                    ma.setFecha(fecha.getTime());

                                    tma = null;
                                    lAlmacenes = session.createQuery("from TipoMovimientoAlmacen where nombre='" + Constantes.SALIDA_FABRICACION + "'").list();
                                    if (lAlmacenes.size() >= 1) {
                                        tma = ((TipoMovimientoAlmacen) lAlmacenes.get(0));
                                    }
                                    ma.setTipoMovimiento(tma);

                                    ma.setPresupuesto(p);
                                    ma.setModificable(false);
                                    ma.setLineaCorteLona(lcl);
                                    if (indiceMovimientoAlmacenBBDD + 1 > listaMovimientoAlmacenBBDD.size()) {
                                        session.save(ma);
                                    } else {
                                        indiceMovimientoAlmacenBBDD++;
                                        session.update(ma);
                                    }

                                    //Si hay mas restos se tomara de ahi y si no pues de una talla nueva
                                    if (indiceRestos < tamListaRestosUsados) {
                                        if (indiceMovimientoPresupuestoBBDD + 1 > listaMovimientoPresupuestoBBDD.size()) {
                                            mp = new MovimientoPresupuesto();
                                        } else {
                                            mp = (MovimientoPresupuesto) listaMovimientoPresupuestoBBDD.get(contadorMovimientoPresupuesto);
                                            contadorMovimientoPresupuesto++;
                                        }

                                        existenciaResto = null;

                                        existenciaNueva = listaRestosUsados.get(indiceRestos);
                                        existenciaNueva.setEstaUsado(true);
                                        session.update(existenciaNueva);
                                        mp.setExistencia(existenciaNueva);
                                        mp.setNumRestos(0);
                                        indiceRestos++;

                                        mp.setAlmacen(p.getAlmacen());
                                        mp.setArticulo(nlcl.getArticulo());
                                        mp.setCaracteristica(nlcl.getCaracteristica());
                                        mp.setExistenciaResto(existenciaResto);
                                        mp.setMedida1(alto);
                                        mp.setUnidadMedida1(tc.getUnidad1());
                                        mp.setMedida2(nlcl.getRestoIzquierdo());
                                        mp.setUnidadMedida2(tc.getUnidad2().getIid());
                                        mp.setPresupuesto(p);
                                        mp.setLineaCorteLona(lcl);
                                        mp.setNumRestos(1);
                                        mp.setUnidadMedidaTotal(um);

                                        if (indiceMovimientoPresupuestoBBDD + 1 > listaMovimientoPresupuestoBBDD.size()) {
                                            session.save(mp);
                                        } else {
                                            indiceMovimientoPresupuestoBBDD++;
                                            session.update(mp);
                                        }

                                        if (indiceMovimientoAlmacenBBDD + 1 > listaMovimientoAlmacenBBDD.size()) {
                                            ma = new MovimientoAlmacen();
                                        } else {
                                            ma = (MovimientoAlmacen) listaMovimientoAlmacenBBDD.get(contadorMovimientoAlmacen);
                                            contadorMovimientoAlmacen++;
                                        }
                                        ma.setAlmacen(p.getAlmacen());
                                        ma.setArticulo(nlcl.getArticulo());
                                        ma.setCantidad1(1F);
                                        ma.setCantidad1(nlcl.getAlto());
                                        ma.setUnidadMedida1(tc.getUnidad1());
                                        ma.setCantidad2(nlcl.getAnchoSeleccionado() - nlcl.getRestoIzquierdo());
                                        ma.setUnidadMedida2(tc.getUnidad2().getIid());
                                        ma.setCaracteristica(nlcl.getCaracteristica());
                                        ma.setConcepto("Resto de Lona");
                                        ma.setEmpresa(p.getEmpresa());
                                        ma.setUnidadMedidaTotal(um);
                                        fecha = new Date(); // fecha y hora locales

                                        ma.setFecha(fecha.getTime());

                                        tma = null;
                                        lAlmacenes = session.createQuery("from TipoMovimientoAlmacen where nombre='" + Constantes.TIPO_MOVIMIENTO_ALMACEN_RESTO + "'").list();
                                        if (lAlmacenes.size() >= 1) {
                                            tma = ((TipoMovimientoAlmacen) lAlmacenes.get(0));
                                        }
                                        ma.setTipoMovimiento(tma);
                                        ma.setPresupuesto(p);
                                        ma.setCantidad(1F);
                                        ma.setModificable(false);
                                        ma.setLineaCorteLona(lcl);
                                        if (indiceMovimientoAlmacenBBDD + 1 > listaMovimientoAlmacenBBDD.size()) {
                                            session.save(ma);
                                        } else {
                                            indiceMovimientoAlmacenBBDD++;
                                            session.update(ma);
                                        }


                                        //Se ha de crear un movimiento de almacen negativo del resto 
                                        if (indiceMovimientoAlmacenBBDD + 1 > listaMovimientoAlmacenBBDD.size()) {
                                            ma = new MovimientoAlmacen();
                                        } else {
                                            ma = (MovimientoAlmacen) listaMovimientoAlmacenBBDD.get(contadorMovimientoAlmacen);
                                            contadorMovimientoAlmacen++;
                                        }

                                        ma.setAlmacen(p.getAlmacen());
                                        ma.setArticulo(nlcl.getArticulo());
                                        ma.setCantidad(1F);
                                        ma.setCantidad1(nlcl.getAlto());
                                        ma.setUnidadMedida1(tc.getUnidad1());
                                        ma.setCantidad2(nlcl.getRestoIzquierdo());
                                        ma.setUnidadMedida2(tc.getUnidad2().getIid());
                                        ma.setCaracteristica(nlcl.getCaracteristica());
                                        ma.setConcepto("Pedido de fabricaciÃ³n: " + p.getNumero());
                                        ma.setEmpresa(p.getEmpresa());
                                        ma.setUnidadMedidaTotal(um);
                                        fecha = new Date(); // fecha y hora locales

                                        ma.setFecha(fecha.getTime());

                                        tma = null;
                                        lAlmacenes = session.createQuery("from TipoMovimientoAlmacen where nombre='" + Constantes.SALIDA_FABRICACION + "'").list();
                                        if (lAlmacenes.size() >= 1) {
                                            tma = ((TipoMovimientoAlmacen) lAlmacenes.get(0));
                                        }
                                        ma.setTipoMovimiento(tma);

                                        ma.setPresupuesto(p);
                                        ma.setModificable(false);
                                        ma.setLineaCorteLona(lcl);
                                        if (indiceMovimientoAlmacenBBDD + 1 > listaMovimientoAlmacenBBDD.size()) {
                                            session.save(ma);
                                        } else {
                                            indiceMovimientoAlmacenBBDD++;
                                            session.update(ma);
                                        }

                                    } else {
                                        ex = null;
                                        iter = listaExistencias.iterator();
                                        seguirBuscandoExistencia = true;

                                        while (iter.hasNext() && seguirBuscandoExistencia) {
                                            ex = (Existencia) iter.next();
                                            if (ex.getCantidad1() >= matematico.Matematico.redondear2decimales(alto)) {
                                                seguirBuscandoExistencia = false;
                                            }
                                        }

                                        if (seguirBuscandoExistencia) {
                                            res = false;
                                        } else {

                                            if (indiceMovimientoPresupuestoBBDD + 1 > listaMovimientoPresupuestoBBDD.size()) {
                                                mp = new MovimientoPresupuesto();
                                            } else {
                                                mp = (MovimientoPresupuesto) listaMovimientoPresupuestoBBDD.get(contadorMovimientoPresupuesto);
                                                contadorMovimientoPresupuesto++;
                                            }

                                            existenciaResto = null;

                                            if (ex.getExistencia() > 1) {

                                                existenciaNueva = ex.clonar();
                                                existenciaNueva.setExistencia(1F);
                                                existenciaNueva.setCantidad1(ex.getCantidad1() - alto);
                                                session.saveOrUpdate(existenciaNueva);

                                                if ((anchoSeleccionado - nlcl.getRestoIzquierdo()) >= restoMinimo) {
                                                    existenciaResto = existenciaNueva.clonar();
                                                    existenciaResto.setExistencia(1F);
                                                    existenciaResto.setCantidad1(alto);
                                                    existenciaResto.setCantidad2(anchoSeleccionado - nlcl.getRestoIzquierdo());
                                                    existenciaResto.setEstaUsado(false);
                                                    session.save(existenciaResto);
                                                }

                                                listaExistencias.add(existenciaNueva);
                                                mp.setExistencia(existenciaNueva);
                                                ex.setExistencia(ex.getExistencia() - 1);
                                                session.saveOrUpdate(ex);

                                            } else {
                                                ex.setCantidad1(ex.getCantidad1() - alto);
                                                session.saveOrUpdate(ex);
                                                mp.setExistencia(ex);

                                                if ((anchoSeleccionado - nlcl.getRestoIzquierdo()) >= restoMinimo) {
                                                    existenciaResto = ex.clonar();
                                                    existenciaResto.setExistencia(1F);
                                                    existenciaResto.setCantidad1(alto);
                                                    existenciaResto.setUnidadMedida1(tc.getUnidad1()); 
                                                    existenciaResto.setCantidad2(anchoSeleccionado - nlcl.getRestoIzquierdo());
                                                    existenciaResto.setUnidadMedida2(tc.getUnidad2().getIid()); 
                                                    existenciaResto.setEsResto(true);
                                                    existenciaResto.setEstaUsado(false);
                                                    existenciaResto.setUnidadMedidaTotal(um); 
                                                    session.save(existenciaResto);
                                                }
                                            }

                                            mp.setAlmacen(p.getAlmacen());
                                            mp.setArticulo(nlcl.getArticulo());
                                            mp.setCaracteristica(nlcl.getCaracteristica());
                                            mp.setExistenciaResto(existenciaResto);
                                            mp.setMedida1(alto);
                                            mp.setUnidadMedida1(tc.getUnidad1());
                                            mp.setMedida2(nlcl.getRestoIzquierdo());
                                            mp.setUnidadMedida2(tc.getUnidad2().getIid());
                                            mp.setPresupuesto(p);
                                            mp.setLineaCorteLona(lcl);
                                            mp.setNumRestos(1);
                                            mp.setUnidadMedidaTotal(um);

                                            if (indiceMovimientoPresupuestoBBDD + 1 > listaMovimientoPresupuestoBBDD.size()) {
                                                session.save(mp);
                                            } else {
                                                indiceMovimientoPresupuestoBBDD++;
                                                session.update(mp);
                                            }

                                            if (indiceMovimientoAlmacenBBDD + 1 > listaMovimientoAlmacenBBDD.size()) {
                                                ma = new MovimientoAlmacen();
                                            } else {
                                                ma = (MovimientoAlmacen) listaMovimientoAlmacenBBDD.get(contadorMovimientoAlmacen);
                                                contadorMovimientoAlmacen++;
                                            }
                                            ma.setAlmacen(p.getAlmacen());
                                            ma.setArticulo(nlcl.getArticulo());
                                            ma.setCantidad1(1F);
                                            ma.setUnidadMedida1(tc.getUnidad1());
                                            ma.setCantidad1(nlcl.getAlto());
                                            ma.setCantidad2(nlcl.getAnchoSeleccionado() - nlcl.getRestoIzquierdo());
                                            ma.setUnidadMedida2(tc.getUnidad2().getIid());
                                            ma.setCaracteristica(nlcl.getCaracteristica());
                                            ma.setConcepto("Resto de Lona");
                                            ma.setEmpresa(p.getEmpresa());
                                            ma.setUnidadMedidaTotal(um);
                                            fecha = new Date(); // fecha y hora locales

                                            ma.setFecha(fecha.getTime());

                                            tma = null;
                                            lAlmacenes = session.createQuery("from TipoMovimientoAlmacen where nombre='" + Constantes.TIPO_MOVIMIENTO_ALMACEN_RESTO + "'").list();
                                            if (lAlmacenes.size() >= 1) {
                                                tma = ((TipoMovimientoAlmacen) lAlmacenes.get(0));
                                            }
                                            ma.setTipoMovimiento(tma);
                                            ma.setPresupuesto(p);
                                            ma.setCantidad(1F);
                                            ma.setModificable(false);
                                            ma.setLineaCorteLona(lcl);
                                            if (indiceMovimientoAlmacenBBDD + 1 > listaMovimientoAlmacenBBDD.size()) {
                                                session.save(ma);
                                            } else {
                                                indiceMovimientoAlmacenBBDD++;
                                                session.update(ma);
                                            }

                                            //Se ha de crear un movimiento de almacen negativo del resto 
                                            if (indiceMovimientoAlmacenBBDD + 1 > listaMovimientoAlmacenBBDD.size()) {
                                                ma = new MovimientoAlmacen();
                                            } else {
                                                ma = (MovimientoAlmacen) listaMovimientoAlmacenBBDD.get(contadorMovimientoAlmacen);
                                                contadorMovimientoAlmacen++;
                                            }

                                            ma.setAlmacen(p.getAlmacen());
                                            ma.setArticulo(nlcl.getArticulo());
                                            ma.setCantidad(1F);
                                            ma.setCantidad1(nlcl.getAlto());
                                            ma.setUnidadMedida1(tc.getUnidad1());
                                            ma.setCantidad2(nlcl.getRestoIzquierdo());
                                            ma.setUnidadMedida2(tc.getUnidad2().getIid());
                                            ma.setCaracteristica(nlcl.getCaracteristica());
                                            ma.setConcepto("Pedido de fabricaciÃ³n: " + p.getNumero());
                                            ma.setEmpresa(p.getEmpresa());
                                            ma.setUnidadMedidaTotal(um);
                                            fecha = new Date(); // fecha y hora locales

                                            ma.setFecha(fecha.getTime());

                                            tma = null;
                                            lAlmacenes = session.createQuery("from TipoMovimientoAlmacen where nombre='" + Constantes.SALIDA_FABRICACION + "'").list();
                                            if (lAlmacenes.size() >= 1) {
                                                tma = ((TipoMovimientoAlmacen) lAlmacenes.get(0));
                                            }
                                            ma.setTipoMovimiento(tma);

                                            ma.setPresupuesto(p);
                                            ma.setModificable(false);
                                            ma.setLineaCorteLona(lcl);
                                            if (indiceMovimientoAlmacenBBDD + 1 > listaMovimientoAlmacenBBDD.size()) {
                                                session.save(ma);
                                            } else {
                                                indiceMovimientoAlmacenBBDD++;
                                                session.update(ma);
                                            }
                                        }
                                    }
                                } else {
                                    ex = null;
                                    iter = listaExistencias.iterator();
                                    seguirBuscandoExistencia = true;
                                    while (iter.hasNext() && seguirBuscandoExistencia) {
                                        ex = (Existencia) iter.next();
                                        if (ex.getCantidad1() >= matematico.Matematico.redondear2decimales(alto)) {
                                            seguirBuscandoExistencia = false;
                                        }
                                    }

                                    if (seguirBuscandoExistencia) {
                                        res = false;
                                    } else {

                                        if (indiceMovimientoPresupuestoBBDD + 1 > listaMovimientoPresupuestoBBDD.size()) {
                                            mp = new MovimientoPresupuesto();
                                        } else {
                                            mp = (MovimientoPresupuesto) listaMovimientoPresupuestoBBDD.get(contadorMovimientoPresupuesto);
                                            contadorMovimientoPresupuesto++;
                                        }

                                        existenciaResto = null;
                                        if (ex.getExistencia() > 1) {

                                            Existencia existenciaNueva = ex.clonar();
                                            existenciaNueva.setExistencia(1F);
                                            existenciaNueva.setCantidad1(ex.getCantidad1() - alto);
                                            session.saveOrUpdate(existenciaNueva);

                                            if (((anchoSeleccionado - (2 * nlcl.getRestoIzquierdo())) >= restoMinimo) && (art.getCorteLiso() != null && art.getCorteLiso())) {
                                                existenciaResto = existenciaNueva.clonar();
                                                existenciaResto.setExistencia(1F);
                                                existenciaResto.setCantidad1(alto);
                                                existenciaResto.setUnidadMedida1(tc.getUnidad1()); 
                                                existenciaResto.setCantidad2(anchoSeleccionado - (nlcl.getRestoIzquierdo() * 2));
                                                existenciaResto.setUnidadMedida2(tc.getUnidad2().getIid()); 
                                                existenciaResto.setEsResto(true);
                                                existenciaResto.setEstaUsado(false);
                                                existenciaResto.setUnidadMedidaTotal(um); 
                                                session.save(existenciaResto);
                                            }

                                            listaExistencias.add(existenciaNueva);
                                            mp.setExistencia(existenciaNueva);
                                            ex.setExistencia(ex.getExistencia() - 1);
                                            session.saveOrUpdate(ex);

                                        } else {
                                            ex.setCantidad1(ex.getCantidad1() - alto);
                                            session.saveOrUpdate(ex);
                                            mp.setExistencia(ex);

                                            if (((anchoSeleccionado - (2 * nlcl.getRestoIzquierdo())) >= restoMinimo) && (art.getCorteLiso() != null && art.getCorteLiso())) {
                                                existenciaResto = ex.clonar();
                                                existenciaResto.setExistencia(1F);
                                                existenciaResto.setCantidad1(alto);
                                                existenciaResto.setUnidadMedida1(tc.getUnidad1()); 
                                                existenciaResto.setUnidadMedida2(tc.getUnidad2().getIid()); 
                                                existenciaResto.setCantidad2(anchoSeleccionado - (nlcl.getRestoIzquierdo() * 2));
                                                existenciaResto.setEsResto(true);
                                                existenciaResto.setEstaUsado(false);
                                                existenciaResto.setUnidadMedidaTotal(um); 
                                                session.save(existenciaResto);
                                            }
                                        }

                                        mp.setAlmacen(p.getAlmacen());
                                        mp.setArticulo(nlcl.getArticulo());
                                        mp.setCaracteristica(nlcl.getCaracteristica());
                                        mp.setExistenciaResto(existenciaResto);
                                        mp.setMedida1(alto);
                                        mp.setUnidadMedida1(tc.getUnidad1());
                                        mp.setMedida2(2 * nlcl.getRestoIzquierdo());
                                        mp.setUnidadMedida2(tc.getUnidad2().getIid());
                                        mp.setPresupuesto(p);
                                        mp.setLineaCorteLona(lcl);
                                        mp.setNumRestos(2);
                                     
                                        mp.setUnidadMedidaTotal(um);

                                        if (indiceMovimientoPresupuestoBBDD + 1 > listaMovimientoPresupuestoBBDD.size()) {
                                            session.save(mp);
                                        } else {
                                            indiceMovimientoPresupuestoBBDD++;
                                            session.update(mp);
                                        }

                                        if (indiceMovimientoAlmacenBBDD + 1 > listaMovimientoAlmacenBBDD.size()) {
                                            ma = new MovimientoAlmacen();
                                        } else {
                                            ma = (MovimientoAlmacen) listaMovimientoAlmacenBBDD.get(contadorMovimientoAlmacen);
                                            contadorMovimientoAlmacen++;
                                        }
                                        ma.setAlmacen(p.getAlmacen());
                                        ma.setArticulo(nlcl.getArticulo());
                                        ma.setCantidad1(1F);
                                        ma.setCantidad1(nlcl.getAlto());
                                        ma.setUnidadMedida1(tc.getUnidad1());
                                        ma.setCantidad2(nlcl.getAnchoSeleccionado() - (2 * nlcl.getRestoIzquierdo()));
                                        ma.setUnidadMedida2(tc.getUnidad2().getIid());
                                        ma.setCaracteristica(nlcl.getCaracteristica());
                                        ma.setConcepto("Resto de Lona");
                                        ma.setEmpresa(p.getEmpresa());
                                        ma.setUnidadMedidaTotal(um);
                                        fecha = new Date(); // fecha y hora locales

                                        ma.setFecha(fecha.getTime());

                                        tma = null;
                                        lAlmacenes = session.createQuery("from TipoMovimientoAlmacen where nombre='" + Constantes.TIPO_MOVIMIENTO_ALMACEN_RESTO + "'").list();
                                        if (lAlmacenes.size() >= 1) {
                                            tma = ((TipoMovimientoAlmacen) lAlmacenes.get(0));
                                        }
                                        ma.setTipoMovimiento(tma);
                                        ma.setPresupuesto(p);
                                        ma.setCantidad(1F);
                                        ma.setModificable(false);
                                        ma.setPresupuesto(p);
                                        ma.setLineaCorteLona(lcl);
                                        if (indiceMovimientoAlmacenBBDD + 1 > listaMovimientoAlmacenBBDD.size()) {
                                            session.save(ma);
                                        } else {
                                            indiceMovimientoAlmacenBBDD++;
                                            session.update(ma);
                                        }

                                        //Se ha de crear un movimiento de almacen negativo del resto 
                                        if (indiceMovimientoAlmacenBBDD + 1 > listaMovimientoAlmacenBBDD.size()) {
                                            ma = new MovimientoAlmacen();
                                        } else {
                                            ma = (MovimientoAlmacen) listaMovimientoAlmacenBBDD.get(contadorMovimientoAlmacen);
                                            contadorMovimientoAlmacen++;
                                        }

                                        ma.setAlmacen(p.getAlmacen());
                                        ma.setArticulo(nlcl.getArticulo());
                                        ma.setCantidad(1F);
                                        ma.setCantidad1(nlcl.getAlto());
                                        ma.setUnidadMedida1(tc.getUnidad1());
                                        ma.setCantidad2(2 * nlcl.getRestoIzquierdo());
                                        ma.setUnidadMedida2(tc.getUnidad2().getIid());
                                        ma.setCaracteristica(nlcl.getCaracteristica());
                                        ma.setConcepto("Pedido de fabricaciÃ³n: " + p.getNumero());
                                        ma.setEmpresa(p.getEmpresa());
                                        ma.setUnidadMedidaTotal(um);
                                        fecha = new Date(); // fecha y hora locales

                                        ma.setFecha(fecha.getTime());

                                        tma = null;
                                        lAlmacenes = session.createQuery("from TipoMovimientoAlmacen where nombre='" + Constantes.SALIDA_FABRICACION + "'").list();
                                        if (lAlmacenes.size() >= 1) {
                                            tma = ((TipoMovimientoAlmacen) lAlmacenes.get(0));
                                        }
                                        ma.setTipoMovimiento(tma);

                                        ma.setPresupuesto(p);
                                        ma.setModificable(false);
                                        ma.setLineaCorteLona(lcl);
                                        if (indiceMovimientoAlmacenBBDD + 1 > listaMovimientoAlmacenBBDD.size()) {
                                            session.save(ma);
                                        } else {
                                            indiceMovimientoAlmacenBBDD++;
                                            session.update(ma);
                                        }
                                    }
                                }
                            }
                        }
                    } else if (tipoCorte.equals(Constantes.TIPO_CORTE_DEGRADEE)) {
                        for (int z = 1; z <= lcl.getCantidad(); z++) {
                            seguirBuscandoExistencia = true;

                            listaExistencias = mapaExistencias.get(anchoSeleccionado);
                            if (listaExistencias == null) {
                                queryExistencias = "From Existencia where articulo.iid = " + nlcl.getArticulo().getIid() + " and existencia > 0";
                                if (nlcl.getCaracteristica() != null) {
                                    queryExistencias += " and caracteristica.iid = " + nlcl.getCaracteristica().getIid();
                                }
                                queryExistencias += " and existencia >= 1";
                                queryExistencias += " and cantidad1 >= " + (ancho + 2 * nlcl.getDobladillo());
                                queryExistencias += " and (abs(cantidad2 - " + anchoSeleccionado + ") < " + Constantes.THRESHOLD + ")";
                                queryExistencias += " and almacen.iid = " + p.getAlmacen().getIid();
                                queryExistencias += " and (esResto is null or esResto = 0)";
                                queryExistencias += " order by cantidad1";
                                listaExistencias = session.createQuery(queryExistencias).list();
                                mapaExistencias.put(anchoSeleccionado, listaExistencias);
                            }

                            ex = null;
                            iter = listaExistencias.iterator();
                            seguirBuscandoExistencia = true;
                            while (iter.hasNext() && seguirBuscandoExistencia) {
                                ex = (Existencia) iter.next();
                                if (ex.getCantidad1() >= matematico.Matematico.redondear2decimales(ancho + 2 * nlcl.getDobladillo())) {
                                    seguirBuscandoExistencia = false;
                                }
                            }

                            if (seguirBuscandoExistencia) {
                                res = false;
                            } else {

                                if (indiceMovimientoPresupuestoBBDD + 1 > listaMovimientoPresupuestoBBDD.size()) {
                                    mp = new MovimientoPresupuesto();
                                } else {
                                    mp = (MovimientoPresupuesto) listaMovimientoPresupuestoBBDD.get(contadorMovimientoPresupuesto);
                                    contadorMovimientoPresupuesto++;
                                }

                                if (ex.getExistencia() > 1) {

                                    Existencia existenciaNueva = ex.clonar();
                                    existenciaNueva.setExistencia(1F);
                                    existenciaNueva.setCantidad1(ex.getCantidad1() - ancho - 2 * nlcl.getDobladillo());
                                    session.save(existenciaNueva);
                                    listaExistencias.add(existenciaNueva);
                                    mp.setExistencia(existenciaNueva);

                                    ex.setExistencia(ex.getExistencia() - 1);
                                    session.saveOrUpdate(ex);

                                } else {
                                    ex.setCantidad1(ex.getCantidad1() - ancho - 2 * nlcl.getDobladillo());
                                    session.saveOrUpdate(ex);
                                    mp.setExistencia(ex);
                                }
                                
                                FamiliaVenta fv = BaseDatos.obtenerFamiliaVentaPorIidBD(nlcl.getArticulo().getIid_fam_venta().getIid(), session);
                                TipoControl tc = BaseDatos.obtenerTipoControlPorIidBD(fv.getIid_tipo_control().getIid(), session);

                                mp.setAlmacen(p.getAlmacen());
                                mp.setArticulo(nlcl.getArticulo());
                                mp.setCaracteristica(nlcl.getCaracteristica());
                                mp.setMedida1(alto);
                                mp.setUnidadMedida1(tc.getUnidad1());
                                mp.setMedida2(ancho + 2 * nlcl.getDobladillo());
                                mp.setUnidadMedida2(tc.getUnidad2().getIid());
                                mp.setPresupuesto(p);
                                mp.setExistenciaResto(null);
                                mp.setLineaCorteLona(lcl);
                                mp.setNumRestos(0);
                                UnidadMedida um = 
                                    BaseDatos.obtenerUnidadMedidaIid(lcl.getArticulo().getIid_unidad_medida().getIid(), session);
                                mp.setUnidadMedidaTotal(um);

                                if (indiceMovimientoPresupuestoBBDD + 1 > listaMovimientoPresupuestoBBDD.size()) {
                                    session.save(mp);
                                } else {
                                    indiceMovimientoPresupuestoBBDD++;
                                    session.update(mp);
                                }
                            }
                            Collections.sort(listaExistencias);
                        }


                    } else if (tipoCorte.equals(Constantes.TIPO_CORTE_SCREEN)) {
                    }
                }
            }

            Object o;
            int i;
            if (listaMovimientoAlmacenBBDD != null) {
                for (i = indiceMovimientoAlmacenBBDD; i < listaMovimientoAlmacenBBDD.size(); i++) {
                    ma = (MovimientoAlmacen) listaMovimientoAlmacenBBDD.get(i);
                    o = session.load(MovimientoAlmacen.class, ma.getIid());
                    session.delete(o);
                }
            }

            if (listaMovimientoPresupuestoBBDD != null) {
                for (i = indiceMovimientoPresupuestoBBDD; i < listaMovimientoPresupuestoBBDD.size(); i++) {
                    mp = (MovimientoPresupuesto) listaMovimientoPresupuestoBBDD.get(i);
                    o = session.load(MovimientoPresupuesto.class, mp.getIid());
                    session.delete(o);
                }
            }

            if (listaLineaCorteLonaBBDD != null) {
                for (i = indiceLineaCorteLonaBBDD; i < listaLineaCorteLonaBBDD.size(); i++) {
                    lcl = (LineaCorteLona) listaLineaCorteLonaBBDD.get(i);
                    o = session.load(LineaCorteLona.class, lcl.getIid());
                    session.delete(o);
                }
            }

        } catch (Exception ex) {
            log.error("Error cortando lonas ", ex);
            ex.printStackTrace();
            res = false;
            session.getTransaction().rollback();
        } finally {
            if (res) {
                try {
                    if (session.isOpen() && session.getTransaction().isActive()) {
                        session.getTransaction().commit();
                    }
                } catch (Exception ex) {
                    res = false;
                    session.getTransaction().rollback();
                }
            }
        }

        return res;
    }

    public static List<Integer> getListaRestosUsados(Integer iidPresupuesto) {
        List<Integer> lres = new ArrayList<Integer>();
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {

            List movimientoPresupuesto = session.createQuery("from MovimientoPresupuesto where presupuesto.iid = " + iidPresupuesto).list();
            Iterator iterMP = movimientoPresupuesto.iterator();
            MovimientoPresupuesto mp;
            Existencia ex;
            Existencia exR;
            while (iterMP.hasNext()) {
                mp = (MovimientoPresupuesto) iterMP.next();
                if (mp.getExistenciaResto() == null) {
                    ex = mp.getExistencia();
                    if ((ex.getEsResto() != null && ex.getEsResto()) && (ex.getEstaUsado() != null && ex.getEstaUsado())) {
                        lres.add(ex.getIid());
                    }
                }
            }
        } catch (Exception e) {
            lres = new ArrayList<Integer>();
        }
        return lres;
    }

    public static DespiecePresupuesto obtenerDespiecePresupuestoByIid(Integer iidDP) {
        DespiecePresupuesto dp = null;
        List lv = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lv = session.createQuery("from DespiecePresupuesto where iid = " + iidDP).list();
            if (lv != null && lv.size() > 0) {
                dp = (DespiecePresupuesto) lv.get(0);
            }
        } catch (Exception e) {
            dp = null;
        }
        return dp;
    }

    public static List<Presupuesto> obtenerFlujo(int iid) {
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        List<Presupuesto> lp = new ArrayList<Presupuesto>();
        List<Conversion> lc;
        try {
            lc = session.createQuery("from Conversion where iidOrigen = " + iid + "or iidDestino = " + iid).list();
            if(lc != null && lc.size() > 0){
                int iidFlujo;
                List<Conversion> lcc;
                Conversion c;
                Iterator it;
                StringBuffer inFlujo = new StringBuffer();
                for (it = lc.iterator(); it.hasNext();) {
                    iidFlujo = ((Conversion) it.next()).getFlujo();
                    if(inFlujo.length() > 0){
                        inFlujo.append(",");
                    }
                    inFlujo.append(iidFlujo);
                }
                
                lcc = session.createQuery("from Conversion where flujo in (" + inFlujo + ")").list();
                if(lcc != null && lcc.size() > 0){
                    SortedSet<Integer> liid = new TreeSet<Integer>();
                    for (it = lcc.iterator(); it.hasNext();) {
                        c = (Conversion) it.next();
                        liid.add(c.getIidOrigen());
                        liid.add(c.getIidDestino());
                    }
                    
                    if (liid != null && liid.size() > 0) {
                        Integer id;
                        Presupuesto p;
                        for (it = liid.iterator(); it.hasNext();) {
                            id = (Integer) it.next();
                            p = BaseDatos.obtenerPresupuesto(id);
                            lp.add(p);
                        }
                    }
                }
            }
        } catch (Exception e) {
            log.error("Error al obtener el flujo ", e);
            lp = null;
        }
        return lp;
    }

    public static Integer comprobarFlujo(Integer iid) {
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        List<Conversion> lc;
        Integer i = 0;
        try {
            lc = session.createQuery("from Conversion where iidOrigen = " + iid + "or iidDestino = " + iid).list();
            if (lc != null && lc.size() > 0) {
                i = lc.get(0).getFlujo();
            }
        } catch (Exception e) {
            log.error("Error al comprobar el flujo ", e);
        }
        
        return i;
    }

    public static List busquedaRapidaMedicion(String nombre, Empresa em, String estado, String medidor, String campo) {
        List lp = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lp = session.createQuery("from Medicion where empresa = " + em.getIid() + " and " + campo + " like '%" + nombre + "%'" + " and estado " + estado + " and medidor like '" + medidor + "' order by llamada desc").list();
        } catch (Exception e) {
            lp = null;
        }
        return lp;
    }

    public static List getListaMedicion(String medidor, String llamada, String medicion, String estado, Empresa empresa) {
        List lm = null;
        String conEst = "";
        Usuario u = BaseDatos.obtenerUsuarioNombre(medidor);
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();

        if (estado.equals("Todos")) {
            //Todos los estados menos presupuestado(finalizado)
            conEst = " estado != 'Presupuestado' ";
        } else {
            conEst = " estado = '" + estado + "'";
        }

        try {
            if (!medidor.equals("Todos")) {
                lm = session.createQuery("from Medicion where empresa = " + empresa.getIid() + " and montador = '" + u.getNombre()  + "' and llamada like '%" + llamada + "%' and ( medicion like '%" + medicion + "%' or medicion = null ) and" + conEst + " order by llamada desc").list();
            } else {
                lm = session.createQuery("from Medicion where empresa = " + empresa.getIid() + " and llamada like '%" + llamada + "%' and ( medicion like '%" + medicion + "%' or medicion = null ) and" + conEst + " order by llamada desc").list();
            }
        } catch (Exception e) {
            lm = null;
        } 
        return lm;
    }

    public static Montaje obtenerMontaje(Presupuesto p) {
        List<Montaje> lm = new ArrayList<Montaje>();
        Montaje m = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lm = session.createQuery("from Montaje where iidPedido = " + p.getIid()).list();
            if (lm != null && lm.size() > 0) {
                m = (Montaje) lm.get(0);
            }
        } catch (Exception e) {
            lm = null;
        }
        return m;
    }

    public static List<Montaje> getMontajes(Empresa em) {
        List<Montaje> lm = new ArrayList<Montaje>();
        Montaje m = new Montaje();
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lm = session.createQuery("from Montaje where iidEmpresa = " + em.getIid()).list();
        } catch (Exception e) {
            lm = null;
        }
        return lm;
    }

    public static List<TipoMontaje> obtenerTiposMontajes(Empresa em) {
        List<TipoMontaje> lt = new ArrayList<TipoMontaje>();
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lt = session.createQuery("from TipoMontaje where iidEmpresa = " + em.getIid()).list();
        } catch (Exception e) {
            lt = null;
        }
        return lt;
    }

    public static TipoMontaje obtenerTipoMontajeDescripcion(Empresa em, String descripcion) {
        List<TipoMontaje> lt = new ArrayList<TipoMontaje>();
        TipoMontaje tm = new TipoMontaje();
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lt = session.createQuery("from TipoMontaje where iidEmpresa = " + em.getIid() + " and descripcion = '" + descripcion + "'").list();
			if (lt != null && lt.size() > 0) {
				tm = (TipoMontaje) lt.get(0);
			}
		} catch (Exception e) {
            tm = null;
        }
        return tm;
    }

    public static TipoMontaje obtenerTipoMontajeIid(Integer iid) {
        List<TipoMontaje> lt = new ArrayList<TipoMontaje>();
        TipoMontaje tm = new TipoMontaje();
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lt = session.createQuery("from TipoMontaje where iid = " + iid).list();
			if (lt != null && lt.size() > 0) {
				tm = (TipoMontaje) lt.get(0);
			}
        } catch (Exception e) {
            tm = null;
        }
        return tm;
    }

    public static boolean eliminarMontaje(Montaje m) {
        boolean res = true;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            session.delete(m);
        } catch (Exception e) {
            res = false;
            session.getTransaction().rollback();
        } finally {
            if (session.isOpen() && session.getTransaction().isActive()) {
                session.getTransaction().commit();
            }
            return res;
        }
    }

    public static boolean mandarMensaje(String asunto, String cuerpo, Empresa e, ClaseDocumento cd, Integer iidpre) {
        //Obtenemos los usuarios tipo Administrador y Oficina
        List<Usuario> lu = BaseDatos.obtenerUsuariosMensajes();
        Iterator i = lu.iterator();
        Mensajes m = new Mensajes();
        Calendar calendario = Calendar.getInstance();
        int hora, minutos;

        //Fecha actuales
        Date fecha = new Date(); // fecha y hora locales
        SimpleDateFormat formatoFecha = new SimpleDateFormat("dd/MM/yyyy");

        String horaActual = new SimpleDateFormat("HH:mm").format(fecha);

        //Hora actual
        hora = calendario.get(Calendar.HOUR_OF_DAY);
        minutos = calendario.get(Calendar.MINUTE);

        m.setAsunto(asunto);
        m.setCuerpo(cuerpo);
        m.setLeido("0");
        m.setFecha(formatoFecha.format(fecha));
        m.setIidEmpresa(e.getIid());
        m.setHora(horaActual);
        m.setIidDocumento(iidpre);
        m.setIidTipoDocumento(cd.getIid());

        for (i = lu.iterator(); i.hasNext();) {
            //Insertamos un mensaje para cada usuario seleccionado  
            m.setUsuario((Usuario) i.next());
            BaseDatos.insertarElemento(m);
        }

        return true;
    }

    //Obtener mensajes por usuario y empresa
    public static List<Mensajes> obtenerMensajes(Usuario u, Empresa em) {
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        List<Mensajes> lm = new ArrayList<Mensajes>();
        try {
            lm = session.createQuery("from Mensajes where iidEmpresa = " + em.getIid() + " and usuario = '" + u.getNombre() + "'" + " order by iid desc").list();
        } catch (Exception e) {
            lm = null;
        }
        return lm;
    }

    public static Mensajes leerMensaje(int iid) {
        List<Mensajes> lm = new ArrayList<Mensajes>();
        Mensajes m = new Mensajes();
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lm = session.createQuery("from Mensajes where iid = " + iid).list();
            if (lm.size() >= 1) {
                m = (Mensajes) lm.get(0);
            } else {
                m = null;
            }
        } catch (Exception e) {
            m = null;
        }
        return m;
    }

    public static boolean eliminarMensaje(Mensajes m) {
        boolean res = true;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            session.delete(m);
        } catch (Exception e) {
            res = false;
            session.getTransaction().rollback();
        } finally {
            if (session.isOpen() && session.getTransaction().isActive()) {
                session.getTransaction().commit();
            }
            return res;
        }
    }

    /*********************************
     * Métodos del corte de perfiles *
	 *********************************/
    public static List<LineaCorteLona> getListaLineaCortePerfil(Integer iidPresupuesto) {
        List llcl = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            llcl = session.createQuery("from LineaCortePerfil where presupuesto = " + iidPresupuesto).list();
        } catch (Exception e) {
            llcl = null;
        }
        return llcl;
    }

    public static List<Integer> getListaRestosPerfilesUsados(Integer iidPresupuesto) {
        List<Integer> lres = new ArrayList<Integer>();
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            List movimientoPresupuesto = session.createQuery("from MovimientoPresupuesto where presupuesto.iid = " + iidPresupuesto).list();
            Iterator iterMP = movimientoPresupuesto.iterator();
            MovimientoPresupuesto mp;
            Existencia ex;
            Existencia exR;
            while (iterMP.hasNext()) {
                mp = (MovimientoPresupuesto) iterMP.next();
                if (mp.getExistenciaResto() == null) {
                    ex = mp.getExistencia();
                    if ((ex.getEsResto() != null && ex.getEsResto()) && (ex.getEstaUsado() != null && ex.getEstaUsado())) {
                        lres.add(ex.getIid());
                    }
                }
            }
        } catch (Exception e) {
            lres = new ArrayList<Integer>();
        }
        return lres;
    }

    public static boolean realizarCortePerfil(Presupuesto p, JPanel panelCortePerfil, int perfilesMostrados) {
        boolean res = true;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            List<Integer> listaIidPerfilesSinCambios = new ArrayList<Integer>();
            NuevaLineaCorteDePerfil nlcp;

            String notIn = "";
            for (int i = 0; i < perfilesMostrados && res; i++) {
                nlcp = (NuevaLineaCorteDePerfil) panelCortePerfil.getComponent(i);
                if (nlcp.getIid() != null && !nlcp.getHayCambios()) {
                    listaIidPerfilesSinCambios.add(nlcp.getIid());
                }
            }
            if (listaIidPerfilesSinCambios != null && listaIidPerfilesSinCambios.size() > 0) {
                Iterator iter = listaIidPerfilesSinCambios.iterator();
                while (iter.hasNext()) {
                    if (notIn.equals("")) {
                        notIn += (Integer) iter.next();
                    } else {
                        notIn += "," + (Integer) iter.next();
                    }
                }
            }

            String notInLcp = "";
            String notInIid = "";

            if (!notIn.equals("")) {
                notInLcp = " and lineaCortePerfil.iid not in (" + notIn + ")";
                notInIid = " and iid not in (" + notIn + ")";
            }

            List movimientoPresupuesto = session.createQuery("from MovimientoPresupuesto  where lineaCortePerfil is not null AND presupuesto.iid = " + p.getIid() + notInLcp).list();
            Iterator iterMP = movimientoPresupuesto.iterator();
            MovimientoPresupuesto mp;
            Existencia ex1;
            Existencia exR1;
            DespiecePresupuesto dp;
            List lDespiecePresupuesto;
            //PARA QUE SOLO OBTENGA LOS PERFILES
            List<MovimientoAlmacen> listaMovimientoAlmacenBBDD = session.createQuery("from MovimientoAlmacen where presupuesto.iid = " + p.getIid() + notInLcp + " and ( lineaCorteLona is null and lineaCortePerfil is not null)" ).list();
            List<MovimientoPresupuesto> listaMovimientoPresupuestoBBDD = session.createQuery("from MovimientoPresupuesto where lineaCortePerfil is not null AND presupuesto.iid = " + p.getIid() + notInLcp).list();
            List<LineaCortePerfil> listaLineaCortePerfilBBDD = session.createQuery("from LineaCortePerfil where presupuesto.iid = " + p.getIid() + notInIid).list();
            int indiceMovimientoAlmacenBBDD = 0;
            int contadorMovimientoAlmacen = 0;
            int indiceMovimientoPresupuestoBBDD = 0;
            int contadorMovimientoPresupuesto = 0;
            int indiceLineaCortePerfilBBDD = 0;
            int contadorLineaCortePerfil = 0;
            MovimientoAlmacen ma;
            List<LineaPresupuesto> lp;
            List lAlmacenes = null;
            TipoMovimientoAlmacen tma = null;

            String queryExistencias;
            Float longitudSeleccionada, longitud;
            HashMap<Float, List<Existencia>> mapaExistencias = new HashMap<Float, List<Existencia>>();
            List<Existencia> listaExistencias;
            boolean seguirBuscandoExistencia, esDespiece;
            Iterator iter, it;
            Existencia ex, existenciaResto, existenciaRestoUsada;
            LineaCortePerfil lcp;
            List<Existencia> listaRestosUsados;
            Float restoMinimo = 0F;
            Articulo art;
            FamiliaVenta famV;
            int indiceRestos = 0;
            int tamListaRestosUsados;

            while (iterMP.hasNext()) {
                mp = (MovimientoPresupuesto) iterMP.next();
                ex1 = mp.getExistencia();
                if (ex1 != null && (ex1.getEsResto() == null || !ex1.getEsResto()) && (ex1.getEstaUsado() == null || !ex1.getEstaUsado())) {
                    ex1.setCantidad1(mp.getMedida1() + ex1.getCantidad1());
                    session.saveOrUpdate(ex1);
                } else if ((ex1.getEsResto() != null && ex1.getEsResto()) && (ex1.getEstaUsado() != null && ex1.getEstaUsado())) {
                    ex1.setEstaUsado(false);
                    session.saveOrUpdate(ex1);
                }
            }

            for (int i = 0; i < perfilesMostrados && res; i++) {
                nlcp = (NuevaLineaCorteDePerfil) panelCortePerfil.getComponent(i);
                if (nlcp.getHayCambios()) {
                    longitud = nlcp.getLongitud();
                    longitudSeleccionada = nlcp.getLongitudSeleccionada();
                    listaRestosUsados = nlcp.getListaRestosUsados();

                    if (indiceLineaCortePerfilBBDD + 1 > listaLineaCortePerfilBBDD.size()) {
                        lcp = new LineaCortePerfil();
                    } else {
                        lcp = (LineaCortePerfil) listaLineaCortePerfilBBDD.get(contadorLineaCortePerfil);
                        contadorLineaCortePerfil++;
                    }

                    lcp.setLongitudSeleccionada(new Double(longitudSeleccionada.toString()));
                    lcp.setArticulo(nlcp.getArticulo());
                    lcp.setCantidad(new Double(nlcp.getCantidad().toString()));
                    lcp.setCaracteristica(nlcp.getCaracteristica());
                    lcp.setCodigoLinea(nlcp.getCodigoLinea());
                    lcp.setPresupuesto(p);
                    lcp.setLongitud(new Double(nlcp.getLongitud().toString()));

                    lp = session.createQuery("from LineaPresupuesto where presupuesto_iid = " + p.getIid() + " and codigo = " + nlcp.getCodigoLinea()).list();
                    if (lp != null && lp.size() > 0) {
                        lcp.setLineaPresupuesto((LineaPresupuesto) lp.get(0));
                    }

                    esDespiece = nlcp.getEsDespiece();
                    lcp.setEsDespiece(esDespiece);
                    if (esDespiece) {
                        lDespiecePresupuesto = session.createQuery("from DespiecePresupuesto where dacPresupuesto.presupuesto = " + p.getIid() + " and dacPresupuesto.codigo = " + nlcp.getCodigoLinea() + " and orden = " + nlcp.getCortePerfil().getIndiceElemento()).list();
                        if (lDespiecePresupuesto.size() >= 1) {
                            lcp.setDespiece((DespiecePresupuesto) lDespiecePresupuesto.get(0));
                        } else {
                            lcp.setDespiece(null);
                        }
                    }

                    if (indiceLineaCortePerfilBBDD + 1 > listaLineaCortePerfilBBDD.size()) {
                        session.save(lcp);
                    } else {
                        indiceLineaCortePerfilBBDD++;
                        session.update(lcp);
                    }

                    mapaExistencias.clear();

                    for (int z = 1; z <= lcp.getCantidad(); z++) {
                        seguirBuscandoExistencia = true;

                        listaExistencias = mapaExistencias.get(longitudSeleccionada);
                        if (listaExistencias == null) {
                            queryExistencias = "From Existencia where articulo.iid = " + nlcp.getArticulo().getIid() + " and existencia > 0";
                            if (nlcp.getCaracteristica() != null) {
                                queryExistencias += " and caracteristica.iid = " + nlcp.getCaracteristica().getIid();
                            }
                            queryExistencias += " and existencia >= 1";
                            queryExistencias += " and cantidad1 >= " + longitud;
                            queryExistencias += " and almacen.iid = " + p.getAlmacen().getIid();
                            queryExistencias += " and (esResto is null or esResto = 0)";
                            queryExistencias += " order by cantidad1";
                            listaExistencias = session.createQuery(queryExistencias).list();
                            mapaExistencias.put(longitudSeleccionada, listaExistencias);
                        }

                        ex = null;
                        existenciaResto = null;

                        if (listaExistencias != null) {
                            iter = listaExistencias.iterator();
                            while (iter.hasNext()) {
                                ex = (Existencia) iter.next();
                            }
                        }

                        iter = listaExistencias.iterator();
                        seguirBuscandoExistencia = true;

                        while (iter.hasNext() && seguirBuscandoExistencia) {
                            ex = (Existencia) iter.next();
                            if (ex.getCantidad1() >= matematico.Matematico.redondear2decimales(longitud)) {
                                seguirBuscandoExistencia = false;
                            }
                        }

                        if (seguirBuscandoExistencia) {
                            res = false;
                        } else {
                            if (indiceMovimientoPresupuestoBBDD + 1 > listaMovimientoPresupuestoBBDD.size()) {
                                mp = new MovimientoPresupuesto();
                            } else {
                                mp = (MovimientoPresupuesto) listaMovimientoPresupuestoBBDD.get(contadorMovimientoPresupuesto);
                                contadorMovimientoPresupuesto++;
                            }

                            if (ex.getExistencia() > 1) {
                                Existencia existenciaNueva = ex.clonar();
                                existenciaNueva.setExistencia(1F);
                                existenciaNueva.setCantidad1(ex.getCantidad1() - longitud);
                                session.save(existenciaNueva);
                                listaExistencias.add(existenciaNueva);
                                mp.setExistencia(existenciaNueva);
                                ex.setExistencia(ex.getExistencia() - 1);
                                session.saveOrUpdate(ex);

                            } else {
                                ex.setCantidad1(ex.getCantidad1() - longitud);
                                session.saveOrUpdate(ex);
                                mp.setExistencia(ex);
                            }

                            FamiliaVenta fv = BaseDatos.obtenerFamiliaVentaPorIidBD(nlcp.getArticulo().getIid_fam_venta().getIid(), session);
                            TipoControl tc = BaseDatos.obtenerTipoControlPorIidBD(fv.getIid_tipo_control().getIid(), session);

                            mp.setAlmacen(p.getAlmacen());
                            mp.setArticulo(nlcp.getArticulo());
                            mp.setCaracteristica(nlcp.getCaracteristica());
                            mp.setMedida1(longitud);
                            mp.setUnidadMedida1(tc.getUnidad1());
                            mp.setPresupuesto(p);
                            mp.setExistenciaResto(null);
                            mp.setLineaCortePerfil(lcp);
                            mp.setNumRestos(0);
                            UnidadMedida um =
                                    BaseDatos.obtenerUnidadMedidaIid(lcp.getArticulo().getIid_unidad_medida().getIid(), session);
                            mp.setUnidadMedidaTotal(um);

                            if (indiceMovimientoPresupuestoBBDD + 1 > listaMovimientoPresupuestoBBDD.size()) {
                                session.save(mp);
                            } else {
                                indiceMovimientoPresupuestoBBDD++;
                                session.update(mp);
                            }
                        }
                        Collections.sort(listaExistencias);

                        //Se ha de crear un movimiento de almacen negativo
                        if (indiceMovimientoAlmacenBBDD + 1 > listaMovimientoAlmacenBBDD.size()) {
                            ma = new MovimientoAlmacen();
                        } else {
                            ma = (MovimientoAlmacen) listaMovimientoAlmacenBBDD.get(contadorMovimientoAlmacen);
                            contadorMovimientoAlmacen++;
                        }
                        
                       FamiliaVenta fv = BaseDatos.obtenerFamiliaVentaPorIidBD(nlcp.getArticulo().getIid_fam_venta().getIid(), session);
                       TipoControl tc = BaseDatos.obtenerTipoControlPorIidBD(fv.getIid_tipo_control().getIid(), session);

                        
                        ma.setAlmacen(p.getAlmacen());
                        ma.setArticulo(nlcp.getArticulo());
                        ma.setCantidad(1F);
                        ma.setCantidad1(nlcp.getLongitud());
                        ma.setUnidadMedida1(tc.getUnidad1());
                        ma.setCantidad2(0F);
                        if (tc.getUnidad2()!=null){
                            ma.setUnidadMedida2(tc.getUnidad2().getIid());
                        }
                        ma.setCaracteristica(nlcp.getCaracteristica());
                        ma.setConcepto("Pedido de fabricaciÃ³n: " + p.getNumero());
                        ma.setEmpresa(p.getEmpresa());
                        ma.setFecha(new Date().getTime());
                        
                          UnidadMedida um =
                                    BaseDatos.obtenerUnidadMedidaIid(lcp.getArticulo().getIid_unidad_medida().getIid(), session);
                            ma.setUnidadMedidaTotal(um);

                        tma = null;
                        lAlmacenes = session.createQuery("from TipoMovimientoAlmacen where nombre='" + Constantes.SALIDA_FABRICACION + "'").list();
                        if (lAlmacenes.size() >= 1) {
                            tma = ((TipoMovimientoAlmacen) lAlmacenes.get(0));
                        }
                        ma.setTipoMovimiento(tma);

                        ma.setPresupuesto(p);
                        ma.setModificable(false);
                        ma.setLineaCortePerfil(lcp);
                        if (indiceMovimientoAlmacenBBDD + 1 > listaMovimientoAlmacenBBDD.size()) {
                            session.save(ma);
                        } else { 
                           indiceMovimientoAlmacenBBDD++;
                            session.update(ma);
                        }
                    }
                }
            }

            Object o;
            int i;
            if (listaMovimientoAlmacenBBDD != null) {
                for (i = indiceMovimientoAlmacenBBDD; i < listaMovimientoAlmacenBBDD.size(); i++) {
                    ma = (MovimientoAlmacen) listaMovimientoAlmacenBBDD.get(i);
                    o = session.load(MovimientoAlmacen.class, ma.getIid());
                    session.delete(o);
                }
            }

            if (listaMovimientoPresupuestoBBDD != null) {
                for (i = indiceMovimientoPresupuestoBBDD; i < listaMovimientoPresupuestoBBDD.size(); i++) {
                    mp = (MovimientoPresupuesto) listaMovimientoPresupuestoBBDD.get(i);
                    o = session.load(MovimientoPresupuesto.class, mp.getIid());
                    session.delete(o);
                }
            }

            if (listaLineaCortePerfilBBDD != null) {
                for (i = indiceLineaCortePerfilBBDD; i < listaLineaCortePerfilBBDD.size(); i++) {
                    lcp = (LineaCortePerfil) listaLineaCortePerfilBBDD.get(i);
                    o = session.load(LineaCorteLona.class, lcp.getIid());
                    session.delete(o);
                }
            }

        } catch (Exception ex) {
            ex.printStackTrace();
            res = false;
            session.getTransaction().rollback();
        } finally {
            if (res) {
                try {
                    if (session.isOpen() && session.getTransaction().isActive()) {
                        session.getTransaction().commit();
                    }
                } catch (Exception ex) {
                    res = false;
                    session.getTransaction().rollback();
                }
            } else {
                session.getTransaction().rollback();
            }
        }

        return res;
    }

    public static boolean realizarDescuentoUnidades(Presupuesto p, List<DesUnidades> listaArticulo) {
        boolean res = true;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        if (listaArticulo == null) {
            listaArticulo = new ArrayList();
        }
        try {
            MovimientoPresupuesto mp;
            Existencia ex1;

            List<MovimientoAlmacen> listaMovimientoAlmacenBBDD = session.createQuery("from MovimientoAlmacen where presupuesto.iid = " + p.getIid() + " and lineaCorteLona is null and lineaCortePerfil is null").list();
            List<MovimientoPresupuesto> listaMovimientoPresupuestoBBDD = session.createQuery("from MovimientoPresupuesto where lineaCortePerfil is null and lineaCorteLona is null AND presupuesto.iid = " + p.getIid()).list();
            Iterator iterMP = listaMovimientoPresupuestoBBDD.iterator();
            int indiceMovimientoAlmacenBBDD = 0;
            int contadorMovimientoAlmacen = 0;
            int indiceMovimientoPresupuestoBBDD = 0;
            int contadorMovimientoPresupuesto = 0;
            MovimientoAlmacen ma;
            List<LineaPresupuesto> lp;
            List lAlmacenes = null;
            TipoMovimientoAlmacen tma = null;
            String queryExistencias;
            List<Existencia> listaExistencias = null;
            boolean seguirBuscandoExistencia;
            Iterator iter;
            Existencia ex;
            DesUnidades du;

            while (iterMP.hasNext()) {
                mp = (MovimientoPresupuesto) iterMP.next();
                ex1 = mp.getExistencia();
                if (ex1 != null) {
                    ex1.setExistencia(mp.getMedida1() + ex1.getExistencia());
                    session.saveOrUpdate(ex1);
                }
            }

            Iterator iterDU = listaArticulo.iterator();
            while (iterDU.hasNext() && res) {
                du = (DesUnidades) iterDU.next();
                seguirBuscandoExistencia = true;

                queryExistencias = "From Existencia where articulo.iid = " + du.getAr().getIid() + " and existencia > 0";
                if (du.getCar() != null) {
                    queryExistencias += " and caracteristica.iid = " + du.getCar().getIid();
                }
                queryExistencias += " and existencia >= 1";
                queryExistencias += " and almacen.iid = " + p.getAlmacen().getIid();
                queryExistencias += " order by existencia";
                listaExistencias = session.createQuery(queryExistencias).list();

                ex = null;

                if (listaExistencias != null) {
                    iter = listaExistencias.iterator();
                    while (iter.hasNext()) {
                        ex = (Existencia) iter.next();
                    }
                }

                iter = listaExistencias.iterator();
                seguirBuscandoExistencia = true;

                while (iter.hasNext() && seguirBuscandoExistencia) {
                    ex = (Existencia) iter.next();
                    if (ex.getExistencia() >= matematico.Matematico.redondear2decimales(du.getCantidad())) {
                        seguirBuscandoExistencia = false;
                    }
                }

                if (seguirBuscandoExistencia) {
                    res = false;
                } else {
                    if (indiceMovimientoPresupuestoBBDD + 1 > listaMovimientoPresupuestoBBDD.size()) {
                        mp = new MovimientoPresupuesto();
                    } else {
                        mp = (MovimientoPresupuesto) listaMovimientoPresupuestoBBDD.get(contadorMovimientoPresupuesto);
                        contadorMovimientoPresupuesto++;
                    }

                    ex.setExistencia(new Float(ex.getExistencia() - du.getCantidad()));
                    session.saveOrUpdate(ex);
       
                    mp.setMedida1(new Float(du.getCantidad()));
                    mp.setExistencia(ex);
                    mp.setAlmacen(p.getAlmacen());
                    mp.setArticulo(du.getAr());
                    mp.setCaracteristica(du.getCar());
                    mp.setPresupuesto(p);
                    mp.setExistenciaResto(null);
                    mp.setLineaCortePerfil(null);
                    mp.setLineaCorteLona(null);
                    mp.setNumRestos(du.getIidLineaPresupuesto());

                    if (indiceMovimientoPresupuestoBBDD + 1 > listaMovimientoPresupuestoBBDD.size()) {
                        session.save(mp);
                    } else {
                        indiceMovimientoPresupuestoBBDD++;
                        session.update(mp);
                    }
                }
                Collections.sort(listaExistencias);

                //Se ha de crear un movimiento de almacen negativo
                if (indiceMovimientoAlmacenBBDD + 1 > listaMovimientoAlmacenBBDD.size()) {
                    ma = new MovimientoAlmacen();
                } else {
                    ma = (MovimientoAlmacen) listaMovimientoAlmacenBBDD.get(contadorMovimientoAlmacen);
                    contadorMovimientoAlmacen++;
                }

                ma.setAlmacen(p.getAlmacen());
                ma.setArticulo(du.getAr());
                ma.setCantidad(new Float(du.getCantidad()));
                ma.setCaracteristica(du.getCar());
                ma.setConcepto("Pedido de fabricaciÃ³n: " + p.getNumero());
                ma.setEmpresa(p.getEmpresa());
                ma.setFecha(new Date().getTime());
                ma.setLineaPresupuesto(du.getIidLineaPresupuesto());
                tma = null;
                lAlmacenes = session.createQuery("from TipoMovimientoAlmacen where nombre='" + Constantes.SALIDA_FABRICACION + "'").list();
                if (lAlmacenes.size() >= 1) {
                    tma = ((TipoMovimientoAlmacen) lAlmacenes.get(0));
                }
                ma.setTipoMovimiento(tma);

                ma.setPresupuesto(p);
                ma.setModificable(false);
                ma.setLineaCortePerfil(null);
                ma.setLineaCorteLona(null);
                if (indiceMovimientoAlmacenBBDD + 1 > listaMovimientoAlmacenBBDD.size()) {
                    session.save(ma);
                } else {
                    indiceMovimientoAlmacenBBDD++;
                    session.update(ma);
                }
            }

            Object o;
            int i;

            if (listaMovimientoAlmacenBBDD != null) {
                for (i = indiceMovimientoAlmacenBBDD; i < listaMovimientoAlmacenBBDD.size(); i++) {
                    ma = (MovimientoAlmacen) listaMovimientoAlmacenBBDD.get(i);
                    o = session.load(MovimientoAlmacen.class, ma.getIid());
                    session.delete(o);
                }
            }

            if (listaMovimientoPresupuestoBBDD != null) {
                for (i = indiceMovimientoPresupuestoBBDD; i < listaMovimientoPresupuestoBBDD.size(); i++) {
                    mp = (MovimientoPresupuesto) listaMovimientoPresupuestoBBDD.get(i);
                    o = session.load(MovimientoPresupuesto.class, mp.getIid());
                    session.delete(o);
                }
            }

        } catch (Exception ex) {
            ex.printStackTrace();
            res = false;
            session.getTransaction().rollback();
        } finally {
            if (res) {
                try {
                    if (session.isOpen() && session.getTransaction().isActive()) {
                        session.getTransaction().commit();
                    }
                } catch (Exception ex) {
                    res = false;
                    session.getTransaction().rollback();
                }
            } else {
                session.getTransaction().rollback();
            }
        }

        return res;
    }

    public static void eliminarCortePerfilByLineaPresupuesto(Integer iidLineaPresupuesto) {
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            List<LineaCortePerfil> llcp = session.createQuery("from LineaCortePerfil where lineaPresupuesto = " + iidLineaPresupuesto).list();
            Iterator iter = llcp.iterator();
            String cadenaIID = "";
            LineaCortePerfil lcp;
            while (iter.hasNext()) {
                lcp = (LineaCortePerfil) iter.next();
                if (!cadenaIID.equals("")) {
                    cadenaIID += ",";
                }
                cadenaIID += lcp.getIid();
            }

            if (!cadenaIID.equals("")) {
                cadenaIID = "(" + cadenaIID + ")";
                List movimientoPresupuesto = session.createQuery("from MovimientoPresupuesto where lineaCortePerfil.iid in " + cadenaIID).list();
                Iterator iterMP = movimientoPresupuesto.iterator();
                MovimientoPresupuesto mp;
                Existencia ex;
                while (iterMP.hasNext()) {
                    mp = (MovimientoPresupuesto) iterMP.next();
                    lcp = mp.getLineaCortePerfil();
                    ex = mp.getExistencia();
                    ex.setCantidad1(mp.getMedida1() + ex.getCantidad1());
                    session.saveOrUpdate(ex);
                }

                session.createQuery("delete from MovimientoPresupuesto where lineaCortePerfil.iid in " + cadenaIID).executeUpdate();
                session.createQuery("delete from MovimientoAlmacen where lineaCortePerfil.iid in " + cadenaIID).executeUpdate();
                session.createQuery("delete from LineaCortePerfil where iid in " + cadenaIID).executeUpdate();
            }

        } catch (Exception ex) {
            session.getTransaction().rollback();
        } finally {
            if (session.isOpen() && session.getTransaction().isActive()) {
                session.getTransaction().commit();
            }
        }
    }
    
    public static boolean eliminarCortePerfilByLineasPresupuesto(List<Integer> listaIidLineaPresupuesto) {
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        boolean res = true;
        try {
            String cadenaIdLinea = "";
            if(listaIidLineaPresupuesto != null && listaIidLineaPresupuesto.size() > 0){
                for(int i = 0; i < listaIidLineaPresupuesto.size(); i++){
                    if(cadenaIdLinea.equals("")){
                        cadenaIdLinea += listaIidLineaPresupuesto.get(i);
                    } else {
                         cadenaIdLinea += "," + listaIidLineaPresupuesto.get(i);
                    }
                }
            }
            cadenaIdLinea += ")";

            List<LineaCortePerfil> llcp = session.createQuery("from LineaCortePerfil where lineaPresupuesto in (" + cadenaIdLinea).list();
            Iterator iter = llcp.iterator();
            String cadenaIID = "";
            LineaCortePerfil lcp;
            while (iter.hasNext()) {
                lcp = (LineaCortePerfil) iter.next();
                if (!cadenaIID.equals("")) {
                    cadenaIID += ",";
                }

                cadenaIID += lcp.getIid();
            }

            if (!cadenaIID.equals("")) {
                cadenaIID = "(" + cadenaIID + ")";


                List movimientoPresupuesto = session.createQuery("from MovimientoPresupuesto where lineaCortePerfil.iid in " + cadenaIID).list();
                Iterator iterMP = movimientoPresupuesto.iterator();
                MovimientoPresupuesto mp;
                Existencia ex;
                while (iterMP.hasNext()) {
                    mp = (MovimientoPresupuesto) iterMP.next();
                    lcp = mp.getLineaCortePerfil();
                    ex = mp.getExistencia();
                    ex.setCantidad1(mp.getMedida1() + ex.getCantidad1());
                    session.saveOrUpdate(ex);
                }

                session.createQuery("delete from MovimientoPresupuesto where lineaCortePerfil.iid in " + cadenaIID).executeUpdate();
                session.createQuery("delete from MovimientoAlmacen where lineaCortePerfil.iid in " + cadenaIID).executeUpdate();
                session.createQuery("delete from LineaCortePerfil where iid in " + cadenaIID).executeUpdate();
            }

        } catch (Exception ex) {
            log.error("Error en mÃ©todo eliminarCortePerfilByLineasPresupuesto", ex);
            session.getTransaction().rollback();
            res = false;
        } finally {
            if (session.isOpen() && session.getTransaction().isActive()) {
                try{
                    session.getTransaction().commit();
                } catch (Exception exx){
                    log.error("Error realizar commit en método eliminarCortePerfilByLineasPresupuesto", exx);
                    res = false;
                }
            }
        }
        return res;
    }

    public static List<MovimientoPresupuesto> getListaMovimientoPresupuestoDescuentoUnidades(Integer iidLineaPresupuesto) {
        List ld = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            ld = session.createQuery("from MovimientoPresupuesto where numRestos = " + iidLineaPresupuesto).list();
        } catch (Exception e) {
            ld = null;
            session.getTransaction().rollback();
        } finally {
            if (session.isOpen() && session.getTransaction().isActive()) {
                session.getTransaction().commit();
            }
        }
        return ld;
    }

    public static List<LineaCortePerfil> getListaLineaCortePerfilByLineaPresupuesto(Integer iidLineaPresupuesto) {
        List llcp = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            llcp = session.createQuery("from LineaCortePerfil where lineaPresupuesto = " + iidLineaPresupuesto).list();
        } catch (Exception e) {
            llcp = null;
        }
        return llcp;
    }

    public static Double obtenerLongitudSeleccionadaPerfil(Integer iidLineaPresupuesto, Integer iidDespiecePresupuesto) {
        Double res = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            List lLineaCortePerfil = session.createQuery("from LineaCortePerfil where lineaPresupuesto = " + iidLineaPresupuesto + " and despiece = " + iidDespiecePresupuesto).list();
            if (lLineaCortePerfil.size() >= 1) {
                res = ((LineaCortePerfil) lLineaCortePerfil.get(0)).getLongitudSeleccionada();
            }
        } catch (Exception e) {
            res = null;
        }
        return res;
    }

    public static List<Presupuesto> obtenerPresupuestosPorMedicion(int iidEmpresa, int medicion) {
        List<Presupuesto> lp = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();

        try {
            lp = session.createQuery("from Presupuesto where empresa = " + iidEmpresa + " and medicion = " + medicion).list();
            if (lp.size() < 0) {
                lp = null;
            }
        } catch (Exception e) {
            lp = null;
        }
        return lp;
    }

    //Color Familia
    public static List<colorFamilia> getColoresPorFamilia(Integer iidEmpresa, Integer iidFamilia) {
        List llcp = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            llcp = session.createQuery("from colorFamilia where iidEmpresa = " + iidEmpresa + " and iidFamilia = " + iidFamilia).list();
        } catch (Exception e) {
            llcp = null;
        }
        return llcp;
    }

    public static precioFamilia obtenerPrecioFamilia(Empresa em, FamiliaVenta fv, String tipoRal) {
        precioFamilia res = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            List lad = session.createQuery("from precioFamilia where iidEmpresa = " + em.getIid() + " and iidFamilia = " + fv.getIid() + " and tipoRal = '" + tipoRal + "'").list();
            if (lad.size() >= 1) {
                res = (precioFamilia) lad.get(0);
            } 
        } catch (Exception e) {
            res = null;
        }
        return res;
    }

    public static List<Articulo> getListaArticuloFV(Empresa em, FamiliaVenta fv) {
        List lart = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();

        //Obtenemos los artículos
        try {
            lart = session.createQuery("from Articulo where iid_empresa = " + em.getIid() + " and iid_fam_venta = " + fv.getIid()).list();
        } catch (Exception e) {
            lart = null;
        }
        return lart;
    }

    /****************
     * Interlocutor *
     ****************/
    public static List<Interlocutor> getListaInterlocutores() {
        List lista = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lista = session.createQuery("from Interlocutor").list();
        } catch (Exception e) {
            lista = null;
        }
        return lista;
    }

    public static List<Interlocutor> obtenerlistaInterlocutores(Integer empresaIid) {
        List lista = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lista = session.createQuery("from Interlocutor where empresaMadre = " + empresaIid).list();
        } catch (Exception e) {
            lista = null;
        }
        return lista;
    }

    public static List<Interlocutor> obtenerlistaInterlocutoresReducida(Integer empresaIid) {
        List lista = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        String consulta = "select eh.cod_empresa, eh.desc_empresa, ag.nombre_comercial"
                + " from Interlocutor inte, Empresa eh, Agentes ag"
                + " where empresaMadre = " + empresaIid
                + " and inte.empresaHija = eh "
                + " and inte.iidCliente = ag";
        try {
            lista = session.createQuery(consulta).list();
        } catch (Exception e) {
            lista = null;
        }
        return lista;
    }

    public static List obtenerlistaInterlocutoresPorNombreComercial(Integer empresaIid, String nombreComercial) {
        List lista = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        String consulta = "select eh.cod_empresa, eh.desc_empresa, ag.nombre_comercial"
                + " from Interlocutor inte, Empresa eh, Agentes ag"
                + " where empresaMadre = " + empresaIid
                + " and inte.empresaHija = eh "
                + " and inte.iidCliente = ag"
                + " and ag.nombre_comercial like '%" + nombreComercial + "%'";
        try {
            lista = session.createQuery(consulta).list();
        } catch (Exception e) {
            lista = null;
        }
        return lista;
    }

    public static List obtenerlistaInterlocutoresPorDescripcion(Integer empresaIid, String descripcion) {
        List lista = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        String consulta = "select eh.cod_empresa, eh.desc_empresa, ag.nombre_comercial"
                + " from Interlocutor inte, Empresa eh, Agentes ag"
                + " where empresaMadre = " + empresaIid
                + " and inte.empresaHija = eh "
                + " and inte.iidCliente = ag"
                + " and eh.desc_empresa like '%" + descripcion + "%'";
        try {
            lista = session.createQuery(consulta).list();
        } catch (Exception e) {
            lista = null;
        }
        return lista;
    }

    public static List obtenerlistaInterlocutoresPorCodigo(Integer empresaIid, String codigo) {
        List lista = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        String consulta = "select eh.cod_empresa, eh.desc_empresa, ag.nombre_comercial"
                + " from Interlocutor inte, Empresa eh, Agentes ag"
                + " where empresaMadre = " + empresaIid
                + " and inte.empresaHija = eh "
                + " and inte.iidCliente = ag"
                + " and eh.cod_empresa like '%" + codigo + "%'";
        try {
            lista = session.createQuery(consulta).list();
        } catch (Exception e) {
            lista = null;
        }
        return lista;
    }

    public static List obtenerFamiliaVentasSinInterlocutores(Integer iidEmpresaMadre, Integer iidEmpresaHija) {
        List lista = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        String consulta =
                "select fv.cod_familia, fv.nombre "
                + " from FamiliaVenta fv"
                + " where fv.iid_empresa = " + iidEmpresaMadre
                + " and fv.iid not in"
                + " (select fv.iid "
                + " from FamiliaVenta fv,"
                + " Interlocutor i,"
                + " InterlocutorFamiliaVenta ifv"
                + " where ifv.interlocutor = i.iid"
                + " and ifv.familiaVenta = fv.iid"
                + " and i.empresaMadre = " + iidEmpresaMadre + " and i.empresaHija = " + iidEmpresaHija + ")";
        try {
            lista = session.createQuery(consulta).list();
        } catch (Exception e) {
            lista = null;
        }
        return lista;
    }

    public static List obtenerFamiliaVentasConInterlocutores(Integer iidEmpresaMadre, Integer iidEmpresaHija) {
        List lista = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        String consulta =
                "select fv.cod_familia, fv.nombre, ifv.formula "
                + " from FamiliaVenta fv,"
                + " Interlocutor i,"
                + " InterlocutorFamiliaVenta ifv"
                + " where ifv.interlocutor = i.iid"
                + " and ifv.familiaVenta = fv.iid"
                + " and i.empresaMadre = " + iidEmpresaMadre + " and i.empresaHija = " + iidEmpresaHija;
        try {
            lista = session.createQuery(consulta).list();
        } catch (Exception e) {
            lista = null;
        }
        return lista;
    }

    public static boolean eliminarInterlocutor(Integer iidEmpresaMadre, String codigoEmpresaHija) {
        log.info("Se ha entrado a la clase: BaseDatos, metodo: obtenerInterlocutorPorCodigoEmpresaHija");
        boolean res = true;
        Interlocutor i = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {

            List lInterlocutores = session.createQuery("from Interlocutor where empresaMadre = " + iidEmpresaMadre + " and empresaHija.cod_empresa = '" + codigoEmpresaHija + "'").list();
            if (lInterlocutores.size() >= 1) {
                i = (Interlocutor) lInterlocutores.get(0);

                String consultaInterlocutor = "delete from Interlocutor where iid = " + i.getIid();
                String consultaInterlocutorFamVenta = "delete from InterlocutorFamiliaVenta where interlocutor = " + i.getIid();

                session.createQuery(consultaInterlocutorFamVenta).executeUpdate();
                session.createQuery(consultaInterlocutor).executeUpdate();
            } else {
                res = false;
            }
        } catch (Exception e) {
            log.error("Se ha producido una excepcion en la clase: BaseDatos, metodo: obtenerInterlocutorPorCodigoEmpresaHija");
            res = false;
            session.getTransaction().rollback();
        } finally {
            if (session.isOpen() && session.getTransaction().isActive()) {
                session.getTransaction().commit();
            }
        }
        return res;
    }

    public static Interlocutor obtenerInterlocutor(Integer iidEmpresaMadre, Integer iidEmpresaHija) {

        log.info("Se ha entrado a la clase: BaseDatos, metodo: obtenerInterlocutor");
        Interlocutor res = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            List lInterlocutores = session.createQuery("from Interlocutor where empresaMadre = " + iidEmpresaMadre + " and empresaHija = " + iidEmpresaHija).list();
            if (lInterlocutores.size() >= 1) {
                res = (Interlocutor) lInterlocutores.get(0);
            }
        } catch (Exception e) {
            log.error("Se ha producido una excepcion en la clase: BaseDatos, metodo: obtenerInterlocutor");
            res = null;
        }
        return res;
    }

    public static boolean crearInterlocutor(Empresa empresaMadre, String descripcionEmpresa, String codigoFamilia, String factor, Agentes cliente) {
        log.info("Se ha entrado a la clase: BaseDatos, metodo: crearInterlocutor");

        boolean ok = true;
        Interlocutor i = null;
        InterlocutorFamiliaVenta ifv;
        String queryEmpresa = "From Empresa where cod_empresa = '" + descripcionEmpresa + "'";
        String queryFamilia = "From FamiliaVenta where iid_Empresa = " + empresaMadre.getIid() + " and cod_familia = '" + codigoFamilia + "'";
        Empresa empresaHija = null;
        FamiliaVenta fv = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();        
        Date fecha = new Date();

        try {
            List lEmpresas = session.createQuery(queryEmpresa).list();
            if (lEmpresas != null && lEmpresas.size() >= 1) {
                empresaHija = (Empresa) lEmpresas.get(0);
            } else {
                ok = false;
            }

            List lFamilias = session.createQuery(queryFamilia).list();
            if (ok && lFamilias != null && lFamilias.size() >= 1) {
                fv = (FamiliaVenta) lFamilias.get(0);
            } else {
                ok = false;
            }

            if (ok) {

                String queryInterlocutor = "From Interlocutor where empresaMadre = " + empresaMadre.getIid() + " and empresaHija = " + empresaHija.getIid();
                List lInterlocutores = session.createQuery(queryInterlocutor).list();
                if (lInterlocutores != null && lInterlocutores.size() > 0) {
                    i = (Interlocutor) lInterlocutores.get(0);
                    i.setIidCliente(cliente);
                    session.update(i);
                } else {
                    i = new Interlocutor();
                    i.setEmpresaHija(empresaHija);
                    i.setEmpresaMadre(empresaMadre);
                    i.setIidCliente(cliente);
                    Integer iidInterlocutor = (Integer) session.save(i);
                    i.setIid(iidInterlocutor);
                }

                ifv = new InterlocutorFamiliaVenta();
                ifv.setFamiliaVenta(fv);
                ifv.setInterlocutor(i);
                ifv.setFormula(factor);
                ifv.setFecha(fecha.getTime());
                session.save(ifv);
            }
        } catch (Exception e) {
            log.error("Se ha producido una excepcion en la clase: BaseDatos, metodo: crearInterlocutor");
            ok = false;
            session.getTransaction().rollback();
        } finally {
            if (session.isOpen() && session.getTransaction().isActive()) {
                session.getTransaction().commit();
            }
        }
        return ok;
    }

    public static List<InterlocutorFamiliaVenta> getListaInterlocutoresFamiliaVenta() {
        List lista = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        String consulta = "from InterlocutorFamiliaVenta";
        try {
            lista = session.createQuery(consulta).list();
        } catch (Exception e) {
            lista = null;
        }
        return lista;
    }

    public static List getListaInterlocutores(Empresa em) {
        List linter = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            linter = session.createQuery("from Interlocutor where empresaMadre = " + em.getIid()).list();
        } catch (Exception e) {
            linter = null;
        }
        return linter;
    }

    public static boolean eliminarInterlocutorFamiliaVenta(Integer iidEmpresaMadre, String codigoEmpresaHija, String codigoFamilia) {
        boolean res = true;
        List lista = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        String consulta =
                "select ifv.iid, ifv.interlocutor.iid "
                + " from FamiliaVenta fv,"
                + " Interlocutor i,"
                + " InterlocutorFamiliaVenta ifv"
                + " where ifv.interlocutor = i.iid"
                + " and fv.cod_familia = '" + codigoFamilia + "'"
                + " and ifv.familiaVenta = fv.iid"
                + " and i.empresaMadre = " + iidEmpresaMadre + " and i.empresaHija.cod_empresa = '" + codigoEmpresaHija + "'";

        try {
            lista = session.createQuery(consulta).list();
            if (lista != null && lista.size() > 0) {

                Object[] elemento = (Object[]) lista.get(0);
                Integer iidIFV = (Integer) elemento[0];
                Integer iidI = (Integer) elemento[1];

                session.createQuery("delete from InterlocutorFamiliaVenta where iid = " + iidIFV).executeUpdate();

                consulta = "select count(*) from InterlocutorFamiliaVenta where interlocutor.iid = " + iidI;
                lista = session.createQuery(consulta).list();
                if (lista != null && lista.size() >= 0) {
                    Long count = (Long) lista.get(0);
                    if (count < 1) {
                        session.createQuery("delete from Interlocutor where iid = " + iidI).executeUpdate();
                    }
                }
            }
        } catch (Exception e) {
            res = false;
            session.getTransaction().rollback();
        } finally {
            if (session.isOpen() && session.getTransaction().isActive()) {
                session.getTransaction().commit();
            }
        }
        return res;
    }


    public static Precios obtenerPrecioActivo(Empresa em, Articulo art, Integer car) {
        Precios res = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction(); 
        try {
            List lp = session.createQuery("from Precios where iid_empresa = " + em.getIid() + " and iid_art = " + art.getIid() + " and iid_car = " + car + "order by fecha desc").list();
            if (lp.size() > 0) {
                res = (Precios) lp.get(0);
            }
        } catch (Exception e) {
            res = null;
        }
        return res;
    }
        
    public static Precios obtenerPrecioActivoFecha(Empresa em, Articulo art, Integer car, Long fecha) {
        Precios res = null;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            List lp = session.createQuery("from Precios where iid_empresa = " + em.getIid() + " and iid_art = " + art.getIid() + " and iid_car = " + car + " and fecha <= "+ fecha +" order by fecha desc").list();
            if (lp.size() > 0) {
                res = (Precios) lp.get(0);
            } 
        } catch (Exception e) {
            res = null;
        }
        return res;
    }    
        
        
     public static List obtenerRegistroPrecios (Empresa em, Articulo art, Integer car) {
        List lp = new ArrayList(); 
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
              
        try {
            lp =  session.createQuery("from Precios where iid_empresa = " + em.getIid() + " and iid_art = " + art.getIid() + " and iid_car = " + car + "order by fecha desc").list();
            if (lp.size() < 1) {
               lp = null;
            }
        } catch (Exception e) {
            lp = null;
        }
        return lp;
    }
     
    public static List obtenerRegistroPreciosTotal (Empresa em, Articulo art) {
        List lp = new ArrayList(); 
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            lp = session.createQuery("from Precios where iid_empresa = " + em.getIid() + " and iid_art = " + art.getIid() + "order by iid_car, fecha desc").list();
            if (lp.size() < 1) {
               lp = null;
            }
        } catch (Exception e) {
            lp = null;
        }
        return lp;
    }
       
    public static Double getPMP(Integer iidArticulo, Integer iidCaracteristica, Integer iidEmpresa) {
        Double res = null;
        List llin = new ArrayList();
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        try {
            if (!iidCaracteristica.equals(0)){
            llin = session.createQuery("select avg(lc.precio) from LineaPresupuesto lc inner join lc.presupuesto_iid as p"
                    + " where p.clase_documento = 7 and p.empresa = "+ iidEmpresa +" and lc.articulo_iid = " + iidArticulo +" and caracteristica = " +iidCaracteristica ).list();
				if (llin != null) {
					res = (Double) llin.get(0);
				}
            }else{
                 llin = session.createQuery("select avg(lc.precio) from LineaPresupuesto lc inner join lc.presupuesto_iid as p"
                    + " where p.clase_documento = 7 and p.empresa = "+ iidEmpresa +" and lc.articulo_iid = " + iidArticulo +" and caracteristica is null" ).list();
				if (llin != null) {
					res = (Double) llin.get(0);
				}
            }
        } catch (Exception e) {
            res = null;
        }
        return res;
    }
	
	public static boolean convertirDocumentoParcial(Presupuesto presupuestoNuevo, Presupuesto presupuestoAntiguo, List<LineaPresupuesto> listaLineaPresupuestos, Usuario u, Presupuesto presupuestoInterlocutor, String serie, Integer iidEmpresa, Integer iidEmpresaI, Agentes aI) {
        boolean res = true;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        boolean hayInterlocutor = presupuestoInterlocutor != null;
        Integer iidEmpresaMeta = iidEmpresa;
        Integer iidFp2;
        try {

            String claseDocumento = presupuestoNuevo.getClase_documento().getDescripcion();
            Metadata num = null;
            Metadata anio = null;
            String numeroDocumento = "";
            String anioDocumento = "";
            
            iidFp2 = (Integer) session.save(presupuestoNuevo.getFp());
            presupuestoNuevo.getFp().setIid(iidFp2);

            if (claseDocumento.equals(Constantes.ALBARAN)) {
                if (iidEmpresa.equals(presupuestoAntiguo.getInterlocutor())) {
                    if (serie.equals(Constantes.SERIE_STD)) {
                        numeroDocumento = "numAlbaran";
                        anioDocumento = "anioAlbaran";
                    } else {
                        numeroDocumento = "numAlbaranB";
                        anioDocumento = "anioAlbaranB";
                    }
                } else {
                    if (serie.equals(Constantes.SERIE_STD)) {
                        numeroDocumento = "numAlbaran";
                        anioDocumento = "anioAlbaran";
                    } else {
                        numeroDocumento = "numAlbaranB";
                        anioDocumento = "anioAlbaranB";
                    }
                    iidEmpresaMeta = iidEmpresaI;
                }
            } else if (claseDocumento.equals(Constantes.FACTURA) || claseDocumento.equals(Constantes.FACTURAA)) {
                numeroDocumento = "numFactura";
                anioDocumento = "anioFactura";
            } else if (claseDocumento.equals(Constantes.PEDIDO)) {
		numeroDocumento = "numPedido";
                anioDocumento = "anioPedido";
            } else if (claseDocumento.equals(Constantes.PEDIDOC)) {
                numeroDocumento = "numPedidoF";
                anioDocumento = "anioPedidoF";
            } else if (claseDocumento.equals(Constantes.ALBARANC)) {
                numeroDocumento = "numAlbaranF";
                anioDocumento = "anioAlbaranF";
            } else if (claseDocumento.equals(Constantes.FACTURAC)) {
                numeroDocumento = "numFacturaF";
                anioDocumento = "anioFacturaF";
            }

            List listaMetadataNum = session.createQuery("from Metadata where nombre='" + numeroDocumento + "' and iid_empresa = " + iidEmpresaMeta).list();
            if (listaMetadataNum.size() >= 1) {
                num = ((Metadata) listaMetadataNum.get(0));
            }

            List listaMetadataAnio = session.createQuery("from Metadata where nombre='" + anioDocumento + "' and iid_empresa = " + iidEmpresaMeta).list();
            if (listaMetadataAnio.size() >= 1) {
                anio = ((Metadata) listaMetadataAnio.get(0));
            }

            String numero;

            String numPresupuestoS = num.getValor();
            int numPresupuestoI = Integer.valueOf(numPresupuestoS);

            num.setValor(String.valueOf(numPresupuestoI + 1));
            numero = anio.getValor() + "/" + num.getValor();

            session.update(num);

            presupuestoNuevo.setNumero(numero);

            int contadorLineas = 1;
            Integer iidPresupuestoNuevo, iidPresupuestoInterlocutor;
            Integer iidLineaPresupuestoCopiada, iidLineaPresupuestoInterlocutor;
            Integer iidVpCopiada, iidVpCopiadaInterlocutor;
            Integer iidDpCopiado, iidDpCopiadoInterlocutor;
            HashMap<Integer, Integer> mapaCodigos = new HashMap<Integer, Integer>();
            LineaPresupuesto lp, lpOriginal, lpCopiada, lpCopiadaInterlocutor;
            DacPresupuesto dp, dpCopiado, dpCopiadoInterlocutor = null;
            VariablePresupuesto vp, vpCopiada, vpCopiadaInterlocutor;
            SeleccionPresupuesto sp, spCopiada, spCopiadaInterlocutor;
            DespiecePresupuesto desp, despCopiado, despCopiadoInterlocutor;
            MovimientoAlmacen ma;
            Articulo ar;
            TipoMovimientoAlmacen tma = null;
            FamiliaVenta fv;
            TipoControl tc;
            UnidadMedida t;
            Date fecha = new Date();
            Iterator it = listaLineaPresupuestos.iterator();
            Iterator iter2, iter3;
            Double importeD = 0.0;
            Double importeI = 0.0;
            List<Integer> listaLineasCopiadas = new ArrayList<Integer>();
            List<DacPresupuesto> listaDacPresupuesto;
            List<VariablePresupuesto> listaVariablePresupuesto;
            List<DespiecePresupuesto> listaDespiecePresupuesto;
            List<SeleccionPresupuesto> listaSeleccionPresupuesto;
            List<TipoMovimientoAlmacen> listaTipoMovimientoAlmacen;
            Almacen almac = (Almacen) session.createQuery("from Almacen where iid = " + presupuestoNuevo.getAlmacen().getIid()).list().get(0);
            listaTipoMovimientoAlmacen = session.createQuery("from TipoMovimientoAlmacen where nombre='" + Constantes.TIPO_MOVIMIENTO_ALMACEN_COMPRA + "'").list();
            if (listaTipoMovimientoAlmacen != null && listaTipoMovimientoAlmacen.size() > 0) {
                tma = listaTipoMovimientoAlmacen.get(0);
            }

            iidPresupuestoNuevo = (Integer) session.save(presupuestoNuevo);
            presupuestoNuevo.setIid(iidPresupuestoNuevo);

            if (hayInterlocutor) {
                listaMetadataNum = session.createQuery("from Metadata where nombre='numAlbaran' and iid_empresa = " + iidEmpresa).list();
                if (listaMetadataNum.size() >= 1) {
                    num = ((Metadata) listaMetadataNum.get(0));
                }

                listaMetadataAnio = session.createQuery("from Metadata where nombre='anioAlbaran' and iid_empresa = " + iidEmpresa).list();
                if (listaMetadataAnio.size() >= 1) {
                    anio = ((Metadata) listaMetadataAnio.get(0));
                }

                numPresupuestoS = num.getValor();
                numPresupuestoI = Integer.valueOf(numPresupuestoS);

                num.setValor(String.valueOf(numPresupuestoI + 1));
                numero = anio.getValor() + "/" + num.getValor();
                session.update(num);

                presupuestoInterlocutor.setNumero(numero);
                iidPresupuestoInterlocutor = (Integer) session.save(presupuestoInterlocutor);
                presupuestoInterlocutor.setIid(iidPresupuestoInterlocutor);
            }

            while (it.hasNext()) {
                lp = (LineaPresupuesto) it.next();

                lpCopiada = lp.copiar(presupuestoNuevo);
                lpOriginal = (LineaPresupuesto) session.createQuery("from LineaPresupuesto where iid = " + lp.getIid()).list().get(0);

                mapaCodigos.put(lpCopiada.getCodigo(), contadorLineas);

                lpCopiada.setCodigo(contadorLineas);
                if (lpOriginal.getCantidadRec() == null) {
                    lpOriginal.setCantidadRec(0.0D);
                }
                //Comprobamos que la cantidad a restar 
                if (lpOriginal.getCantidad() != null && lpOriginal.getCantidad() >= lpCopiada.getCantidad()) {
                    lpOriginal.setCantidadRec(lpOriginal.getCantidadRec() + lpCopiada.getCantidad());
                    lpOriginal.setCantidad(lpOriginal.getCantidad());
                    session.update(lpOriginal);
                }

                if (lpOriginal.getCantidad() != null && !lpOriginal.getCantidad().isNaN()) {
                    lpCopiada.setImporte(matematico.Matematico.redondear2decimales((lpOriginal.getImporte() * lpCopiada.getCantidad()) / lpOriginal.getCantidad()));
                }

                if (claseDocumento.equals(Constantes.FACTURAA) || claseDocumento.equals(Constantes.FACTURAC)) {
                    lpCopiada.setCantidad(-lpCopiada.getCantidad());
                    lpCopiada.setImporte(-lpCopiada.getImporte());
                }

                importeD += lpCopiada.getImporte();
                iidLineaPresupuestoCopiada = (Integer) session.save(lpCopiada);
                lpCopiada.setIid(iidLineaPresupuestoCopiada);
                listaLineasCopiadas.add(lp.getCodigo());

                if (hayInterlocutor) {
                    lpCopiadaInterlocutor = lpCopiada.copiar(presupuestoInterlocutor);
                    lpCopiadaInterlocutor.setIid(null);
                    calcularPrecioInterlocutor(session, lpCopiadaInterlocutor, presupuestoAntiguo.getIid(), aI);
                    calcularDAC(session, lpCopiadaInterlocutor, presupuestoAntiguo.getIid());
                    iidLineaPresupuestoInterlocutor = (Integer) session.save(lpCopiadaInterlocutor);
                    lpCopiadaInterlocutor.setIid(iidLineaPresupuestoInterlocutor);
                    importeI += lpCopiadaInterlocutor.getImporte();
                }
                
                contadorLineas++;

                if (claseDocumento.equals(Constantes.ALBARANC)) {
                    ar = (Articulo) session.createQuery("from Articulo where iid = " + lpCopiada.getArticulo_iid().getIid()).list().get(0);
                    fv = (FamiliaVenta) session.createQuery("from FamiliaVenta where iid = " + ar.getIid_fam_venta().getIid()).list().get(0);
                    tc = (TipoControl) session.createQuery("from TipoControl where iid = " + fv.getIid_tipo_control().getIid()).list().get(0);

                    ma = new MovimientoAlmacen();
                    ma.setCantidad(Float.parseFloat(lpCopiada.getCantidad().toString()));
                    ma.setCantidad1(Float.parseFloat(lpCopiada.getMedida1().toString()));
                    ma.setCantidad2(Float.parseFloat(lpCopiada.getMedida2().toString()));
                    ma.setCantidad3(Float.parseFloat(lpCopiada.getMedida3().toString()));
                    ma.setCantidad4(Float.parseFloat(lpCopiada.getMedida4().toString()));
                    ma.setCantidad5(Float.parseFloat(lpCopiada.getMedida5().toString()));
                    ma.setCaracteristica(lpCopiada.getCaracteristica());
                    ma.setConcepto(Constantes.INVENTARIO_POR_DOCUMENTO_DE_COMPRAS);
                    ma.setEmpresa(presupuestoNuevo.getEmpresa());
                    ma.setFecha(fecha.getTime());
                    ma.setModificable(false);
                    ma.setTipoMovimiento(tma);
                    ma.setPresupuesto(presupuestoNuevo);
                    ma.setArticulo(ar);
                    ma.setAlmacen(almac);

                    if (tc.getUnidad1() != null) {
                        t = (UnidadMedida) session.createQuery("from UnidadMedida where iid=" + tc.getUnidad1().getIid()).list().get(0);
                        ma.setUnidadMedida1(t);
                    }
                    if (tc.getUnidad2() != null) {
                        ma.setUnidadMedida2(tc.getUnidad2().getIid());
                    }
                    if (tc.getUnidad3() != null) {
                        ma.setUnidadMedida3(tc.getUnidad3().getIid());
                    }
                    if (tc.getUnidad4() != null) {
                        ma.setUnidadMedida4(tc.getUnidad4().getIid());
                    }
                    if (tc.getUnidad5() != null) {
                        ma.setUnidadMedida5(tc.getUnidad5().getIid());
                    }
                    if (ar.getIid_unidad_medida() != null) {
                        t = (UnidadMedida) session.createQuery("from UnidadMedida where iid=" + ar.getIid_unidad_medida().getIid()).list().get(0);
                        ma.setUnidadMedidaTotal(t);
                    }

                    insertarMovimientoExistenciaSession(ma, session);
                }
            }

            listaDacPresupuesto = session.createQuery("from DacPresupuesto where presupuesto.iid = " + presupuestoAntiguo.getIid()).list();
            it = listaDacPresupuesto.iterator();

            vpCopiadaInterlocutor = null;
            while (it.hasNext()) {
                dp = (DacPresupuesto) it.next();
                if (listaLineasCopiadas.contains(dp.getCodigo())) {
                    dpCopiado = dp.copiar();

                    dpCopiado.setPresupuesto(presupuestoNuevo);
                    dpCopiado.setCodigo(mapaCodigos.get(dpCopiado.getCodigo()));
                    iidDpCopiado = (Integer) session.save(dpCopiado);
                    dpCopiado.setIid(iidDpCopiado);

                    if (hayInterlocutor) {
                        dpCopiadoInterlocutor = dp.copiar();
                        dpCopiadoInterlocutor.setPresupuesto(presupuestoInterlocutor);
                        dpCopiadoInterlocutor.setCodigo(mapaCodigos.get(dpCopiado.getCodigo()));
                        dpCopiadoInterlocutor.setIid(null);
                        iidDpCopiadoInterlocutor = (Integer) session.save(dpCopiadoInterlocutor);
                        dpCopiadoInterlocutor.setIid(iidDpCopiadoInterlocutor);
                    }

                    listaVariablePresupuesto = session.createQuery("from VariablePresupuesto where dacPresupuesto.iid = " + dp.getIid()).list();
                    iter2 = listaVariablePresupuesto.iterator();
                    while (iter2.hasNext()) {
                        vp = (VariablePresupuesto) iter2.next();
                        vpCopiada = vp.copiar();
                        vpCopiada.setDacPresupuesto(dpCopiado);
                        vpCopiada.setIid(null);
                        iidVpCopiada = (Integer) session.save(vpCopiada);
                        vpCopiada.setIid(iidVpCopiada);

                        if (hayInterlocutor) {
                            vpCopiadaInterlocutor = vp.copiar();
                            vpCopiadaInterlocutor.setDacPresupuesto(dpCopiadoInterlocutor);
                            vpCopiadaInterlocutor.setIid(null);
                            iidVpCopiadaInterlocutor = (Integer) session.save(vpCopiadaInterlocutor);
                            vpCopiadaInterlocutor.setIid(iidVpCopiadaInterlocutor);
                        }

                        listaSeleccionPresupuesto = session.createQuery("from SeleccionPresupuesto where variablePresupuesto.iid = " + vp.getIid()).list();
                        iter3 = listaSeleccionPresupuesto.iterator();

                        while (iter3.hasNext()) {
                            sp = (SeleccionPresupuesto) iter3.next();
                            spCopiada = sp.copiar();
                            spCopiada.setDacPresupuesto(dpCopiado);
                            spCopiada.setVariablePresupuesto(vpCopiada);
                            session.save(spCopiada);

                            if (hayInterlocutor) {
                                spCopiadaInterlocutor = sp.copiar();
                                spCopiadaInterlocutor.setDacPresupuesto(dpCopiadoInterlocutor);
                                spCopiadaInterlocutor.setVariablePresupuesto(vpCopiadaInterlocutor);
                                spCopiadaInterlocutor.setIid(null);
                                session.save(spCopiadaInterlocutor);
                            }
                        }
                    }

                    listaDespiecePresupuesto = session.createQuery("from DespiecePresupuesto where dacPresupuesto.iid = " + dp.getIid()).list();
                    iter2 = listaDespiecePresupuesto.iterator();
                    while (iter2.hasNext()) {
                        desp = (DespiecePresupuesto) iter2.next();
                        despCopiado = desp.copiar();
                        despCopiado.setDacPresupuesto(dpCopiado);
                        session.save(despCopiado);

                        if (hayInterlocutor) {
                            despCopiadoInterlocutor = desp.copiar();
                            despCopiadoInterlocutor.setDacPresupuesto(dpCopiadoInterlocutor);
                            despCopiadoInterlocutor.setIid(null);
                            session.save(despCopiadoInterlocutor);
                        }
                    }
                }
            }

            Iva ivaP;
            
            if (presupuestoNuevo.getDto() > 0){
                importeD = importeD * (1 - (presupuestoNuevo.getDto() / 100));
            }
            if (presupuestoNuevo.getIva() != null) {
                ivaP = (Iva) session.createQuery("from Iva where iid = " + presupuestoNuevo.getIva().getIid()).list().get(0);
                importeD = importeD * (1 + (ivaP.getPorcentaje() / 100));
            }
            presupuestoNuevo.setImporte_total(importeD);
            session.update(presupuestoNuevo);
			
            session.update(presupuestoAntiguo);

            if(hayInterlocutor){
                if(presupuestoInterlocutor.getDto() > 0){
                    importeI = importeI * (1 - (presupuestoInterlocutor.getDto() / 100));
                }
                if (presupuestoInterlocutor.getIva() != null) {
                    ivaP = (Iva) session.createQuery("from Iva where iid = " + presupuestoInterlocutor.getIva().getIid()).list().get(0);
                    importeI = importeI * (1 + (ivaP.getPorcentaje() / 100));
                }
                presupuestoInterlocutor.setImporte_total(importeI);
                session.update(presupuestoInterlocutor);
            }
            
            Conversion c = new Conversion();
            c.setIidOrigen(presupuestoAntiguo.getIid());
            c.setIidDestino(presupuestoNuevo.getIid());

            Integer iFlujo = 0;
            List<Conversion> lc = session.createQuery("from Conversion where iidOrigen = " + presupuestoAntiguo.getIid() + "or iidDestino = " + presupuestoAntiguo.getIid()).list();
            if (lc != null && lc.size() > 0) {
                iFlujo = lc.get(0).getFlujo();
            }

            if (iFlujo != 0) {
                c.setFlujo(iFlujo);
            } else {
                c.setFlujo(presupuestoAntiguo.getIid());
            }

            session.save(c);

        } catch (Exception e) {
            e.printStackTrace();
            res = false;
            log.error("Error al procesar parcialmente el documento " + e);
            session.getTransaction().rollback();
        } finally {
            if (session.isOpen() && session.getTransaction().isActive()) {
                session.getTransaction().commit();
            }
        }

        return res;
    }

    public static Presupuesto convertirDocumentoCompleto(Presupuesto presupuestoNuevo, Presupuesto presupuestoAntiguo, Presupuesto presupuestoInterlocutor, Usuario u, Agentes aI, Integer iidEmpresaI, String serie, Empresa e) {

        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        boolean hayInterlocutor = presupuestoInterlocutor != null;
        boolean todoOk = true;
        String claseDocumento = presupuestoNuevo.getClase_documento().getDescripcion();
        Integer iidEmpresa = e.getIid();
        Integer iidEmpresaMeta = iidEmpresa;
        Integer iidFp2;

        try {
            iidFp2 = (Integer) session.save(presupuestoNuevo.getFp());
            presupuestoNuevo.getFp().setIid(iidFp2);

            presupuestoAntiguo.setConvertido(true);
            session.update(presupuestoAntiguo);

            Metadata num = null;
            Metadata anio = null;
            String numeroDocumento = "";
            String anioDocumento = "";

            if (claseDocumento.equals(Constantes.ALBARAN)) {
                if (iidEmpresa.equals(presupuestoAntiguo.getInterlocutor())) {
                    if (serie.equals(Constantes.SERIE_STD)) {
                        numeroDocumento = "numAlbaran";
                        anioDocumento = "anioAlbaran";
                    } else {
                        numeroDocumento = "numAlbaranB";
                        anioDocumento = "anioAlbaranB";
                    }
                } else {
                    if (serie.equals(Constantes.SERIE_STD)) {
                        numeroDocumento = "numAlbaran";
                        anioDocumento = "anioAlbaran";
                    } else {
                        numeroDocumento = "numAlbaranB";
                        anioDocumento = "anioAlbaranB";
                    }
                    iidEmpresaMeta = iidEmpresaI;
                }
            } else if (claseDocumento.equals(Constantes.FACTURA) || claseDocumento.equals(Constantes.FACTURAA)) {
                numeroDocumento = "numFactura";
                anioDocumento = "anioFactura";
            } else if (claseDocumento.equals(Constantes.PEDIDO)) {
		numeroDocumento = "numPedido";
                anioDocumento = "anioPedido";
            } else if (claseDocumento.equals(Constantes.PEDIDOC)) {
                numeroDocumento = "numPedidoF";
                anioDocumento = "anioPedidoF";
            } else if (claseDocumento.equals(Constantes.ALBARANC)) {
                numeroDocumento = "numAlbaranF";
                anioDocumento = "anioAlbaranF";
            } else if (claseDocumento.equals(Constantes.FACTURAC)) {
                numeroDocumento = "numFacturaF";
                anioDocumento = "anioFacturaF";
            }


            List listaMetadataNum = session.createQuery("from Metadata where nombre='" + numeroDocumento + "' and iid_empresa = " + iidEmpresaMeta).list();
            if (listaMetadataNum.size() >= 1) {
                num = ((Metadata) listaMetadataNum.get(0));
            }

            List listaMetadataAnio = session.createQuery("from Metadata where nombre='" + anioDocumento + "' and iid_empresa = " + iidEmpresaMeta).list();
            if (listaMetadataAnio.size() >= 1) {
                anio = ((Metadata) listaMetadataAnio.get(0));
            }

            String numPresupuestoS = num.getValor();
            int numPresupuestoI = Integer.valueOf(numPresupuestoS);

            num.setValor(String.valueOf(numPresupuestoI + 1));
            String numero = anio.getValor() + "/" + num.getValor();

            session.update(num);

            presupuestoNuevo.setNumero(numero);

            Integer iidPresupuestoNuevo = (Integer) session.save(presupuestoNuevo);
            presupuestoNuevo.setIid(iidPresupuestoNuevo);

            Integer iidPresupuestoInterlocutor = null;
            if (hayInterlocutor) {
                listaMetadataNum = session.createQuery("from Metadata where nombre='numAlbaran' and iid_empresa = " + iidEmpresa).list();
                if (listaMetadataNum.size() >= 1) {
                    num = ((Metadata) listaMetadataNum.get(0));
                }

                listaMetadataAnio = session.createQuery("from Metadata where nombre='anioAlbaran' and iid_empresa = " + iidEmpresa).list();
                if (listaMetadataAnio.size() >= 1) {
                    anio = ((Metadata) listaMetadataAnio.get(0));
                }

                numPresupuestoS = num.getValor();
                numPresupuestoI = Integer.valueOf(numPresupuestoS);

                num.setValor(String.valueOf(numPresupuestoI + 1));
                numero = anio.getValor() + "/" + num.getValor();
                session.update(num);

                presupuestoInterlocutor.setNumero(numero);
                iidPresupuestoInterlocutor = (Integer) session.save(presupuestoInterlocutor);
                presupuestoInterlocutor.setIid(iidPresupuestoInterlocutor);
            }

            Integer iidLineaPresupuesto, iidLineaPresupuestoInterlocutor;
            Integer iidDpCopiado, iidDpCopiadoInterlocutor;
            Integer iidVpCopiada, iidVpCopiadaInterlocutor;
            Integer iFlujo;
            Double importeI = 0.0;
            MovimientoAlmacen ma;
            LineaPresupuesto lineaPresupuesto, lpCopiadaInterlocutor;
            TipoMovimientoAlmacen tma = null;
            List<LineaPresupuesto> listaLineaPresupuesto;
            List<Conversion> lc;
            List<DacPresupuesto> listaDacPresupuesto;
            List<VariablePresupuesto> listaVariablePresupuesto;
            List<DespiecePresupuesto> listaDespiecePresupuesto;
            DacPresupuesto dp, dpCopiado, dpCopiadoInterlocutor;
            VariablePresupuesto vp, vpCopiada, vpCopiadaInterlocutor;
            SeleccionPresupuesto sp, spCopiada, spCopiadaInterlocutor;
            DespiecePresupuesto desp, despCopiado, despCopiadoInterlocutor;
            List listaSeleccionPresupuesto;
            Conversion c;
            Iterator it, it2;
            Iterator iter2, iter3;
            Articulo ar;
            FamiliaVenta fv;
            TipoControl tc;
            Date fecha = new Date();
            UnidadMedida t;
            List<TipoMovimientoAlmacen> listaTipoMovimientoAlmacen;
            Almacen almac = (Almacen) session.createQuery("from Almacen where iid = " + presupuestoNuevo.getAlmacen().getIid()).list().get(0);

            listaTipoMovimientoAlmacen = session.createQuery("from TipoMovimientoAlmacen where nombre='" + Constantes.TIPO_MOVIMIENTO_ALMACEN_COMPRA + "'").list();
            if (listaTipoMovimientoAlmacen != null && listaTipoMovimientoAlmacen.size() > 0) {
                tma = listaTipoMovimientoAlmacen.get(0);
            }

            //Se añaden las lineas de cada presupuesto asociado
            listaLineaPresupuesto = session.createQuery("from LineaPresupuesto where presupuesto_iid = " + presupuestoAntiguo.getIid()).list();
            it2 = listaLineaPresupuesto.iterator();
            while (it2.hasNext()) {
                lineaPresupuesto = (LineaPresupuesto) it2.next();

                if (presupuestoAntiguo.getClase_documento().getDescripcion().equals(Constantes.PEDIDOC)) {
                    lineaPresupuesto.setCantidadRec(lineaPresupuesto.getCantidad());
                    session.update(lineaPresupuesto);
                }

                if (hayInterlocutor) {
                    lpCopiadaInterlocutor = lineaPresupuesto.copiar(presupuestoInterlocutor);
                    lpCopiadaInterlocutor.setIid(null);
                    calcularPrecioInterlocutor(session, lpCopiadaInterlocutor, presupuestoAntiguo.getIid(), aI);
                    calcularDAC(session, lpCopiadaInterlocutor, presupuestoAntiguo.getIid());
                    iidLineaPresupuestoInterlocutor = (Integer) session.save(lpCopiadaInterlocutor);
                    lpCopiadaInterlocutor.setIid(iidLineaPresupuestoInterlocutor);
                    importeI += lpCopiadaInterlocutor.getImporte();
                }

                lineaPresupuesto = lineaPresupuesto.copiar(presupuestoNuevo);
                lineaPresupuesto.setIid(null);
                lineaPresupuesto.setPresupuesto_iid(presupuestoNuevo);
                if (claseDocumento.equals(Constantes.FACTURAA) || claseDocumento.equals(Constantes.FACTURAC)) {
                    lineaPresupuesto.setImporte(-lineaPresupuesto.getImporte());
                    lineaPresupuesto.setCantidad(-lineaPresupuesto.getCantidad());
                }
                iidLineaPresupuesto = (Integer) session.save(lineaPresupuesto);
                lineaPresupuesto.setIid(iidLineaPresupuesto);

                if (claseDocumento.equals(Constantes.ALBARANC)) {
                    ar = (Articulo) session.createQuery("from Articulo where iid = " + lineaPresupuesto.getArticulo_iid().getIid()).list().get(0);
                    fv = (FamiliaVenta) session.createQuery("from FamiliaVenta where iid = " + ar.getIid_fam_venta().getIid()).list().get(0);
                    tc = (TipoControl) session.createQuery("from TipoControl where iid = " + fv.getIid_tipo_control().getIid()).list().get(0);

                    ma = new MovimientoAlmacen();
                    ma.setCantidad(Float.parseFloat(lineaPresupuesto.getCantidad().toString()));
                    ma.setCantidad1(Float.parseFloat(lineaPresupuesto.getMedida1().toString()));
                    ma.setCantidad2(Float.parseFloat(lineaPresupuesto.getMedida2().toString()));
                    ma.setCantidad3(Float.parseFloat(lineaPresupuesto.getMedida3().toString()));
                    ma.setCantidad4(Float.parseFloat(lineaPresupuesto.getMedida4().toString()));
                    ma.setCantidad5(Float.parseFloat(lineaPresupuesto.getMedida5().toString()));
                    ma.setCaracteristica(lineaPresupuesto.getCaracteristica());
                    ma.setConcepto(Constantes.INVENTARIO_POR_DOCUMENTO_DE_COMPRAS);
                    ma.setEmpresa(e);
                    ma.setFecha(fecha.getTime());
                    ma.setModificable(false);
                    ma.setTipoMovimiento(tma);
                    ma.setPresupuesto(presupuestoNuevo);
                    ma.setArticulo(ar);
                    ma.setAlmacen(almac);

                    if (tc.getUnidad1() != null) {
                        t = (UnidadMedida) session.createQuery("from UnidadMedida where iid=" + tc.getUnidad1().getIid()).list().get(0);
                        ma.setUnidadMedida1(t);
                    }
                    if (tc.getUnidad2() != null) {
                        ma.setUnidadMedida2(tc.getUnidad2().getIid());
                    }
                    if (tc.getUnidad3() != null) {
                        ma.setUnidadMedida3(tc.getUnidad3().getIid());
                    }
                    if (tc.getUnidad4() != null) {
                        ma.setUnidadMedida4(tc.getUnidad4().getIid());
                    }
                    if (tc.getUnidad5() != null) {
                        ma.setUnidadMedida5(tc.getUnidad5().getIid());
                    }
                    if (ar.getIid_unidad_medida() != null) {
                        t = (UnidadMedida) session.createQuery("from UnidadMedida where iid=" + ar.getIid_unidad_medida().getIid()).list().get(0);
                        ma.setUnidadMedidaTotal(t);
                    }

                    insertarMovimientoExistenciaSession(ma, session);
                }
            }

            //se añaden los datos de conversion de cada presupuesto asociado
            c = new Conversion();
            c.setIidOrigen(presupuestoAntiguo.getIid());
            c.setIidDestino(presupuestoNuevo.getIid());

            iFlujo = 0;
            lc = session.createQuery("from Conversion where iidOrigen = " + presupuestoAntiguo.getIid() + "or iidDestino = " + presupuestoAntiguo.getIid()).list();
            if (lc != null && lc.size() > 0) {
                iFlujo = lc.get(0).getFlujo();
            }

            if (iFlujo != 0) {
                c.setFlujo(iFlujo);
            } else {
                c.setFlujo(presupuestoAntiguo.getIid());
            }

            session.save(c);

            listaDacPresupuesto = session.createQuery("from DacPresupuesto where presupuesto.iid = " + presupuestoAntiguo.getIid()).list();
            it = listaDacPresupuesto.iterator();
            dpCopiadoInterlocutor = null;
            
            while (it.hasNext()) {
                dp = (DacPresupuesto) it.next();
                dpCopiado = dp.copiar();
                dpCopiado.setPresupuesto(presupuestoNuevo);
                dpCopiado.setIid(null);
                iidDpCopiado = (Integer) session.save(dpCopiado);
                dpCopiado.setIid(iidDpCopiado);

                if (hayInterlocutor) {
                    dpCopiadoInterlocutor = dp.copiar();
                    dpCopiadoInterlocutor.setPresupuesto(presupuestoInterlocutor);
                    dpCopiadoInterlocutor.setIid(null);
                    iidDpCopiadoInterlocutor = (Integer) session.save(dpCopiadoInterlocutor);
                    dpCopiadoInterlocutor.setIid(iidDpCopiadoInterlocutor);
                }

                listaVariablePresupuesto = session.createQuery("from VariablePresupuesto where dacPresupuesto.iid = " + dp.getIid()).list();
                iter2 = listaVariablePresupuesto.iterator();
                vpCopiadaInterlocutor = null;
                while (iter2.hasNext()) {
                    vp = (VariablePresupuesto) iter2.next();
                    vpCopiada = vp.copiar();
                    vpCopiada.setDacPresupuesto(dpCopiado);
                    vpCopiada.setIid(null);
                    iidVpCopiada = (Integer) session.save(vpCopiada);
                    vpCopiada.setIid(iidVpCopiada);

                    if (hayInterlocutor) {
                        vpCopiadaInterlocutor = vp.copiar();
                        vpCopiadaInterlocutor.setDacPresupuesto(dpCopiadoInterlocutor);
                        vpCopiadaInterlocutor.setIid(null);
                        iidVpCopiadaInterlocutor = (Integer) session.save(vpCopiadaInterlocutor);
                        vpCopiadaInterlocutor.setIid(iidVpCopiadaInterlocutor);
                    }

                    listaSeleccionPresupuesto = session.createQuery("from SeleccionPresupuesto where variablePresupuesto.iid = " + vp.getIid()).list();
                    iter3 = listaSeleccionPresupuesto.iterator();

                    while (iter3.hasNext()) {
                        sp = (SeleccionPresupuesto) iter3.next();
                        spCopiada = sp.copiar();
                        spCopiada.setDacPresupuesto(dpCopiado);
                        spCopiada.setVariablePresupuesto(vpCopiada);
                        spCopiada.setIid(null);
                        session.save(spCopiada);

                        if (hayInterlocutor) {
                            spCopiadaInterlocutor = sp.copiar();
                            spCopiadaInterlocutor.setDacPresupuesto(dpCopiadoInterlocutor);
                            spCopiadaInterlocutor.setVariablePresupuesto(vpCopiadaInterlocutor);
                            spCopiadaInterlocutor.setIid(null);
                            session.save(spCopiadaInterlocutor);
                        }
                    }
                }

                listaDespiecePresupuesto = session.createQuery("from DespiecePresupuesto where dacPresupuesto.iid = " + dp.getIid()).list();
                iter2 = listaDespiecePresupuesto.iterator();
                while (iter2.hasNext()) {
                    desp = (DespiecePresupuesto) iter2.next();
                    despCopiado = desp.copiar();
                    despCopiado.setDacPresupuesto(dpCopiado);
                    despCopiado.setIid(null);
                    session.save(despCopiado);

                    if (hayInterlocutor) {
                        despCopiadoInterlocutor = desp.copiar();
                        despCopiadoInterlocutor.setDacPresupuesto(dpCopiadoInterlocutor);
                        despCopiadoInterlocutor.setIid(null);
                        session.save(despCopiadoInterlocutor);
                    }
                }
            }
            
            if(hayInterlocutor){
                if(presupuestoInterlocutor.getDto() > 0){
                    importeI = importeI * (1 - (presupuestoInterlocutor.getDto() / 100));
                }
                if (presupuestoInterlocutor.getIva() != null) {
                    Iva ivaP = (Iva) session.createQuery("from Iva where iid = " + presupuestoInterlocutor.getIva().getIid()).list().get(0);
                    importeI = importeI * (1 + (ivaP.getPorcentaje() / 100));
                }
                presupuestoInterlocutor.setImporte_total(importeI);
                session.update(presupuestoInterlocutor);
            }	
        } catch (Exception ex) {
            todoOk = false;
            ex.printStackTrace();
            log.error("Error al procesar el documento completo " + ex);
            session.getTransaction().rollback();
        } finally {
            if (session.isOpen() && session.getTransaction().isActive()) {
                session.getTransaction().commit();
            }
        }

        if (todoOk) {
            return presupuestoNuevo;
        } else {
            return null;
        }
    }

    public static boolean convertirVariosDocumentos(Presupuesto presupuestoNuevo, List<Presupuesto> lineasFinal, Presupuesto presupuestoInterlocutor, Agentes aI, Usuario u, String serie, Integer iidEmpresa, Integer iidEmpresaI) {
        boolean res = true;
        Session session = HibernateUtil.getSessionFactory().getCurrentSession();
        session.beginTransaction();
        boolean hayInterlocutor = presupuestoInterlocutor != null;
        Presupuesto presupuestoAntiguo = lineasFinal.get(0);
        Integer iidEmpresaMeta = iidEmpresa;
        String claseDocumento = presupuestoNuevo.getClase_documento().getDescripcion();
        
        try {
            Metadata num = null;
            Metadata anio = null;
            String numeroDocumento = "";
            String anioDocumento = "";

            if (claseDocumento.equals(Constantes.ALBARAN)) {
                if (iidEmpresa.equals(presupuestoAntiguo.getInterlocutor())) {
                    if (serie.equals(Constantes.SERIE_STD)) {
                        numeroDocumento = "numAlbaran";
                        anioDocumento = "anioAlbaran";
                    } else {
                        numeroDocumento = "numAlbaranB";
                        anioDocumento = "anioAlbaranB";
                    }
                } else {
                    if (serie.equals(Constantes.SERIE_STD)) {
                        numeroDocumento = "numAlbaran";
                        anioDocumento = "anioAlbaran";
                    } else {
                        numeroDocumento = "numAlbaranB";
                        anioDocumento = "anioAlbaranB";
                    }
                    iidEmpresaMeta = iidEmpresaI;
                }
            } else if (claseDocumento.equals(Constantes.FACTURA) || claseDocumento.equals(Constantes.FACTURAA)) {
                numeroDocumento = "numFactura";
                anioDocumento = "anioFactura";
            } else if (claseDocumento.equals(Constantes.PEDIDO)) {
		numeroDocumento = "numPedido";
                anioDocumento = "anioPedido";
            } else if (claseDocumento.equals(Constantes.PEDIDOC)) {
                numeroDocumento = "numPedidoF";
                anioDocumento = "anioPedidoF";
            } else if (claseDocumento.equals(Constantes.ALBARANC)) {
                numeroDocumento = "numAlbaranF";
                anioDocumento = "anioAlbaranF";
            } else if (claseDocumento.equals(Constantes.FACTURAC)) {
                numeroDocumento = "numFacturaF";
                anioDocumento = "anioFacturaF";
            }

            List listaMetadataNum = session.createQuery("from Metadata where nombre='" + numeroDocumento + "' and iid_empresa = " + iidEmpresaMeta).list();
            if (listaMetadataNum.size() >= 1) {
                num = ((Metadata) listaMetadataNum.get(0));
            }

            List listaMetadataAnio = session.createQuery("from Metadata where nombre='" + anioDocumento + "' and iid_empresa = " + iidEmpresaMeta).list();
            if (listaMetadataAnio.size() >= 1) {
                anio = ((Metadata) listaMetadataAnio.get(0));
            }

            String numero;

            String numPresupuestoS = num.getValor();
            int numPresupuestoI = Integer.valueOf(numPresupuestoS);

            num.setValor(String.valueOf(numPresupuestoI + 1));
            numero = anio.getValor() + "/" + num.getValor();

            session.update(num);

            presupuestoNuevo.setNumero(numero);
            presupuestoNuevo.setAlmacen(presupuestoAntiguo.getAlmacen());

            Integer iidFp2 = (Integer) session.save(presupuestoNuevo.getFp());
            presupuestoNuevo.getFp().setIid(iidFp2);

            Integer iidPresupuestoNuevo = (Integer) session.save(presupuestoNuevo);
            presupuestoNuevo.setIid(iidPresupuestoNuevo);

            Integer iidPresupuestoInterlocutor = null;
            if (hayInterlocutor) {

                listaMetadataNum = session.createQuery("from Metadata where nombre='numAlbaran' and iid_empresa = " + iidEmpresa).list();
                if (listaMetadataNum.size() >= 1) {
                    num = ((Metadata) listaMetadataNum.get(0));
                }

                listaMetadataAnio = session.createQuery("from Metadata where nombre='anioAlbaran' and iid_empresa = " + iidEmpresa).list();
                if (listaMetadataAnio.size() >= 1) {
                    anio = ((Metadata) listaMetadataAnio.get(0));
                }

                numPresupuestoS = num.getValor();
                numPresupuestoI = Integer.valueOf(numPresupuestoS);

                num.setValor(String.valueOf(numPresupuestoI + 1));
                numero = anio.getValor() + "/" + num.getValor();
                session.update(num);

                presupuestoInterlocutor.setNumero(numero);
                iidPresupuestoInterlocutor = (Integer) session.save(presupuestoInterlocutor);
                presupuestoInterlocutor.setIid(iidPresupuestoInterlocutor);
            }

            Integer iidLineaPresupuesto, iidLineaPresupuestoInterlocutor;
            Integer iidDpCopiado, iidDpCopiadoInterlocutor;
            Integer iidVpCopiada, iidVpCopiadaInterlocutor;
            Integer iFlujo;
            Presupuesto pres;
            MovimientoAlmacen ma;
            Double importeI = 0.0D, importeD = 0.0D;
            LineaPresupuesto lineaPresupuesto, lpCopiadaInterlocutor;
            HashMap<Integer, Integer> mapaCodigos = new HashMap<Integer, Integer>();
            int contadorLineas = 1;
            List<TipoMovimientoAlmacen> lAlmacenes;
            TipoMovimientoAlmacen tma;
            List<LineaPresupuesto> listaLineaPresupuesto;
            List<Conversion> lc;
            List<DacPresupuesto> listaDacPresupuesto;
            List<VariablePresupuesto> listaVariablePresupuesto;
            List<DespiecePresupuesto> listaDespiecePresupuesto;
            DacPresupuesto dp, dpCopiado, dpCopiadoInterlocutor;
            VariablePresupuesto vp, vpCopiada, vpCopiadaInterlocutor;
            SeleccionPresupuesto sp, spCopiada, spCopiadaInterlocutor;
            DespiecePresupuesto desp, despCopiado, despCopiadoInterlocutor;
            List listaSeleccionPresupuesto;
            Conversion c;
            Iterator it, it2, iter2, iter3;
            Iterator iter = lineasFinal.iterator();
            while (iter.hasNext()) {
                pres = (Presupuesto) iter.next();

                //Se añaden las lineas de cada presupuesto asociado
                listaLineaPresupuesto = session.createQuery("from LineaPresupuesto where presupuesto_iid = " + pres.getIid()).list();
                it2 = listaLineaPresupuesto.iterator();
                while (it2.hasNext()) {
                    lineaPresupuesto = (LineaPresupuesto) it2.next();
                    lineaPresupuesto = lineaPresupuesto.copiar(presupuestoNuevo);
                    lineaPresupuesto.setPresupuesto_iid(presupuestoNuevo);
                    
                    mapaCodigos.put(lineaPresupuesto.getCodigo(), contadorLineas);
                    lineaPresupuesto.setCodigo(contadorLineas);
                    
                    if (claseDocumento.equals(Constantes.FACTURAA) || claseDocumento.equals(Constantes.FACTURAC)) {
                        lineaPresupuesto.setImporte(-lineaPresupuesto.getImporte());
                        lineaPresupuesto.setCantidad(-lineaPresupuesto.getCantidad());
                    }
                    iidLineaPresupuesto = (Integer) session.save(lineaPresupuesto);
                    lineaPresupuesto.setIid(iidLineaPresupuesto);
                    importeD += lineaPresupuesto.getImporte();

                    /*if (hayInterlocutor) {
                        lpCopiadaInterlocutor = lineaPresupuesto.copiar(presupuestoInterlocutor);
                        lpCopiadaInterlocutor.setIid(null);
                        calcularPrecioInterlocutor(session, lpCopiadaInterlocutor, presupuestoAntiguo.getIid(), aI);
                        calcularDAC(session, lpCopiadaInterlocutor, presupuestoAntiguo.getIid());
                        iidLineaPresupuestoInterlocutor = (Integer) session.save(lpCopiadaInterlocutor);
                        lpCopiadaInterlocutor.setIid(iidLineaPresupuestoInterlocutor);
                        importeI += lpCopiadaInterlocutor.getImporte();
                    }*/
                    
                    contadorLineas++;
                    
                    if (claseDocumento.equals(Constantes.ALBARANC)) {
                        ma = new MovimientoAlmacen();
                        ma.setCantidad(Float.parseFloat(lineaPresupuesto.getCantidad().toString()));
                        ma.setCantidad1(Float.parseFloat(lineaPresupuesto.getMedida1().toString()));
                        ma.setCantidad2(Float.parseFloat(lineaPresupuesto.getMedida2().toString()));
                        ma.setCantidad3(Float.parseFloat(lineaPresupuesto.getMedida3().toString()));
                        ma.setCantidad4(Float.parseFloat(lineaPresupuesto.getMedida4().toString()));
                        ma.setCantidad5(Float.parseFloat(lineaPresupuesto.getMedida5().toString()));
                        if (lineaPresupuesto.getCaracteristica() != null) {
                            ma.setCaracteristica(lineaPresupuesto.getCaracteristica());
                        } else {
                            ma.setCaracteristica(null);
                        }
                        ma.setConcepto(Constantes.INVENTARIO_POR_DOCUMENTO_DE_COMPRAS);
                        ma.setEmpresa(presupuestoNuevo.getEmpresa());
                        ma.setFecha(new Date().getTime());
                        ma.setModificable(false);
                        ma.setPresupuesto(presupuestoNuevo);
                        ma.setAlmacen(presupuestoNuevo.getAlmacen());
                        ma.setArticulo(lineaPresupuesto.getArticulo_iid());

                        lAlmacenes = session.createQuery("from TipoMovimientoAlmacen where nombre='" + Constantes.TIPO_MOVIMIENTO_ALMACEN_COMPRA + "'").list();
                        if (lAlmacenes.size() >= 1) {
                            tma = ((TipoMovimientoAlmacen) lAlmacenes.get(0));
                        } else {
                            tma = null;
                        }
                        ma.setTipoMovimiento(tma);
                        insertarMovimientoExistenciaSession(ma, session);
                    }
                }

                //se añaden los datos de conversion de cada presupuesto asociado
                c = new Conversion();
                c.setIidOrigen(pres.getIid());
                c.setIidDestino(presupuestoNuevo.getIid());

                iFlujo = 0;
                lc = session.createQuery("from Conversion where iidOrigen = " + pres.getIid() + "or iidDestino = " + pres.getIid()).list();
                if (lc != null && lc.size() > 0) {
                    iFlujo = lc.get(0).getFlujo();
                }

                if (iFlujo != 0) {
                    c.setFlujo(iFlujo);
                } else {
                    c.setFlujo(pres.getIid());
                }

                session.save(c);

                listaDacPresupuesto = session.createQuery("from DacPresupuesto where presupuesto.iid = " + pres.getIid()).list();
                it = listaDacPresupuesto.iterator();
                dpCopiadoInterlocutor = null;
                vpCopiadaInterlocutor = null;
                while (it.hasNext()) {
                    dp = (DacPresupuesto) it.next();
                    dpCopiado = dp.copiar();
                    dpCopiado.setPresupuesto(presupuestoNuevo);
                    dpCopiado.setCodigo(mapaCodigos.get(dpCopiado.getCodigo()));
                    dpCopiado.setIid(null);
                    iidDpCopiado = (Integer) session.save(dpCopiado);
                    dpCopiado.setIid(iidDpCopiado);

                    listaVariablePresupuesto = session.createQuery("from VariablePresupuesto where dacPresupuesto.iid = " + dp.getIid()).list();
                    iter2 = listaVariablePresupuesto.iterator();
                    while (iter2.hasNext()) {
                        vp = (VariablePresupuesto) iter2.next();
                        vpCopiada = vp.copiar();
                        vpCopiada.setDacPresupuesto(dpCopiado);
                        vpCopiada.setIid(null);
                        iidVpCopiada = (Integer) session.save(vpCopiada);
                        vpCopiada.setIid(iidVpCopiada);

                        listaSeleccionPresupuesto = session.createQuery("from SeleccionPresupuesto where variablePresupuesto.iid = " + vp.getIid()).list();
                        iter3 = listaSeleccionPresupuesto.iterator();

                        while (iter3.hasNext()) {
                            sp = (SeleccionPresupuesto) iter3.next();
                            spCopiada = sp.copiar();
                            spCopiada.setDacPresupuesto(dpCopiado);
                            spCopiada.setVariablePresupuesto(vpCopiada);
                            spCopiada.setIid(null);
                            session.save(spCopiada);
                        }
                    }

                    listaDespiecePresupuesto = session.createQuery("from DespiecePresupuesto where dacPresupuesto.iid = " + dp.getIid()).list();
                    iter2 = listaDespiecePresupuesto.iterator();
                    while (iter2.hasNext()) {
                        desp = (DespiecePresupuesto) iter2.next();
                        despCopiado = desp.copiar();
                        despCopiado.setDacPresupuesto(dpCopiado);
                        despCopiado.setIid(null);
                        session.save(despCopiado);
                    }
                }
                
                mapaCodigos.clear();
                pres.setConvertido(true);
                session.update(pres);
            }
            
            if (presupuestoNuevo.getDto() > 0) {
                importeD = importeD * (1 - (presupuestoNuevo.getDto() / 100));
            }
            if (presupuestoNuevo.getIva() != null) {
                Iva ivaP = (Iva) session.createQuery("from Iva where iid = " + presupuestoNuevo.getIva().getIid()).list().get(0);
                importeD = importeD * (1 + (ivaP.getPorcentaje() / 100));
            }
            presupuestoNuevo.setImporte_total(importeD);
            session.update(presupuestoNuevo);

            if(hayInterlocutor){
                //Se añaden las lineas de cada presupuesto asociado
                listaLineaPresupuesto = session.createQuery("from LineaPresupuesto where presupuesto_iid = " + presupuestoNuevo.getIid()).list();
                it2 = listaLineaPresupuesto.iterator();
                while (it2.hasNext()) {
                    lineaPresupuesto = (LineaPresupuesto) it2.next();
                    lpCopiadaInterlocutor = lineaPresupuesto.copiar(presupuestoInterlocutor);
                    lpCopiadaInterlocutor.setIid(null);
                    calcularPrecioInterlocutor(session, lpCopiadaInterlocutor, presupuestoNuevo.getIid(), aI);
                    calcularDAC(session, lpCopiadaInterlocutor, presupuestoNuevo.getIid());
                    iidLineaPresupuestoInterlocutor = (Integer) session.save(lpCopiadaInterlocutor);
                    lpCopiadaInterlocutor.setIid(iidLineaPresupuestoInterlocutor);
                    importeI += lpCopiadaInterlocutor.getImporte();
                }
                
                listaDacPresupuesto = session.createQuery("from DacPresupuesto where presupuesto.iid = " + presupuestoNuevo.getIid()).list();
                it = listaDacPresupuesto.iterator();
                dpCopiadoInterlocutor = null;
                vpCopiadaInterlocutor = null;
                while (it.hasNext()) {
                    dp = (DacPresupuesto) it.next();
                    dpCopiadoInterlocutor = dp.copiar();
                    dpCopiadoInterlocutor.setPresupuesto(presupuestoInterlocutor);
                    dpCopiadoInterlocutor.setIid(null);
                    iidDpCopiadoInterlocutor = (Integer) session.save(dpCopiadoInterlocutor);
                    dpCopiadoInterlocutor.setIid(iidDpCopiadoInterlocutor);

                    listaVariablePresupuesto = session.createQuery("from VariablePresupuesto where dacPresupuesto.iid = " + dp.getIid()).list();
                    iter2 = listaVariablePresupuesto.iterator();
                    while (iter2.hasNext()) {
                        vp = (VariablePresupuesto) iter2.next();
                        vpCopiadaInterlocutor = vp.copiar();
                        vpCopiadaInterlocutor.setDacPresupuesto(dpCopiadoInterlocutor);
                        vpCopiadaInterlocutor.setIid(null);
                        iidVpCopiadaInterlocutor = (Integer) session.save(vpCopiadaInterlocutor);
                        vpCopiadaInterlocutor.setIid(iidVpCopiadaInterlocutor);

                        listaSeleccionPresupuesto = session.createQuery("from SeleccionPresupuesto where variablePresupuesto.iid = " + vp.getIid()).list();
                        iter3 = listaSeleccionPresupuesto.iterator();

                        while (iter3.hasNext()) {
                            sp = (SeleccionPresupuesto) iter3.next();
                            spCopiadaInterlocutor = sp.copiar();
                            spCopiadaInterlocutor.setDacPresupuesto(dpCopiadoInterlocutor);
                            spCopiadaInterlocutor.setVariablePresupuesto(vpCopiadaInterlocutor);
                            spCopiadaInterlocutor.setIid(null);
                            session.save(spCopiadaInterlocutor);
                        }
                    }

                    listaDespiecePresupuesto = session.createQuery("from DespiecePresupuesto where dacPresupuesto.iid = " + dp.getIid()).list();
                    iter2 = listaDespiecePresupuesto.iterator();
                    while (iter2.hasNext()) {
                        desp = (DespiecePresupuesto) iter2.next();
                        despCopiadoInterlocutor = desp.copiar();
                        despCopiadoInterlocutor.setDacPresupuesto(dpCopiadoInterlocutor);
                        despCopiadoInterlocutor.setIid(null);
                        session.save(despCopiadoInterlocutor);
                    }
                }
                
                if(presupuestoInterlocutor.getDto() > 0){
                    importeI = importeI * (1 - (presupuestoInterlocutor.getDto() / 100));
                }
                if (presupuestoInterlocutor.getIva() != null) {
                    Iva ivaP = (Iva) session.createQuery("from Iva where iid = " + presupuestoInterlocutor.getIva().getIid()).list().get(0);
                    importeI = importeI * (1 + (ivaP.getPorcentaje() / 100));
                }
                presupuestoInterlocutor.setImporte_total(importeI);
                session.update(presupuestoInterlocutor);
            }
        } catch (Exception e) {
            e.printStackTrace();
            res = false;
            log.error("Error al procesar varios documentos " + e);
            session.getTransaction().rollback();
        } finally {
            if (session.isOpen() && session.getTransaction().isActive()) {
                session.getTransaction().commit();
            }
        }

        return res;
    }

    private static void calcularPrecioInterlocutor(Session session, LineaPresupuesto lp, Integer iidEmpresa, Agentes aI) throws ScriptException {

        Float fMedida1 = -1F;
        Float fMedida2 = -1F;
        Float fprecio = -1F;
        Float medidaTotal = -1F;
        Caracteristica car = null;

        Articulo ar = (Articulo) session.createQuery("from Articulo where iid = " + lp.getArticulo_iid().getIid()).list().get(0);
        FamiliaVenta fv = (FamiliaVenta) session.createQuery("from FamiliaVenta where iid = " + ar.getIid_fam_venta().getIid()).list().get(0);

        if (lp.getCaracteristica() != null) {
            car = (Caracteristica) session.createQuery("from Caracteristica where iid = " + lp.getCaracteristica().getIid()).list().get(0);
        }

        if (!lp.getMedida1().equals(0.0)) {
            fMedida1 = Float.parseFloat(Util.convertirComaAPunto(lp.getMedida1().toString()));
        }
        if (!lp.getMedida2().equals(0.0)) {
            fMedida2 = Float.parseFloat(Util.convertirComaAPunto(lp.getMedida2().toString()));
        }

        if (ar.getEscalado()) {
            fprecio = obtenerPrecioEscalado(session, ar.getIid(), null, fMedida1.intValue(), fMedida2.intValue());
        } else if (ar.getEscaladoCaracteristica()) {
            fprecio = obtenerPrecioEscalado(session, ar.getIid(), car.getIid(), fMedida1.intValue(), fMedida2.intValue());
        } else {
            if (car != null) {
                if (car.getPvp() != null) {
                    fprecio = car.getPvp();
                } else {
                    fprecio = 0F;
                }
            } else {
                if (ar.getPrecio_v() != null) {
                    fprecio = ar.getPrecio_v();
                } else {
                    fprecio = 0F;
                }
            }

            fprecio = matematico.Matematico.redondear2decimales(fprecio);
            lp.setPrecioArticulo(Double.parseDouble(fprecio.toString()));

            ScriptEngineManager manager = new ScriptEngineManager();
            ScriptEngine engine = manager.getEngineByName("js");

            engine.put("Dim1", Util.convertirComaAPunto(lp.getMedida1().toString()));
            engine.put("Dim2", Util.convertirComaAPunto(lp.getMedida2().toString()));
            engine.put("Dim3", Util.convertirComaAPunto(lp.getMedida3().toString()));
            engine.put("Dim4", Util.convertirComaAPunto(lp.getMedida4().toString()));
            engine.put("Dim5", Util.convertirComaAPunto(lp.getMedida5().toString()));

            TipoControl tc = (TipoControl) session.createQuery("from TipoControl where iid = " + fv.getIid_tipo_control().getIid()).list().get(0);
            TipoMedida tm = (TipoMedida) session.createQuery("from TipoMedida where iid = " + tc.getIid_tipo_medida().getIid()).list().get(0);
            String tipoCalculo = tm.getTipo_calculo();

            if (tipoCalculo.equals(Constantes.FORMULA)) {
                Double medidaTotalDouble = (Double) engine.eval(tm.getFormula());
                medidaTotal = Float.parseFloat(String.valueOf(medidaTotalDouble));
            } else {
                medidaTotal = Float.parseFloat(Util.convertirComaAPunto(lp.getMedida1().toString())) / 100;
            }

            if (ar.getEscalado() || ar.getEscaladoCaracteristica()) {
                medidaTotal = 1F;
            }

        }
        //Obtener descuento
        //Se ha de calcular el descuento segun la siguiente prioridad:
        //1.- Se usará el descuento que el cliente tenga para ese articulo
        //2.- Se usará el descuento que el cliente tenga para esa familia
        //3.- Se usará el descuento qeu el articulo tenga en si
        Double descuento = 0.0D;
        if (aI != null) {
            String codigoAgente = aI.getCod_agente();
            if (codigoAgente != null && codigoAgente.length() > 0) {
                List<Agentes> lagentes = session.createQuery("from Agentes where cod_agente ='" + codigoAgente + "' and iid_empresa = " + iidEmpresa).list();
                Agentes ag;
                if (lagentes != null && lagentes.size() > 0) {
                    ag = lagentes.get(0);
                    List<DescuentoClienteArticulo> listaDescuento = session.createQuery("from DescuentoClienteArticulo where cliente.iid = " + ag.getIid() + " and articulo.iid = " + ar.getIid()).list();
                    if (listaDescuento != null && listaDescuento.size() > 0) {
                        //Se toma el descuento del cliente
                        descuento = (listaDescuento.get(0)).getDescuento();
                    } else {
                        List<DescuentoClienteFamiliaVenta> listaDescuentoClienteFamiliaVenta = session.createQuery("from DescuentoClienteFamiliaVenta where cliente.iid = " + ag.getIid() + " and familiaVenta.iid = " + ar.getIid_fam_venta().getIid()).list();
                        if (listaDescuentoClienteFamiliaVenta != null && listaDescuentoClienteFamiliaVenta.size() > 0) {
                            //Se toma el descuento de la familia
                            descuento = listaDescuentoClienteFamiliaVenta.get(0).getDescuento();
                        } else if (ar.getDescuento() != null) {
                            descuento = Double.parseDouble(ar.getDescuento().toString());
                        }
                    }
                } else if (ar.getDescuento() != null) {
                    descuento = Double.parseDouble(ar.getDescuento().toString());
                }
            } else if (ar.getDescuento() != null) {
                descuento = Double.parseDouble(ar.getDescuento().toString());
            }
        }
        lp.setDescuento(descuento);

        Double precio = lp.getCantidad() * lp.getPrecioArticulo() * medidaTotal * (100 - lp.getDescuento()) / 100;
        precio = matematico.Matematico.redondear2decimales(precio);
        lp.setPrecio(lp.getPrecioArticulo());
        lp.setImporte(precio);
    }

    private static void calcularDAC(Session session, LineaPresupuesto lp, Integer iidPresupuesto) throws ScriptException {
        Float fMedida1 = -1F;
        Float fMedida2 = -1F;
        Float medidaTotal = -1F;

        //Comprobar si es un Producto
        Articulo ar = (Articulo) session.createQuery("from Articulo where iid = " + lp.getArticulo_iid().getIid()).list().get(0);
        FamiliaVenta fv = (FamiliaVenta) session.createQuery("from FamiliaVenta where iid = " + ar.getIid_fam_venta().getIid()).list().get(0);

        if (fv.getCod_familia().equals(Constantes.PRODUCTO_COMPUESTO)) {
            //Calculamos el precio del Producto
            ScriptEngineManager manager = new ScriptEngineManager();
            ScriptEngine engine = manager.getEngineByName("js");

            engine.put("Dim1", Util.convertirComaAPunto(lp.getMedida1().toString()));
            engine.put("Dim2", Util.convertirComaAPunto(lp.getMedida2().toString()));
            engine.put("Dim3", Util.convertirComaAPunto(lp.getMedida3().toString()));
            engine.put("Dim4", Util.convertirComaAPunto(lp.getMedida4().toString()));
            engine.put("Dim5", Util.convertirComaAPunto(lp.getMedida5().toString()));

            if (!lp.getMedida1().equals(0.0)) {
                fMedida1 = Float.parseFloat(Util.convertirComaAPunto(lp.getMedida1().toString()));
            }
            if (!lp.getMedida2().equals(0.0)) {
                fMedida2 = Float.parseFloat(Util.convertirComaAPunto(lp.getMedida2().toString()));
            }

            TipoControl tc = (TipoControl) session.createQuery("from TipoControl where iid = " + fv.getIid_tipo_control().getIid()).list().get(0);
            TipoMedida tm = (TipoMedida) session.createQuery("from TipoMedida where iid = " + tc.getIid_tipo_medida().getIid()).list().get(0);
            String tipoCalculo = tm.getTipo_calculo();

            if (tipoCalculo.equals(Constantes.FORMULA)) {
                Double medidaTotalDouble = null;
                medidaTotalDouble = (Double) engine.eval(tm.getFormula());
                medidaTotal = Float.parseFloat(String.valueOf(medidaTotalDouble));
            } else {
                medidaTotal = Float.parseFloat(Util.convertirComaAPunto(lp.getMedida1().toString())) / 100;
            }

            if (ar.getEscalado() || ar.getEscaladoCaracteristica()) {
                medidaTotal = 1F;
            }

            Double escalado = obtenerPrecioEscalado(session, ar.getIid(), null, fMedida1.intValue(), fMedida2.intValue()).doubleValue();
            Double precio = medidaTotal.doubleValue() * escalado;
            Double importe = precio;

            DacPresupuesto dp = obtenerDacPresupuestoByPresupuestoCodigo(iidPresupuesto, lp.getCodigo(), session);
            Integer iidDacPresupuesto = dp.getIid();
            List<VariablePresupuesto> listaV = session.createQuery("from VariablePresupuesto where dacPresupuesto.iid = " + iidDacPresupuesto).list();
            List<SeleccionPresupuesto> listaS = session.createQuery("from SeleccionPresupuesto where dacPresupuesto.iid = " + iidDacPresupuesto).list();
            List<DespiecePresupuesto> listaD = session.createQuery("from  DespiecePresupuesto where dacPresupuesto.iid = " + iidDacPresupuesto).list();

            RellenarDacBean rdBean = new RellenarDacBean(session, String.valueOf(lp.getCantidad()), String.valueOf(lp.getMedida1()), String.valueOf(lp.getMedida2()),
                    String.valueOf(lp.getMedida3()), String.valueOf(lp.getMedida4()), String.valueOf(lp.getMedida5()),
                    listaV, listaS, listaD);

            List<DespiecePresupuesto> lista = rdBean.getListaDespiece();
            Iterator<DespiecePresupuesto> iter = lista.iterator();
            DespiecePresupuesto despieceTemp;
            while (iter.hasNext()) {
                despieceTemp = iter.next();
                precio += rdBean.calcularPrecioDespiece(despieceTemp);
            }

            //DUDA: QUE PASA CON EL DESCUENTO QUE TUVIERA LA LINEA???
            precio = precio * lp.getCantidad();
            lp.setPrecio(importe);
            lp.setPrecioArticulo(importe);
            lp.setImporte(precio);
        }
    }

    public static Articulo obtenerArticuloPorIidBD(Integer iid, Session session) {
        return (Articulo) session.createQuery("from Articulo where iid = " + iid).list().get(0);
    }

    public static Caracteristica obtenerCaracteristicaPorIidBD(Integer iid, Session session) {
        return (Caracteristica) session.createQuery("from Caracteristica where iid = " + iid).list().get(0);
    }

    public static DacPresupuesto obtenerDacPresupuestoByPresupuestoCodigo(Integer iidPresupuesto, Integer codigo, Session session) {
        DacPresupuesto res = null;
        List<DacPresupuesto> listaDacPresupuesto = session.createQuery("from DacPresupuesto where presupuesto.iid = " + iidPresupuesto + " and codigo = " + codigo).list();
        if (listaDacPresupuesto != null && listaDacPresupuesto.size() > 0) {
            res = listaDacPresupuesto.get(0);
        }
        return res;
    }
    
}