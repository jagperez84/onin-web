package util;

public class Constantes {
    
    public static String DECIMALES2 = "2 Decimales";
    public static String TRUNCAR = "Truncar";
    public static String EXCESO = "Exceso";
    
    public static String ALBARAN = "Albarán";
    public static String ALBARANB = "Albarán B";
    public static String PRESUPUESTO = "Presupuesto";
    public static String FACTURA = "Factura";
    public static String PEDIDO = "Pedido";
    public static String PEDIDOC = "Pedido de Compra";
    public static String ALBARANC = "Albarán de Compra";
    public static String FACTURAC = "Factura de Devolución";
    public static String FACTURAA = "Factura de Abono";
    
    public static String SERIE_STD = "Serie STD";
    public static String SERIE_SEC = "Serie SEC";
    
    public static String DEVUELTO_PARCIAL = "Devuelto Parcial";
    public static String DEVUELTO = "Devuelto";
    public static String FACTURADO = "Facturado";
    public static String ACEPTADO = "Aceptado";
    public static String FINALIZADO = "Finalizado";
    public static String ACEPTADO_PARCIAL = "Aceptado Parcialmente";
    public static String FINALIZADO_PARCIAL = "Finalizado Parcial";
    public static String FACTURADO_PARCIAL = "Facturado Parcial";
    public static String PENDIENTE_FABRICACION = "Pendiente de Fabricación";
    public static String PENDIENTE_FACTURA = "Pendiente de Factura";
    public static String IMPAGADO = "Impagado";
    public static String PRODUCTO_COMPUESTO = "PC";
    public static String FORMULA = "Fórmula";
    public static String ALMACEN_PRINCIPAL = "Almacén principal";
    public static String INVENTARIO_POR_DOCUMENTO_DE_COMPRAS = "Inventario por documento de compras";
    
    public static String VACIO = "-- Vacío --";
    public static String TODOS = "----Todos----";
    public static String SELECCIONE_COMERCIAL = "-- Seleccione un comercial --";
    public static String RECOMENDADO = "Recomendado";
    public static String TELEFONO = "Teléfono";
    public static String VISITA_OFICINA = "Visita oficina";
    public static String EMAIL = "Email";
    public static String TARJETA = "Tarjeta";
    public static String COMERCIALES = "Comerciales";
    public static String PRESUPUESTO_ONLINE = "Presupuesto on-line";
    public static String OTROS = "otros";
    public static String THRESHOLD = "0.0001";
    public static String NUMERICA = "Numérica";
    public static String SELECCION = "Selección";
    public static String CALCULADA = "Calculada";
    public static int TAM_CP = 5;
    
    //Constantes para Usuario
    public static String USUARIO_ADMINISTRADOR = "Administrador";
    public static String USUARIO_INTERNO = "Usuario Interno";
    public static String USUARIO_EXTERNO = "Usuario Externo";
    public static String USUARIO_MONTADOR = "Montador";
    public static int TAM_NOMBRE_USUARIO = 45;
    public static int TAM_CONTRASENHA_USUARIO = 45;
    public static int TAM_DEPARTAMENTO_USUARIO = 45;
    public static int TAM_EMAIL_USUARIO = 45;
    public static int TAM_PIE_USUARIO = 255;
    
    //Constantes para Colores
    public static int TAM_DESCRIPCION_COLOR = 45;
    public static int TAM_CODIGO_COLOR = 45;
    
     //Constantes para FamiliaVenta
    public static int TAM_NOMBRE_FAM_VENTA = 45;
    public static int TAM_CODIGO_FAM_VENTA = 3;
    public static String NOMBRE_FAM_PRECIO = "PRECIO";
    public static String NOMBRE_FAM_LONA = "LONA";
    public static String NOMBRE_FAM_ESPECIFICACION = "ESPECIFICACION";
    public static String FAMILIA_TALLER = "Taller";
    public static String FAMILIA_CONFECCION = "Confección";
    public static String FAMILIA_AMBOS = "Ambos";
    
    //Constantes para TipoToldo
    public static int TAM_DESCRIPCION_TIPO_TOLDO = 100;
    public static int TAM_CODIGO_TIPO_TOLDO = 45;
    
    //Constantes para TipoProducto
    public static int TAM_NOMBRE_TIPO_PRODUCTO = 45;
    public static int TAM_CODIGO_TIPO_PRODUCTO = 45;
    
    //Constantes para Magnitud
    public static int TAM_NOMBRE_MAGNITUD = 45;
    public static int TAM_CODIGO_MAGNITUD = 45;
    
    //Constantes para UnidadMedida
    public static int TAM_NOMBRE_UNIDAD_MEDIDA = 45;
    public static int TAM_CODIGO_UNIDAD_MEDIDA = 45;
    public static int TAM_ABREVIACION_UNIDAD_MEDIDA = 45;
    
    //Constantes para TipoMedida
    public static int TAM_NOMBRE_TIPO_MEDIDA = 45;
    public static int TAM_CODIGO_TIPO_MEDIDA = 45;
    public static int TAM_NOMBRE_DIM_1_TIPO_MEDIDA = 45;
    public static int TAM_NOMBRE_DIM_2_TIPO_MEDIDA = 45;
    public static int TAM_NOMBRE_DIM_3_TIPO_MEDIDA = 45;
    public static int TAM_NOMBRE_DIM_4_TIPO_MEDIDA = 45;
    public static int TAM_NOMBRE_DIM_5_TIPO_MEDIDA = 45;
    public static int TAM_FORMULA_TIPO_MEDIDA = 200;
    
    //Constantes para TipoControl
    public static int TAM_NOMBRE_TIPO_CONTROL = 45;
    public static int TAM_CODIGO_TIPO_CONTROL = 45;
    
    //Constantes para Almacen
    public static int TAM_NOMBRE_ALMACEN = 45;
    public static int TAM_DESCRIPCION_ALMACEN = 200;
    
    //Constantes para TipoMovimientoAlmacen
    public static int TAM_NOMBRE_TIPO_MOVIMIENTO_ALMACEN = 45;
    public static int TAM_DESCRIPCION_TIPO_MOVIMIENTO_ALMACEN = 200;
    public static String TIPO_MOVIMIENTO_ALMACEN_RESTO = "RESTO";
    public static String TIPO_MOVIMIENTO_ALMACEN_COMPRA = "Compra";
    public static String SALIDA_FABRICACION = "Salida";
    
    //Estados documentos
    public static String RECIBIDO_PARCIAL = "Recibido Parcial"; 
    public static String PEDIDO_RECIBIDO = "Pedido Recibido";
    
    //Constantes para Articulo
    public static int TAM_CODIGO_ARTICULO = 45;
    public static int TAM_CODIGO_VISUAL_ARTICULO = 25;
    public static int TAM_OBSERVACIONES_ARTICULO = 255;
    public static int TAM_DESCRIPCION_TECNICA_ARTICULO = 255;
    public static int TAM_DESCRIPCION_INFORMATIVA_ARTICULO = 255;
    public static String MANUAL = "Manual";
    public static String PMC = "P.M.C.";
    public static String ULTIMO_PRECIO_COSTE = "Último Precio Coste";
    
    //Constantes para AgenteArticulo
    public static int TAM_REFERENCIA_ARTICULO_CODIGO = 45;
    
    //Constantes para MovimientoAlmacen
    public static int TAM_CONCEPTO_MOVIMIENTO_ALMACEN = 255;
    
    //Constantes para Presupuesto
    public static int TAM_REFERENCIA_PRESUPUESTO = 255;
    public static int TAM_CODIGO_CLIENTE_PRESUPUESTO = 45;
    public static int TAM_NOMBRE_CLIENTE_PRESUPUESTO = 70;
    public static int TAM_DOMICILIO_CLIENTE_PRESUPUESTO = 45;
    public static int TAM_LOCALIDAD_CLIENTE_PRESUPUESTO = 45;
    public static int TAM_PROVINCIA_CLIENTE_PRESUPUESTO = 45;
    public static int TAM_TELEFONO_CLIENTE_PRESUPUESTO = 45;
    public static int TAM_CIF_CLIENTE_PRESUPUESTO = 45;
    public static int TAM_DIRECCION_CLIENTE_PRESUPUESTO = 45;
    public static int TAM_CP_CLIENTE_PRESUPUESTO = 10;
    public static int TAM_PAIS_CLIENTE_PRESUPUESTO = 45;
    public static int TAM_OBSERVACIONES_PRESUPUESTO = 200;
    public static int TAM_DESCRIPCION_ARTICULO_PRESUPUESTO = 255;
    public static int TAM_NOTA_PRESUPUESTO = 5;
    public static int TAM_RECOMENDADO_POR = 100;
    public static int TAM_EMAIL_CLIENTE_PRESUPUESTO = 45;
    public static int NUM_LINEAS_DOCUMENTO = 3;
    public static String USUARIO_OFICINA = "Oficina";
    public static String USUARIO_CONFECCION = "Confección";
    public static String USUARIO_TALLER = "Taller";
    public static String TIPO_CORTE_ASIMETRICO = "Asimétrico";
    public static String TIPO_CORTE_RETAL_MAXI = "Retal Maxi";
    public static String TIPO_CORTE_RETAL_MINI = "Retal Mini";
    public static String TIPO_CORTE_DEGRADEE = "Degradee";
    public static String TIPO_CORTE_SCREEN = "Screen";
    
    //Constantes para Plazo
    public static int TAM_NOMBRE_PLAZO = 45;
    
    //Constantes para Iva
    public static int TAM_DESCRIPCION_IVA = 255;
    
    //Constantes para Dac
    public static int TAM_DESCRIPCION_DAC = 45;
    
    //Constantes para Agentes
    public static int TAM_CODIGO_AGENTE = 45;
    public static int TAM_NOMBRE_COMERCIAL_AGENTE = 70;
    public static int TAM_NOMBRE_FISCAL_AGENTE = 70;
    public static int TAM_CIF_AGENTE = 45;
    public static int TAM_PAIS_AGENTE = 45;
    public static int TAM_POBLACION_AGENTE = 45;
    public static int TAM_PROVINCIA_AGENTE = 45;
    public static int TAM_DIRECCION_AGENTE = 45;
    public static int TAM_CP_AGENTE = 10;
    public static int TAM_EMAIL_AGENTE = 45;
    public static int TAM_TLF_AGENTE = 45;
    public static int TAM_TLF2_AGENTE = 45;
    public static int TAM_TLF3_AGENTE = 45;
    public static int TAM_FAX_AGENTE = 45;
    public static int TAM_ENTIDAD_AGENTE = 200;
    public static int TAM_DIRECCION_ENTIDAD_AGENTE = 200;
    public static int TAM_POBLACION_ENTIDAD_AGENTE = 45;
    public static int TAM_PROVINCIA_ENTIDAD_AGENTE = 45;
    public static int TAM_CUENTA_ENTIDAD_AGENTE = 45;
    public static int TAM_CP_FISCAL_AGENTE = 10;
    public static int TAM_DIRECCION_FISCAL_AGENTE = 45;
    public static int TAM_POBLACION_FISCAL_AGENTE = 45;
    public static int TAM_PROVINCIA_FISCAL_AGENTE = 45;
    
    //Constantes para comerciales
    public static int TAM_CODIGO_COMERCIAL = 45;
    public static int TAM_NOMBRE_COMERCIAL = 45;
    public static int TAM_NIF_COMERCIAL = 45;
    public static int TAM_PAIS_COMERCIAL = 45;
    public static int TAM_PROVINCIA_COMERCIAL = 45;
    public static int TAM_POBLACION_COMERCIAL = 45;
    public static int TAM_DIRECCION_COMERCIAL = 45;
    public static int TAM_CP_COMERCIAL = 45;
    public static int TAM_TLF_COMERCIAL = 45;
    public static int TAM_TLF2_COMERCIAL = 45;
    public static int TAM_FAX_COMERCIAL = 45;
    public static int TAM_MAIL_COMERCIAL = 45;
    
    //Constantes para Variables
    public static int TAM_NOMBRE_VARIABLE = 45;
    public static int TAM_TIPO_VARIABLE = 15;
    public static int TAM_CONDICION_VARIABLE = 512;
    public static int TAM_FORMULA_VARIABLE = 512;
    
    //Constantes para SeleccionVariables
    public static int TAM_NOMBRE_SELECCION = 45;
    public static int TAM_VALOR_SELECCION = 45;
    public static int TAM_CONDICION_SELECCION = 45;
    
    //Constantes para TipoRecibo
    public static int TAM_CODIGO_TIPO_RECIBO = 45;
    public static int TAM_DESCRIPCION_TIPO_RECIBO = 45;
    public static int TAM_REQUISITOS_TIPO_RECIBO = 200;
    
    //Constantes para FormaPago
    public static int TAM_CODIGO_FORMA_PAGO = 45;
    public static int TAM_DESCRIPCION_IDENTIFICATIVA_FORMA_PAGO = 50;
    public static int TAM_DESCRIPCION_CLIENTE_FORMA_PAGO = 50;
    public static int TAM_NOMBRE_PLAZO_FORMA_PAGO = 45;
    public static String MESES_ENTEROS = "Meses enteros";
    public static String DIAS_EXACTOS = "Días exactos";
    
    public static String SIN_EXISTENCIAS = "Sin Existencias";
    
    public static String PLANTILLA_TOLDO_ENRROLLADO = "Toldo enrrollado";
    public static String PLANTILLA_TOLDO_PLANO      = "Toldo plano";
    public static String PLANTILLA_TOLDO_GENERAL    = "Toldo general";
    
    public static String DESC_COLOR_BLANCO = "Blanco";
    public static String COD_COLOR_BLANCO = "BL";
    public static String DESC_COLOR_NEGRO = "Negro";
    public static String COD_COLOR_NEGRO = "NG";
    
    //Constantes para Empresa
    public static int TAM_CODIGO_EMPRESA = 10;
    public static int TAM_DESCRIPCION_EMPRESA = 45;
    public static int TAM_DIRECCION_EMPRESA = 45;
    public static int TAM_POBLACION_EMPRESA = 45;
    public static int TAM_PROVINCIA_EMPRESA = 45;
    public static int TAM_CP_EMPRESA = 5;
    public static int TAM_CUENTA_EMPRESA = 45;
    public static int TAM_CIF_EMPRESA = 45;
    public static int TAM_URLWEB_EMPRESA = 255;
    public static int TAM_EMAIL_EMPRESA = 100;
    public static int TAM_TELEFONO_EMPRESA = 20;
    public static int TAM_FAX_EMPRESA = 20;
    
    public static int TAM_FACTOR_INTERLOCUTOR_FAMILIA_VENTA = 200;
}