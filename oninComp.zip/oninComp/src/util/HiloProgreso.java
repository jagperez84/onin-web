package util;

import javax.swing.JProgressBar;

public class HiloProgreso implements Runnable {
    JProgressBar progreso;
    public Integer valor;
	
    public HiloProgreso(JProgressBar progreso1) {
        super();
        this.progreso = progreso1;
    }

    public void run() {
        progreso.setValue(valor);
        this.progreso.repaint();
    }

    public void act(Integer valor) {
        progreso.setValue(valor);
    }
}
