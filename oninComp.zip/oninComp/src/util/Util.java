package util;

import bean.Agentes;
import bean.FormaPago2;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Shape;
import java.awt.Toolkit;
import java.awt.geom.Line2D;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.imageio.ImageIO;

public class Util {
    
    public static boolean isNifNie(String nif) {
        //si es NIE, eliminar la x,y,z inicial para tratarlo como nif
        if (nif.toUpperCase().startsWith("X") || nif.toUpperCase().startsWith("Y") || nif.toUpperCase().startsWith("Z")) {
            nif = nif.substring(1);
        }
        Pattern nifPattern = Pattern.compile("(\\d{1,8})([TRWAGMYFPDXBNJZSQVHLCKEtrwagmyfpdxbnjzsqvhlcke])");
        Matcher m = nifPattern.matcher(nif);
        if (m.matches()) {
            String letra = m.group(2);
            //Extraer letra del NIF
            String letras = "TRWAGMYFPDXBNJZSQVHLCKE";
            int dni = Integer.parseInt(m.group(1));
            dni = dni % 23;
            String reference = letras.substring(dni, dni + 1);

            if (reference.equalsIgnoreCase(letra)) {
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    public static String convertirComaAPunto(String valor){
        return valor.replace(",", ".");
    }
    
    public static String convertirPuntoAComa(String valor){
        return valor.replace(".", ",");
    }
    
    public static Long calcularFecha(int diasSumar, String tipoCalculo, Long fecha, List<Integer> listaDiasOrdenada){
        Date fechaV = null;
        Date fechaError = null;
        SimpleDateFormat formatoFecha = new SimpleDateFormat("dd/MM/yyyy");
        try{
            Date fechaP = formatoFecha.parse(formatoFecha.format(new Date(fecha)));
            fechaError = formatoFecha.parse("01/01/1900");

            if(diasSumar % 30 == 0 && tipoCalculo.equals(Constantes.MESES_ENTEROS)){
                Calendar c1 = Calendar.getInstance();
                c1.setTime(fechaP);
                c1.add(Calendar.MONTH, diasSumar / 30);
                
                if(listaDiasOrdenada != null && listaDiasOrdenada.get(0) != 32){
                    if(c1.get(Calendar.DATE) <= listaDiasOrdenada.get(0)){
                        c1.add(Calendar.DATE, listaDiasOrdenada.get(0) - c1.get(Calendar.DATE));
                    } else {
                        if(listaDiasOrdenada.get(1) != 32){
                            if(listaDiasOrdenada.get(1) >= c1.get(Calendar.DATE)){
                                c1.add(Calendar.DATE, listaDiasOrdenada.get(1) - c1.get(Calendar.DATE));
                            } else {
                                if(listaDiasOrdenada.get(2) != 32){
                                    if(listaDiasOrdenada.get(2) >= c1.get(Calendar.DATE)){
                                        c1.add(Calendar.DATE, listaDiasOrdenada.get(2) - c1.get(Calendar.DATE));
                                    } else {
                                        c1.set(Calendar.MONTH, c1.get(Calendar.MONTH) + 1);
                                        c1.set(Calendar.DATE, listaDiasOrdenada.get(0));
                                    }
                                } else {
                                    c1.set(Calendar.MONTH, c1.get(Calendar.MONTH) + 1);
                                    c1.set(Calendar.DATE, listaDiasOrdenada.get(0));
                                }
                            }
                        } else {
                            c1.set(Calendar.MONTH, c1.get(Calendar.MONTH) + 1);
                            c1.set(Calendar.DATE, listaDiasOrdenada.get(0));
                        }
                    }
                }
                fechaV = c1.getTime();
            } else {
                Calendar c1 = Calendar.getInstance();
                c1.setTime(fechaP);
                c1.add(Calendar.DATE, diasSumar);
                if(listaDiasOrdenada != null && listaDiasOrdenada.get(0) != 32){
                    if(c1.get(Calendar.DATE) <= listaDiasOrdenada.get(0)){
                        c1.add(Calendar.DATE, listaDiasOrdenada.get(0) - c1.get(Calendar.DATE));
                    } else {
                        if(listaDiasOrdenada.get(1) != 32){
                            if(listaDiasOrdenada.get(1) >= c1.get(Calendar.DATE)){
                                c1.add(Calendar.DATE, listaDiasOrdenada.get(1) - c1.get(Calendar.DATE));
                            } else {
                                if(listaDiasOrdenada.get(2) != 32){
                                    if(listaDiasOrdenada.get(2) >= c1.get(Calendar.DATE)){
                                        c1.add(Calendar.DATE, listaDiasOrdenada.get(2) - c1.get(Calendar.DATE));
                                    } else {
                                        c1.set(Calendar.MONTH, c1.get(Calendar.MONTH) + 1);
                                        c1.set(Calendar.DATE, listaDiasOrdenada.get(0));
                                    }
                                } else {
                                    c1.set(Calendar.MONTH, c1.get(Calendar.MONTH) + 1);
                                    c1.set(Calendar.DATE, listaDiasOrdenada.get(0));
                                }
                            }
                        } else {
                            c1.set(Calendar.MONTH, c1.get(Calendar.MONTH) + 1);
                            c1.set(Calendar.DATE, listaDiasOrdenada.get(0));
                        }
                    }
                }
                fechaV = c1.getTime();
            }
        } catch(Exception ex){
            ex.printStackTrace();
            fechaV = fechaError;
        }
        
        return fechaV.getTime();
    }
    
    public static Long calcularFecha(int diasSumar, FormaPago2 fp2, Long fecha, Agentes ag){
        Date fechaV = null;
        Date fechaError = null;
        SimpleDateFormat formatoFecha = new SimpleDateFormat("dd/MM/yyyy");
        try{
            Date fechaP = formatoFecha.parse(formatoFecha.format(new Date(fecha)));
            fechaError = formatoFecha.parse("01/01/1900");
            List<Integer> listaDiasOrdenada;
            if(ag != null){ 
                listaDiasOrdenada = ag.ordenarDiasCobro();
            } else {
                listaDiasOrdenada = null;
            }
            
            if(diasSumar % 30 == 0 && fp2.getTipodecalculo().equals(Constantes.MESES_ENTEROS)){
                Calendar c1 = Calendar.getInstance();
                c1.setTime(fechaP);
                c1.add(Calendar.MONTH, diasSumar / 30);
                
                if(listaDiasOrdenada != null && listaDiasOrdenada.get(0) != 32){
                    if(c1.get(Calendar.DATE) <= listaDiasOrdenada.get(0)){
                        c1.add(Calendar.DATE, listaDiasOrdenada.get(0) - c1.get(Calendar.DATE));
                    } else {
                        if(listaDiasOrdenada.get(1) != 32){
                            if(listaDiasOrdenada.get(1) >= c1.get(Calendar.DATE)){
                                c1.add(Calendar.DATE, listaDiasOrdenada.get(1) - c1.get(Calendar.DATE));
                            } else {
                                if(listaDiasOrdenada.get(2) != 32){
                                    if(listaDiasOrdenada.get(2) >= c1.get(Calendar.DATE)){
                                        c1.add(Calendar.DATE, listaDiasOrdenada.get(2) - c1.get(Calendar.DATE));
                                    } else {
                                        c1.set(Calendar.MONTH, c1.get(Calendar.MONTH) + 1);
                                        c1.set(Calendar.DATE, listaDiasOrdenada.get(0));
                                    }
                                } else {
                                    c1.set(Calendar.MONTH, c1.get(Calendar.MONTH) + 1);
                                    c1.set(Calendar.DATE, listaDiasOrdenada.get(0));
                                }
                            }
                        } else {
                            c1.set(Calendar.MONTH, c1.get(Calendar.MONTH) + 1);
                            c1.set(Calendar.DATE, listaDiasOrdenada.get(0));
                        }
                    }
                }
                fechaV = c1.getTime();
            } else {
                Calendar c1 = Calendar.getInstance();
                c1.setTime(fechaP);
                c1.add(Calendar.DATE, diasSumar);
                if(listaDiasOrdenada != null && listaDiasOrdenada.get(0) != 32){
                    if(c1.get(Calendar.DATE) <= listaDiasOrdenada.get(0)){
                        c1.add(Calendar.DATE, listaDiasOrdenada.get(0) - c1.get(Calendar.DATE));
                    } else {
                        if(listaDiasOrdenada.get(1) != 32){
                            if(listaDiasOrdenada.get(1) >= c1.get(Calendar.DATE)){
                                c1.add(Calendar.DATE, listaDiasOrdenada.get(1) - c1.get(Calendar.DATE));
                            } else {
                                if(listaDiasOrdenada.get(2) != 32){
                                    if(listaDiasOrdenada.get(2) >= c1.get(Calendar.DATE)){
                                        c1.add(Calendar.DATE, listaDiasOrdenada.get(2) - c1.get(Calendar.DATE));
                                    } else {
                                        c1.set(Calendar.MONTH, c1.get(Calendar.MONTH) + 1);
                                        c1.set(Calendar.DATE, listaDiasOrdenada.get(0));
                                    }
                                } else {
                                    c1.set(Calendar.MONTH, c1.get(Calendar.MONTH) + 1);
                                    c1.set(Calendar.DATE, listaDiasOrdenada.get(0));
                                }
                            }
                        } else {
                            c1.set(Calendar.MONTH, c1.get(Calendar.MONTH) + 1);
                            c1.set(Calendar.DATE, listaDiasOrdenada.get(0));
                        }
                    }
                }
                fechaV = c1.getTime();
            }
        } catch(Exception ex){
            ex.printStackTrace();
            fechaV = fechaError;
        }
        
        return fechaV.getTime();
    }
    
    public static ByteArrayInputStream  pintarLona(String corteLonaS, String tLinea, String tSalida, String tDobladillo, String tSolape, Float anchoSeleccionado) {
        ByteArrayInputStream bais = null;
        BufferedImage bi = null;
		int anchoN = 100, altoN = 50, anchoTotal = 0, i, numLineas = 0, numPañosEnteros = 0;
		float[] dash = {1.5f, 1.5f, 1.5f};
        Font fuente = new Font("Times New Roman", Font.PLAIN, 11);
        Shape linea;
        BasicStroke bs;
        Graphics2D g = null;
        byte[] imageInByte = null;
        Float fLinea = new Float(Util.convertirComaAPunto(tLinea));
        Float dobladillo = Float.valueOf(Util.convertirComaAPunto(tDobladillo));
        Float solape = Float.valueOf(Util.convertirComaAPunto(tSolape));
        boolean hayRestos = false;
        Float restoIzquierdo = null, lineaAcumulada = 0F;
        tSalida = Util.convertirPuntoAComa(tSalida);

        if (corteLonaS.equals(Constantes.TIPO_CORTE_ASIMETRICO)) {
            hayRestos = true;
            restoIzquierdo = 0F;
            while (lineaAcumulada < fLinea) {
                lineaAcumulada += anchoSeleccionado;
                numPañosEnteros++;
            }

            if (lineaAcumulada > fLinea) {
                numPañosEnteros--;
                restoIzquierdo = (fLinea - numPañosEnteros * anchoSeleccionado);
                restoIzquierdo += (2 * dobladillo) + (numPañosEnteros * solape);
                hayRestos = true;

                if (anchoSeleccionado.equals(restoIzquierdo)) {
                    numPañosEnteros++;
                    restoIzquierdo = 0F;
                    hayRestos = false;
                }
            } else if (lineaAcumulada.equals(fLinea)) {
                restoIzquierdo = (2 * dobladillo) + (numPañosEnteros * solape);
                hayRestos = true;
            }
        } else if (corteLonaS.equals(Constantes.TIPO_CORTE_RETAL_MAXI)) {
            Float restoRepartir = 0F;
            hayRestos = true;
            restoIzquierdo = 0F;
            while (lineaAcumulada < fLinea) {
                lineaAcumulada += anchoSeleccionado;
                numPañosEnteros++;
            }

            if (lineaAcumulada > fLinea) {
                numPañosEnteros = numPañosEnteros - 2;
                restoRepartir = (fLinea - numPañosEnteros * anchoSeleccionado);
                restoRepartir += (2 * dobladillo) + ((numPañosEnteros + 1) * solape);
                restoIzquierdo = restoRepartir / 2;
                hayRestos = true;

                if (anchoSeleccionado.equals(restoRepartir)) {
                    numPañosEnteros++;
                    restoIzquierdo = 0F;
                    hayRestos = false;

                }
            } else if (lineaAcumulada.equals(fLinea)) {
                numPañosEnteros--;
                restoIzquierdo = (anchoSeleccionado + (2 * dobladillo) + ((numPañosEnteros + 1) * solape)) / 2;
                hayRestos = true;
            }
        } else if (corteLonaS.equals(Constantes.TIPO_CORTE_RETAL_MINI)) {
            Float restoRepartir = 0F;
            hayRestos = true;
            restoIzquierdo = 0F;
            while (lineaAcumulada < fLinea) {
                lineaAcumulada += anchoSeleccionado;
                numPañosEnteros++;
            }

            if (lineaAcumulada > fLinea) {
                numPañosEnteros--;
                restoRepartir = (fLinea - numPañosEnteros * anchoSeleccionado);
                restoRepartir += (2 * dobladillo) + ((numPañosEnteros + 1) * solape);
                restoIzquierdo = restoRepartir / 2;
                hayRestos = true;

                if (anchoSeleccionado.equals(restoRepartir)) {
                    numPañosEnteros++;
                    restoIzquierdo = 0F;
                    hayRestos = false;

                }
            } else if (lineaAcumulada.equals(fLinea)) {
                restoIzquierdo = ((2 * dobladillo) + ((numPañosEnteros + 1) * solape)) / 2;
                hayRestos = true;
            }
        } else if (corteLonaS.equals(Constantes.TIPO_CORTE_DEGRADEE)) {
            hayRestos = false;
            restoIzquierdo = 0F;
            numPañosEnteros = 1;
        }
        
        //Se obtiene el resultado
        if (corteLonaS.equals(Constantes.TIPO_CORTE_ASIMETRICO)) {

            if(numPañosEnteros == 0 || (numPañosEnteros == 1 && !hayRestos)){
                anchoTotal = anchoN;
                anchoTotal = (int) (anchoN * 1.8);
                anchoTotal = 3 * anchoN;
                altoN = (int) (altoN * 1.3);
                
                bi = new BufferedImage(anchoTotal + 1,  altoN + 1, BufferedImage.TYPE_INT_RGB);
                g = bi.createGraphics();

                g.setColor(Color.WHITE);
                g.fillRect(0, 0, anchoTotal + 1, altoN + 1);

                g.setColor(Color.BLACK);
                g.drawRect(0, 0,(int) (0.9 * anchoN), (int)(0.8 * altoN));

                g.setFont(fuente);
                if(!hayRestos){
                    g.drawString("TE", anchoN - (anchoN / 2) - 20, altoN - (altoN / 2) - 8);
                    g.drawString(tSalida + "x" + Util.convertirPuntoAComa(anchoSeleccionado.toString()), anchoN - (anchoN / 2) - 43, (altoN / 2) + 3);
                } else {
                    g.drawString("TC", anchoN - (anchoN / 2) - 20, altoN - (altoN / 2) - 8);
                    g.drawString(tSalida + "x" + Util.convertirPuntoAComa(restoIzquierdo.toString()), anchoN - (anchoN / 2) - 43, (altoN / 2) + 3);
                }
            } else if((numPañosEnteros == 2 && !hayRestos)|| (numPañosEnteros == 1 && hayRestos)){
                anchoTotal = (int) (anchoN * 1.8);
                anchoTotal = 3 * anchoN;
                altoN = (int) (altoN * 1.3);
                
                bi = new BufferedImage(anchoTotal + 1, altoN + 1, BufferedImage.TYPE_INT_RGB);
                g = bi.createGraphics();

                g.setColor(Color.WHITE);
                g.fillRect(0, 0, anchoTotal + 1, altoN + 1);

                g.setColor(Color.BLACK);
                g.drawRect(0, 0,(int) (0.7 * anchoTotal) -  25, (int)(0.7 * altoN));

                linea = new Line2D.Double(anchoN - 8, 0, anchoN - 8,altoN - 20);
                bs = new BasicStroke(1.0f, BasicStroke.CAP_BUTT, BasicStroke.JOIN_MITER, 1.0f, dash, 0.0f);
                g.setStroke(bs);
                g.draw(linea);
                
                g.setFont(fuente);
                g.drawString("TE", anchoN - (anchoN / 2) - 10, altoN - (altoN / 2) - 15);
                g.drawString(tSalida + "x" + Util.convertirPuntoAComa(anchoSeleccionado.toString()), anchoN - (anchoN / 2) - 33, (altoN / 2) + 3);
                
                if(hayRestos){
                    g.drawString("TC", 80 + anchoN - (anchoN / 2) , altoN - (altoN / 2) - 15);
                    g.drawString(tSalida + "x" + Util.convertirPuntoAComa(restoIzquierdo.toString()), 55 + anchoN - (anchoN / 2), (altoN / 2) + 3);
                } else {
                    g.drawString("TE", 80 + anchoN - (anchoN / 2) , altoN - (altoN / 2) - 15);
                    g.drawString(tSalida + "x" + Util.convertirPuntoAComa(anchoSeleccionado.toString()), 55 + anchoN - (anchoN / 2), (altoN / 2) + 3);
                }

            } else {
                numLineas = 0;
                anchoTotal = numPañosEnteros * anchoN;
                numLineas = numPañosEnteros - 1;

                if (hayRestos) {
                    anchoTotal += anchoN;
                    numLineas++;
                }

                bi = new BufferedImage(anchoTotal + 1, altoN + 1, BufferedImage.TYPE_INT_RGB);
                g = bi.createGraphics();

                g.setColor(Color.WHITE);
                g.fillRect(0, 0, anchoTotal + 1, altoN + 1);

                g.setColor(Color.BLACK);
                g.drawRect(0, 0, anchoTotal, altoN);

                for (i = 1; i <= numLineas; i++) {
                    linea = new Line2D.Double(anchoN * i, 0, anchoN * i, altoN);
                    bs = new BasicStroke(1.0f, BasicStroke.CAP_BUTT, BasicStroke.JOIN_MITER, 1.0f, dash, 0.0f);
                    g.setStroke(bs);
                    g.draw(linea);
                }

                for (i = 1; i <= numLineas + 1; i++) {
                    g.setFont(fuente);

                    if ((i == numLineas + 1) && hayRestos) {
                        g.drawString("TC", i * anchoN - (anchoN / 2) - 20, (altoN / 2) - 8);
                        g.drawString(tSalida + "x" + Util.convertirPuntoAComa(restoIzquierdo.toString()), i * anchoN - (anchoN / 2) - 43, (altoN / 2) + 8);
                    } else {
                        g.drawString("TE", i * anchoN - (anchoN / 2) - 20, (altoN / 2) - 8);
                        g.drawString(tSalida + "x" + Util.convertirPuntoAComa(anchoSeleccionado.toString()), i * anchoN - (anchoN / 2) - 43, (altoN / 2) + 8);
                    }
                }
            }
        } else if (corteLonaS.equals(Constantes.TIPO_CORTE_RETAL_MAXI) || corteLonaS.equals(Constantes.TIPO_CORTE_RETAL_MINI)) {
            if(numPañosEnteros == 0 && hayRestos){
                anchoTotal = (int) (anchoN * 1.8);
                anchoTotal = 3 * anchoN;
                altoN = (int) (altoN * 1.3);
                
                bi = new BufferedImage(anchoTotal + 1, altoN + 1, BufferedImage.TYPE_INT_RGB);
                g = bi.createGraphics();

                g.setColor(Color.WHITE);
                g.fillRect(0, 0, anchoTotal + 1, altoN + 1);

                g.setColor(Color.BLACK);
                g.drawRect(0, 0,(int) (0.7 * anchoTotal) -  25, (int)(0.7 * altoN));

                linea = new Line2D.Double(anchoN - 8, 0, anchoN - 8,altoN - 20);
                bs = new BasicStroke(1.0f, BasicStroke.CAP_BUTT, BasicStroke.JOIN_MITER, 1.0f, dash, 0.0f);
                g.setStroke(bs);
                g.draw(linea);
                
                g.setFont(fuente);
                g.drawString("TC", anchoN - (anchoN / 2) - 10, altoN - (altoN / 2) - 15);
                g.drawString(tSalida + "x" + Util.convertirPuntoAComa(restoIzquierdo.toString()), anchoN - (anchoN / 2) - 33, (altoN / 2) + 3);

                g.drawString("TC", 80 + anchoN - (anchoN / 2) , altoN - (altoN / 2) - 15);
                g.drawString(tSalida + "x" + Util.convertirPuntoAComa(restoIzquierdo.toString()), 55 + anchoN - (anchoN / 2), (altoN / 2) + 3);
            
            } else if(numPañosEnteros == 1 && !hayRestos){
                anchoTotal = anchoN;
                anchoTotal = (int) (anchoN * 1.8);
                anchoTotal = 3 * anchoN;
                altoN = (int) (altoN * 1.3);
                
                bi = new BufferedImage(anchoTotal + 1,  altoN + 1, BufferedImage.TYPE_INT_RGB);
                g = bi.createGraphics();

                g.setColor(Color.WHITE);
                g.fillRect(0, 0, anchoTotal + 1, altoN + 1);

                g.setColor(Color.BLACK);
                g.drawRect(0, 0,(int) (0.9 * anchoN), (int)(0.8 * altoN));

                g.setFont(fuente);
                
                g.drawString("TE", anchoN - (anchoN / 2) - 20, altoN - (altoN / 2) - 8);
                g.drawString(tSalida + "x" + Util.convertirPuntoAComa(anchoSeleccionado.toString()), anchoN - (anchoN / 2) - 43, (altoN / 2) + 3);

            } else {
                numLineas = 0;
                anchoTotal = numPañosEnteros * anchoN;
                numLineas = numPañosEnteros - 1;

                if (hayRestos) {
                    anchoTotal += anchoN * 2;
                    numLineas += 2;
                }

                bi = new BufferedImage(anchoTotal + 1, altoN + 1, BufferedImage.TYPE_INT_RGB);
                g = bi.createGraphics();

                g.setColor(Color.WHITE);
                g.fillRect(0, 0, anchoTotal + 1, altoN + 1);

                g.setColor(Color.BLACK);
                g.drawRect(0, 0, anchoTotal, altoN);

                for (i = 1; i <= numLineas; i++) {
                    linea = new Line2D.Double(anchoN * i, 0, anchoN * i, altoN);
                    bs = new BasicStroke(1.0f, BasicStroke.CAP_BUTT, BasicStroke.JOIN_MITER, 1.0f, dash, 0.0f);
                    g.setStroke(bs);
                    g.draw(linea);
                }

                for (i = 1; i <= numLineas + 1; i++) {
                    g.setFont(fuente);

                    if ((i == 1 || i == numLineas + 1) && hayRestos) {
                        g.drawString("TC", i * anchoN - (anchoN / 2) - 20, (altoN / 2) - 8);
                        g.drawString(tSalida + "x" + Util.convertirPuntoAComa(restoIzquierdo.toString()), i * anchoN - (anchoN / 2) - 43, (altoN / 2) + 8);
                    } else {
                        g.drawString("TE", i * anchoN - (anchoN / 2) - 20, (altoN / 2) - 8);
                        g.drawString(tSalida + "x" + Util.convertirPuntoAComa(anchoSeleccionado.toString()), i * anchoN - (anchoN / 2) - 43, (altoN / 2) + 8);
                    }
                }
            }
        } else if(corteLonaS.equals(Constantes.TIPO_CORTE_DEGRADEE)){
            anchoTotal = anchoN;
            anchoTotal = (int) (anchoN * 1.8);
            anchoTotal = 3 * anchoN;
            altoN = (int) (altoN * 1.3);
                
            bi = new BufferedImage(anchoTotal + 1,  altoN + 1, BufferedImage.TYPE_INT_RGB);
            g = bi.createGraphics();
            g.setColor(Color.WHITE);
            g.fillRect(0, 0, anchoTotal + 1, altoN + 1);
            
            g.setColor(Color.BLACK);
            g.drawRect(0, 0,(int) (0.9 * anchoN), (int)(0.8 * altoN));

            g.setFont(fuente);
                
            g.drawString("TE", anchoN - (anchoN / 2) - 20, altoN - (altoN / 2) - 8);
            g.drawString(tSalida + "x" + Util.convertirPuntoAComa(anchoSeleccionado.toString()), anchoN - (anchoN / 2) - 43, (altoN / 2) + 3);
        }

        try {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            ImageIO.write(bi, "png", baos);
            baos.flush();
            imageInByte = baos.toByteArray();
            baos.close();
            bais = new ByteArrayInputStream(imageInByte);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return bais;
    }
    
    public static Dimension getDimensiones(Dimension dimensionPantalla){
        boolean autoAjustar = false;
        Dimension res = null, screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        int anchoAjustado = 0, altoAjustado = 0;
        
        if(screenSize.height < dimensionPantalla.height){
            altoAjustado = screenSize.height - 50;
            autoAjustar = true;
        } else {
            altoAjustado = dimensionPantalla.height;
        }
        
        if(screenSize.width < dimensionPantalla.width){
            anchoAjustado = screenSize.width - 10;
            autoAjustar = true;
        } else {
            anchoAjustado = dimensionPantalla.width;
        }
        if(autoAjustar){
            res = new Dimension(anchoAjustado, altoAjustado);
        }
        
        return res;
    }
}
