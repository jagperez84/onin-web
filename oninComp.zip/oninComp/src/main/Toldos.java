package main;
import acceso.BaseDatos;
import bean.Empresa;
import bean.Usuario;
import gui.Login;
import gui.MenuPrincipal;
import javax.swing.ImageIcon;
import javax.swing.UIManager;
//import org.apache.log4j.PropertyConfigurator;

public class Toldos {

    public static void main(String[] args) {
        try {
            
            //Esto es para que tenga el aspecto de Windows
            UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
            //PropertyConfigurator.configure("log4j.properties");
            //setIconImage(new ImageIcon(getClass().getResource("")).getImage());
            //Empresa e = BaseDatos.obtenerEmpresa("GV");
            //Usuario u = BaseDatos.obtenerUsuarioNombre("jose");
            
            Login frame = new Login();
            //MenuPrincipal frame = new MenuPrincipal(u,e);
            frame.setDefaultCloseOperation(Login.EXIT_ON_CLOSE);
            frame.setLocationRelativeTo(null);
            frame.setVisible(true);
        }
        catch (Exception e){
            e.printStackTrace();
        }
    }
}
