package informes.confeccionLonasTotal;

import informes.InformeGeneral;
import java.util.HashMap;
import net.sf.jasperreports.engine.JREmptyDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.view.JasperViewer;
import org.apache.log4j.Logger;

public class ConfeccionLonasTotal extends InformeGeneral {
    private static final Logger LOG = Logger.getLogger(ConfeccionLonasTotal.class);

    public static void imprimirConfeccionLonasTotal(HashMap parameters) {
        JasperReport jasperReportMaestro = CargarPlantilla(".\\src\\informes\\confeccionLonasTotal\\ConfeccionLonasTotal.jrxml", ".\\src\\informes\\confeccionLonasTotal\\ConfeccionLonasTotal.jasper");
        JasperReport jasperReportSubreporte1 = CargarPlantilla(".\\src\\informes\\confeccionLonasTotal\\DatosConfeccionLonasTotal.jrxml", ".\\src\\informes\\confeccionLonasTotal\\DatosConfeccionLonasTotal.jasper");

        parameters.put("reportDatosConfeccionLonasTotal", jasperReportSubreporte1);
        try {
            JasperViewer.viewReport(JasperFillManager.fillReport(jasperReportMaestro, parameters, new JREmptyDataSource()), false);
        } catch (JRException e) {
            LOG.error("Se ha producido una excepción en el método imprimirConfeccionLonasTotal", e);
        }
    }
}