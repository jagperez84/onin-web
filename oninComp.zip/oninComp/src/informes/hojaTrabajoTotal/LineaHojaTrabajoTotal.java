package informes.hojaTrabajoTotal;

public class LineaHojaTrabajoTotal {
    private String codigo;
    private String descripcion;
    private String color;
    private String cantidad;
    private String medidas;
    private String imprimirLineaSuperior;
    private String imprimirLineaLateral;
    private String codigoGris;
    private String descripcionGris;
    private String colorGris;
    private String cantidadGris;
    private String medidasGris;

    public LineaHojaTrabajoTotal() {
        codigo = "";
        descripcion = "";
        color = "";
        cantidad = "";
        medidas = "";
        imprimirLineaSuperior = "";
        imprimirLineaLateral = "";
        codigoGris = "";
        descripcionGris = "";
        colorGris = "";
        cantidadGris = "";
        medidasGris = "";
    }

    public String getCantidad() {
        return cantidad;
    }

    public void setCantidad(String cantidad) {
        this.cantidad = cantidad;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getMedidas() {
        return medidas;
    }

    public void setMedidas(String medidas) {
        this.medidas = medidas;
    }

    public String getImprimirLineaLateral() {
        return imprimirLineaLateral;
    }

    public void setImprimirLineaLateral(String imprimirLineaLateral) {
        this.imprimirLineaLateral = imprimirLineaLateral;
    }

    public String getImprimirLineaSuperior() {
        return imprimirLineaSuperior;
    }

    public void setImprimirLineaSuperior(String imprimirLineaSuperior) {
        this.imprimirLineaSuperior = imprimirLineaSuperior;
    }

    public String getCantidadGris() {
        return cantidadGris;
    }

    public void setCantidadGris(String cantidadGris) {
        this.cantidadGris = cantidadGris;
    }

    public String getCodigoGris() {
        return codigoGris;
    }

    public void setCodigoGris(String codigoGris) {
        this.codigoGris = codigoGris;
    }

    public String getColorGris() {
        return colorGris;
    }

    public void setColorGris(String colorGris) {
        this.colorGris = colorGris;
    }

    public String getDescripcionGris() {
        return descripcionGris;
    }

    public void setDescripcionGris(String descripcionGris) {
        this.descripcionGris = descripcionGris;
    }

    public String getMedidasGris() {
        return medidasGris;
    }

    public void setMedidasGris(String medidasGris) {
        this.medidasGris = medidasGris;
    }
}