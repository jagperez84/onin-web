package informes.hojaTrabajoTotal;

import informes.InformeGeneral;
import java.util.HashMap;
import net.sf.jasperreports.engine.JREmptyDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.view.JasperViewer;
import org.apache.log4j.Logger;

public class HojaTrabajoTotal extends InformeGeneral {
    private static final Logger LOG = Logger.getLogger(HojaTrabajoTotal.class);

    public static void imprimirHojaTrabajoTotal(HashMap parameters) {
        JasperReport jasperReportMaestro = CargarPlantilla(".\\src\\informes\\hojaTrabajoTotal\\HojaTrabajoTotal.jrxml", ".\\src\\informes\\hojaTrabajoTotal\\HojaTrabajoTotal.jasper");
        JasperReport jasperReportSubreporte1 = CargarPlantilla(".\\src\\informes\\hojaTrabajoTotal\\DatosHojaTrabajoTotal.jrxml", ".\\src\\informes\\hojaTrabajoTotal\\DatosHojaTrabajoTotal.jasper");

        parameters.put("reportDatosHojaTrabajoTotal", jasperReportSubreporte1);
        try {
            JasperPrint print = JasperFillManager.fillReport(jasperReportMaestro, parameters, new JREmptyDataSource());
            JasperViewer.viewReport(print, false);
        } catch (JRException e) {
            LOG.error("Se ha producido una excepción en el método imprimirHojaTrabajoTotal", e);
        }
    }
}