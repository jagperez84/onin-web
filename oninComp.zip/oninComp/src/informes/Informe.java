package informes;

import java.io.File;
import java.util.HashMap;
import net.sf.jasperreports.engine.JREmptyDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.view.JasperViewer;
import org.apache.log4j.Logger;

public class Informe extends InformeGeneral {
    private static final Logger LOG = Logger.getLogger(Informe.class);
    public static String ruta = "C:/Toldos/Temp";

    public static void imprimirPresupuesto(HashMap parameters) {
        JasperReport jasperReportMaestro = CargarPlantilla(".\\src\\informes\\Presupuesto.jrxml", ".\\src\\informes\\Presupuesto.jasper");
        JasperReport jasperReportSubreporte1 = CargarPlantilla(".\\src\\informes\\LineaPresupuesto.jrxml", ".\\src\\informes\\LineaPresupuesto.jasper");
        JasperReport jasperReportSubreporte2 = CargarPlantilla(".\\src\\informes\\PrecioPresupuesto.jrxml", ".\\src\\informes\\PrecioPresupuesto.jasper");
        JasperReport jasperReportSubreporte3 = CargarPlantilla(".\\src\\informes\\FormaPago.jrxml", ".\\src\\informes\\FormaPago.jasper");

        parameters.put("reportLineaPresupuesto", jasperReportSubreporte1);
        parameters.put("reportPrecioPresupuesto", jasperReportSubreporte2);
        parameters.put("reportFormaPago", jasperReportSubreporte3);
        try {
            JasperViewer.viewReport(JasperFillManager.fillReport(jasperReportMaestro, parameters, new JREmptyDataSource()), false);
        } catch (JRException e) {
            LOG.error("Se ha producido una excepción en el método imprimirPresupuesto", e);
        }
    }

    public static String crearPresupuestoEmail(HashMap parameters) {
        JasperReport jasperReportMaestro = CargarPlantilla(".\\src\\informes\\Presupuesto.jrxml", ".\\src\\informes\\Presupuesto.jasper");
        JasperReport jasperReportSubreporte1 = CargarPlantilla(".\\src\\informes\\LineaPresupuesto.jrxml", ".\\src\\informes\\LineaPresupuesto.jasper");
        JasperReport jasperReportSubreporte2 = CargarPlantilla(".\\src\\informes\\PrecioPresupuesto.jrxml", ".\\src\\informes\\PrecioPresupuesto.jasper");
        JasperReport jasperReportSubreporte3 = CargarPlantilla(".\\src\\informes\\FormaPago.jrxml", ".\\src\\informes\\FormaPago.jasper");

        parameters.put("reportLineaPresupuesto", jasperReportSubreporte1);
        parameters.put("reportPrecioPresupuesto", jasperReportSubreporte2);
        parameters.put("reportFormaPago", jasperReportSubreporte3);

        String numero = (String) parameters.get("numero");
        numero = numero.replace("\\", "_");
        numero = numero.replace("/", "_");
        String fecha = (String) parameters.get("fecha");
        fecha = fecha.replace("/", "_");
        fecha = fecha.replace("\\", "_");
        String rutaPdf = ruta + "/" + fecha + numero + ".pdf";
        try {
            JasperPrint print = JasperFillManager.fillReport(jasperReportMaestro, parameters, new JREmptyDataSource());
            File dirTemp = new File(ruta);
            if (!dirTemp.exists()) {
                dirTemp.mkdirs();
            }
            JasperExportManager.exportReportToPdfFile(print, rutaPdf);
        } catch (JRException e) {
            LOG.error("Se ha producido una excepción en el método crearPresupuestoEmail", e);
        }

        return rutaPdf;
    }

    public static void guardarPresupuesto(HashMap parameters, String fichero) {
        JasperReport jasperReportMaestro = CargarPlantilla(".\\src\\informes\\Presupuesto.jrxml", ".\\src\\informes\\Presupuesto.jasper");
        JasperReport jasperReportSubreporte1 = CargarPlantilla(".\\src\\informes\\LineaPresupuesto.jrxml", ".\\src\\informes\\LineaPresupuesto.jasper");
        JasperReport jasperReportSubreporte2 = CargarPlantilla(".\\src\\informes\\PrecioPresupuesto.jrxml", ".\\src\\informes\\PrecioPresupuesto.jasper");
        JasperReport jasperReportSubreporte3 = CargarPlantilla(".\\src\\informes\\FormaPago.jrxml", ".\\src\\informes\\FormaPago.jasper");

        parameters.put("reportLineaPresupuesto", jasperReportSubreporte1);
        parameters.put("reportPrecioPresupuesto", jasperReportSubreporte2);
        parameters.put("reportFormaPago", jasperReportSubreporte3);
        try {
            JasperPrint print = JasperFillManager.fillReport(jasperReportMaestro, parameters, new JREmptyDataSource());
            File dirTemp = new File(ruta);
            if (!dirTemp.exists()) {
                dirTemp.mkdirs();
            }
            JasperExportManager.exportReportToPdfFile(print, fichero);
        } catch (JRException e) {
            LOG.error("Se ha producido una excepción en el método guardarPresupuesto", e);
        }
    }
}
