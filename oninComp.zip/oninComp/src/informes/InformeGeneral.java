package informes;

import java.io.File;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.util.JRLoader;
import org.apache.log4j.Logger;

public class InformeGeneral {
    private static final Logger LOG = Logger.getLogger(InformeGeneral.class);

    public static JasperReport CargarPlantilla(String sPlantillaFuente, String sPlantillaCompilada) {
        JasperReport objetoJasperReport = null;
        File informeCompilado = new File(sPlantillaCompilada);
        try {
            objetoJasperReport = (JasperReport) JRLoader.loadObject(informeCompilado);
        } catch (JRException e) {
            LOG.error("Se ha producido una excepción en el método CargarPlantilla", e);
            try {
                JasperCompileManager.compileReportToFile(sPlantillaFuente, sPlantillaCompilada);
                objetoJasperReport = (JasperReport) JRLoader.loadObject(informeCompilado);
            } catch (JRException f) {
                try {
                    objetoJasperReport = JasperCompileManager.compileReport(sPlantillaFuente);
                } catch (JRException e1) {
                    LOG.error("Se ha producido una excepción en el método CargarPlantilla", e1);
                }
            }
        }
        return objetoJasperReport;
    }
}
