package informes.comerciales;

import informes.InformeGeneral;
import java.util.HashMap;
import net.sf.jasperreports.engine.JREmptyDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.view.JasperViewer;
import org.apache.log4j.Logger;

public class InformeComercial extends InformeGeneral {
    private static final Logger LOG = Logger.getLogger(InformeComercial.class);

    public static void imprimirPresupuesto(HashMap parameters) {
        JasperReport jasperReportMaestro = CargarPlantilla(".\\src\\informes\\comerciales\\Presupuesto.jrxml", ".\\src\\informes\\comerciales\\Presupuesto.jasper");
        JasperReport jasperReportSubreporte1 = CargarPlantilla(".\\src\\informes\\comerciales\\LineaPresupuesto.jrxml", ".\\src\\informes\\comerciales\\LineaPresupuesto.jasper");
        JasperReport jasperReportSubreporte2 = CargarPlantilla(".\\src\\informes\\comerciales\\PrecioPresupuesto.jrxml", ".\\src\\informes\\comerciales\\PrecioPresupuesto.jasper");

        parameters.put("reportLineaPresupuesto", jasperReportSubreporte1);
        parameters.put("reportPrecioPresupuesto", jasperReportSubreporte2);
        try {
            JasperViewer.viewReport(JasperFillManager.fillReport(jasperReportMaestro, parameters, new JREmptyDataSource()), false);
        } catch (JRException e) {
            LOG.error("Se ha producido una excepción en el método imprimirPresupuesto", e);
        }
    }
}
