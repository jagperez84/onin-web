package informes.recibos;

import informes.InformeGeneral;
import java.util.HashMap;
import net.sf.jasperreports.engine.JREmptyDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.view.JasperViewer;
import org.apache.log4j.Logger;

public class Recibo extends InformeGeneral{
    private static final Logger LOG = Logger.getLogger(Recibo.class);

    public static void imprimirRecibo(HashMap parameters) {
        JasperReport jasperReportMaestro = CargarPlantilla(".\\src\\informes\\recibos\\Recibos.jrxml", ".\\src\\informes\\recibos\\Recibos.jasper");
        JasperReport jasperReportSubreporte1 = CargarPlantilla(".\\src\\informes\\recibos\\Vencimiento.jrxml", ".\\src\\informes\\recibos\\Vencimiento.jasper");
        
        parameters.put("reportVencimiento", jasperReportSubreporte1);
        try {
            JasperViewer.viewReport(JasperFillManager.fillReport(jasperReportMaestro, parameters, new JREmptyDataSource()), false);
        } catch (JRException e) {
            LOG.error("Se ha producido una excepción en el método imprimirRecibo", e);
        }
    }
}