package informes.recibos;

public class VencimientoImpreso {
    String ejemplarPara;
    String numRecibo;
    String fechaExp;
    String fechaVen;
    String importeStr;
    String importeEuros;
    String entidad;
    String cuenta; 
    String nombre;
    String direccion;
    String codPostalLocalidad;
    String provincia;
    String telefono;
    String cifDni;
    String nombreEmpresa;
    String cifEmpresa;

    public VencimientoImpreso(String ejemplarPara, String numRecibo, String fechaExp, String fechaVen, String importeStr, String importeEuros, String entidad, String cuenta, String nombre, String direccion, String codPostalLocalidad, String provincia, String telefono, String cifDni, String nombreEmpresa, String cifEmpresa) {
        this.ejemplarPara = ejemplarPara;
        this.numRecibo = numRecibo;
        this.fechaExp = fechaExp;
        this.fechaVen = fechaVen;
        this.importeStr = importeStr;
        this.importeEuros = importeEuros;
        this.entidad = entidad;
        this.cuenta = cuenta;
        this.nombre = nombre;
        this.direccion = direccion;
        this.codPostalLocalidad = codPostalLocalidad;
        this.provincia = provincia;
        this.telefono = telefono;
        this.cifDni = cifDni;
        this.nombreEmpresa = nombreEmpresa;
        this.cifEmpresa = cifEmpresa;
    }

    public String getCifDni() {
        return cifDni;
    }

    public void setCifDni(String cifDni) {
        this.cifDni = cifDni;
    }

    public String getCifEmpresa() {
        return cifEmpresa;
    }

    public void setCifEmpresa(String cifEmpresa) {
        this.cifEmpresa = cifEmpresa;
    }

    public String getCodPostalLocalidad() {
        return codPostalLocalidad;
    }

    public void setCodPostalLocalidad(String codPostalLocalidad) {
        this.codPostalLocalidad = codPostalLocalidad;
    }

    public String getCuenta() {
        return cuenta;
    }

    public void setCuenta(String cuenta) {
        this.cuenta = cuenta;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getEjemplarPara() {
        return ejemplarPara;
    }

    public void setEjemplarPara(String ejemplarPara) {
        this.ejemplarPara = ejemplarPara;
    }

    public String getEntidad() {
        return entidad;
    }

    public void setEntidad(String entidad) {
        this.entidad = entidad;
    }

    public String getFechaExp() {
        return fechaExp;
    }

    public void setFechaExp(String fechaExp) {
        this.fechaExp = fechaExp;
    }

    public String getFechaVen() {
        return fechaVen;
    }

    public void setFechaVen(String fechaVen) {
        this.fechaVen = fechaVen;
    }

    public String getImporteEuros() {
        return importeEuros;
    }

    public void setImporteEuros(String importeEuros) {
        this.importeEuros = importeEuros;
    }

    public String getImporteStr() {
        return importeStr;
    }

    public void setImporteStr(String importeStr) {
        this.importeStr = importeStr;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getNombreEmpresa() {
        return nombreEmpresa;
    }

    public void setNombreEmresa(String nombreEmpresa) {
        this.nombreEmpresa = nombreEmpresa;
    }

    public String getNumRecibo() {
        return numRecibo;
    }

    public void setNumRecibo(String numRecibo) {
        this.numRecibo = numRecibo;
    }

    public String getProvincia() {
        return provincia;
    }

    public void setProvincia(String provincia) {
        this.provincia = provincia;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }
}