package informes.mediciones;

import informes.InformeGeneral;
import java.util.HashMap;
import net.sf.jasperreports.engine.JREmptyDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.view.JasperViewer;
import org.apache.log4j.Logger;

public class Mediciones extends InformeGeneral{
    private static final Logger LOG = Logger.getLogger(Mediciones.class);

    public static void imprimirMedicion(HashMap parameters) {
        JasperReport jasperReportMaestro = CargarPlantilla(".\\src\\informes\\mediciones\\Mediciones.jrxml", ".\\src\\informes\\mediciones\\Mediciones.jasper");       
        try {
            JasperViewer.viewReport(JasperFillManager.fillReport(jasperReportMaestro, parameters, new JREmptyDataSource()), false);
        } catch (JRException e) {
            LOG.error("Se ha producido una excepción en el método imprimirMedicion ", e);
        }
    }
}