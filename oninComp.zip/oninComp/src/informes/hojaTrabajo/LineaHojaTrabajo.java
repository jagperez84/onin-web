package informes.hojaTrabajo;

public class LineaHojaTrabajo {
    private String codigo;
    private String descripcion;
    private String color;
    private String cantidad;
    private String medidas;

    public LineaHojaTrabajo(String codigo, String descripcion, String color, String cantidad, String medidas) {
        this.codigo = codigo;
        this.descripcion = descripcion;
        this.color = color;
        this.cantidad = cantidad;
        this.medidas = medidas;
    }

    public LineaHojaTrabajo(String descripcion) {
        this.descripcion = descripcion;
        this.codigo = "";
        this.color = "";
        this.medidas = "";
        this.cantidad = "";
    }

    public LineaHojaTrabajo() {
    }
    
    public String getCantidad() {
        return cantidad;
    }

    public void setCantidad(String cantidad) {
        this.cantidad = cantidad;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getMedidas() {
        return medidas;
    }

    public void setMedidas(String medidas) {
        this.medidas = medidas;
    }
}
