package informes.hojaTrabajo;

import informes.InformeGeneral;
import java.util.HashMap;
import net.sf.jasperreports.engine.JREmptyDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.view.JasperViewer;
import org.apache.log4j.Logger;

public class HojaTrabajo extends InformeGeneral {
    private static final Logger LOG = Logger.getLogger(HojaTrabajo.class);

    public static void imprimirHojaTrabajo(HashMap parameters) {
        JasperReport jasperReportMaestro = CargarPlantilla(".\\src\\informes\\hojaTrabajo\\HojaTrabajo.jrxml", ".\\src\\informes\\hojaTrabajo\\HojaTrabajo.jasper");
        JasperReport jasperReportSubreporte1 = CargarPlantilla(".\\src\\informes\\hojaTrabajo\\DatosHojaTrabajo.jrxml", ".\\src\\informes\\hojaTrabajo\\DatosHojaTrabajo.jasper");
        JasperReport jasperReportSubreporte2 = CargarPlantilla(".\\src\\informes\\hojaTrabajo\\LineaHojaTrabajo.jrxml", ".\\src\\informes\\hojaTrabajo\\LineaHojaTrabajo.jasper");

        parameters.put("reportDatosHojaTrabajo", jasperReportSubreporte1);
        parameters.put("reportLineaHojaTrabajo", jasperReportSubreporte2);
        try {
            JasperViewer.viewReport(JasperFillManager.fillReport(jasperReportMaestro, parameters, new JREmptyDataSource()), false);
        } catch (JRException e) {
            LOG.error("Se ha producido una excepción en el método imprimirHojaTrabajo", e);
        }
    }
}