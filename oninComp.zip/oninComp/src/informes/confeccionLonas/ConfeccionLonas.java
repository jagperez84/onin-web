package informes.confeccionLonas;

import informes.InformeGeneral;
import java.util.HashMap;
import net.sf.jasperreports.engine.JREmptyDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.view.JasperViewer;
import org.apache.log4j.Logger;

public class ConfeccionLonas extends InformeGeneral {
    private static final Logger LOG = Logger.getLogger(ConfeccionLonas.class);

    public static void imprimirConfeccionLonas(HashMap parameters) {
        JasperReport jasperReportMaestro = CargarPlantilla(".\\src\\informes\\confeccionLonas\\ConfeccionLonas.jrxml", ".\\src\\informes\\confeccionLonas\\ConfeccionLonas.jasper");
        JasperReport jasperReportSubreporte1 = CargarPlantilla(".\\src\\informes\\confeccionLonas\\LineaLona.jrxml", ".\\src\\informes\\confeccionLonas\\LineaLona.jasper");
        JasperReport jasperReportSubreporte2 = CargarPlantilla(".\\src\\informes\\confeccionLonas\\DatosConfeccionLonas.jrxml", ".\\src\\informes\\confeccionLonas\\DatosConfeccionLonas.jasper");

        parameters.put("reportLineaLona", jasperReportSubreporte1);
        parameters.put("reportDatosConfeccionLonas", jasperReportSubreporte2);
        try {
            JasperViewer.viewReport(JasperFillManager.fillReport(jasperReportMaestro, parameters, new JREmptyDataSource()), false);
        } catch (JRException e) {
            LOG.error("Se ha producido una excepción en el método imprimirConfeccionLonas", e);
        }
    }
}
