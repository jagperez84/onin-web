package informes.confeccionLonas;

import java.io.ByteArrayInputStream;

public class LineaConfeccion {
    private ByteArrayInputStream imagenConfeccion;
    private String contadorLinea;
    private String codigo;
    private String cant;
    private String medida;
    private String numeroDoc;
    private String descInterna;
    private String articulos;
    private String descripcion;
    private String corte;
    
    public LineaConfeccion(){
    
    }

    public ByteArrayInputStream getImagenConfeccion() {
        return imagenConfeccion;
    }

    public void setImagenConfeccion(ByteArrayInputStream imagenConfeccion) {
        this.imagenConfeccion = imagenConfeccion;
    }

    public String getCant() {
        return cant;
    }

    public void setCant(String cant) {
        this.cant = cant;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getContadorLinea() {
        return contadorLinea;
    }

    public void setContadorLinea(String contadorLinea) {
        this.contadorLinea = contadorLinea;
    }

    public String getMedida() {
        return medida;
    }

    public void setMedida(String medida) {
        this.medida = medida;
    }

    public String getNumeroDoc() {
        return numeroDoc;
    }

    public void setNumeroDoc(String numeroDoc) {
        this.numeroDoc = numeroDoc;
    }

    public String getDescInterna() {
        return descInterna;
    }

    public void setDescInterna(String descToldo) {
        this.descInterna = descToldo;
    }

    public String getArticulos() {
        return articulos;
    }

    public void setArticulos(String articulos) {
        this.articulos = articulos;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getCorte() {
        return corte;
    }

    public void setCorte(String corte) {
        this.corte = corte;
    }
}