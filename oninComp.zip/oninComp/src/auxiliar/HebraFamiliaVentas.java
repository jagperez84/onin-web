package auxiliar;

import acceso.BaseDatos;
import bean.Articulo;
import bean.Caracteristica;
import bean.Empresa;
import bean.Precios;
import bean.Usuario;
import gui.LogMasivoProgreso;
import gui.NuevaFamiliaVenta;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import javax.swing.JOptionPane;

public class HebraFamiliaVentas implements Runnable {
    private LogMasivoProgreso lmp;
    private NuevaFamiliaVenta nfv;
    
    public HebraFamiliaVentas(LogMasivoProgreso lmp, NuevaFamiliaVenta nfv) {
        this.lmp = lmp;
        this.nfv = nfv;
    }

    public void run() {
        aplicarCalculo();
    }
    
    private void aplicarCalculo(){
        Usuario u = nfv.getUsuario();
        Empresa e = nfv.getEmpresa();
        List lart = BaseDatos.getListaArticuloFV(e, nfv.getFamiliaVenta());
        Articulo art = new Articulo();
        Caracteristica car = new Caracteristica();
        List<Caracteristica> listC = new ArrayList();
        Iterator iA = lart.iterator();
        Integer cont = 0;
        Precios p;
        Date fecha = new Date();

        Float pvpB = null;
        Float ptcB = null;
        Float upcB = null;

        Float pvpR = null;
        Float ptcR = null;
        Float upcR = null;

        Float pvpE = null;
        Float ptcE = null;
        Float upcE = null;
        
        Float pvpS = null;
        Float ptcS = null;
        Float upcS = null;

        //Obtener estructura de precio
        if (nfv.getAnadirB()) {
            pvpB = Float.parseFloat(util.Util.convertirComaAPunto(nfv.getTPVPbTexto()));
            ptcB = Float.parseFloat(util.Util.convertirComaAPunto(nfv.getTPTCbTexto()));
            upcB = Float.parseFloat(util.Util.convertirComaAPunto(nfv.getTUPCbTexto()));
        }

        if (nfv.getAnadirR()) {
            pvpR = Float.parseFloat(util.Util.convertirComaAPunto(nfv.getTPVPrTexto()));
            ptcR = Float.parseFloat(util.Util.convertirComaAPunto(nfv.getTPTCrTexto()));
            upcR = Float.parseFloat(util.Util.convertirComaAPunto(nfv.getTUPCrTexto()));
        }

        if (nfv.getAnadirE()) {
            pvpE = Float.parseFloat(util.Util.convertirComaAPunto(nfv.getTPVPeTexto()));
            ptcE = Float.parseFloat(util.Util.convertirComaAPunto(nfv.getTPTCeTexto()));
            upcE = Float.parseFloat(util.Util.convertirComaAPunto(nfv.getTUPCeTexto()));
        }
        
        if (nfv.getAnadirS()) {
            pvpS = Float.parseFloat(util.Util.convertirComaAPunto(nfv.getTPVPsTexto()));
            ptcS = Float.parseFloat(util.Util.convertirComaAPunto(nfv.getTPTCsTexto()));
            upcS = Float.parseFloat(util.Util.convertirComaAPunto(nfv.getTUPCsTexto()));
        }
    
        while (iA.hasNext()) {
            art = (Articulo) iA.next();
            p = new Precios();
            listC = BaseDatos.getListaCaracteristicas(e, art);
            Iterator iC = listC.iterator();
            cont++;
            //Si no tenemos caracteristicas
            if (listC.isEmpty()) {
                //Cambiamos el valor del precio de articulo si el base está marcado
                if (nfv.getAnadirS()) {
                    //Obtener el precio para lacado Base 
                    // precioFamilia pF = (precioFamilia) precios.get(0);
                    art.setPrecio_v(pvpS);
                    art.setPtc(ptcS);
                    art.setUpc(upcS);

                    //Modificamos el artículo
                    BaseDatos.modificarElemento(art);
                    lmp.insertarLinea("Actualizando artículo " + art.getCod_articulo());

                    //Modificar registro precio
                    p.setIid_art(art);
                    p.setIid_car(0); //Precio articulo
                    p.setIid_empresa(e);
                    p.setFecha(fecha.getTime());
                    p.setUpc(upcS);
                    p.setPtc(ptcS);
                    p.setPvp(pvpS);
                    p.setPi(0F);
                    p.setAccion("Actualización por FV");
                    p.setUsuario(u.getNombre());
                    BaseDatos.insertarElemento(p);
                }
            } else {
                //Obtenemos los colores del ral
                //Blanco / Sin color
                if (nfv.getAnadirS()) {
                    iC = listC.iterator();
                    p = new Precios();
                    while (iC.hasNext()) {
                        car = (Caracteristica) iC.next();
                        if (car.getIid_color().getRal() == 0) {
                            //Se actualiza precio
                            //Obtener el precio para lacado Base 
                            //precioFamilia pF = (precioFamilia) precios.get(0);
                            car.setPvp(pvpS);
                            car.setPtc(ptcS);
                            car.setUpc(upcS);
                            //Modificamos el artículo
                            BaseDatos.modificarElemento(car);
                            lmp.insertarLinea("Actualizando artículo " + art.getCod_articulo() +", característica " + car.getIid_color().getDescripcion());

                            //Modificar registro precio
                            p.setIid_art(art);
                            p.setIid_car(car.getIid_color().getIid()); //Precio articulo
                            p.setIid_empresa(e);
                            p.setFecha(fecha.getTime());
                            p.setUpc(upcS);
                            p.setPtc(ptcS);
                            p.setPvp(pvpS);
                            p.setPi(0F);
                            p.setAccion("Actualización por FV");
                            p.setUsuario(u.getNombre());
                            BaseDatos.insertarElemento(p);
                        }
                    }
                }
                
                //Base
                if (nfv.getAnadirB()) {
                    iC = listC.iterator();
                    p = new Precios();
                    while (iC.hasNext()) {
                        car = (Caracteristica) iC.next();
                        if (car.getIid_color().getRal() == 1) {
                            //Se actualiza precio
                            //Obtener el precio para lacado Base 
                            //precioFamilia pF = (precioFamilia) precios.get(0);
                            car.setPvp(pvpB);
                            car.setPtc(ptcB);
                            car.setUpc(upcB);
                            //Modificamos el artículo
                            BaseDatos.modificarElemento(car);
                            lmp.insertarLinea("Actualizando artículo " + art.getCod_articulo() +", característica " + car.getIid_color().getDescripcion());

                            //Modificar registro precio
                            p.setIid_art(art);
                            p.setIid_car(car.getIid_color().getIid()); //Precio articulo
                            p.setIid_empresa(e);
                            p.setFecha(fecha.getTime());
                            p.setUpc(upcB);
                            p.setPtc(ptcB);
                            p.setPvp(pvpB);
                            p.setPi(0F);
                            p.setAccion("Actualización por FV");
                            p.setUsuario(u.getNombre());
                            BaseDatos.insertarElemento(p);
                        }
                    }
                }

                //Ral
                if (nfv.getAnadirR()) {
                    p = new Precios();
                    iC = listC.iterator();
                    while (iC.hasNext()) {
                        car = (Caracteristica) iC.next();
                        if (car.getIid_color().getRal() == 2) {
                            //Se actualiza precio
                            //Obtener el precio para lacado Base 
                            //precioFamilia pF = (precioFamilia) precios.get(1);
                            car.setPvp(pvpR);
                            car.setPtc(ptcR);
                            car.setUpc(upcR);
                            //Modificamos el artículo
                            BaseDatos.modificarElemento(car);
                            lmp.insertarLinea("Actualizando artículo " + art.getCod_articulo() +", característica " + car.getIid_color().getDescripcion());

                            //Modificar registro precio
                            p.setIid_art(art);
                            p.setIid_car(car.getIid_color().getIid()); //Precio articulo
                            p.setIid_empresa(e);
                            p.setFecha(fecha.getTime());
                            p.setUpc(upcR);
                            p.setPtc(ptcR);
                            p.setPvp(pvpR);
                            p.setPi(0F);
                            p.setAccion("Actualización por FV");
                            p.setUsuario(u.getNombre());
                            BaseDatos.insertarElemento(p);
                        }
                    }
                }
                //Especial
                if (nfv.getAnadirE()) {
                    iC = listC.iterator();
                    p = new Precios();
                    while (iC.hasNext()) {
                        car = (Caracteristica) iC.next();
                        if (car.getIid_color().getRal() == 3) {
                            //Se actualiza precio
                            //Obtener el precio para lacado Base 
                            // precioFamilia pF = (precioFamilia) precios.get(2);
                            car.setPvp(pvpE);
                            car.setPtc(ptcE);
                            car.setUpc(upcE);
                            //Modificamos el artículo
                            BaseDatos.modificarElemento(car);
                            lmp.insertarLinea("Actualizando artículo " + art.getCod_articulo() +", característica " + car.getIid_color().getDescripcion());

                            //Modificar registro precio
                            p.setIid_art(art);
                            p.setIid_car(car.getIid_color().getIid()); //Precio articulo
                            p.setIid_empresa(e);
                            p.setFecha(fecha.getTime());
                            p.setUpc(upcE);
                            p.setPtc(ptcE);
                            p.setPvp(pvpE);
                            p.setPi(0F);
                            p.setAccion("Actualización por FV");
                            p.setUsuario(u.getNombre());
                            BaseDatos.insertarElemento(p);
                        }
                    }
                }
            }
        }
        lmp.acabarProceso();
        JOptionPane.showMessageDialog(null, "Se han actualizados los precios", "Actualizado", JOptionPane.INFORMATION_MESSAGE);
    }
}
