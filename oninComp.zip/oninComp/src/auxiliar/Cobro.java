
package auxiliar;

public class Cobro {
    private String numero;
    private String nombre;
    private String tipoDocumento;
    private Double importe;
    private Long fechaVencimiento;
    private String cobrado;
    private String tipoCobro;

    
    public Cobro(String numero, String nombre, String tipoDocumento, Double importe, Long fechaVencimiento, String cobrado, String tipoCobro) {
        this.numero = numero;
        this.nombre = nombre;
        this.tipoDocumento = tipoDocumento;
        this.importe = importe;
        this.fechaVencimiento = fechaVencimiento;
        this.cobrado = cobrado;
        this.tipoCobro = tipoCobro;
    }

    public String getCobrado() {
        return cobrado;
    }

    public void setCobrado(String cobrado) {
        this.cobrado = cobrado;
    }

    public Long getFechaVencimiento() {
        return fechaVencimiento;
    }

    public void setFechaVencimiento(Long fechaVencimiento) {
        this.fechaVencimiento = fechaVencimiento;
    }

    public Double getImporte() {
        return importe;
    }

    public void setImporte(Double importe) {
        this.importe = importe;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public String getTipoDocumento() {
        return tipoDocumento;
    }

    public void setTipoDocumento(String tipoDocumento) {
        this.tipoDocumento = tipoDocumento;
    }

    public String getTipoCobro() {
        return tipoCobro;
    }

    public void setTipoCobro(String tipoCobro) {
        this.tipoCobro = tipoCobro;
    }
}

