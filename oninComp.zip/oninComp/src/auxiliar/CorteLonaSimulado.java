package auxiliar;

import acceso.BaseDatos;
import bean.Articulo;
import bean.Caracteristica;
import bean.Colores;
import bean.Despiece;
import gui.NuevaLineaPresupuesto;
import gui.RellenarDac;
import util.Util;

public class CorteLonaSimulado {

    private RellenarDac rd;
    private NuevaLineaPresupuesto lp;
    private Integer indiceElemento;
    private Articulo arti;
    private Caracteristica carac;
    private int codigoLinea;
    
    
    public CorteLonaSimulado(int codigoLinea, RellenarDac rd, int indice, NuevaLineaPresupuesto lp){
        this.rd = rd;
        this.indiceElemento = indice;
        this.lp = lp;
        this.codigoLinea = codigoLinea;
        
        Despiece despi = rd.getListaDespiece().get(indiceElemento);
        arti = despi.getArticulo();
        arti = BaseDatos.obtenerArticuloPorIid(arti.getIid());
        carac = despi.getCaracteristica();
        if(carac != null){
            carac = BaseDatos.obtenerCaracteristicaPorIid(carac.getIid());
        }
    }

    public CorteLonaSimulado(int codigoLinea, NuevaLineaPresupuesto lp){
        this.rd = null;
        this.lp = lp;
        this.codigoLinea = codigoLinea;
        arti = lp.getArticulo();
        arti = BaseDatos.obtenerArticuloPorIid(arti.getIid());
        carac = lp.getCaracteristica();
        if(carac != null){
            carac = BaseDatos.obtenerCaracteristicaPorIid(carac.getIid());
        }
    }
    
    public String getCantidad() {
        if(rd != null){
            Despiece despi = rd.getListaDespiece().get(indiceElemento);
            return Util.convertirPuntoAComa(rd.evaluar(despi.getFormulaCantidad(), despi.getRedondeo(), false).toString());
        } else {
            return Util.convertirPuntoAComa(lp.getTcantidad());
        }
    }

    public String getCodigoArticuloCaracterisitica() {
        String codigo = arti.getCod_articulo();
        
        if(carac != null){
            Colores col= carac.getIid_color();
            col = BaseDatos.obtenerColorPorIid(col.getIid());
            codigo += "/" + col.getCod_color();
        }

        return codigo;
    }

    public Integer getIddNuevaLineaPresupuesto() {
        if(lp != null){
            return lp.getIid();
        } else {
            return null;
        }
    }
    
    public Integer getIndiceElemento(){
        return indiceElemento;
    }

    public String getMedida1(){
        if(rd != null){
            Despiece despi = rd.getListaDespiece().get(indiceElemento);
            return Util.convertirPuntoAComa(rd.evaluar(despi.getFormulaMedida1(), despi.getRedondeo(), false).toString());
        } else {
            return Util.convertirPuntoAComa(String.valueOf(lp.getMedida1()));
        }
    }
    
    public String getMedida2(){
        if(rd != null){
            Despiece despi = rd.getListaDespiece().get(indiceElemento);
            return Util.convertirPuntoAComa(rd.evaluar(despi.getFormulaMedida2(), despi.getRedondeo(), false).toString());
        } else {
            return Util.convertirPuntoAComa(String.valueOf(lp.getMedida2()));
        }
    }
    
    public String getCodigoLinea(){
        return String.valueOf(codigoLinea);
    }
    
    public Caracteristica getCaracteristica(){
        return carac;
    }
    
    public Articulo getArticulo(){
        return arti;
    }

    public boolean getEsDespiece(){
        return rd != null;
    }
    
    public RellenarDac getRd(){
        return this.rd;
    }
}
