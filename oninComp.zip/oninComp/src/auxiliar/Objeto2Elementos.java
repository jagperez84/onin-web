/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package auxiliar;

/**
 *
 * @author Tony
 */
public class Objeto2Elementos {
    
    private String elemento1;
    private String elemento2;

    public Objeto2Elementos() {
    
    }
    
    public Objeto2Elementos(String elemento1, String elemento2) {
        this.elemento1 = elemento1;
        this.elemento2 = elemento2;
    }

    public String getElemento1() {
        return elemento1;
    }

    public void setElemento1(String elemento1) {
        this.elemento1 = elemento1;
    }

    public String getElemento2() {
        return elemento2;
    }

    public void setElemento2(String elemento2) {
        this.elemento2 = elemento2;
    }
}
