package auxiliar;

import acceso.BaseDatos;
import bean.Articulo;
import bean.Caracteristica;
import bean.Colores;
import bean.Empresa;
import bean.Precios;
import gui.LogMasivoProgreso;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.swing.JOptionPane;
import jxl.Sheet;
import jxl.Workbook;

public class HebraActualizarPrecios implements Runnable {

    private Empresa em;
    private LogMasivoProgreso lmp;
    private Workbook workbook;

    public HebraActualizarPrecios(LogMasivoProgreso lmp, Workbook workbook, Empresa e) {
        this.em = e;
        this.lmp = lmp;
        this.workbook = workbook;
    }

    public void run() {
        actualizarPrecios();
    }

    private void actualizarPrecios() {
        
        Sheet sheet;
        int columna, numColumnas;
        int fila, numFilas;
        List<Integer> lColumnas;
        List<Integer> lFilas;
        List listaPrecios = new ArrayList();
        Date fecha = new Date();
        Float cell;
        Articulo articulo;
        Float pvp = new Float(0);
        Float upc = new Float(0);
        Float ptc = new Float(0);
        Float pi = new Float(0);
        Caracteristica car;
        Colores c;
        int cont = 0;
        int err = 0;
        Precios p = new Precios();
        //Obtenemos la hoja a analizar
        sheet = workbook.getSheet(0);
        //Calculamos el número de columnas
        numColumnas = sheet.getColumns();
        //Calculamos el numero de filas
        numFilas = sheet.getRows();

        //Calculamos cada elemento [fila,columna]=Dato
        for (fila = 0; fila < numFilas; fila++) {
            //0 Código 1 Caracteristica 3 UPC 4 PTC 5 PVP 6 Precio Incremento
            //Comprobamos si es un artículo o una caracteristica
            //if (sheet.getCell(fila, 1).toString().equals("")){
            //Es un artículo, tiene el campo caracteristicas vacío
            try{
                if (sheet.getCell(1, fila).getContents().isEmpty()) {

                    upc = upc.parseFloat(sheet.getCell(2, fila).getContents().replace(",", "."));
                    ptc = ptc.parseFloat(sheet.getCell(3, fila).getContents().replace(",", "."));
                    pvp = pvp.parseFloat(sheet.getCell(4, fila).getContents().replace(",", "."));
                    pi = pi.parseFloat(sheet.getCell(5, fila).getContents().replace(",", "."));

                    articulo = BaseDatos.obtenerArticulo(sheet.getCell(0, fila).getContents(), em.getIid());
                    if (articulo != null) {
                        articulo.setUpc(upc);
                        articulo.setPtc(ptc);
                        articulo.setPrecio_v(pvp);
                        articulo.setPrecioIncremento(pi);
                        BaseDatos.modificarElemento(articulo);
                        lmp.insertarLinea("Actualizando el artículo " + sheet.getCell(0, fila).getContents());

                        //Actualizar lista de precios
                        p.setIid_art(articulo);
                        p.setIid_car(0); //Precio articulo
                        p.setIid_empresa(em);
                        p.setFecha(fecha.getTime());
                        p.setUpc(upc);
                        p.setPtc(ptc);
                        p.setPvp(pvp);
                        p.setPi(0F);
                        BaseDatos.insertarElemento(p);
                        cont++;
                    } else {
                        err++;
                        lmp.insertarLinea("El artículo " + sheet.getCell(0, fila).getContents() + " no existe");
                    }
                } else {
                    //Vamos a modificar una característica
                    articulo = BaseDatos.obtenerArticulo(sheet.getCell(0, fila).getContents(), em.getIid());
                    c = BaseDatos.obtenerColor(sheet.getCell(1, fila).getContents());
                    car = BaseDatos.obtenerCaracteristica(articulo, em, c);
                    if (car != null) {

                        upc = upc.parseFloat(sheet.getCell(2, fila).getContents().replace(",", "."));
                        ptc = ptc.parseFloat(sheet.getCell(3, fila).getContents().replace(",", "."));
                        pvp = pvp.parseFloat(sheet.getCell(4, fila).getContents().replace(",", "."));
                        pi = pi.parseFloat(sheet.getCell(5, fila).getContents().replace(",", "."));

                        car.setUpc(upc);
                        car.setPtc(ptc);
                        car.setPvp(pvp);
                        car.setPrecioIncremento(pi);
                        BaseDatos.modificarElemento(car);
                        lmp.insertarLinea("Actualizando el artículo " + articulo.getCod_articulo() + " - característica " + c.getCod_color());

                        //Actualizar lista de precios
                        p.setIid_art(articulo);
                        p.setIid_car(car.getIid_color().getIid()); //Precio articulo
                        p.setIid_empresa(em);
                        p.setFecha(fecha.getTime());
                        p.setUpc(upc);
                        p.setPtc(ptc);
                        p.setPvp(pvp);
                        p.setPi(0F);
                        BaseDatos.insertarElemento(p);
                        cont++;
                    } else {
                        lmp.insertarLinea("El artículo " + sheet.getCell(0, fila).getContents() + " no posee la característica " + sheet.getCell(1, fila).getContents());
                        err++;
                    }
                }
            } catch (Exception ex){
                lmp.insertarLinea("Error al procesar la línea " + fila);
            }
        }
        lmp.acabarProceso();
        JOptionPane.showMessageDialog(null, "Se han modificado " + cont + " elementos, han aparecido " + err + " errores", "Información", JOptionPane.INFORMATION_MESSAGE);
    }
}
