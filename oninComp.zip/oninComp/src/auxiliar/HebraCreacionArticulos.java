package auxiliar;

import acceso.BaseDatos;
import bean.AgenteArticulo;
import bean.AgenteArticuloCodigo;
import bean.Agentes;
import bean.Articulo;
import bean.ArticuloDescuento;
import bean.Caracteristica;
import bean.Colores;
import bean.Empresa;
import bean.Escalado;
import bean.Existencia;
import bean.FamiliaVenta;
import bean.Iva;
import bean.Moneda;
import bean.MovimientoAlmacen;
import bean.colorFamilia;
import bean.Precios;
import bean.Usuario;
import gui.LogMasivoProgreso;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import javax.swing.JOptionPane;
import jxl.Sheet;
import jxl.Workbook;

public class HebraCreacionArticulos implements Runnable {

    private Empresa em;
    private List<Caracteristica> listaCaracteristicas;
    private List<Escalado> listaEscalados;
    private List<MovimientoAlmacen> listaMovimientos;
    private List<MovimientoAlmacen> listaMovimientosBorrados;
    private List<MovimientoAlmacen> listaMovimientosCreados;
    private List<Existencia> listaExistencias;
    private List<ArticuloDescuento> lArticuloDescuentos;
    private List<AgenteArticulo> lAgenteArticulo;
    private List<AgenteArticuloCodigo> lAgenteArticuloCodigo;
    private List<Precios> listaPrecios = new ArrayList();
    private Usuario u;
    private LogMasivoProgreso lmp;
    private Workbook workbook;
    
    public HebraCreacionArticulos(LogMasivoProgreso lmp, Workbook workbook, Empresa e, Usuario us) {
        this.em = e;
        this.u = us;
        this.lmp = lmp;
        this.workbook = workbook;
    }

    public void run() {
        actualizarPrecios(workbook);
    }
    
    private void actualizarPrecios(Workbook workbook) {

        Sheet sheet;
        int fila, numFilas;

        Articulo articulo;
        Float pvp = new Float(0);
        Float upc = new Float(0);
        Float ptc = new Float(0);
        Float pi = new Float(0);
        Caracteristica car;
        Colores c;
        Moneda m;
        Iva i;
        int cont = 0;
        int err = 0;

        Date fecha = new Date();

        //Obtenemos la hoja a analizar
        sheet = workbook.getSheet(0);

        //Calculamos el numero de filas
        numFilas = sheet.getRows();
        if (listaCaracteristicas != null) {
            listaCaracteristicas.clear();
        }

        m = BaseDatos.obtenerMoneda("EUR");
        i = BaseDatos.obtenerIvaPorTipo(21);

        //Calculamos cada elemento [fila,columna]=Dato
        for (fila = 1; fila < numFilas; fila++) {
            //0 Código 1 Caracteristica 3 UPC 4 PTC 5 PVP 6 Precio Incremento
            //Comprobamos si es un artículo o una caracteristica
            //if (sheet.getCell(fila, 1).toString().equals("")){
            //Es un artículo, tiene el campo caracteristicas vacío

            // if (sheet.getCell(1, fila).getContents().isEmpty()) {
            articulo = new Articulo();
            Precios p = new Precios();

            listaPrecios.clear();

            if (BaseDatos.obtenerArticulo(sheet.getCell(0, fila).getContents().toString(), em.getIid()) == null) {
                FamiliaVenta fv = BaseDatos.obtenerFamiliaVentaPorNombre(em, sheet.getCell(4, fila).getContents().toString());
                listaCaracteristicas = BaseDatos.getListaCaracteristicas(em, articulo);
                listaEscalados = BaseDatos.getListaEscalados(articulo.getIid());
                listaExistencias = BaseDatos.getListaExistencias(articulo);
                listaMovimientos = BaseDatos.getListaMovimientosAlmacenFiltrados(articulo, em);
                listaMovimientosBorrados = new ArrayList<MovimientoAlmacen>();
                listaMovimientosCreados = new ArrayList<MovimientoAlmacen>();
                lArticuloDescuentos = BaseDatos.getListaArticuloDescuentoPorArticulo(articulo.getIid());
                lAgenteArticulo = BaseDatos.getListaAgenteArticulo(em, articulo);
                lAgenteArticuloCodigo = BaseDatos.getListaAgenteArticuloCodigo(articulo.getIid());

                articulo.setCod_articulo(sheet.getCell(0, fila).getContents().toString());
                articulo.setDes_tecnica(sheet.getCell(1, fila).getContents().toString());
                articulo.setDes_inf(sheet.getCell(2, fila).getContents().toString());
                Agentes prov = BaseDatos.obtenerAgenteNombreComercial(sheet.getCell(3, fila).getContents().toString(), em);
                if (prov != null) {
                    articulo.setProv_hab(prov);
                }
                articulo.setIid_fam_venta(fv);
                articulo.setIid_empresa(em);
                //Probar unidad de medida
                articulo.setIid_unidad_medida(fv.getIid_tipo_control().getUnidadResultado());
                articulo.setCod_arb("");
                articulo.setIid_moneda(m);
                articulo.setIva(i);
                articulo.setAct_stock(false);
                articulo.setStock_neg(false);
                articulo.setStock_med(false);
                articulo.setStock_col(false);
                articulo.setEscalado(false);
                articulo.setEscaladoCaracteristica(false);

                upc = upc.parseFloat(sheet.getCell(5, fila).getContents().replace(",", "."));
                ptc = ptc.parseFloat(sheet.getCell(6, fila).getContents().replace(",", "."));
                pvp = pvp.parseFloat(sheet.getCell(7, fila).getContents().replace(",", "."));

                articulo.setUpc(upc);
                articulo.setPtc(ptc);
                articulo.setPrecio_v(pvp);
                articulo.setPrecioIncremento(pi);

                //Actualizar lista de precios
                p.setIid_art(articulo);
                p.setIid_car(0); //Precio articulo
                p.setIid_empresa(em);
                p.setFecha(fecha.getTime());
                p.setUpc(upc);
                p.setPtc(ptc);
                p.setPvp(pvp);
                p.setPi(0F);
                listaPrecios.add(p);

                // } else {
                //Vamos a i una característica
                // CAMBIO: Ahora las caraterísticas la indica la familia, para ello leemos la familia a la que pertenece el artículo
                List<colorFamilia> cs = BaseDatos.getColoresPorFamilia(em.getIid(), articulo.getIid_fam_venta().getIid());

                Iterator iC = cs.iterator();
                while (iC.hasNext()) {
                    colorFamilia cf = (colorFamilia) iC.next();
                    c = BaseDatos.obtenerColorPorIid(cf.getIidColor());
                    if (c != null) {
                        car = new Caracteristica();

                        car.setIid_empresa(em);
                        car.setIid_articulo(BaseDatos.obtenerArticulo(sheet.getCell(0, fila).getContents().toString(), em.getIid()));
                        car.setIid_color(c);

                        //Según el tipo de Color, obtenemos un precio u otro
                        //Blanco
                        if (c.getRal() == 1) {
                            upc = upc.parseFloat(sheet.getCell(5, fila).getContents().replace(",", "."));
                            ptc = ptc.parseFloat(sheet.getCell(6, fila).getContents().replace(",", "."));
                            pvp = pvp.parseFloat(sheet.getCell(7, fila).getContents().replace(",", "."));
                            //Color
                        } else if (c.getRal() == 2) {
                            upc = upc.parseFloat(sheet.getCell(8, fila).getContents().replace(",", "."));
                            ptc = ptc.parseFloat(sheet.getCell(9, fila).getContents().replace(",", "."));
                            pvp = pvp.parseFloat(sheet.getCell(10, fila).getContents().replace(",", "."));
                            // Especial
                        } else if (c.getRal() == 3) {
                            upc = upc.parseFloat(sheet.getCell(11, fila).getContents().replace(",", "."));
                            ptc = ptc.parseFloat(sheet.getCell(12, fila).getContents().replace(",", "."));
                            pvp = pvp.parseFloat(sheet.getCell(13, fila).getContents().replace(",", "."));
                        }

                        car.setUpc(upc);
                        car.setPtc(ptc);
                        car.setPvp(pvp);
                        car.setPrecioIncremento(pi);
                        car.setEscalado(false);
                        car.setCond_pedir(false);
                        car.setStock_max(false);
                        car.setStock_min(false);
                        listaCaracteristicas.add(car);

                        p = new Precios();
                        //Actualizar lista de precios
                        p.setIid_art(articulo);
                        p.setIid_car(car.getIid_color().getIid()); //Precio articulo
                        p.setIid_empresa(em);
                        p.setFecha(fecha.getTime());

                        p.setUpc(upc);
                        p.setPtc(ptc);
                        p.setPvp(pvp);
                        p.setPi(0F);

                        listaPrecios.add(p);
                    }
                }

                if (BaseDatos.insertarArticulo(articulo, listaCaracteristicas, listaEscalados, listaMovimientos, listaExistencias, lArticuloDescuentos, lAgenteArticulo, lAgenteArticuloCodigo, listaPrecios,"Creación masiva",u.getNombre(), lmp)) {
                    cont++;
                } else {
                    lmp.insertarLinea("No se ha podido insertar el artículo " + articulo.getCod_articulo());
                }
            } else {
                lmp.insertarLinea("El artículo " + sheet.getCell(0, fila).getContents().toString() + " ya existe");
            }
        }
        lmp.acabarProceso();
        JOptionPane.showMessageDialog(null, "Se han insertado " + cont + " elementos ", "Información", JOptionPane.INFORMATION_MESSAGE);
    }
}
