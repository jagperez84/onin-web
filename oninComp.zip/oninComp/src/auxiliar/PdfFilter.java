package auxiliar;

import java.io.*;

public class PdfFilter extends javax.swing.filechooser.FileFilter
{
  public boolean accept (File f) {
    return f.getName ().toLowerCase ().endsWith (".pdf")
          || f.isDirectory ();
  }
  
  public String getDescription () {
    return "Archivos pdf (*.pdf)";
  }
}
