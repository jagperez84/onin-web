package auxiliar;

import acceso.BaseDatos;
import bean.AgenteArticuloCodigo;
import bean.Agentes;
import bean.Articulo;
import bean.Caracteristica;
import bean.Colores;
import bean.Empresa;
import gui.LogMasivoProgreso;
import javax.swing.JOptionPane;
import jxl.Sheet;
import jxl.Workbook;

public class HebraActualizarPreciosProveedor implements Runnable {

    private Empresa em;
    private LogMasivoProgreso lmp;
    private Workbook workbook;

    public HebraActualizarPreciosProveedor(LogMasivoProgreso lmp, Workbook workbook, Empresa e) {
        this.em = e;
        this.lmp = lmp;
        this.workbook = workbook;
    }

    public void run() {
        actualizarPrecios();
    }

    private void actualizarPrecios() {
        Sheet sheet;
        int fila, numFilas;
        Articulo articulo = new Articulo();
        Float pvp = new Float(0);
        Float upc = new Float(0);
        Float ptc = new Float(0);
        Float pi = new Float(0);
        Caracteristica car;
        Agentes a;
        AgenteArticuloCodigo aa;
        Colores c;
        String prov;
        int cont = 0;
        int err = 0;

        //Obtenemos la hoja a analizar
        sheet = workbook.getSheet(0);
        //Calculamos el número de columnas

        //Calculamos el numero de filas
        numFilas = sheet.getRows();

        //Calculamos cada elemento [fila,columna]=Dato
        for (fila = 0; fila < numFilas; fila++) {
            //0 Código 1 Caracteristica 3 UPC 4 PTC 5 PVP 6 Precio Incremento
            //Comprobamos si es un artículo o una caracteristica
            //if (sheet.getCell(fila, 1).toString().equals("")){
            //Es un artículo, tiene el campo caracteristicas vacío

            articulo = BaseDatos.obtenerArticulo(sheet.getCell(0, fila).getContents(), em.getIid());
            if (articulo != null) {
                //a = new Agentes();
                prov = sheet.getCell(2, fila).getContents();
                a = BaseDatos.obtenerAgentesPorCodigo(prov, "prov", em);

                if (a != null) {

                    aa = BaseDatos.obtenerAgenteArticuloCodigoPorAgente(articulo, a);

                    if (aa != null) {
                        String codCar = sheet.getCell(1, fila).getContents();
                        if (codCar.isEmpty()) {
                            aa.setIid_color(0);
                        } else {
                            c = BaseDatos.obtenerColor(codCar);
                            if (c != null) {
                                aa.setIid_color(c.getIid());
                            }else{
                                aa.setIid_color(0);
                            }
                        }
                                   
                        
                        aa.setCodigo(sheet.getCell(3, fila).getContents());
                        pvp = pvp.parseFloat(sheet.getCell(4, fila).getContents().replace(",", "."));
                        aa.setPrecio(pvp);
                        aa.setCheckDto(!sheet.getCell(5, fila).getContents().isEmpty());
                        upc = upc.parseFloat(sheet.getCell(6, fila).getContents().replace(",", ".")); //PARA DESCUENTO

                        aa.setDescuento(upc);
                        aa.setTipoPrecio(sheet.getCell(7, fila).getContents());
                        aa.setDescripcion(sheet.getCell(8, fila).getContents());

                        if (BaseDatos.modificarElemento(aa)) {
                            lmp.insertarLinea("Actualizando artículo " + articulo.getIid());
                            cont++;
                        } else {
                            err++;
                            lmp.insertarLinea("No se ha podido actualizar el artículo " + articulo.getIid());
                        }
                    } else {
                        aa = new AgenteArticuloCodigo();
                        aa.setIid_agente(a);
                        aa.setIid_articulo(articulo);
                        aa.setCodigo(sheet.getCell(3, fila).getContents());
                        pvp = pvp.parseFloat(sheet.getCell(4, fila).getContents().replace(",", "."));
                        aa.setPrecio(pvp);
                        aa.setCheckDto(!sheet.getCell(5, fila).getContents().isEmpty());
                        upc = upc.parseFloat(sheet.getCell(6, fila).getContents().replace(",", ".")); //PARA DESCUENTO

                        aa.setDescuento(upc);
                        aa.setTipoPrecio(sheet.getCell(7, fila).getContents());
                        aa.setDescripcion(sheet.getCell(8, fila).getContents());

                        if (BaseDatos.insertarElemento(aa)) {
                            lmp.insertarLinea("Actualizando artículo " + articulo.getIid());
                            cont++;
                        } else {
                            lmp.insertarLinea("No se ha podido actualizar el artículo " + articulo.getIid());
                            err++;
                        }
                    }
                } else {
                    lmp.insertarLinea("El proveedor " + prov + " no existe");
                    err++;
                }
            } else {
                lmp.insertarLinea("El arículo " + sheet.getCell(0, fila).getContents() + " no existe");
            }

        }
        lmp.acabarProceso();
        JOptionPane.showMessageDialog(null, "Se han modificado " + cont + " elementos, han aparecido " + err + " errores", "Información", JOptionPane.INFORMATION_MESSAGE);
    }
}
