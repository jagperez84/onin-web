package auxiliar;

import acceso.BaseDatos;
import bean.Articulo;
import bean.Caracteristica;
import bean.DespiecePresupuesto;
import bean.FamiliaVenta;
import bean.SeleccionPresupuesto;
import bean.TipoControl;
import bean.TipoMedida;
import bean.VariablePresupuesto;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;
import org.apache.log4j.Logger;
import org.hibernate.Session;
import util.Constantes;
import util.Util;

public class RellenarDacBean {

    private String cantidad,  medida1,  medida2,  medida3,  medida4,  medida5;
    private List<VariablePresupuesto> listaVbles;
    private List<SeleccionPresupuesto> listaSeleccion;
    private List<DespiecePresupuesto> listaDespiece;
    private ScriptEngine engineGlobal;
    private Session session;
    private static Logger log = Logger.getLogger(RellenarDacBean.class);

    public RellenarDacBean(Session session, String cantidad, String medida1, String medida2, String medida3, String medida4, String medida5,
            List<VariablePresupuesto> listaVbles, List<SeleccionPresupuesto> listaSeleccion, List<DespiecePresupuesto> listaDespiece) {

        this.listaVbles = listaVbles;
        this.listaSeleccion = listaSeleccion;
        this.listaDespiece = listaDespiece;
        this.cantidad = cantidad;
        this.medida1 = medida1;
        this.medida2 = medida2;
        this.medida3 = medida3;
        this.medida4 = medida4;
        this.medida5 = medida5;
        this.session = session;

        ScriptEngineManager manager = new ScriptEngineManager();
        engineGlobal = manager.getEngineByName("js");
        engineGlobal.put("Cantidad", Double.valueOf(Util.convertirComaAPunto(cantidad)));
        engineGlobal.put("Dim1", Double.valueOf(Util.convertirComaAPunto(medida1)));
        engineGlobal.put("Dim2", Double.valueOf(Util.convertirComaAPunto(medida2)));
        engineGlobal.put("Dim3", Double.valueOf(Util.convertirComaAPunto(medida3)));
        engineGlobal.put("Dim4", Double.valueOf(Util.convertirComaAPunto(medida4)));
        engineGlobal.put("Dim5", Double.valueOf(Util.convertirComaAPunto(medida5)));

        iniciarVariables();
    }

    public List<DespiecePresupuesto> getListaDespiece() {
        return this.listaDespiece;
    }

    private void iniciarVariables() {
        if (listaVbles != null && listaVbles.size() > 0) {
            VariablePresupuesto vTemp;
            Iterator lIter = listaVbles.iterator();
            double valorTemp = 0D;
            while (lIter.hasNext()) {
                vTemp = (VariablePresupuesto) lIter.next();

                if (vTemp.getTipo().equals(Constantes.NUMERICA)) {

                    if (vTemp.getValor() == null) {
                        vTemp.setValor(0d);
                    }

                    valorTemp = vTemp.getValor();
                    engineGlobal.put(vTemp.getNombre(), valorTemp);
                } else if (vTemp.getTipo().equals(Constantes.SELECCION)) {
                    List<SeleccionPresupuesto> listaSeleccionTemp = obtenerSeleccionVbles(vTemp.getNombre());

                    if (listaSeleccionTemp != null && listaSeleccionTemp.size() > 0) {
                        List<String> listaOpciones = new ArrayList<String>();
                        SeleccionPresupuesto seleccionTemp;
                        boolean vbleSeleccionada = false;
                        Iterator iter = listaSeleccionTemp.iterator();
                        while (iter.hasNext()) {
                            seleccionTemp = (SeleccionPresupuesto) iter.next();
                            listaOpciones.add(seleccionTemp.getNombre());
                            if (seleccionTemp.getSeleccionada()) {
                                valorTemp = seleccionTemp.getValor();
                                engineGlobal.put(vTemp.getNombre(), valorTemp);
                                vbleSeleccionada = true;
                            }
                        }

                        if (!vbleSeleccionada) {
                            valorTemp = Double.valueOf(0d);
                            engineGlobal.put(vTemp.getNombre(), valorTemp);
                        }
                    }
                } else {
                    try {
                        Double resultado = (Double) engineGlobal.eval(vTemp.getFormula());
                        resultado = matematico.Matematico.redondear2decimales(resultado);

                        if (vTemp.getActivarMinimo() && vTemp.getValorMinimo() > resultado) {
                            resultado = vTemp.getValorMinimo();
                        } else if (vTemp.getActivarMaximo() && vTemp.getValorMaximo() < resultado) {
                            resultado = vTemp.getValorMaximo();
                        }

                        vTemp.setValor(resultado);
                        engineGlobal.put(vTemp.getNombre(), resultado);
                    } catch (ScriptException se) {
                        log.error("Hay un error al evaluar la fórmula de la variable " + vTemp.getNombre() + " ", se);
                    }
                }
            }
        }
    }

    private ArrayList<SeleccionPresupuesto> obtenerSeleccionVbles(String nombre) {
        ArrayList<SeleccionPresupuesto> lres = new ArrayList<SeleccionPresupuesto>();
        Iterator<SeleccionPresupuesto> iter = listaSeleccion.iterator();
        SeleccionPresupuesto sel;
        VariablePresupuesto var;
        while (iter.hasNext()) {
            sel = iter.next();
            var = sel.getVariablePresupuesto();
            if (var.getNombre().equalsIgnoreCase(nombre)) {
                lres.add(sel);
            }
        }
        return lres;
    }

    public Double calcularPrecioDespiece(DespiecePresupuesto des) {
        Double res = 0D;

        if (des.getPrecio() == null) {

            Articulo arTemp = des.getArticulo();
            if (arTemp.getIid() != null) {
                arTemp = BaseDatos.obtenerArticuloPorIidBD(arTemp.getIid(), session);
            }

            Caracteristica carTemp = des.getCaracteristica();
            if (carTemp != null) {
                carTemp = BaseDatos.obtenerCaracteristicaPorIidBD(carTemp.getIid(), session);
            }

            FamiliaVenta fv = BaseDatos.obtenerFamiliaVentaPorIidBD(arTemp.getIid_fam_venta().getIid(), session);
            TipoControl tc = BaseDatos.obtenerTipoControlPorIidBD(fv.getIid_tipo_control().getIid(), session);
            TipoMedida tm = BaseDatos.obtenerTipoMedidaByIidBD(tc.getIid_tipo_medida().getIid(), session);
            String tipoCalculo = tm.getTipo_calculo();
            Float medidaTotal;

            if (des.getArticuloBase() == null && des.getAnadirIncremento() == null && des.getAnadirPvp() == null) {
                des.setAnadirPvp(true);
            }

            //Si Articulo Base ==> el precio es 0
            if (des.getArticuloBase()) {
                res = 0D;
            } //Si es Anadir Incremento ==> el precio es el precio por incremento del articulo o caracteristica
            else if (des.getAnadirIncremento()) {
                double precioTemporal = 0D;
                if (carTemp != null) {
                    if (carTemp.getPrecioIncremento() != null) {
                        precioTemporal = carTemp.getPrecioIncremento().doubleValue();
                    } else {
                        precioTemporal = 0D;
                    }
                } else {
                    if (arTemp.getPrecioIncremento() != null) {
                        precioTemporal = arTemp.getPrecioIncremento().doubleValue();
                    } else {
                        precioTemporal = 0D;
                    }
                }

                try {
                    if (tipoCalculo.equals(Constantes.FORMULA)) {
                        Double medidaTotalDouble = (Double) engineGlobal.eval(tm.getFormula());
                        medidaTotal = medidaTotalDouble.floatValue();
                    } else {
                        medidaTotal = Float.valueOf(Util.convertirComaAPunto(medida1)) / 100;
                    }

                    if ((arTemp.getEscalado() != null && arTemp.getEscalado()) || (arTemp.getEscaladoCaracteristica() != null && arTemp.getEscaladoCaracteristica())) {
                        medidaTotal = 1F;
                    }

                    res = precioTemporal * medidaTotal * evaluar(des.getFormulaCantidad(), des.getRedondeo());
                } catch (Exception ex) {
                    res = 0D;
                }

            } //Si es Anadir PVP ==> el precio es el precio ya sea por formula, escalado.. del articulo o caracteristica
            else if (des.getAnadirPvp()) {
                double precioTemporal = 0D;
                if ((arTemp.getEscalado() != null && arTemp.getEscalado()) || (arTemp.getEscaladoCaracteristica() != null && arTemp.getEscaladoCaracteristica())) {

                    Float fMedida1 = -1F;
                    Float fMedida2 = -1F;
                    if (medida1.length() != 0) {
                        fMedida1 = evaluar(des.getFormulaMedida1(), des.getRedondeo()).floatValue();
                    }
                    if (medida2.length() != 0) {
                        fMedida2 = evaluar(des.getFormulaMedida2(), des.getRedondeo()).floatValue();
                    }

                    if (arTemp.getEscaladoCaracteristica() == null || !arTemp.getEscaladoCaracteristica()) {
                        precioTemporal = BaseDatos.obtenerPrecioEscalado(session, arTemp.getIid(), null, fMedida1.intValue(), fMedida2.intValue());
                    } else {
                        precioTemporal = BaseDatos.obtenerPrecioEscalado(session, arTemp.getIid(), carTemp.getIid(), fMedida1.intValue(), fMedida2.intValue());
                    }
                } else {
                    if (carTemp != null) {
                        if (carTemp.getPvp() != null) {
                            precioTemporal = carTemp.getPvp().doubleValue();
                        } else {
                            precioTemporal = 0D;
                        }
                    } else {
                        if (arTemp.getPrecio_v() != null) {
                            precioTemporal = arTemp.getPrecio_v().doubleValue();
                        } else {
                            precioTemporal = 0D;
                        }
                    }
                }

                try {
                    if (tipoCalculo.equals(Constantes.FORMULA)) {
                        Double medidaTotalDouble = (Double) engineGlobal.eval(tm.getFormula());
                        medidaTotal = medidaTotalDouble.floatValue();
                    } else {
                        medidaTotal = Float.valueOf(Util.convertirComaAPunto(medida1)) / 100;
                    }

                    if ((arTemp.getEscalado() != null && arTemp.getEscalado()) || (arTemp.getEscaladoCaracteristica() != null && arTemp.getEscaladoCaracteristica())) {
                        medidaTotal = 1F;
                    }

                    res = precioTemporal * medidaTotal * evaluar(des.getFormulaCantidad(), des.getRedondeo());

                } catch (Exception ex) {
                    ex.printStackTrace();
                    log.error("Error al evaluar el precio en calcularPrecioDespiece ", ex);
                    res = 0D;
                }
            }
        } else {
            res = Double.valueOf(Float.toString(des.getPrecio()));
        }
        return res;

    }

    public Double evaluar(String formula, String tipoRedondeo) {
        Double resultado = null;

        if (formula.length() == 0) {
            formula = "0.0";
            resultado = 0D;
        } else {
            try {
                resultado = (Double) engineGlobal.eval(Util.convertirComaAPunto(formula));
                if (tipoRedondeo.equals(Constantes.TRUNCAR)) {
                    resultado = matematico.Matematico.truncar(resultado);
                } else if (tipoRedondeo.equals(Constantes.EXCESO)) {
                    resultado = matematico.Matematico.exceso(resultado);
                } else {
                    resultado = matematico.Matematico.redondear2decimales(resultado);
                }
            } catch (Exception se) {
                resultado = 0D;
                log.error("Se ha producido una excepción en el método evaluar con la formula " + formula, se);
            }
        }

        return resultado;
    }
}