package auxiliar;

import bean.Articulo;
import bean.Caracteristica;



public class DesUnidades {

    private Articulo ar;
    private Caracteristica car;
    private Double cantidad;
    private Integer iidLineaPresupuesto;

    public DesUnidades(){

    }

    public DesUnidades(Articulo ar ,Caracteristica car, Double cantidad, Integer iidLineaPresupuesto){

        this.ar = ar;
        this.car = car;
        this.cantidad = cantidad;
        this.iidLineaPresupuesto = iidLineaPresupuesto;
    }

    public Articulo getAr() {
        return ar;
    }

    public void setAr(Articulo ar) {
        this.ar = ar;
    }

    public Double getCantidad() {
        return cantidad;
    }

    public void setCantidad(Double cantidad) {
        this.cantidad = cantidad;
    }

    public Caracteristica getCar() {
        return car;
    }

    public void setCar(Caracteristica car) {
        this.car = car;
    }

    public Integer getIidLineaPresupuesto() {
        return iidLineaPresupuesto;
    }

    public void setIidLineaPresupuesto(Integer iidLineaPresupuesto) {
        this.iidLineaPresupuesto = iidLineaPresupuesto;
    }
}
