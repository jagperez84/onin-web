package matematico;

public class Matematico {

   

    private static double redondear(double numero, int decimales) {
        return Math.round(numero * Math.pow(10, decimales)) / Math.pow(10, decimales);
    }

    public static double redondear1decimal(double valor) {
        return redondear(valor,1);
    }

    public static double redondear2decimales(double valor) {
        return redondear(valor,2);
    }

    public static double redondear3decimales(double valor) {
        return redondear(valor,3);
    }
    
    public static double truncar (double valor){
        return redondear(valor,0);
    }
    
    public static double exceso (double valor){
        return Math.ceil(valor);
    }
    
    private static float redondear(float numero, int decimales) {
        return (float) (Math.round(numero * Math.pow(10, decimales)) / Math.pow(10, decimales));
    }

    public static float redondear1decimal(float valor) {
        return redondear(valor,1);
    }

    public static float redondear2decimales(float valor) {
        return redondear(valor,2);
    }

    public static float redondear3decimales(float valor) {
        return redondear(valor,3);
    }
    
    public static float truncar (float valor){
        return redondear(valor,0);
    }
    
    public static float exceso (float valor){
        return (float) Math.ceil(valor);
    }
}
