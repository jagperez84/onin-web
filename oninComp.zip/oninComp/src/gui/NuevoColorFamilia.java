package gui;

import acceso.BaseDatos;
import bean.Colores;
import bean.Empresa;
import bean.FamiliaVenta;
import bean.colorFamilia;
import java.util.Iterator;
import java.util.List;


public class NuevoColorFamilia extends javax.swing.JFrame {

    private NuevaFamiliaVenta nfv;
    private FamiliaVenta fv;
    private Empresa e;

    public NuevoColorFamilia(Empresa e, FamiliaVenta fv, NuevaFamiliaVenta nfv) {
        super("Insertar Color");
        this.fv = fv;
        this.e = e;
        this.nfv = nfv;
        
        initComponents();

        rellenarCombosColores();

    }

    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        baceptar = new javax.swing.JButton();
        bcancelar = new javax.swing.JButton();
        cColor = new javax.swing.JComboBox();
        jLabel2 = new javax.swing.JLabel();

        jLabel1.setText("jLabel1");

        baceptar.setText("Insertar");
        baceptar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                baceptarActionPerformed(evt);
            }
        });

        bcancelar.setText("Cancelar");
        bcancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bcancelarActionPerformed(evt);
            }
        });

        cColor.setModel(new javax.swing.DefaultComboBoxModel(new String[] { }));

        jLabel2.setText("COLOR:");

        org.jdesktop.layout.GroupLayout layout = new org.jdesktop.layout.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .add(jLabel2)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                    .add(cColor, 0, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .add(layout.createSequentialGroup()
                        .add(baceptar)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                        .add(bcancelar)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, layout.createSequentialGroup()
                .addContainerGap(30, Short.MAX_VALUE)
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(cColor, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(jLabel2))
                .add(28, 28, 28)
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(bcancelar)
                    .add(baceptar))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

private void baceptarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_baceptarActionPerformed
    //Obtener color
    Colores c = BaseDatos.obtenerColorPorDescripcion((String) cColor.getSelectedItem());
    colorFamilia cf = new colorFamilia();
    
    cf.setIidColor(c.getIid());
    cf.setIidEmpresa(e.getIid());
    if (fv!=null){
        cf.setIidFamilia(fv.getIid());
    }
    nfv.insertarColor(cf);
    
    cerrarVentana();

}//GEN-LAST:event_baceptarActionPerformed
    private void rellenarCombosColores() {
        List listaColores = BaseDatos.getListaColores();
        Iterator it = listaColores.iterator();
        Colores c;
        while (it.hasNext()) {
            c = (Colores) it.next();
            cColor.addItem(c.getDescripcion());
        }
    }
private void bcancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bcancelarActionPerformed
    cerrarVentana();
}//GEN-LAST:event_bcancelarActionPerformed
    private void cerrarVentana() {
        removeAll();
        dispose();
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton baceptar;
    private javax.swing.JButton bcancelar;
    private javax.swing.JComboBox cColor;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    // End of variables declaration//GEN-END:variables
}
