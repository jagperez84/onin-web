package gui;

import acceso.BaseDatos;
import bean.FormaPago;
import bean.TipoRecibo;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.net.URL;
import java.util.Iterator;
import java.util.List;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JOptionPane;
import javax.swing.KeyStroke;
import matematico.Matematico.*;
import util.Constantes;
import util.Util;

public class NuevaFormaDePago extends javax.swing.JFrame {

    private FormaPago fp;
    private boolean crear;
    private double vpago[];
    private double ppago[];
    private int plazo[];
    private float v_pago1,  v_pago2,  v_pago3,  v_pago4,  v_pago5,  v_pago6,  v_pago7,  v_pago8,  v_pago9,  v_pago10;
    private float p_pago1,  p_pago2,  p_pago3,  p_pago4,  p_pago5,  p_pago6,  p_pago7,  p_pago8,  p_pago9,  p_pago10;
    private String codigoAntiguo = "";

    public NuevaFormaDePago() {
        super("Forma de pago - Creación");
        vpago = new double[10];
        ppago = new double[10];
        plazo = new int[10];
        fp = new FormaPago();
        crear = true;
        initComponents();
        bmodificar.setVisible(false);
        cplazospagoadelantados.setSelectedIndex(0);
        cvencimientosadelantados.setSelectedIndex(0);
        actualizarPagos(0);
        actualizarVencimientos(0);
        crearIconosBotones();
        crearAcciones();
    }

    public NuevaFormaDePago(String titulo, FormaPago fp) {
        super(titulo);
        crear = false;
        vpago = new double[10];
        ppago = new double[10];
        plazo = new int[10];
        this.fp = fp;
        initComponents();

        codigoAntiguo = fp.getCodigo();
        tcodigo.setText(codigoAntiguo);

        tdescripcioncliente.setText(fp.getDescripcioncliente());
        tdescripcionidentificativa.setText(fp.getDescripcionidentificativa());
        tdtopp.setText(Util.convertirPuntoAComa(String.valueOf(fp.getDtoprontopago())));
        ctiporecibop.setSelectedItem(fp.getTiporecibopago());

        int numplazosadelantados = fp.getNumplazosadelantados();
        cplazospagoadelantados.setSelectedIndex(numplazosadelantados);
        actualizarPagos(numplazosadelantados);

        tplazopago1.setText(fp.getNombreplazo1());
        tplazopago2.setText(fp.getNombreplazo2());
        tplazopago3.setText(fp.getNombreplazo3());
        tplazopago4.setText(fp.getNombreplazo4());
        tplazopago5.setText(fp.getNombreplazo5());
        tplazopago6.setText(fp.getNombreplazo6());
        tplazopago7.setText(fp.getNombreplazo7());
        tplazopago8.setText(fp.getNombreplazo8());
        tplazopago9.setText(fp.getNombreplazo9());
        tplazopago10.setText(fp.getNombreplazo10());

        tporcentajepago1.setText(Util.convertirPuntoAComa(String.valueOf(matematico.Matematico.redondear2decimales(fp.getPorcentajepago1()))));
        tporcentajepago2.setText(Util.convertirPuntoAComa(String.valueOf(matematico.Matematico.redondear2decimales(fp.getPorcentajepago2()))));
        tporcentajepago3.setText(Util.convertirPuntoAComa(String.valueOf(matematico.Matematico.redondear2decimales(fp.getPorcentajepago3()))));
        tporcentajepago4.setText(Util.convertirPuntoAComa(String.valueOf(matematico.Matematico.redondear2decimales(fp.getPorcentajepago4()))));
        tporcentajepago5.setText(Util.convertirPuntoAComa(String.valueOf(matematico.Matematico.redondear2decimales(fp.getPorcentajepago5()))));
        tporcentajepago6.setText(Util.convertirPuntoAComa(String.valueOf(matematico.Matematico.redondear2decimales(fp.getPorcentajepago6()))));
        tporcentajepago7.setText(Util.convertirPuntoAComa(String.valueOf(matematico.Matematico.redondear2decimales(fp.getPorcentajepago7()))));
        tporcentajepago8.setText(Util.convertirPuntoAComa(String.valueOf(matematico.Matematico.redondear2decimales(fp.getPorcentajepago8()))));
        tporcentajepago9.setText(Util.convertirPuntoAComa(String.valueOf(matematico.Matematico.redondear2decimales(fp.getPorcentajepago9()))));
        tporcentajepago10.setText(Util.convertirPuntoAComa(String.valueOf(matematico.Matematico.redondear2decimales(fp.getPorcentajepago10()))));

        ctiporecibov.setSelectedItem(fp.getTiporecibovencimiento());

        int numvencimientosadelantados = fp.getNumplazosvencimiento();
        cvencimientosadelantados.setSelectedIndex(numvencimientosadelantados);
        actualizarVencimientos(numvencimientosadelantados);
        ctipocalculo.setSelectedItem(fp.getTipodecalculo());

        if (fp.getCalculovencimientoautomatico()) {
            bcalculoautomatico.setSelected(true);
            tdiasentreplazos.setText(String.valueOf(fp.getDiasentreplazos()));
            tdiasprimerplazo.setText(String.valueOf(fp.getDiasprimerplazo()));
            calculoAutomatico();
        } else {
            if (numvencimientosadelantados > 0) {
                tplazovm1.setText(String.valueOf(fp.getPlazovm1()));
            }
            if (numvencimientosadelantados > 1) {
                tplazovm2.setText(String.valueOf(fp.getPlazovm2()));
            }
            if (numvencimientosadelantados > 2) {
                tplazovm3.setText(String.valueOf(fp.getPlazovm3()));
            }
            if (numvencimientosadelantados > 3) {
                tplazovm4.setText(String.valueOf(fp.getPlazovm4()));
            }
            if (numvencimientosadelantados > 4) {
                tplazovm5.setText(String.valueOf(fp.getPlazovm5()));
            }
            if (numvencimientosadelantados > 5) {
                tplazovm6.setText(String.valueOf(fp.getPlazovm6()));
            }
            if (numvencimientosadelantados > 6) {
                tplazovm7.setText(String.valueOf(fp.getPlazovm7()));
            }
            if (numvencimientosadelantados > 7) {
                tplazovm8.setText(String.valueOf(fp.getPlazovm8()));
            }
            if (numvencimientosadelantados > 8) {
                tplazovm9.setText(String.valueOf(fp.getPlazovm9()));
            }
            if (numvencimientosadelantados > 9) {
                tplazovm10.setText(String.valueOf(fp.getPlazovm10()));
            }
        }

        if (fp.getPorcentajeautomatico()) {
            bporcentajesautomaticos.setSelected(true);
            porcentajesAutomaticos();
        } else {
            if (numvencimientosadelantados > 0) {
                tplazopm1.setText(Util.convertirPuntoAComa(String.valueOf(matematico.Matematico.redondear2decimales(fp.getPlazopm1()))));
            }
            if (numvencimientosadelantados > 1) {
                tplazopm2.setText(Util.convertirPuntoAComa(String.valueOf(matematico.Matematico.redondear2decimales(fp.getPlazopm2()))));
            }
            if (numvencimientosadelantados > 2) {
                tplazopm3.setText(Util.convertirPuntoAComa(String.valueOf(matematico.Matematico.redondear2decimales(fp.getPlazopm3()))));
            }
            if (numvencimientosadelantados > 3) {
                tplazopm4.setText(Util.convertirPuntoAComa(String.valueOf(matematico.Matematico.redondear2decimales(fp.getPlazopm4()))));
            }
            if (numvencimientosadelantados > 4) {
                tplazopm5.setText(Util.convertirPuntoAComa(String.valueOf(matematico.Matematico.redondear2decimales(fp.getPlazopm5()))));
            }
            if (numvencimientosadelantados > 5) {
                tplazopm6.setText(Util.convertirPuntoAComa(String.valueOf(matematico.Matematico.redondear2decimales(fp.getPlazopm6()))));
            }
            if (numvencimientosadelantados > 6) {
                tplazopm7.setText(Util.convertirPuntoAComa(String.valueOf(matematico.Matematico.redondear2decimales(fp.getPlazopm7()))));
            }
            if (numvencimientosadelantados > 7) {
                tplazopm8.setText(Util.convertirPuntoAComa(String.valueOf(matematico.Matematico.redondear2decimales(fp.getPlazopm8()))));
            }
            if (numvencimientosadelantados > 8) {
                tplazopm9.setText(Util.convertirPuntoAComa(String.valueOf(matematico.Matematico.redondear2decimales(fp.getPlazopm9()))));
            }
            if (numvencimientosadelantados > 9) {
                tplazopm10.setText(Util.convertirPuntoAComa(String.valueOf(matematico.Matematico.redondear2decimales(fp.getPlazopm10()))));
            }
        }

        timporteminimo.setText(Util.convertirPuntoAComa(String.valueOf(fp.getImporteminimo())));
        tcodigo.setEnabled(false);
        tdescripcioncliente.setEnabled(false);
        tdescripcionidentificativa.setEnabled(false);
        tdtopp.setEnabled(false);
        cplazospagoadelantados.setEnabled(false);
        ctiporecibop.setEnabled(false);
        habilitarPagos(false);
        cvencimientosadelantados.setEnabled(false);
        ctipocalculo.setEnabled(false);
        ctiporecibov.setEnabled(false);
        bcalculoautomatico.setEnabled(false);
        bporcentajesautomaticos.setEnabled(false);
        timporteminimo.setEnabled(false);
        tdiasentreplazos.setEnabled(false);
        tdiasprimerplazo.setEnabled(false);
        habilitarPorcentajesManuales(false);
        habilitarVencimientosManuales(false);

        bcancelar.setToolTipText("Cancelar la creación");
        baceptar.setToolTipText("Realizar la modificación");
        bmodificar.setText("Modificar");
        bmodificar.setToolTipText("Modificar campos");

        crearIconosBotones();
        crearAcciones();
    }

    private void cerrarVentana() {
        removeAll();
        dispose();
    }

    private void crearAcciones() {
        KeyStroke escapeKeyStroke = KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false);
        Action escapeAction = new AbstractAction() {

            public void actionPerformed(ActionEvent e) {
                cerrarVentana();
            }
        };
        getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(escapeKeyStroke, "ESCAPE");
        getRootPane().getActionMap().put("ESCAPE", escapeAction);
    }

    private void crearIconosBotones() {
        URL url = getClass().getResource("/iconos/cancelar.gif");
        ImageIcon icono = new ImageIcon(url);
        bcancelar.setIcon(icono);

        url = getClass().getResource("/iconos/guardarYvolver.png");
        icono = new ImageIcon(url);
        baceptar.setIcon(icono);

        url = getClass().getResource("/iconos/editar.png");
        icono = new ImageIcon(url);
        bmodificar.setIcon(icono);
    }

    private String crearMensajePlazos() {
        String res = "";
        int numPlazos = new Integer((String) cplazospagoadelantados.getSelectedItem());

        if (numPlazos == 1) {
            if (tplazopago1.getText() == null || tplazopago1.getText().equals("")) {
                res = "Error";
            }
        } else if (numPlazos == 2) {
            if (tplazopago1.getText() == null || tplazopago1.getText().equals("") ||
                    tplazopago2.getText() == null || tplazopago2.getText().equals("")) {
                res = "Error";
            }
        } else if (numPlazos == 3) {
            if (tplazopago1.getText() == null || tplazopago1.getText().equals("") ||
                    tplazopago2.getText() == null || tplazopago2.getText().equals("") ||
                    tplazopago3.getText() == null || tplazopago3.getText().equals("")) {
                res = "Error";
            }
        } else if (numPlazos == 4) {
            if (tplazopago1.getText() == null || tplazopago1.getText().equals("") ||
                    tplazopago2.getText() == null || tplazopago2.getText().equals("") ||
                    tplazopago3.getText() == null || tplazopago3.getText().equals("") ||
                    tplazopago4.getText() == null || tplazopago4.getText().equals("")) {
                res = "Error";
            }
        } else if (numPlazos == 5) {
            if (tplazopago1.getText() == null || tplazopago1.getText().equals("") ||
                    tplazopago2.getText() == null || tplazopago2.getText().equals("") ||
                    tplazopago3.getText() == null || tplazopago3.getText().equals("") ||
                    tplazopago4.getText() == null || tplazopago4.getText().equals("") ||
                    tplazopago5.getText() == null || tplazopago5.getText().equals("")) {
                res = "Error";
            }
        } else if (numPlazos == 6) {
            if (tplazopago1.getText() == null || tplazopago1.getText().equals("") ||
                    tplazopago2.getText() == null || tplazopago2.getText().equals("") ||
                    tplazopago3.getText() == null || tplazopago3.getText().equals("") ||
                    tplazopago4.getText() == null || tplazopago4.getText().equals("") ||
                    tplazopago5.getText() == null || tplazopago5.getText().equals("") ||
                    tplazopago6.getText() == null || tplazopago6.getText().equals("")) {
                res = "Error";
            }
        } else if (numPlazos == 7) {
            if (tplazopago1.getText() == null || tplazopago1.getText().equals("") ||
                    tplazopago2.getText() == null || tplazopago2.getText().equals("") ||
                    tplazopago3.getText() == null || tplazopago3.getText().equals("") ||
                    tplazopago4.getText() == null || tplazopago4.getText().equals("") ||
                    tplazopago5.getText() == null || tplazopago5.getText().equals("") ||
                    tplazopago6.getText() == null || tplazopago6.getText().equals("") ||
                    tplazopago7.getText() == null || tplazopago7.getText().equals("")) {
                res = "Error";
            }
        } else if (numPlazos == 8) {
            if (tplazopago1.getText() == null || tplazopago1.getText().equals("") ||
                    tplazopago2.getText() == null || tplazopago2.getText().equals("") ||
                    tplazopago3.getText() == null || tplazopago3.getText().equals("") ||
                    tplazopago4.getText() == null || tplazopago4.getText().equals("") ||
                    tplazopago5.getText() == null || tplazopago5.getText().equals("") ||
                    tplazopago6.getText() == null || tplazopago6.getText().equals("") ||
                    tplazopago7.getText() == null || tplazopago7.getText().equals("") ||
                    tplazopago8.getText() == null || tplazopago8.getText().equals("")) {
                res = "Error";
            }
        } else if (numPlazos == 9) {
            if (tplazopago1.getText() == null || tplazopago1.getText().equals("") ||
                    tplazopago2.getText() == null || tplazopago2.getText().equals("") ||
                    tplazopago3.getText() == null || tplazopago3.getText().equals("") ||
                    tplazopago4.getText() == null || tplazopago4.getText().equals("") ||
                    tplazopago5.getText() == null || tplazopago5.getText().equals("") ||
                    tplazopago6.getText() == null || tplazopago6.getText().equals("") ||
                    tplazopago7.getText() == null || tplazopago7.getText().equals("") ||
                    tplazopago8.getText() == null || tplazopago8.getText().equals("") ||
                    tplazopago9.getText() == null || tplazopago9.getText().equals("")) {
                res = "Error";
            }
        } else if (numPlazos == 10) {
            if (tplazopago1.getText() == null || tplazopago1.getText().equals("") ||
                    tplazopago2.getText() == null || tplazopago2.getText().equals("") ||
                    tplazopago3.getText() == null || tplazopago3.getText().equals("") ||
                    tplazopago4.getText() == null || tplazopago4.getText().equals("") ||
                    tplazopago5.getText() == null || tplazopago5.getText().equals("") ||
                    tplazopago6.getText() == null || tplazopago6.getText().equals("") ||
                    tplazopago7.getText() == null || tplazopago7.getText().equals("") ||
                    tplazopago8.getText() == null || tplazopago8.getText().equals("") ||
                    tplazopago9.getText() == null || tplazopago9.getText().equals("") ||
                    tplazopago10.getText() == null || tplazopago10.getText().equals("")) {
                res = "Error";
            }
        }
        return res;
    }

    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTabbedPane1 = new javax.swing.JTabbedPane();
        pdatos = new javax.swing.JPanel();
        lcodigo = new javax.swing.JLabel();
        ldescripcionIdentificativa = new javax.swing.JLabel();
        ldescripcionCliente = new javax.swing.JLabel();
        lprontoPago = new javax.swing.JLabel();
        tcodigo = new javax.swing.JTextField();
        tdescripcionidentificativa = new javax.swing.JTextField();
        tdescripcioncliente = new javax.swing.JTextField();
        tdtopp = new javax.swing.JTextField();
        lporcentaje = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        lnplazosAdelantados = new javax.swing.JLabel();
        ltiporecibop = new javax.swing.JLabel();
        ctiporecibop = new javax.swing.JComboBox();
        lplazopago2 = new javax.swing.JLabel();
        tplazopago1 = new javax.swing.JTextField();
        lplazopago8 = new javax.swing.JLabel();
        tplazopago5 = new javax.swing.JTextField();
        lplazopago9 = new javax.swing.JLabel();
        tplazopago2 = new javax.swing.JTextField();
        lplazopago10 = new javax.swing.JLabel();
        tplazopago3 = new javax.swing.JTextField();
        lplazopago11 = new javax.swing.JLabel();
        tplazopago4 = new javax.swing.JTextField();
        tporcentajepago1 = new javax.swing.JTextField();
        tporcentajepago2 = new javax.swing.JTextField();
        tporcentajepago3 = new javax.swing.JTextField();
        tporcentajepago4 = new javax.swing.JTextField();
        tporcentajepago5 = new javax.swing.JTextField();
        lporcentaje2 = new javax.swing.JLabel();
        lporcentaje3 = new javax.swing.JLabel();
        lporcentaje4 = new javax.swing.JLabel();
        lporcentaje5 = new javax.swing.JLabel();
        lporcentaje6 = new javax.swing.JLabel();
        lplazopago12 = new javax.swing.JLabel();
        lplazopago13 = new javax.swing.JLabel();
        tplazopago10 = new javax.swing.JTextField();
        tplazopago9 = new javax.swing.JTextField();
        lplazopago14 = new javax.swing.JLabel();
        lplazopago3 = new javax.swing.JLabel();
        lplazopago7 = new javax.swing.JLabel();
        tplazopago6 = new javax.swing.JTextField();
        tplazopago7 = new javax.swing.JTextField();
        tplazopago8 = new javax.swing.JTextField();
        tporcentajepago7 = new javax.swing.JTextField();
        lporcentaje7 = new javax.swing.JLabel();
        tporcentajepago6 = new javax.swing.JTextField();
        lporcentaje8 = new javax.swing.JLabel();
        tporcentajepago8 = new javax.swing.JTextField();
        lporcentaje9 = new javax.swing.JLabel();
        tporcentajepago9 = new javax.swing.JTextField();
        lporcentaje10 = new javax.swing.JLabel();
        tporcentajepago10 = new javax.swing.JTextField();
        lporcentaje11 = new javax.swing.JLabel();
        lnplazosAdelantados2 = new javax.swing.JLabel();
        lnplazosAdelantados3 = new javax.swing.JLabel();
        cplazospagoadelantados = new javax.swing.JComboBox();
        jPanel2 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        lnplazosvencimientos = new javax.swing.JLabel();
        ltipocalculo = new javax.swing.JLabel();
        ctipocalculo = new javax.swing.JComboBox();
        ltiporecibov = new javax.swing.JLabel();
        ctiporecibov = new javax.swing.JComboBox();
        bcalculoautomatico = new javax.swing.JCheckBox();
        bporcentajesautomaticos = new javax.swing.JCheckBox();
        limporteminimo = new javax.swing.JLabel();
        timporteminimo = new javax.swing.JTextField();
        leuros = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        lplazopago4 = new javax.swing.JLabel();
        tplazovm1 = new javax.swing.JTextField();
        lplazopago17 = new javax.swing.JLabel();
        tplazovm2 = new javax.swing.JTextField();
        lplazopago18 = new javax.swing.JLabel();
        tplazovm3 = new javax.swing.JTextField();
        lplazopago19 = new javax.swing.JLabel();
        tplazovm4 = new javax.swing.JTextField();
        lplazopago16 = new javax.swing.JLabel();
        tplazovm5 = new javax.swing.JTextField();
        lplazopago5 = new javax.swing.JLabel();
        tplazovm6 = new javax.swing.JTextField();
        lplazopago23 = new javax.swing.JLabel();
        tplazovm7 = new javax.swing.JTextField();
        lplazopago22 = new javax.swing.JLabel();
        tplazovm8 = new javax.swing.JTextField();
        lplazopago20 = new javax.swing.JLabel();
        tplazovm9 = new javax.swing.JTextField();
        lplazopago21 = new javax.swing.JLabel();
        tplazovm10 = new javax.swing.JTextField();
        jPanel7 = new javax.swing.JPanel();
        ldiasprimerplazo = new javax.swing.JLabel();
        tdiasprimerplazo = new javax.swing.JTextField();
        ldiasentreplazos = new javax.swing.JLabel();
        tdiasentreplazos = new javax.swing.JTextField();
        lresultadovencimientos = new javax.swing.JLabel();
        jPanel8 = new javax.swing.JPanel();
        lplazopago43 = new javax.swing.JLabel();
        tplazopm1 = new javax.swing.JTextField();
        lplazopago44 = new javax.swing.JLabel();
        tplazopm2 = new javax.swing.JTextField();
        lplazopago45 = new javax.swing.JLabel();
        tplazopm3 = new javax.swing.JTextField();
        lplazopago46 = new javax.swing.JLabel();
        tplazopm4 = new javax.swing.JTextField();
        lplazopago47 = new javax.swing.JLabel();
        tplazopm5 = new javax.swing.JTextField();
        lplazopago48 = new javax.swing.JLabel();
        tplazopm6 = new javax.swing.JTextField();
        lplazopago49 = new javax.swing.JLabel();
        tplazopm7 = new javax.swing.JTextField();
        lplazopago50 = new javax.swing.JLabel();
        tplazopm8 = new javax.swing.JTextField();
        lplazopago51 = new javax.swing.JLabel();
        tplazopm9 = new javax.swing.JTextField();
        lplazopago52 = new javax.swing.JLabel();
        tplazopm10 = new javax.swing.JTextField();
        lporcentaje21 = new javax.swing.JLabel();
        lporcentaje22 = new javax.swing.JLabel();
        lporcentaje23 = new javax.swing.JLabel();
        lporcentaje24 = new javax.swing.JLabel();
        lporcentaje25 = new javax.swing.JLabel();
        lporcentaje26 = new javax.swing.JLabel();
        lporcentaje27 = new javax.swing.JLabel();
        lporcentaje28 = new javax.swing.JLabel();
        lporcentaje29 = new javax.swing.JLabel();
        lporcentaje30 = new javax.swing.JLabel();
        cvencimientosadelantados = new javax.swing.JComboBox();
        jPanel6 = new javax.swing.JPanel();
        lresultadoporcentajes = new javax.swing.JLabel();
        bmodificar = new javax.swing.JButton();
        baceptar = new javax.swing.JButton();
        bcancelar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        lcodigo.setText("Código");

        ldescripcionIdentificativa.setText("Descripción identificativa");

        ldescripcionCliente.setText("Descripción para el cliente");

        lprontoPago.setText("Dto. por pronto pago");

        tcodigo.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tcodigoKeyReleased(evt);
            }
        });

        tdescripcionidentificativa.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tdescripcionidentificativaKeyReleased(evt);
            }
        });

        tdescripcioncliente.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tdescripcionclienteKeyReleased(evt);
            }
        });

        tdtopp.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tdtoppKeyReleased(evt);
            }
        });

        lporcentaje.setText("%");

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder("Plazos adelantados"));

        lnplazosAdelantados.setText("Nº de plazos adelantados");

        ltiporecibop.setText("Tipo de recibo");

        ctiporecibop.setModel(new javax.swing.DefaultComboBoxModel(new String[] {}));

        lplazopago2.setText("Plazo 1");

        tplazopago1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tplazopago1KeyReleased(evt);
            }
        });

        lplazopago8.setText("Plazo 5");

        tplazopago5.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tplazopago5KeyReleased(evt);
            }
        });

        lplazopago9.setText("Plazo 2");

        tplazopago2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tplazopago2KeyReleased(evt);
            }
        });

        lplazopago10.setText("Plazo 3");

        tplazopago3.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tplazopago3KeyReleased(evt);
            }
        });

        lplazopago11.setText("Plazo 4");

        tplazopago4.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tplazopago4KeyReleased(evt);
            }
        });

        tporcentajepago1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tporcentajepago1KeyReleased(evt);
            }
        });

        tporcentajepago2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tporcentajepago2KeyReleased(evt);
            }
        });

        tporcentajepago3.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tporcentajepago3KeyReleased(evt);
            }
        });

        tporcentajepago4.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tporcentajepago4KeyReleased(evt);
            }
        });

        tporcentajepago5.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tporcentajepago5KeyReleased(evt);
            }
        });

        lporcentaje2.setText("%");

        lporcentaje3.setText("%");

        lporcentaje4.setText("%");

        lporcentaje5.setText("%");

        lporcentaje6.setText("%");

        lplazopago12.setText("Plazo 9");

        lplazopago13.setText("Plazo 10");

        tplazopago10.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tplazopago10KeyReleased(evt);
            }
        });

        tplazopago9.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tplazopago9KeyReleased(evt);
            }
        });

        lplazopago14.setText("Plazo 8");

        lplazopago3.setText("Plazo 6");

        lplazopago7.setText("Plazo 7");

        tplazopago6.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tplazopago6KeyReleased(evt);
            }
        });

        tplazopago7.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tplazopago7KeyReleased(evt);
            }
        });

        tplazopago8.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tplazopago8KeyReleased(evt);
            }
        });

        tporcentajepago7.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tporcentajepago7KeyReleased(evt);
            }
        });

        lporcentaje7.setText("%");

        tporcentajepago6.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tporcentajepago6KeyReleased(evt);
            }
        });

        lporcentaje8.setText("%");

        tporcentajepago8.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tporcentajepago8KeyReleased(evt);
            }
        });

        lporcentaje9.setText("%");

        tporcentajepago9.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tporcentajepago9KeyReleased(evt);
            }
        });

        lporcentaje10.setText("%");

        tporcentajepago10.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tporcentajepago10KeyReleased(evt);
            }
        });

        lporcentaje11.setText("%");

        lnplazosAdelantados2.setText("Nombre");

        lnplazosAdelantados3.setText("Porcentaje");

        cplazospagoadelantados.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10"}));
        cplazospagoadelantados.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cplazospagoadelantadosActionPerformed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout jPanel1Layout = new org.jdesktop.layout.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jPanel1Layout.createSequentialGroup()
                        .add(lnplazosAdelantados)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(cplazospagoadelantados, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 45, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(ltiporecibop)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(ctiporecibop, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 224, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                    .add(org.jdesktop.layout.GroupLayout.TRAILING, jPanel1Layout.createSequentialGroup()
                        .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(jPanel1Layout.createSequentialGroup()
                                .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                                    .add(lplazopago10)
                                    .add(lplazopago2)
                                    .add(lplazopago9))
                                .add(10, 10, 10)
                                .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                                    .add(tplazopago2, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 219, Short.MAX_VALUE)
                                    .add(jPanel1Layout.createSequentialGroup()
                                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                        .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                                            .add(tplazopago1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 219, Short.MAX_VALUE)
                                            .add(lnplazosAdelantados2)))
                                    .add(tplazopago3, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 219, Short.MAX_VALUE)))
                            .add(jPanel1Layout.createSequentialGroup()
                                .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                                    .add(lplazopago14)
                                    .add(lplazopago3)
                                    .add(lplazopago7)
                                    .add(lplazopago12)
                                    .add(lplazopago13))
                                .add(4, 4, 4)
                                .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                                    .add(org.jdesktop.layout.GroupLayout.TRAILING, tplazopago9, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 219, Short.MAX_VALUE)
                                    .add(org.jdesktop.layout.GroupLayout.TRAILING, tplazopago7, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 219, Short.MAX_VALUE)
                                    .add(tplazopago8, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 219, Short.MAX_VALUE)
                                    .add(tplazopago10, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 219, Short.MAX_VALUE)
                                    .add(jPanel1Layout.createSequentialGroup()
                                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                        .add(tplazopago6, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 219, Short.MAX_VALUE))))
                            .add(jPanel1Layout.createSequentialGroup()
                                .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                                    .add(lplazopago11)
                                    .add(lplazopago8))
                                .add(10, 10, 10)
                                .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                                    .add(tplazopago4, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 219, Short.MAX_VALUE)
                                    .add(tplazopago5, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 219, Short.MAX_VALUE))))
                        .add(33, 33, 33)
                        .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(lnplazosAdelantados3)
                            .add(jPanel1Layout.createSequentialGroup()
                                .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                                    .add(tporcentajepago1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 70, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                    .add(tporcentajepago2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 70, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                                    .add(lporcentaje2)
                                    .add(lporcentaje3)))
                            .add(jPanel1Layout.createSequentialGroup()
                                .add(tporcentajepago3, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 70, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                .add(lporcentaje4))
                            .add(jPanel1Layout.createSequentialGroup()
                                .add(tporcentajepago4, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 70, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                .add(lporcentaje5))
                            .add(jPanel1Layout.createSequentialGroup()
                                .add(tporcentajepago5, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 70, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                .add(lporcentaje6))
                            .add(jPanel1Layout.createSequentialGroup()
                                .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                                    .add(tporcentajepago6, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 70, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                    .add(tporcentajepago7, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 70, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                    .add(tporcentajepago8, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 70, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                    .add(tporcentajepago9, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 70, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                    .add(tporcentajepago10, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 70, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                                    .add(lporcentaje8)
                                    .add(lporcentaje7)
                                    .add(lporcentaje9)
                                    .add(lporcentaje10)
                                    .add(lporcentaje11))))
                        .add(99, 99, 99)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel1Layout.createSequentialGroup()
                .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(lnplazosAdelantados)
                    .add(ltiporecibop)
                    .add(cplazospagoadelantados, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(ctiporecibop, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jPanel1Layout.createSequentialGroup()
                        .add(lnplazosAdelantados2)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(lplazopago2)
                            .add(jPanel1Layout.createSequentialGroup()
                                .add(tplazopago1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                                    .add(lplazopago9)
                                    .add(tplazopago2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(lplazopago10)
                            .add(tplazopago3, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                        .add(8, 8, 8)
                        .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(lplazopago11)
                            .add(tplazopago4, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(lplazopago8)
                            .add(tplazopago5, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(lplazopago3)
                            .add(jPanel1Layout.createSequentialGroup()
                                .add(tplazopago6, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                                    .add(lplazopago7)
                                    .add(tplazopago7, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(lplazopago14)
                            .add(tplazopago8, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                        .add(8, 8, 8)
                        .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(lplazopago12)
                            .add(tplazopago9, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(lplazopago13)
                            .add(tplazopago10, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                    .add(jPanel1Layout.createSequentialGroup()
                        .add(lnplazosAdelantados3)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(tporcentajepago1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(lporcentaje2))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(tporcentajepago2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(lporcentaje3))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(tporcentajepago3, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(lporcentaje4))
                        .add(8, 8, 8)
                        .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(lporcentaje5)
                            .add(tporcentajepago4, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(tporcentajepago5, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(lporcentaje6))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(tporcentajepago6, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(lporcentaje8))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(tporcentajepago7, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(lporcentaje7))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(tporcentajepago8, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(lporcentaje9))
                        .add(8, 8, 8)
                        .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(tporcentajepago9, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(lporcentaje10))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(tporcentajepago10, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(lporcentaje11)))))
        );

        List ltiporecibop = BaseDatos.getListaTipoRecibo();
        TipoRecibo tr;
        ctiporecibop.addItem("-- Vacío --");
        for (Iterator it = ltiporecibop.iterator(); it.hasNext();) {
            tr = (TipoRecibo) it.next();
            ctiporecibop.addItem(tr.getDescripcion());
        }

        org.jdesktop.layout.GroupLayout pdatosLayout = new org.jdesktop.layout.GroupLayout(pdatos);
        pdatos.setLayout(pdatosLayout);
        pdatosLayout.setHorizontalGroup(
            pdatosLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(pdatosLayout.createSequentialGroup()
                .addContainerGap()
                .add(pdatosLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(pdatosLayout.createSequentialGroup()
                        .add(lcodigo)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(tcodigo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 72, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                    .add(pdatosLayout.createSequentialGroup()
                        .add(pdatosLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(ldescripcionCliente)
                            .add(ldescripcionIdentificativa)
                            .add(lprontoPago))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(pdatosLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(pdatosLayout.createSequentialGroup()
                                .add(tdtopp, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 49, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                .add(lporcentaje))
                            .add(pdatosLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                                .add(tdescripcionidentificativa)
                                .add(tdescripcioncliente, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 348, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))))
                    .add(jPanel1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(122, Short.MAX_VALUE))
        );
        pdatosLayout.setVerticalGroup(
            pdatosLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(pdatosLayout.createSequentialGroup()
                .addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .add(pdatosLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                    .add(pdatosLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                        .add(ldescripcionIdentificativa)
                        .add(tdescripcionidentificativa, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                    .add(pdatosLayout.createSequentialGroup()
                        .add(pdatosLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(lcodigo)
                            .add(tcodigo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                        .add(32, 32, 32)))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(pdatosLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(ldescripcionCliente)
                    .add(tdescripcioncliente, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(pdatosLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(lprontoPago)
                    .add(tdtopp, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(lporcentaje))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
        );

        jTabbedPane1.addTab("Datos generales", pdatos);

        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder("Vencimientos"));

        lnplazosvencimientos.setText("Nº de vencimientos");

        ltipocalculo.setText("Tipo de cálculo vencimientos");

        ctipocalculo.setModel(new javax.swing.DefaultComboBoxModel(new String[] { Constantes.VACIO, Constantes.MESES_ENTEROS, Constantes.DIAS_EXACTOS }));

        ltiporecibov.setText("Tipo de recibo");

        ctiporecibov.setModel(new javax.swing.DefaultComboBoxModel(new String[] {}));

        bcalculoautomatico.setText("Cálculo de vencimientos automático");
        bcalculoautomatico.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bcalculoautomaticoActionPerformed(evt);
            }
        });

        bporcentajesautomaticos.setText("Porcentajes automáticos");
        bporcentajesautomaticos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bporcentajesautomaticosActionPerformed(evt);
            }
        });

        limporteminimo.setText("Importe mínimo varios plazos");

        timporteminimo.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                timporteminimoKeyReleased(evt);
            }
        });

        leuros.setText("€");

        jPanel4.setBorder(javax.swing.BorderFactory.createTitledBorder("Vencimientos manuales"));

        lplazopago4.setText("Plazo 1");

        tplazovm1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tplazovm1KeyReleased(evt);
            }
        });

        lplazopago17.setText("Plazo 2");

        tplazovm2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tplazovm2KeyReleased(evt);
            }
        });

        lplazopago18.setText("Plazo 3");

        tplazovm3.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tplazovm3KeyReleased(evt);
            }
        });

        lplazopago19.setText("Plazo 4");

        tplazovm4.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tplazovm4KeyReleased(evt);
            }
        });

        lplazopago16.setText("Plazo 5");

        tplazovm5.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tplazovm5KeyReleased(evt);
            }
        });

        lplazopago5.setText("Plazo 6");

        tplazovm6.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tplazovm6KeyReleased(evt);
            }
        });

        lplazopago23.setText("Plazo 7");

        tplazovm7.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tplazovm7KeyReleased(evt);
            }
        });

        lplazopago22.setText("Plazo 8");

        tplazovm8.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tplazovm8KeyReleased(evt);
            }
        });

        lplazopago20.setText("Plazo 9");

        tplazovm9.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tplazovm9KeyReleased(evt);
            }
        });

        lplazopago21.setText("Plazo 10");

        tplazovm10.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tplazovm10KeyReleased(evt);
            }
        });

        org.jdesktop.layout.GroupLayout jPanel4Layout = new org.jdesktop.layout.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel4Layout.createSequentialGroup()
                .add(jPanel4Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING, false)
                    .add(jPanel4Layout.createSequentialGroup()
                        .add(lplazopago4)
                        .add(10, 10, 10)
                        .add(tplazovm1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 58, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(12, 12, 12)
                        .add(lplazopago17)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                        .add(tplazovm2))
                    .add(org.jdesktop.layout.GroupLayout.LEADING, jPanel4Layout.createSequentialGroup()
                        .add(lplazopago5)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                        .add(tplazovm6, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 60, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                        .add(lplazopago23)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                        .add(tplazovm7, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 60, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                .add(18, 18, 18)
                .add(jPanel4Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                    .add(jPanel4Layout.createSequentialGroup()
                        .add(lplazopago22)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                        .add(tplazovm8, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 60, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                        .add(lplazopago20)
                        .add(18, 18, 18)
                        .add(tplazovm9))
                    .add(jPanel4Layout.createSequentialGroup()
                        .add(lplazopago18)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                        .add(tplazovm3, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 60, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                        .add(lplazopago19)
                        .add(18, 18, 18)
                        .add(tplazovm4, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 58, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                .add(18, 18, 18)
                .add(jPanel4Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                    .add(jPanel4Layout.createSequentialGroup()
                        .add(lplazopago21)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                        .add(tplazovm10, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 54, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                    .add(jPanel4Layout.createSequentialGroup()
                        .add(lplazopago16)
                        .add(18, 18, 18)
                        .add(tplazovm5)))
                .addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel4Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(lplazopago4)
                    .add(jPanel4Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                        .add(tplazovm1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(lplazopago17)
                        .add(tplazovm2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(lplazopago18)
                        .add(tplazovm3, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(lplazopago19)
                        .add(tplazovm4, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(lplazopago16)
                        .add(tplazovm5, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 19, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                .add(18, 18, 18)
                .add(jPanel4Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(lplazopago5)
                    .add(tplazovm6, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(lplazopago23)
                    .add(tplazovm7, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(lplazopago22)
                    .add(tplazovm8, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(lplazopago20)
                    .add(lplazopago21)
                    .add(tplazovm9, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(tplazovm10, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel7.setBorder(javax.swing.BorderFactory.createTitledBorder("Vencimientos automáticos"));

        ldiasprimerplazo.setText("Días hasta primer plazo");

        tdiasprimerplazo.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tdiasprimerplazoKeyReleased(evt);
            }
        });

        ldiasentreplazos.setText("Días entre plazos");

        tdiasentreplazos.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tdiasentreplazosKeyReleased(evt);
            }
        });

        lresultadovencimientos.setText("Resultado del cálculo: ");

        org.jdesktop.layout.GroupLayout jPanel7Layout = new org.jdesktop.layout.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel7Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(lresultadovencimientos, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 550, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(jPanel7Layout.createSequentialGroup()
                        .add(ldiasprimerplazo)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(tdiasprimerplazo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 51, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(47, 47, 47)
                        .add(ldiasentreplazos)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(tdiasentreplazos, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 51, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(32, Short.MAX_VALUE))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel7Layout.createSequentialGroup()
                .add(jPanel7Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(ldiasprimerplazo)
                    .add(tdiasprimerplazo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(tdiasentreplazos, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(ldiasentreplazos))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(lresultadovencimientos))
        );

        jPanel8.setBorder(javax.swing.BorderFactory.createTitledBorder("Porcentajes manuales"));

        lplazopago43.setText("Plazo 1");

        tplazopm1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tplazopm1KeyReleased(evt);
            }
        });

        lplazopago44.setText("Plazo 2");

        tplazopm2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tplazopm2KeyReleased(evt);
            }
        });

        lplazopago45.setText("Plazo 3");

        tplazopm3.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tplazopm3KeyReleased(evt);
            }
        });

        lplazopago46.setText("Plazo 4");

        tplazopm4.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tplazopm4KeyReleased(evt);
            }
        });

        lplazopago47.setText("Plazo 5");

        tplazopm5.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tplazopm5KeyReleased(evt);
            }
        });

        lplazopago48.setText("Plazo 6");

        tplazopm6.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tplazopm6KeyReleased(evt);
            }
        });

        lplazopago49.setText("Plazo 7");

        tplazopm7.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tplazopm7KeyReleased(evt);
            }
        });

        lplazopago50.setText("Plazo 8");

        tplazopm8.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tplazopm8KeyReleased(evt);
            }
        });

        lplazopago51.setText("Plazo 9");

        tplazopm9.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tplazopm9KeyReleased(evt);
            }
        });

        lplazopago52.setText("Plazo 10");

        tplazopm10.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tplazopm10KeyReleased(evt);
            }
        });

        lporcentaje21.setText("%");

        lporcentaje22.setText("%");

        lporcentaje23.setText("%");

        lporcentaje24.setText("%");

        lporcentaje25.setText("%");

        lporcentaje26.setText("%");

        lporcentaje27.setText("%");

        lporcentaje28.setText("%");

        lporcentaje29.setText("%");

        lporcentaje30.setText("%");

        org.jdesktop.layout.GroupLayout jPanel8Layout = new org.jdesktop.layout.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel8Layout.createSequentialGroup()
                .add(jPanel8Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                    .add(jPanel8Layout.createSequentialGroup()
                        .add(lplazopago43)
                        .add(10, 10, 10)
                        .add(tplazopm1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 52, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(lporcentaje21)
                        .add(10, 10, 10)
                        .add(lplazopago44)
                        .add(7, 7, 7)
                        .add(tplazopm2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 52, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                    .add(jPanel8Layout.createSequentialGroup()
                        .add(lplazopago48)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                        .add(tplazopm6, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 52, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(lporcentaje22)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                        .add(lplazopago49)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                        .add(tplazopm7)))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel8Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                    .add(jPanel8Layout.createSequentialGroup()
                        .add(lporcentaje23)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(lplazopago45)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(tplazopm3, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 52, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(lporcentaje25)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                        .add(lplazopago46)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(tplazopm4, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 49, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(lporcentaje27)
                        .add(8, 8, 8)
                        .add(lplazopago47)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                        .add(tplazopm5, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 48, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                    .add(jPanel8Layout.createSequentialGroup()
                        .add(lporcentaje24)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(lplazopago50)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(tplazopm8, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 52, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(lporcentaje26)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                        .add(lplazopago51)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(tplazopm9, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 51, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(lporcentaje28)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(lplazopago52)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(tplazopm10)))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel8Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(lporcentaje29)
                    .add(lporcentaje30))
                .addContainerGap())
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel8Layout.createSequentialGroup()
                .addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .add(jPanel8Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(lplazopago43)
                    .add(jPanel8Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                        .add(tplazopm1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(tplazopm2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(lporcentaje21)
                        .add(lplazopago44))
                    .add(jPanel8Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                        .add(lplazopago45)
                        .add(tplazopm3, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(lporcentaje23)
                        .add(lporcentaje25)
                        .add(lplazopago46)
                        .add(tplazopm4, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(lporcentaje27)
                        .add(lplazopago47)
                        .add(lporcentaje29)
                        .add(tplazopm5, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel8Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(lplazopago48)
                    .add(tplazopm6, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(lporcentaje22)
                    .add(lplazopago49)
                    .add(tplazopm7, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(lporcentaje24)
                    .add(lplazopago50)
                    .add(tplazopm8, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(lporcentaje26)
                    .add(lplazopago51)
                    .add(tplazopm9, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(lporcentaje28)
                    .add(lplazopago52)
                    .add(tplazopm10, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(lporcentaje30)))
        );

        cvencimientosadelantados.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10" }));
        cvencimientosadelantados.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cvencimientosadelantadosActionPerformed(evt);
            }
        });

        jPanel6.setBorder(javax.swing.BorderFactory.createTitledBorder("Porcentajes automáticos"));

        lresultadoporcentajes.setText("Resultado del cálculo: ");

        org.jdesktop.layout.GroupLayout jPanel6Layout = new org.jdesktop.layout.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .add(lresultadoporcentajes, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 571, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel6Layout.createSequentialGroup()
                .add(lresultadoporcentajes)
                .addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        org.jdesktop.layout.GroupLayout jPanel3Layout = new org.jdesktop.layout.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jPanel3Layout.createSequentialGroup()
                        .add(jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(jPanel3Layout.createSequentialGroup()
                                .add(limporteminimo)
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                .add(timporteminimo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 65, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                .add(leuros))
                            .add(jPanel3Layout.createSequentialGroup()
                                .add(jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                                    .add(lnplazosvencimientos)
                                    .add(ltiporecibov))
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                .add(jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                                    .add(cvencimientosadelantados, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 49, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                    .add(ctiporecibov, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 208, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))))
                        .add(29, 29, 29)
                        .add(jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(bporcentajesautomaticos)
                            .add(bcalculoautomatico)
                            .add(jPanel3Layout.createSequentialGroup()
                                .add(ltipocalculo)
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                .add(ctipocalculo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 118, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))))
                    .add(jPanel3Layout.createSequentialGroup()
                        .add(jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(jPanel3Layout.createSequentialGroup()
                                .add(jPanel6, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED, 1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                            .add(jPanel3Layout.createSequentialGroup()
                                .add(jPanel4, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED))
                            .add(jPanel7, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .add(jPanel8, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 604, Short.MAX_VALUE))
                        .add(8, 8, 8))))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel3Layout.createSequentialGroup()
                .add(jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(lnplazosvencimientos)
                    .add(ltipocalculo)
                    .add(ctipocalculo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(cvencimientosadelantados, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jPanel3Layout.createSequentialGroup()
                        .add(jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(ltiporecibov)
                            .add(ctiporecibov, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 22, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(limporteminimo)
                            .add(timporteminimo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(leuros)))
                    .add(jPanel3Layout.createSequentialGroup()
                        .add(bcalculoautomatico)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(bporcentajesautomaticos)))
                .add(18, 18, 18)
                .add(jPanel7, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel4, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel6, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel8, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
        );

        List ltiporecibov = BaseDatos.getListaTipoRecibo();
        TipoRecibo tr1;
        ctiporecibov.addItem("-- Vacío --");
        for (Iterator it = ltiporecibov.iterator(); it.hasNext();) {
            tr1 = (TipoRecibo) it.next();
            ctiporecibov.addItem(tr1.getDescripcion());
        }

        org.jdesktop.layout.GroupLayout jPanel2Layout = new org.jdesktop.layout.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel3, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel3, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
        );

        jTabbedPane1.addTab("Vencimientos", jPanel2);

        bmodificar.setText("Modificar");
        bmodificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bmodificarActionPerformed(evt);
            }
        });

        baceptar.setText("Aceptar");
        baceptar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                baceptarActionPerformed(evt);
            }
        });

        bcancelar.setText("Cancelar");
        bcancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bcancelarActionPerformed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout layout = new org.jdesktop.layout.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                .add(layout.createSequentialGroup()
                    .add(baceptar)
                    .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                    .add(bmodificar, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 103, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                    .add(bcancelar))
                .add(jTabbedPane1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(layout.createSequentialGroup()
                .add(jTabbedPane1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(bcancelar)
                    .add(bmodificar)
                    .add(baceptar))
                .addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

private void bmodificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bmodificarActionPerformed

    if (bmodificar.getText().equals("Modificar")) {
        tcodigo.setEnabled(true);
        tdescripcioncliente.setEnabled(true);
        tdescripcionidentificativa.setEnabled(true);
        tdtopp.setEnabled(true);
        cplazospagoadelantados.setEnabled(true);
        ctiporecibop.setEnabled(true);
        habilitarPagos(true);
        cvencimientosadelantados.setEnabled(true);
        ctipocalculo.setEnabled(true);
        ctiporecibov.setEnabled(true);
        bcalculoautomatico.setEnabled(true);
        bporcentajesautomaticos.setEnabled(true);
        timporteminimo.setEnabled(true);
        tdiasentreplazos.setEnabled(true);
        tdiasprimerplazo.setEnabled(true);
        if (!bporcentajesautomaticos.isSelected()) {
            habilitarPorcentajesManuales(true);
        }
        if (!bcalculoautomatico.isSelected()) {
            habilitarVencimientosManuales(true);
        }
        URL urlModificar = getClass().getResource("/iconos/buscar.gif");
        ImageIcon iconoModificar = new ImageIcon(urlModificar);
        bmodificar.setIcon(iconoModificar);
        bmodificar.setText("Visualizar");
        bmodificar.setToolTipText("Visualizar campos");
    } else {
        tcodigo.setEnabled(false);
        tdescripcioncliente.setEnabled(false);
        tdescripcionidentificativa.setEnabled(false);
        tdtopp.setEnabled(false);
        cplazospagoadelantados.setEnabled(false);
        ctiporecibop.setEnabled(false);
        habilitarPagos(false);
        cvencimientosadelantados.setEnabled(false);
        ctipocalculo.setEnabled(false);
        ctiporecibov.setEnabled(false);
        bcalculoautomatico.setEnabled(false);
        bporcentajesautomaticos.setEnabled(false);
        timporteminimo.setEnabled(false);
        tdiasentreplazos.setEnabled(false);
        tdiasprimerplazo.setEnabled(false);
        habilitarPorcentajesManuales(false);
        habilitarVencimientosManuales(false);
        URL urlModificar = getClass().getResource("/iconos/editar.png");
        ImageIcon iconoModificar = new ImageIcon(urlModificar);
        bmodificar.setIcon(iconoModificar);
        bmodificar.setText("Modificar");
        bmodificar.setToolTipText("Modificar campos");
    }
}//GEN-LAST:event_bmodificarActionPerformed

private void baceptarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_baceptarActionPerformed
    try {
        String codigo = tcodigo.getText();
        String descripcionCliente = tdescripcioncliente.getText();
        String descripcionIdentificativa = tdescripcionidentificativa.getText();

        if (codigo.length() == 0 || descripcionCliente.length() == 0 || descripcionIdentificativa.length() == 0) {
            JOptionPane.showMessageDialog(null, "Debe rellenar el código y las descripciones", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            double porcentaje_pronto_pago;
            if (tdtopp.getText().length() == 0) {
                porcentaje_pronto_pago = 0;
            } else {
                porcentaje_pronto_pago = Double.valueOf(Util.convertirComaAPunto(tdtopp.getText()));
            }

            String tipoReciboP = (String) ctiporecibop.getSelectedItem();
            String tipoReciboV = (String) ctiporecibov.getSelectedItem();
            String tipoCalculo = (String) ctipocalculo.getSelectedItem();

            fp.setCodigo(codigo);
            fp.setDescripcioncliente(descripcionCliente);
            fp.setDescripcionidentificativa(descripcionIdentificativa);
            fp.setDtoprontopago(porcentaje_pronto_pago);
            fp.setTipodecalculo(tipoCalculo);
            fp.setNumplazosadelantados(Integer.valueOf((String) cplazospagoadelantados.getSelectedItem()));
            fp.setNumplazosvencimiento(Integer.valueOf((String) cvencimientosadelantados.getSelectedItem()));
            TipoRecibo tr_aux = BaseDatos.obtenerTipoReciboPorDesc(tipoReciboP);
            fp.setTiporecibopago(tipoReciboP);
            fp.setIid_tr_p1(tr_aux);
            fp.setIid_tr_p2(tr_aux);
            fp.setIid_tr_p3(tr_aux);
            fp.setIid_tr_p4(tr_aux);
            fp.setIid_tr_p5(tr_aux);
            fp.setIid_tr_p6(tr_aux);
            fp.setIid_tr_p7(tr_aux);
            fp.setIid_tr_p8(tr_aux);
            fp.setIid_tr_p9(tr_aux);
            fp.setIid_tr_p10(tr_aux);

            tr_aux = BaseDatos.obtenerTipoReciboPorDesc(tipoReciboV);
            fp.setTiporecibovencimiento(tipoReciboV);
            fp.setIid_tr_v1(tr_aux);
            fp.setIid_tr_v2(tr_aux);
            fp.setIid_tr_v3(tr_aux);
            fp.setIid_tr_v4(tr_aux);
            fp.setIid_tr_v5(tr_aux);
            fp.setIid_tr_v6(tr_aux);
            fp.setIid_tr_v7(tr_aux);
            fp.setIid_tr_v8(tr_aux);
            fp.setIid_tr_v9(tr_aux);
            fp.setIid_tr_v10(tr_aux);

            double porcentaje_pago = calcularPorcentajesPago();
            double porcentaje_vto = calcularPorcentajeVencimiento();
            String nombrePlazos = crearMensajePlazos();

            if (!bcalculoautomatico.isSelected() && !bporcentajesautomaticos.isSelected() && !calcularPlazosVencimiento()) {
                if (nombrePlazos.length() == 0) {
                    JOptionPane.showMessageDialog(null, "Debe completar los plazos de vencimiento", "Error", JOptionPane.ERROR_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(null, "Debe completar los plazos de vencimiento y el nombre de los plazos adelantados", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } else if ((matematico.Matematico.redondear2decimales(porcentaje_pago + porcentaje_vto + porcentaje_pronto_pago)) < 100) {
                if (nombrePlazos.length() == 0) {
                    JOptionPane.showMessageDialog(null, "Los % no suman 100", "Error", JOptionPane.ERROR_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(null, "Los % no suman 100 y debe completar el nombre de los plazos adelantados", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } else if (nombrePlazos.length() != 0) {
                JOptionPane.showMessageDialog(null, "Debe completar el nombre de los plazos", "Error", JOptionPane.ERROR_MESSAGE);
            } else {
                double importe_minimo;
                if (timporteminimo.getText().length() == 0) {
                    importe_minimo = 0;
                } else {
                    importe_minimo = Double.parseDouble(Util.convertirComaAPunto(timporteminimo.getText()));
                }

                fp.setCalculovencimientoautomatico(bcalculoautomatico.isSelected());
                fp.setPorcentajeautomatico(bporcentajesautomaticos.isSelected());
                fp.setTipodecalculo((String) ctipocalculo.getSelectedItem());
                fp.setNombreplazo1(tplazopago1.getText());
                fp.setNombreplazo2(tplazopago2.getText());
                fp.setNombreplazo3(tplazopago3.getText());
                fp.setNombreplazo4(tplazopago4.getText());
                fp.setNombreplazo5(tplazopago5.getText());
                fp.setNombreplazo6(tplazopago6.getText());
                fp.setNombreplazo7(tplazopago7.getText());
                fp.setNombreplazo8(tplazopago8.getText());
                fp.setNombreplazo9(tplazopago9.getText());
                fp.setNombreplazo10(tplazopago10.getText());
                fp.setImporteminimo(importe_minimo);
                fp.setImportep1(0.0);
                fp.setImportep2(0.0);
                fp.setImportep3(0.0);
                fp.setImportep4(0.0);
                fp.setImportep5(0.0);
                fp.setImportep6(0.0);
                fp.setImportep7(0.0);
                fp.setImportep8(0.0);
                fp.setImportep9(0.0);
                fp.setImportep10(0.0);
                fp.setImportev1(0.0);
                fp.setImportev2(0.0);
                fp.setImportev3(0.0);
                fp.setImportev4(0.0);
                fp.setImportev5(0.0);
                fp.setImportev6(0.0);
                fp.setImportev7(0.0);
                fp.setImportev8(0.0);
                fp.setImportev9(0.0);
                fp.setImportev10(0.0);

                if (crear) {
                    if (BaseDatos.obtenerFormaPago(codigo) == null) {
                        if (BaseDatos.insertarElemento(fp)) {
                            cerrarVentana();
                        } else {
                            JOptionPane.showMessageDialog(null, "Se ha producido un error al insertar el elemento", "Error", JOptionPane.ERROR_MESSAGE);
                        }
                    } else {
                        JOptionPane.showMessageDialog(null, "El código introducido ya existe", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                } else {
                    if (codigoAntiguo.equals(tcodigo.getText()) || BaseDatos.obtenerFormaPago(codigo) == null) {
                        if (BaseDatos.modificarElemento(fp)) {
                            cerrarVentana();
                        } else {
                            JOptionPane.showMessageDialog(null, "No se ha podido modificar el elemento", "Error", JOptionPane.ERROR_MESSAGE);
                        }
                    } else {
                        JOptionPane.showMessageDialog(null, "El código introducido ya existe", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
            }
        }
    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "Error, los campos numéricos deben ser números", "Error", JOptionPane.ERROR_MESSAGE);
    }
}//GEN-LAST:event_baceptarActionPerformed

private void bcancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bcancelarActionPerformed
    cerrarVentana();
}//GEN-LAST:event_bcancelarActionPerformed

private void cvencimientosadelantadosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cvencimientosadelantadosActionPerformed
    int vencimientosadelantados = Integer.valueOf((String) cvencimientosadelantados.getSelectedItem());

    if (!this.bcalculoautomatico.isSelected()) {
        actualizarVencimientos(vencimientosadelantados);
    }

    if (!this.bporcentajesautomaticos.isSelected()) {
        actualizarPorcentajesVto(vencimientosadelantados);
    } else {
        porcentajesAutomaticos();
    }
}//GEN-LAST:event_cvencimientosadelantadosActionPerformed

private void cplazospagoadelantadosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cplazospagoadelantadosActionPerformed
    actualizarPagos(Integer.valueOf((String) cplazospagoadelantados.getSelectedItem()));
}//GEN-LAST:event_cplazospagoadelantadosActionPerformed

private void bcalculoautomaticoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bcalculoautomaticoActionPerformed
    calculoAutomatico();
}//GEN-LAST:event_bcalculoautomaticoActionPerformed

    private void calculoAutomatico() {
        try {
            int numvto = Integer.valueOf((String) cvencimientosadelantados.getSelectedItem());
            String resultado = "Resultado del cálculo: ";
            if (bcalculoautomatico.isSelected()) {
                //Calculo de vencimientos automático pulsado
                plazo[0] = plazo[1] = plazo[2] = plazo[3] = plazo[4] = plazo[5] = plazo[6] = plazo[7] = plazo[8] = plazo[9] = 0;
                String sdiasEntrePlazos = tdiasentreplazos.getText();
                String sdiasPrimerPlazo = tdiasprimerplazo.getText();

                if (sdiasEntrePlazos.length() == 0 || sdiasPrimerPlazo.length() == 0) {
                    JOptionPane.showMessageDialog(null, "Error, Debe introducir  los días entre plazos y el día del primer plazo", "Error", JOptionPane.ERROR_MESSAGE);
                    bcalculoautomatico.setSelected(false);
                } else {
                    actualizarVencimientos(0);
                    if (numvto > 0) {
                        int diasEntrePlazos;
                        if (tdiasentreplazos.getText().length() == 0) {
                            diasEntrePlazos = 0;
                        } else {
                            diasEntrePlazos = Integer.valueOf(tdiasentreplazos.getText());
                        }
                        fp.setDiasentreplazos(diasEntrePlazos);

                        int diaPrimerPlazo;
                        if (tdiasprimerplazo.getText().length() == 0) {
                            diaPrimerPlazo = 0;
                        } else {
                            diaPrimerPlazo = Integer.valueOf(tdiasprimerplazo.getText());
                        }
                        fp.setDiasprimerplazo(diaPrimerPlazo);

                        int dias = diaPrimerPlazo;

                        resultado += diaPrimerPlazo;
                        plazo[0] = diaPrimerPlazo;
                        for (int i = 1; i < numvto; i++) {
                            dias += diasEntrePlazos;
                            resultado += ", " + dias;
                            plazo[i] = dias;
                        }

                        fp.setPlazovm1(plazo[0]);
                        fp.setPlazovm2(plazo[1]);
                        fp.setPlazovm3(plazo[2]);
                        fp.setPlazovm4(plazo[3]);
                        fp.setPlazovm5(plazo[4]);
                        fp.setPlazovm6(plazo[5]);
                        fp.setPlazovm7(plazo[6]);
                        fp.setPlazovm8(plazo[7]);
                        fp.setPlazovm9(plazo[8]);
                        fp.setPlazovm10(plazo[9]);
                    }
                    lresultadovencimientos.setText(resultado);
                }
            } else {
                tdiasprimerplazo.setText("");
                tdiasentreplazos.setText("");
                lresultadovencimientos.setText("Resultado del cálculo: ");
                actualizarVencimientos(numvto);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error, los campos numéricos deben ser números", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

private void bporcentajesautomaticosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bporcentajesautomaticosActionPerformed
    porcentajesAutomaticos();
}//GEN-LAST:event_bporcentajesautomaticosActionPerformed

private void tcodigoKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tcodigoKeyReleased
    String campo = tcodigo.getText();
    if (campo.length() > Constantes.TAM_CODIGO_FORMA_PAGO) {
        JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_CODIGO_FORMA_PAGO, "Error", JOptionPane.ERROR_MESSAGE);
        tcodigo.setText(campo.substring(0, Constantes.TAM_CODIGO_FORMA_PAGO));
    }
}//GEN-LAST:event_tcodigoKeyReleased

private void tdescripcionidentificativaKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tdescripcionidentificativaKeyReleased
    String campo = tdescripcionidentificativa.getText();
    if (campo.length() > Constantes.TAM_DESCRIPCION_IDENTIFICATIVA_FORMA_PAGO) {
        JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_DESCRIPCION_IDENTIFICATIVA_FORMA_PAGO, "Error", JOptionPane.ERROR_MESSAGE);
        tdescripcionidentificativa.setText(campo.substring(0, Constantes.TAM_DESCRIPCION_IDENTIFICATIVA_FORMA_PAGO));
    }
}//GEN-LAST:event_tdescripcionidentificativaKeyReleased

private void tdtoppKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tdtoppKeyReleased
    int tamaño = tdtopp.getText().length();
    if (tamaño > 0) {
        char c = tdtopp.getText().charAt(tamaño - 1);

        if (c == '.') {
            String contenidoAntiguo = tdtopp.getText().replace(".", ",");
            tdtopp.setText(contenidoAntiguo);
            c = ',';
        }

        if (!((c >= '0' && c <= '9') || c == ',')) {
            String str = tdtopp.getText().substring(0, tamaño - 1);
            tdtopp.setText(str);
        } else if (c == ',') {
            int indicePunto = tdtopp.getText().indexOf(',');
            if (indicePunto != (tamaño - 1)) {
                String str = tdtopp.getText().substring(0, tamaño - 1);
                tdtopp.setText(str);
            }
        }
    }
}//GEN-LAST:event_tdtoppKeyReleased

private void tplazopago1KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tplazopago1KeyReleased
    String codigo = tplazopago1.getText();
    if (codigo.length() > Constantes.TAM_NOMBRE_PLAZO_FORMA_PAGO) {
        JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_NOMBRE_PLAZO_FORMA_PAGO, "Error", JOptionPane.ERROR_MESSAGE);
        tplazopago1.setText(codigo.substring(0, Constantes.TAM_NOMBRE_PLAZO_FORMA_PAGO));
    }
}//GEN-LAST:event_tplazopago1KeyReleased

private void tporcentajepago1KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tporcentajepago1KeyReleased
    int tamaño = tporcentajepago1.getText().length();
    if (tamaño > 0) {
        char c = tporcentajepago1.getText().charAt(tamaño - 1);

        if (c == '.') {
            String contenidoAntiguo = tporcentajepago1.getText().replace(".", ",");
            tporcentajepago1.setText(contenidoAntiguo);
            c = ',';
        }

        if (!((c >= '0' && c <= '9') || c == ',')) {
            String str = tporcentajepago1.getText().substring(0, tamaño - 1);
            tporcentajepago1.setText(str);
        } else if (c == ',') {
            int indicePunto = tporcentajepago1.getText().indexOf(',');
            if (indicePunto != (tamaño - 1)) {
                String str = tporcentajepago1.getText().substring(0, tamaño - 1);
                tporcentajepago1.setText(str);
            }
        }
    }
}//GEN-LAST:event_tporcentajepago1KeyReleased

private void tdescripcionclienteKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tdescripcionclienteKeyReleased
    String campo = tdescripcioncliente.getText();
    if (campo.length() > Constantes.TAM_DESCRIPCION_CLIENTE_FORMA_PAGO) {
        JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_DESCRIPCION_CLIENTE_FORMA_PAGO, "Error", JOptionPane.ERROR_MESSAGE);
        tdescripcioncliente.setText(campo.substring(0, Constantes.TAM_DESCRIPCION_CLIENTE_FORMA_PAGO));
    }
}//GEN-LAST:event_tdescripcionclienteKeyReleased

private void tplazopago2KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tplazopago2KeyReleased
    String codigo = tplazopago2.getText();
    if (codigo.length() > Constantes.TAM_NOMBRE_PLAZO_FORMA_PAGO) {
        JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_NOMBRE_PLAZO_FORMA_PAGO, "Error", JOptionPane.ERROR_MESSAGE);
        tplazopago2.setText(codigo.substring(0, Constantes.TAM_NOMBRE_PLAZO_FORMA_PAGO));
    }
}//GEN-LAST:event_tplazopago2KeyReleased

private void tporcentajepago2KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tporcentajepago2KeyReleased
    int tamaño = tporcentajepago2.getText().length();
    if (tamaño > 0) {
        char c = tporcentajepago2.getText().charAt(tamaño - 1);

        if (c == '.') {
            String contenidoAntiguo = tporcentajepago2.getText().replace(".", ",");
            tporcentajepago2.setText(contenidoAntiguo);
            c = ',';
        }

        if (!((c >= '0' && c <= '9') || c == ',')) {
            String str = tporcentajepago2.getText().substring(0, tamaño - 1);
            tporcentajepago2.setText(str);
        } else if (c == ',') {
            int indicePunto = tporcentajepago2.getText().indexOf(',');
            if (indicePunto != (tamaño - 1)) {
                String str = tporcentajepago2.getText().substring(0, tamaño - 1);
                tporcentajepago2.setText(str);
            }
        }
    }
}//GEN-LAST:event_tporcentajepago2KeyReleased

private void tplazopago3KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tplazopago3KeyReleased
    String codigo = tplazopago3.getText();
    if (codigo.length() > Constantes.TAM_NOMBRE_PLAZO_FORMA_PAGO) {
        JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_NOMBRE_PLAZO_FORMA_PAGO, "Error", JOptionPane.ERROR_MESSAGE);
        tplazopago3.setText(codigo.substring(0, Constantes.TAM_NOMBRE_PLAZO_FORMA_PAGO));
    }
}//GEN-LAST:event_tplazopago3KeyReleased

private void tporcentajepago3KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tporcentajepago3KeyReleased
    int tamaño = tporcentajepago3.getText().length();
    if (tamaño > 0) {
        char c = tporcentajepago3.getText().charAt(tamaño - 1);

        if (c == '.') {
            String contenidoAntiguo = tporcentajepago3.getText().replace(".", ",");
            tporcentajepago3.setText(contenidoAntiguo);
            c = ',';
        }

        if (!((c >= '0' && c <= '9') || c == ',')) {
            String str = tporcentajepago3.getText().substring(0, tamaño - 1);
            tporcentajepago3.setText(str);
        } else if (c == ',') {
            int indicePunto = tporcentajepago3.getText().indexOf(',');
            if (indicePunto != (tamaño - 1)) {
                String str = tporcentajepago3.getText().substring(0, tamaño - 1);
                tporcentajepago3.setText(str);
            }
        }
    }
}//GEN-LAST:event_tporcentajepago3KeyReleased

private void tplazopago4KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tplazopago4KeyReleased
    String codigo = tplazopago4.getText();
    if (codigo.length() > Constantes.TAM_NOMBRE_PLAZO_FORMA_PAGO) {
        JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_NOMBRE_PLAZO_FORMA_PAGO, "Error", JOptionPane.ERROR_MESSAGE);
        tplazopago4.setText(codigo.substring(0, Constantes.TAM_NOMBRE_PLAZO_FORMA_PAGO));
    }
}//GEN-LAST:event_tplazopago4KeyReleased

private void tporcentajepago4KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tporcentajepago4KeyReleased
    int tamaño = tporcentajepago4.getText().length();
    if (tamaño > 0) {
        char c = tporcentajepago4.getText().charAt(tamaño - 1);

        if (c == '.') {
            String contenidoAntiguo = tporcentajepago4.getText().replace(".", ",");
            tporcentajepago4.setText(contenidoAntiguo);
            c = ',';
        }

        if (!((c >= '0' && c <= '9') || c == ',')) {
            String str = tporcentajepago4.getText().substring(0, tamaño - 1);
            tporcentajepago4.setText(str);
        } else if (c == ',') {
            int indicePunto = tporcentajepago4.getText().indexOf(',');
            if (indicePunto != (tamaño - 1)) {
                String str = tporcentajepago4.getText().substring(0, tamaño - 1);
                tporcentajepago4.setText(str);
            }
        }
    }
}//GEN-LAST:event_tporcentajepago4KeyReleased

private void tplazopago5KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tplazopago5KeyReleased
    String codigo = tplazopago5.getText();
    if (codigo.length() > Constantes.TAM_NOMBRE_PLAZO_FORMA_PAGO) {
        JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_NOMBRE_PLAZO_FORMA_PAGO, "Error", JOptionPane.ERROR_MESSAGE);
        tplazopago5.setText(codigo.substring(0, Constantes.TAM_NOMBRE_PLAZO_FORMA_PAGO));
    }
}//GEN-LAST:event_tplazopago5KeyReleased

private void tporcentajepago5KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tporcentajepago5KeyReleased
    int tamaño = tporcentajepago5.getText().length();
    if (tamaño > 0) {
        char c = tporcentajepago5.getText().charAt(tamaño - 1);

        if (c == '.') {
            String contenidoAntiguo = tporcentajepago5.getText().replace(".", ",");
            tporcentajepago5.setText(contenidoAntiguo);
            c = ',';
        }

        if (!((c >= '0' && c <= '9') || c == ',')) {
            String str = tporcentajepago5.getText().substring(0, tamaño - 1);
            tporcentajepago5.setText(str);
        } else if (c == ',') {
            int indicePunto = tporcentajepago5.getText().indexOf(',');
            if (indicePunto != (tamaño - 1)) {
                String str = tporcentajepago5.getText().substring(0, tamaño - 1);
                tporcentajepago5.setText(str);
            }
        }
    }
}//GEN-LAST:event_tporcentajepago5KeyReleased

private void tplazopago6KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tplazopago6KeyReleased
    String codigo = tplazopago6.getText();
    if (codigo.length() > Constantes.TAM_NOMBRE_PLAZO_FORMA_PAGO) {
        JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_NOMBRE_PLAZO_FORMA_PAGO, "Error", JOptionPane.ERROR_MESSAGE);
        tplazopago6.setText(codigo.substring(0, Constantes.TAM_NOMBRE_PLAZO_FORMA_PAGO));
    }
}//GEN-LAST:event_tplazopago6KeyReleased

private void tporcentajepago6KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tporcentajepago6KeyReleased
    int tamaño = tporcentajepago6.getText().length();
    if (tamaño > 0) {
        char c = tporcentajepago6.getText().charAt(tamaño - 1);

        if (c == '.') {
            String contenidoAntiguo = tporcentajepago6.getText().replace(".", ",");
            tporcentajepago6.setText(contenidoAntiguo);
            c = ',';
        }

        if (!((c >= '0' && c <= '9') || c == ',')) {
            String str = tporcentajepago6.getText().substring(0, tamaño - 1);
            tporcentajepago6.setText(str);
        } else if (c == ',') {
            int indicePunto = tporcentajepago6.getText().indexOf(',');
            if (indicePunto != (tamaño - 1)) {
                String str = tporcentajepago6.getText().substring(0, tamaño - 1);
                tporcentajepago6.setText(str);
            }
        }
    }
}//GEN-LAST:event_tporcentajepago6KeyReleased

private void tplazopago7KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tplazopago7KeyReleased
    String codigo = tplazopago7.getText();
    if (codigo.length() > Constantes.TAM_NOMBRE_PLAZO_FORMA_PAGO) {
        JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_NOMBRE_PLAZO_FORMA_PAGO, "Error", JOptionPane.ERROR_MESSAGE);
        tplazopago7.setText(codigo.substring(0, Constantes.TAM_NOMBRE_PLAZO_FORMA_PAGO));
    }
}//GEN-LAST:event_tplazopago7KeyReleased

private void tporcentajepago7KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tporcentajepago7KeyReleased
    int tamaño = tporcentajepago7.getText().length();
    if (tamaño > 0) {
        char c = tporcentajepago7.getText().charAt(tamaño - 1);

        if (c == '.') {
            String contenidoAntiguo = tporcentajepago7.getText().replace(".", ",");
            tporcentajepago7.setText(contenidoAntiguo);
            c = ',';
        }

        if (!((c >= '0' && c <= '9') || c == ',')) {
            String str = tporcentajepago7.getText().substring(0, tamaño - 1);
            tporcentajepago7.setText(str);
        } else if (c == ',') {
            int indicePunto = tporcentajepago7.getText().indexOf(',');
            if (indicePunto != (tamaño - 1)) {
                String str = tporcentajepago7.getText().substring(0, tamaño - 1);
                tporcentajepago7.setText(str);
            }
        }
    }
}//GEN-LAST:event_tporcentajepago7KeyReleased

private void tplazopago8KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tplazopago8KeyReleased
    String codigo = tplazopago8.getText();
    if (codigo.length() > Constantes.TAM_NOMBRE_PLAZO_FORMA_PAGO) {
        JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_NOMBRE_PLAZO_FORMA_PAGO, "Error", JOptionPane.ERROR_MESSAGE);
        tplazopago8.setText(codigo.substring(0, Constantes.TAM_NOMBRE_PLAZO_FORMA_PAGO));
    }
}//GEN-LAST:event_tplazopago8KeyReleased

private void tporcentajepago8KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tporcentajepago8KeyReleased
    int tamaño = tporcentajepago8.getText().length();
    if (tamaño > 0) {
        char c = tporcentajepago8.getText().charAt(tamaño - 1);

        if (c == '.') {
            String contenidoAntiguo = tporcentajepago8.getText().replace(".", ",");
            tporcentajepago8.setText(contenidoAntiguo);
            c = ',';
        }

        if (!((c >= '0' && c <= '9') || c == ',')) {
            String str = tporcentajepago8.getText().substring(0, tamaño - 1);
            tporcentajepago8.setText(str);
        } else if (c == ',') {
            int indicePunto = tporcentajepago8.getText().indexOf(',');
            if (indicePunto != (tamaño - 1)) {
                String str = tporcentajepago8.getText().substring(0, tamaño - 1);
                tporcentajepago8.setText(str);
            }
        }
    }
}//GEN-LAST:event_tporcentajepago8KeyReleased

private void tplazopago9KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tplazopago9KeyReleased
    String codigo = tplazopago9.getText();
    if (codigo.length() > Constantes.TAM_NOMBRE_PLAZO_FORMA_PAGO) {
        JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_NOMBRE_PLAZO_FORMA_PAGO, "Error", JOptionPane.ERROR_MESSAGE);
        tplazopago9.setText(codigo.substring(0, Constantes.TAM_NOMBRE_PLAZO_FORMA_PAGO));
    }
}//GEN-LAST:event_tplazopago9KeyReleased

private void tporcentajepago9KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tporcentajepago9KeyReleased
    int tamaño = tporcentajepago9.getText().length();
    if (tamaño > 0) {
        char c = tporcentajepago9.getText().charAt(tamaño - 1);

        if (c == '.') {
            String contenidoAntiguo = tporcentajepago9.getText().replace(".", ",");
            tporcentajepago9.setText(contenidoAntiguo);
            c = ',';
        }

        if (!((c >= '0' && c <= '9') || c == ',')) {
            String str = tporcentajepago9.getText().substring(0, tamaño - 1);
            tporcentajepago9.setText(str);
        } else if (c == ',') {
            int indicePunto = tporcentajepago9.getText().indexOf(',');
            if (indicePunto != (tamaño - 1)) {
                String str = tporcentajepago9.getText().substring(0, tamaño - 1);
                tporcentajepago9.setText(str);
            }
        }
    }
}//GEN-LAST:event_tporcentajepago9KeyReleased

private void tplazopago10KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tplazopago10KeyReleased
    String codigo = tplazopago10.getText();
    if (codigo.length() > Constantes.TAM_NOMBRE_PLAZO_FORMA_PAGO) {
        JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_NOMBRE_PLAZO_FORMA_PAGO, "Error", JOptionPane.ERROR_MESSAGE);
        tplazopago10.setText(codigo.substring(0, Constantes.TAM_NOMBRE_PLAZO_FORMA_PAGO));
    }
}//GEN-LAST:event_tplazopago10KeyReleased

private void tporcentajepago10KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tporcentajepago10KeyReleased
    int tamaño = tporcentajepago10.getText().length();
    if (tamaño > 0) {
        char c = tporcentajepago10.getText().charAt(tamaño - 1);

        if (c == '.') {
            String contenidoAntiguo = tporcentajepago10.getText().replace(".", ",");
            tporcentajepago10.setText(contenidoAntiguo);
            c = ',';
        }

        if (!((c >= '0' && c <= '9') || c == ',')) {
            String str = tporcentajepago10.getText().substring(0, tamaño - 1);
            tporcentajepago10.setText(str);
        } else if (c == ',') {
            int indicePunto = tporcentajepago10.getText().indexOf(',');
            if (indicePunto != (tamaño - 1)) {
                String str = tporcentajepago10.getText().substring(0, tamaño - 1);
                tporcentajepago10.setText(str);
            }
        }
    }
}//GEN-LAST:event_tporcentajepago10KeyReleased

private void timporteminimoKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_timporteminimoKeyReleased
    int tamaño = timporteminimo.getText().length();
    if (tamaño > 0) {
        char c = timporteminimo.getText().charAt(tamaño - 1);
        if (!((c >= '0' && c <= '9') || c == '.')) {
            String str = timporteminimo.getText().substring(0, tamaño - 1);
            timporteminimo.setText(str);
        } else if (c == '.') {
            int indicePunto = timporteminimo.getText().indexOf('.');
            if (indicePunto != (tamaño - 1)) {
                String str = timporteminimo.getText().substring(0, tamaño - 1);
                timporteminimo.setText(str);
            }
        }
    }
}//GEN-LAST:event_timporteminimoKeyReleased

private void tdiasprimerplazoKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tdiasprimerplazoKeyReleased
    int tamaño = tdiasprimerplazo.getText().length();
    if (tamaño > 0) {
        char c = tdiasprimerplazo.getText().charAt(tamaño - 1);
        if (!(c >= '0' && c <= '9')) {
            String str = tdiasprimerplazo.getText().substring(0, tamaño - 1);
            tdiasprimerplazo.setText(str);
        }
    }
}//GEN-LAST:event_tdiasprimerplazoKeyReleased

private void tplazovm1KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tplazovm1KeyReleased
    int tamaño = tplazovm1.getText().length();
    if (tamaño > 0) {
        char c = tplazovm1.getText().charAt(tamaño - 1);
        if (!(c >= '0' && c <= '9')) {
            String str = tplazovm1.getText().substring(0, tamaño - 1);
            tplazovm1.setText(str);
        }
    }
}//GEN-LAST:event_tplazovm1KeyReleased

private void tplazovm2KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tplazovm2KeyReleased
    int tamaño = tplazovm2.getText().length();
    if (tamaño > 0) {
        char c = tplazovm2.getText().charAt(tamaño - 1);
        if (!(c >= '0' && c <= '9')) {
            String str = tplazovm2.getText().substring(0, tamaño - 1);
            tplazovm2.setText(str);
        }
    }
}//GEN-LAST:event_tplazovm2KeyReleased

private void tplazovm3KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tplazovm3KeyReleased
    int tamaño = tplazovm3.getText().length();
    if (tamaño > 0) {
        char c = tplazovm3.getText().charAt(tamaño - 1);
        if (!(c >= '0' && c <= '9')) {
            String str = tplazovm3.getText().substring(0, tamaño - 1);
            tplazovm3.setText(str);
        }
    }
}//GEN-LAST:event_tplazovm3KeyReleased

private void tplazovm4KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tplazovm4KeyReleased
    int tamaño = tplazovm4.getText().length();
    if (tamaño > 0) {
        char c = tplazovm4.getText().charAt(tamaño - 1);
        if (!(c >= '0' && c <= '9')) {
            String str = tplazovm4.getText().substring(0, tamaño - 1);
            tplazovm4.setText(str);
        }
    }
}//GEN-LAST:event_tplazovm4KeyReleased

private void tplazovm5KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tplazovm5KeyReleased
    int tamaño = tplazovm5.getText().length();
    if (tamaño > 0) {
        char c = tplazovm5.getText().charAt(tamaño - 1);
        if (!(c >= '0' && c <= '9')) {
            String str = tplazovm5.getText().substring(0, tamaño - 1);
            tplazovm5.setText(str);
        }
    }
}//GEN-LAST:event_tplazovm5KeyReleased

private void tplazovm6KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tplazovm6KeyReleased
    int tamaño = tplazovm6.getText().length();
    if (tamaño > 0) {
        char c = tplazovm6.getText().charAt(tamaño - 1);
        if (!(c >= '0' && c <= '9')) {
            String str = tplazovm6.getText().substring(0, tamaño - 1);
            tplazovm6.setText(str);
        }
    }
}//GEN-LAST:event_tplazovm6KeyReleased

private void tplazovm7KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tplazovm7KeyReleased
    int tamaño = tplazovm7.getText().length();
    if (tamaño > 0) {
        char c = tplazovm7.getText().charAt(tamaño - 1);
        if (!(c >= '0' && c <= '9')) {
            String str = tplazovm7.getText().substring(0, tamaño - 1);
            tplazovm7.setText(str);
        }
    }
}//GEN-LAST:event_tplazovm7KeyReleased

private void tplazovm8KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tplazovm8KeyReleased
    int tamaño = tplazovm8.getText().length();
    if (tamaño > 0) {
        char c = tplazovm8.getText().charAt(tamaño - 1);
        if (!(c >= '0' && c <= '9')) {
            String str = tplazovm8.getText().substring(0, tamaño - 1);
            tplazovm8.setText(str);
        }
    }
}//GEN-LAST:event_tplazovm8KeyReleased

private void tplazovm9KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tplazovm9KeyReleased
    int tamaño = tplazovm9.getText().length();
    if (tamaño > 0) {
        char c = tplazovm9.getText().charAt(tamaño - 1);
        if (!(c >= '0' && c <= '9')) {
            String str = tplazovm9.getText().substring(0, tamaño - 1);
            tplazovm9.setText(str);
        }
    }
}//GEN-LAST:event_tplazovm9KeyReleased

private void tplazovm10KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tplazovm10KeyReleased
    int tamaño = tplazovm10.getText().length();
    if (tamaño > 0) {
        char c = tplazovm10.getText().charAt(tamaño - 1);
        if (!(c >= '0' && c <= '9')) {
            String str = tplazovm10.getText().substring(0, tamaño - 1);
            tplazovm10.setText(str);
        }
    }
}//GEN-LAST:event_tplazovm10KeyReleased

private void tplazopm1KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tplazopm1KeyReleased
    int tamaño = tplazopm1.getText().length();
    if (tamaño > 0) {
        char c = tplazopm1.getText().charAt(tamaño - 1);

        if (c == '.') {
            String contenidoAntiguo = tplazopm1.getText().replace(".", ",");
            tplazopm1.setText(contenidoAntiguo);
            c = ',';
        }

        if (!((c >= '0' && c <= '9') || c == ',')) {
            String str = tplazopm1.getText().substring(0, tamaño - 1);
            tplazopm1.setText(str);
        } else if (c == ',') {
            int indicePunto = tplazopm1.getText().indexOf(',');
            if (indicePunto != (tamaño - 1)) {
                String str = tplazopm1.getText().substring(0, tamaño - 1);
                tplazopm1.setText(str);
            }
        }
    }
}//GEN-LAST:event_tplazopm1KeyReleased

private void tplazopm2KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tplazopm2KeyReleased
    int tamaño = tplazopm2.getText().length();
    if (tamaño > 0) {
        char c = tplazopm2.getText().charAt(tamaño - 1);

        if (c == '.') {
            String contenidoAntiguo = tplazopm2.getText().replace(".", ",");
            tplazopm2.setText(contenidoAntiguo);
            c = ',';
        }

        if (!((c >= '0' && c <= '9') || c == ',')) {
            String str = tplazopm2.getText().substring(0, tamaño - 1);
            tplazopm2.setText(str);
        } else if (c == ',') {
            int indicePunto = tplazopm2.getText().indexOf(',');
            if (indicePunto != (tamaño - 1)) {
                String str = tplazopm2.getText().substring(0, tamaño - 1);
                tplazopm2.setText(str);
            }
        }
    }
}//GEN-LAST:event_tplazopm2KeyReleased

private void tplazopm3KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tplazopm3KeyReleased
    int tamaño = tplazopm3.getText().length();
    if (tamaño > 0) {
        char c = tplazopm3.getText().charAt(tamaño - 1);

        if (c == '.') {
            String contenidoAntiguo = tplazopm3.getText().replace(".", ",");
            tplazopm3.setText(contenidoAntiguo);
            c = ',';
        }

        if (!((c >= '0' && c <= '9') || c == ',')) {
            String str = tplazopm3.getText().substring(0, tamaño - 1);
            tplazopm3.setText(str);
        } else if (c == ',') {
            int indicePunto = tplazopm3.getText().indexOf(',');
            if (indicePunto != (tamaño - 1)) {
                String str = tplazopm3.getText().substring(0, tamaño - 1);
                tplazopm3.setText(str);
            }
        }
    }
}//GEN-LAST:event_tplazopm3KeyReleased

private void tplazopm4KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tplazopm4KeyReleased
    int tamaño = tplazopm4.getText().length();
    if (tamaño > 0) {
        char c = tplazopm4.getText().charAt(tamaño - 1);

        if (c == '.') {
            String contenidoAntiguo = tplazopm4.getText().replace(".", ",");
            tplazopm4.setText(contenidoAntiguo);
            c = ',';
        }

        if (!((c >= '0' && c <= '9') || c == ',')) {
            String str = tplazopm4.getText().substring(0, tamaño - 1);
            tplazopm4.setText(str);
        } else if (c == ',') {
            int indicePunto = tplazopm4.getText().indexOf(',');
            if (indicePunto != (tamaño - 1)) {
                String str = tplazopm4.getText().substring(0, tamaño - 1);
                tplazopm4.setText(str);
            }
        }
    }
}//GEN-LAST:event_tplazopm4KeyReleased

private void tplazopm5KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tplazopm5KeyReleased
    int tamaño = tplazopm5.getText().length();
    if (tamaño > 0) {
        char c = tplazopm5.getText().charAt(tamaño - 1);

        if (c == '.') {
            String contenidoAntiguo = tplazopm5.getText().replace(".", ",");
            tplazopm5.setText(contenidoAntiguo);
            c = ',';
        }

        if (!((c >= '0' && c <= '9') || c == ',')) {
            String str = tplazopm5.getText().substring(0, tamaño - 1);
            tplazopm5.setText(str);
        } else if (c == ',') {
            int indicePunto = tplazopm5.getText().indexOf(',');
            if (indicePunto != (tamaño - 1)) {
                String str = tplazopm5.getText().substring(0, tamaño - 1);
                tplazopm5.setText(str);
            }
        }
    }
}//GEN-LAST:event_tplazopm5KeyReleased

private void tplazopm6KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tplazopm6KeyReleased
    int tamaño = tplazopm6.getText().length();
    if (tamaño > 0) {
        char c = tplazopm6.getText().charAt(tamaño - 1);

        if (c == '.') {
            String contenidoAntiguo = tplazopm6.getText().replace(".", ",");
            tplazopm6.setText(contenidoAntiguo);
            c = ',';
        }

        if (!((c >= '0' && c <= '9') || c == ',')) {
            String str = tplazopm6.getText().substring(0, tamaño - 1);
            tplazopm6.setText(str);
        } else if (c == ',') {
            int indicePunto = tplazopm6.getText().indexOf(',');
            if (indicePunto != (tamaño - 1)) {
                String str = tplazopm6.getText().substring(0, tamaño - 1);
                tplazopm6.setText(str);
            }
        }
    }
}//GEN-LAST:event_tplazopm6KeyReleased

private void tplazopm7KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tplazopm7KeyReleased
    int tamaño = tplazopm7.getText().length();
    if (tamaño > 0) {
        char c = tplazopm7.getText().charAt(tamaño - 1);

        if (c == '.') {
            String contenidoAntiguo = tplazopm7.getText().replace(".", ",");
            tplazopm7.setText(contenidoAntiguo);
            c = ',';
        }

        if (!((c >= '0' && c <= '9') || c == ',')) {
            String str = tplazopm7.getText().substring(0, tamaño - 1);
            tplazopm7.setText(str);
        } else if (c == ',') {
            int indicePunto = tplazopm7.getText().indexOf(',');
            if (indicePunto != (tamaño - 1)) {
                String str = tplazopm7.getText().substring(0, tamaño - 1);
                tplazopm7.setText(str);
            }
        }
    }
}//GEN-LAST:event_tplazopm7KeyReleased

private void tplazopm8KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tplazopm8KeyReleased
    int tamaño = tplazopm8.getText().length();
    if (tamaño > 0) {
        char c = tplazopm8.getText().charAt(tamaño - 1);

        if (c == '.') {
            String contenidoAntiguo = tplazopm8.getText().replace(".", ",");
            tplazopm8.setText(contenidoAntiguo);
            c = ',';
        }

        if (!((c >= '0' && c <= '9') || c == ',')) {
            String str = tplazopm8.getText().substring(0, tamaño - 1);
            tplazopm8.setText(str);
        } else if (c == ',') {
            int indicePunto = tplazopm8.getText().indexOf(',');
            if (indicePunto != (tamaño - 1)) {
                String str = tplazopm8.getText().substring(0, tamaño - 1);
                tplazopm8.setText(str);
            }
        }
    }
}//GEN-LAST:event_tplazopm8KeyReleased

private void tplazopm9KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tplazopm9KeyReleased
    int tamaño = tplazopm9.getText().length();
    if (tamaño > 0) {
        char c = tplazopm9.getText().charAt(tamaño - 1);

        if (c == '.') {
            String contenidoAntiguo = tplazopm9.getText().replace(".", ",");
            tplazopm9.setText(contenidoAntiguo);
            c = ',';
        }

        if (!((c >= '0' && c <= '9') || c == ',')) {
            String str = tplazopm9.getText().substring(0, tamaño - 1);
            tplazopm9.setText(str);
        } else if (c == ',') {
            int indicePunto = tplazopm9.getText().indexOf(',');
            if (indicePunto != (tamaño - 1)) {
                String str = tplazopm9.getText().substring(0, tamaño - 1);
                tplazopm9.setText(str);
            }
        }
    }
}//GEN-LAST:event_tplazopm9KeyReleased

private void tplazopm10KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tplazopm10KeyReleased
    int tamaño = tplazopm10.getText().length();
    if (tamaño > 0) {
        char c = tplazopm10.getText().charAt(tamaño - 1);

        if (c == '.') {
            String contenidoAntiguo = tplazopm10.getText().replace(".", ",");
            tplazopm10.setText(contenidoAntiguo);
            c = ',';
        }

        if (!((c >= '0' && c <= '9') || c == ',')) {
            String str = tplazopm10.getText().substring(0, tamaño - 1);
            tplazopm10.setText(str);
        } else if (c == ',') {
            int indicePunto = tplazopm10.getText().indexOf(',');
            if (indicePunto != (tamaño - 1)) {
                String str = tplazopm10.getText().substring(0, tamaño - 1);
                tplazopm10.setText(str);
            }
        }
    }
}//GEN-LAST:event_tplazopm10KeyReleased

private void tdiasentreplazosKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tdiasentreplazosKeyReleased
    int tamaño = tdiasentreplazos.getText().length();
    if (tamaño > 0) {
        char c = tdiasentreplazos.getText().charAt(tamaño - 1);
        if (!(c >= '0' && c <= '9')) {
            String str = tdiasentreplazos.getText().substring(0, tamaño - 1);
            tdiasentreplazos.setText(str);
        }
    }
}//GEN-LAST:event_tdiasentreplazosKeyReleased

    private void porcentajesAutomaticos() {
        try {
            String resultado = "Resultado del cálculo: ";
            int numvto = Integer.valueOf((String) cvencimientosadelantados.getSelectedItem());
            if (bporcentajesautomaticos.isSelected()) {
                //Calculo automático pulsado
                vpago[0] = vpago[1] = vpago[2] = vpago[3] = vpago[4] = vpago[5] = vpago[6] = vpago[7] = vpago[8] = vpago[9] = 0;

                if (numvto > 0) {
                    int i;
                    float dtopp;
                    if (tdtopp.getText().equals("")) {
                        dtopp = 0;
                    } else {
                        dtopp = Float.valueOf(Util.convertirComaAPunto(tdtopp.getText()));
                    }

                    double dtovto = 100 - dtopp - calcularPorcentajesPago();
                    double dtoaux = 0;
                    double dto = matematico.Matematico.redondear2decimales((dtovto / numvto));
                    for (i = 1; i < numvto; i++) {
                        resultado += Util.convertirPuntoAComa(String.valueOf(dto)) + ", ";
                        vpago[i - 1] = dto;
                        dtoaux += dto;
                    }

                    vpago[i - 1] = matematico.Matematico.redondear2decimales(dtovto - dtoaux);
                    resultado += vpago[i - 1];
                    fp.setPlazopm1(vpago[0]);
                    fp.setPlazopm2(vpago[1]);
                    fp.setPlazopm3(vpago[2]);
                    fp.setPlazopm4(vpago[3]);
                    fp.setPlazopm5(vpago[4]);
                    fp.setPlazopm6(vpago[5]);
                    fp.setPlazopm7(vpago[6]);
                    fp.setPlazopm8(vpago[7]);
                    fp.setPlazopm9(vpago[8]);
                    fp.setPlazopm10(vpago[9]);
                }
                lresultadoporcentajes.setText(resultado);

                tplazopm1.setEnabled(false);
                tplazopm2.setEnabled(false);
                tplazopm3.setEnabled(false);
                tplazopm4.setEnabled(false);
                tplazopm5.setEnabled(false);
                tplazopm6.setEnabled(false);
                tplazopm7.setEnabled(false);
                tplazopm8.setEnabled(false);
                tplazopm9.setEnabled(false);
                tplazopm10.setEnabled(false);
                tplazopm1.setText("");
                tplazopm2.setText("");
                tplazopm3.setText("");
                tplazopm4.setText("");
                tplazopm5.setText("");
                tplazopm6.setText("");
                tplazopm7.setText("");
                tplazopm8.setText("");
                tplazopm9.setText("");
                tplazopm10.setText("");
            } else {
                lresultadoporcentajes.setText(resultado);
                actualizarPorcentajesVto(numvto);
                if (numvto == 0) {
                    tplazopm1.setEnabled(false);
                    tplazopm2.setEnabled(false);
                    tplazopm3.setEnabled(false);
                    tplazopm4.setEnabled(false);
                    tplazopm5.setEnabled(false);
                    tplazopm6.setEnabled(false);
                    tplazopm7.setEnabled(false);
                    tplazopm8.setEnabled(false);
                    tplazopm9.setEnabled(false);
                    tplazopm10.setEnabled(false);
                } else if (numvto == 1) {
                    tplazopm1.setEnabled(true);
                    tplazopm2.setEnabled(false);
                    tplazopm3.setEnabled(false);
                    tplazopm4.setEnabled(false);
                    tplazopm5.setEnabled(false);
                    tplazopm6.setEnabled(false);
                    tplazopm7.setEnabled(false);
                    tplazopm8.setEnabled(false);
                    tplazopm9.setEnabled(false);
                    tplazopm10.setEnabled(false);
                } else if (numvto == 2) {
                    tplazopm1.setEnabled(true);
                    tplazopm2.setEnabled(true);
                    tplazopm3.setEnabled(false);
                    tplazopm4.setEnabled(false);
                    tplazopm5.setEnabled(false);
                    tplazopm6.setEnabled(false);
                    tplazopm7.setEnabled(false);
                    tplazopm8.setEnabled(false);
                    tplazopm9.setEnabled(false);
                    tplazopm10.setEnabled(false);
                } else if (numvto == 3) {
                    tplazopm1.setEnabled(true);
                    tplazopm2.setEnabled(true);
                    tplazopm3.setEnabled(true);
                    tplazopm4.setEnabled(false);
                    tplazopm5.setEnabled(false);
                    tplazopm6.setEnabled(false);
                    tplazopm7.setEnabled(false);
                    tplazopm8.setEnabled(false);
                    tplazopm9.setEnabled(false);
                    tplazopm10.setEnabled(false);
                } else if (numvto == 4) {
                    tplazopm1.setEnabled(true);
                    tplazopm2.setEnabled(true);
                    tplazopm3.setEnabled(true);
                    tplazopm4.setEnabled(true);
                    tplazopm5.setEnabled(false);
                    tplazopm6.setEnabled(false);
                    tplazopm7.setEnabled(false);
                    tplazopm8.setEnabled(false);
                    tplazopm9.setEnabled(false);
                    tplazopm10.setEnabled(false);
                } else if (numvto == 5) {
                    tplazopm1.setEnabled(true);
                    tplazopm2.setEnabled(true);
                    tplazopm3.setEnabled(true);
                    tplazopm4.setEnabled(true);
                    tplazopm5.setEnabled(true);
                    tplazopm6.setEnabled(false);
                    tplazopm7.setEnabled(false);
                    tplazopm8.setEnabled(false);
                    tplazopm9.setEnabled(false);
                    tplazopm10.setEnabled(false);
                } else if (numvto == 6) {
                    tplazopm1.setEnabled(true);
                    tplazopm2.setEnabled(true);
                    tplazopm3.setEnabled(true);
                    tplazopm4.setEnabled(true);
                    tplazopm5.setEnabled(true);
                    tplazopm6.setEnabled(true);
                    tplazopm7.setEnabled(false);
                    tplazopm8.setEnabled(false);
                    tplazopm9.setEnabled(false);
                    tplazopm10.setEnabled(false);
                } else if (numvto == 7) {
                    tplazopm1.setEnabled(true);
                    tplazopm2.setEnabled(true);
                    tplazopm3.setEnabled(true);
                    tplazopm4.setEnabled(true);
                    tplazopm5.setEnabled(true);
                    tplazopm6.setEnabled(true);
                    tplazopm7.setEnabled(true);
                    tplazopm8.setEnabled(false);
                    tplazopm9.setEnabled(false);
                    tplazopm10.setEnabled(false);
                } else if (numvto == 8) {
                    tplazopm1.setEnabled(true);
                    tplazopm2.setEnabled(true);
                    tplazopm3.setEnabled(true);
                    tplazopm4.setEnabled(true);
                    tplazopm5.setEnabled(true);
                    tplazopm6.setEnabled(true);
                    tplazopm7.setEnabled(true);
                    tplazopm8.setEnabled(true);
                    tplazopm9.setEnabled(false);
                    tplazopm10.setEnabled(false);
                } else if (numvto == 9) {
                    tplazopm1.setEnabled(true);
                    tplazopm2.setEnabled(true);
                    tplazopm3.setEnabled(true);
                    tplazopm4.setEnabled(true);
                    tplazopm5.setEnabled(true);
                    tplazopm6.setEnabled(true);
                    tplazopm7.setEnabled(true);
                    tplazopm8.setEnabled(true);
                    tplazopm9.setEnabled(true);
                    tplazopm10.setEnabled(false);
                } else if (numvto == 10) {
                    tplazopm1.setEnabled(true);
                    tplazopm2.setEnabled(true);
                    tplazopm3.setEnabled(true);
                    tplazopm4.setEnabled(true);
                    tplazopm5.setEnabled(true);
                    tplazopm6.setEnabled(true);
                    tplazopm7.setEnabled(true);
                    tplazopm8.setEnabled(true);
                    tplazopm9.setEnabled(true);
                    tplazopm10.setEnabled(true);
                }
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error, los campos numéricos deben ser números", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private double calcularPorcentajeVencimiento() {
        if (!this.bporcentajesautomaticos.isSelected()) {
            vpago[0] = vpago[1] = vpago[2] = vpago[3] = vpago[4] = vpago[5] = vpago[6] = vpago[7] = vpago[8] = vpago[9] = 0;

            if (tplazopm1.getText().length() != 0) {
                vpago[0] = Float.parseFloat(Util.convertirComaAPunto(tplazopm1.getText()));
                fp.setPlazopm1(vpago[0]);
            }
            if (tplazopm2.getText().length() != 0) {
                vpago[1] = Float.parseFloat(Util.convertirComaAPunto(tplazopm2.getText()));
                fp.setPlazopm2(vpago[1]);
            }
            if (tplazopm3.getText().length() != 0) {
                vpago[2] = Float.parseFloat(Util.convertirComaAPunto(tplazopm3.getText()));
                fp.setPlazopm3(vpago[2]);
            }
            if (tplazopm4.getText().length() != 0) {
                vpago[3] = Float.parseFloat(Util.convertirComaAPunto(tplazopm4.getText()));
                fp.setPlazopm4(vpago[3]);
            }
            if (tplazopm5.getText().length() != 0) {
                vpago[4] = Float.parseFloat(Util.convertirComaAPunto(tplazopm5.getText()));
                fp.setPlazopm5(vpago[4]);
            }
            if (tplazopm6.getText().length() != 0) {
                vpago[5] = Float.parseFloat(Util.convertirComaAPunto(tplazopm6.getText()));
                fp.setPlazopm6(vpago[5]);
            }
            if (tplazopm7.getText().length() != 0) {
                vpago[6] = Float.parseFloat(Util.convertirComaAPunto(tplazopm7.getText()));
                fp.setPlazopm7(vpago[6]);
            }
            if (tplazopm8.getText().length() != 0) {
                vpago[7] = Float.parseFloat(Util.convertirComaAPunto(tplazopm8.getText()));
                fp.setPlazopm8(vpago[7]);
            }
            if (tplazopm9.getText().length() != 0) {
                vpago[8] = Float.parseFloat(Util.convertirComaAPunto(tplazopm9.getText()));
                fp.setPlazopm9(vpago[8]);
            }
            if (tplazopm10.getText().length() != 0) {
                vpago[9] = Float.parseFloat(Util.convertirComaAPunto(tplazopm10.getText()));
                fp.setPlazopm10(vpago[9]);
            }
        }
        return vpago[0] + vpago[1] + vpago[2] + vpago[3] + vpago[4] + vpago[5] + vpago[6] + vpago[7] + vpago[8] + vpago[9];
    }

    private double calcularPorcentajesPago() {
        ppago[0] = ppago[1] = ppago[2] = ppago[3] = ppago[4] = ppago[5] = ppago[6] = ppago[7] = ppago[8] = ppago[9] = 0;

        if (tporcentajepago1.getText().length() != 0) {
            ppago[0] = Float.parseFloat(Util.convertirComaAPunto(tporcentajepago1.getText()));
            fp.setPorcentajepago1(ppago[0]);
        }
        if (tporcentajepago2.getText().length() != 0) {
            ppago[1] = Float.parseFloat(Util.convertirComaAPunto(tporcentajepago2.getText()));
            fp.setPorcentajepago2(ppago[1]);
        }
        if (tporcentajepago3.getText().length() != 0) {
            ppago[2] = Float.parseFloat(Util.convertirComaAPunto(tporcentajepago3.getText()));
            fp.setPorcentajepago3(ppago[2]);
        }
        if (tporcentajepago4.getText().length() != 0) {
            ppago[3] = Float.parseFloat(Util.convertirComaAPunto(tporcentajepago4.getText()));
            fp.setPorcentajepago4(ppago[3]);
        }
        if (tporcentajepago5.getText().length() != 0) {
            ppago[4] = Float.parseFloat(Util.convertirComaAPunto(tporcentajepago5.getText()));
            fp.setPorcentajepago5(ppago[4]);
        }
        if (tporcentajepago7.getText().length() != 0) {
            ppago[5] = Float.parseFloat(Util.convertirComaAPunto(tporcentajepago7.getText()));
            fp.setPorcentajepago6(ppago[5]);
        }
        if (tporcentajepago6.getText().length() != 0) {
            ppago[6] = Float.parseFloat(Util.convertirComaAPunto(tporcentajepago6.getText()));
            fp.setPorcentajepago7(ppago[6]);
        }
        if (tporcentajepago8.getText().length() != 0) {
            ppago[7] = Float.parseFloat(Util.convertirComaAPunto(tporcentajepago8.getText()));
            fp.setPorcentajepago8(ppago[7]);
        }
        if (tporcentajepago9.getText().length() != 0) {
            ppago[8] = Float.parseFloat(Util.convertirComaAPunto(tporcentajepago9.getText()));
            fp.setPorcentajepago9(ppago[8]);
        }
        if (tporcentajepago10.getText().length() != 0) {
            ppago[9] = Float.parseFloat(Util.convertirComaAPunto(tporcentajepago10.getText()));
            fp.setPorcentajepago10(ppago[9]);
        }

        return ppago[0] + ppago[1] + ppago[2] + ppago[3] + ppago[4] + ppago[5] + ppago[6] + ppago[7] + ppago[8] + ppago[9];
    }

    private boolean calcularPlazosVencimiento() {
        int numv, check, check2;
        plazo[0] = plazo[1] = plazo[2] = plazo[3] = plazo[4] = plazo[5] = plazo[6] = plazo[7] = plazo[8] = plazo[9] = 0;
        check = 0;

        if (tplazovm1.getText().length() != 0) {
            plazo[0] = Integer.parseInt(tplazovm1.getText());
            fp.setPlazovm1(plazo[0]);
            check += 1;
        }
        if (tplazovm2.getText().length() != 0) {
            plazo[1] = Integer.parseInt(tplazovm2.getText());
            fp.setPlazovm2(plazo[1]);
            check += 2;
        }
        if (tplazovm3.getText().length() != 0) {
            plazo[2] = Integer.parseInt(tplazovm3.getText());
            fp.setPlazovm3(plazo[2]);
            check += 3;
        }
        if (tplazovm4.getText().length() != 0) {
            plazo[3] = Integer.parseInt(tplazovm4.getText());
            fp.setPlazovm4(plazo[3]);
            check += 4;
        }
        if (tplazovm5.getText().length() != 0) {
            plazo[4] = Integer.parseInt(tplazovm5.getText());
            fp.setPlazovm5(plazo[4]);
            check += 5;
        }
        if (tplazovm6.getText().length() != 0) {
            plazo[5] = Integer.parseInt(tplazovm6.getText());
            fp.setPlazovm6(plazo[5]);
            check += 6;
        }
        if (tplazovm7.getText().length() != 0) {
            plazo[6] = Integer.parseInt(tplazovm7.getText());
            fp.setPlazovm7(plazo[6]);
            check += 7;
        }
        if (tplazovm8.getText().length() != 0) {
            plazo[7] = Integer.parseInt(tplazovm9.getText());
            fp.setPlazovm8(plazo[7]);
            check += 8;
        }
        if (tplazovm9.getText().length() != 0) {
            plazo[8] = Integer.parseInt(tplazovm9.getText());
            fp.setPlazovm9(plazo[8]);
            check += 9;
        }
        if (tplazovm10.getText().length() != 0) {
            plazo[9] = Integer.parseInt(tplazovm10.getText());
            fp.setPlazovm10(plazo[9]);
            check += 10;
        }

        check2 = 0;
        numv = fp.getNumplazosvencimiento();
        for (int i = 0; i <= numv; i++) {
            check2 += i;
        }

        return check == check2;
    }

    private void habilitarPorcentajesManuales(boolean habilitar) {
        int numVencimientos = Integer.valueOf((String) cvencimientosadelantados.getSelectedItem());

        if (numVencimientos == 0) {
            tplazopm1.setEnabled(false);
            tplazopm2.setEnabled(false);
            tplazopm3.setEnabled(false);
            tplazopm4.setEnabled(false);
            tplazopm5.setEnabled(false);
            tplazopm6.setEnabled(false);
            tplazopm7.setEnabled(false);
            tplazopm8.setEnabled(false);
            tplazopm9.setEnabled(false);
            tplazopm10.setEnabled(false);
        } else if (numVencimientos == 1) {
            tplazopm1.setEnabled(habilitar);
            tplazopm2.setEnabled(false);
            tplazopm3.setEnabled(false);
            tplazopm4.setEnabled(false);
            tplazopm5.setEnabled(false);
            tplazopm6.setEnabled(false);
            tplazopm7.setEnabled(false);
            tplazopm8.setEnabled(false);
            tplazopm9.setEnabled(false);
            tplazopm10.setEnabled(false);
        } else if (numVencimientos == 2) {
            tplazopm1.setEnabled(habilitar);
            tplazopm2.setEnabled(habilitar);
            tplazopm3.setEnabled(false);
            tplazopm4.setEnabled(false);
            tplazopm5.setEnabled(false);
            tplazopm6.setEnabled(false);
            tplazopm7.setEnabled(false);
            tplazopm8.setEnabled(false);
            tplazopm9.setEnabled(false);
            tplazopm10.setEnabled(false);
        } else if (numVencimientos == 3) {
            tplazopm1.setEnabled(habilitar);
            tplazopm2.setEnabled(habilitar);
            tplazopm3.setEnabled(habilitar);
            tplazopm4.setEnabled(false);
            tplazopm5.setEnabled(false);
            tplazopm6.setEnabled(false);
            tplazopm7.setEnabled(false);
            tplazopm8.setEnabled(false);
            tplazopm9.setEnabled(false);
            tplazopm10.setEnabled(false);
        } else if (numVencimientos == 4) {
            tplazopm1.setEnabled(habilitar);
            tplazopm2.setEnabled(habilitar);
            tplazopm3.setEnabled(habilitar);
            tplazopm4.setEnabled(habilitar);
            tplazopm5.setEnabled(false);
            tplazopm6.setEnabled(false);
            tplazopm7.setEnabled(false);
            tplazopm8.setEnabled(false);
            tplazopm9.setEnabled(false);
            tplazopm10.setEnabled(false);
        } else if (numVencimientos == 5) {
            tplazopm1.setEnabled(habilitar);
            tplazopm2.setEnabled(habilitar);
            tplazopm3.setEnabled(habilitar);
            tplazopm4.setEnabled(habilitar);
            tplazopm5.setEnabled(habilitar);
            tplazopm6.setEnabled(false);
            tplazopm7.setEnabled(false);
            tplazopm8.setEnabled(false);
            tplazopm9.setEnabled(false);
            tplazopm10.setEnabled(false);
        } else if (numVencimientos == 6) {
            tplazopm1.setEnabled(habilitar);
            tplazopm2.setEnabled(habilitar);
            tplazopm3.setEnabled(habilitar);
            tplazopm4.setEnabled(habilitar);
            tplazopm5.setEnabled(habilitar);
            tplazopm6.setEnabled(habilitar);
            tplazopm7.setEnabled(false);
            tplazopm8.setEnabled(false);
            tplazopm9.setEnabled(false);
            tplazopm10.setEnabled(false);
        } else if (numVencimientos == 7) {
            tplazopm1.setEnabled(habilitar);
            tplazopm2.setEnabled(habilitar);
            tplazopm3.setEnabled(habilitar);
            tplazopm4.setEnabled(habilitar);
            tplazopm5.setEnabled(habilitar);
            tplazopm6.setEnabled(habilitar);
            tplazopm7.setEnabled(habilitar);
            tplazopm8.setEnabled(false);
            tplazopm9.setEnabled(false);
            tplazopm10.setEnabled(false);
        } else if (numVencimientos == 8) {
            tplazopm1.setEnabled(habilitar);
            tplazopm2.setEnabled(habilitar);
            tplazopm3.setEnabled(habilitar);
            tplazopm4.setEnabled(habilitar);
            tplazopm5.setEnabled(habilitar);
            tplazopm6.setEnabled(habilitar);
            tplazopm7.setEnabled(habilitar);
            tplazopm8.setEnabled(habilitar);
            tplazopm9.setEnabled(false);
            tplazopm10.setEnabled(false);
        } else if (numVencimientos == 9) {
            tplazopm1.setEnabled(habilitar);
            tplazopm2.setEnabled(habilitar);
            tplazopm3.setEnabled(habilitar);
            tplazopm4.setEnabled(habilitar);
            tplazopm5.setEnabled(habilitar);
            tplazopm6.setEnabled(habilitar);
            tplazopm7.setEnabled(habilitar);
            tplazopm8.setEnabled(habilitar);
            tplazopm9.setEnabled(habilitar);
            tplazopm10.setEnabled(false);
        } else if (numVencimientos == 10) {
            tplazopm1.setEnabled(habilitar);
            tplazopm2.setEnabled(habilitar);
            tplazopm3.setEnabled(habilitar);
            tplazopm4.setEnabled(habilitar);
            tplazopm5.setEnabled(habilitar);
            tplazopm6.setEnabled(habilitar);
            tplazopm7.setEnabled(habilitar);
            tplazopm8.setEnabled(habilitar);
            tplazopm9.setEnabled(habilitar);
            tplazopm10.setEnabled(habilitar);
        }
    }

    private void habilitarVencimientosManuales(boolean habilitar) {
        int numVencimientos = Integer.valueOf((String) cvencimientosadelantados.getSelectedItem());

        if (numVencimientos == 0) {
            tplazovm1.setEnabled(false);
            tplazovm2.setEnabled(false);
            tplazovm3.setEnabled(false);
            tplazovm4.setEnabled(false);
            tplazovm5.setEnabled(false);
            tplazovm6.setEnabled(false);
            tplazovm7.setEnabled(false);
            tplazovm8.setEnabled(false);
            tplazovm9.setEnabled(false);
            tplazovm10.setEnabled(false);
        } else if (numVencimientos == 1) {
            tplazovm1.setEnabled(habilitar);
            tplazovm2.setEnabled(false);
            tplazovm3.setEnabled(false);
            tplazovm4.setEnabled(false);
            tplazovm5.setEnabled(false);
            tplazovm6.setEnabled(false);
            tplazovm7.setEnabled(false);
            tplazovm8.setEnabled(false);
            tplazovm9.setEnabled(false);
            tplazovm10.setEnabled(false);
        } else if (numVencimientos == 2) {
            tplazovm1.setEnabled(habilitar);
            tplazovm2.setEnabled(habilitar);
            tplazovm3.setEnabled(false);
            tplazovm4.setEnabled(false);
            tplazovm5.setEnabled(false);
            tplazovm6.setEnabled(false);
            tplazovm7.setEnabled(false);
            tplazovm8.setEnabled(false);
            tplazovm9.setEnabled(false);
            tplazovm10.setEnabled(false);
        } else if (numVencimientos == 3) {
            tplazovm1.setEnabled(habilitar);
            tplazovm2.setEnabled(habilitar);
            tplazovm3.setEnabled(habilitar);
            tplazovm4.setEnabled(false);
            tplazovm5.setEnabled(false);
            tplazovm6.setEnabled(false);
            tplazovm7.setEnabled(false);
            tplazovm8.setEnabled(false);
            tplazovm9.setEnabled(false);
            tplazovm10.setEnabled(false);
        } else if (numVencimientos == 4) {
            tplazovm1.setEnabled(habilitar);
            tplazovm2.setEnabled(habilitar);
            tplazovm3.setEnabled(habilitar);
            tplazovm4.setEnabled(habilitar);
            tplazovm5.setEnabled(false);
            tplazovm6.setEnabled(false);
            tplazovm7.setEnabled(false);
            tplazovm8.setEnabled(false);
            tplazovm9.setEnabled(false);
            tplazovm10.setEnabled(false);
        } else if (numVencimientos == 5) {
            tplazovm1.setEnabled(habilitar);
            tplazovm2.setEnabled(habilitar);
            tplazovm3.setEnabled(habilitar);
            tplazovm4.setEnabled(habilitar);
            tplazovm5.setEnabled(habilitar);
            tplazovm6.setEnabled(false);
            tplazovm7.setEnabled(false);
            tplazovm8.setEnabled(false);
            tplazovm9.setEnabled(false);
            tplazovm10.setEnabled(false);
        } else if (numVencimientos == 6) {
            tplazovm1.setEnabled(habilitar);
            tplazovm2.setEnabled(habilitar);
            tplazovm3.setEnabled(habilitar);
            tplazovm4.setEnabled(habilitar);
            tplazovm5.setEnabled(habilitar);
            tplazovm6.setEnabled(habilitar);
            tplazovm7.setEnabled(false);
            tplazovm8.setEnabled(false);
            tplazovm9.setEnabled(false);
            tplazovm10.setEnabled(false);
        } else if (numVencimientos == 7) {
            tplazovm1.setEnabled(habilitar);
            tplazovm2.setEnabled(habilitar);
            tplazovm3.setEnabled(habilitar);
            tplazovm4.setEnabled(habilitar);
            tplazovm5.setEnabled(habilitar);
            tplazovm6.setEnabled(habilitar);
            tplazovm7.setEnabled(habilitar);
            tplazovm8.setEnabled(false);
            tplazovm9.setEnabled(false);
            tplazovm10.setEnabled(false);
        } else if (numVencimientos == 8) {
            tplazovm1.setEnabled(habilitar);
            tplazovm2.setEnabled(habilitar);
            tplazovm3.setEnabled(habilitar);
            tplazovm4.setEnabled(habilitar);
            tplazovm5.setEnabled(habilitar);
            tplazovm6.setEnabled(habilitar);
            tplazovm7.setEnabled(habilitar);
            tplazovm8.setEnabled(habilitar);
            tplazovm9.setEnabled(false);
            tplazovm10.setEnabled(false);
        } else if (numVencimientos == 9) {
            tplazovm1.setEnabled(habilitar);
            tplazovm2.setEnabled(habilitar);
            tplazovm3.setEnabled(habilitar);
            tplazovm4.setEnabled(habilitar);
            tplazovm5.setEnabled(habilitar);
            tplazovm6.setEnabled(habilitar);
            tplazovm7.setEnabled(habilitar);
            tplazovm8.setEnabled(habilitar);
            tplazovm9.setEnabled(habilitar);
            tplazovm10.setEnabled(false);
        } else if (numVencimientos == 10) {
            tplazovm1.setEnabled(habilitar);
            tplazovm2.setEnabled(habilitar);
            tplazovm3.setEnabled(habilitar);
            tplazovm4.setEnabled(habilitar);
            tplazovm5.setEnabled(habilitar);
            tplazovm6.setEnabled(habilitar);
            tplazovm7.setEnabled(habilitar);
            tplazovm8.setEnabled(habilitar);
            tplazovm9.setEnabled(habilitar);
            tplazovm10.setEnabled(habilitar);
        }
    }

    private void habilitarPagos(boolean habilitar) {
        int numPagos = Integer.valueOf((String) cplazospagoadelantados.getSelectedItem());

        if (numPagos == 0) {
            tplazopago1.setEnabled(false);
            tplazopago2.setEnabled(false);
            tplazopago3.setEnabled(false);
            tplazopago4.setEnabled(false);
            tplazopago5.setEnabled(false);
            tplazopago6.setEnabled(false);
            tplazopago7.setEnabled(false);
            tplazopago8.setEnabled(false);
            tplazopago9.setEnabled(false);
            tplazopago10.setEnabled(false);
            tporcentajepago1.setEnabled(false);
            tporcentajepago2.setEnabled(false);
            tporcentajepago3.setEnabled(false);
            tporcentajepago4.setEnabled(false);
            tporcentajepago5.setEnabled(false);
            tporcentajepago7.setEnabled(false);
            tporcentajepago6.setEnabled(false);
            tporcentajepago8.setEnabled(false);
            tporcentajepago9.setEnabled(false);
            tporcentajepago10.setEnabled(false);
        } else if (numPagos == 1) {
            tplazopago1.setEnabled(habilitar);
            tplazopago2.setEnabled(false);
            tplazopago3.setEnabled(false);
            tplazopago4.setEnabled(false);
            tplazopago5.setEnabled(false);
            tplazopago6.setEnabled(false);
            tplazopago7.setEnabled(false);
            tplazopago8.setEnabled(false);
            tplazopago9.setEnabled(false);
            tplazopago10.setEnabled(false);
            tporcentajepago1.setEnabled(habilitar);
            tporcentajepago2.setEnabled(false);
            tporcentajepago3.setEnabled(false);
            tporcentajepago4.setEnabled(false);
            tporcentajepago5.setEnabled(false);
            tporcentajepago7.setEnabled(false);
            tporcentajepago6.setEnabled(false);
            tporcentajepago8.setEnabled(false);
            tporcentajepago9.setEnabled(false);
            tporcentajepago10.setEnabled(false);
        }
        if (numPagos == 2) {
            tplazopago1.setEnabled(habilitar);
            tplazopago2.setEnabled(habilitar);
            tplazopago3.setEnabled(false);
            tplazopago4.setEnabled(false);
            tplazopago5.setEnabled(false);
            tplazopago6.setEnabled(false);
            tplazopago7.setEnabled(false);
            tplazopago8.setEnabled(false);
            tplazopago9.setEnabled(false);
            tplazopago10.setEnabled(false);
            tporcentajepago1.setEnabled(habilitar);
            tporcentajepago2.setEnabled(habilitar);
            tporcentajepago3.setEnabled(false);
            tporcentajepago4.setEnabled(false);
            tporcentajepago5.setEnabled(false);
            tporcentajepago7.setEnabled(false);
            tporcentajepago6.setEnabled(false);
            tporcentajepago8.setEnabled(false);
            tporcentajepago9.setEnabled(false);
            tporcentajepago10.setEnabled(false);
        }
        if (numPagos == 3) {
            tplazopago1.setEnabled(habilitar);
            tplazopago2.setEnabled(habilitar);
            tplazopago3.setEnabled(habilitar);
            tplazopago4.setEnabled(false);
            tplazopago5.setEnabled(false);
            tplazopago6.setEnabled(false);
            tplazopago7.setEnabled(false);
            tplazopago8.setEnabled(false);
            tplazopago9.setEnabled(false);
            tplazopago10.setEnabled(false);
            tporcentajepago1.setEnabled(habilitar);
            tporcentajepago2.setEnabled(habilitar);
            tporcentajepago3.setEnabled(habilitar);
            tporcentajepago4.setEnabled(false);
            tporcentajepago5.setEnabled(false);
            tporcentajepago7.setEnabled(false);
            tporcentajepago6.setEnabled(false);
            tporcentajepago8.setEnabled(false);
            tporcentajepago9.setEnabled(false);
            tporcentajepago10.setEnabled(false);
        }
        if (numPagos == 4) {
            tplazopago1.setEnabled(habilitar);
            tplazopago2.setEnabled(habilitar);
            tplazopago3.setEnabled(habilitar);
            tplazopago4.setEnabled(habilitar);
            tplazopago5.setEnabled(false);
            tplazopago6.setEnabled(false);
            tplazopago7.setEnabled(false);
            tplazopago8.setEnabled(false);
            tplazopago9.setEnabled(false);
            tplazopago10.setEnabled(false);
            tporcentajepago1.setEnabled(habilitar);
            tporcentajepago2.setEnabled(habilitar);
            tporcentajepago3.setEnabled(habilitar);
            tporcentajepago4.setEnabled(habilitar);
            tporcentajepago5.setEnabled(false);
            tporcentajepago7.setEnabled(false);
            tporcentajepago6.setEnabled(false);
            tporcentajepago8.setEnabled(false);
            tporcentajepago9.setEnabled(false);
            tporcentajepago10.setEnabled(false);
        }
        if (numPagos == 5) {
            tplazopago1.setEnabled(habilitar);
            tplazopago2.setEnabled(habilitar);
            tplazopago3.setEnabled(habilitar);
            tplazopago4.setEnabled(habilitar);
            tplazopago5.setEnabled(habilitar);
            tplazopago6.setEnabled(false);
            tplazopago7.setEnabled(false);
            tplazopago8.setEnabled(false);
            tplazopago9.setEnabled(false);
            tplazopago10.setEnabled(false);
            tporcentajepago1.setEnabled(habilitar);
            tporcentajepago2.setEnabled(habilitar);
            tporcentajepago3.setEnabled(habilitar);
            tporcentajepago4.setEnabled(habilitar);
            tporcentajepago5.setEnabled(habilitar);
            tporcentajepago7.setEnabled(false);
            tporcentajepago6.setEnabled(false);
            tporcentajepago8.setEnabled(false);
            tporcentajepago9.setEnabled(false);
            tporcentajepago10.setEnabled(false);
        }
        if (numPagos == 6) {
            tplazopago1.setEnabled(habilitar);
            tplazopago2.setEnabled(habilitar);
            tplazopago3.setEnabled(habilitar);
            tplazopago4.setEnabled(habilitar);
            tplazopago5.setEnabled(habilitar);
            tplazopago6.setEnabled(habilitar);
            tplazopago7.setEnabled(false);
            tplazopago8.setEnabled(false);
            tplazopago9.setEnabled(false);
            tplazopago10.setEnabled(false);
            tporcentajepago1.setEnabled(habilitar);
            tporcentajepago2.setEnabled(habilitar);
            tporcentajepago3.setEnabled(habilitar);
            tporcentajepago4.setEnabled(habilitar);
            tporcentajepago5.setEnabled(habilitar);
            tporcentajepago6.setEnabled(habilitar);
            tporcentajepago7.setEnabled(false);
            tporcentajepago8.setEnabled(false);
            tporcentajepago9.setEnabled(false);
            tporcentajepago10.setEnabled(false);
        }
        if (numPagos == 7) {
            tplazopago1.setEnabled(habilitar);
            tplazopago2.setEnabled(habilitar);
            tplazopago3.setEnabled(habilitar);
            tplazopago4.setEnabled(habilitar);
            tplazopago5.setEnabled(habilitar);
            tplazopago6.setEnabled(habilitar);
            tplazopago7.setEnabled(habilitar);
            tplazopago8.setEnabled(false);
            tplazopago9.setEnabled(false);
            tplazopago10.setEnabled(false);
            tporcentajepago1.setEnabled(habilitar);
            tporcentajepago2.setEnabled(habilitar);
            tporcentajepago3.setEnabled(habilitar);
            tporcentajepago4.setEnabled(habilitar);
            tporcentajepago5.setEnabled(habilitar);
            tporcentajepago7.setEnabled(habilitar);
            tporcentajepago6.setEnabled(habilitar);
            tporcentajepago8.setEnabled(false);
            tporcentajepago9.setEnabled(false);
            tporcentajepago10.setEnabled(false);
        }
        if (numPagos == 8) {
            tplazopago1.setEnabled(habilitar);
            tplazopago2.setEnabled(habilitar);
            tplazopago3.setEnabled(habilitar);
            tplazopago4.setEnabled(habilitar);
            tplazopago5.setEnabled(habilitar);
            tplazopago6.setEnabled(habilitar);
            tplazopago7.setEnabled(habilitar);
            tplazopago8.setEnabled(habilitar);
            tplazopago9.setEnabled(false);
            tplazopago10.setEnabled(false);
            tporcentajepago1.setEnabled(habilitar);
            tporcentajepago2.setEnabled(habilitar);
            tporcentajepago3.setEnabled(habilitar);
            tporcentajepago4.setEnabled(habilitar);
            tporcentajepago5.setEnabled(habilitar);
            tporcentajepago7.setEnabled(habilitar);
            tporcentajepago6.setEnabled(habilitar);
            tporcentajepago8.setEnabled(habilitar);
            tporcentajepago9.setEnabled(false);
            tporcentajepago10.setEnabled(false);
        }
        if (numPagos == 9) {
            tplazopago1.setEnabled(habilitar);
            tplazopago2.setEnabled(habilitar);
            tplazopago3.setEnabled(habilitar);
            tplazopago4.setEnabled(habilitar);
            tplazopago5.setEnabled(habilitar);
            tplazopago6.setEnabled(habilitar);
            tplazopago7.setEnabled(habilitar);
            tplazopago8.setEnabled(habilitar);
            tplazopago9.setEnabled(habilitar);
            tplazopago10.setEnabled(false);
            tporcentajepago1.setEnabled(habilitar);
            tporcentajepago2.setEnabled(habilitar);
            tporcentajepago3.setEnabled(habilitar);
            tporcentajepago4.setEnabled(habilitar);
            tporcentajepago5.setEnabled(habilitar);
            tporcentajepago7.setEnabled(habilitar);
            tporcentajepago6.setEnabled(habilitar);
            tporcentajepago8.setEnabled(habilitar);
            tporcentajepago9.setEnabled(habilitar);
            tporcentajepago10.setEnabled(false);
        }
        if (numPagos == 10) {
            tplazopago1.setEnabled(habilitar);
            tplazopago2.setEnabled(habilitar);
            tplazopago3.setEnabled(habilitar);
            tplazopago4.setEnabled(habilitar);
            tplazopago5.setEnabled(habilitar);
            tplazopago6.setEnabled(habilitar);
            tplazopago7.setEnabled(habilitar);
            tplazopago8.setEnabled(habilitar);
            tplazopago9.setEnabled(habilitar);
            tplazopago10.setEnabled(habilitar);
            tporcentajepago1.setEnabled(habilitar);
            tporcentajepago2.setEnabled(habilitar);
            tporcentajepago3.setEnabled(habilitar);
            tporcentajepago4.setEnabled(habilitar);
            tporcentajepago5.setEnabled(habilitar);
            tporcentajepago7.setEnabled(habilitar);
            tporcentajepago6.setEnabled(habilitar);
            tporcentajepago8.setEnabled(habilitar);
            tporcentajepago9.setEnabled(habilitar);
            tporcentajepago10.setEnabled(habilitar);
        }
    }

    private void actualizarPagos(int num) {
        tporcentajepago1.setText("");
        tporcentajepago2.setText("");
        tporcentajepago3.setText("");
        tporcentajepago4.setText("");
        tporcentajepago5.setText("");
        tporcentajepago7.setText("");
        tporcentajepago6.setText("");
        tporcentajepago8.setText("");
        tporcentajepago9.setText("");
        tporcentajepago10.setText("");
        tplazopago1.setText("");
        tplazopago2.setText("");
        tplazopago3.setText("");
        tplazopago4.setText("");
        tplazopago5.setText("");
        tplazopago6.setText("");
        tplazopago7.setText("");
        tplazopago8.setText("");
        tplazopago9.setText("");
        tplazopago10.setText("");

        if (num == 0) {
            tplazopago1.setEnabled(false);
            tplazopago2.setEnabled(false);
            tplazopago3.setEnabled(false);
            tplazopago4.setEnabled(false);
            tplazopago5.setEnabled(false);
            tplazopago6.setEnabled(false);
            tplazopago7.setEnabled(false);
            tplazopago8.setEnabled(false);
            tplazopago9.setEnabled(false);
            tplazopago10.setEnabled(false);
            tporcentajepago1.setEnabled(false);
            tporcentajepago2.setEnabled(false);
            tporcentajepago3.setEnabled(false);
            tporcentajepago4.setEnabled(false);
            tporcentajepago5.setEnabled(false);
            tporcentajepago7.setEnabled(false);
            tporcentajepago6.setEnabled(false);
            tporcentajepago8.setEnabled(false);
            tporcentajepago9.setEnabled(false);
            tporcentajepago10.setEnabled(false);
        } else if (num == 1) {
            tplazopago1.setEnabled(true);
            tplazopago2.setEnabled(false);
            tplazopago3.setEnabled(false);
            tplazopago4.setEnabled(false);
            tplazopago5.setEnabled(false);
            tplazopago6.setEnabled(false);
            tplazopago7.setEnabled(false);
            tplazopago8.setEnabled(false);
            tplazopago9.setEnabled(false);
            tplazopago10.setEnabled(false);
            tporcentajepago1.setEnabled(true);
            tporcentajepago2.setEnabled(false);
            tporcentajepago3.setEnabled(false);
            tporcentajepago4.setEnabled(false);
            tporcentajepago5.setEnabled(false);
            tporcentajepago7.setEnabled(false);
            tporcentajepago6.setEnabled(false);
            tporcentajepago8.setEnabled(false);
            tporcentajepago9.setEnabled(false);
            tporcentajepago10.setEnabled(false);
        }
        if (num == 2) {
            tplazopago1.setEnabled(true);
            tplazopago2.setEnabled(true);
            tplazopago3.setEnabled(false);
            tplazopago4.setEnabled(false);
            tplazopago5.setEnabled(false);
            tplazopago6.setEnabled(false);
            tplazopago7.setEnabled(false);
            tplazopago8.setEnabled(false);
            tplazopago9.setEnabled(false);
            tplazopago10.setEnabled(false);
            tporcentajepago1.setEnabled(true);
            tporcentajepago2.setEnabled(true);
            tporcentajepago3.setEnabled(false);
            tporcentajepago4.setEnabled(false);
            tporcentajepago5.setEnabled(false);
            tporcentajepago7.setEnabled(false);
            tporcentajepago6.setEnabled(false);
            tporcentajepago8.setEnabled(false);
            tporcentajepago9.setEnabled(false);
            tporcentajepago10.setEnabled(false);
        }
        if (num == 3) {
            tplazopago1.setEnabled(true);
            tplazopago2.setEnabled(true);
            tplazopago3.setEnabled(true);
            tplazopago4.setEnabled(false);
            tplazopago5.setEnabled(false);
            tplazopago6.setEnabled(false);
            tplazopago7.setEnabled(false);
            tplazopago8.setEnabled(false);
            tplazopago9.setEnabled(false);
            tplazopago10.setEnabled(false);
            tporcentajepago1.setEnabled(true);
            tporcentajepago2.setEnabled(true);
            tporcentajepago3.setEnabled(true);
            tporcentajepago4.setEnabled(false);
            tporcentajepago5.setEnabled(false);
            tporcentajepago7.setEnabled(false);
            tporcentajepago6.setEnabled(false);
            tporcentajepago8.setEnabled(false);
            tporcentajepago9.setEnabled(false);
            tporcentajepago10.setEnabled(false);
        }
        if (num == 4) {
            tplazopago1.setEnabled(true);
            tplazopago2.setEnabled(true);
            tplazopago3.setEnabled(true);
            tplazopago4.setEnabled(true);
            tplazopago5.setEnabled(false);
            tplazopago6.setEnabled(false);
            tplazopago7.setEnabled(false);
            tplazopago8.setEnabled(false);
            tplazopago9.setEnabled(false);
            tplazopago10.setEnabled(false);
            tporcentajepago1.setEnabled(true);
            tporcentajepago2.setEnabled(true);
            tporcentajepago3.setEnabled(true);
            tporcentajepago4.setEnabled(true);
            tporcentajepago5.setEnabled(false);
            tporcentajepago7.setEnabled(false);
            tporcentajepago6.setEnabled(false);
            tporcentajepago8.setEnabled(false);
            tporcentajepago9.setEnabled(false);
            tporcentajepago10.setEnabled(false);
        }
        if (num == 5) {
            tplazopago1.setEnabled(true);
            tplazopago2.setEnabled(true);
            tplazopago3.setEnabled(true);
            tplazopago4.setEnabled(true);
            tplazopago5.setEnabled(true);
            tplazopago6.setEnabled(false);
            tplazopago7.setEnabled(false);
            tplazopago8.setEnabled(false);
            tplazopago9.setEnabled(false);
            tplazopago10.setEnabled(false);
            tporcentajepago1.setEnabled(true);
            tporcentajepago2.setEnabled(true);
            tporcentajepago3.setEnabled(true);
            tporcentajepago4.setEnabled(true);
            tporcentajepago5.setEnabled(true);
            tporcentajepago7.setEnabled(false);
            tporcentajepago6.setEnabled(false);
            tporcentajepago8.setEnabled(false);
            tporcentajepago9.setEnabled(false);
            tporcentajepago10.setEnabled(false);
        }
        if (num == 6) {
            tplazopago1.setEnabled(true);
            tplazopago2.setEnabled(true);
            tplazopago3.setEnabled(true);
            tplazopago4.setEnabled(true);
            tplazopago5.setEnabled(true);
            tplazopago6.setEnabled(true);
            tplazopago7.setEnabled(false);
            tplazopago8.setEnabled(false);
            tplazopago9.setEnabled(false);
            tplazopago10.setEnabled(false);
            tporcentajepago1.setEnabled(true);
            tporcentajepago2.setEnabled(true);
            tporcentajepago3.setEnabled(true);
            tporcentajepago4.setEnabled(true);
            tporcentajepago5.setEnabled(true);
            tporcentajepago6.setEnabled(true);
            tporcentajepago7.setEnabled(false);
            tporcentajepago8.setEnabled(false);
            tporcentajepago9.setEnabled(false);
            tporcentajepago10.setEnabled(false);
        }
        if (num == 7) {
            tplazopago1.setEnabled(true);
            tplazopago2.setEnabled(true);
            tplazopago3.setEnabled(true);
            tplazopago4.setEnabled(true);
            tplazopago5.setEnabled(true);
            tplazopago6.setEnabled(true);
            tplazopago7.setEnabled(true);
            tplazopago8.setEnabled(false);
            tplazopago9.setEnabled(false);
            tplazopago10.setEnabled(false);
            tporcentajepago1.setEnabled(true);
            tporcentajepago2.setEnabled(true);
            tporcentajepago3.setEnabled(true);
            tporcentajepago4.setEnabled(true);
            tporcentajepago5.setEnabled(true);
            tporcentajepago7.setEnabled(true);
            tporcentajepago6.setEnabled(true);
            tporcentajepago8.setEnabled(false);
            tporcentajepago9.setEnabled(false);
            tporcentajepago10.setEnabled(false);
        }
        if (num == 8) {
            tplazopago1.setEnabled(true);
            tplazopago2.setEnabled(true);
            tplazopago3.setEnabled(true);
            tplazopago4.setEnabled(true);
            tplazopago5.setEnabled(true);
            tplazopago6.setEnabled(true);
            tplazopago7.setEnabled(true);
            tplazopago8.setEnabled(true);
            tplazopago9.setEnabled(false);
            tplazopago10.setEnabled(false);
            tporcentajepago1.setEnabled(true);
            tporcentajepago2.setEnabled(true);
            tporcentajepago3.setEnabled(true);
            tporcentajepago4.setEnabled(true);
            tporcentajepago5.setEnabled(true);
            tporcentajepago7.setEnabled(true);
            tporcentajepago6.setEnabled(true);
            tporcentajepago8.setEnabled(true);
            tporcentajepago9.setEnabled(false);
            tporcentajepago10.setEnabled(false);
        }
        if (num == 9) {
            tplazopago1.setEnabled(true);
            tplazopago2.setEnabled(true);
            tplazopago3.setEnabled(true);
            tplazopago4.setEnabled(true);
            tplazopago5.setEnabled(true);
            tplazopago6.setEnabled(true);
            tplazopago7.setEnabled(true);
            tplazopago8.setEnabled(true);
            tplazopago9.setEnabled(true);
            tplazopago10.setEnabled(false);
            tporcentajepago1.setEnabled(true);
            tporcentajepago2.setEnabled(true);
            tporcentajepago3.setEnabled(true);
            tporcentajepago4.setEnabled(true);
            tporcentajepago5.setEnabled(true);
            tporcentajepago7.setEnabled(true);
            tporcentajepago6.setEnabled(true);
            tporcentajepago8.setEnabled(true);
            tporcentajepago9.setEnabled(true);
            tporcentajepago10.setEnabled(false);
        }
        if (num == 10) {
            tplazopago1.setEnabled(true);
            tplazopago2.setEnabled(true);
            tplazopago3.setEnabled(true);
            tplazopago4.setEnabled(true);
            tplazopago5.setEnabled(true);
            tplazopago6.setEnabled(true);
            tplazopago7.setEnabled(true);
            tplazopago8.setEnabled(true);
            tplazopago9.setEnabled(true);
            tplazopago10.setEnabled(true);
            tporcentajepago1.setEnabled(true);
            tporcentajepago2.setEnabled(true);
            tporcentajepago3.setEnabled(true);
            tporcentajepago4.setEnabled(true);
            tporcentajepago5.setEnabled(true);
            tporcentajepago7.setEnabled(true);
            tporcentajepago6.setEnabled(true);
            tporcentajepago8.setEnabled(true);
            tporcentajepago9.setEnabled(true);
            tporcentajepago10.setEnabled(true);
        }
    }

    private void actualizarPorcentajesVto(int num) {
        tplazopm1.setText("");
        tplazopm2.setText("");
        tplazopm3.setText("");
        tplazopm4.setText("");
        tplazopm5.setText("");
        tplazopm6.setText("");
        tplazopm7.setText("");
        tplazopm8.setText("");
        tplazopm9.setText("");
        tplazopm10.setText("");

        if (num == 0) {
            tplazopm1.setEnabled(false);
            tplazopm2.setEnabled(false);
            tplazopm3.setEnabled(false);
            tplazopm4.setEnabled(false);
            tplazopm5.setEnabled(false);
            tplazopm6.setEnabled(false);
            tplazopm7.setEnabled(false);
            tplazopm8.setEnabled(false);
            tplazopm9.setEnabled(false);
            tplazopm10.setEnabled(false);
        }
        if (num == 1) {
            tplazopm1.setEnabled(true);
            tplazopm2.setEnabled(false);
            tplazopm3.setEnabled(false);
            tplazopm4.setEnabled(false);
            tplazopm5.setEnabled(false);
            tplazopm6.setEnabled(false);
            tplazopm7.setEnabled(false);
            tplazopm8.setEnabled(false);
            tplazopm9.setEnabled(false);
            tplazopm10.setEnabled(false);
        }
        if (num == 2) {
            tplazopm1.setEnabled(true);
            tplazopm2.setEnabled(true);
            tplazopm3.setEnabled(false);
            tplazopm4.setEnabled(false);
            tplazopm5.setEnabled(false);
            tplazopm6.setEnabled(false);
            tplazopm7.setEnabled(false);
            tplazopm8.setEnabled(false);
            tplazopm9.setEnabled(false);
            tplazopm10.setEnabled(false);
        }
        if (num == 3) {
            tplazopm1.setEnabled(true);
            tplazopm2.setEnabled(true);
            tplazopm3.setEnabled(true);
            tplazopm4.setEnabled(false);
            tplazopm5.setEnabled(false);
            tplazopm6.setEnabled(false);
            tplazopm7.setEnabled(false);
            tplazopm8.setEnabled(false);
            tplazopm9.setEnabled(false);
            tplazopm10.setEnabled(false);
        }
        if (num == 4) {
            tplazopm1.setEnabled(true);
            tplazopm2.setEnabled(true);
            tplazopm3.setEnabled(true);
            tplazopm4.setEnabled(true);
            tplazopm5.setEnabled(false);
            tplazopm6.setEnabled(false);
            tplazopm7.setEnabled(false);
            tplazopm8.setEnabled(false);
            tplazopm9.setEnabled(false);
            tplazopm10.setEnabled(false);
        }
        if (num == 5) {
            tplazopm1.setEnabled(true);
            tplazopm2.setEnabled(true);
            tplazopm3.setEnabled(true);
            tplazopm4.setEnabled(true);
            tplazopm5.setEnabled(true);
            tplazopm6.setEnabled(false);
            tplazopm7.setEnabled(false);
            tplazopm8.setEnabled(false);
            tplazopm9.setEnabled(false);
            tplazopm10.setEnabled(false);
        }
        if (num == 6) {
            tplazopm1.setEnabled(true);
            tplazopm2.setEnabled(true);
            tplazopm3.setEnabled(true);
            tplazopm4.setEnabled(true);
            tplazopm5.setEnabled(true);
            tplazopm6.setEnabled(true);
            tplazopm7.setEnabled(false);
            tplazopm8.setEnabled(false);
            tplazopm9.setEnabled(false);
            tplazopm10.setEnabled(false);
        }
        if (num == 7) {
            tplazopm1.setEnabled(true);
            tplazopm2.setEnabled(true);
            tplazopm3.setEnabled(true);
            tplazopm4.setEnabled(true);
            tplazopm5.setEnabled(true);
            tplazopm6.setEnabled(true);
            tplazopm7.setEnabled(true);
            tplazopm8.setEnabled(false);
            tplazopm9.setEnabled(false);
            tplazopm10.setEnabled(false);
        }
        if (num == 8) {
            tplazopm1.setEnabled(true);
            tplazopm2.setEnabled(true);
            tplazopm3.setEnabled(true);
            tplazopm4.setEnabled(true);
            tplazopm5.setEnabled(true);
            tplazopm6.setEnabled(true);
            tplazopm7.setEnabled(true);
            tplazopm8.setEnabled(true);
            tplazopm9.setEnabled(false);
            tplazopm10.setEnabled(false);
        }
        if (num == 9) {
            tplazopm1.setEnabled(true);
            tplazopm2.setEnabled(true);
            tplazopm3.setEnabled(true);
            tplazopm4.setEnabled(true);
            tplazopm5.setEnabled(true);
            tplazopm6.setEnabled(true);
            tplazopm7.setEnabled(true);
            tplazopm8.setEnabled(true);
            tplazopm9.setEnabled(true);
            tplazopm10.setEnabled(false);
        }
        if (num == 10) {
            tplazopm1.setEnabled(true);
            tplazopm2.setEnabled(true);
            tplazopm3.setEnabled(true);
            tplazopm4.setEnabled(true);
            tplazopm5.setEnabled(true);
            tplazopm6.setEnabled(true);
            tplazopm7.setEnabled(true);
            tplazopm8.setEnabled(true);
            tplazopm9.setEnabled(true);
            tplazopm10.setEnabled(true);
        }
    }

    private void actualizarVencimientos(int num) {
        tplazovm1.setText("");
        tplazovm2.setText("");
        tplazovm3.setText("");
        tplazovm4.setText("");
        tplazovm5.setText("");
        tplazovm6.setText("");
        tplazovm7.setText("");
        tplazovm8.setText("");
        tplazovm9.setText("");
        tplazovm10.setText("");

        if (num == 0) {
            tplazovm1.setEnabled(false);
            tplazovm2.setEnabled(false);
            tplazovm3.setEnabled(false);
            tplazovm4.setEnabled(false);
            tplazovm5.setEnabled(false);
            tplazovm6.setEnabled(false);
            tplazovm7.setEnabled(false);
            tplazovm8.setEnabled(false);
            tplazovm9.setEnabled(false);
            tplazovm10.setEnabled(false);
        }
        if (num == 1) {
            tplazovm1.setEnabled(true);
            tplazovm2.setEnabled(false);
            tplazovm3.setEnabled(false);
            tplazovm4.setEnabled(false);
            tplazovm5.setEnabled(false);
            tplazovm6.setEnabled(false);
            tplazovm7.setEnabled(false);
            tplazovm8.setEnabled(false);
            tplazovm9.setEnabled(false);
            tplazovm10.setEnabled(false);
        }
        if (num == 2) {
            tplazovm1.setEnabled(true);
            tplazovm2.setEnabled(true);
            tplazovm3.setEnabled(false);
            tplazovm4.setEnabled(false);
            tplazovm5.setEnabled(false);
            tplazovm6.setEnabled(false);
            tplazovm7.setEnabled(false);
            tplazovm8.setEnabled(false);
            tplazovm9.setEnabled(false);
            tplazovm10.setEnabled(false);
        }
        if (num == 3) {
            tplazovm1.setEnabled(true);
            tplazovm2.setEnabled(true);
            tplazovm3.setEnabled(true);
            tplazovm4.setEnabled(false);
            tplazovm5.setEnabled(false);
            tplazovm6.setEnabled(false);
            tplazovm7.setEnabled(false);
            tplazovm8.setEnabled(false);
            tplazovm9.setEnabled(false);
            tplazovm10.setEnabled(false);
        }
        if (num == 4) {
            tplazovm1.setEnabled(true);
            tplazovm2.setEnabled(true);
            tplazovm3.setEnabled(true);
            tplazovm4.setEnabled(true);
            tplazovm5.setEnabled(false);
            tplazovm6.setEnabled(false);
            tplazovm7.setEnabled(false);
            tplazovm8.setEnabled(false);
            tplazovm9.setEnabled(false);
            tplazovm10.setEnabled(false);
        }
        if (num == 5) {
            tplazovm1.setEnabled(true);
            tplazovm2.setEnabled(true);
            tplazovm3.setEnabled(true);
            tplazovm4.setEnabled(true);
            tplazovm5.setEnabled(true);
            tplazovm6.setEnabled(false);
            tplazovm7.setEnabled(false);
            tplazovm8.setEnabled(false);
            tplazovm9.setEnabled(false);
            tplazovm10.setEnabled(false);
        }
        if (num == 6) {
            tplazovm1.setEnabled(true);
            tplazovm2.setEnabled(true);
            tplazovm3.setEnabled(true);
            tplazovm4.setEnabled(true);
            tplazovm5.setEnabled(true);
            tplazovm6.setEnabled(true);
            tplazovm7.setEnabled(false);
            tplazovm8.setEnabled(false);
            tplazovm9.setEnabled(false);
            tplazovm10.setEnabled(false);
        }
        if (num == 7) {
            tplazovm1.setEnabled(true);
            tplazovm2.setEnabled(true);
            tplazovm3.setEnabled(true);
            tplazovm4.setEnabled(true);
            tplazovm5.setEnabled(true);
            tplazovm6.setEnabled(true);
            tplazovm7.setEnabled(true);
            tplazovm8.setEnabled(false);
            tplazovm9.setEnabled(false);
            tplazovm10.setEnabled(false);
        }
        if (num == 8) {
            tplazovm1.setEnabled(true);
            tplazovm2.setEnabled(true);
            tplazovm3.setEnabled(true);
            tplazovm4.setEnabled(true);
            tplazovm5.setEnabled(true);
            tplazovm6.setEnabled(true);
            tplazovm7.setEnabled(true);
            tplazovm8.setEnabled(true);
            tplazovm9.setEnabled(false);
            tplazovm10.setEnabled(false);
        }
        if (num == 9) {
            tplazovm1.setEnabled(true);
            tplazovm2.setEnabled(true);
            tplazovm3.setEnabled(true);
            tplazovm4.setEnabled(true);
            tplazovm5.setEnabled(true);
            tplazovm6.setEnabled(true);
            tplazovm7.setEnabled(true);
            tplazovm8.setEnabled(true);
            tplazovm9.setEnabled(true);
            tplazovm10.setEnabled(false);
        }
        if (num == 10) {
            tplazovm1.setEnabled(true);
            tplazovm2.setEnabled(true);
            tplazovm3.setEnabled(true);
            tplazovm4.setEnabled(true);
            tplazovm5.setEnabled(true);
            tplazovm6.setEnabled(true);
            tplazovm7.setEnabled(true);
            tplazovm8.setEnabled(true);
            tplazovm9.setEnabled(true);
            tplazovm10.setEnabled(true);
        }
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton baceptar;
    private javax.swing.JCheckBox bcalculoautomatico;
    private javax.swing.JButton bcancelar;
    private javax.swing.JButton bmodificar;
    private javax.swing.JCheckBox bporcentajesautomaticos;
    private javax.swing.JComboBox cplazospagoadelantados;
    private javax.swing.JComboBox ctipocalculo;
    private javax.swing.JComboBox ctiporecibop;
    private javax.swing.JComboBox ctiporecibov;
    private javax.swing.JComboBox cvencimientosadelantados;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JLabel lcodigo;
    private javax.swing.JLabel ldescripcionCliente;
    private javax.swing.JLabel ldescripcionIdentificativa;
    private javax.swing.JLabel ldiasentreplazos;
    private javax.swing.JLabel ldiasprimerplazo;
    private javax.swing.JLabel leuros;
    private javax.swing.JLabel limporteminimo;
    private javax.swing.JLabel lnplazosAdelantados;
    private javax.swing.JLabel lnplazosAdelantados2;
    private javax.swing.JLabel lnplazosAdelantados3;
    private javax.swing.JLabel lnplazosvencimientos;
    private javax.swing.JLabel lplazopago10;
    private javax.swing.JLabel lplazopago11;
    private javax.swing.JLabel lplazopago12;
    private javax.swing.JLabel lplazopago13;
    private javax.swing.JLabel lplazopago14;
    private javax.swing.JLabel lplazopago16;
    private javax.swing.JLabel lplazopago17;
    private javax.swing.JLabel lplazopago18;
    private javax.swing.JLabel lplazopago19;
    private javax.swing.JLabel lplazopago2;
    private javax.swing.JLabel lplazopago20;
    private javax.swing.JLabel lplazopago21;
    private javax.swing.JLabel lplazopago22;
    private javax.swing.JLabel lplazopago23;
    private javax.swing.JLabel lplazopago3;
    private javax.swing.JLabel lplazopago4;
    private javax.swing.JLabel lplazopago43;
    private javax.swing.JLabel lplazopago44;
    private javax.swing.JLabel lplazopago45;
    private javax.swing.JLabel lplazopago46;
    private javax.swing.JLabel lplazopago47;
    private javax.swing.JLabel lplazopago48;
    private javax.swing.JLabel lplazopago49;
    private javax.swing.JLabel lplazopago5;
    private javax.swing.JLabel lplazopago50;
    private javax.swing.JLabel lplazopago51;
    private javax.swing.JLabel lplazopago52;
    private javax.swing.JLabel lplazopago7;
    private javax.swing.JLabel lplazopago8;
    private javax.swing.JLabel lplazopago9;
    private javax.swing.JLabel lporcentaje;
    private javax.swing.JLabel lporcentaje10;
    private javax.swing.JLabel lporcentaje11;
    private javax.swing.JLabel lporcentaje2;
    private javax.swing.JLabel lporcentaje21;
    private javax.swing.JLabel lporcentaje22;
    private javax.swing.JLabel lporcentaje23;
    private javax.swing.JLabel lporcentaje24;
    private javax.swing.JLabel lporcentaje25;
    private javax.swing.JLabel lporcentaje26;
    private javax.swing.JLabel lporcentaje27;
    private javax.swing.JLabel lporcentaje28;
    private javax.swing.JLabel lporcentaje29;
    private javax.swing.JLabel lporcentaje3;
    private javax.swing.JLabel lporcentaje30;
    private javax.swing.JLabel lporcentaje4;
    private javax.swing.JLabel lporcentaje5;
    private javax.swing.JLabel lporcentaje6;
    private javax.swing.JLabel lporcentaje7;
    private javax.swing.JLabel lporcentaje8;
    private javax.swing.JLabel lporcentaje9;
    private javax.swing.JLabel lprontoPago;
    private javax.swing.JLabel lresultadoporcentajes;
    private javax.swing.JLabel lresultadovencimientos;
    private javax.swing.JLabel ltipocalculo;
    private javax.swing.JLabel ltiporecibop;
    private javax.swing.JLabel ltiporecibov;
    private javax.swing.JPanel pdatos;
    private javax.swing.JTextField tcodigo;
    private javax.swing.JTextField tdescripcioncliente;
    private javax.swing.JTextField tdescripcionidentificativa;
    private javax.swing.JTextField tdiasentreplazos;
    private javax.swing.JTextField tdiasprimerplazo;
    private javax.swing.JTextField tdtopp;
    private javax.swing.JTextField timporteminimo;
    private javax.swing.JTextField tplazopago1;
    private javax.swing.JTextField tplazopago10;
    private javax.swing.JTextField tplazopago2;
    private javax.swing.JTextField tplazopago3;
    private javax.swing.JTextField tplazopago4;
    private javax.swing.JTextField tplazopago5;
    private javax.swing.JTextField tplazopago6;
    private javax.swing.JTextField tplazopago7;
    private javax.swing.JTextField tplazopago8;
    private javax.swing.JTextField tplazopago9;
    private javax.swing.JTextField tplazopm1;
    private javax.swing.JTextField tplazopm10;
    private javax.swing.JTextField tplazopm2;
    private javax.swing.JTextField tplazopm3;
    private javax.swing.JTextField tplazopm4;
    private javax.swing.JTextField tplazopm5;
    private javax.swing.JTextField tplazopm6;
    private javax.swing.JTextField tplazopm7;
    private javax.swing.JTextField tplazopm8;
    private javax.swing.JTextField tplazopm9;
    private javax.swing.JTextField tplazovm1;
    private javax.swing.JTextField tplazovm10;
    private javax.swing.JTextField tplazovm2;
    private javax.swing.JTextField tplazovm3;
    private javax.swing.JTextField tplazovm4;
    private javax.swing.JTextField tplazovm5;
    private javax.swing.JTextField tplazovm6;
    private javax.swing.JTextField tplazovm7;
    private javax.swing.JTextField tplazovm8;
    private javax.swing.JTextField tplazovm9;
    private javax.swing.JTextField tporcentajepago1;
    private javax.swing.JTextField tporcentajepago10;
    private javax.swing.JTextField tporcentajepago2;
    private javax.swing.JTextField tporcentajepago3;
    private javax.swing.JTextField tporcentajepago4;
    private javax.swing.JTextField tporcentajepago5;
    private javax.swing.JTextField tporcentajepago6;
    private javax.swing.JTextField tporcentajepago7;
    private javax.swing.JTextField tporcentajepago8;
    private javax.swing.JTextField tporcentajepago9;
    // End of variables declaration//GEN-END:variables
}
