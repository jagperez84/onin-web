/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package gui;

/**
 *
 * @author Jose
 */
public class PaneldeTeclado extends javax.swing.JPanel {
    public boolean isFocusable(){
        return true;
}
}
