package gui;

import acceso.BaseDatos;
import bean.Agentes;
import bean.Articulo;
import bean.Caracteristica;
import bean.Colores;
import bean.Dac;
import bean.DescuentoClienteArticulo;
import bean.DescuentoClienteFamiliaVenta;
import bean.Despiece;
import bean.DespiecePresupuesto;
import bean.Empresa;
import bean.FamiliaVenta;
import bean.LineaCorteLona;
import bean.LineaCortePerfil;
import bean.LineaPresupuesto;
import bean.MovimientoPresupuesto;
import bean.Precios;
import bean.TipoControl;
import bean.TipoMedida;
import bean.Usuario;
import informes.confeccionLonas.ConfeccionLonas;
import informes.confeccionLonas.LineaConfeccion;
import informes.hojaTrabajo.HojaTrabajo;
import informes.hojaTrabajo.LineaHojaTrabajo;
import java.awt.Color;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.text.JTextComponent;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import util.Constantes;
import util.Util;

public class NuevaLineaPresupuesto extends javax.swing.JPanel {
    private int codigo;
    private Articulo a;
    private Caracteristica car;
    private Empresa e;
    private int numMedidas;
    private Double precio;
    private Double cantidad;
    private Double descuento;
    private Double importe;
    private NuevoPresupuesto p;
    private Integer iid;
    private Boolean isLineaArticulo;
    private boolean isDac;
    private List<Despiece> listaDespiece;
    private boolean lineaOculta = false;
    private Double cantidadAntesFoco;
    private Double cantidadDespuesFoco;
    private Double medida1AntesFoco;
    private Double medida1DespuesFoco;
    private Double medida2AntesFoco;
    private Double medida2DespuesFoco;
    private Double medida3AntesFoco;
    private Double medida3DespuesFoco;
    private Double medida4AntesFoco;
    private Double medida4DespuesFoco;
    private Double medida5AntesFoco;
    private Double medida5DespuesFoco;
    private Usuario u;
    public Boolean manual = false;
    private List<String> codigos;

    public NuevaLineaPresupuesto(NuevoPresupuesto p, int codigo, Empresa e, Usuario u) {
        this(p, codigo, e, true, u);
        crearIconosBotones();
        lineaOculta = false;
    }

    public NuevaLineaPresupuesto(NuevoPresupuesto p, int codigo, Empresa e, boolean isLineaArticulo, Usuario u) {
        initComponents();
        this.codigo = codigo;
        this.e = e;
        this.p = p;
        this.u = u;
        setNumMedidas(0);
        tmedidaResultado.setEnabled(false);

        precio = 0.0;
        a = null;
        car = null;
        iid = null;

        mostrarCamposLineaArticulo(isLineaArticulo);
        this.isLineaArticulo = isLineaArticulo;
        bVisualizarDac.setVisible(false);
        bdetalle.setVisible(false);
        bVisualizarCL.setVisible(false);
        bVisualizarHT.setVisible(false);
        crearIconosBotones();
        lineaOculta = false;
    }

    public NuevaLineaPresupuesto(NuevoPresupuesto p, int codigo, Empresa e, LineaPresupuesto lp, boolean isLineaArticulo, Usuario u) {
        initComponents();
        this.codigo = codigo;
        this.e = e;
        this.p = p;
        this.iid = lp.getIid();
        this.u = u;

        setNumMedidas(0);
        tmedidaResultado.setEnabled(false);
        precio = 0.0;
        a = null;
        car = null;

        if (lp.getArticulo_iid() != null) {
            a = BaseDatos.obtenerArticuloPorIid(lp.getArticulo_iid().getIid());

            if (lp.getCaracteristica() != null) {
                car = BaseDatos.obtenerCaracteristicaPorIid(lp.getCaracteristica().getIid());
            }
            Double m1 = lp.getMedida1();
            Double m2 = lp.getMedida2();
            Double m3 = lp.getMedida3();
            Double m4 = lp.getMedida4();
            Double m5 = lp.getMedida5();
            Double mr = lp.getMedidares();

            precio = lp.getPrecioArticulo();

            if (precio != null) {
                tPrecio.setText(Util.convertirPuntoAComa(String.valueOf(precio)));
            }
            numMedidas = lp.getNummedidas();

            cantidad = lp.getCantidad();
            if (cantidad != null) {
                tCantidad.setText(Util.convertirPuntoAComa(String.valueOf(cantidad)));
            }

            descuento = lp.getDescuento();
            if (descuento != null) {
                tDescuento.setText(Util.convertirPuntoAComa(String.valueOf(descuento)));
            }

            if (m1 != null) {
                this.tMedida1.setText(Util.convertirPuntoAComa(String.valueOf(m1)));
            }

            if (m2 != null) {
                this.tMedida2.setText(Util.convertirPuntoAComa(String.valueOf(m2)));
            }

            if (m3 != null) {
                this.tMedida3.setText(Util.convertirPuntoAComa(String.valueOf(m3)));
            }

            if (m4 != null) {
                this.tMedida4.setText(Util.convertirPuntoAComa(String.valueOf(m4)));
            }

            if (m5 != null) {
                this.tMedida5.setText(Util.convertirPuntoAComa(String.valueOf(m5)));
            }

            if (mr != null) {
                this.tmedidaResultado.setText(Util.convertirPuntoAComa(String.valueOf(mr)));
            }

            setNumMedidas(numMedidas);
            insertarArticulo(a, car);

            precio = lp.getPrecioArticulo();
            if (precio != null) {
                tPrecio.setText(Util.convertirPuntoAComa(String.valueOf(precio)));
            }

            descuento = lp.getDescuento();
            if (descuento != null) {
                tDescuento.setText(Util.convertirPuntoAComa(String.valueOf(descuento)));
            }

            importe = lp.getImporte();
            if (importe != null) {
                timporte.setText(Util.convertirPuntoAComa(String.valueOf(importe)));
            }

            iid = lp.getIid();
        }

        if (lp.getDescripcion() != null && !lp.getDescripcion().equals("")) {
            tdescripcion.setText(lp.getDescripcion());
        }

        mostrarCamposLineaArticulo(isLineaArticulo);
        this.isLineaArticulo = isLineaArticulo;

        if (this.a != null) {
            Dac dac = BaseDatos.obtenerDacPorCodigoArticulo(a.getCod_articulo(), e.getIid());
            this.bVisualizarDac.setVisible(dac != null);
            this.bdetalle.setVisible(dac != null);
            if (this.p.getTipoDocumento().equalsIgnoreCase(Constantes.PEDIDO)) {
                this.bVisualizarCL.setVisible(dac != null);
                this.bVisualizarHT.setVisible(dac != null);
            } else {
                this.bVisualizarCL.setVisible(false);
                this.bVisualizarHT.setVisible(false);
            }
        } else {
            this.bVisualizarDac.setVisible(false);
            this.bdetalle.setVisible(false);
            this.bVisualizarCL.setVisible(false);
            this.bVisualizarHT.setVisible(false);
        }

        crearIconosBotones();
        lineaOculta = false;
        if (lp.getManual() != null && lp.getManual().equals("S")) {
            timporte.setForeground(Color.red);
        }
    }

    public NuevaLineaPresupuesto(NuevoPresupuesto p, int codigo, Empresa e, LineaPresupuesto lp, boolean isLineaArticulo, Usuario u, boolean habilitado) {
        initComponents();
        this.codigo = codigo;
        this.e = e;
        this.p = p;
        this.iid = lp.getIid();
        this.u = u;

        setNumMedidas(0);
        tmedidaResultado.setEnabled(false);
        precio = 0.0;
        a = null;
        car = null;

        if (lp.getArticulo_iid() != null) {
            a = BaseDatos.obtenerArticuloPorIid(lp.getArticulo_iid().getIid());

            if (lp.getCaracteristica() != null) {
                car = BaseDatos.obtenerCaracteristicaPorIid(lp.getCaracteristica().getIid());
            }
            Double m1 = lp.getMedida1();
            Double m2 = lp.getMedida2();
            Double m3 = lp.getMedida3();
            Double m4 = lp.getMedida4();
            Double m5 = lp.getMedida5();
            Double mr = lp.getMedidares();

            precio = lp.getPrecioArticulo();
            if (precio != null) {
                tPrecio.setText(Util.convertirPuntoAComa(String.valueOf(precio)));
            }
            numMedidas = lp.getNummedidas();

            cantidad = lp.getCantidad();
            if (cantidad != null) {
                tCantidad.setText(Util.convertirPuntoAComa(String.valueOf(cantidad)));
            }

            descuento = lp.getDescuento();
            if (descuento != null) {
                tDescuento.setText(Util.convertirPuntoAComa(String.valueOf(descuento)));
            }

            if (m1 != null) {
                this.tMedida1.setText(Util.convertirPuntoAComa(String.valueOf(m1)));
            }

            if (m2 != null) {
                this.tMedida2.setText(Util.convertirPuntoAComa(String.valueOf(m2)));
            }

            if (m3 != null) {
                this.tMedida3.setText(Util.convertirPuntoAComa(String.valueOf(m3)));
            }

            if (m4 != null) {
                this.tMedida4.setText(Util.convertirPuntoAComa(String.valueOf(m4)));
            }

            if (m5 != null) {
                this.tMedida5.setText(Util.convertirPuntoAComa(String.valueOf(m5)));
            }

            if (mr != null) {
                this.tmedidaResultado.setText(Util.convertirPuntoAComa(String.valueOf(mr)));
            }

            setNumMedidas(numMedidas);

            insertarArticulo(a, car);

            precio = lp.getPrecioArticulo();
            if (precio != null) {
                tPrecio.setText(Util.convertirPuntoAComa(String.valueOf(precio)));
            }

            descuento = lp.getDescuento();
            if (descuento != null) {
                tDescuento.setText(Util.convertirPuntoAComa(String.valueOf(descuento)));
            }

            importe = lp.getImporte();
            if (importe != null) {
                timporte.setText(Util.convertirPuntoAComa(String.valueOf(importe)));
            }

            iid = lp.getIid();
        }

        if (lp.getDescripcion() != null && !lp.getDescripcion().equals("")) {
            tdescripcion.setText(lp.getDescripcion());
        }

        mostrarCamposLineaArticulo(isLineaArticulo);
        this.isLineaArticulo = isLineaArticulo;

        if (this.a != null) {
            Dac dac = BaseDatos.obtenerDacPorCodigoArticulo(a.getCod_articulo(), e.getIid());
            this.bVisualizarDac.setVisible(dac != null);
            this.bdetalle.setVisible(dac != null);
            if (this.p.getTipoDocumento().equalsIgnoreCase(Constantes.PEDIDO)) {
                this.bVisualizarCL.setVisible(dac != null);
                this.bVisualizarHT.setVisible(dac != null);
            } else {
                this.bVisualizarCL.setVisible(false);
                this.bVisualizarHT.setVisible(false);
            }
        } else {
            this.bVisualizarDac.setVisible(false);
            this.bdetalle.setVisible(false);
            this.bVisualizarCL.setVisible(false);
            this.bVisualizarHT.setVisible(false);
        }

        crearIconosBotones();
        lineaOculta = false;
        if (lp.getManual() != null && lp.getManual().equals("S")) {
            timporte.setForeground(Color.red);
        }

        if (!habilitado) {
            habilitarElementos(habilitado);
        }
    }

    public NuevaLineaPresupuesto(NuevoPresupuesto p, int codigo, Empresa e, LineaPresupuesto lp, Usuario u) {
        this(p, codigo, e, lp, true, u);
        crearIconosBotones();
        lineaOculta = false;
    }

    protected void habilitarElementos(boolean habilitado) {
        tCantidad.setEnabled(habilitado);
        this.bborrar.setEnabled(habilitado);
        this.tcodigo.setEnabled(habilitado);
        this.tdescripcion.setEnabled(habilitado);
        this.bseleccionArticulo.setEnabled(habilitado);
        this.bVisualizarDac.setEnabled(habilitado);
        this.bVisualizarHT.setEnabled(habilitado);
        this.bVisualizarCL.setEnabled(habilitado);
        this.tMedida1.setEnabled(habilitado);
        this.tMedida2.setEnabled(habilitado);
        this.tMedida3.setEnabled(habilitado);
        this.tMedida4.setEnabled(habilitado);
        this.tMedida5.setEnabled(habilitado);
        this.timporte.setEnabled(habilitado);
        this.tDescuento.setEnabled(habilitado);
        this.tPrecio.setEnabled(habilitado);
        if (habilitado) {
            this.setNumMedidas(numMedidas);
        }
    }

    public Integer getIid() {
        return iid;
    }

    public void setIid(Integer iid) {
        this.iid = iid;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }
	
	public boolean getManual() {
        return manual;
    }

    public double getPrecio() {
        if (this.tPrecio.getText() == null || this.tPrecio.getText().length() == 0) {
            precio = 0D;
        } else if (this.tPrecio.getText() != null && this.tPrecio.getText().length() > 0) {
            precio = Double.parseDouble(Util.convertirComaAPunto(tPrecio.getText()));
        } else {
            precio = 0D;
        }
        return precio;
    }

    public double getCantidad() {
        if (this.tCantidad.getText() == null || this.tCantidad.getText().length() == 0) {
            cantidad = 0D;
        } else if (this.tCantidad.getText() != null && this.tCantidad.getText().length() > 0) {
            if (this.tCantidad.getText().equals("-")) {
                cantidad = 0D;
            } else {
                cantidad = Double.parseDouble(Util.convertirComaAPunto(tCantidad.getText()));
            }
        } else {
            cantidad = 0D;
        }
        return cantidad;
    }

    public double getDescuento() {
        if (this.tDescuento.getText() == null || this.tDescuento.getText().length() == 0) {
            descuento = 0D;
        } else if (this.tDescuento.getText() != null && this.tDescuento.getText().length() > 0) {
            descuento = Double.parseDouble(Util.convertirComaAPunto(tDescuento.getText()));
        } else {
            descuento = 0D;
        }
        return descuento;
    }

    public double getImporte() {
        if (this.importe != null) {
            return importe;
        } else {
            if (this.timporte.getText() == null || this.timporte.getText().length() == 0) {
                importe = 0D;
            } else if (this.timporte.getText() != null && this.timporte.getText().length() > 0) {
                importe = Double.parseDouble(Util.convertirComaAPunto(timporte.getText()));
            } else {
                importe = 0D;
            }
            return importe;
        }
    }

    public double getPrecioArticulo() {
        return Double.valueOf(Util.convertirComaAPunto(tPrecio.getText()));
    }

    public double getMedida1() {
        double m = 0;
        String smedida = Util.convertirComaAPunto(tMedida1.getText());
        if (smedida != null && smedida.length() > 0) {
            m = Double.valueOf(smedida);
        }
        return m;
    }

    public double getMedida2() {
        double m = 0;
        String smedida = Util.convertirComaAPunto(tMedida2.getText());
        if (smedida != null && smedida.length() > 0) {
            m = Double.valueOf(smedida);
        }
        return m;
    }

    public double getMedida3() {
        double m = 0;
        String smedida = Util.convertirComaAPunto(tMedida3.getText());
        if (smedida != null && smedida.length() > 0) {
            m = Double.valueOf(smedida);
        }
        return m;
    }

    public double getMedida4() {
        double m = 0;
        String smedida = Util.convertirComaAPunto(tMedida4.getText());
        if (smedida != null && smedida.length() > 0) {
            m = Double.valueOf(smedida);
        }
        return m;
    }

    public double getMedida5() {
        double m = 0;
        String smedida = Util.convertirComaAPunto(tMedida5.getText());
        if (smedida != null && smedida.length() > 0) {
            m = Double.valueOf(smedida);
        }
        return m;
    }

    public double getMedidares() {
        double m = 0;
        String smedida = Util.convertirComaAPunto(tmedidaResultado.getText());
        if (smedida != null && smedida.length() > 0) {
            m = Double.valueOf(smedida);
        }
        return m;
    }

    public void setNumMedidas(int numMedidas) {
        if (numMedidas == 0) {
            tMedida1.setEnabled(false);
            tMedida2.setEnabled(false);
            tMedida3.setEnabled(false);
            tMedida4.setEnabled(false);
            tMedida5.setEnabled(false);
            tMedida1.setText("");
            tMedida2.setText("");
            tMedida3.setText("");
            tMedida4.setText("");
            tMedida5.setText("");
        } else if (numMedidas == 1) {
            tMedida1.setEnabled(true);
            tMedida2.setEnabled(false);
            tMedida3.setEnabled(false);
            tMedida4.setEnabled(false);
            tMedida5.setEnabled(false);

            if (tMedida1.getText() != null && tMedida1.getText().length() == 0) {
                tMedida1.setText("0");
            }

            tMedida2.setText("");
            tMedida3.setText("");
            tMedida4.setText("");
            tMedida5.setText("");
        } else if (numMedidas == 2) {
            tMedida1.setEnabled(true);
            tMedida2.setEnabled(true);
            tMedida3.setEnabled(false);
            tMedida4.setEnabled(false);
            tMedida5.setEnabled(false);

            if (tMedida1.getText() != null && tMedida1.getText().length() == 0) {
                tMedida1.setText("0");
            }

            if (tMedida2.getText() != null && tMedida2.getText().length() == 0) {
                tMedida2.setText("0");
            }
            tMedida3.setText("");
            tMedida4.setText("");
            tMedida5.setText("");
        } else if (numMedidas == 3) {
            tMedida1.setEnabled(true);
            tMedida2.setEnabled(true);
            tMedida3.setEnabled(true);
            tMedida4.setEnabled(false);
            tMedida5.setEnabled(false);

            if (tMedida1.getText() != null && tMedida1.getText().length() == 0) {
                tMedida1.setText("0");
            }

            if (tMedida2.getText() != null && tMedida2.getText().length() == 0) {
                tMedida2.setText("0");
            }

            if (tMedida3.getText() != null && tMedida3.getText().length() == 0) {
                tMedida3.setText("0");
            }

            tMedida4.setText("");
            tMedida5.setText("");
        } else if (numMedidas == 4) {
            tMedida1.setEnabled(true);
            tMedida2.setEnabled(true);
            tMedida3.setEnabled(true);
            tMedida4.setEnabled(true);
            tMedida5.setEnabled(false);

            if (tMedida1.getText() != null && tMedida1.getText().length() == 0) {
                tMedida1.setText("0");
            }

            if (tMedida2.getText() != null && tMedida2.getText().length() == 0) {
                tMedida2.setText("0");
            }

            if (tMedida3.getText() != null && tMedida3.getText().length() == 0) {
                tMedida3.setText("0");
            }

            if (tMedida4.getText() != null && tMedida4.getText().length() == 0) {
                tMedida4.setText("0");
            }

            tMedida5.setText("");
        } else {
            tMedida1.setEnabled(true);
            tMedida2.setEnabled(true);
            tMedida3.setEnabled(true);
            tMedida4.setEnabled(true);
            tMedida5.setEnabled(true);

            if (tMedida1.getText() != null && tMedida1.getText().length() == 0) {
                tMedida1.setText("0");
            }

            if (tMedida2.getText() != null && tMedida2.getText().length() == 0) {
                tMedida2.setText("0");
            }

            if (tMedida3.getText() != null && tMedida3.getText().length() == 0) {
                tMedida3.setText("0");
            }

            if (tMedida4.getText() != null && tMedida4.getText().length() == 0) {
                tMedida4.setText("0");
            }

            if (tMedida5.getText() != null && tMedida5.getText().length() == 0) {
                tMedida5.setText("0");
            }
        }
    }

    public Articulo getArticulo() {
        return a;
    }

    public boolean isLineaArticulo() {
        return isLineaArticulo;
    }

    public Caracteristica getCaracteristica() {
        return car;
    }

    public boolean isDac() {
        boolean res = isDac;
        if (!res && a != null) {
            res = BaseDatos.obtenerDacPorCodigoArticulo(a.getCod_articulo(), e.getIid()) != null;
        }
        return res;
    }

    private void crearIconosBotones() {
        URL url = getClass().getResource("/iconos/lupa.gif");
        ImageIcon icono = new ImageIcon(url);
        bVisualizarDac.setIcon(icono);

        url = getClass().getResource("/iconos/cut.png");
        icono = new ImageIcon(url);
        this.bVisualizarCL.setIcon(icono);

        url = getClass().getResource("/iconos/gafas.gif");
        icono = new ImageIcon(url);
        bVisualizarHT.setIcon(icono);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        tCantidad = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tdescripcion = new javax.swing.JTextArea();
        tMedida1 = new javax.swing.JTextField();
        tMedida2 = new javax.swing.JTextField();
        tMedida3 = new javax.swing.JTextField();
        tMedida4 = new javax.swing.JTextField();
        tMedida5 = new javax.swing.JTextField();
        tmedidaResultado = new javax.swing.JTextField();
        bseleccionArticulo = new javax.swing.JButton();
        tPrecio = new javax.swing.JTextField();
        tDescuento = new javax.swing.JTextField();
        ldto = new javax.swing.JLabel();
        timporte = new javax.swing.JTextField();
        bborrar = new javax.swing.JButton();
        bVisualizarDac = new javax.swing.JButton();
        bVisualizarHT = new javax.swing.JButton();
        bVisualizarCL = new javax.swing.JButton();
        jSeparator1 = new javax.swing.JSeparator();
        jSeparator2 = new javax.swing.JSeparator();
        jSeparator3 = new javax.swing.JSeparator();
        jSeparator4 = new javax.swing.JSeparator();
        jSeparator5 = new javax.swing.JSeparator();
        bdetalle = new javax.swing.JButton();
        tcodigo = new javax.swing.JComboBox();

        setBackground(new java.awt.Color(204, 204, 204));
        setAutoscrolls(true);

        tCantidad.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                tCantidadFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                tCantidadFocusLost(evt);
            }
        });
        tCantidad.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tCantidadKeyReleased(evt);
            }
        });

        tdescripcion.setColumns(20);
        tdescripcion.setRows(5);
        tdescripcion.setAutoscrolls(false);
        tdescripcion.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                tdescripcionFocusGained(evt);
            }
        });
        tdescripcion.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tdescripcionKeyReleased(evt);
            }
        });
        jScrollPane1.setViewportView(tdescripcion);

        tMedida1.setFont(new java.awt.Font("Tahoma", 1, 11));
        tMedida1.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                tMedida1FocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                tMedida1FocusLost(evt);
            }
        });
        tMedida1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tMedida1KeyReleased(evt);
            }
        });

        tMedida2.setFont(new java.awt.Font("Tahoma", 1, 11));
        tMedida2.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                tMedida2FocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                tMedida2FocusLost(evt);
            }
        });
        tMedida2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tMedida2KeyReleased(evt);
            }
        });

        tMedida3.setFont(new java.awt.Font("Tahoma", 1, 11));
        tMedida3.setToolTipText("0");
        tMedida3.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                tMedida3FocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                tMedida3FocusLost(evt);
            }
        });
        tMedida3.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tMedida3KeyReleased(evt);
            }
        });

        tMedida4.setFont(new java.awt.Font("Tahoma", 1, 11));
        tMedida4.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                tMedida4FocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                tMedida4FocusLost(evt);
            }
        });
        tMedida4.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tMedida4KeyReleased(evt);
            }
        });

        tMedida5.setFont(new java.awt.Font("Tahoma", 1, 11));
        tMedida5.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                tMedida5FocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                tMedida5FocusLost(evt);
            }
        });
        tMedida5.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tMedida5KeyReleased(evt);
            }
        });

        tmedidaResultado.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                tmedidaResultadoFocusGained(evt);
            }
        });

        bseleccionArticulo.setText("...");
        bseleccionArticulo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bseleccionArticuloActionPerformed(evt);
            }
        });

        tPrecio.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                tPrecioFocusGained(evt);
            }
        });
        tPrecio.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tPrecioKeyReleased(evt);
            }
        });

        tDescuento.setFont(new java.awt.Font("Tahoma", 1, 11));
        tDescuento.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                tDescuentoFocusGained(evt);
            }
        });
        tDescuento.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tDescuentoKeyReleased(evt);
            }
        });

        ldto.setText("Dto:");

        timporte.setEditable(false);
        timporte.setFont(new java.awt.Font("Tahoma", 1, 11));

        bborrar.setText("Borrar");
        bborrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bborrarActionPerformed(evt);
            }
        });

        bVisualizarDac.setToolTipText("Visualizar Dac");
        bVisualizarDac.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bVisualizarDacActionPerformed(evt);
            }
        });

        bVisualizarHT.setToolTipText("Visualizar hoja de trabajo");
        bVisualizarHT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bVisualizarHTActionPerformed(evt);
            }
        });

        bVisualizarCL.setToolTipText("Visualizar corte de lona");
        bVisualizarCL.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bVisualizarCLActionPerformed(evt);
            }
        });

        jSeparator1.setOrientation(javax.swing.SwingConstants.VERTICAL);

        jSeparator2.setOrientation(javax.swing.SwingConstants.VERTICAL);

        jSeparator3.setOrientation(javax.swing.SwingConstants.VERTICAL);

        jSeparator4.setOrientation(javax.swing.SwingConstants.VERTICAL);

        bdetalle.setText("Detalle");
        bdetalle.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bdetalleActionPerformed(evt);
            }
        });

        tcodigo.setEditable(true);
        tcodigo.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tcodigoKeyReleased(evt);
            }
        });
        tcodigo.getEditor().getEditorComponent().addKeyListener(new KeyAdapter() {

            public void keyReleased(KeyEvent evt){
                tcodigoKeyReleased(evt);
            }

        });

        org.jdesktop.layout.GroupLayout layout = new org.jdesktop.layout.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(layout.createSequentialGroup()
                .addContainerGap()
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(layout.createSequentialGroup()
                        .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                            .add(tCantidad, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 58, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(bdetalle, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .add(bborrar, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jSeparator1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                        .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(jScrollPane1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 300, Short.MAX_VALUE)
                            .add(tcodigo, 0, 300, Short.MAX_VALUE))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(bseleccionArticulo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 23, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(bVisualizarDac, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 23, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(bVisualizarHT, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 23, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(bVisualizarCL, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 23, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                        .add(14, 14, 14)
                        .add(jSeparator2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                            .add(tMedida4)
                            .add(tMedida1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 51, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                        .add(6, 6, 6)
                        .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                            .add(tMedida5)
                            .add(tMedida2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 50, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                            .add(tMedida3, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 56, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(org.jdesktop.layout.GroupLayout.LEADING, tmedidaResultado, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 56, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jSeparator3, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(tDescuento, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 67, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(ldto)
                            .add(org.jdesktop.layout.GroupLayout.TRAILING, tPrecio, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 67, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jSeparator4, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(20, 20, 20)
                        .add(timporte, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 66, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(14, 14, 14))
                    .add(layout.createSequentialGroup()
                        .add(jSeparator5, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 782, Short.MAX_VALUE)
                        .addContainerGap())))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(layout.createSequentialGroup()
                .add(6, 6, 6)
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                        .add(jSeparator4)
                        .add(jSeparator3)
                        .add(layout.createSequentialGroup()
                            .add(tPrecio, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(18, 18, 18)
                            .add(ldto)
                            .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                            .add(tDescuento, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                        .add(layout.createSequentialGroup()
                            .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                                .add(layout.createSequentialGroup()
                                    .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                                        .add(tMedida2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                        .add(tMedida3, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                                    .add(26, 26, 26))
                                .add(layout.createSequentialGroup()
                                    .add(tMedida1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                    .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                                        .add(tMedida4, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                        .add(tMedida5, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))))
                            .add(11, 11, 11)
                            .add(tmedidaResultado, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                        .add(timporte, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(layout.createSequentialGroup()
                            .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                                    .add(bseleccionArticulo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 21, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                    .add(tcodigo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                                .add(tCantidad, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                            .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                            .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                                .add(layout.createSequentialGroup()
                                    .add(bVisualizarDac, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 21, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                    .add(8, 8, 8)
                                    .add(bVisualizarHT, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 21, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                    .add(bVisualizarCL, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 21, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                                .add(layout.createSequentialGroup()
                                    .add(bborrar)
                                    .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                    .add(bdetalle))
                                .add(jScrollPane1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 79, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                        .add(jSeparator2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 106, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                    .add(jSeparator1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 106, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jSeparator5, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
        );
    }// </editor-fold>//GEN-END:initComponents

private void bseleccionArticuloActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bseleccionArticuloActionPerformed
    ListaSeleccionArticulos frame = new ListaSeleccionArticulos(e, this, this.u);
    frame.setDefaultCloseOperation(ListaSeleccionArticulos.DISPOSE_ON_CLOSE);
    frame.setLocationRelativeTo(null);
    frame.setVisible(true);
    p.setLineaActiva(codigo);
    anadirLineaDocumento();
}//GEN-LAST:event_bseleccionArticuloActionPerformed

    public void borrarRDAC(int codigo) {
        p.borrarRDAC(codigo);
    }

    public void borrarRDAC() {
        p.borrarRDAC(codigo);
    }

private void tCantidadFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_tCantidadFocusGained
    cantidadAntesFoco = 0D;
    if (tCantidad.getText().length() > 0) {
        cantidadAntesFoco = new Double(Util.convertirComaAPunto(tCantidad.getText()));
    }
    anadirLineaDocumento();
    p.setLineaActiva(codigo);
}//GEN-LAST:event_tCantidadFocusGained

private void tMedida1KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tMedida1KeyReleased
    int tamaño = tMedida1.getText().length();
    if (tamaño > 0) {
        char c = tMedida1.getText().charAt(tamaño - 1);

        if (c == '.') {
            String contenidoAntiguo = tMedida1.getText().replace(".", ",");
            tMedida1.setText(contenidoAntiguo);
            c = ',';
        }

        if (!((c >= '0' && c <= '9') || c == ',')) {
            String str = tMedida1.getText().substring(0, tamaño - 1);
            tMedida1.setText(str);
        } else if (c == ',') {
            int indicePunto = tMedida1.getText().indexOf(',');
            if (indicePunto != (tamaño - 1)) {
                String str = tMedida1.getText().substring(0, tamaño - 1);
                tMedida1.setText(str);
            }
        }
        if (!this.bVisualizarDac.isVisible()) {
            tPrecio.setText(Util.convertirPuntoAComa(String.valueOf(calcularPrecioEscalado())));
        }
    }

    if (this.bVisualizarDac.isVisible()) {
        calcularPrecioDac();
    } else {
        calcularPrecioArticulo();
    }
    p.setLineaActiva(codigo);
    anadirLineaDocumento();
}//GEN-LAST:event_tMedida1KeyReleased

private void tMedida2KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tMedida2KeyReleased
    int tamaño = tMedida2.getText().length();
    if (tamaño > 0) {
        char c = tMedida2.getText().charAt(tamaño - 1);

        if (c == '.') {
            String contenidoAntiguo = tMedida2.getText().replace(".", ",");
            tMedida2.setText(contenidoAntiguo);
            c = ',';
        }

        if (!((c >= '0' && c <= '9') || c == ',')) {
            String str = tMedida2.getText().substring(0, tamaño - 1);
            tMedida2.setText(str);
        } else if (c == ',') {
            int indicePunto = tMedida2.getText().indexOf(',');
            if (indicePunto != (tamaño - 1)) {
                String str = tMedida2.getText().substring(0, tamaño - 1);
                tMedida2.setText(str);
            }
        }

        tPrecio.setText(Util.convertirPuntoAComa(String.valueOf(calcularPrecioEscalado())));
    }

    if (this.bVisualizarDac.isVisible()) {
        calcularPrecioDac();
    } else {
        calcularPrecioArticulo();
    }
    p.setLineaActiva(codigo);
    anadirLineaDocumento();
}//GEN-LAST:event_tMedida2KeyReleased

private void tMedida3KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tMedida3KeyReleased
    int tamaño = tMedida3.getText().length();
    if (tamaño > 0) {
        char c = tMedida3.getText().charAt(tamaño - 1);

        if (c == '.') {
            String contenidoAntiguo = tMedida3.getText().replace(".", ",");
            tMedida3.setText(contenidoAntiguo);
            c = ',';
        }

        if (!((c >= '0' && c <= '9') || c == ',')) {
            String str = tMedida3.getText().substring(0, tamaño - 1);
            tMedida3.setText(str);
        } else if (c == ',') {
            int indicePunto = tMedida3.getText().indexOf(',');
            if (indicePunto != (tamaño - 1)) {
                String str = tMedida3.getText().substring(0, tamaño - 1);
                tMedida3.setText(str);
            }
        }

        tPrecio.setText(Util.convertirPuntoAComa(String.valueOf(calcularPrecioEscalado())));
    }

    if (this.bVisualizarDac.isVisible()) {
        calcularPrecioDac();
    } else {
        calcularPrecioArticulo();
    }

    p.setLineaActiva(codigo);
    anadirLineaDocumento();
}//GEN-LAST:event_tMedida3KeyReleased

private void tMedida4KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tMedida4KeyReleased
    int tamaño = tMedida4.getText().length();
    if (tamaño > 0) {
        char c = tMedida4.getText().charAt(tamaño - 1);

        if (c == '.') {
            String contenidoAntiguo = tMedida4.getText().replace(".", ",");
            tMedida4.setText(contenidoAntiguo);
            c = ',';
        }

        if (!((c >= '0' && c <= '9') || c == ',')) {
            String str = tMedida4.getText().substring(0, tamaño - 1);
            tMedida4.setText(str);
        } else if (c == ',') {
            int indicePunto = tMedida4.getText().indexOf(',');
            if (indicePunto != (tamaño - 1)) {
                String str = tMedida4.getText().substring(0, tamaño - 1);
                tMedida4.setText(str);
            }
        }

        tPrecio.setText(Util.convertirPuntoAComa(String.valueOf(calcularPrecioEscalado())));
    }

    if (this.bVisualizarDac.isVisible()) {
        calcularPrecioDac();
    } else {
        calcularPrecioArticulo();
    }
    p.setLineaActiva(codigo);
    anadirLineaDocumento();
}//GEN-LAST:event_tMedida4KeyReleased

private void tMedida5KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tMedida5KeyReleased
    int tamaño = tMedida5.getText().length();
    if (tamaño > 0) {
        char c = tMedida5.getText().charAt(tamaño - 1);

        if (c == '.') {
            String contenidoAntiguo = tMedida5.getText().replace(".", ",");
            tMedida5.setText(contenidoAntiguo);
            c = ',';
        }

        if (!((c >= '0' && c <= '9') || c == ',')) {
            String str = tMedida5.getText().substring(0, tamaño - 1);
            tMedida5.setText(str);
        } else if (c == ',') {
            int indicePunto = tMedida5.getText().indexOf(',');
            if (indicePunto != (tamaño - 1)) {
                String str = tMedida5.getText().substring(0, tamaño - 1);
                tMedida5.setText(str);
            }
        }

        tPrecio.setText(Util.convertirPuntoAComa(String.valueOf(calcularPrecioEscalado())));
    }

    if (this.bVisualizarDac.isVisible()) {
        calcularPrecioDac();
    } else {
        calcularPrecioArticulo();
    }

    p.setLineaActiva(codigo);
    anadirLineaDocumento();
}//GEN-LAST:event_tMedida5KeyReleased

private void tCantidadKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tCantidadKeyReleased
    int codigoTecla = evt.getKeyCode();
    if (codigoTecla != KeyEvent.VK_BACK_SPACE && codigoTecla != KeyEvent.VK_ENTER && codigoTecla != KeyEvent.VK_DELETE && codigoTecla != KeyEvent.VK_LEFT && codigoTecla != KeyEvent.VK_RIGHT) {
        char c = evt.getKeyChar();
        int carePosition = tCantidad.getCaretPosition();
        String contenidoAntiguo = tCantidad.getText().replace(".", ",");
        int indiceComaPuntoUltimo = contenidoAntiguo.lastIndexOf(",");
        int indiceComaPuntoPrimero = contenidoAntiguo.indexOf(',');

        if (!(c >= '0' && c <= '9') && c != '.' && c != ',') {
            contenidoAntiguo = contenidoAntiguo.replace(String.valueOf(c), "");
            carePosition--;
        }

        if (indiceComaPuntoUltimo != indiceComaPuntoPrimero) {
            contenidoAntiguo = contenidoAntiguo.replaceFirst(",", "");
            if (indiceComaPuntoUltimo <= carePosition) {
                carePosition--;
            }
        }

        if (carePosition > contenidoAntiguo.length()) {
            carePosition = contenidoAntiguo.length();
        }

        tCantidad.setText(contenidoAntiguo);
        tCantidad.setCaretPosition(carePosition);
    }
    
    if (this.bVisualizarDac.isVisible()) {
        calcularPrecioDac();
    } else {
        calcularPrecioArticulo();
    }
    p.setLineaActiva(codigoTecla);
    anadirLineaDocumento();
    
    
    
    
    
    
    
    /*int tamaño = tCantidad.getText().length();
    if (tamaño > 0) {
        char c = tCantidad.getText().charAt(tamaño - 1);

        if (c == '.') {
            String contenidoAntiguo = tCantidad.getText().replace(".", ",");
            tCantidad.setText(contenidoAntiguo);
            c = ',';
        }

        if (c == '-' && tamaño == 1) {
            //Se perminte, así que no se hace nada
        } else if (!((c >= '0' && c <= '9') || c == ',')) {
            String str = tCantidad.getText().substring(0, tamaño - 1);
            tCantidad.setText(str);
        } else if (c == ',') {
            int indicePunto = tCantidad.getText().indexOf(',');
            if (indicePunto != (tamaño - 1)) {
                String str = tCantidad.getText().substring(0, tamaño - 1);
                tCantidad.setText(str);
            }
        }
    }
    if (this.bVisualizarDac.isVisible()) {
        calcularPrecioDac();
    } else {
        calcularPrecioArticulo();
    }
    p.setLineaActiva(codigoTecla);
    anadirLineaDocumento();*/
}//GEN-LAST:event_tCantidadKeyReleased

private void tPrecioKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tPrecioKeyReleased
    int tamaño = tPrecio.getText().length();
    if (tamaño > 0) {
        char c = tPrecio.getText().charAt(tamaño - 1);

        if (c == '.') {
            String contenidoAntiguo = tPrecio.getText().replace(".", ",");
            tPrecio.setText(contenidoAntiguo);
            c = ',';
        }

        if (!((c >= '0' && c <= '9') || c == ',')) {
            String str = tPrecio.getText().substring(0, tamaño - 1);
            tPrecio.setText(str);
        } else if (c == ',') {
            int indicePunto = tPrecio.getText().indexOf(',');
            if (indicePunto != (tamaño - 1)) {
                String str = tPrecio.getText().substring(0, tamaño - 1);
                tPrecio.setText(str);
            }
        }

		//Establecemos precio material si se ha cambiado el importe
        timporte.setForeground(Color.red);
        manual = true;
    }

    //Al cambiar el valor simplemente multiplicamos el valor añadido por la cantidad
    String scantidad;
    String sprecio;
    if (tCantidad.getText().length() == 0 || tCantidad.getText().equals("-")) {
        scantidad = "0";
    } else {
        scantidad = Util.convertirComaAPunto(tCantidad.getText());
    }

    if (tPrecio.getText().length() == 0) {
        sprecio = "0";
    } else {
        sprecio = Util.convertirComaAPunto(tPrecio.getText());
    }

    cantidad = Double.valueOf(scantidad);
    precio = Double.valueOf(sprecio);

    importe = cantidad * precio;
    timporte.setText(Util.convertirPuntoAComa(importe.toString()));

    p.setLineaActiva(codigo);
    anadirLineaDocumento();
}//GEN-LAST:event_tPrecioKeyReleased

private void tDescuentoKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tDescuentoKeyReleased
    int tamaño = tDescuento.getText().length();
    if (tamaño > 0) {
        char c = tDescuento.getText().charAt(tamaño - 1);

        if (c == '.') {
            String contenidoAntiguo = tDescuento.getText().replace(".", ",");
            tDescuento.setText(contenidoAntiguo);
            c = ',';
        }

        if (!((c >= '0' && c <= '9') || c == ',')) {
            String str = tDescuento.getText().substring(0, tamaño - 1);
            tDescuento.setText(str);
        } else if (c == ',') {
            int indicePunto = tDescuento.getText().indexOf(',');
            if (indicePunto != (tamaño - 1)) {
                String str = tDescuento.getText().substring(0, tamaño - 1);
                tDescuento.setText(str);
            }
        }
    }

    if (this.bVisualizarDac.isVisible()) {
        calcularPrecioDac();
    } else {
        calcularPrecioArticulo();
    }

    p.setLineaActiva(codigo);
    anadirLineaDocumento();
}//GEN-LAST:event_tDescuentoKeyReleased

private void bborrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bborrarActionPerformed
    //Si la linea ya está almacenada en la BBDD y esta linea tiene cortes de lona entonces se han de borrar
    List<LineaCorteLona> llcl = BaseDatos.getListaLineaCorteLonaByLineaPresupuesto(iid);
    List<LineaCortePerfil> llcp = BaseDatos.getListaLineaCortePerfilByLineaPresupuesto(iid);
    List<MovimientoPresupuesto> ld = BaseDatos.getListaMovimientoPresupuestoDescuentoUnidades(iid);

    String mensaje = "";
    if (ld != null && ld.size() > 0) {
        mensaje += "Los descuentos de unidades serán deshechos.";
    }
    if (llcl != null && llcl.size() > 0) {
        mensaje += "Los cortes de lona serán eliminados";
    }
    if (llcp != null && llcp.size() > 0) {
        mensaje += "Los cortes de perfil serán eliminados";
    }

    if (mensaje != null && mensaje.length() > 0) {
        int guardar = JOptionPane.showConfirmDialog(null, mensaje + ". ¿Desea continuar? ", "Información", JOptionPane.YES_NO_OPTION);
        //hacerCambios = -1 ==> se ha pulsado la "x" de cancelar;
        //hacerCambios =  0 ==> se ha pulsado el "sÃ­"
        //hacerCambios =  1 ==> se ha pulsado el "no"
        if (guardar == 0) {
            p.borrarLineaDocumento(codigo);
            p.setLineaActiva(codigo);
            anadirLineaDocumento();
        }
    } else {
        p.borrarLineaDocumento(codigo);
        p.setLineaActiva(codigo);
        anadirLineaDocumento();
    }
}//GEN-LAST:event_bborrarActionPerformed

private void tMedida1FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_tMedida1FocusGained
    medida1AntesFoco = 0D;
    if (tMedida1.getText().length() > 0) {
        medida1AntesFoco = new Double(Util.convertirComaAPunto(tMedida1.getText()));
    }
    p.setLineaActiva(codigo);
    anadirLineaDocumento();
}//GEN-LAST:event_tMedida1FocusGained

private void tMedida2FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_tMedida2FocusGained
    medida2AntesFoco = 0D;
    if (tMedida2.getText().length() > 0) {
        medida2AntesFoco = new Double(Util.convertirComaAPunto(tMedida2.getText()));
    }
    p.setLineaActiva(codigo);
    anadirLineaDocumento();
}//GEN-LAST:event_tMedida2FocusGained

private void tMedida3FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_tMedida3FocusGained
    medida3AntesFoco = 0D;
    if (tMedida3.getText().length() > 0) {
        medida3AntesFoco = new Double(Util.convertirComaAPunto(tMedida3.getText()));
    }
    p.setLineaActiva(codigo);
    anadirLineaDocumento();
}//GEN-LAST:event_tMedida3FocusGained

private void tMedida4FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_tMedida4FocusGained
    medida4AntesFoco = 0D;
    if (tMedida4.getText().length() > 0) {
        medida4AntesFoco = new Double(Util.convertirComaAPunto(tMedida4.getText()));
    }
    p.setLineaActiva(codigo);
    anadirLineaDocumento();
}//GEN-LAST:event_tMedida4FocusGained

private void tMedida5FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_tMedida5FocusGained
    medida5AntesFoco = 0D;
    if (tMedida5.getText().length() > 0) {
        medida5AntesFoco = new Double(Util.convertirComaAPunto(tMedida5.getText()));
    }
    p.setLineaActiva(codigo);
    anadirLineaDocumento();
}//GEN-LAST:event_tMedida5FocusGained

private void tmedidaResultadoFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_tmedidaResultadoFocusGained
    medida5AntesFoco = 0D;
    if (tMedida5.getText().length() > 0) {
        medida5AntesFoco = new Double(Util.convertirComaAPunto(tMedida5.getText()));
    }
    p.setLineaActiva(codigo);
    anadirLineaDocumento();
}//GEN-LAST:event_tmedidaResultadoFocusGained

private void tPrecioFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_tPrecioFocusGained
    p.setLineaActiva(codigo);
    anadirLineaDocumento();
}//GEN-LAST:event_tPrecioFocusGained

private void tDescuentoFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_tDescuentoFocusGained
    p.setLineaActiva(codigo);
    anadirLineaDocumento();
}//GEN-LAST:event_tDescuentoFocusGained

private void bVisualizarDacActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bVisualizarDacActionPerformed
    RellenarDac rd = p.getRellenarDac(codigo);
    Dac dac = rd.getDacBase();

    if (this.tCantidad.getText() != null && this.tCantidad.getText().length() > 0) {
        dac.setCantidad(Double.parseDouble(Util.convertirComaAPunto(this.tCantidad.getText())));
    } else {
        dac.setCantidad(0D);
    }

    if (this.tMedida1.getText() != null && this.tMedida1.getText().length() > 0) {
        dac.setMedida1(Double.parseDouble(Util.convertirComaAPunto(this.tMedida1.getText())));
    } else {
        dac.setMedida1(0D);
    }

    if (this.tMedida2.getText() != null && this.tMedida2.getText().length() > 0) {
        dac.setMedida2(Double.parseDouble(Util.convertirComaAPunto(this.tMedida2.getText())));
    } else {
        dac.setMedida2(0D);
    }

    if (this.tMedida3.getText() != null && this.tMedida3.getText().length() > 0) {
        dac.setMedida3(Double.parseDouble(Util.convertirComaAPunto(this.tMedida3.getText())));
    } else {
        dac.setMedida3(0D);
    }

    if (this.tMedida4.getText() != null && this.tMedida4.getText().length() > 0) {
        dac.setMedida4(Double.parseDouble(Util.convertirComaAPunto(this.tMedida4.getText())));
    } else {
        dac.setMedida4(0D);
    }

    if (this.tMedida5.getText() != null && this.tMedida5.getText().length() > 0) {
        dac.setMedida5(Double.parseDouble(Util.convertirComaAPunto(this.tMedida5.getText())));
    } else {
        dac.setMedida5(0D);
    }

    rd.setDacBase(dac);

    RellenarDac rdac = new RellenarDac(rd, p, "Titulo");
    rdac.setDefaultCloseOperation(RellenarDac.DISPOSE_ON_CLOSE);
    rdac.setLocationRelativeTo(null);
    rdac.setVisible(true);

    if (iid != null) {
        List<LineaCorteLona> llcl = BaseDatos.getListaLineaCorteLonaByLineaPresupuesto(iid);
        List<LineaCortePerfil> llcp = BaseDatos.getListaLineaCortePerfilByLineaPresupuesto(iid);

        if (llcl != null && llcl.size() > 0 && llcp != null && llcp.size() > 0) {
            //Las lonas y perfiles cortados serán deshechos
            JOptionPane.showMessageDialog(null, "Si cambia las medidas de alguna variable y/o dimensión los cortes de lona y perfil de esta linea serán eliminados", "Información", JOptionPane.INFORMATION_MESSAGE);
        } else if (llcl != null && llcl.size() > 0) {
            //Las lonas cortadas serán deshechas
            JOptionPane.showMessageDialog(null, "Si cambia las medidas de alguna variable y/o dimensión los cortes de lona de esta linea serán eliminados", "Información", JOptionPane.INFORMATION_MESSAGE);
        } else if (llcp != null && llcp.size() > 0) {
            //Los perfiles cortados serán deshechos
            JOptionPane.showMessageDialog(null, "Si cambia las medidas de alguna variable y/o dimensión los cortes de perfil de esta linea serán eliminados", "Información", JOptionPane.INFORMATION_MESSAGE);
        }
    }
}//GEN-LAST:event_bVisualizarDacActionPerformed

private void bVisualizarHTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bVisualizarHTActionPerformed
    RellenarDac rd = p.getRellenarDac(codigo);
    if (this.tMedida1.getText() != null && this.tMedida1.getText().length() > 0) {
        rd.setMedida1(this.tMedida1.getText());
    } else {
        rd.setMedida1("0");
    }

    if (this.tMedida2.getText() != null && this.tMedida2.getText().length() > 0) {
        rd.setMedida2(this.tMedida2.getText());
    } else {
        rd.setMedida2("0");
    }

    if (this.tMedida3.getText() != null && this.tMedida3.getText().length() > 0) {
        rd.setMedida3(this.tMedida3.getText());
    } else {
        rd.setMedida3("0");
    }

    if (this.tMedida4.getText() != null && this.tMedida4.getText().length() > 0) {
        rd.setMedida4(this.tMedida4.getText());
    } else {
        rd.setMedida4("0");
    }

    if (this.tMedida5.getText() != null && this.tMedida5.getText().length() > 0) {
        rd.setMedida5(this.tMedida5.getText());
    } else {
        rd.setMedida5("0");
    }
    rd.iniciarVariables();
    
	List listaDesp;
    Iterator<Despiece> iter = rd.getListaDespiece().iterator();
    HashMap mapaArticulos = new HashMap();
    Articulo arTemp;
    Despiece desTemp;
    FamiliaVenta famTemp;

    while (iter.hasNext()) {
        desTemp = iter.next();
        arTemp = desTemp.getArticulo();
        arTemp = BaseDatos.obtenerArticuloPorIid(arTemp.getIid());
        famTemp = arTemp.getIid_fam_venta();
        famTemp = BaseDatos.obtenerFamiliaVentaPorIid(famTemp.getIid());

        if (mapaArticulos.get(famTemp.getNombre()) == null) {
            listaDesp = new ArrayList();
        } else {
            listaDesp = (List) mapaArticulos.get(famTemp.getNombre());
        }
        listaDesp.add(desTemp);
        mapaArticulos.put(famTemp.getNombre(), listaDesp);
    }

    LineaHojaTrabajo lht;
    List<LineaHojaTrabajo> llht = new ArrayList<LineaHojaTrabajo>();
    String cantidadTemporal;
    String colorTemp;
    Float cantidad1;
    Colores col;
    String clave;
    cantidad1 = Float.parseFloat(Util.convertirComaAPunto(this.getTcantidad()));
    String perfilS = "";
    Double perfilD;
    for (Iterator<String> it = mapaArticulos.keySet().iterator(); it.hasNext();) {
        clave = it.next();
        listaDesp = (List) mapaArticulos.get(clave);
        iter = listaDesp.iterator();
        lht = new LineaHojaTrabajo(clave);
        llht.add(lht);
        while (iter.hasNext()) {
            desTemp = iter.next();
            arTemp = desTemp.getArticulo();
            arTemp = BaseDatos.obtenerArticuloPorIid(arTemp.getIid());
            if (desTemp.getFormulaCantidad() == null || desTemp.getFormulaCantidad().length() == 0) {
                cantidadTemporal = "0";
            } else {
                cantidadTemporal = Util.convertirPuntoAComa(String.valueOf(rd.evaluar(cantidad1 + "*(" + desTemp.getFormulaCantidad() + ")", desTemp.getRedondeo(), false)));
            }
            colorTemp = "";
            perfilS = "";
            perfilD = null;
            if (desTemp.getColor() != null) {
                col = BaseDatos.obtenerColorPorIid(desTemp.getColor().getIid());
                colorTemp = col.getDescripcion();
            }

            if (iid != null && desTemp.getIidInicial() != null) {
                perfilD = BaseDatos.obtenerLongitudSeleccionadaPerfil(iid, desTemp.getIidInicial());
                if (perfilD != null) {
                    perfilS = " (" + Util.convertirPuntoAComa(String.valueOf(perfilD)) + ")";
                }
            }

            lht = new LineaHojaTrabajo(arTemp.getCod_articulo(), arTemp.getDes_inf() + perfilS, colorTemp, cantidadTemporal, rd.calcularMedidasStr(desTemp));
            llht.add(lht);
        }
    }

    HashMap parameters = new HashMap();
    parameters.put("numero", p.getNumero());
    parameters.put("referencia", p.getReferencia());

    HashMap hashDatos = new HashMap();
    hashDatos.put("codigoCliente", p.getCodigoCliente());
    hashDatos.put("nombreCliente", p.getNombreCliente());
    hashDatos.put("codigo", tcodigo.getSelectedItem());
    hashDatos.put("descripcion", tdescripcion.getText());
    hashDatos.put("cantidad", tCantidad.getText());
    hashDatos.put("dimensionesStr", getDimensionesStr());
    hashDatos.put("medidasStr", getMedidasStr(rd));
    
	parameters.put("hashDatos", hashDatos);
    parameters.put("LineaHojaTrabajo", new JRBeanCollectionDataSource(llht));
	
    HojaTrabajo.imprimirHojaTrabajo(parameters);
}//GEN-LAST:event_bVisualizarHTActionPerformed

private void bVisualizarCLActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bVisualizarCLActionPerformed
    RellenarDac rd = p.getRellenarDac(codigo);
    Dac dac = rd.getDacBase();

    if (this.tCantidad.getText() != null && this.tCantidad.getText().length() > 0) {
        dac.setCantidad(Double.parseDouble(Util.convertirComaAPunto(this.tCantidad.getText())));
    } else {
        dac.setCantidad(0D);
    }

    if (this.tMedida1.getText() != null && this.tMedida1.getText().length() > 0) {
        dac.setMedida1(Double.parseDouble(Util.convertirComaAPunto(this.tMedida1.getText())));
    } else {
        dac.setMedida1(0D);
    }

    if (this.tMedida2.getText() != null && this.tMedida2.getText().length() > 0) {
        dac.setMedida2(Double.parseDouble(Util.convertirComaAPunto(this.tMedida2.getText())));
    } else {
        dac.setMedida2(0D);
    }

    if (this.tMedida3.getText() != null && this.tMedida3.getText().length() > 0) {
        dac.setMedida3(Double.parseDouble(Util.convertirComaAPunto(this.tMedida3.getText())));
    } else {
        dac.setMedida3(0D);
    }

    if (this.tMedida4.getText() != null && this.tMedida4.getText().length() > 0) {
        dac.setMedida4(Double.parseDouble(Util.convertirComaAPunto(this.tMedida4.getText())));
    } else {
        dac.setMedida4(0D);
    }

    if (this.tMedida5.getText() != null && this.tMedida5.getText().length() > 0) {
        dac.setMedida5(Double.parseDouble(Util.convertirComaAPunto(this.tMedida5.getText())));
    } else {
        dac.setMedida5(0D);
    }

    rd.setDacBase(dac);
    rd = new RellenarDac(rd, p, "Titulo");
   
    Iterator<LineaCorteLona> iter = null;
    LineaCorteLona lcl;
    DespiecePresupuesto dp;
    Despiece d;
    Articulo articuloBase;
    List<LineaConfeccion> llc = new ArrayList<LineaConfeccion>();
    Float cantidad1 = Float.parseFloat(Util.convertirComaAPunto(this.getTcantidad()));
    HashMap parameters = new HashMap();
    String cantidadTemporal;

    parameters.put("numero", p.getNumero());
    parameters.put("referencia", p.getReferencia());
    parameters.put("cliente", p.getNombreCliente());

    Date fecha = new Date(p.getFechaLong());
    SimpleDateFormat formatoFecha = new SimpleDateFormat("dd/MM/yyyy");
    parameters.put("fecha", formatoFecha.format(fecha).toString());

    String articulos = "";
 
    List<LineaCorteLona> llcl = BaseDatos.getListaLineaCorteLonaByLineaPresupuesto(iid);

    if (llcl != null && llcl.size() > 0) {
        iter = llcl.iterator();
        String contadorLineaStr;
        LineaConfeccion lc;

        while (iter.hasNext()) {
            lcl = iter.next();
			contadorLineaStr = "L" + getCodigo();
            lc = new LineaConfeccion();
            lc.setContadorLinea(contadorLineaStr);
            lc.setNumeroDoc(p.getNumero());
            lc.setCorte("Corte de tipo " + lcl.getTipoCorteLona());

            if (lcl.getEsDespiece()) {
                dp = BaseDatos.obtenerDespiecePresupuestoByIid(lcl.getDespiece().getIid());
                d = dp.clonar();
                articuloBase = BaseDatos.obtenerArticuloPorIid(dp.getArticulo().getIid());
                lc.setCodigo(articuloBase.getCod_articulo());
                cantidadTemporal = Util.convertirPuntoAComa(String.valueOf(rd.evaluar(cantidad1 + "*(" + dp.getFormulaCantidad() + ")", dp.getRedondeo(), false)));
                lc.setCant(cantidadTemporal);
                lc.setMedida(Util.convertirPuntoAComa(String.valueOf(rd.evaluar(dp.getFormulaMedida1(), dp.getRedondeo(), false))) + " x " + Util.convertirPuntoAComa(String.valueOf(rd.evaluar(dp.getFormulaMedida2(), dp.getRedondeo(), false))));
                lc.setDescripcion(articuloBase.getDes_tecnica());
            } else {
                lc.setCodigo((String) tcodigo.getSelectedItem());
                lc.setMedida(tMedida1.getText() + " x" + tMedida2.getText());
                lc.setCant(tCantidad.getText());
                lc.setDescripcion(a.getDes_tecnica());
            }

            lc.setArticulos(articulos);
            lc.setImagenConfeccion(Util.pintarLona(lcl.getTipoCorteLona(), lcl.getLinea().toString(), lcl.getSalida().toString(), lcl.getDobladillo().toString(), lcl.getSolape().toString(), lcl.getAnchoSeleccionado().floatValue()));
            llc.add(lc);
        }

        parameters.put("LineaLona", new JRBeanCollectionDataSource(llc));

        HashMap hashDatos = new HashMap();
        hashDatos.put("codigoToldo", tcodigo.getSelectedItem());
        hashDatos.put("medida", tMedida1.getText() + " x " + tMedida2.getText());
        hashDatos.put("cantidad", tCantidad.getText());
        hashDatos.put("descripcion", a.getDes_tecnica());
        parameters.put("hashDatos", hashDatos);
        ConfeccionLonas.imprimirConfeccionLonas(parameters);
    } else {
        NuevoCorteLonaSimulado ncs = new NuevoCorteLonaSimulado(this);
        ncs.setDefaultCloseOperation(NuevoArticulo.DISPOSE_ON_CLOSE);
        ncs.setLocationRelativeTo(null);
        ncs.setVisible(true);
    }
}//GEN-LAST:event_bVisualizarCLActionPerformed

private void tdescripcionKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tdescripcionKeyReleased
    String descripcion = tdescripcion.getText();
    if (descripcion.length() > Constantes.TAM_DESCRIPCION_ARTICULO_PRESUPUESTO) {
        JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_DESCRIPCION_ARTICULO_PRESUPUESTO, "Error", JOptionPane.ERROR_MESSAGE);
        tdescripcion.setText(descripcion.substring(0, Constantes.TAM_DESCRIPCION_ARTICULO_PRESUPUESTO));
    }
    p.setLineaActiva(codigo);
    anadirLineaDocumento();
}//GEN-LAST:event_tdescripcionKeyReleased

private void tdescripcionFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_tdescripcionFocusGained
    p.setLineaActiva(codigo);
    anadirLineaDocumento();
}//GEN-LAST:event_tdescripcionFocusGained

private void tCantidadFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_tCantidadFocusLost
    if (p.getTipoDocumento().equalsIgnoreCase(Constantes.PEDIDO)) {
        cantidadDespuesFoco = 0D;
        if (!tCantidad.getText().equals("")) {
            cantidadDespuesFoco = new Double(Util.convertirComaAPunto(tCantidad.getText()));
        }
        if (iid != null && !cantidadAntesFoco.equals(cantidadDespuesFoco)) {
            //Si la linea ya está almacenada en la BBDD y esta linea tiene cortes de lona entonces se han de borrar
            List<LineaCorteLona> llcl = BaseDatos.getListaLineaCorteLonaByLineaPresupuesto(iid);
            List<LineaCortePerfil> llcp = BaseDatos.getListaLineaCortePerfilByLineaPresupuesto(iid);
            List<MovimientoPresupuesto> ld = BaseDatos.getListaMovimientoPresupuestoDescuentoUnidades(iid);

            StringBuffer buffer = new StringBuffer();
            if (ld != null && ld.size() > 0) {
                buffer.append("Los descuentos de unidades serán deshechos.");
            }
            if (llcl != null && llcl.size() > 0) {
                buffer.append("Los cortes de lona serán eliminados");
            }
            if (llcp != null && llcp.size() > 0) {
                buffer.append("Los cortes de perfil serán eliminados");
            }

            if (buffer.toString().length() > 0) {
                JOptionPane.showMessageDialog(null, buffer.toString(), "Informacion", JOptionPane.INFORMATION_MESSAGE);
                if (ld != null && ld.size() > 0) {
                    BaseDatos.eliminarDescuentoUnidadesByLineaPresupuesto(iid);
                }
                if (llcl != null && llcl.size() > 0) {
                    BaseDatos.eliminarCorteLonaByLineaPresupuesto(iid);
                }
                if (llcp != null && llcp.size() > 0) {
                    BaseDatos.eliminarCortePerfilByLineaPresupuesto(iid);
                }
            }
            
            if (this.bVisualizarDac.isVisible()) {
                calcularPrecioDac();
            } else {
                calcularPrecioArticulo();
            }
        }
    }
}//GEN-LAST:event_tCantidadFocusLost

private void tMedida1FocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_tMedida1FocusLost
    if (p.getTipoDocumento().equalsIgnoreCase(Constantes.PEDIDO)) {
        medida1DespuesFoco = 0D;
        if (!tMedida1.getText().equals("")) {
            medida1DespuesFoco = new Double(Util.convertirComaAPunto(tMedida1.getText()));
        }
        if (iid != null && !medida1AntesFoco.equals(medida1DespuesFoco)) {
            //Si la linea ya está almacenada en la BBDD y esta linea tiene cortes de lona entonces se han de borrar
            List<LineaCorteLona> llcl = BaseDatos.getListaLineaCorteLonaByLineaPresupuesto(iid);
            List<LineaCortePerfil> llcp = BaseDatos.getListaLineaCortePerfilByLineaPresupuesto(iid);
            List<MovimientoPresupuesto> ld = BaseDatos.getListaMovimientoPresupuestoDescuentoUnidades(iid);

            StringBuffer buffer = new StringBuffer();
            if (ld != null && ld.size() > 0) {
                buffer.append("Los descuentos de unidades serán deshechos.");
            }
            if (llcl != null && llcl.size() > 0) {
                buffer.append("Los cortes de lona serán eliminados");
            }
            if (llcp != null && llcp.size() > 0) {
                buffer.append("Los cortes de perfil serán eliminados");
            }

            if (buffer.toString().length() > 0) {
                JOptionPane.showMessageDialog(null, buffer.toString(), "Información", JOptionPane.INFORMATION_MESSAGE);
                if (ld != null && ld.size() > 0) {
                    BaseDatos.eliminarDescuentoUnidadesByLineaPresupuesto(iid);
                }
                if (llcl != null && llcl.size() > 0) {
                    BaseDatos.eliminarCorteLonaByLineaPresupuesto(iid);
                }
                if (llcp != null && llcp.size() > 0) {
                    BaseDatos.eliminarCortePerfilByLineaPresupuesto(iid);
                }
            }
            
            if (this.bVisualizarDac.isVisible()) {
                calcularPrecioDac();
            } else {
                calcularPrecioArticulo();
            }
        }
    }
}//GEN-LAST:event_tMedida1FocusLost

private void tMedida2FocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_tMedida2FocusLost
    if (p.getTipoDocumento().equalsIgnoreCase(Constantes.PEDIDO)) {
        medida2DespuesFoco = 0D;
        if (tMedida2.getText().length() > 0) {
            medida2DespuesFoco = new Double(Util.convertirComaAPunto(tMedida2.getText()));
        }
        if (iid != null && !medida2AntesFoco.equals(medida2DespuesFoco)) {
            //Si la linea ya está almacenada en la BBDD y esta linea tiene cortes de lona entonces se han de borrar
            List<LineaCorteLona> llcl = BaseDatos.getListaLineaCorteLonaByLineaPresupuesto(iid);
            List<LineaCortePerfil> llcp = BaseDatos.getListaLineaCortePerfilByLineaPresupuesto(iid);
            List<MovimientoPresupuesto> ld = BaseDatos.getListaMovimientoPresupuestoDescuentoUnidades(iid);

            StringBuffer buffer = new StringBuffer();
            if (ld != null && ld.size() > 0) {
				buffer.append("Los descuentos de unidades serán deshechos.");
            }
            if (llcl != null && llcl.size() > 0) {
                buffer.append("Los cortes de lona serán eliminados");
            }
            if (llcp != null && llcp.size() > 0) {
                buffer.append("Los cortes de perfil serán eliminados");
            }

            if (buffer.toString().length() > 0) {
                JOptionPane.showMessageDialog(null, buffer.toString(), "Información", JOptionPane.INFORMATION_MESSAGE);
                if (ld != null && ld.size() > 0) {
                    BaseDatos.eliminarDescuentoUnidadesByLineaPresupuesto(iid);
                }
                if (llcl != null && llcl.size() > 0) {
                    BaseDatos.eliminarCorteLonaByLineaPresupuesto(iid);
                }
                if (llcp != null && llcp.size() > 0) {
                    BaseDatos.eliminarCortePerfilByLineaPresupuesto(iid);
                }
            }

            if (this.bVisualizarDac.isVisible()) {
                calcularPrecioDac();
            } else {
                calcularPrecioArticulo();
            }
        }
    }
}//GEN-LAST:event_tMedida2FocusLost

    private void bdetalleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bdetalleActionPerformed
        despieceProd frame = new despieceProd(p.getRellenarDac(codigo), this);
        frame.setDefaultCloseOperation(despieceProd.DISPOSE_ON_CLOSE);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        if (manual) {
            timporte.setForeground(Color.red);
        }
    }//GEN-LAST:event_bdetalleActionPerformed

private void tMedida3FocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_tMedida3FocusLost
    if (p.getTipoDocumento().equalsIgnoreCase(Constantes.PEDIDO)) {
        medida3DespuesFoco = 0D;
        if (tMedida3.getText().length() > 0) {
            medida3DespuesFoco = new Double(Util.convertirComaAPunto(tMedida3.getText()));
        }
        if (iid != null && !medida3AntesFoco.equals(medida3DespuesFoco)) {
            //Si la linea ya está almacenada en la BBDD y esta linea tiene cortes de lona entonces se han de borrar
            List<LineaCorteLona> llcl = BaseDatos.getListaLineaCorteLonaByLineaPresupuesto(iid);
            List<LineaCortePerfil> llcp = BaseDatos.getListaLineaCortePerfilByLineaPresupuesto(iid);
            List<MovimientoPresupuesto> ld = BaseDatos.getListaMovimientoPresupuestoDescuentoUnidades(iid);

            StringBuffer buffer = new StringBuffer();
            if (ld != null && ld.size() > 0) {
                buffer.append("Los descuentos de unidades serán deshechos.");
            }
            if (llcl != null && llcl.size() > 0) {
                buffer.append("Los cortes de lona serán eliminados");
            }
            if (llcp != null && llcp.size() > 0) {
                buffer.append("Los cortes de perfil serán eliminados");
            }

            if (buffer.toString().length() > 0) {
                JOptionPane.showMessageDialog(null, buffer.toString(), "Información", JOptionPane.INFORMATION_MESSAGE);
                if (ld != null && ld.size() > 0) {
                    BaseDatos.eliminarDescuentoUnidadesByLineaPresupuesto(iid);
                }
                if (llcl != null && llcl.size() > 0) {
                    BaseDatos.eliminarCorteLonaByLineaPresupuesto(iid);
                }
                if (llcp != null && llcp.size() > 0) {
                    BaseDatos.eliminarCortePerfilByLineaPresupuesto(iid);
                }
            }
            
            if (this.bVisualizarDac.isVisible()) {
                calcularPrecioDac();
            } else {
                calcularPrecioArticulo();
            }
        }
    }
}//GEN-LAST:event_tMedida3FocusLost

private void tMedida4FocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_tMedida4FocusLost
    if (p.getTipoDocumento().equalsIgnoreCase(Constantes.PEDIDO)) {
        medida4DespuesFoco = 0D;
        if (!tMedida4.getText().equals("")) {
            medida4DespuesFoco = new Double(Util.convertirComaAPunto(tMedida4.getText()));
        }
        if (iid != null && !medida4AntesFoco.equals(medida4DespuesFoco)) {
            //Si la linea ya está almacenada en la BBDD y esta linea tiene cortes de lona entonces se han de borrar
            List<LineaCorteLona> llcl = BaseDatos.getListaLineaCorteLonaByLineaPresupuesto(iid);
            List<LineaCortePerfil> llcp = BaseDatos.getListaLineaCortePerfilByLineaPresupuesto(iid);
            List<MovimientoPresupuesto> ld = BaseDatos.getListaMovimientoPresupuestoDescuentoUnidades(iid);

            StringBuffer buffer = new StringBuffer();
            if (ld != null && ld.size() > 0) {
				buffer.append("Los descuentos de unidades serán deshechos.");
            }
            if (llcl != null && llcl.size() > 0) {
		              buffer.append("Los cortes de lona serán eliminados");
            }
            if (llcp != null && llcp.size() > 0) {
                buffer.append("Los cortes de perfil serán eliminados");
            }

            if (buffer.toString().length() > 0) {
                JOptionPane.showMessageDialog(null, buffer.toString(), "Información", JOptionPane.INFORMATION_MESSAGE);
                if (ld != null && ld.size() > 0) {
                    BaseDatos.eliminarDescuentoUnidadesByLineaPresupuesto(iid);
                }
                if (llcl != null && llcl.size() > 0) {
                    BaseDatos.eliminarCorteLonaByLineaPresupuesto(iid);
                }
                if (llcp != null && llcp.size() > 0) {
                    BaseDatos.eliminarCortePerfilByLineaPresupuesto(iid);
                }
            }

            if (this.bVisualizarDac.isVisible()) {
                calcularPrecioDac();
            } else {
                calcularPrecioArticulo();
            }
        }
    }
}//GEN-LAST:event_tMedida4FocusLost

private void tMedida5FocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_tMedida5FocusLost
    if (p.getTipoDocumento().equalsIgnoreCase(Constantes.PEDIDO)) {
        medida5DespuesFoco = 0D;
        if (tMedida5.getText().length() > 0) {
            medida5DespuesFoco = new Double(Util.convertirComaAPunto(tMedida5.getText()));
        }
        if (iid != null && !medida5AntesFoco.equals(medida5DespuesFoco)) {
            //Si la linea ya está almacenada en la BBDD y esta linea tiene cortes de lona entonces se han de borrar
            List<LineaCorteLona> llcl = BaseDatos.getListaLineaCorteLonaByLineaPresupuesto(iid);
            List<LineaCortePerfil> llcp = BaseDatos.getListaLineaCortePerfilByLineaPresupuesto(iid);
            List<MovimientoPresupuesto> ld = BaseDatos.getListaMovimientoPresupuestoDescuentoUnidades(iid);

            StringBuffer buffer = new StringBuffer();
            if (ld != null && ld.size() > 0) {
                buffer.append("Los descuentos de unidades serán deshechos.");
            }
            if (llcl != null && llcl.size() > 0) {
                buffer.append("Los cortes de lona serán eliminados");
            }
            if (llcp != null && llcp.size() > 0) {
                buffer.append("Los cortes de perfil serán eliminados");
            }

            if (buffer.toString().length() > 0) {
                JOptionPane.showMessageDialog(null, buffer.toString(), "Información", JOptionPane.INFORMATION_MESSAGE);
                if (ld != null && ld.size() > 0) {
                    BaseDatos.eliminarDescuentoUnidadesByLineaPresupuesto(iid);
                }
                if (llcl != null && llcl.size() > 0) {
                    BaseDatos.eliminarCorteLonaByLineaPresupuesto(iid);
                }
                if (llcp != null && llcp.size() > 0) {
                    BaseDatos.eliminarCortePerfilByLineaPresupuesto(iid);
                }
            }
            
            if (this.bVisualizarDac.isVisible()) {
                calcularPrecioDac();
            } else {
                calcularPrecioArticulo();
            }
        }
    }
}//GEN-LAST:event_tMedida5FocusLost

    private void tcodigoKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tcodigoKeyReleased
        importe = 0D;

        if (evt.getKeyChar() == KeyEvent.VK_ENTER) {
            tcodigo.setPopupVisible(false);
            String sCodigo = (String) tcodigo.getSelectedItem();
            if (sCodigo.length() > 0) {
                String codigoArticulo = "";
                String codigoCaracteristica = "";

                if (sCodigo.contains("/")) {
                    codigoArticulo = sCodigo.substring(0, sCodigo.indexOf('/'));
                    codigoCaracteristica = sCodigo.substring(sCodigo.indexOf('/') + 1);
                } else {
                    codigoArticulo = sCodigo;
                }

                Articulo artT = BaseDatos.obtenerArticulo(codigoArticulo, e.getIid());
                Colores colorT = null;
                Caracteristica cT = null;
                boolean operacionOK = true;

                if (artT == null) {
                    //Error, el articulo no existe
                    tcodigo.setForeground(Color.RED);
                    tdescripcion.setText("El artículo introducido no existe");
                    operacionOK = false;
                    mostrarBotonVerDac(false);
                } else {
                    List listaC = BaseDatos.getListaCaracteristicas(e, artT);
                    if (listaC != null && listaC.size() > 0) {
                        if (codigoCaracteristica.length() == 0) {
                            //Error
                            tdescripcion.setText("El artículo introducido tiene características");
                            operacionOK = false;
                        } else {
                            //Ok
                            colorT = BaseDatos.obtenerColor(codigoCaracteristica);
                            if (colorT == null) {
                                //Error
                                tdescripcion.setText("La característica introducida no existe");
                                operacionOK = false;
                            } else {
                                cT = BaseDatos.obtenerCaracteristica(artT, e, colorT);
                                if (cT == null) {
                                    //Error
                                    tdescripcion.setText("La característica introducida no existe");
                                    operacionOK = false;
                                }
                            }
                        }
                    } else {
                        if (codigoCaracteristica.length() > 0) {
                            //Error
                            tdescripcion.setText("El artículo introducido no tiene características");
                            operacionOK = false;
                        } else {
                            //Ok
                            colorT = null;
                            cT = null;
                        }
                    }

                    if (operacionOK) {
                        this.a = artT;
                        this.car = cT;
                        tdescripcion.setText("");
                        Dac dac = BaseDatos.obtenerDacPorCodigoArticulo(codigoArticulo, e.getIid());
                        if (dac != null) {
                            RellenarDac rdac = new RellenarDac(this, e, dac, car, "Titulo");
                            rdac.setDefaultCloseOperation(RellenarDac.DISPOSE_ON_CLOSE);
                            rdac.setLocationRelativeTo(null);
                            rdac.setVisible(true);
                        } else {
                            borrarRDAC(getCodigo());
                            insertarArticulo(artT, cT);
                            anadirLineaDocumento();
                            FamiliaVenta fv = BaseDatos.obtenerFamiliaVentaPorIid(artT.getIid_fam_venta().getIid());
                            TipoControl tc = BaseDatos.obtenerTipoControlPorIid(fv.getIid_tipo_control().getIid());
                            setNumMedidas(tc.getIid_tipo_medida().getNum_dimensiones());
                            mostrarBotonVerDac(false);
                        }
                    } else {
                        tcodigo.setForeground(Color.red);
                        tCantidad.setText("");
                        tMedida1.setText("");
                        tMedida2.setText("");
                        tMedida3.setText("");
                        tMedida4.setText("");
                        tMedida5.setText("");
                        tmedidaResultado.setText("");
                        tPrecio.setText("");
                        tDescuento.setText("");
                        timporte.setText("");
                        mostrarBotonVerDac(false);
                    }
                }
            }
            p.calcularPrecio(false);
        } else if (evt.getKeyCode() == 34) {
            codigos = BaseDatos.busquedaRapidaArticuloPorCodigo((String) tcodigo.getEditor().getItem(), e.getIid());
            DefaultComboBoxModel modelo = new DefaultComboBoxModel();
            String cadenaEscrita = tcodigo.getEditor().getItem().toString();
            Iterator i = codigos.iterator();
            if (evt.getKeyCode() != 8) {
                Articulo aa;
                List lcaracteristicas;
                Iterator<Caracteristica> iC;
                while (i.hasNext()) {
                    aa = (Articulo) i.next();
                    lcaracteristicas = BaseDatos.getListaCaracteristicas(e, aa);
                    iC = lcaracteristicas.iterator();
                    if ((lcaracteristicas != null) && (lcaracteristicas.size() > 0)) {
                        while (iC.hasNext()) {
                            Colores co = BaseDatos.obtenerColorPorIid(iC.next().getIid_color().getIid());
                            modelo.addElement(aa.getCod_articulo() + "/" + co.getCod_color());
                        }
                    } else {
                        modelo.addElement(aa.getCod_articulo());
                    }
                }
                tcodigo.setModel(modelo);

                if (tcodigo.getItemCount() > 0) {
                    tcodigo.showPopup();
                    ((JTextComponent) tcodigo.getEditor().getEditorComponent()).select(cadenaEscrita.length(), tcodigo.getEditor().getItem().toString().length());
                } else {
                    tcodigo.getEditor().setItem(cadenaEscrita);
                }
            } else {
                tcodigo.addItem(cadenaEscrita);
            }
        }
    }//GEN-LAST:event_tcodigoKeyReleased

    protected String getMedidasStrHT(RellenarDac rd) {
        String res = "";

        if (tMedida1.getText() != null && tMedida1.getText().length() > 0) {
            res += tMedida1.getText() + rd.getMagnitud1();
        }

        if (tMedida2.getText() != null && tMedida2.getText().length() > 0) {
            res += " x " + tMedida2.getText() + rd.getMagnitud2();
        }

        if (tMedida3.getText() != null && tMedida3.getText().length() > 0) {
            res += " x " + tMedida3.getText() + rd.getMagnitud3();
        }

        if (tMedida4.getText() != null && tMedida4.getText().length() > 0) {
            res += " x " + tMedida4.getText() + rd.getMagnitud4();
        }

        if (tMedida5.getText() != null && tMedida5.getText().length() > 0) {
            res += " x " + tMedida5.getText() + rd.getMagnitud5();
        }

        return res;
    }
    
    protected String getMedidasStr(RellenarDac rd) {
        String res = "";

        if (tMedida1.getText() != null && tMedida1.getText().length() > 0 && tMedida1.isEnabled()) {
            res += tMedida1.getText() + rd.getMagnitud1();
        }

        if (tMedida2.getText() != null && tMedida2.getText().length() > 0 && tMedida2.isEnabled()) {
            res += " x " + tMedida2.getText() + rd.getMagnitud2();
        }

        if (tMedida3.getText() != null && tMedida3.getText().length() > 0 && tMedida3.isEnabled()) {
            res += " x " + tMedida3.getText() + rd.getMagnitud3();
        }

        if (tMedida4.getText() != null && tMedida4.getText().length() > 0 && tMedida4.isEnabled()) {
            res += " x " + tMedida4.getText() + rd.getMagnitud4();
        }

        if (tMedida5.getText() != null && tMedida5.getText().length() > 0 && tMedida5.isEnabled()) {
            res += " x " + tMedida5.getText() + rd.getMagnitud5();
        }

        return res;
    }

    protected String getDimensionesStr() {
        String res = "";

        if (a != null) {
            FamiliaVenta fv = BaseDatos.obtenerFamiliaVentaPorIid(a.getIid_fam_venta().getIid());
            TipoControl tc = BaseDatos.obtenerTipoControlPorIid(fv.getIid_tipo_control().getIid());

            if (tc.getUnidad1() != null && tc.getUnidad1().getNombre() != null && tc.getUnidad1().getNombre().length() > 0) {
                res += tc.getUnidad1().getNombre();
            }
            if (tc.getUnidad2() != null && tc.getUnidad2().getNombre() != null && tc.getUnidad2().getNombre().length() > 0) {
                res += " x " + tc.getUnidad2().getNombre();
            }
            if (tc.getUnidad3() != null && tc.getUnidad3().getNombre() != null && tc.getUnidad3().getNombre().length() > 0) {
                res += " x " + tc.getUnidad3().getNombre();
            }
            if (tc.getUnidad4() != null && tc.getUnidad4().getNombre() != null && tc.getUnidad4().getNombre().length() > 0) {
                res += " x " + tc.getUnidad4().getNombre();
            }
            if (tc.getUnidad5() != null && tc.getUnidad5().getNombre() != null && tc.getUnidad5().getNombre().length() > 0) {
                res += " x " + tc.getUnidad5().getNombre();
            }
        }
        return res;
    }

    private void calcularPrecioArticulo() {
        ScriptEngineManager manager = new ScriptEngineManager();
        ScriptEngine engine = manager.getEngineByName("js");
        String scantidad;
        String sprecio;
        String sdescuento;

        if (tCantidad.getText().length() == 0 || tCantidad.getText().equals("-")) {
            scantidad = "0";
        } else {
            scantidad = Util.convertirComaAPunto(tCantidad.getText());
        }

        if (tPrecio.getText().length() == 0) {
            sprecio = "0";
        } else {
            sprecio = Util.convertirComaAPunto(tPrecio.getText());
        }

        if (tDescuento.getText().length() == 0) {
            sdescuento = "0";
        } else {
            sdescuento = Util.convertirComaAPunto(tDescuento.getText());
        }

        if (scantidad.length() > 0 && sprecio.length() > 0) {
            try {
                if (sdescuento.length() == 0) {
                    sdescuento = "0";
                }
                if (sprecio.length() == 0) {
                    sprecio = "0";
                }
                if (scantidad.length() == 0) {
                    scantidad = "0";
                }
                cantidad = Double.valueOf(scantidad);
                float fprecio = Float.valueOf(sprecio);
                              
                //Descuento de interlocutor
                Double desI = p.descuentoInterlocutor(a);
                if (desI != null && desI != 0.0D) {
                    //En el caso que tenga descuento lo aplicamos
                    fprecio = fprecio - (fprecio * Float.parseFloat(desI.toString()));
                    
                }
                //Iva interlocutor
                float ivaF = p.calcularIvaInterlocutor();
                if (ivaF != 0.0F) {
                    //En el caso que tenga IVA lo aplicamos
                    fprecio = fprecio + (fprecio * ivaF);
                }
                //Actualizar precio String
                sprecio = Float.toString(fprecio);
                //Añadir formula                                
                String formula = p.obtenerFormula(a.getIid_fam_venta());
                if (formula != null && !formula.isEmpty()) {
                    //Sustituir pvp por el precio real
                    formula = formula.replace("pvp", sprecio);
                    fprecio = (Float) Float.parseFloat(engine.eval(formula).toString());
                    fprecio = matematico.Matematico.redondear2decimales(fprecio);
                    tPrecio.setText(Util.convertirPuntoAComa(String.valueOf(fprecio)));
                }

                if (sdescuento.length() > 0) {
                    descuento = Double.valueOf(sdescuento);
                }

                engine.put("Dim1", Util.convertirComaAPunto(tMedida1.getText()));
                engine.put("Dim2", Util.convertirComaAPunto(tMedida2.getText()));
                engine.put("Dim3", Util.convertirComaAPunto(tMedida3.getText()));
                engine.put("Dim4", Util.convertirComaAPunto(tMedida4.getText()));
                engine.put("Dim5", Util.convertirComaAPunto(tMedida5.getText()));

                FamiliaVenta fv = BaseDatos.obtenerFamiliaVentaPorIid(a.getIid_fam_venta().getIid());
                TipoControl tc = BaseDatos.obtenerTipoControlPorIid(fv.getIid_tipo_control().getIid());

                TipoMedida tm = tc.getIid_tipo_medida();
                String tipoCalculo = tm.getTipo_calculo();
                Float medidaTotal;

                if (tipoCalculo.equals(Constantes.FORMULA)) {
                    medidaTotal = Float.parseFloat(String.valueOf((Double) engine.eval(tm.getFormula())));
                } else {
                    medidaTotal = Float.parseFloat(Util.convertirComaAPunto(tMedida1.getText())) / 100;
                }

                tmedidaResultado.setText(Util.convertirPuntoAComa(String.valueOf(medidaTotal)));

                if (a.getEscalado() || a.getEscaladoCaracteristica()) {
                    medidaTotal = 1F;
                }

                precio = matematico.Matematico.redondear2decimales(cantidad * fprecio * medidaTotal * (100 - descuento) / 100);
                timporte.setText(Util.convertirPuntoAComa(String.valueOf(precio)));
                importe = precio;
                p.calcularPrecio(false);

            } catch (Exception ex) {
                timporte.setText("");
                importe = 0d;
                this.precio = 0d;
                p.calcularPrecio(false);
                //Error, los campos numéricos no contienen números
            }
        } else {
            timporte.setText("");
            importe = 0d;
            this.precio = 0d;
            p.calcularPrecio(false);
        }
    }

    public void calcularPrecioDac() {
        ScriptEngine engine = new ScriptEngineManager().getEngineByName("js");
        String scantidad;
        String sprecio;
        String sdescuento;

        if (tCantidad.getText().length() == 0 || tCantidad.getText().equals("-")) {
            scantidad = "0";
        } else {
            scantidad = Util.convertirComaAPunto(tCantidad.getText());
        }

        if (tPrecio.getText().length() == 0) {
            sprecio = "0";
        } else {
            sprecio = Util.convertirComaAPunto(tPrecio.getText());
        }

        if (tDescuento.getText().length() == 0) {
            sdescuento = "0";
        } else {
            sdescuento = Util.convertirComaAPunto(tDescuento.getText());
        }

        if (scantidad.length() > 0 && sprecio.length() > 0) {
            try {
                if (sdescuento.length() == 0) {
                    sdescuento = "0";
                }
                if (sprecio.length() == 0) {
                    sprecio = "0";
                }
                if (scantidad.length() == 0) {
                    scantidad = "0";
                }
                cantidad = Double.valueOf(scantidad);

                if (!sdescuento.equals("")) {
                    descuento = Double.valueOf(sdescuento);
                }

                engine.put("Dim1", Util.convertirComaAPunto(tMedida1.getText()));
                engine.put("Dim2", Util.convertirComaAPunto(tMedida2.getText()));
                engine.put("Dim3", Util.convertirComaAPunto(tMedida3.getText()));
                engine.put("Dim4", Util.convertirComaAPunto(tMedida4.getText()));
                engine.put("Dim5", Util.convertirComaAPunto(tMedida5.getText()));

                FamiliaVenta fv = a.getIid_fam_venta();
                fv = BaseDatos.obtenerFamiliaVentaPorIid(fv.getIid());
                TipoControl tc = BaseDatos.obtenerTipoControlPorIid(fv.getIid_tipo_control().getIid());
                TipoMedida tm = BaseDatos.obtenerTipoMedidaByIid(tc.getIid_tipo_medida().getIid());
                String tipoCalculo = tm.getTipo_calculo();
                Float medidaTotal;

                if (tipoCalculo.equals(Constantes.FORMULA)) {
                    medidaTotal = Float.parseFloat(String.valueOf((Double) engine.eval(tm.getFormula())));
                } else {
                    medidaTotal = Float.parseFloat(Util.convertirComaAPunto(tMedida1.getText())) / 100;
                }

                tmedidaResultado.setText(Util.convertirPuntoAComa(String.valueOf(medidaTotal)));

                if (a.getEscalado() || a.getEscaladoCaracteristica()) {
                    medidaTotal = 1F;
                }

                precio = medidaTotal.doubleValue() * calcularPrecioEscalado().doubleValue();
                //Obtener formula de interlocutor
                
                //Descuento de interlocutor
                Double desI = p.descuentoInterlocutor(a);
                if (desI != null && desI != 0.0D) {
                    //En el caso que tenga descuento lo aplicamos
                    precio = precio - (precio * Float.parseFloat(desI.toString()));
                }
                //Iva interlocutor
                float ivaF = p.calcularIvaInterlocutor();
                if (ivaF != 0.0F) {
                    //En el caso que tenga IVA lo aplicamos
                    precio = precio + (precio * ivaF);
                }
                precio = precio * cantidad / Math.abs(cantidad);
                
                sprecio = Double.toString(matematico.Matematico.redondear2decimales(precio));
                //Añadir formula                                
                String formula = p.obtenerFormula(a.getIid_fam_venta());
                if (formula != null && !formula.isEmpty()) {
                    //Sustituir pvp por el precio real
                    formula = formula.replace("pvp", sprecio);
                    precio = (Double) Double.parseDouble(engine.eval(formula).toString());
                    tPrecio.setText(Util.convertirPuntoAComa(String.valueOf(precio)));
                }           

                RellenarDac rd = p.getRellenarDac(codigo);
                Dac dac = rd.getDacBase();

                if (this.tMedida1.getText() != null && this.tMedida1.getText().length() > 0) {
                    dac.setMedida1(Double.parseDouble(Util.convertirComaAPunto(this.tMedida1.getText())));
                } else {
                    dac.setMedida1(0D);
                }

                if (this.tMedida2.getText() != null && this.tMedida2.getText().length() > 0) {
                    dac.setMedida2(Double.parseDouble(Util.convertirComaAPunto(this.tMedida2.getText())));
                } else {
                    dac.setMedida2(0D);
                }

                if (this.tMedida3.getText() != null && this.tMedida3.getText().length() > 0) {
                    dac.setMedida3(Double.parseDouble(Util.convertirComaAPunto(this.tMedida3.getText())));
                } else {
                    dac.setMedida3(0D);
                }

                if (this.tMedida4.getText() != null && this.tMedida4.getText().length() > 0) {
                    dac.setMedida4(Double.parseDouble(Util.convertirComaAPunto(this.tMedida4.getText())));
                } else {
                    dac.setMedida4(0D);
                }

                if (this.tMedida5.getText() != null && this.tMedida5.getText().length() > 0) {
                    dac.setMedida5(Double.parseDouble(Util.convertirComaAPunto(this.tMedida5.getText())));
                } else {
                    dac.setMedida5(0D);
                }

                rd.setDacBase(dac);
                rd = new RellenarDac(rd, p, "Titulo");
                rd.setMedida1(tMedida1.getText());
                rd.setMedida2(tMedida2.getText());
                rd.setMedida3(tMedida3.getText());
                rd.setMedida4(tMedida4.getText());
                rd.setMedida5(tMedida5.getText());
                
                List<Despiece> lista = rd.getListaDespiece();
                Iterator<Despiece> iter = lista.iterator();
                while (iter.hasNext()) {
                    precio += rd.calcularPrecioDespiece(iter.next(),desI,ivaF,p);
                }

                precio = ( precio * (100 - descuento) / 100 ) * cantidad;
                if(cantidad < 0){
                    precio = -precio;
                }
                
                rd.dispose();
                rd = null;
                System.gc();

                precio = matematico.Matematico.redondear2decimales(precio);
                //Añadir formula
                timporte.setText(Util.convertirPuntoAComa(String.valueOf(precio)));
                importe = precio;
                p.calcularPrecio(false);
            } catch (Exception ex) {
                ex.printStackTrace();
                timporte.setText("");
                importe = 0d;
                this.precio = 0d;
                p.calcularPrecio(false);
                //Error, los campos numéricos no contienen números
            }
        } else {
            timporte.setText("");
            importe = 0d;
        }
    }

    protected void anadirLineaDocumento() {
        if (isUltimoPanel()) {
            p.anadirLineaPresupuesto();
        }
        //Comprobamos si el precio es manual, para establecer el color rojo
        if (manual) {
            timporte.setForeground(Color.red);
        }
    }

    public String getTcantidad() {
        return tCantidad.getText();
    }

    public String getTMedida1() {
        return tMedida1.getText();
    }

    public String getTMedida2() {
        return tMedida2.getText();
    }

    public String getTMedida3() {
        return tMedida3.getText();
    }

    public String getTMedida4() {
        return tMedida4.getText();
    }

    public String getTMedida5() {
        return tMedida5.getText();
    }

    public String getTCodigo() {
        return (String) tcodigo.getSelectedItem();
    }

    public String getDescripcion() {
        return tdescripcion.getText();
    }

    private Float calcularPrecioEscalado() {
        Float res = 0F;
        Float fMedida1 = -1F;
        Float fMedida2 = -1F;
        if (tMedida1.getText().length() > 0) {
            fMedida1 = Float.parseFloat(Util.convertirComaAPunto(tMedida1.getText()));
        }
        if (tMedida2.getText().length() > 0) {
            fMedida2 = Float.parseFloat(Util.convertirComaAPunto(tMedida2.getText()));
        }

        if (a.getEscalado()) {
            res = BaseDatos.obtenerPrecioEscalado(a.getIid(), null, fMedida1.intValue(), fMedida2.intValue());
        } else if (a.getEscaladoCaracteristica()) {
            res = BaseDatos.obtenerPrecioEscalado(a.getIid(), car.getIid(), fMedida1.intValue(), fMedida2.intValue());
        } else {
            Precios prec;
            if (car != null) {
                //Se obtiene el precio de artículo por la tabla y la fecha de creación
                Date fecha = new Date();
                Date fini = new Date(0);
                if (this.p.fechaD !=null && !this.p.fechaD.equals(fini.getTime())){
                    fecha = new Date(this.p.fechaD.getTime());
                }
                    
                prec = BaseDatos.obtenerPrecioActivoFecha(e, a, car.getIid_color().getIid(), fecha.getTime());
                //Para evitar fallos de artículos antiguos
                if(prec!=null){
                    res = prec.getPvp();
                }else if (car.getPvp() != null) {
                    res = car.getPvp();
                }else{
                    res = 0F;
                }
            } else {
                Date fecha = new Date();
                if (this.p.fechaD!=null && this.p.fechaD.getTime()!= 0){
                    fecha = new Date(this.p.fechaD.getTime());
                }
                    
                prec = BaseDatos.obtenerPrecioActivoFecha(e, a, 0, fecha.getTime());
                //Para evitar fallos de artículos antiguos
                if(prec!=null){
                    res = prec.getPvp();
                }else if (car.getPvp() != null) {
                    res = car.getPvp();
                }else{
                    res = 0F;
                }
            }
        }
        return res;
    }

    protected void insertarArticulo(Articulo ar, Caracteristica c) {
        isDac = false;
        insertarElemento(ar, c);
        if (tCantidad.getText() == null || tCantidad.getText().length() == 0) {
            tCantidad.setText("0");
        }
        calcularPrecioArticulo();
    }

    protected void insertarRellenarDac(RellenarDac rdac) {
        isDac = true;
        this.listaDespiece = rdac.getListaDespiece();
        tCantidad.setText(rdac.getCantidad());
        this.cantidad = Double.parseDouble(Util.convertirComaAPunto(tCantidad.getText()));
        tMedida1.setText(rdac.getDim1().toString());
        tMedida2.setText(rdac.getDim2().toString());
        tMedida3.setText(rdac.getDim3().toString());
        tMedida4.setText(rdac.getDim4().toString());
        tMedida5.setText(rdac.getDim5().toString());
        insertarElementoDac(rdac.getDac(), rdac.getArticulo(), rdac.getCaracteristica(), listaDespiece, rdac);
        calcularPrecioDac();
    }

    private void insertarElementoDac(Dac dac, Articulo ar, Caracteristica c, List<Despiece> listaDespiece, RellenarDac rdac) {
        a = ar;
        car = c;
        FamiliaVenta fv = a.getIid_fam_venta();
        fv = BaseDatos.obtenerFamiliaVentaPorIid(fv.getIid());
        TipoControl tc = BaseDatos.obtenerTipoControlPorIid(fv.getIid_tipo_control().getIid());
        TipoMedida tm = BaseDatos.obtenerTipoMedidaByIid(tc.getIid_tipo_medida().getIid());
        numMedidas = tm.getNum_dimensiones();
        String codigoArticulo = ar.getCod_articulo();
        if (c != null) {
            codigoArticulo += "/" + c.getIid_color().getCod_color();
        }
        tcodigo.setSelectedItem(codigoArticulo);
        tPrecio.setText(Util.convertirPuntoAComa(String.valueOf(calcularPrecioEscalado())));

        if (p.getTipoDocumento().toLowerCase().contains("pedido")) {
            tdescripcion.setText(a.getDes_tecnica());
        } else {
            tdescripcion.setText(a.getDes_inf());
        }

        //Se ha de calcular el descuento segun la siguiente prioridad:
        //1.- Se usará el descuento que el cliente tenga para ese articulo
        //2.- Se usará el descuento que el cliente tenga para esa familia
        //3.- Se usará el descuento qeu el articulo tenga en si

        String codigoAgente = p.getCodigoCliente();
        if (codigoAgente != null && codigoAgente.length() > 0) {
            Agentes ag = BaseDatos.obtenerAgentePorEmpresaYCodigo(e.getIid(), codigoAgente);
            if (ag != null) {
                DescuentoClienteArticulo dca = BaseDatos.obtenerDescuentoClienteArticulo(ag.getIid(), ar.getIid());
                if (dca != null) {
                    //Se toma el descuento del cliente
                    this.tDescuento.setText(dca.getDescuento().toString());
                } else {
                    DescuentoClienteFamiliaVenta dcfv = BaseDatos.obtenerDescuentoClienteFamiliaVenta(ag.getIid(), ar.getIid_fam_venta().getIid());
                    if (dcfv != null) {
                        //Se toma el descuento de la familia
                        this.tDescuento.setText(dcfv.getDescuento().toString());
                    } else {
                        //Se toma el descuento del articulo
                        if (ar.getDescuento() != null) {
                            this.tDescuento.setText(ar.getDescuento().toString());
                        }
                    }
                }
            } else {
                //Se toma el descuento del articulo
                if (ar.getDescuento() != null) {
                    this.tDescuento.setText(ar.getDescuento().toString());
                }
            }
        } else {
            //Se toma el descuento del articulo;
            if (ar.getDescuento() != null) {
                this.tDescuento.setText(ar.getDescuento().toString());
            }
        }

        //Creamos los ToolTipText de cada unidad de medida
        if (tc.getUnidad1() != null) {
            tMedida1.setToolTipText(tc.getUnidad1().getNombre());
        }
        if (tc.getUnidad2() != null) {
            tMedida2.setToolTipText(tc.getUnidad2().getNombre());
        }
        if (tc.getUnidad3() != null) {
            tMedida3.setToolTipText(tc.getUnidad3().getNombre());
        }
        if (tc.getUnidad4() != null) {
            tMedida4.setToolTipText(tc.getUnidad4().getNombre());
        }
        if (tc.getUnidad5() != null) {
            tMedida5.setToolTipText(tc.getUnidad5().getNombre());
        }
        p.insertarRDAC(codigo, rdac);
    }

    private void insertarElemento(Articulo ar, Caracteristica c) {
        a = ar;
        car = c;
        //Obtener dimensiones
        FamiliaVenta fv = BaseDatos.obtenerFamiliaVentaPorIid(a.getIid_fam_venta().getIid());
        TipoControl tc = BaseDatos.obtenerTipoControlPorIid(fv.getIid_tipo_control().getIid());
        TipoMedida tm = BaseDatos.obtenerTipoMedidaByIid(tc.getIid_tipo_medida().getIid());
        numMedidas = tm.getNum_dimensiones();
        String codigoArticulo = ar.getCod_articulo();

        if (c != null) {
            codigoArticulo += "/" + c.getIid_color().getCod_color();
        }
        tcodigo.setSelectedItem(codigoArticulo);
        tPrecio.setText(Util.convertirPuntoAComa(String.valueOf(calcularPrecioEscalado())));

        if (p.getTipoDocumento().toLowerCase().contains("pedido")) {
            tdescripcion.setText(a.getDes_tecnica());
        } else {
            tdescripcion.setText(a.getDes_inf());
        }

        //Se ha de calcular el descuento segun la siguiente prioridad:
        //1.- Se usará el descuento que el cliente tenga para ese articulo
        //2.- Se usará el descuento que el cliente tenga para esa familia
        //3.- Se usará el descuento qeu el articulo tenga en si
        String codigoAgente = p.getCodigoCliente();
        if (codigoAgente != null && codigoAgente.length() > 0) {
            Object[] agenteReducido = BaseDatos.obtenerAgentePorEmpresaYCodigoPresupuestoReducido(e.getIid(), codigoAgente);
            if (agenteReducido != null) {
                DescuentoClienteArticulo dca = BaseDatos.obtenerDescuentoClienteArticulo((Integer) agenteReducido[3], ar.getIid());
                if (dca != null) {
                    //Se toma el descuento del cliente
                    this.tDescuento.setText(Util.convertirPuntoAComa(dca.getDescuento().toString()));
                } else {
                    DescuentoClienteFamiliaVenta dcfv = BaseDatos.obtenerDescuentoClienteFamiliaVenta((Integer) agenteReducido[3], ar.getIid_fam_venta().getIid());
                    if (dcfv != null) {
                        //Se toma el descuento de la familia
                        this.tDescuento.setText(Util.convertirPuntoAComa(dcfv.getDescuento().toString()));
                    } else {
                        //Se toma el descuento del articulo
                        if (ar.getDescuento() != null) {
                            this.tDescuento.setText(Util.convertirPuntoAComa(ar.getDescuento().toString()));
                        }
                    }
                }
            } else {
                //Se toma el descuento del articulo
                if (ar.getDescuento() != null) {
                    this.tDescuento.setText(Util.convertirPuntoAComa(ar.getDescuento().toString()));
                }
            }
        } else {
            //Se toma el descuento del articulo;
            if (ar.getDescuento() != null) {
                this.tDescuento.setText(Util.convertirPuntoAComa(ar.getDescuento().toString()));
            }
        }

        //Creamos los ToolTipText de cada unidad de medida
        if (tc.getUnidad1() != null) {
            tMedida1.setToolTipText(tc.getUnidad1().getNombre());
        }
        if (tc.getUnidad2() != null) {
            tMedida2.setToolTipText(tm.getNombre_dim_2());
        }
        if (tc.getUnidad3() != null) {
            tMedida3.setToolTipText(tm.getNombre_dim_3());
        }
        if (tc.getUnidad4() != null) {
            tMedida4.setToolTipText(tm.getNombre_dim_4());
        }
        if (tc.getUnidad5() != null) {
            tMedida5.setToolTipText(tm.getNombre_dim_5());
        }
    }

    private boolean isUltimoPanel() {
        return codigo == p.getNumArticulos();
    }

    public void mostrarBotonVerDac(boolean mostrar) {
        bVisualizarDac.setVisible(mostrar);
        bdetalle.setVisible(mostrar);
        
        if (p.getTipoDocumento().equals(Constantes.PEDIDO)) {
            bVisualizarCL.setVisible(mostrar);
            bVisualizarHT.setVisible(mostrar);
        }
    }

    public void ocultarTodo() {
        tCantidad.setVisible(false);
        bborrar.setVisible(false);
        this.tcodigo.setVisible(false);
        this.jScrollPane1.setVisible(false);
        bseleccionArticulo.setVisible(false);
        this.bVisualizarCL.setVisible(false);
        this.bVisualizarDac.setVisible(false);
        this.bdetalle.setVisible(false);
        this.bVisualizarHT.setVisible(false);
        tMedida1.setVisible(false);
        tMedida2.setVisible(false);
        tMedida3.setVisible(false);
        tMedida4.setVisible(false);
        tMedida5.setVisible(false);
        tmedidaResultado.setVisible(false);
        tDescuento.setVisible(false);
        tPrecio.setVisible(false);
        ldto.setVisible(false);
        this.timporte.setVisible(false);
        jSeparator1.setVisible(false);
        jSeparator2.setVisible(false);
        jSeparator3.setVisible(false);
        jSeparator4.setVisible(false);
        jSeparator5.setVisible(false);
        lineaOculta = true;
    }

    public boolean getLineaOculta() {
        return lineaOculta;
    }

    private void mostrarCamposLineaArticulo(boolean isLineaArticulo) {
        jSeparator2.setVisible(isLineaArticulo);
        jSeparator3.setVisible(isLineaArticulo);
        jSeparator4.setVisible(isLineaArticulo);
        timporte.setVisible(isLineaArticulo);
        tPrecio.setVisible(isLineaArticulo);
        tDescuento.setVisible(isLineaArticulo);
        ldto.setVisible(isLineaArticulo);
        tmedidaResultado.setVisible(isLineaArticulo);
        tMedida1.setVisible(isLineaArticulo);
        tMedida2.setVisible(isLineaArticulo);
        tMedida3.setVisible(isLineaArticulo);
        tMedida4.setVisible(isLineaArticulo);
        tMedida5.setVisible(isLineaArticulo);
        tcodigo.setVisible(isLineaArticulo);
        bseleccionArticulo.setVisible(isLineaArticulo);
        this.bVisualizarDac.setVisible(isLineaArticulo);
        this.bdetalle.setVisible(isLineaArticulo);
        tCantidad.setVisible(isLineaArticulo);
    }

    public boolean esLineaCorrecta() {
        boolean res = true;
        String sCodigo = (String) tcodigo.getSelectedItem();

        if (sCodigo != null && sCodigo.length() > 0) {
            String codigoArticulo = "";
            String codigoCaracteristica = "";

            if (sCodigo.contains("/")) {
                codigoArticulo = sCodigo.substring(0, sCodigo.indexOf('/'));
                codigoCaracteristica = sCodigo.substring(sCodigo.indexOf('/') + 1);
            } else {
                codigoArticulo = sCodigo;
            }

            Articulo artT = BaseDatos.obtenerArticulo(codigoArticulo, e.getIid());
            Colores colorT = null;
            Caracteristica cT = null;

            if (artT == null) {
                //Error, el articulo no existe
                res = false;
            } else {
                List listaC = BaseDatos.getListaCaracteristicas(e, artT);
                if (listaC != null && listaC.size() > 0) {
                    if (codigoCaracteristica.length() == 0) {
                        res = false;
                    } else {
                        //Ok
                        colorT = BaseDatos.obtenerColor(codigoCaracteristica);
                        if (colorT == null) {
                            //Error
                            res = false;
                        } else {
                            cT = BaseDatos.obtenerCaracteristica(artT, e, colorT);
                            if (cT == null) {
                                //Error
                                res = false;
                            }
                        }
                    }
                } else {
                    if (!codigoCaracteristica.equals("")) {
                        //Error
                        res = false;
                    }
                }
            }
        }

        return res;
    }

    public NuevoPresupuesto getNuevoPresupuesto() {
        return p;
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bVisualizarCL;
    private javax.swing.JButton bVisualizarDac;
    private javax.swing.JButton bVisualizarHT;
    private javax.swing.JButton bborrar;
    private javax.swing.JButton bdetalle;
    private javax.swing.JButton bseleccionArticulo;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JSeparator jSeparator4;
    private javax.swing.JSeparator jSeparator5;
    private javax.swing.JLabel ldto;
    private javax.swing.JTextField tCantidad;
    private javax.swing.JTextField tDescuento;
    private javax.swing.JTextField tMedida1;
    private javax.swing.JTextField tMedida2;
    private javax.swing.JTextField tMedida3;
    private javax.swing.JTextField tMedida4;
    private javax.swing.JTextField tMedida5;
    private javax.swing.JTextField tPrecio;
    private javax.swing.JComboBox tcodigo;
    private javax.swing.JTextArea tdescripcion;
    public javax.swing.JTextField timporte;
    private javax.swing.JTextField tmedidaResultado;
    // End of variables declaration//GEN-END:variables
}
