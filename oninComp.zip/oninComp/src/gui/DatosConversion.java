package gui;

import acceso.BaseDatos;
import bean.Agentes;
import bean.Articulo;
import bean.Caracteristica;
import bean.ClaseDocumento;
import bean.Empresa;
import bean.EstadoDocumento;
import bean.LineaPresupuesto;
import bean.Metadata;
import bean.Presupuesto;
import bean.Usuario;
import bean.MovimientoAlmacen;
import bean.TipoMovimientoAlmacen;
import java.net.URL;
import java.util.Iterator;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import util.Constantes;
import bean.DacPresupuesto;
import bean.DescuentoClienteArticulo;
import bean.DescuentoClienteFamiliaVenta;
import bean.Despiece;
import bean.VariablePresupuesto;
import bean.SeleccionPresupuesto;
import bean.DespiecePresupuesto;
import bean.FamiliaVenta;
import bean.FormaPago2;
import bean.Interlocutor;
import bean.TipoControl;
import bean.TipoMedida;
import bean.UnidadMedida;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.Date;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.JComponent;
import javax.swing.KeyStroke;
import org.apache.log4j.Logger;
import util.Util;

public class DatosConversion extends javax.swing.JFrame {

    private Presupuesto p, pInicioRango, pFinalRango;
    private String tipo;
    private Empresa e;
    private Agentes a;
    private Usuario u;
    private ClaseDocumento cd;
    private Interlocutor in;
    private Agentes aI;
    private Empresa eI;
    private List formulas;
    private ListaDePresupuestos ldp;
    private static Logger log = Logger.getLogger(DatosConversion.class);

    public DatosConversion(Presupuesto p, String modo, Empresa e, Usuario u, ListaDePresupuestos ldp) {
        this(p, modo, e, u);
        this.ldp = ldp;
    }
    
    public DatosConversion(Presupuesto p, String modo, Empresa e, Usuario u) {
        super("Procesar...");
        this.e = e;
        
        this.p = p;
        this.u = u;
        this.cd = BaseDatos.getClaseDocumentosByIid(p.getClase_documento().getIid());
		this.tipo = cd.getDescripcion();
        initComponents();

        if (cd.getDescripcion().equals(Constantes.PEDIDOC)) {
            jLabel6.setText("Proveedor");
        }

        //this.bseleccion1.setEnabled(true);
        this.bseleccion2.setEnabled(false);
        this.bseleccion3.setEnabled(false);
        this.bseleccioncliente.setEnabled(false);
        
        //En el caso de que sea directamente del presupuesto preparamos la pantalla
        if (modo.equals("directo")) {
            this.rcompleto.setSelected(true);
            this.tdocumento.setText(this.p.getNumero());
            this.tdocumentofinal.setEnabled(false);
            this.tdocumentoini.setEnabled(false);
            this.tcliente.setEnabled(false);
        }

        crearIconosBotones();
        crearAcciones();
    }

    public DatosConversion(Interlocutor in, Agentes aI, Empresa eI, Presupuesto p, Empresa e) {
        super("Procesar...");
        this.in = in;
        this.aI = aI;
        this.eI = eI;
        this.p = p;
        this.e = e;
    }

    private void crearAcciones() {
        KeyStroke escapeKeyStroke = KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false);
        Action escapeAction = new AbstractAction() {
            public void actionPerformed(ActionEvent e) {
                cerrarListaDatosConversion();
            }
        };
        getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(escapeKeyStroke, "ESCAPE");
        getRootPane().getActionMap().put("ESCAPE", escapeAction);

        KeyStroke enterKeyStroke = KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0, false);
        Action enterAction;
        enterAction = new AbstractAction() {
            public void actionPerformed(ActionEvent e) {
                procesar();
            }
        };
        getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(enterKeyStroke, "ENTER");
        getRootPane().getActionMap().put("ENTER", enterAction);
    }

    private void cerrarListaDatosConversion() {
        removeAll();
        dispose();
    }
    
    protected void actualizarListadoDocumentos(){
        if(ldp != null){
            ldp.obtenerResultado();
        }
    }

    private void crearIconosBotones() {
        URL url;
	ImageIcon icono;
		
        url = getClass().getResource("/iconos/eliminar.png");
        icono = new ImageIcon(url);
        bCancelar.setIcon(icono);
        
        url = getClass().getResource("/iconos/anadir.png");
        icono = new ImageIcon(url);
        this.bseleccion1.setIcon(icono);
        this.bseleccion2.setIcon(icono);
        this.bseleccion3.setIcon(icono);
        this.bseleccioncliente.setIcon(icono);
        
        url = getClass().getResource("/iconos/convertir32.png");
        icono= new ImageIcon(url);
        bAceptar.setIcon(icono);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        tiposeleccion = new javax.swing.ButtonGroup();
        cSeries = new javax.swing.JComboBox();
        jLabel1 = new javax.swing.JLabel();
        bAceptar = new javax.swing.JButton();
        bCancelar = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        lpasar = new javax.swing.JComboBox();
        jPanel1 = new javax.swing.JPanel();
        rlinea = new javax.swing.JRadioButton();
        rcompleto = new javax.swing.JRadioButton();
        rvarios = new javax.swing.JRadioButton();
        jPanel2 = new javax.swing.JPanel();
        tdocumento = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        tdocumentoini = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        tdocumentofinal = new javax.swing.JTextField();
        bseleccion1 = new javax.swing.JButton();
        bseleccion2 = new javax.swing.JButton();
        bseleccion3 = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        tcliente = new javax.swing.JTextField();
        bseleccioncliente = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        cSeries.setModel(new javax.swing.DefaultComboBoxModel(new String[] { Constantes.SERIE_STD, Constantes.SERIE_SEC }));

        jLabel1.setText("Series:");

        bAceptar.setToolTipText("procesar...");
        bAceptar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bAceptarActionPerformed(evt);
            }
        });

        bCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bCancelarActionPerformed(evt);
            }
        });

        jLabel2.setText("Destino:");

        if (this.tipo.equals(Constantes.PRESUPUESTO)){
            lpasar.setModel(new javax.swing.DefaultComboBoxModel(new String[] {Constantes.PEDIDO , Constantes.ALBARAN}));
        }else if (this.tipo.equals(Constantes.PEDIDO)){
            lpasar.setModel(new javax.swing.DefaultComboBoxModel(new String[] {Constantes.ALBARAN}));
        } else if (this.tipo.equals(Constantes.ALBARAN)){
            lpasar.setModel(new javax.swing.DefaultComboBoxModel(new String[] {Constantes.FACTURA}));
        } else if (this.tipo.equals(Constantes.PEDIDOC)){
            lpasar.setModel(new javax.swing.DefaultComboBoxModel(new String[] {Constantes.ALBARANC}));
        } else if (this.tipo.equals(Constantes.ALBARANC)){
            lpasar.setModel(new javax.swing.DefaultComboBoxModel(new String[] {Constantes.FACTURAC}));
        } else if (this.tipo.equals(Constantes.FACTURA)){
            lpasar.setModel(new javax.swing.DefaultComboBoxModel(new String[] {Constantes.FACTURAA}));
        }

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder("Tipo de Selección"));

        tiposeleccion.add(rlinea);
        rlinea.setText("Selección por lineas");
        rlinea.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rlineaActionPerformed(evt);
            }
        });

        tiposeleccion.add(rcompleto);
        rcompleto.setText("Documento Completo");
        rcompleto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rcompletoActionPerformed(evt);
            }
        });

        tiposeleccion.add(rvarios);
        rvarios.setText("Varios Documentos");
        rvarios.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rvariosActionPerformed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout jPanel1Layout = new org.jdesktop.layout.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .add(rlinea)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(rvarios)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(rcompleto)
                .addContainerGap(32, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel1Layout.createSequentialGroup()
                .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(rlinea)
                    .add(rvarios)
                    .add(rcompleto))
                .addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder("Selección"));

        jLabel3.setText("Nº de Documento");

        jLabel4.setText("Documento Inicial");

        jLabel5.setText("Documento Final");

        bseleccion1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bseleccion1ActionPerformed(evt);
            }
        });

        bseleccion2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bseleccion2ActionPerformed(evt);
            }
        });

        bseleccion3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bseleccion3ActionPerformed(evt);
            }
        });

        jLabel6.setText("Cliente");

        bseleccioncliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bseleccionclienteActionPerformed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout jPanel2Layout = new org.jdesktop.layout.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jPanel2Layout.createSequentialGroup()
                        .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                            .add(jLabel5)
                            .add(jLabel4, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .add(jLabel3, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED, 170, Short.MAX_VALUE)
                        .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(tdocumento, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 89, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(tdocumentoini, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 89, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(tdocumentofinal, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 89, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                    .add(jPanel2Layout.createSequentialGroup()
                        .add(jLabel6, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 43, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(tcliente, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 296, Short.MAX_VALUE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)))
                .add(3, 3, 3)
                .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(bseleccion1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 35, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(bseleccion2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 35, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(bseleccioncliente, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 35, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(bseleccion3, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 35, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel2Layout.createSequentialGroup()
                .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(bseleccion1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 20, Short.MAX_VALUE)
                    .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                        .add(tdocumento, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(jLabel3)))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(bseleccioncliente, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 20, Short.MAX_VALUE)
                    .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                        .add(jLabel6)
                        .add(tcliente, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(bseleccion2, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 20, Short.MAX_VALUE)
                    .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                        .add(tdocumentoini, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(jLabel4)))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(bseleccion3, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 20, Short.MAX_VALUE)
                    .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                        .add(tdocumentofinal, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(jLabel5)))
                .addContainerGap())
        );

        org.jdesktop.layout.GroupLayout layout = new org.jdesktop.layout.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(layout.createSequentialGroup()
                .addContainerGap()
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(layout.createSequentialGroup()
                        .add(jLabel2)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(lpasar, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 147, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(35, 35, 35)
                        .add(jLabel1)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(cSeries, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 150, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                    .add(jPanel2, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .add(org.jdesktop.layout.GroupLayout.TRAILING, layout.createSequentialGroup()
                        .add(bAceptar, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 60, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(bCancelar, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 55, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                    .add(jPanel1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(layout.createSequentialGroup()
                .addContainerGap()
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(jLabel2)
                    .add(lpasar, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(jLabel1)
                    .add(cSeries, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .add(12, 12, 12)
                .add(jPanel1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(bAceptar, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 58, Short.MAX_VALUE)
                    .add(bCancelar, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 58, Short.MAX_VALUE))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

private void bCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bCancelarActionPerformed
    cerrarListaDatosConversion();
}//GEN-LAST:event_bCancelarActionPerformed

    public void rellenarCaja1(String valor) {
        this.tdocumento.setText(valor);
    }

    public void rellenarCaja2(String valor) {
        this.tdocumentoini.setText(valor);
    }

    public void rellenarCaja3(String valor) {
        this.tdocumentofinal.setText(valor);
    }

    private EstadoDocumento establecerEstado() {
        EstadoDocumento ed = null;
        String itemSeleccionado = (String) lpasar.getSelectedItem();
        if (itemSeleccionado.equals(Constantes.PEDIDO)) {
            ed = BaseDatos.obtenerEstadoDocumentoPorDesc(Constantes.PENDIENTE_FABRICACION);
        } else if (itemSeleccionado.equals(Constantes.ALBARAN) || lpasar.getSelectedItem().equals(Constantes.ALBARANC)) {
            ed = BaseDatos.obtenerEstadoDocumentoPorDesc(Constantes.PENDIENTE_FACTURA);
        } else if (itemSeleccionado.equals(Constantes.FACTURA)) {
            ed = BaseDatos.obtenerEstadoDocumentoPorDesc(Constantes.IMPAGADO);
        } else if (itemSeleccionado.equals(Constantes.FACTURAC) || lpasar.getSelectedItem().equals(Constantes.FACTURAA)) {
            ed = BaseDatos.obtenerEstadoDocumentoPorDesc(Constantes.DEVUELTO);
        }
        return ed;
    }
    
    private void procesarDocumentoCompleto() {
        String claseDocumento = (String) lpasar.getSelectedItem();
        ClaseDocumento cdN = BaseDatos.getClaseDocumentosByDescripcion(claseDocumento);
	String serie = (String) cSeries.getSelectedItem();
	Integer iidEmpresaI = null;
        
        //Comprobar si el documento ha cambiado
        if (!(this.tdocumento.getText().equals(p.getNumero()))) {
            this.p = BaseDatos.obtenerPresupuestoPorNumeroPorClaseDocumento(tdocumento.getText(), claseDocumento, e, p.getInterlocutor());
        }

        if (p!= null && p.getInterlocutor() != null && !p.getInterlocutor().equals(e.getIid())) {
            //Comprobar Interlocutor
            eI = BaseDatos.obtenerEmpresaPorIid(p.getInterlocutor());
            iidEmpresaI = eI.getIid();
            in = BaseDatos.obtenerInterlocutor(eI, e);
            aI = BaseDatos.obtenerAgenteByIid(in.getIidCliente().getIid());
            formulas = BaseDatos.obtenerInterFormulas(in);
        }

        Presupuesto nuevo = new Presupuesto();
        nuevo.setClase_documento(cdN);
        nuevo.setCifCliente(p.getCifCliente());
        nuevo.setReferencia(p.getReferencia());
        nuevo.setCodigoCliente(p.getCodigoCliente());

        if (claseDocumento.equals(Constantes.FACTURAC)) {
            a = BaseDatos.obtenerAgentesPorCodigo(p.getCodigoCliente(), "prov", e);
            if (a != null) {
                nuevo.setCpCliente(a.getCodigo_postal_fiscal().toString());
                nuevo.setDomicilioCliente(a.getDireccion_fiscal());
                nuevo.setLocalidadCliente(a.getPoblacion_fiscal());
                nuevo.setNombreCliente(a.getNombre_fiscal());
                nuevo.setProvinciaCliente(a.getProvincia_fiscal());
            } else {
                nuevo.setCpCliente(p.getCpCliente());
                nuevo.setDomicilioCliente(p.getDomicilioCliente());
                nuevo.setLocalidadCliente(p.getLocalidadCliente());
                nuevo.setNombreCliente(p.getNombreCliente());
                nuevo.setProvinciaCliente(p.getProvinciaCliente());
            }
        } else if (!claseDocumento.equals(Constantes.FACTURA)) {
            nuevo.setCpCliente(p.getCpCliente());
            nuevo.setDomicilioCliente(p.getDomicilioCliente());
            nuevo.setLocalidadCliente(p.getLocalidadCliente());
            nuevo.setNombreCliente(p.getNombreCliente());
            nuevo.setProvinciaCliente(p.getProvinciaCliente());
        } else {
            a = BaseDatos.obtenerAgentesPorCodigo(p.getCodigoCliente(), "cli", e);
            if (a != null) {
                nuevo.setCpCliente(a.getCodigo_postal_fiscal().toString());
                nuevo.setDomicilioCliente(a.getDireccion_fiscal());
                nuevo.setLocalidadCliente(a.getPoblacion_fiscal());
                nuevo.setNombreCliente(a.getNombre_fiscal());
                nuevo.setProvinciaCliente(a.getProvincia_fiscal());
            } else {
                nuevo.setCpCliente(p.getCpCliente());
                nuevo.setDomicilioCliente(p.getDomicilioCliente());
                nuevo.setLocalidadCliente(p.getLocalidadCliente());
                nuevo.setNombreCliente(p.getNombreCliente());
                nuevo.setProvinciaCliente(p.getProvinciaCliente());
            }
        }

        nuevo.setPaisCliente(p.getPaisCliente());
        nuevo.setTelefonoCliente(p.getTelefonoCliente());
        nuevo.setDesde_presupuesto(true);
        nuevo.setDto(p.getDto());
        nuevo.setPagado(p.getPagado());
        nuevo.setImpagado(p.getImpagado());
        nuevo.setPreparado(false);
        nuevo.setInstalado(false);
        nuevo.setConfeccionado(false);
        nuevo.setFabricado(false);
        nuevo.setEmpresa(BaseDatos.obtenerEmpresaPorIid(p.getEmpresa().getIid()));
        nuevo.setEstado(establecerEstado());
        nuevo.setFecha(p.getFecha());

        //DUDA: SE HA DE USAR LA MISMA FP O CREAR UNA NUEVA????
        //nuevo.setFp(p.getFp());
        FormaPago2 pfAux = BaseDatos.obtenerFormaPago2(p.getFp().getIid());
        nuevo.setFp(pfAux.copiar());

        if (claseDocumento.equals(Constantes.FACTURAA)) {
            nuevo.setImporte_total(-p.getImporte_total());
        } else {
            nuevo.setImporte_total(p.getImporte_total());
        }

        nuevo.setSerie(serie);
        nuevo.setNumero("");
        nuevo.setIva(p.getIva());
        nuevo.setConvertido(false);
        nuevo.setContactado(p.getContactado());
        nuevo.setComercial(p.getComercial());
        nuevo.setPorcentajeComercial(p.getPorcentajeComercial());
        nuevo.setAlmacen(p.getAlmacen());
        nuevo.setEmailCliente(p.getEmailCliente());
        if (claseDocumento.equals(Constantes.PEDIDO)) {
            nuevo.setFechaEntrega(p.getFecha());
        }
        nuevo.setInterlocutor(p.getInterlocutor());

        cd = BaseDatos.getClaseDocumentosByIid(p.getClase_documento().getIid());
	p.setClase_documento(cd);
        EstadoDocumento estadoDocumento = null;
        if (cd.getDescripcion().equals(Constantes.PEDIDOC)) {
            estadoDocumento = BaseDatos.obtenerEstadoDocumentoPorDesc(Constantes.PEDIDO_RECIBIDO);
        } else if (cd.getDescripcion().equals(Constantes.PRESUPUESTO)) {
            estadoDocumento = BaseDatos.obtenerEstadoDocumentoPorDesc(Constantes.ACEPTADO);
        } else if (cd.getDescripcion().equals(Constantes.PEDIDO)) {
            estadoDocumento = BaseDatos.obtenerEstadoDocumentoPorDesc(Constantes.FINALIZADO);
        } else if (cd.getDescripcion().equals(Constantes.ALBARAN)) {
            estadoDocumento = BaseDatos.obtenerEstadoDocumentoPorDesc(Constantes.FACTURADO);
        } else if (cd.getDescripcion().equals(Constantes.ALBARANC)) {
            estadoDocumento = BaseDatos.obtenerEstadoDocumentoPorDesc(Constantes.FACTURADO);
        } else if (cd.getDescripcion().equals(Constantes.FACTURA) || cd.getDescripcion().equals(Constantes.FACTURAC)) {
            estadoDocumento = BaseDatos.obtenerEstadoDocumentoPorDesc(Constantes.DEVUELTO);
        }
        
        if(estadoDocumento != null){
            p.setEstado(estadoDocumento);
        }
        
        //En el caso que sea Albarán y el interlocutor sea distinto a la empresa madre,
        //creamos el albaran entre EMPRESA MADRE Y EMPRESA HIJA
        Presupuesto presupuestoInterlocutor = null;
        if (claseDocumento.equals(Constantes.ALBARAN) && !e.getIid().equals(p.getInterlocutor())) {
            presupuestoInterlocutor = this.crearDocumentoInter(nuevo);
        }

        if (eI != null) {
            iidEmpresaI = eI.getIid();
        }
        
        nuevo = BaseDatos.convertirDocumentoCompleto(nuevo, p, presupuestoInterlocutor, u, aI, iidEmpresaI, serie, e);
        if (nuevo != null) {
            String mensajeGeneracion = obtenerMensajeGeneracionCorrecta(claseDocumento, nuevo.getNumero());			
            JOptionPane.showMessageDialog(null, mensajeGeneracion , "Convertido", JOptionPane.INFORMATION_MESSAGE);
            int ver = JOptionPane.showConfirmDialog(null, "¿Desea visualizar el documento generado?", "Visualizar", JOptionPane.YES_NO_OPTION);
            if (ver == 0 && (claseDocumento.equals(Constantes.ALBARANC) || claseDocumento.equals(Constantes.FACTURAC))) {
                NuevoCompras nc = new NuevoCompras(e, nuevo, this.u, cdN, null);
                nc.setDefaultCloseOperation(NuevoPresupuesto.DISPOSE_ON_CLOSE);
                nc.setLocationRelativeTo(null);
                nc.setVisible(true);
            } else if (ver == 0) {
                NuevoPresupuesto np = new NuevoPresupuesto(e, nuevo, this.u, null);
                np.setDefaultCloseOperation(NuevoPresupuesto.DISPOSE_ON_CLOSE);
                np.setLocationRelativeTo(null);
                np.setVisible(true);
            }
			
            if(this.ldp != null){
                ldp.obtenerResultado();
            }
            cerrarListaDatosConversion();
        } else {
            JOptionPane.showMessageDialog(null, "Conversión imposible de realizar", "Convertir", JOptionPane.ERROR_MESSAGE);
        }
    }
	
    public String obtenerMensajeGeneracionCorrecta(String claseDocumento, String numero) {
        String mensaje;
        if (claseDocumento.equals(Constantes.FACTURA) || claseDocumento.equals(Constantes.FACTURAA) || claseDocumento.equals(Constantes.FACTURAC)) {
            mensaje = "Conversión realizada con éxito. La " + claseDocumento + " " + numero + " ha sido generado";
        } else {
            mensaje = "Conversión realizada con éxito. El " + claseDocumento + " " + numero + " ha sido generado";
        }
        return mensaje;
    }

    protected String obtenerSerie() {
        return (String) cSeries.getSelectedItem();
    }

    protected String getClaseDocumento() {
        return (String) lpasar.getSelectedItem();
    }
    
    private void procesarDocumentoParcial() {
        String claseDocumento = (String) lpasar.getSelectedItem();
        ClaseDocumento cdN = BaseDatos.getClaseDocumentosByDescripcion(claseDocumento);
	Integer iidEmpresaI = null;

        if (!(this.tdocumento.getText().equals(p.getNumero()))) {
            this.p = BaseDatos.obtenerPresupuestoPorNumeroPorClaseDocumento(tdocumento.getText(), claseDocumento, e, p.getInterlocutor());
        }

        if (p.getInterlocutor() != null && !p.getInterlocutor().equals(e.getIid())) {
            eI = BaseDatos.obtenerEmpresaPorIid(p.getInterlocutor());
            iidEmpresaI = eI.getIid();
            in = BaseDatos.obtenerInterlocutor(eI, e);
            aI = BaseDatos.obtenerAgenteByIid(in.getIidCliente().getIid());
            formulas = BaseDatos.obtenerInterFormulas(in);
        }

        Presupuesto nuevo = new Presupuesto();
        nuevo.setClase_documento(cdN);
        nuevo.setCifCliente(p.getCifCliente());
        nuevo.setReferencia(p.getReferencia());
        nuevo.setCodigoCliente(p.getCodigoCliente());

        if (claseDocumento.equals(Constantes.FACTURAC)) {
            a = BaseDatos.obtenerAgentesPorCodigo(p.getCodigoCliente(), "prov", e);
            if (a != null) {
                nuevo.setCpCliente(a.getCodigo_postal_fiscal().toString());
                nuevo.setDomicilioCliente(a.getDireccion_fiscal());
                nuevo.setLocalidadCliente(a.getPoblacion_fiscal());
                nuevo.setNombreCliente(a.getNombre_fiscal());
                nuevo.setProvinciaCliente(a.getProvincia_fiscal());
            } else {
                nuevo.setCpCliente(p.getCpCliente());
                nuevo.setDomicilioCliente(p.getDomicilioCliente());
                nuevo.setLocalidadCliente(p.getLocalidadCliente());
                nuevo.setNombreCliente(p.getNombreCliente());
                nuevo.setProvinciaCliente(p.getProvinciaCliente());
            }
        } else if (!claseDocumento.equals(Constantes.FACTURA)) {
            nuevo.setCpCliente(p.getCpCliente());
            nuevo.setDomicilioCliente(p.getDomicilioCliente());
            nuevo.setLocalidadCliente(p.getLocalidadCliente());
            nuevo.setNombreCliente(p.getNombreCliente());
            nuevo.setProvinciaCliente(p.getProvinciaCliente());
        } else {
            a = BaseDatos.obtenerAgentesPorCodigo(p.getCodigoCliente(), "cli", e);
            if (a != null) {
                nuevo.setCpCliente(a.getCodigo_postal_fiscal().toString());
                nuevo.setDomicilioCliente(a.getDireccion_fiscal());
                nuevo.setLocalidadCliente(a.getPoblacion_fiscal());
                nuevo.setNombreCliente(a.getNombre_fiscal());
                nuevo.setProvinciaCliente(a.getProvincia_fiscal());
            } else {
                nuevo.setCpCliente(p.getCpCliente());
                nuevo.setDomicilioCliente(p.getDomicilioCliente());
                nuevo.setLocalidadCliente(p.getLocalidadCliente());
                nuevo.setNombreCliente(p.getNombreCliente());
                nuevo.setProvinciaCliente(p.getProvinciaCliente());
            }
        }

        nuevo.setPaisCliente(p.getPaisCliente());
        nuevo.setTelefonoCliente(p.getTelefonoCliente());
        nuevo.setDesde_presupuesto(true);
        nuevo.setDto(p.getDto());
        nuevo.setPagado(p.getPagado());
        nuevo.setImpagado(p.getImpagado());
        nuevo.setPreparado(false);
        nuevo.setInstalado(false);
        nuevo.setConfeccionado(false);
        nuevo.setFabricado(false);
        nuevo.setEmpresa(BaseDatos.obtenerEmpresaPorIid(p.getEmpresa().getIid()));
        nuevo.setEstado(establecerEstado());
        nuevo.setFecha(p.getFecha());
        //DUDA: SE HA DE USAR LA MISMA FP O CREAR UNA NUEVA????
        //nuevo.setFp(p.getFp());
        FormaPago2 pfAux = BaseDatos.obtenerFormaPago2(p.getFp().getIid());
        nuevo.setFp(pfAux.copiar());
        if (claseDocumento.equals(Constantes.FACTURAA)) {
            nuevo.setImporte_total(-p.getImporte_total());
        } else {
            nuevo.setImporte_total(p.getImporte_total());
        }

        nuevo.setSerie((String) cSeries.getSelectedItem());
        nuevo.setNumero("");
        nuevo.setIva(p.getIva());
        if(nuevo.getIva() != null){
            nuevo.setIva(BaseDatos.obtenerIvaPorIid(nuevo.getIva().getIid()));
        }
        nuevo.setConvertido(false);
        nuevo.setContactado(p.getContactado());
        nuevo.setComercial(p.getComercial());
        nuevo.setPorcentajeComercial(p.getPorcentajeComercial());
        nuevo.setAlmacen(p.getAlmacen());
        if(nuevo.getAlmacen() != null){
            nuevo.setAlmacen(BaseDatos.obtenerAlmacenById(nuevo.getAlmacen().getIid()));
        }
        nuevo.setEmailCliente(p.getEmailCliente());
        if (claseDocumento.equals(Constantes.PEDIDO)) {
            nuevo.setFechaEntrega(p.getFecha());
        }
        nuevo.setInterlocutor(p.getInterlocutor());

        //Llamar para interlocutor
        if (this.in == null) {
            ListaSeleccionLineas ls = new ListaSeleccionLineas(p, nuevo, u, e, this, iidEmpresaI);
            ls.setDefaultCloseOperation(DatosConversion.DISPOSE_ON_CLOSE);
            ls.setLocationRelativeTo(null);
            ls.setVisible(true);
        } else {
            //String numeroAi = "";
            //ListaSeleccionLineas ls = new ListaSeleccionLineas(p, nuevo, u, e, in, aI, eI, formulas, numeroAi, this, iidEmpresaI);
            //ls.setDefaultCloseOperation(DatosConversion.DISPOSE_ON_CLOSE);
            //ls.setLocationRelativeTo(null);
            //ls.setVisible(true);
        }
    }
    
    private void procesarVariosDocumentos() {
        String claseDocumento = (String) lpasar.getSelectedItem();
        ClaseDocumento claseDocumentoNuevo = BaseDatos.getClaseDocumentosByDescripcion(claseDocumento);
	Integer iidEmpresaI = null;

        if (p.getInterlocutor() != null && !p.getInterlocutor().equals(e.getIid())) {
            //Comprobar Interlocutor
            eI = BaseDatos.obtenerEmpresaPorIid(p.getInterlocutor());
            iidEmpresaI = eI.getIid();
            in = BaseDatos.obtenerInterlocutor(eI, e);
            aI = BaseDatos.obtenerAgenteByIid(in.getIidCliente().getIid());
            formulas = BaseDatos.obtenerInterFormulas(in);
        }

        Presupuesto nuevo = new Presupuesto();
        nuevo.setClase_documento(claseDocumentoNuevo);
        nuevo.setCifCliente(a.getCif_nif());
        nuevo.setCodigoCliente(a.getCod_agente());

        if (!cd.getDescripcion().equals(Constantes.FACTURA)) {
            nuevo.setCpCliente(a.getCodigo_postal().toString());
            nuevo.setDomicilioCliente(a.getDireccion());
            nuevo.setLocalidadCliente(a.getPoblacion());
            nuevo.setProvinciaCliente(a.getProvincia());
            nuevo.setNombreCliente(a.getNombre_comercial());
        } else {
            nuevo.setCpCliente(a.getCodigo_postal_fiscal().toString());
            nuevo.setDomicilioCliente(a.getDireccion_fiscal());
            nuevo.setLocalidadCliente(a.getPoblacion_fiscal());
            nuevo.setProvinciaCliente(a.getProvincia_fiscal());
            nuevo.setNombreCliente(a.getNombre_fiscal());
        }
        nuevo.setPaisCliente(a.getPais());
        nuevo.setTelefonoCliente(a.getTelefono());
        nuevo.setEmailCliente(a.getEmail());
        nuevo.setDesde_presupuesto(true);
        nuevo.setEmpresa(this.e);
        nuevo.setPagado(false);
        nuevo.setImpagado(false);
        nuevo.setPreparado(false);
        nuevo.setInstalado(false);
        nuevo.setConfeccionado(false);
        nuevo.setFabricado(false);
        nuevo.setSerie((String) cSeries.getSelectedItem());
        nuevo.setEstado(establecerEstado());
        nuevo.setConvertido(false);
 
        //Más adelante se le asignará el almacén, ya que todos los documentos han de tener el mismo
        nuevo.setAlmacen(BaseDatos.obtenerAlmacenPorDescripcion(Constantes.ALMACEN_PRINCIPAL));
		
		//Más adelante se le asignará el dto, ya que todos los documentos han de tener el mismo
		nuevo.setDto(0D);
        
        ListaRangoPresupuestos lrp = new ListaRangoPresupuestos(pInicioRango, pFinalRango, nuevo, this.e, this.tcliente.getText(), this.u, this, aI, iidEmpresaI);
        lrp.setDefaultCloseOperation(DatosConversion.DISPOSE_ON_CLOSE);
        lrp.setLocationRelativeTo(null);
        lrp.setVisible(true);
    }
    
    private void procesar() {
        if (rvarios.isSelected()) {
            procesarVariosDocumentos();
        } else if (rcompleto.isSelected()) {
            procesarDocumentoCompleto();
        } else {
            procesarDocumentoParcial();
        }
    }
    
    private void procesarkk() {
        
        boolean correcto = true;
        boolean res = false;
        boolean docI = false;
        String numero = "";
        String numeroAi = "";
        String claseDocumento = (String) lpasar.getSelectedItem();

        ClaseDocumento cdN = BaseDatos.getClaseDocumentosByDescripcion(claseDocumento);

        if (p.getInterlocutor()!=null && !p.getInterlocutor().equals(e.getIid())) {
            //Comprobar Interlocutor
            eI = BaseDatos.obtenerEmpresaPorIid(p.getInterlocutor());
            in = BaseDatos.obtenerInterlocutor(eI, e);
            aI = BaseDatos.obtenerAgenteByIid(in.getIidCliente().getIid());
            formulas = BaseDatos.obtenerInterFormulas(in);
        }

        Metadata num = null;
        Metadata anio = null;
        if (claseDocumento.equals(Constantes.ALBARAN)) {
            //Se pasa de presupuesto a albarán
            if (cdN.getDescripcion().equals(Constantes.ALBARAN) && !e.getIid().equals(p.getInterlocutor())) {
                if (((String) cSeries.getSelectedItem()).equals(Constantes.SERIE_STD)) {
                    num = BaseDatos.obtenerMetadaPorNombre("numAlbaran", eI.getIid());
                    anio = BaseDatos.obtenerMetadaPorNombre("anioAlbaran", eI.getIid());
                } else {
                    num = BaseDatos.obtenerMetadaPorNombre("numAlbaranB", eI.getIid());
                    anio = BaseDatos.obtenerMetadaPorNombre("anioAlbaranB", eI.getIid());
                }
            }else{
                if (((String) cSeries.getSelectedItem()).equals(Constantes.SERIE_STD)) {
                    num = BaseDatos.obtenerMetadaPorNombre("numAlbaran", e.getIid());
                    anio = BaseDatos.obtenerMetadaPorNombre("anioAlbaran", e.getIid());
                } else {
                    num = BaseDatos.obtenerMetadaPorNombre("numAlbaranB", e.getIid());
                    anio = BaseDatos.obtenerMetadaPorNombre("anioAlbaranB", e.getIid());
                }
            }
        } else if (claseDocumento.equals(Constantes.FACTURA) || claseDocumento.equals(Constantes.FACTURAA)) {
            //Se pasa de albarán a factura
            num = BaseDatos.obtenerMetadaPorNombre("numFactura", e.getIid());
            anio = BaseDatos.obtenerMetadaPorNombre("anioFactura", e.getIid());
        } else if (claseDocumento.equals(Constantes.PEDIDO)) {
            //Se pasa de presupuesto a pedido
            num = BaseDatos.obtenerMetadaPorNombre("numPedido", e.getIid());
            anio = BaseDatos.obtenerMetadaPorNombre("anioPedido", e.getIid());
        } else if (claseDocumento.equals(Constantes.ALBARANC)) {
            //Se pasa de presupuesto a pedido
            num = BaseDatos.obtenerMetadaPorNombre("numAlbaranF", e.getIid());
            anio = BaseDatos.obtenerMetadaPorNombre("anioAlbaranF", e.getIid());
        } else if (claseDocumento.equals(Constantes.FACTURAC)) {
            //Se pasa de presupuesto a pedido
            num = BaseDatos.obtenerMetadaPorNombre("numFacturaF", e.getIid());
            anio = BaseDatos.obtenerMetadaPorNombre("anioFacturaF", e.getIid());
        }
        
        //Automático: hay que seleccionar el numero del albarán de la bbdd
        String numS = num.getValor();
        int numI = Integer.valueOf(numS);
        num.setValor(String.valueOf(numI + 1));
        numero = anio.getValor() + "/" + num.getValor();
        correcto = BaseDatos.modificarElemento(num);

        if (correcto) {
            //Comprobar si el documento ha cambiado
            if (!(this.tdocumento.getText().equals(p.getNumero()))) {
                this.p = BaseDatos.obtenerPresupuestoPorNumeroPorClaseDocumento(tdocumento.getText(), claseDocumento, e, p.getInterlocutor());
            }
            Presupuesto nuevo = new Presupuesto();
            // Crear documento para cuando no se han seleccionado varios documentos
            if (!rvarios.isSelected()) {

                nuevo.setClase_documento(cdN);
                nuevo.setCifCliente(p.getCifCliente());
                nuevo.setReferencia(p.getReferencia());
                nuevo.setCodigoCliente(p.getCodigoCliente());

                if (cdN.getDescripcion().equals(Constantes.FACTURAC)) {
                    a = BaseDatos.obtenerAgentesPorCodigo(p.getCodigoCliente(), "prov", e);
                    if(a != null){
                        nuevo.setCpCliente(a.getCodigo_postal_fiscal().toString());
                        nuevo.setDomicilioCliente(a.getDireccion_fiscal());
                        nuevo.setLocalidadCliente(a.getPoblacion_fiscal());
                        nuevo.setNombreCliente(a.getNombre_fiscal());
                        nuevo.setProvinciaCliente(a.getProvincia_fiscal());
                    } else {
                        nuevo.setCpCliente(p.getCpCliente());
                        nuevo.setDomicilioCliente(p.getDomicilioCliente());
                        nuevo.setLocalidadCliente(p.getLocalidadCliente());
                        nuevo.setNombreCliente(p.getNombreCliente());
                        nuevo.setProvinciaCliente(p.getProvinciaCliente());
                    }
                } else if (!cdN.getDescripcion().equals(Constantes.FACTURA)) {
                    nuevo.setCpCliente(p.getCpCliente());
                    nuevo.setDomicilioCliente(p.getDomicilioCliente());
                    nuevo.setLocalidadCliente(p.getLocalidadCliente());
                    nuevo.setNombreCliente(p.getNombreCliente());
                    nuevo.setProvinciaCliente(p.getProvinciaCliente());
                } else {
                    a = BaseDatos.obtenerAgentesPorCodigo(p.getCodigoCliente(), "cli", e);
                    if(a != null){
                        nuevo.setCpCliente(a.getCodigo_postal_fiscal().toString());
                        nuevo.setDomicilioCliente(a.getDireccion_fiscal());
                        nuevo.setLocalidadCliente(a.getPoblacion_fiscal());
                        nuevo.setNombreCliente(a.getNombre_fiscal());
                        nuevo.setProvinciaCliente(a.getProvincia_fiscal());
                    } else {
                        nuevo.setCpCliente(p.getCpCliente());
                        nuevo.setDomicilioCliente(p.getDomicilioCliente());
                        nuevo.setLocalidadCliente(p.getLocalidadCliente());
                        nuevo.setNombreCliente(p.getNombreCliente());
                        nuevo.setProvinciaCliente(p.getProvinciaCliente());
                    }
                }
                
                nuevo.setPaisCliente(p.getPaisCliente());
                nuevo.setTelefonoCliente(p.getTelefonoCliente());
                nuevo.setDesde_presupuesto(true);
                nuevo.setDto(p.getDto());
                nuevo.setPagado(p.getPagado());
                nuevo.setImpagado(p.getImpagado());
                nuevo.setPreparado(false);
                nuevo.setInstalado(false);
                nuevo.setConfeccionado(false);
                nuevo.setFabricado(false);
                nuevo.setEmpresa(p.getEmpresa());
                nuevo.setEstado(establecerEstado());
                nuevo.setFecha(p.getFecha());
                nuevo.setFp(p.getFp());

                if(claseDocumento.equals(Constantes.FACTURAA)){
                    nuevo.setImporte_total(- p.getImporte_total());
                } else {
                    nuevo.setImporte_total(p.getImporte_total());
                }

                nuevo.setSerie((String) cSeries.getSelectedItem());
                nuevo.setNumero(numero);
                nuevo.setIva(p.getIva());
                nuevo.setConvertido(false);
                nuevo.setContactado(p.getContactado());
                nuevo.setComercial(p.getComercial());
                nuevo.setPorcentajeComercial(p.getPorcentajeComercial());
                nuevo.setAlmacen(p.getAlmacen());
                nuevo.setEmailCliente(p.getEmailCliente());
                if (claseDocumento.equals(Constantes.PEDIDO)) {
                    nuevo.setFechaEntrega(p.getFecha());
                }
                nuevo.setInterlocutor(p.getInterlocutor());

                res = BaseDatos.insertarElemento(nuevo);

                //En el caso que sea Albarán y el interlocutor sea distinto a la empresa madre,
                //creamos el albaran entre EMPRESA MADRE Y EMPRESA HIJA

                if (cdN.getDescripcion().equals(Constantes.ALBARAN) && !e.getIid().equals(p.getInterlocutor())) {
                    numeroAi = this.crearDocumentoInterS(nuevo);
                    docI = true;
                }
            } else {
                //Si se han seleccionado varios documentos
                cdN = BaseDatos.getClaseDocumentosByDescripcion(claseDocumento);
                nuevo.setClase_documento(cdN);
                nuevo.setCifCliente(a.getCif_nif());
                nuevo.setCodigoCliente(a.getCod_agente());
                if (!cd.getDescripcion().equals(Constantes.FACTURA)) {
                    nuevo.setCpCliente(a.getCodigo_postal().toString());
                    nuevo.setDomicilioCliente(a.getDireccion());
                    nuevo.setLocalidadCliente(a.getPoblacion());
                    nuevo.setProvinciaCliente(a.getProvincia());
                    nuevo.setNombreCliente(a.getNombre_comercial());
                } else {
                    nuevo.setCpCliente(a.getCodigo_postal_fiscal().toString());
                    nuevo.setDomicilioCliente(a.getDireccion_fiscal());
                    nuevo.setLocalidadCliente(a.getPoblacion_fiscal());
                    nuevo.setProvinciaCliente(a.getProvincia_fiscal());
                    nuevo.setNombreCliente(a.getNombre_fiscal());
                }
                nuevo.setPaisCliente(a.getPais());
                nuevo.setTelefonoCliente(a.getTelefono());
                nuevo.setEmailCliente(a.getEmail());
                nuevo.setDesde_presupuesto(true);
                nuevo.setEmpresa(this.e);
                nuevo.setPagado(false);
                nuevo.setImpagado(false);
                nuevo.setPreparado(false);
                nuevo.setInstalado(false);
                nuevo.setConfeccionado(false);
                nuevo.setFabricado(false);
                nuevo.setSerie((String) cSeries.getSelectedItem());
                nuevo.setEstado(establecerEstado());
                //Temporal
                nuevo.setAlmacen(BaseDatos.obtenerAlmacenPorDescripcion("Almacén principal"));
                nuevo.setNumero(numero);
                nuevo.setConvertido(false);
                //ASKI
                // QUE OCURRE CON LOS INTERLOCUTORES si se procesan varios documentos ¿¿
                // Esta linea la he puesto yo xk antes no estaba ==> nuevo.setInterlocutor(p.getInterlocutor());
                //ASKI
                res = BaseDatos.insertarElemento(nuevo);

                if (cdN.getDescripcion().equals(Constantes.ALBARAN) && !e.getIid().equals(p.getInterlocutor())) {
                    numeroAi = this.crearDocumentoInterS(nuevo);
                }
            }
            if (res) {
                boolean seguir = true;
                int ver = 0;

                //En el caso de que pasemos un único documento
                if (rcompleto.isSelected()) {

                    //Necesitamos el nuevo iid
                    Integer iidNuevo;
                    Presupuesto presupuestoNuevo = BaseDatos.obtenerPresupuestoPorNumeroPorClaseDocumento(nuevo.getNumero(), claseDocumento, e, nuevo.getInterlocutor());
                    iidNuevo = presupuestoNuevo.getIid();

                    //Asociamos el documento nuevo con el antiguo
                    p.setConvertido(true);

                    //Establecemos el pedido como recibido
                    EstadoDocumento esp = null;
                    if (cd.getDescripcion().equals(Constantes.PEDIDOC)) {
                        esp = BaseDatos.obtenerEstadoDocumentoPorDesc(Constantes.PEDIDO_RECIBIDO);
                        p.setEstado(esp);
                        BaseDatos.modificarElemento(p);
                    } else if (cd.getDescripcion().equals(Constantes.PRESUPUESTO)) {
                        esp = BaseDatos.obtenerEstadoDocumentoPorDesc("Aceptado");
                        p.setEstado(esp);
                        BaseDatos.modificarElemento(p);
                    } else if (cd.getDescripcion().equals(Constantes.PEDIDO)) {
                        esp = BaseDatos.obtenerEstadoDocumentoPorDesc("Finalizado");
                        p.setEstado(esp);
                        BaseDatos.modificarElemento(p);
                    } else if (cd.getDescripcion().equals(Constantes.ALBARAN)) {
                        esp = BaseDatos.obtenerEstadoDocumentoPorDesc("Facturado");
                        p.setEstado(esp);
                        BaseDatos.modificarElemento(p);
                    } else if (cd.getDescripcion().equals(Constantes.ALBARANC)) {
                        esp = BaseDatos.obtenerEstadoDocumentoPorDesc("Facturado");
                        p.setEstado(esp);
                        BaseDatos.modificarElemento(p);
                    }
                    //ASKI ==> habría que hacer algo en el codigo de arriba para faturas devuelta o de abono?
                    //ASKI

                    
                    //Presupuesto pre = BaseDatos.obtenerPresupuestoPorNumero(numero);
                    //Una vez que se ha creado el nuevo documento hay que copiar sus artículos
                    Presupuesto pre = BaseDatos.obtenerPresupuestoPorNumeroPorClaseDocumento(numero, claseDocumento, e, p.getInterlocutor());
                    List<LineaPresupuesto> listaLp = BaseDatos.getListaLineaPresupuesto(p.getIid());
                    LineaPresupuesto lp, lpCopiada;

                    Iterator it = listaLp.iterator();

                    while (it.hasNext() && seguir) {
                        lp = (LineaPresupuesto) it.next();
                        lpCopiada = lp.copiar(pre);
                        if(claseDocumento.equals(Constantes.FACTURAA) || claseDocumento.equals(Constantes.FACTURAC)){
                            lpCopiada.setCantidad(-lpCopiada.getCantidad());
                            lpCopiada.setImporte(-lpCopiada.getImporte());
                        }

                        seguir = BaseDatos.insertarElemento(lpCopiada);
                        if ((cd.getDescripcion().equals(Constantes.PEDIDOC)) && seguir) {
                            lp.setCantidadRec(lp.getCantidad());
                            BaseDatos.modificarElemento(lp);
                        }
                    }

                    List listaDacPresupuesto = BaseDatos.getlistaDacPresupuesto(p.getIid());
                    it = listaDacPresupuesto.iterator();
                    Iterator iter2, iter3;
                    List listaVariablePresupuesto;
                    List listaDespiecePresupuesto;
                    DacPresupuesto dp, dpCopiado;
                    VariablePresupuesto vp, vpCopiada;
                    SeleccionPresupuesto sp, spCopiada;
                    DespiecePresupuesto desp, despCopiado;
                    List listaSeleccionPresupuesto;

                    while (it.hasNext() && seguir) {
                        dp = (DacPresupuesto) it.next();
                        dpCopiado = dp.copiar();
                        dpCopiado.setPresupuesto(pre);
                        seguir = BaseDatos.insertarElemento(dpCopiado);

                        listaVariablePresupuesto = BaseDatos.getListaVariablePresupuestoByDacPresupuesto(dp.getIid());
                        iter2 = listaVariablePresupuesto.iterator();
                        while (iter2.hasNext() && seguir) {
                            vp = (VariablePresupuesto) iter2.next();
                            vpCopiada = vp.copiar();
                            vpCopiada.setDacPresupuesto(dpCopiado);
                            seguir = BaseDatos.insertarElemento(vpCopiada);

                            listaSeleccionPresupuesto = BaseDatos.getListaSeleccionPresupuestoByVariablePresupuesto(vp.getIid());
                            iter3 = listaSeleccionPresupuesto.iterator();

                            while (iter3.hasNext() && seguir) {
                                sp = (SeleccionPresupuesto) iter3.next();
                                spCopiada = sp.copiar();
                                spCopiada.setDacPresupuesto(dpCopiado);
                                spCopiada.setVariablePresupuesto(vpCopiada);
                                seguir = BaseDatos.insertarElemento(spCopiada);
                            }
                        }

                        listaDespiecePresupuesto = BaseDatos.getListaDespiecePresupuestoByDacPresupuesto(dp.getIid());
                        iter2 = listaDespiecePresupuesto.iterator();
                        while (iter2.hasNext() && seguir) {
                            desp = (DespiecePresupuesto) iter2.next();
                            despCopiado = desp.copiar();
                            despCopiado.setDacPresupuesto(dpCopiado);
                            seguir = BaseDatos.insertarElemento(despCopiado);
                        }

                    }

                    if (seguir) {
                        //Asociamos el documento final y origen
                        //asociarDocumentos(iidNuevo);
                        //Se han añadido correctamente las lineas de presupuesto
                        //Ahora hay que copiar la forma de pago

                        BaseDatos.modificarElemento(p);
                        //Comprobamos si es un albaran de compras, en caso de que así sea insertamos las existencias nuevas
                        if (cdN.getDescripcion().equals(Constantes.ALBARANC)) {

                            //Obtener lineas del documento
                            List<LineaPresupuesto> nlp = BaseDatos.getListaLineaPresupuesto(presupuestoNuevo.getIid());
                            Iterator i = nlp.iterator();
                            LineaPresupuesto mlp;
                            MovimientoAlmacen ma = new MovimientoAlmacen();

                            Date fecha = new Date(); // fecha y hora locales

                            while (i.hasNext()) {
                                // Creamos movimientos de almacen
                                mlp = (LineaPresupuesto) i.next();
                                // ma.setAlmacen(presupuestoNuevo.getAlmacen());
                                // ma.setArticulo(mlp.getArticulo_iid());
                                ma.setCantidad(Float.parseFloat(mlp.getCantidad().toString()));
                                ma.setCantidad1(Float.parseFloat(mlp.getMedida1().toString()));
                                ma.setCantidad2(Float.parseFloat(mlp.getMedida2().toString()));
                                ma.setCantidad3(Float.parseFloat(mlp.getMedida3().toString()));
                                ma.setCantidad4(Float.parseFloat(mlp.getMedida4().toString()));
                                ma.setCantidad5(Float.parseFloat(mlp.getMedida5().toString()));
                                if (mlp.getCaracteristica()!= null){
                                    Caracteristica cc = BaseDatos.obtenerCaracteristicaPorIid(mlp.getCaracteristica().getIid());
                                    ma.setCaracteristica(cc);
                                }
                                ma.setConcepto("Inventario por documento de compras");
                                ma.setEmpresa(e);
                                ma.setFecha(fecha.getTime());
                                ma.setModificable(false);
                                TipoMovimientoAlmacen tma = BaseDatos.obtenerTipoMovimientoAlmacen(Constantes.TIPO_MOVIMIENTO_ALMACEN_COMPRA);
                                ma.setTipoMovimiento(tma);

                                ma.setPresupuesto(presupuestoNuevo);
                                Articulo ar = BaseDatos.obtenerArticuloPorIid(mlp.getArticulo_iid().getIid());
                                ma.setAlmacen(BaseDatos.obtenerAlmacenById(presupuestoNuevo.getAlmacen().getIid()));
                                ma.setArticulo(ar);
                                FamiliaVenta fv = BaseDatos.obtenerFamiliaVentaPorIid(ar.getIid_fam_venta().getIid());
                                TipoControl  tc = BaseDatos.obtenerTipoControlPorIid(fv.getIid_tipo_control().getIid());
                                if(tc.getUnidad1()!=null){
                                    UnidadMedida t1 = BaseDatos.obtenerUnidadMedidaIid(tc.getUnidad1().getIid());
                                    ma.setUnidadMedida1(t1);
                                }
                                if(tc.getUnidad2()!=null){
                                    ma.setUnidadMedida2(tc.getUnidad2().getIid());
                                }
                                if(tc.getUnidad3()!=null){
                                    ma.setUnidadMedida3(tc.getUnidad3().getIid());
                                }
                                if(tc.getUnidad4()!=null){
                                    ma.setUnidadMedida4(tc.getUnidad4().getIid());
                                }
                                if(tc.getUnidad5()!=null){
                                    ma.setUnidadMedida5(tc.getUnidad5().getIid());
                                }
                                if(ar.getIid_unidad_medida()!=null){
                                    UnidadMedida um = BaseDatos.obtenerUnidadMedidaIid(ar.getIid_unidad_medida().getIid());
                                    ma.setUnidadMedidaTotal(um);
                                }
                                BaseDatos.insertarMovimientoExistencia(ma);

                            }
                        }

                        //Creamos el contenido del documento de Albaran para interlocutor
                        if (docI) {
                            
                            //Siempre será Albarán (Comprobar)
                            pre = BaseDatos.obtenerPresupuestoPorNumeroPorClaseDocumento(numeroAi, claseDocumento, e, e.getIid());
                            //ClaseDocumento cd = BaseDatos.getClaseDocumentosByDescripcion(claseDocumento);
                            List listaArticulo = new ArrayList();
                            listaDacPresupuesto = BaseDatos.getlistaDacPresupuesto(p.getIid());
                            it = listaDacPresupuesto.iterator();

                            while (it.hasNext() && seguir) {
                                dp = (DacPresupuesto) it.next();
                                dpCopiado = dp.copiar();
                                dpCopiado.setPresupuesto(pre);
                                seguir = BaseDatos.insertarElemento(dpCopiado);

                                listaVariablePresupuesto = BaseDatos.getListaVariablePresupuestoByDacPresupuesto(dp.getIid());
                                iter2 = listaVariablePresupuesto.iterator();
                                while (iter2.hasNext() && seguir) {
                                    vp = (VariablePresupuesto) iter2.next();
                                    vpCopiada = vp.copiar();
                                    vpCopiada.setDacPresupuesto(dpCopiado);
                                    seguir = BaseDatos.insertarElemento(vpCopiada);

                                    listaSeleccionPresupuesto = BaseDatos.getListaSeleccionPresupuestoByVariablePresupuesto(vp.getIid());
                                    iter3 = listaSeleccionPresupuesto.iterator();

                                    while (iter3.hasNext() && seguir) {
                                        sp = (SeleccionPresupuesto) iter3.next();
                                        spCopiada = sp.copiar();
                                        spCopiada.setDacPresupuesto(dpCopiado);
                                        spCopiada.setVariablePresupuesto(vpCopiada);
                                        seguir = BaseDatos.insertarElemento(spCopiada);
                                    }
                                }

                                listaDespiecePresupuesto = BaseDatos.getListaDespiecePresupuestoByDacPresupuesto(dp.getIid());
                                iter2 = listaDespiecePresupuesto.iterator();
                                while (iter2.hasNext() && seguir) {
                                    desp = (DespiecePresupuesto) iter2.next();
                                    despCopiado = desp.copiar();
                                    despCopiado.setDacPresupuesto(dpCopiado);
                                    seguir = BaseDatos.insertarElemento(despCopiado);
                                }

                            }

                            seguir = true;

                            it = listaLp.iterator();
                            NuevoPresupuesto npC = null;
                            while (it.hasNext() && seguir) {
                                lp = (LineaPresupuesto) it.next();
                                lpCopiada = lp.copiar(pre);
                                lpCopiada = this.calcularPrecioInterlocutor(pre, lpCopiada);
                                seguir = BaseDatos.insertarElemento(lpCopiada);
                                //Comprobar DAC para calcular precio
                                if (npC == null) {
                                    npC = new NuevoPresupuesto(e, pre, this.u, null);
                                }
                                if (calcularDAC(pre, lpCopiada, npC)) {
                                    BaseDatos.modificarElemento(lpCopiada);
                                }
                                //Actulizar lineas
                                NuevaLineaPresupuesto nlpI = new NuevaLineaPresupuesto(npC, lpCopiada.getCodigo(), e, lpCopiada, true, u);
                                listaArticulo.add(nlpI);
                            }
                            //Actualizamos la lista de articulos
                            npC.listaArticulos.clear();
                            npC.listaArticulos.addAll(listaArticulo);

                            //Obligar a calcular precio
                            pre.setImporte_total(npC.calcularPrecio(true));
                            BaseDatos.guardarDocumento(pre, npC.fp2, npC.cod_fp2, npC.fp2_aux, npC.listaArticulos, false, cd, npC.rellenarDacMap);
                        }


                        JOptionPane.showMessageDialog(null, "Conversión realizada con éxito. El " + cdN.getDescripcion() + " " + presupuestoNuevo.getNumero() + " ha sido generado", "Convertido", JOptionPane.INFORMATION_MESSAGE);

                        ver = JOptionPane.showConfirmDialog(null, "¿Desea visualizar el documento generado?", "Visualizar", JOptionPane.YES_NO_OPTION);
                        //Si no es albaran de compra llamamos a nuevo presupuesto
                        if (ver == 0
                                && !cdN.getDescripcion().equals(Constantes.ALBARANC)
                                && (ver == 0
                                && !cdN.getDescripcion().equals(Constantes.FACTURAC))) {

                            //ListaDePresupuestos Lp = new ListaDePresupuestos(e,this.u,presupuestoNuevo.getClase_documento());
                            //NuevoPresupuesto np = new NuevoPresupuesto(Lp, e, presupuestoNuevo,this.u);
                            NuevoPresupuesto np = new NuevoPresupuesto(e, presupuestoNuevo, this.u, null);
                            np.setDefaultCloseOperation(NuevoPresupuesto.DISPOSE_ON_CLOSE);
                            np.setLocationRelativeTo(null);
                            np.setVisible(true);
                        } //en caso contrario llamamos a NuevoCompras
                        else if (ver == 0
                                && cdN.getDescripcion().equals(Constantes.ALBARANC)
                                || (ver == 0
                                && cdN.getDescripcion().equals(Constantes.FACTURAC))) {

                            NuevoCompras nc = new NuevoCompras(e, presupuestoNuevo, this.u, cdN, null);
                            nc.setDefaultCloseOperation(NuevoPresupuesto.DISPOSE_ON_CLOSE);
                            nc.setLocationRelativeTo(null);
                            nc.setVisible(true);
                            cerrarListaDatosConversion();
                        }
                    } else {
                        JOptionPane.showMessageDialog(null, "Conversión imposible de realizar", "Convertir", JOptionPane.INFORMATION_MESSAGE);
                    }
                }
            } else {
                JOptionPane.showMessageDialog(null, "Conversión imposible de realizar", "Convertir", JOptionPane.INFORMATION_MESSAGE);
            }


            //En el caso de que pasemos lineas de un documento
            if (rlinea.isSelected()) {
                Integer iidNuevo = nuevo.getIid();

                //Asociamos el documento final y origen
                //asociarDocumentos(iidNuevo);
                //Presupuesto pre = BaseDatos.obtenerPresupuestoPorNumero(numero);
                //Una vez que se ha creado el nuevo documento hay que copiar sus artículos
                Presupuesto pre = BaseDatos.obtenerPresupuesto(p.getIid());

                //Llamar para interlocutor
                if (this.in == null) {
                    //ListaSeleccionLineas ls = new ListaSeleccionLineas(pre, nuevo, u, e, this, );
                    //ls.setDefaultCloseOperation(DatosConversion.DISPOSE_ON_CLOSE);
                    //ls.setLocationRelativeTo(null);
                    //ls.setVisible(true);
                } else {
                    //ListaSeleccionLineas ls = new ListaSeleccionLineas(pre, nuevo, u, e,in,aI,eI,formulas,numeroAi, this);
                    //ls.setDefaultCloseOperation(DatosConversion.DISPOSE_ON_CLOSE);
                    //ls.setLocationRelativeTo(null);
                    //ls.setVisible(true);
                }
            } else if (rvarios.isSelected()) {
                //Necesitamos el nuevo iid
                String numeroNuevo;
                Presupuesto presupuestoNuevo = BaseDatos.obtenerPresupuestoPorNumeroPorClaseDocumento(nuevo.getNumero(), claseDocumento, e, nuevo.getInterlocutor());
                numeroNuevo = presupuestoNuevo.getNumero();

//                ListaRangoPresupuestos lrp = new ListaRangoPresupuestos(tdocumentoini.getText(), tdocumentofinal.getText(), numeroNuevo, this.e, this.tcliente.getText(), this.u, cdN, cd);
//                lrp.setDefaultCloseOperation(DatosConversion.DISPOSE_ON_CLOSE);
//                lrp.setLocationRelativeTo(null);
//                lrp.setVisible(true);
//                cerrarListaDatosConversion();
            }


            //En el caso de que pasemos más de un documento
            cerrarListaDatosConversion();
        }
    }

private void bAceptarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bAceptarActionPerformed
    boolean procesamos = true;

    if ((this.rcompleto.isSelected() || this.rlinea.isSelected()) && this.tdocumento.getText().length() == 0) {
        procesamos = false;
        JOptionPane.showMessageDialog(null, "Debe seleccionar el documento a convertir", "Error", JOptionPane.ERROR_MESSAGE);
    } else if ((this.a == null || this.tdocumentoini.getText().equals("") || this.tdocumentofinal.getText().equals("")) && this.rvarios.isSelected()) {
        String tipoAgente = "cliente";
        //Según el tipo mostramos proveedores o clientes
        if (this.tipo.equals(Constantes.PEDIDOC) || this.tipo.equals(Constantes.ALBARANC) || this.tipo.equals(Constantes.FACTURAC)) {
            tipoAgente = "proveedor";
        }
        JOptionPane.showMessageDialog(null, "Debe seleccionar el " + tipoAgente + " y los documentos inicial y final.", "Error", JOptionPane.ERROR_MESSAGE);
        procesamos = false;
    } else if (this.rvarios.isSelected()) {
        pInicioRango = BaseDatos.obtenerPresupuestoPorNumero(this.tdocumentoini.getText(), this.e.getIid(), this.cd.getIid());
        pFinalRango = BaseDatos.obtenerPresupuestoPorNumero(this.tdocumentofinal.getText(), this.e.getIid(), this.cd.getIid());

        Integer pInicial = pInicioRango.getIid();
        Integer pFinal = pFinalRango.getIid();

        List listaPresupuestos = BaseDatos.obtenerRangoPresupuesto(pInicial, pFinal, this.e.getIid(), this.cd.getIid(), this.tcliente.getText());

        if (listaPresupuestos == null || listaPresupuestos.size() < 1) {
            JOptionPane.showMessageDialog(null, "No hay documentos que se adapten al criterio seleccionado", "Error", JOptionPane.ERROR_MESSAGE);
            procesamos = false;
        }
    }

    if (procesamos) {
        procesar();
    }
}//GEN-LAST:event_bAceptarActionPerformed

private void rcompletoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rcompletoActionPerformed
    if (this.rcompleto.isSelected()) {
        //tdocumento.setEnabled(true);
        //tdocumentoini.setEnabled(false);
        //tdocumentofinal.setEnabled(false);
        //tcliente.setEnabled(false);
        bseleccion1.setEnabled(true);
        bseleccion2.setEnabled(false);
        bseleccion3.setEnabled(false);
        bseleccioncliente.setEnabled(false);
        tcliente.setText("");
        tdocumentoini.setText("");
        tdocumentofinal.setText("");
    }
}//GEN-LAST:event_rcompletoActionPerformed

private void rvariosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rvariosActionPerformed
    if (this.rvarios.isSelected()) {
        this.tdocumento.setText("");
        //this.tdocumento.setEnabled(false);
        //this.tdocumentoini.setEnabled(true);
        //this.tdocumentofinal.setEnabled(true);
        //this.tcliente.setEnabled(true);
        this.bseleccion1.setEnabled(false);
        this.bseleccion2.setEnabled(true);
        this.bseleccion3.setEnabled(true);
        this.bseleccioncliente.setEnabled(true);
    }
}//GEN-LAST:event_rvariosActionPerformed

private void rlineaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rlineaActionPerformed
    if (this.rlinea.isSelected()) {
        //tdocumento.setEnabled(true);
        //tdocumentoini.setEnabled(false);
        //tdocumentofinal.setEnabled(false);
        //tcliente.setEnabled(false);
        bseleccion1.setEnabled(true);
        bseleccion2.setEnabled(false);
        bseleccion3.setEnabled(false);
        bseleccioncliente.setEnabled(false);
        tcliente.setText("");
        tdocumentoini.setText("");
        tdocumentofinal.setText("");
    }
}//GEN-LAST:event_rlineaActionPerformed

private void bseleccion1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bseleccion1ActionPerformed
    if (rcompleto.isSelected() || rlinea.isSelected()) {
        a = null;
        ListaSeleccionPresupuestos lsp = new ListaSeleccionPresupuestos(this.e, this.tipo, this, "tipo1", a);
        lsp.setDefaultCloseOperation(DatosConversion.DISPOSE_ON_CLOSE);
        lsp.setLocationRelativeTo(null);
        lsp.setVisible(true);
    }
}//GEN-LAST:event_bseleccion1ActionPerformed

private void bseleccion2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bseleccion2ActionPerformed
    ListaSeleccionPresupuestos lsp = new ListaSeleccionPresupuestos(this.e, this.tipo, this, "tipo2", a);
    lsp.setDefaultCloseOperation(DatosConversion.DISPOSE_ON_CLOSE);
    lsp.setLocationRelativeTo(null);
    lsp.setVisible(true);
}//GEN-LAST:event_bseleccion2ActionPerformed

private void bseleccion3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bseleccion3ActionPerformed
    ListaSeleccionPresupuestos lsp = new ListaSeleccionPresupuestos(this.e, this.tipo, this, "tipo3", a);
    lsp.setDefaultCloseOperation(DatosConversion.DISPOSE_ON_CLOSE);
    lsp.setLocationRelativeTo(null);
    lsp.setVisible(true);
}//GEN-LAST:event_bseleccion3ActionPerformed

private void bseleccionclienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bseleccionclienteActionPerformed
    String tipoAgente = "cli";
    if (this.tipo.equals(Constantes.PEDIDOC) || this.tipo.equals(Constantes.ALBARANC) || this.tipo.equals(Constantes.FACTURAC)) {
        tipoAgente = "prov";
    }
    ListaDeClientes ldc = new ListaDeClientes(this, e, tipoAgente);
    ldc.setDefaultCloseOperation(ListaDeClientes.DISPOSE_ON_CLOSE);
    ldc.setLocationRelativeTo(null);
    ldc.setVisible(true);
}//GEN-LAST:event_bseleccionclienteActionPerformed

    public void establecerCliente(Agentes a) {
        tcliente.setText(a.getCod_agente());
        this.a = a;
    }
    
    public Presupuesto crearDocumentoInter(Presupuesto nuevoP) {
        Presupuesto nuevoA = new Presupuesto(nuevoP);
        nuevoA.setCifCliente(aI.getCif_nif());
        nuevoA.setReferencia(p.getNombreCliente() + "//" + p.getReferencia());
        nuevoA.setCodigoCliente(aI.getCod_agente());
        nuevoA.setCpCliente(aI.getCodigo_postal().toString());
        nuevoA.setDomicilioCliente(aI.getDireccion());
        nuevoA.setLocalidadCliente(aI.getPoblacion());
        nuevoA.setNombreCliente(aI.getNombre_comercial());
        nuevoA.setProvinciaCliente(aI.getProvincia());
        nuevoA.setTelefonoCliente(aI.getTelefono());
        nuevoA.setInterlocutor(e.getIid());

        //Calcular IVA a Interlocutor
        if (aI != null) {
            if (aI.getExento_iva() != null && aI.getExento_iva()) {
                nuevoA.setIva(null);
            } else if (aI.getIva() != null) {
                //Obtener IVA del cliente asociado al interlocutor
                nuevoA.setIva(aI.getIva());
            } else {
                //Iva del documento
                Metadata mdtIva = (Metadata) BaseDatos.obtenerMetadaPorNombre("ivaDocumento", e.getIid());
                nuevoA.setIva(BaseDatos.obtenerIvaPorPorcentaje(mdtIva.getValor()));
            }
        }
        return nuevoA;
    }

    public String crearDocumentoInterS(Presupuesto nuevoP) {
        String numero = "";
        Presupuesto nuevoA = new Presupuesto(nuevoP);
        //Obtenemos la numeración para la empresa Interlocutor
        Metadata num = BaseDatos.obtenerMetadaPorNombre("numAlbaran", e.getIid());
        Metadata anio = BaseDatos.obtenerMetadaPorNombre("anioAlbaran", e.getIid());

        //Automático: hay que seleccionar el numero del albarán de la bbdd
        String numS = num.getValor();
        Integer numI = Integer.valueOf(numS);
        num.setValor(String.valueOf(numI + 1));
        numero = anio.getValor() + "/" + num.getValor();
        Boolean correcto = BaseDatos.modificarElemento(num);

        nuevoA.setNumero(numero);
        //Obtener Cliente de Interlocutor
        nuevoA.setCifCliente(aI.getCif_nif());
        nuevoA.setReferencia(p.getNombreCliente() + "//" + p.getReferencia());
        nuevoA.setCodigoCliente(aI.getCod_agente());
        nuevoA.setCpCliente(aI.getCodigo_postal().toString());
        nuevoA.setDomicilioCliente(aI.getDireccion());
        nuevoA.setLocalidadCliente(aI.getPoblacion());
        nuevoA.setNombreCliente(aI.getNombre_comercial());
        nuevoA.setProvinciaCliente(aI.getProvincia());
        nuevoA.setTelefonoCliente(aI.getTelefono());
        nuevoA.setInterlocutor(e.getIid());

        //Calcular IVA a Interlocutor
        if (aI != null) {
            //String serie = (String) cSeries.getSelectedItem();
            //if (serie.equals(Constantes.SERIE_STD)) {
                if (aI.getExento_iva() != null && aI.getExento_iva()) {
                    nuevoA.setIva(null);
                } else {
                    if (aI.getIva() != null) {
                        //Obtener IVA del cliente asociado al interlocutor
                        nuevoA.setIva(aI.getIva());
                    } else {
                        //Iva del documento
                        Metadata mdtIva = (Metadata) BaseDatos.obtenerMetadaPorNombre("ivaDocumento", e.getIid());
                        nuevoA.setIva(BaseDatos.obtenerIvaPorPorcentaje(mdtIva.getValor()));
                    }
                }
            //Insertamos documento nuevo
            BaseDatos.insertarElemento(nuevoA);
        }
        return numero;
    }

    public LineaPresupuesto calcularPrecioInterlocutor(Presupuesto pre, LineaPresupuesto lp) {

        Float fMedida1 = -1F;
        Float fMedida2 = -1F;
        Float fprecio = -1F;
        Float medidaTotal = -1F;
        Caracteristica car = null;
        LineaPresupuesto nlp = new LineaPresupuesto();
        nlp = lp.copiar(pre);
        Articulo ar = BaseDatos.obtenerArticuloPorIid(lp.getArticulo_iid().getIid());
        FamiliaVenta fv = BaseDatos.obtenerFamiliaVentaPorIid(ar.getIid_fam_venta().getIid());

        if (lp.getCaracteristica() != null) {
            car = BaseDatos.obtenerCaracteristicaPorIid(lp.getCaracteristica().getIid());
        }

        if (!lp.getMedida1().equals(0.0)) {
            fMedida1 = Float.parseFloat(Util.convertirComaAPunto(lp.getMedida1().toString()));
        }
        if (!lp.getMedida2().equals(0.0)) {
            fMedida2 = Float.parseFloat(Util.convertirComaAPunto(lp.getMedida2().toString()));
        }

        if (ar.getEscalado()) {
            fprecio = BaseDatos.obtenerPrecioEscalado(ar.getIid(), null, fMedida1.intValue(), fMedida2.intValue());
        } else if (ar.getEscaladoCaracteristica()) {
            fprecio = BaseDatos.obtenerPrecioEscalado(ar.getIid(), car.getIid(), fMedida1.intValue(), fMedida2.intValue());
        } else {
            if (car != null) {
                if (car.getPvp() != null) {
                    fprecio = car.getPvp();
                } else {
                    fprecio = 0F;
                }
            } else {
                if (ar.getPrecio_v() != null) {
                    fprecio = ar.getPrecio_v();
                } else {
                    fprecio = 0F;
                }
            }

            matematico.Matematico.redondear2decimales(fprecio);
            nlp.setPrecioArticulo(Double.parseDouble(fprecio.toString()));

            try {

                ScriptEngineManager manager = new ScriptEngineManager();
                ScriptEngine engine = manager.getEngineByName("js");

                engine.put("Dim1", Util.convertirComaAPunto(lp.getMedida1().toString()));
                engine.put("Dim2", Util.convertirComaAPunto(lp.getMedida2().toString()));
                engine.put("Dim3", Util.convertirComaAPunto(lp.getMedida3().toString()));
                engine.put("Dim4", Util.convertirComaAPunto(lp.getMedida4().toString()));
                engine.put("Dim5", Util.convertirComaAPunto(lp.getMedida5().toString()));

                TipoControl tc = BaseDatos.obtenerTipoControlPorIid(fv.getIid_tipo_control().getIid());

                TipoMedida tm = tc.getIid_tipo_medida();
                String tipoCalculo = tm.getTipo_calculo();

                if (tipoCalculo.equals(Constantes.FORMULA)) {
                    Double medidaTotalDouble = (Double) engine.eval(tm.getFormula());
                    medidaTotal = Float.parseFloat(String.valueOf(medidaTotalDouble));
                } else {
                    medidaTotal = Float.parseFloat(Util.convertirComaAPunto(lp.getMedida1().toString())) / 100;
                }

                if (ar.getEscalado() || ar.getEscaladoCaracteristica()) {
                    medidaTotal = 1F;
                }
            } catch (Exception ex) {
                log.error("Error al calcular el precio de interlocutor ", ex);
            }

        }
        //Obtener descuento
        //Se ha de calcular el descuento segun la siguiente prioridad:
        //1.- Se usará el descuento que el cliente tenga para ese articulo
        //2.- Se usará el descuento que el cliente tenga para esa familia
        //3.- Se usará el descuento qeu el articulo tenga en si
        Double descuento = 0.0D;
        if (aI != null) {
            String codigoAgente = aI.getCod_agente();
            if (codigoAgente != null && !codigoAgente.equals("")) {
                Agentes ag = BaseDatos.obtenerAgentePorEmpresaYCodigo(e.getIid(), codigoAgente);
                if (ag != null) {
                    DescuentoClienteArticulo dca = BaseDatos.obtenerDescuentoClienteArticulo(ag.getIid(), ar.getIid());
                    if (dca != null) {
                        //Se toma el descuento del cliente
                        descuento = dca.getDescuento();
                    } else {
                        DescuentoClienteFamiliaVenta dcfv = BaseDatos.obtenerDescuentoClienteFamiliaVenta(ag.getIid(), ar.getIid_fam_venta().getIid());
                        if (dcfv != null) {
                            //Se toma el descuento de la familia
                            descuento = dcfv.getDescuento();
                        } else if (ar.getDescuento() != null) {
                            descuento = Double.parseDouble(ar.getDescuento().toString());
                        }
                    }
                } else if (ar.getDescuento() != null) {
                    descuento = Double.parseDouble(ar.getDescuento().toString());
                }
            } else if (ar.getDescuento() != null) {
                descuento = Double.parseDouble(ar.getDescuento().toString());
            }
        }

        nlp.setDescuento(descuento);
        
        Double precio = nlp.getCantidad() * nlp.getPrecioArticulo() * medidaTotal * (100 - nlp.getDescuento()) / 100;
        precio = matematico.Matematico.redondear2decimales(precio);
        nlp.setPrecio(nlp.getPrecioArticulo());
        nlp.setImporte(precio);
        return nlp;
    }

    public boolean calcularDAC(Presupuesto pre, LineaPresupuesto lp, NuevoPresupuesto npC) {

        Float fMedida1 = -1F;
        Float fMedida2 = -1F;
        Boolean modificar = false;
        Float medidaTotal = -1F;
        Caracteristica car = null;
        LineaPresupuesto nlp = new LineaPresupuesto();
        nlp = lp.copiar(pre);
        //Comprobar si es un Producto
        Articulo ar = BaseDatos.obtenerArticuloPorIid(lp.getArticulo_iid().getIid());
        FamiliaVenta fv = BaseDatos.obtenerFamiliaVentaPorIid(ar.getIid_fam_venta().getIid());

        if (fv.getCod_familia().equals("PC")) {

            //Calculamos el precio del Producto
            ScriptEngineManager manager = new ScriptEngineManager();
            ScriptEngine engine = manager.getEngineByName("js");
            try {
                engine.put("Dim1", Util.convertirComaAPunto(lp.getMedida1().toString()));
                engine.put("Dim2", Util.convertirComaAPunto(lp.getMedida2().toString()));
                engine.put("Dim3", Util.convertirComaAPunto(lp.getMedida3().toString()));
                engine.put("Dim4", Util.convertirComaAPunto(lp.getMedida4().toString()));
                engine.put("Dim5", Util.convertirComaAPunto(lp.getMedida5().toString()));

                if (!lp.getMedida1().equals(0.0)) {
                    fMedida1 = Float.parseFloat(Util.convertirComaAPunto(lp.getMedida1().toString()));
                }
                if (!lp.getMedida2().equals(0.0)) {
                    fMedida2 = Float.parseFloat(Util.convertirComaAPunto(lp.getMedida2().toString()));
                }

                fv = BaseDatos.obtenerFamiliaVentaPorIid(fv.getIid());
                TipoControl tc = BaseDatos.obtenerTipoControlPorIid(fv.getIid_tipo_control().getIid());
                TipoMedida tm = BaseDatos.obtenerTipoMedidaByIid(tc.getIid_tipo_medida().getIid());
                String tipoCalculo = tm.getTipo_calculo();

                if (tipoCalculo.equals(Constantes.FORMULA)) {
                    Double medidaTotalDouble = null;
                    try {
                        medidaTotalDouble = (Double) engine.eval(tm.getFormula());
                    } catch (ScriptException ex) {
                        log.error("Error al calcular dac ", ex);
                    }
                    medidaTotal = Float.parseFloat(String.valueOf(medidaTotalDouble));
                } else {
                    medidaTotal = Float.parseFloat(Util.convertirComaAPunto(lp.getMedida1().toString())) / 100;
                }

                if (ar.getEscalado() || ar.getEscaladoCaracteristica()) {
                    medidaTotal = 1F;
                }

                Double escalado = BaseDatos.obtenerPrecioEscalado(ar.getIid(), null, fMedida1.intValue(), fMedida2.intValue()).doubleValue();


                Double precio = medidaTotal.doubleValue() * escalado;
                Double importe = precio;
                RellenarDac rd = npC.getRellenarDac(lp.getCodigo());
                List<Despiece> lista = rd.getListaDespiece();
                Iterator iter = lista.iterator();
                Despiece despieceTemp;
                while (iter.hasNext()) {
                    despieceTemp = (Despiece) iter.next();
                    precio += rd.calcularPrecioDespiece(despieceTemp, null, null, null);
                }
                precio = precio * lp.getCantidad();
                lp.setPrecio(importe);
                lp.setPrecioArticulo(importe);
                lp.setImporte(precio);
                modificar = true;
            } catch (Exception ex) {
                log.error("Error al calcular dac ", ex);
            }
        } else {
            modificar = false;
        }
        return modificar;
    }

    protected Agentes getAgenteAI() {
        return this.aI;
    }
	
	
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bAceptar;
    private javax.swing.JButton bCancelar;
    private javax.swing.JButton bseleccion1;
    private javax.swing.JButton bseleccion2;
    private javax.swing.JButton bseleccion3;
    private javax.swing.JButton bseleccioncliente;
    private javax.swing.JComboBox cSeries;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JComboBox lpasar;
    private javax.swing.JRadioButton rcompleto;
    private javax.swing.JRadioButton rlinea;
    private javax.swing.JRadioButton rvarios;
    private javax.swing.JTextField tcliente;
    private javax.swing.JTextField tdocumento;
    private javax.swing.JTextField tdocumentofinal;
    private javax.swing.JTextField tdocumentoini;
    private javax.swing.ButtonGroup tiposeleccion;
    // End of variables declaration//GEN-END:variables
}
