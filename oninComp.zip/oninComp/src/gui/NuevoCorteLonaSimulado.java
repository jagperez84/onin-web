package gui;

import acceso.BaseDatos;
import auxiliar.CorteLona;
import auxiliar.CorteLonaSimulado;
import bean.Dac;
import bean.Despiece;
import bean.Articulo;
import bean.DespiecePresupuesto;
import bean.LineaCorteLona;
import informes.confeccionLonas.ConfeccionLonas;
import informes.confeccionLonas.LineaConfeccion;
import informes.confeccionLonasTotal.ConfeccionLonasTotal;
import informes.confeccionLonasTotal.LineaConfeccionTotal;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JOptionPane;
import javax.swing.KeyStroke;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import util.Util;

public class NuevoCorteLonaSimulado extends javax.swing.JFrame {

    private List<CorteLonaSimulado> listaCorteLona;
    private int lonasMostradas;
    private List<Integer> listaIdentificadoresExistenciasRestosUsados;
    private NuevaLineaPresupuesto nlp;
    private int codigoLinea;
    private NuevoPresupuesto p;
    private boolean desdeLinea;
    private List<Integer> listaCortesLonaPorDac = new ArrayList<Integer>();

    public NuevoCorteLonaSimulado(NuevaLineaPresupuesto nlp) {
        super("Simulación");
        this.listaCorteLona = new ArrayList<CorteLonaSimulado>();
        this.nlp = nlp;
        this.desdeLinea = true;
        
        initComponents();
        
        this.p = nlp.getNuevoPresupuesto();
        this.codigoLinea = nlp.getCodigo();
        RellenarDac rd = (RellenarDac) p.getRellenarDac(this.codigoLinea);
        
        String medida1S = Util.convertirPuntoAComa(String.valueOf(nlp.getMedida1()));
        String medida2S = Util.convertirPuntoAComa(String.valueOf(nlp.getMedida2()));
        String cantidadS = Util.convertirPuntoAComa(String.valueOf(nlp.getCantidad()));
        listaCorteLona.addAll(rd.getArticulosLonaSimulado(medida1S, medida2S, cantidadS, codigoLinea, nlp));

        bCancelar.setToolTipText("Cancelar");
        bFinalizar.setToolTipText("Finalizar");
        rellenarCortesLona();
        crearIconosBotones();
        crearAcciones();
    }
    
    public NuevoCorteLonaSimulado(NuevoPresupuesto p){
        super("Simulación");
        this.listaCorteLona = new ArrayList<CorteLonaSimulado>();
        this.p = p;
        this.desdeLinea = false;
        
        initComponents();
        
        Integer clave;
        RellenarDac rd;
        Dac dac;
        HashMap rellenarDacMap;
        String medida1S;
        String medida2S;
        String cantidadS; 
        rellenarDacMap = p.getRellenarDacMap();
        List listaAAnadir;
        
        for(Iterator it = rellenarDacMap.keySet().iterator(); it.hasNext();) { 
            clave = (Integer)it.next();
            rd =  (RellenarDac) rellenarDacMap.get(clave);
            rd = p.getRellenarDac(clave);
            dac = rd.getDacBase();
            nlp = (NuevaLineaPresupuesto) p.getListaArticulos().get(clave - 1);
            if(nlp.getTcantidad() != null && nlp.getTcantidad().length() > 0){
                dac.setCantidad(Double.parseDouble(Util.convertirComaAPunto(nlp.getTcantidad())));
            } else {
                dac.setCantidad(0D);
            }

            if(nlp.getTMedida1() != null && nlp.getTMedida1().length() > 0){
                dac.setMedida1(Double.parseDouble(Util.convertirComaAPunto(nlp.getTMedida1())));
            } else {
                dac.setMedida1(0D);
            }

            if(nlp.getTMedida2() != null && nlp.getTMedida2().length() > 0){
                dac.setMedida2(Double.parseDouble(Util.convertirComaAPunto(nlp.getTMedida2())));
            } else {
                dac.setMedida2(0D);
            }

            if(nlp.getTMedida3() != null && nlp.getTMedida3().length() > 0){
                dac.setMedida3(Double.parseDouble(Util.convertirComaAPunto(nlp.getTMedida3())));
            } else {
                dac.setMedida3(0D);
            }

            if(nlp.getTMedida5() != null &&nlp.getTMedida5().length() > 0){
                dac.setMedida4(Double.parseDouble(Util.convertirComaAPunto(nlp.getTMedida5())));
            } else {
                dac.setMedida4(0D);
            }

            if(nlp.getTMedida5() != null && nlp.getTMedida5().length() > 0){
                dac.setMedida5(Double.parseDouble(Util.convertirComaAPunto(nlp.getTMedida5())));
            } else {
                dac.setMedida5(0D);
            }

            rd.setDacBase(dac);
            rd = new RellenarDac(rd, p, "Titulo");
            
            medida1S = Util.convertirPuntoAComa(String.valueOf(nlp.getMedida1()));
            medida2S = Util.convertirPuntoAComa(String.valueOf(nlp.getMedida2()));
            cantidadS = Util.convertirPuntoAComa(String.valueOf(nlp.getCantidad()));
            
            listaAAnadir = rd.getArticulosLonaSimulado(medida1S, medida2S, cantidadS, codigoLinea, nlp);
            listaCortesLonaPorDac.add(listaAAnadir.size());
            listaCorteLona.addAll(listaAAnadir);
        }

        bCancelar.setToolTipText("Cancelar");
        bFinalizar.setToolTipText("Finalizar");
        rellenarCortesLona();
        crearIconosBotones();
        crearAcciones();
    }
    
    

    private void rellenarCortesLona(){
        Iterator iter = listaCorteLona.iterator();
        NuevaLineaCorteDeLona nlcl;
        lonasMostradas = 0;
        LineaCorteLona lcl;
        CorteLonaSimulado cl;
        List listaTemporalCortesLona = BaseDatos.getListaLineaCorteLona(this.nlp.getNuevoPresupuesto().getPresupuesto().getIid());
        
        listaIdentificadoresExistenciasRestosUsados = BaseDatos.getListaRestosUsados(this.nlp.getNuevoPresupuesto().getPresupuesto().getIid());
        
        while(iter.hasNext()){
            cl = (CorteLonaSimulado) iter.next();
            lcl = getLineaCorteLonaSimulado(cl, listaTemporalCortesLona);
            if(lcl == null){
                nlcl = new NuevaLineaCorteDeLona(this, this.nlp.getNuevoPresupuesto(), new CorteLona(cl));
            } else {
                nlcl = new NuevaLineaCorteDeLona(this, this.nlp.getNuevoPresupuesto(), new CorteLona(cl), lcl);
            }
            panelCorteLona.add(nlcl);
            panelCorteLona.setVisible(true);
            panelCorteLona.repaint();
            lonasMostradas++;
        }
        
        for(int contadorLonas = lonasMostradas + 1; contadorLonas < 10; contadorLonas ++){
            NuevaLineaCorteDeLonaVacia nlclv = new NuevaLineaCorteDeLonaVacia();
            panelCorteLona.add(nlclv);
        }
        
        panelCorteLona.setSize(500, 500);
        panelCorteLona.setLayout(new GridLayout(0, 1));
        
        panelCorteLona.setVisible(true);
        panelCorteLona.repaint();
    }
    
    
    private LineaCorteLona getLineaCorteLona(CorteLona cl, List listaTemporalCortesLona) {
        LineaCorteLona lcl = null;
        boolean seguir = true;
        Iterator iter = listaTemporalCortesLona.iterator();
        while(iter.hasNext() && seguir){
            lcl = (LineaCorteLona)iter.next();
            if(!lcl.getEsDespiece() && cl.getIndiceElemento() == null && lcl.getLineaPresupuesto().getIid().equals(cl.getIddNuevaLineaPresupuesto())){
                seguir = false;
            } else if(lcl.getEsDespiece() && cl.getIndiceElemento() != null && lcl.getLineaPresupuesto().getIid().equals(cl.getIddNuevaLineaPresupuesto())){
                DespiecePresupuesto dp = lcl.getDespiece();
                dp = BaseDatos.obtenerDespiecePresupuestoByIid(dp.getIid());
                if(dp != null && dp.getOrden().equals(cl.getIndiceElemento())){
                     seguir = false;
                }
            }
        }
        
        if(seguir){
            lcl = null;
        }
        
        return lcl;
    }

    private LineaCorteLona getLineaCorteLonaSimulado(CorteLonaSimulado cl, List listaTemporalCortesLona) {
        LineaCorteLona lcl = null;
        boolean seguir = true;
        Iterator iter = listaTemporalCortesLona.iterator();
        while(iter.hasNext() && seguir){
            lcl = (LineaCorteLona)iter.next();
            if(!lcl.getEsDespiece() && cl.getIndiceElemento() == null && lcl.getLineaPresupuesto().getIid().equals(cl.getIddNuevaLineaPresupuesto())){
                seguir = false;
            } else if(lcl.getEsDespiece() && cl.getIndiceElemento() != null && lcl.getLineaPresupuesto().getIid().equals(cl.getIddNuevaLineaPresupuesto())){
                DespiecePresupuesto dp = lcl.getDespiece();
                dp = BaseDatos.obtenerDespiecePresupuestoByIid(dp.getIid());
                if(dp != null && dp.getOrden().equals(cl.getIndiceElemento())){
                     seguir = false;
                }
            }
        }
        
        if(seguir){
            lcl = null;
        }
        
        return lcl;
    }
    
    public void actualizarLineas() {
        panelCorteLona.setVisible(true);
        panelCorteLona.repaint();
        pack();
    }
    
    private void crearAcciones() {
        KeyStroke escapeKeyStroke = KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false);
        Action escapeAction = new AbstractAction() {
            public void actionPerformed(ActionEvent e) {
                cerrarVentana();
            }
        }; 
        getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(escapeKeyStroke, "ESCAPE");
        getRootPane().getActionMap().put("ESCAPE", escapeAction);
    }
    
    private void cerrarVentana(){
        removeAll();
        dispose();
    }

    private void crearIconosBotones() {
        URL urlCancelar = getClass().getResource("/iconos/cancelar.gif");
        ImageIcon iconoCancelar = new ImageIcon(urlCancelar);
        bCancelar.setIcon(iconoCancelar);
        
        URL urlFinalizar = getClass().getResource("/iconos/aceptar.png");
        ImageIcon iconoFinalizar = new ImageIcon(urlFinalizar);
        bFinalizar.setIcon(iconoFinalizar);
    }

    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        bCancelar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        panelCorteLona = new javax.swing.JPanel();
        lTitulo = new javax.swing.JLabel();
        bFinalizar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        bCancelar.setText("Cancelar");
        bCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bCancelarActionPerformed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout panelCorteLonaLayout = new org.jdesktop.layout.GroupLayout(panelCorteLona);
        panelCorteLona.setLayout(panelCorteLonaLayout);
        panelCorteLonaLayout.setHorizontalGroup(
            panelCorteLonaLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(0, 779, Short.MAX_VALUE)
        );
        panelCorteLonaLayout.setVerticalGroup(
            panelCorteLonaLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(0, 327, Short.MAX_VALUE)
        );

        jScrollPane1.setViewportView(panelCorteLona);

        lTitulo.setFont(new java.awt.Font("Tahoma", 1, 11));
        lTitulo.setText("     C.Linea      Cantidad                        Artículo                           Salida        Línea           T. Corte      Autom.   Doblad.  Solape       Ancho");

        bFinalizar.setText("Finalizar");
        bFinalizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bFinalizarActionPerformed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout layout = new org.jdesktop.layout.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(layout.createSequentialGroup()
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(org.jdesktop.layout.GroupLayout.TRAILING, layout.createSequentialGroup()
                        .add(32, 32, 32)
                        .add(bFinalizar, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 103, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED, 561, Short.MAX_VALUE)
                        .add(bCancelar))
                    .add(lTitulo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 711, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
            .add(jScrollPane1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 781, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, layout.createSequentialGroup()
                .add(lTitulo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 21, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jScrollPane1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 329, Short.MAX_VALUE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(bCancelar)
                    .add(bFinalizar))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

private void bCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bCancelarActionPerformed
    cerrarVentana();
}//GEN-LAST:event_bCancelarActionPerformed

protected List getListaIdentificadoresExistenciasRestosUsados(){
    return this.listaIdentificadoresExistenciasRestosUsados;
}

private void mostrarSimulacionLineaPresupuesto(){
    RellenarDac rd = this.nlp.getNuevoPresupuesto().getRellenarDac(this.nlp.getCodigo());
    
    Dac dac = rd.getDacBase();
    
    if(this.nlp.getTcantidad() != null && this.nlp.getTcantidad().length() > 0){
        dac.setCantidad(Double.parseDouble(Util.convertirComaAPunto(this.nlp.getTcantidad())));
    } else {
        dac.setCantidad(0D);
    }
    
    if(this.nlp.getTMedida1() != null && this.nlp.getTMedida1().length() > 0){
        dac.setMedida1(Double.parseDouble(Util.convertirComaAPunto(this.nlp.getTMedida1())));
    } else {
        dac.setMedida1(0D);
    }
    
    if(this.nlp.getTMedida2() != null && this.nlp.getTMedida2().length() > 0){
        dac.setMedida2(Double.parseDouble(Util.convertirComaAPunto(this.nlp.getTMedida2())));
    } else {
        dac.setMedida2(0D);
    }
    
    if(this.nlp.getTMedida3() != null && this.nlp.getTMedida3().length() > 0){
        dac.setMedida3(Double.parseDouble(Util.convertirComaAPunto(nlp.getTMedida3())));
    } else {
        dac.setMedida3(0D);
    }
    
    if(this.nlp.getTMedida4() != null && this.nlp.getTMedida4().length() > 0){
        dac.setMedida4(Double.parseDouble(Util.convertirComaAPunto(this.nlp.getTMedida4())));
    } else {
        dac.setMedida4(0D);
    }
    
    if(this.nlp.getTMedida5() != null && this.nlp.getTMedida5().length() > 0){
        dac.setMedida5(Double.parseDouble(Util.convertirComaAPunto(this.nlp.getTMedida5())));
    } else {
        dac.setMedida5(0D);
    }

    rd.setDacBase(dac);
    rd = new RellenarDac(rd, p, "Titulo");

    Despiece d;
    Articulo articuloBase;
    List<LineaConfeccion> llc = new ArrayList<LineaConfeccion>();
    Float cantidad1 = Float.parseFloat(Util.convertirComaAPunto(this.nlp.getTcantidad()));
    HashMap parameters = new HashMap();
    String cantidadTemporal;
    NuevaLineaCorteDeLona nlcl;
    CorteLonaSimulado cs;
    
    parameters.put("numero", p.getNumero());
    parameters.put("referencia", p.getReferencia());
    parameters.put("cliente", p.getNombreCliente());
    Date fecha = new Date(p.getFechaLong());
    SimpleDateFormat formatoFecha = new SimpleDateFormat("dd/MM/yyyy");
    parameters.put("fecha", formatoFecha.format(fecha).toString());
    
    String articulos = "";
    
    /*if(!rd.getLona().equals("")){
        articulos += "Lona: " + rd.getLona() + "\n";
    }
    
    if(!rd.getFaldon().equals("")){
        articulos += "Faldón: " + rd.getFaldon() + "\n";
    }
    
    if(!rd.getTipoFaldon().equals("")){
        articulos += "Tipo faldón: " + rd.getTipoFaldon() + "\n";
    }
    
    if(!rd.getRibete().equals("")){
        articulos += "Ribete: " + rd.getRibete() + "\n";
    }
    
    if(!rd.getManivela().equals("")){
        articulos += "Manivela: " + rd.getManivela() + "\n";
    }
    
    if(!rd.getBrazos().equals("")){
        articulos += "Brazos: " + rd.getBrazos() + "\n";
    }
    
    if(!rd.getMotor().equals("")){
        articulos += "Motor: " + rd.getMotor() + "\n";
    }
    
    if(!rd.getTuboEnrrolle().equals("")){
        articulos += "T. enrrolle: " + rd.getTuboEnrrolle() + "\n";
    }
    
    if(!rd.getTuboCarga().equals("")){
        articulos += "T. carga: " + rd.getTuboCarga() + "\n";
    }*/

    for (int i = 0; i < lonasMostradas; i++) {
        nlcl = (NuevaLineaCorteDeLona) panelCorteLona.getComponent(i);
        cs = listaCorteLona.get(i);
        String contadorLineaStr;
        LineaConfeccion lc;
        lc = new LineaConfeccion();  
        contadorLineaStr = "L" + this.nlp.getCodigo();
        lc.setContadorLinea(contadorLineaStr);
        lc.setNumeroDoc(p.getNumero());
        lc.setCorte("Corte de tipo " + nlcl.getTipoCorteLona());
            
        if(nlcl.getEsDespiece()){
            d = rd.getDespiecePorIndice(cs.getIndiceElemento());
            articuloBase = BaseDatos.obtenerArticuloPorIid(d.getArticulo().getIid());
            lc.setCodigo(articuloBase.getCod_articulo());
            cantidadTemporal = Util.convertirPuntoAComa(String.valueOf(rd.evaluar(cantidad1 + "*(" + d.getFormulaCantidad() + ")", d.getRedondeo(), false)));
            lc.setCant(cantidadTemporal);
            lc.setMedida(Util.convertirPuntoAComa(String.valueOf(rd.evaluar(d.getFormulaMedida1(), d.getRedondeo(), false)))  + " x " + Util.convertirPuntoAComa(String.valueOf(rd.evaluar(d.getFormulaMedida2(), d.getRedondeo(), false))));
            lc.setDescripcion(articuloBase.getDes_tecnica());
        } else {
            lc.setCodigo(this.nlp.getTCodigo());
            lc.setMedida(this.nlp.getTMedida1() + " x" + this.nlp.getTMedida2());
            lc.setCant(this.nlp.getTcantidad());
            lc.setDescripcion(this.nlp.getArticulo().getDes_tecnica());
        }

        lc.setArticulos(articulos);
        lc.setImagenConfeccion(Util.pintarLona(nlcl.getTipoCorteLona(), nlcl.getLinea().toString(), nlcl.getSalida().toString(), nlcl.getDobladillo().toString(), nlcl.getSolape().toString(),nlcl.getAnchoSeleccionado().floatValue()));           
        
        llc.add(lc);  
    }
    
    parameters.put("LineaLona", new JRBeanCollectionDataSource(llc));
        
    HashMap hashDatos = new HashMap();
    hashDatos.put("codigoToldo", this.nlp.getTCodigo());
    hashDatos.put("medida",this.nlp.getTMedida1() + " x " + this.nlp.getTMedida2());
    hashDatos.put("cantidad", this.nlp.getTcantidad());
    hashDatos.put("descripcion", this.nlp.getArticulo().getDes_tecnica());
    parameters.put("hashDatos", hashDatos);
        
    ConfeccionLonas.imprimirConfeccionLonas(parameters);
}

private void mostrarSimulacionPresupuesto(){
    
    Integer clave;
    RellenarDac rd;
    Dac dac;
    LineaConfeccionTotal lct;
    NuevaLineaCorteDeLona nlcl;
    Despiece d;
    CorteLonaSimulado cs;
    Articulo articuloBase;
    List<LineaConfeccionTotal> llct = new ArrayList<LineaConfeccionTotal>();
    Float cantidad1;
    HashMap parameters = new HashMap();
    String cantidadTemporal;
    String contadorLineaStr;
    NuevaLineaPresupuesto nlp2;
    int cortesProcesados =0;
    int contador;
    int contadorListaElementosLona = 0;
    int cortesProcesar;
    
    parameters.put("numero", p.getNumero());
    parameters.put("referencia", p.getReferencia());
    parameters.put("cliente", p.getNombreCliente());
    Date fecha = new Date(p.getFechaLong());
    SimpleDateFormat formatoFecha = new SimpleDateFormat("dd/MM/yyyy");
    parameters.put("fecha", formatoFecha.format(fecha).toString());
    HashMap rellenarDacMap = p.getRellenarDacMap();

    for(Iterator it = rellenarDacMap.keySet().iterator(); it.hasNext();) { 
        clave = (Integer)it.next();
        rd =  (RellenarDac) rellenarDacMap.get(clave);
        rd = p.getRellenarDac(clave);
        dac = rd.getDacBase();
        nlp2 = (NuevaLineaPresupuesto) p.getListaArticulos().get(clave - 1);
        cantidad1 = Float.parseFloat(Util.convertirComaAPunto(nlp2.getTcantidad()));
        if(nlp2.getTcantidad() != null && nlp2.getTcantidad().length() > 0){
            dac.setCantidad(Double.parseDouble(Util.convertirComaAPunto(nlp2.getTcantidad())));
        } else {
            dac.setCantidad(0D);
        }

        if(nlp2.getTMedida1() != null && nlp2.getTMedida1().length() > 0){
            dac.setMedida1(Double.parseDouble(Util.convertirComaAPunto(nlp2.getTMedida1())));
        } else {
            dac.setMedida1(0D);
        }

        if(nlp2.getTMedida2() != null && nlp2.getTMedida2().length() > 0){
            dac.setMedida2(Double.parseDouble(Util.convertirComaAPunto(nlp2.getTMedida2())));
        } else {
            dac.setMedida2(0D);
        }

        if(nlp2.getTMedida3() != null && nlp2.getTMedida3().length() > 0){
            dac.setMedida3(Double.parseDouble(Util.convertirComaAPunto(nlp2.getTMedida3())));
        } else {
            dac.setMedida3(0D);
        }

        if(nlp2.getTMedida5() != null &&nlp2.getTMedida5().length() > 0){
            dac.setMedida4(Double.parseDouble(Util.convertirComaAPunto(nlp2.getTMedida5())));
        } else {
            dac.setMedida4(0D);
        }

        if(nlp2.getTMedida5() != null && nlp2.getTMedida5().length() > 0){
            dac.setMedida5(Double.parseDouble(Util.convertirComaAPunto(nlp2.getTMedida5())));
        } else {
            dac.setMedida5(0D);
        }

        rd.setDacBase(dac);
        rd = new RellenarDac(rd, p, "Titulo");

        lct =new LineaConfeccionTotal();
        lct.setDato("dac");
        lct.setCodigoToldo(nlp2.getTCodigo());
        lct.setDescripcionDAC(nlp2.getArticulo().getDes_tecnica());
        lct.setCantidad(nlp2.getTcantidad());
        lct.setMedidaDac(nlp2.getTMedida1() + " x " + nlp2.getTMedida2());
        lct.setImagenConfeccion(null);
        llct.add(lct);

        String articulos = "";

        /*if(!rd.getLona().equals("")){
            articulos += "Lona: " + rd.getLona() + "\n";
        }

        if(!rd.getFaldon().equals("")){
            articulos += "Faldón: " + rd.getFaldon() + "\n";
        }

        if(!rd.getTipoFaldon().equals("")){
            articulos += "Tipo faldón: " + rd.getTipoFaldon() + "\n";
        }

        if(!rd.getRibete().equals("")){
            articulos += "Ribete: " + rd.getRibete() + "\n";
        }

        if(!rd.getManivela().equals("")){
            articulos += "Manivela: " + rd.getManivela() + "\n";
        }

        if(!rd.getBrazos().equals("")){
            articulos += "Brazos: " + rd.getBrazos() + "\n";
        }

        if(!rd.getMotor().equals("")){
            articulos += "Motor: " + rd.getMotor() + "\n";
        }

        if(!rd.getTuboEnrrolle().equals("")){
            articulos += "T. enrrolle: " + rd.getTuboEnrrolle() + "\n";
        }

        if(!rd.getTuboCarga().equals("")){
            articulos += "T. carga: " + rd.getTuboCarga() + "\n";
        }*/

        cortesProcesar = listaCortesLonaPorDac.get(contadorListaElementosLona);
        contadorListaElementosLona++;
        for(contador = 0; contador < cortesProcesar; contador++){
            nlcl = (NuevaLineaCorteDeLona) panelCorteLona.getComponent(cortesProcesados);
            cs = listaCorteLona.get(cortesProcesados);
            cortesProcesados++;

            lct =new LineaConfeccionTotal();
            lct.setDato("articulo");

            contadorLineaStr = "L" + clave;
            lct.setContadorLinea(contadorLineaStr);
            lct.setNumeroDoc(p.getNumero());
            lct.setCorte("Corte de tipo " + nlcl.getTipoCorteLona());

            if(nlcl.getEsDespiece()){
                d = rd.getDespiecePorIndice(cs.getIndiceElemento());
                articuloBase = BaseDatos.obtenerArticuloPorIid(cs.getArticulo().getIid());
                lct.setCodigo(articuloBase.getCod_articulo());
                cantidadTemporal = Util.convertirPuntoAComa(String.valueOf(rd.evaluar(cantidad1 + "*(" + d.getFormulaCantidad() + ")", d.getRedondeo(), false)));
                lct.setCant(cantidadTemporal);
                lct.setMedidaArticulo(Util.convertirPuntoAComa(String.valueOf(rd.evaluar(d.getFormulaMedida1(), d.getRedondeo(), false)))  + " x " + Util.convertirPuntoAComa(String.valueOf(rd.evaluar(d.getFormulaMedida2(), d.getRedondeo(), false))));
                lct.setDescripcionArticulo(articuloBase.getDes_tecnica());
            } else {
                lct.setCodigo(nlp2.getTCodigo());
                lct.setMedidaArticulo(nlp2.getTMedida1() + " x" + nlp2.getTMedida2());
                lct.setCant(nlp2.getTcantidad());
                lct.setDescripcionArticulo(nlp2.getArticulo().getDes_tecnica());
            }

            lct.setArticulos(articulos);
            lct.setImagenConfeccion(Util.pintarLona(nlcl.getTipoCorteLona(), nlcl.getLinea().toString(), nlcl.getSalida().toString(), nlcl.getDobladillo().toString(), nlcl.getSolape().toString(), nlcl.getAnchoSeleccionado().floatValue()));           
            llct.add(lct);
        }
    }
        
    parameters.put("LineaLonaTotal", new JRBeanCollectionDataSource(llct));
    ConfeccionLonasTotal.imprimirConfeccionLonasTotal(parameters);
}

private void bFinalizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bFinalizarActionPerformed
    boolean finalizarOperacion = true;
    NuevaLineaCorteDeLona nlcl;
    for(int i = 0; (i < lonasMostradas) && finalizarOperacion; i++){
        nlcl = (NuevaLineaCorteDeLona)panelCorteLona.getComponent(i);
        finalizarOperacion = nlcl.finalizable();
    }
    
    if(finalizarOperacion){
        if(desdeLinea){
            mostrarSimulacionLineaPresupuesto();
        }
        else {
            mostrarSimulacionPresupuesto();
        }
        cerrarVentana();
    } else {
        JOptionPane.showMessageDialog(null, "Hay anchos o restos sin seleccionar", "Error", JOptionPane.ERROR_MESSAGE);
    }
}//GEN-LAST:event_bFinalizarActionPerformed
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bCancelar;
    private javax.swing.JButton bFinalizar;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lTitulo;
    private javax.swing.JPanel panelCorteLona;
    // End of variables declaration//GEN-END:variables
}
