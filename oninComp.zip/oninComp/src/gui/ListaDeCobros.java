package gui;

import acceso.BaseDatos;
import auxiliar.Cobro;
import bean.Agentes;
import bean.Empresa;
import bean.FormaPago2;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.KeyStroke;
import modelo.Modelo;
import util.Util;

public class ListaDeCobros extends javax.swing.JFrame {
    private Empresa e;
    private String flujo;
    private SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
    private HashMap<String, Agentes> listaAgentes;
    private HashMap<Integer, FormaPago2> listaFormaPago2;
    private HashMap<String, List<Integer>> listaDiasOrdenada;

    public ListaDeCobros(Empresa e, String flujo, String desc) {
        super("Lista de " + desc);
        this.e = e;
        this.flujo = flujo;
        
        listaAgentes = new HashMap<String, Agentes>();
        listaFormaPago2 = new HashMap<Integer, FormaPago2>();
        listaDiasOrdenada = new HashMap<String, List<Integer>>();
        
        List listaTemporal = BaseDatos.getListaFormasPagosDesdeDocumentosFinalesReducidos(e.getIid(),flujo);
        initComponents();
        actualizar(crearListaCobros(listaTemporal));

        crearIconosBotones();
        crearAcciones();
    }
    
    private List<Cobro> crearListaCobros(List lista){
        List<Cobro> listaInicial = new ArrayList<Cobro>();

        if(lista != null && lista.size() > 0){
            FormaPago2 fp;
            Object[] fp2;
            Iterator iter = lista.iterator();
            Object[] fila;
            Agentes a;
            Object[] agenteReducido;
            List<Integer> listaDias = null;
            String fila0, fila1, fila2, fila6;
            Double fila3;
            Integer fila4;
            Long fila5;

            while(iter.hasNext()){
                fila = (Object[]) iter.next();
                fila0 = (String)fila[0];
                fila1 = (String)fila[1];
                fila2 = (String)fila[2];
                fila3 = (Double)fila[3];
                fila5 = (Long)fila[5];
                fila4 = (Integer)fila[4];
                fila6 = (String)fila[6];
                
                fp = listaFormaPago2.get(fila4);
                if(fp == null){
                    fp2 = BaseDatos.obtenerFormaPago2Reducido(fila4);
                    fp = new FormaPago2();
                    fp.setNumplazosadelantados((Integer) fp2[0]);
                    fp.setNumplazosvencimiento((Integer) fp2[1]);
                    fp.setTipodecalculo((String) fp2[2]);
                    fp.setFechaPlazo1((Long) fp2[3]);
                    fp.setCobrado1((String) fp2[4]);
                    fp.setFechaPlazo2((Long) fp2[5]);
                    fp.setCobrado2((String) fp2[6]);
                    fp.setFechaPlazo3((Long) fp2[7]);
                    fp.setCobrado3((String) fp2[8]);
                    fp.setFechaPlazo4((Long) fp2[9]);
                    fp.setCobrado4((String) fp2[10]);
                    fp.setFechaPlazo5((Long) fp2[11]);
                    fp.setCobrado5((String) fp2[12]);
                    fp.setFechaPlazo6((Long) fp2[13]);
                    fp.setCobrado6((String) fp2[14]);
                    fp.setFechaPlazo7((Long) fp2[15]);
                    fp.setCobrado7((String) fp2[16]);
                    fp.setFechaPlazo8((Long) fp2[17]);
                    fp.setCobrado8((String) fp2[18]);
                    fp.setFechaPlazo9((Long) fp2[19]);
                    fp.setCobrado9((String) fp2[20]);
                    fp.setFechaPlazo10((Long) fp2[21]);
                    fp.setCobrado10((String) fp2[22]);
                    fp.setPlazovm1((Integer) fp2[23]);
                    fp.setCobradoVencimiento1((String) fp2[24]);
                    fp.setPlazovm2((Integer) fp2[25]);
                    fp.setCobradoVencimiento2((String) fp2[26]);
                    fp.setPlazovm3((Integer) fp2[27]);
                    fp.setCobradoVencimiento3((String) fp2[28]);
                    fp.setPlazovm4((Integer) fp2[29]);
                    fp.setCobradoVencimiento4((String) fp2[30]);
                    fp.setPlazovm5((Integer) fp2[31]);
                    fp.setCobradoVencimiento5((String) fp2[32]);
                    fp.setPlazovm6((Integer) fp2[33]);
                    fp.setCobradoVencimiento6((String) fp2[34]);
                    fp.setPlazovm7((Integer) fp2[35]);
                    fp.setCobradoVencimiento7((String) fp2[36]);
                    fp.setPlazovm8((Integer) fp2[37]);
                    fp.setCobradoVencimiento8((String) fp2[38]);
                    fp.setPlazovm9((Integer) fp2[39]);
                    fp.setCobradoVencimiento9((String) fp2[40]);
                    fp.setPlazovm10((Integer) fp2[41]);
                    fp.setCobradoVencimiento10((String) fp2[42]);
                    listaFormaPago2.put(fila4, fp);
                }
                
                a = listaAgentes.get(fila6);
                if(a == null){
                    agenteReducido = BaseDatos.obtenerAgentePorEmpresaYCodigoReducido(e.getIid(), fila6);
                    a = new Agentes();
                    if(agenteReducido != null){
                        a.setNombre_comercial((String) agenteReducido[0]);
                        a.setDiaCobro1((Integer) agenteReducido[1]);
                        a.setDiaCobro2((Integer) agenteReducido[2]);
                        a.setDiaCobro3((Integer) agenteReducido[3]);
                        listaDiasOrdenada.put(fila6, a.ordenarDiasCobro());
                    } else {
                        listaDiasOrdenada.put(fila6, null);
                    }
                    listaAgentes.put(fila6, a);
                }
                
                listaDias = listaDiasOrdenada.get(fila6);
                
                if(fp.getNumplazosadelantados() > 0){
                    listaInicial.add(new Cobro(fila0, fila1, fila2, fila3, fp.getFechaPlazo1(), fp.getCobrado1(), "P. Adelantado"));
                }
                if(fp.getNumplazosadelantados() > 1){
                    listaInicial.add(new Cobro(fila0, fila1, fila2, fila3, fp.getFechaPlazo2(), fp.getCobrado2(), "P. Adelantado"));
                }
                if(fp.getNumplazosadelantados() > 2){
                    listaInicial.add(new Cobro(fila0, fila1, fila2, fila3, fp.getFechaPlazo3(), fp.getCobrado3(), "P. Adelantado"));
                }
                if(fp.getNumplazosadelantados() > 3){
                    listaInicial.add(new Cobro(fila0, fila1, fila2, fila3, fp.getFechaPlazo4(), fp.getCobrado4(), "P. Adelantado"));
                }
                if(fp.getNumplazosadelantados() > 4){
                    listaInicial.add(new Cobro(fila0, fila1, fila2, fila3, fp.getFechaPlazo5(), fp.getCobrado5(), "P. Adelantado"));
                }
                if(fp.getNumplazosadelantados() > 5){
                    listaInicial.add(new Cobro(fila0, fila1, fila2, fila3, fp.getFechaPlazo6(), fp.getCobrado6(), "P. Adelantado"));
                }
                if(fp.getNumplazosadelantados() > 6){
                    listaInicial.add(new Cobro(fila0, fila1, fila2, fila3, fp.getFechaPlazo7(), fp.getCobrado7(), "P. Adelantado"));
                }
                if(fp.getNumplazosadelantados() > 7){
                    listaInicial.add(new Cobro(fila0, fila1,fila2, fila3, fp.getFechaPlazo8(), fp.getCobrado8(), "P. Adelantado"));
                }
                if(fp.getNumplazosadelantados() > 8){
                    listaInicial.add(new Cobro(fila0, fila1, fila2, fila3, fp.getFechaPlazo9(), fp.getCobrado9(), "P. Adelantado"));
                }
                if(fp.getNumplazosadelantados() > 9){
                    listaInicial.add(new Cobro(fila0, fila1,fila2, fila3, fp.getFechaPlazo10(), fp.getCobrado10(), "P. Adelantado"));
                }
               
                if(fp.getNumplazosvencimiento() > 0){
                    listaInicial.add(new Cobro(fila0, fila1, fila2, fila3, Util.calcularFecha(fp.getPlazovm1() , fp.getTipodecalculo(), fila5 , listaDias), fp.getCobradoVencimiento1(), "Vencimiento"));
                }
                if(fp.getNumplazosvencimiento() > 1){
                    listaInicial.add(new Cobro(fila0, fila1, fila2, fila3, Util.calcularFecha(fp.getPlazovm2() , fp.getTipodecalculo(), fila5 , listaDias), fp.getCobradoVencimiento2(), "Vencimiento"));
                }
                if(fp.getNumplazosvencimiento() > 2){
                    listaInicial.add(new Cobro(fila0, fila1, fila2, fila3, Util.calcularFecha(fp.getPlazovm3() , fp.getTipodecalculo(), fila5 , listaDias), fp.getCobradoVencimiento3(), "Vencimiento"));
                }
                if(fp.getNumplazosvencimiento() > 3){
                    listaInicial.add(new Cobro(fila0, fila1, fila2, fila3, Util.calcularFecha(fp.getPlazovm4() , fp.getTipodecalculo(), fila5 , listaDias), fp.getCobradoVencimiento4(), "Vencimiento"));
                }
                if(fp.getNumplazosvencimiento() > 4){
                    listaInicial.add(new Cobro(fila0, fila1, fila2, fila3, Util.calcularFecha(fp.getPlazovm5() , fp.getTipodecalculo(), fila5 , listaDias), fp.getCobradoVencimiento5(), "Vencimiento"));
                }
                if(fp.getNumplazosvencimiento() > 5){
                    listaInicial.add(new Cobro(fila0, fila1,  fila2, fila3, Util.calcularFecha(fp.getPlazovm6() , fp.getTipodecalculo(), fila5 , listaDias), fp.getCobradoVencimiento6(), "Vencimiento"));
                }
                if(fp.getNumplazosvencimiento() > 6){
                    listaInicial.add(new Cobro(fila0, fila1, fila2, fila3, Util.calcularFecha(fp.getPlazovm7() , fp.getTipodecalculo(), fila5 , listaDias), fp.getCobradoVencimiento7(), "Vencimiento"));
                }
                if(fp.getNumplazosvencimiento() > 7){
                    listaInicial.add(new Cobro(fila0, fila1, fila2, fila3, Util.calcularFecha(fp.getPlazovm8() , fp.getTipodecalculo(), fila5 , listaDias), fp.getCobradoVencimiento8(), "Vencimiento"));
                }
                if(fp.getNumplazosvencimiento() > 8){
                    listaInicial.add(new Cobro(fila0, fila1, fila2, fila3, Util.calcularFecha(fp.getPlazovm9() , fp.getTipodecalculo(), fila5 , listaDias), fp.getCobradoVencimiento9(), "Vencimiento"));
                }
                if(fp.getNumplazosvencimiento() > 9){
                    listaInicial.add(new Cobro(fila0, fila1, fila2, fila3, Util.calcularFecha(fp.getPlazovm10() , fp.getTipodecalculo(), fila5 , listaDias), fp.getCobradoVencimiento10(), "Vencimiento"));
                }
            }
        }
        return listaInicial;
    }

    private void actualizar(List<Cobro> lista) {
        Modelo modelo = (Modelo) tCobro.getModel();
        int i, j = modelo.getRowCount();
        j--;

        //eliminamos todas las filas
        for (i = j; i >= 0; i--) {
            modelo.removeRow(i);
        }

        if (lista == null) {
            lista = new ArrayList();
        }

        Cobro c;
        Iterator<Cobro> it1;
        Object[] fila1;
        if (lista != null) {
            for (it1 = lista.iterator(); it1.hasNext();) {
                fila1 = new Object[7];
                c = it1.next();
                fila1[0] = c.getNumero();
                fila1[1] = c.getNombre();
                fila1[2] = c.getTipoDocumento();
                fila1[3] = Util.convertirPuntoAComa(c.getImporte().toString());
                if(c.getFechaVencimiento() != null){
                    fila1[4] = formato.format(new Date(c.getFechaVencimiento()));
                }
                fila1[5] = c.getTipoCobro();
                fila1[6] = c.getCobrado();
                modelo.addRow(fila1);
            }
        }
    }

    private void crearIconosBotones() {
        URL urlCerrar = getClass().getResource("/iconos/cancelar.gif");
        ImageIcon iconoCerrar = new ImageIcon(urlCerrar);
        bcancelar.setIcon(iconoCerrar);
    }
    
    private void crearAcciones() {
        KeyStroke escapeKeyStroke = KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false);
        Action escapeAction = new AbstractAction() {
            public void actionPerformed(ActionEvent e) {
                cerrarListadoCobros();
            }
        }; 
        getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(escapeKeyStroke, "ESCAPE");
        getRootPane().getActionMap().put("ESCAPE", escapeAction);
    
        Dimension dim = Util.getDimensiones(this.getSize());
        if(dim != null){
            setResizable(true);
            setSize(dim);
            setResizable(false);
        }
    }
    
    private void cerrarListadoCobros(){
        listaAgentes.clear();
        listaFormaPago2.clear();
        listaDiasOrdenada.clear();
        removeAll();
        dispose();
    }

    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        bcancelar = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        jPanel1 = new javax.swing.JPanel();
        bCobrado = new javax.swing.JRadioButton();
        bTipoDocumento = new javax.swing.JRadioButton();
        bFechaVencimiento = new javax.swing.JRadioButton();
        tBusqueda = new javax.swing.JTextField();
        bNumero = new javax.swing.JRadioButton();
        bImporte = new javax.swing.JRadioButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        Modelo modelo1 = new Modelo();
        modelo1.addColumn("Número");
        modelo1.addColumn("Nombre");
        modelo1.addColumn("Tipo Documento");
        modelo1.addColumn("Importe");
        modelo1.addColumn("Fecha");
        modelo1.addColumn("Tipo");
        modelo1.addColumn("Cobrado");
        tCobro = new javax.swing.JTable(modelo1);
        bNombre = new javax.swing.JRadioButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        bcancelar.setText("Cerrar");
        bcancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bcancelarActionPerformed(evt);
            }
        });

        buttonGroup1.add(bCobrado);
        bCobrado.setText("Cobrado");
        bCobrado.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bCobradoActionPerformed(evt);
            }
        });

        buttonGroup1.add(bTipoDocumento);
        bTipoDocumento.setText("T. Documento");
        bTipoDocumento.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bTipoDocumentoActionPerformed(evt);
            }
        });

        buttonGroup1.add(bFechaVencimiento);
        bFechaVencimiento.setText("F. Vencimiento");
        bFechaVencimiento.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bFechaVencimientoActionPerformed(evt);
            }
        });

        tBusqueda.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tBusquedaKeyReleased(evt);
            }
        });

        buttonGroup1.add(bNumero);
        bNumero.setText("Número");
        bNumero.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bNumeroActionPerformed(evt);
            }
        });

        buttonGroup1.add(bImporte);
        bImporte.setText("Importe");
        bImporte.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bImporteActionPerformed(evt);
            }
        });

        tCobro.getColumnModel().getColumn(0).setPreferredWidth(65);
        tCobro.getColumnModel().getColumn(1).setPreferredWidth(220);
        tCobro.getColumnModel().getColumn(2).setPreferredWidth(110);
        tCobro.getColumnModel().getColumn(3).setPreferredWidth(60);
        tCobro.getColumnModel().getColumn(4).setPreferredWidth(65);
        tCobro.getColumnModel().getColumn(5).setPreferredWidth(90);
        tCobro.getColumnModel().getColumn(6).setPreferredWidth(55);
        tCobro.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        jScrollPane1.setViewportView(tCobro);

        buttonGroup1.add(bNombre);
        bNombre.setText("Nombre");
        bNombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bNombreActionPerformed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout jPanel1Layout = new org.jdesktop.layout.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jPanel1Layout.createSequentialGroup()
                        .add(tBusqueda, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 285, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(bNumero)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(bNombre)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(bTipoDocumento)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(bImporte)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(bFechaVencimiento)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(bCobrado))
                    .add(jScrollPane1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 695, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(26, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(tBusqueda, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(bNumero)
                    .add(bNombre)
                    .add(bTipoDocumento)
                    .add(bImporte)
                    .add(bFechaVencimiento)
                    .add(bCobrado))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jScrollPane1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 523, Short.MAX_VALUE))
        );

        jScrollPane2.setViewportView(jPanel1);

        org.jdesktop.layout.GroupLayout layout = new org.jdesktop.layout.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, layout.createSequentialGroup()
                .addContainerGap(671, Short.MAX_VALUE)
                .add(bcancelar, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 88, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
            .add(jScrollPane2, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 769, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, layout.createSequentialGroup()
                .add(jScrollPane2, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 589, Short.MAX_VALUE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(bcancelar)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

private List<Cobro> purgarListaCobros(List<Cobro> listaCobros, String campo, String valor){
    
    if(valor.length() == 0){
        return listaCobros;
    }
    
    List<Cobro> res = new ArrayList<Cobro>();
    if(listaCobros != null){
        Iterator<Cobro> iter = listaCobros.iterator();
        Cobro c;
        boolean insertar;
        while(iter.hasNext()){
            c = iter.next();
            insertar = false;
            if(campo.equals("importe")){
                if(c.getImporte() != null && Util.convertirPuntoAComa(c.getImporte().toString()).toLowerCase().contains(valor)){
                    insertar = true;
                }
            } else if(campo.equals("cobrado")){
                if(c.getCobrado() != null && c.getCobrado().toString().toLowerCase().contains(valor)){
                    insertar = true;
                }
            } else if(campo.equals("fecha")){
                if(c.getFechaVencimiento() != null){
                    String fechaString = formato.format(new Date(c.getFechaVencimiento()));
                    if(c.getFechaVencimiento() != null && fechaString.toLowerCase().contains(valor)){
                        insertar = true;
                    }
                }
            } else if(campo.equals("nombre")){
                if(c.getNombre() != null && c.getNombre().toString().toLowerCase().contains(valor)){
                    insertar = true;
                }
            }
            
            if(insertar){
                res.add(c);
            }
        }
    }
    
    return res;
}
    
private void bcancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bcancelarActionPerformed
    cerrarListadoCobros();
}//GEN-LAST:event_bcancelarActionPerformed

private void tBusquedaKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tBusquedaKeyReleased
    obtenerResultado();
}//GEN-LAST:event_tBusquedaKeyReleased

private void bNumeroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bNumeroActionPerformed
    obtenerResultado();
}//GEN-LAST:event_bNumeroActionPerformed

private void bNombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bNombreActionPerformed
    obtenerResultado();
}//GEN-LAST:event_bNombreActionPerformed

private void bTipoDocumentoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bTipoDocumentoActionPerformed
    obtenerResultado();
}//GEN-LAST:event_bTipoDocumentoActionPerformed

private void bImporteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bImporteActionPerformed
    obtenerResultado();
}//GEN-LAST:event_bImporteActionPerformed

private void bFechaVencimientoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bFechaVencimientoActionPerformed
    obtenerResultado();
}//GEN-LAST:event_bFechaVencimientoActionPerformed

private void bCobradoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bCobradoActionPerformed
    obtenerResultado();
}//GEN-LAST:event_bCobradoActionPerformed

private void obtenerResultado(){
    if (bNumero.isSelected()) {
        actualizar(crearListaCobros(BaseDatos.getListaFormasPagosDesdeDocumentosFinalesNumeroReducido(e.getIid(), tBusqueda.getText().toLowerCase(), flujo)));
    } else if(bNombre.isSelected()){
        List<Cobro> listaCobros = crearListaCobros(BaseDatos.getListaFormasPagosDesdeDocumentosFinalesReducidos(e.getIid(),flujo));
        listaCobros = purgarListaCobros(listaCobros, "nombre", tBusqueda.getText().toLowerCase());
        actualizar(listaCobros);
    } else if(bTipoDocumento.isSelected()){
        actualizar(crearListaCobros(BaseDatos.getListaFormasPagosDesdeDocumentosFinalesTipoDocumentoReducido(e.getIid(), tBusqueda.getText().toLowerCase(), flujo)));
    } else if(bImporte.isSelected()){
        List<Cobro> listaCobros = crearListaCobros(BaseDatos.getListaFormasPagosDesdeDocumentosFinalesReducidos(e.getIid(),flujo));
        listaCobros = purgarListaCobros(listaCobros, "importe", tBusqueda.getText().toLowerCase());
        actualizar(listaCobros);
    } else if(bFechaVencimiento.isSelected()){
        List<Cobro> listaCobros = crearListaCobros(BaseDatos.getListaFormasPagosDesdeDocumentosFinalesReducidos(e.getIid(),flujo));
        listaCobros = purgarListaCobros(listaCobros, "fecha", tBusqueda.getText().toLowerCase());
        actualizar(listaCobros);
    } else if(bCobrado.isSelected()){
        List<Cobro> listaCobros = crearListaCobros(BaseDatos.getListaFormasPagosDesdeDocumentosFinalesReducidos(e.getIid(),flujo));
        listaCobros = purgarListaCobros(listaCobros, "cobrado", tBusqueda.getText().toLowerCase());
        actualizar(listaCobros);
    }
}
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JRadioButton bCobrado;
    private javax.swing.JRadioButton bFechaVencimiento;
    private javax.swing.JRadioButton bImporte;
    private javax.swing.JRadioButton bNombre;
    private javax.swing.JRadioButton bNumero;
    private javax.swing.JRadioButton bTipoDocumento;
    private javax.swing.JButton bcancelar;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextField tBusqueda;
    private javax.swing.JTable tCobro;
    // End of variables declaration//GEN-END:variables
}
