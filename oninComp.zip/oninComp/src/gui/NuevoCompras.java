package gui;

import acceso.BaseDatos;
import auxiliar.Objeto2Elementos;
import auxiliar.PdfFilter;
import informes.Informe;
import bean.Agentes;
import bean.Almacen;
import bean.Articulo;
import bean.Caracteristica;
import bean.ClaseDocumento;
import bean.Comercial;
import bean.Empresa;
import bean.EstadoDocumento;
import bean.FamiliaVenta;
import bean.TipoMovimientoAlmacen;
import bean.MovimientoAlmacen;
import bean.FormaPago;
import bean.FormaPago2;
import bean.Iva;
import bean.LineaPresupuesto;
import bean.Metadata;
import bean.Presupuesto;
import bean.TipoAgente;
import bean.TipoControl;
import bean.TipoMedida;
import bean.Usuario;
import informes.recibos.Recibo;
import informes.recibos.VencimientoImpreso;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.net.URL;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.KeyStroke;
import javax.swing.ScrollPaneLayout;
import modelo.Modelo;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import util.Constantes;
import util.Util;

public class NuevoCompras extends javax.swing.JFrame {

    private int num_articulos;
    private List listaArticulos;
    private Empresa e;
    private FormaPago fp;
    private FormaPago2 fp2;
    private FormaPago2 fp2_aux;
    private double importe_total = 0;
    private double importe_total_dto = 0;
    private double dto = 0;
    private double precio_dto = 0;
    private double precio_iva;
    private double precio_final;
    private boolean crear;
    private Presupuesto p;
    private Integer cod_fp2;
    private boolean creacion;
    private ClaseDocumento cd;
    private Iva iva;
    private Usuario u;
    private boolean pagado;
    private boolean impagado;
    private Comercial comercial;
    private int lineaActiva;
    private int lineasVacias = 0;
    private Articulo a;
    private HashMap<Integer, Integer> mapaNuevoClaves;
    ListaDeCompras ldc;

    public NuevoCompras(Empresa e, ClaseDocumento cd, Usuario u, ListaDeCompras ldc) {
        super("Onin : " + cd.getDescripcion());
        creacion = true;
        fp = null;
        fp2 = null;
        fp2_aux = null;
        num_articulos = 1;
        this.e = e;
        this.u = u;
        this.cd = cd;
        this.ldc = ldc;
        p = new Presupuesto();
        p.setClase_documento(this.cd);
        crear = true;
        listaArticulos = new ArrayList();
        initComponents();
        
        jMenuAlbaran.setEnabled(false);
        lCliente.setText("Proveedor");

        lconvertido.setText(" ");
        anadirLineaPresupuesto();

        Metadata mdtIva = (Metadata) BaseDatos.obtenerMetadaPorNombre("ivaDocumento", e.getIid());
        iva = BaseDatos.obtenerIvaPorPorcentaje(mdtIva.getValor());
        tIva.setText(Util.convertirPuntoAComa(mdtIva.getValor()));
        tIva.setEnabled(false);

        cod_fp2 = -1;
        creacion = false;

        pagado = false;
        impagado = false;
        comercial = null;

        Date fecha = new Date(); // fecha y hora locales
        SimpleDateFormat formatoFecha = new SimpleDateFormat("dd/MM/yyyy");
        tfecha.setText(formatoFecha.format(fecha));

        lineaActiva = 0;

        crearIconosBotones();

        //this.cestado.setVisible(false);
        //this.lestado.setVisible(false);

        jMenuPagado.setEnabled(false);
        jMenuImpagado.setEnabled(false);
        crearAcciones();

        if(this.getTitle() != null && this.getTitle().contains(Constantes.FACTURA)){
            jMenuImprimirRecibos.setEnabled(false);
        }

    }

    public NuevoCompras(Empresa e, ClaseDocumento cd, Usuario u, Articulo a, Caracteristica c) {
        super("Onin : " + cd.getDescripcion());
        
        creacion = true;
        fp = null;
        fp2 = null;
        fp2_aux = null;
        num_articulos = 1;
        this.e = e;
        this.u = u;
        this.cd = cd;
        this.a = a;
        p = new Presupuesto();
        p.setClase_documento(this.cd);
        crear = true;
        listaArticulos = new ArrayList();
        initComponents();
        //Establece como proveedor habitual
        if (a.getProv_hab() != null) {
            Agentes pr = BaseDatos.obtenerAgenteByIid(a.getProv_hab().getIid());
            p.setCodigoCliente(pr.getCod_agente());
            p.setCifCliente(pr.getCif_nif());
            p.setNombreCliente(pr.getNombre_fiscal());
            p.setDomicilioCliente(pr.getDireccion_fiscal());
            p.setProvinciaCliente(pr.getProvincia_fiscal());
            p.setCpCliente(pr.getCodigo_postal_fiscal().toString());
            p.setLocalidadCliente(pr.getPoblacion_fiscal());
            p.setTelefonoCliente(pr.getTelefono());
            p.setEmailCliente(pr.getEmail());

            //Añadir a las cajas de textos
            tCodCliente.setText(p.getCodigoCliente());
            tDniCliente.setText(p.getCifCliente());
            tNombreCliente.setText(p.getNombreCliente());
            tLocalidadCliente.setText(p.getDomicilioCliente());
            tProvinciaCliente.setText(p.getProvinciaCliente());
            tCpCliente.setText(p.getCpCliente());
            tLocalidadCliente.setText(p.getLocalidadCliente());
            tTelefonoCliente.setText(p.getTelefonoCliente());
            tEmailCliente.setText(p.getEmailCliente());

        } else {
            p.setCodigoCliente("Proveedor Dummy");
            tCodCliente.setText(p.getCodigoCliente());
        }


        if ((cd.getDescripcion().equals(Constantes.ALBARANC))
                || (cd.getDescripcion().equals(Constantes.FACTURAC))) {
            jMenuAlbaran.setEnabled(false);
        }


        lconvertido.setText(" ");

        LineaPresupuesto lp = new LineaPresupuesto();

        lp.setArticulo_iid(a);
        lp.setCantidad(1.0);

        FamiliaVenta fv = BaseDatos.obtenerFamiliaVentaPorIid(a.getIid_fam_venta().getIid());
        TipoControl tp = BaseDatos.obtenerTipoControlPorIid(fv.getIid_tipo_control().getIid());
        TipoMedida tm = BaseDatos.obtenerTipoMedidaByIid(tp.getIid_tipo_medida().getIid());
        lp.setNummedidas(tm.getNum_dimensiones());
             
        lp.setPrecio(0.0);
        
        if (c == null) {
            List<Caracteristica> lc = BaseDatos.getListaCaracteristicas(e, a);
            if (!lc.isEmpty()) {
                c = (Caracteristica) lc.get(0);
                lp.setCaracteristica(c);
            }
        } else {
            lp.setCaracteristica(c);
        }
        mapaNuevoClaves = new HashMap<Integer, Integer>();

        Metadata mdtIva = (Metadata) BaseDatos.obtenerMetadaPorNombre("ivaDocumento", e.getIid());
        iva = BaseDatos.obtenerIvaPorPorcentaje(mdtIva.getValor());
        tIva.setText(Util.convertirPuntoAComa(mdtIva.getValor()));
        tIva.setEnabled(false);

        cod_fp2 = -1;
        creacion = false;

        if (cd.getDescripcion().equals("Presupuesto")) {
            jMenuAlbaran.setText("Convertir a Albarán");
        } else if (cd.getDescripcion().equals("Albarán")) {
            jMenuAlbaran.setText("Convertir a Factura");
        } else {
            jMenuAlbaran.setText("Convertir");
        }
        pagado = false;
        impagado = false;

        Date fecha = new Date(); // fecha y hora locales
        SimpleDateFormat formatoFecha = new SimpleDateFormat("dd/MM/yyyy");
        tfecha.setText(formatoFecha.format(fecha));
        lineaActiva = 0;

        crearIconosBotones();
                
        jMenuPagado.setEnabled(false);
        jMenuImpagado.setEnabled(false);
        crearAcciones();

        if(this.getTitle() != null && this.getTitle().contains(Constantes.FACTURA)){
            jMenuImprimirRecibos.setEnabled(false);
        }
       
       
       anadirLineaPresupuesto(lp);
       setVisible(true);
 
    }

    public NuevoCompras(Empresa e, Presupuesto p, Usuario u, ClaseDocumento cd, ListaDeCompras ldc) {
        super("Onin : " + cd.getDescripcion());
        creacion = true;
        crear = false;
        this.p = p;
        this.e = e;
        this.u = u;
        this.cd = cd;
        this.ldc = ldc;
        num_articulos = 1;
        initComponents();

        lCliente.setText("Proveedor");

        lconvertido.setText(" ");

        iva = BaseDatos.obtenerIvaPorIid(p.getIva().getIid());
        tIva.setText(Util.convertirPuntoAComa(iva.getPorcentaje().toString()));
        tIva.setEnabled(false);

        fp2 = BaseDatos.obtenerFormaPago2(p.getFp().getIid());
        fp2_aux = new FormaPago2();
        fp2_aux.modificar(fp2);
        fp2_aux.setIid(fp2.getIid());
        if (fp2 != null) {
            cod_fp2 = fp2.getIid();
            fp = BaseDatos.obtenerFormaPago(String.valueOf(fp2.getCodigo()));
            cformapago.setSelectedItem(fp.getCodigo());
        }

        if (((String) cformapago.getSelectedItem()).equals(Constantes.VACIO)) {
            bcrearplazo.setEnabled(false);
            beliminarplazo.setEnabled(false);
            bmodificarplazo.setEnabled(false);
        }

        cSeries.setSelectedItem(p.getSerie());
        listaArticulos = new ArrayList();
        tdto.setText(Util.convertirPuntoAComa(String.valueOf(p.getDto())));
        tnumero.setText(p.getNumero());


        if (p.getEstado() != null) {
            EstadoDocumento ed = BaseDatos.obtenerEstadoPorIid(p.getEstado().getIid());
            cestado.setSelectedItem(ed.getDescripcion());
        } else {
            cestado.setSelectedIndex(0);
        }


        tObservaciones.setText(p.getObservaciones());
        tCodCliente.setText(p.getCodigoCliente());
        tDniCliente.setText(p.getCifCliente());
        tNombreCliente.setText(p.getNombreCliente());
        tDireccionCliente.setText(p.getDomicilioCliente());
        tLocalidadCliente.setText(p.getLocalidadCliente());
        tProvinciaCliente.setText(p.getProvinciaCliente());
        tPaisCliente.setText(p.getPaisCliente());
        tTelefonoCliente.setText(p.getTelefonoCliente());
        tEmailCliente.setText(p.getEmailCliente());
        tCpCliente.setText(p.getCpCliente());
        calcularNuevoIva(p.getCifCliente());

        creacion = false;

        if (this.p.getConvertido()) {
            lconvertido.setText("Este " + cd.getDescripcion() + " ya ha sido convertido");
        }

        cargarLineasPresupuesto();
        calcularPrecio();

        boolean hayNotasDocumento = false;
        hayNotasDocumento = p.getNota_documento() != null && !p.getNota_documento().equals("");

        boolean tieneObservacionesCliente = false;
        Agentes cliente = BaseDatos.obtenerAgentePorEmpresaYCodigo(e.getIid(), p.getCodigoCliente());
        if (cliente != null) {
            tieneObservacionesCliente = cliente.getObservaciones() != null && !cliente.getObservaciones().equals("");
        }

        if (hayNotasDocumento && tieneObservacionesCliente) {
            JOptionPane.showMessageDialog(null, "Este documento tiene notas asociadas\nEste cliente tiene observaciones asociadas", "Información", JOptionPane.INFORMATION_MESSAGE);
            bVerNotas.setEnabled(true);
        } else if (hayNotasDocumento) {
            JOptionPane.showMessageDialog(null, "Este documento tiene notas asociadas", "Información", JOptionPane.INFORMATION_MESSAGE);
            bVerNotas.setEnabled(true);
        } else if (tieneObservacionesCliente) {
            JOptionPane.showMessageDialog(null, "Este cliente tiene observaciones asociadas", "Información", JOptionPane.INFORMATION_MESSAGE);
            bVerNotas.setEnabled(true);
        }
        
        if(hayNotasDocumento){
            URL urlExclamacion = getClass().getResource("/iconos/exclamacion.PNG");
            ImageIcon iconoExclamacion = new ImageIcon(urlExclamacion);
            bHayNotas.setIcon(iconoExclamacion);
            bHayNotas.setToolTipText("Hay notas");
        } else {
            bHayNotas.setVisible(false);
        }

        tReferencia.setText(p.getReferencia());

        if (cd.getDescripcion().equals("Presupuesto")) {
            jMenuPagado.setEnabled(false);
            jMenuImpagado.setEnabled(false);
        } else {
            jMenuPagado.setEnabled(true);
            jMenuImpagado.setEnabled(true);
        }
        pagado = p.getPagado();
        impagado = p.getImpagado();

        //Obtener fecha de entrega
        SimpleDateFormat formatoDelTexto = new SimpleDateFormat("dd/MM/yyyy");
        
        tfecha.setText(formatoDelTexto.format(p.getFecha()));

        limpiarPlazosAdelantados();
        rellenarPlazosAdelantados();
        limpiarVencimientos();
        rellenarVencimientos();

        crearIconosBotones();
        habilitarControles(false);

        crearAcciones();

        Almacen alm = BaseDatos.obtenerAlmacenById(p.getAlmacen().getIid());
        cAlmacen.setSelectedItem(alm.getNombre());

        if(this.getTitle() != null && this.getTitle().contains(Constantes.FACTURA)){
            jMenuImprimirRecibos.setEnabled(false);
        }
    }

    
    private void calcularNuevoIva(String cifCliente) {
        Agentes cliente = BaseDatos.obtenerAgentesCif(cifCliente, e);
        if (cliente != null) {
            String serie = (String) cSeries.getSelectedItem();
            if (serie.equals(Constantes.SERIE_STD)) {
                if (cliente.getExento_iva() != null && cliente.getExento_iva()) {
                    tIva.setText("0,0");
                    lIva.setText("Exento Iva");
                } else {
                    if (cliente.getIva() != null) {
                        iva = BaseDatos.obtenerIvaPorIid(cliente.getIva().getIid());
                    }
                    tIva.setText(Util.convertirPuntoAComa(String.valueOf(iva.getPorcentaje())));
                    lIva.setText("% IVA");
                }
            } else if (serie.equals(Constantes.SERIE_SEC)) {
                tIva.setText("0,0");
            }
            calcularPrecio();
        }
    }
    
    private void calcularNuevoIva(Agentes cliente) {
        if (cliente != null) {
            String serie = (String) cSeries.getSelectedItem();
            if (serie.equals(Constantes.SERIE_STD)) {
                if (cliente.getExento_iva() != null && cliente.getExento_iva()) {
                    tIva.setText("0,0");
                    lIva.setText("Exento Iva");
                } else {
                    if (cliente.getIva() != null) {
                        iva = cliente.getIva();
                    } else {
                        Metadata mdtIva = (Metadata) BaseDatos.obtenerMetadaPorNombre("ivaDocumento", e.getIid());
                        iva = BaseDatos.obtenerIvaPorPorcentaje(mdtIva.getValor());
                    }
                    
                    tIva.setText(Util.convertirPuntoAComa(String.valueOf(iva.getPorcentaje())));
                    lIva.setText("% IVA");
                }
            } else if (serie.equals(Constantes.SERIE_SEC)) {
                tIva.setText("0,0");
            }
            calcularPrecio();
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane14 = new javax.swing.JScrollPane();
        jPanel1 = new javax.swing.JPanel();
        tIva = new javax.swing.JTextField();
        lPrecioTotalBruto = new javax.swing.JLabel();
        limporte_iva = new javax.swing.JLabel();
        lObservaciones = new javax.swing.JLabel();
        ldto = new javax.swing.JLabel();
        lTotal = new javax.swing.JLabel();
        lprecio = new javax.swing.JLabel();
        lSubTotal = new javax.swing.JLabel();
        tdto = new javax.swing.JTextField();
        limporte_dto = new javax.swing.JLabel();
        lprecio_final = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        tObservaciones = new javax.swing.JTextArea();
        lIva = new javax.swing.JLabel();
        ltotalbruto = new javax.swing.JLabel();
        lfecha = new javax.swing.JLabel();
        lnumero = new javax.swing.JLabel();
        tfecha = new javax.swing.JTextField();
        tnumero = new javax.swing.JTextField();
        bAnadirNotas = new javax.swing.JButton();
        bVerNotas = new javax.swing.JButton();
        cSeries = new javax.swing.JComboBox();
        lReferencia = new javax.swing.JLabel();
        tReferencia = new javax.swing.JTextField();
        lestado = new javax.swing.JLabel();
        cestado = new javax.swing.JComboBox();
        lnombre = new javax.swing.JLabel();
        ldomicilio = new javax.swing.JLabel();
        tLocalidadCliente = new javax.swing.JTextField();
        tProvinciaCliente = new javax.swing.JTextField();
        tNombreCliente = new javax.swing.JTextField();
        ltelefono = new javax.swing.JLabel();
        tCodCliente = new javax.swing.JTextField();
        binsertarCliente = new javax.swing.JButton();
        ldni = new javax.swing.JLabel();
        tDireccionCliente = new javax.swing.JTextField();
        bImprimir = new javax.swing.JButton();
        bCrearPdf = new javax.swing.JButton();
        bMandarMail = new javax.swing.JButton();
        lconvertido = new javax.swing.JLabel();
        tPaisCliente = new javax.swing.JTextField();
        tDniCliente = new javax.swing.JTextField();
        tTelefonoCliente = new javax.swing.JTextField();
        lPais = new javax.swing.JLabel();
        lLocalidad = new javax.swing.JLabel();
        tProvincia = new javax.swing.JLabel();
        lCliente = new javax.swing.JLabel();
        lCpCliente = new javax.swing.JLabel();
        tCpCliente = new javax.swing.JTextField();
        lEmailCliente = new javax.swing.JLabel();
        tEmailCliente = new javax.swing.JTextField();
        bGuardarCliente = new javax.swing.JButton();
        lAlmacen = new javax.swing.JLabel();
        cAlmacen = new javax.swing.JComboBox();
        bVerNotasCliente = new javax.swing.JButton();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel2 = new javax.swing.JPanel();
        ttitulo2 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        panel = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        Modelo modeloplazosadelantados = new Modelo();
        tplazosadelantados = new javax.swing.JTable(modeloplazosadelantados);
        beliminarplazo = new javax.swing.JButton();
        bmodificarplazo = new javax.swing.JButton();
        bcrearplazo = new javax.swing.JButton();
        lformapago1 = new javax.swing.JLabel();
        lformapago2 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        Modelo modelovencimientos = new Modelo();
        tvencimientos = new javax.swing.JTable(modelovencimientos);
        bCrearVencimiento = new javax.swing.JButton();
        beliminarvencimiento = new javax.swing.JButton();
        bmodificarvencimiento = new javax.swing.JButton();
        lformapago = new javax.swing.JLabel();
        cformapago = new javax.swing.JComboBox();
        tformapago = new javax.swing.JTextField();
        bHayNotas = new javax.swing.JButton();
        bInsertarArticuloAntes = new javax.swing.JButton();
        bInsertarArticuloDespues = new javax.swing.JButton();
        bInsertarArticuloPrincipio = new javax.swing.JButton();
        bInsertarArticuloFinal = new javax.swing.JButton();
        bInsertarNotaAntes = new javax.swing.JButton();
        bInsertarNotaDespues = new javax.swing.JButton();
        bInsertarNotaPrincipio = new javax.swing.JButton();
        bInsertarNotaFinal = new javax.swing.JButton();
        bDatosConversion = new javax.swing.JButton();
        bFlujoDatos = new javax.swing.JButton();
        baceptar = new javax.swing.JButton();
        bguardar = new javax.swing.JButton();
        bmodificar = new javax.swing.JButton();
        bcancelar = new javax.swing.JButton();
        jMenuBar70 = new javax.swing.JMenuBar();
        jMenuOpciones69 = new javax.swing.JMenu();
        jMenuAlbaran = new javax.swing.JMenuItem();
        jMenuPDF = new javax.swing.JMenuItem();
        jMenuPagado = new javax.swing.JMenuItem();
        jMenuImpagado = new javax.swing.JMenuItem();
        jMenuImprimirRecibos = new javax.swing.JMenuItem();
        jSeparator3 = new javax.swing.JSeparator();
        jSeparator1 = new javax.swing.JSeparator();
        jMenuItemNotaPrincipio = new javax.swing.JMenuItem();
        jMenuItemNotaFinal = new javax.swing.JMenuItem();
        jMenuItemNotaAntes = new javax.swing.JMenuItem();
        jMenuItemNotaDespues = new javax.swing.JMenuItem();
        jSeparator2 = new javax.swing.JSeparator();
        jMenuItemLineaPrincipio = new javax.swing.JMenuItem();
        jMenuItemLineaFinal = new javax.swing.JMenuItem();
        jMenuItemLineaAntes = new javax.swing.JMenuItem();
        jMenuItemLineaDespues = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        jScrollPane14.setBackground(new java.awt.Color(255, 153, 153));

        tIva.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        tIva.setText("0.0");
        tIva.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tIvaKeyReleased(evt);
            }
        });

        lPrecioTotalBruto.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        lPrecioTotalBruto.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        lPrecioTotalBruto.setText("0");

        limporte_iva.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        limporte_iva.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        limporte_iva.setText("0");

        lObservaciones.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        lObservaciones.setText("Observaciones");

        ldto.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        ldto.setText("% dto S /");

        lTotal.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lTotal.setForeground(new java.awt.Color(0, 0, 204));
        lTotal.setText("Total");

        lprecio.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lprecio.setForeground(new java.awt.Color(0, 0, 204));
        lprecio.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        lprecio.setText("0");

        lSubTotal.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lSubTotal.setForeground(new java.awt.Color(0, 0, 204));
        lSubTotal.setText("SubTotal");

        tdto.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        tdto.setText("0.0");
        tdto.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tdtoKeyReleased(evt);
            }
        });

        limporte_dto.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        limporte_dto.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        limporte_dto.setText("0");

        lprecio_final.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lprecio_final.setForeground(new java.awt.Color(0, 0, 204));
        lprecio_final.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        lprecio_final.setText("0");

        tObservaciones.setColumns(20);
        tObservaciones.setRows(5);
        tObservaciones.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tObservacionesKeyReleased(evt);
            }
        });
        jScrollPane4.setViewportView(tObservaciones);

        lIva.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        lIva.setText("% IVA");

        ltotalbruto.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        ltotalbruto.setText("Total bruto");

        lfecha.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        lfecha.setText("Fecha");

        lnumero.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        lnumero.setText("Número");

        tfecha.setEditable(false);

        tnumero.setEditable(false);

        bAnadirNotas.setText("Añadir Notas");
        bAnadirNotas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bAnadirNotasActionPerformed(evt);
            }
        });

        bVerNotas.setText("Ver Notas");
        bVerNotas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bVerNotasActionPerformed(evt);
            }
        });

        cSeries.setModel(new javax.swing.DefaultComboBoxModel(new String[] { Constantes.SERIE_STD , Constantes.SERIE_SEC }));
        cSeries.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cSeriesActionPerformed(evt);
            }
        });

        lReferencia.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        lReferencia.setText("Referencia");

        tReferencia.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tReferenciaKeyReleased(evt);
            }
        });

        lestado.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        lestado.setText("Estado");

        cestado.setModel(new javax.swing.DefaultComboBoxModel(new String[] {}));

        lnombre.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        lnombre.setText("Nombre");

        ldomicilio.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        ldomicilio.setText("Domicilio");

        tLocalidadCliente.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tLocalidadClienteKeyReleased(evt);
            }
        });

        tProvinciaCliente.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tProvinciaClienteKeyReleased(evt);
            }
        });

        tNombreCliente.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tNombreClienteKeyReleased(evt);
            }
        });

        ltelefono.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        ltelefono.setText("Teléfono");

        tCodCliente.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tCodClienteKeyReleased(evt);
            }
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tCodClienteKeyPressed(evt);
            }
        });

        binsertarCliente.setText("...");
        binsertarCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                binsertarClienteActionPerformed(evt);
            }
        });

        ldni.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        ldni.setText("CIF/DNI");

        tDireccionCliente.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tDireccionClienteKeyReleased(evt);
            }
        });

        bImprimir.setToolTipText("Imprimir");
        bImprimir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bImprimirActionPerformed(evt);
            }
        });

        bCrearPdf.setToolTipText("Crear PDF");
        bCrearPdf.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bCrearPdfActionPerformed(evt);
            }
        });

        bMandarMail.setToolTipText("Mandar Mail");
        bMandarMail.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bMandarMailActionPerformed(evt);
            }
        });

        lconvertido.setFont(new java.awt.Font("Lucida Sans Unicode", 1, 14)); // NOI18N
        lconvertido.setForeground(new java.awt.Color(0, 0, 153));

        tPaisCliente.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tPaisClienteKeyReleased(evt);
            }
        });

        tTelefonoCliente.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tTelefonoClienteKeyReleased(evt);
            }
        });

        lPais.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        lPais.setText("Pais");

        lLocalidad.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        lLocalidad.setText("Localidad");

        tProvincia.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        tProvincia.setText("Provincia");

        lCliente.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        lCliente.setText("Proveedor");

        lCpCliente.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        lCpCliente.setText("CP");

        tCpCliente.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tCpClienteKeyReleased(evt);
            }
        });

        lEmailCliente.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        lEmailCliente.setText("Email");

        tEmailCliente.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tEmailClienteKeyReleased(evt);
            }
        });

        bGuardarCliente.setText("Guardar Proveedor");
        bGuardarCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bGuardarClienteActionPerformed(evt);
            }
        });

        lAlmacen.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        lAlmacen.setText("Alm.");

        cAlmacen.setModel(new javax.swing.DefaultComboBoxModel(new String[] {}));

        bVerNotasCliente.setToolTipText("Ver notas");
        bVerNotasCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bVerNotasClienteActionPerformed(evt);
            }
        });

        ttitulo2.setBackground(new java.awt.Color(255, 153, 153));
        ttitulo2.setFont(new java.awt.Font("Lucida Sans Unicode", 1, 14)); // NOI18N
        ttitulo2.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        ttitulo2.setText("Cantidad            Artículo(datos externos)                                                      Medidas               Precio        Importe");
        ttitulo2.setOpaque(true);

        jScrollPane1.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);

        panel.setBackground(new java.awt.Color(255, 255, 255));

        org.jdesktop.layout.GroupLayout panelLayout = new org.jdesktop.layout.GroupLayout(panel);
        panel.setLayout(panelLayout);
        panelLayout.setHorizontalGroup(
            panelLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(0, 927, Short.MAX_VALUE)
        );
        panelLayout.setVerticalGroup(
            panelLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(0, 308, Short.MAX_VALUE)
        );

        jScrollPane1.setViewportView(panel);
        panel.setLayout(new GridLayout(0,1));

        org.jdesktop.layout.GroupLayout jPanel2Layout = new org.jdesktop.layout.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jScrollPane1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 941, Short.MAX_VALUE)
            .add(jPanel2Layout.createSequentialGroup()
                .add(ttitulo2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 922, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(19, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel2Layout.createSequentialGroup()
                .add(ttitulo2)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jScrollPane1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 284, Short.MAX_VALUE))
        );

        jScrollPane1.setLayout(new ScrollPaneLayout());

        jScrollPane1.setPreferredSize(new Dimension (100,100));
        jScrollPane1.getAccessibleContext().setAccessibleParent(jScrollPane1);

        jTabbedPane1.addTab("Lineas", jPanel2);

        modeloplazosadelantados.addColumn("Plazo");
        modeloplazosadelantados.addColumn("%");
        modeloplazosadelantados.addColumn("Importe");
        modeloplazosadelantados.addColumn("T.Recibo");
        modeloplazosadelantados.addColumn("Cobrado");

        tplazosadelantados.getColumnModel().getColumn(0).setPreferredWidth(50);
        tplazosadelantados.getColumnModel().getColumn(1).setPreferredWidth(50);
        tplazosadelantados.getColumnModel().getColumn(2).setPreferredWidth(80);
        tplazosadelantados.getColumnModel().getColumn(3).setPreferredWidth(180);
        tplazosadelantados.getColumnModel().getColumn(4).setPreferredWidth(80);
        tplazosadelantados.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        tplazosadelantados.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tplazosadelantadosMouseClicked(evt);
            }
        });
        tplazosadelantados.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tplazosadelantadosKeyPressed(evt);
            }
        });
        jScrollPane2.setViewportView(tplazosadelantados);

        beliminarplazo.setToolTipText("Eliminar");
        beliminarplazo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                beliminarplazoActionPerformed(evt);
            }
        });

        bmodificarplazo.setToolTipText("Modificar");
        bmodificarplazo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bmodificarplazoActionPerformed(evt);
            }
        });

        bcrearplazo.setToolTipText("Crear");
        bcrearplazo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bcrearplazoActionPerformed(evt);
            }
        });

        lformapago1.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        lformapago1.setText("Plazos adelantados");

        lformapago2.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        lformapago2.setText("Plazos con Vencimiento");

        modelovencimientos.addColumn("Días");
        modelovencimientos.addColumn("%");
        modelovencimientos.addColumn("Importe");
        modelovencimientos.addColumn("Tipo Recibo");
        modelovencimientos.addColumn("Fecha");

        tvencimientos.getColumnModel().getColumn(0).setPreferredWidth(50);
        tvencimientos.getColumnModel().getColumn(1).setPreferredWidth(50);
        tvencimientos.getColumnModel().getColumn(2).setPreferredWidth(80);
        tvencimientos.getColumnModel().getColumn(3).setPreferredWidth(200);
        tvencimientos.getColumnModel().getColumn(4).setPreferredWidth(60);
        tvencimientos.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        tvencimientos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tvencimientosMouseClicked(evt);
            }
        });
        tvencimientos.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tvencimientosKeyPressed(evt);
            }
        });
        jScrollPane3.setViewportView(tvencimientos);

        bCrearVencimiento.setToolTipText("Crear");
        bCrearVencimiento.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bCrearVencimientoActionPerformed(evt);
            }
        });

        beliminarvencimiento.setToolTipText("Eliminar");
        beliminarvencimiento.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                beliminarvencimientoActionPerformed(evt);
            }
        });

        bmodificarvencimiento.setToolTipText("Modificar");
        bmodificarvencimiento.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bmodificarvencimientoActionPerformed(evt);
            }
        });

        lformapago.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        lformapago.setText("Forma de pago");

        cformapago.setModel(new javax.swing.DefaultComboBoxModel(new String[] {}));
        //Creamos la lista de formas de pago
        cformapago.addItem("-- Vacío --");
        List lfp = BaseDatos.getListaFormaPago();
        FormaPago fpaux;
        for (Iterator it = lfp.iterator(); it.hasNext();) {
            fpaux = (FormaPago) it.next();
            cformapago.addItem(fpaux.getCodigo());
        }
        cformapago.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cformapagoActionPerformed(evt);
            }
        });

        tformapago.setEnabled(false);

        org.jdesktop.layout.GroupLayout jPanel3Layout = new org.jdesktop.layout.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jPanel3Layout.createSequentialGroup()
                        .add(lformapago)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(cformapago, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 161, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(tformapago, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 180, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                    .add(jPanel3Layout.createSequentialGroup()
                        .add(jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(lformapago1)
                            .add(jPanel3Layout.createSequentialGroup()
                                .add(bcrearplazo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 25, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                .add(bmodificarplazo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 25, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                .add(beliminarplazo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 25, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                            .add(jScrollPane2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 420, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(jPanel3Layout.createSequentialGroup()
                                .add(bCrearVencimiento, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 25, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                .add(bmodificarvencimiento, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 25, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                .add(beliminarvencimiento, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 25, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                            .add(jScrollPane3, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(lformapago2))))
                .addContainerGap(53, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(lformapago)
                    .add(tformapago, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(cformapago, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .add(12, 12, 12)
                .add(jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                    .add(jPanel3Layout.createSequentialGroup()
                        .add(lformapago2)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jScrollPane3, 0, 0, Short.MAX_VALUE))
                    .add(jPanel3Layout.createSequentialGroup()
                        .add(lformapago1)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jScrollPane2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 130, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                        .add(bcrearplazo, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 25, Short.MAX_VALUE)
                        .add(bmodificarplazo, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .add(beliminarplazo, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .add(jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                        .add(bmodificarvencimiento, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 24, Short.MAX_VALUE)
                        .add(beliminarvencimiento, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .add(bCrearVencimiento, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap(89, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Formas de pago", jPanel3);

        bHayNotas.setToolTipText("Hay notas");
        bHayNotas.setVisible(false);

        bInsertarArticuloAntes.setText("AA");
        bInsertarArticuloAntes.setToolTipText("Insertar artículo antes");
        bInsertarArticuloAntes.setMargin(new java.awt.Insets(2, 5, 2, 5));
        bInsertarArticuloAntes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bInsertarArticuloAntesActionPerformed(evt);
            }
        });

        bInsertarArticuloDespues.setText("AD");
        bInsertarArticuloDespues.setToolTipText("Insertar artículo despues");
        bInsertarArticuloDespues.setMargin(new java.awt.Insets(2, 5, 2, 5));
        bInsertarArticuloDespues.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bInsertarArticuloDespuesActionPerformed(evt);
            }
        });

        bInsertarArticuloPrincipio.setText("AP");
        bInsertarArticuloPrincipio.setToolTipText("Insertar artículo al principio");
        bInsertarArticuloPrincipio.setMargin(new java.awt.Insets(2, 5, 2, 5));
        bInsertarArticuloPrincipio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bInsertarArticuloPrincipioActionPerformed(evt);
            }
        });

        bInsertarArticuloFinal.setText("AF");
        bInsertarArticuloFinal.setToolTipText("Insertar artículo al final");
        bInsertarArticuloFinal.setMargin(new java.awt.Insets(2, 5, 2, 5));
        bInsertarArticuloFinal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bInsertarArticuloFinalActionPerformed(evt);
            }
        });

        bInsertarNotaAntes.setText("NA");
        bInsertarNotaAntes.setToolTipText("Insertar nota antes");
        bInsertarNotaAntes.setMargin(new java.awt.Insets(2, 5, 2, 5));
        bInsertarNotaAntes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bInsertarNotaAntesActionPerformed(evt);
            }
        });

        bInsertarNotaDespues.setText("ND");
        bInsertarNotaDespues.setToolTipText("Insertar nota despues");
        bInsertarNotaDespues.setMargin(new java.awt.Insets(2, 5, 2, 5));
        bInsertarNotaDespues.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bInsertarNotaDespuesActionPerformed(evt);
            }
        });

        bInsertarNotaPrincipio.setText("NP");
        bInsertarNotaPrincipio.setToolTipText("Insertar nota principio");
        bInsertarNotaPrincipio.setMargin(new java.awt.Insets(2, 5, 2, 5));
        bInsertarNotaPrincipio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bInsertarNotaPrincipioActionPerformed(evt);
            }
        });

        bInsertarNotaFinal.setText("NF");
        bInsertarNotaFinal.setToolTipText("Insertar nota final");
        bInsertarNotaFinal.setMargin(new java.awt.Insets(2, 5, 2, 5));
        bInsertarNotaFinal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bInsertarNotaFinalActionPerformed(evt);
            }
        });

        bDatosConversion.setText("DC");
        bDatosConversion.setToolTipText("Convertir");
        bDatosConversion.setMargin(new java.awt.Insets(2, 5, 2, 5));
        bDatosConversion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bDatosConversionActionPerformed(evt);
            }
        });

        bFlujoDatos.setText("FD");
        bFlujoDatos.setToolTipText("Flujo de datos");
        bFlujoDatos.setMargin(new java.awt.Insets(2, 5, 2, 5));
        bFlujoDatos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bFlujoDatosActionPerformed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout jPanel1Layout = new org.jdesktop.layout.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jScrollPane4, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 790, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(jPanel1Layout.createSequentialGroup()
                        .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(lconvertido, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .add(jPanel1Layout.createSequentialGroup()
                                .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                                    .add(lReferencia)
                                    .add(jPanel1Layout.createSequentialGroup()
                                        .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                                            .add(lfecha)
                                            .add(lnumero)
                                            .add(lestado))
                                        .add(16, 16, 16)
                                        .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                                            .add(jPanel1Layout.createSequentialGroup()
                                                .add(tfecha, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 71, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                                .add(cSeries, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 124, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                                            .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                                                .add(org.jdesktop.layout.GroupLayout.LEADING, jPanel1Layout.createSequentialGroup()
                                                    .add(cestado, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 140, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                                    .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                                    .add(lAlmacen)
                                                    .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                                    .add(cAlmacen, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 171, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                                                .add(org.jdesktop.layout.GroupLayout.LEADING, jPanel1Layout.createSequentialGroup()
                                                    .add(tnumero, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 119, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                                    .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                                    .add(bAnadirNotas)
                                                    .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                                    .add(bVerNotas)
                                                    .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                                    .add(bHayNotas, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 22, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                                                .add(tReferencia, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 326, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))))
                                .add(70, 70, 70)))
                        .add(18, 18, 18)
                        .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(lCliente)
                            .add(ldomicilio)
                            .add(lLocalidad)
                            .add(lnombre, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 52, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(lEmailCliente))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING, false)
                            .add(org.jdesktop.layout.GroupLayout.LEADING, tEmailCliente)
                            .add(org.jdesktop.layout.GroupLayout.LEADING, jPanel1Layout.createSequentialGroup()
                                .add(tLocalidadCliente, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 76, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                .add(tProvincia)
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                .add(tProvinciaCliente))
                            .add(org.jdesktop.layout.GroupLayout.LEADING, tDireccionCliente)
                            .add(org.jdesktop.layout.GroupLayout.LEADING, tNombreCliente)
                            .add(org.jdesktop.layout.GroupLayout.LEADING, jPanel1Layout.createSequentialGroup()
                                .add(tCodCliente, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 181, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                .add(binsertarCliente, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 19, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                .add(bVerNotasCliente, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 22, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                            .add(org.jdesktop.layout.GroupLayout.LEADING, bGuardarCliente))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(ldni)
                            .add(lCpCliente)
                            .add(lPais)
                            .add(ltelefono))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                            .add(tCpCliente)
                            .add(tTelefonoCliente)
                            .add(tDniCliente, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 126, Short.MAX_VALUE)
                            .add(tPaisCliente)))
                    .add(lObservaciones)
                    .add(jPanel1Layout.createSequentialGroup()
                        .add(bImprimir, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 29, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(bCrearPdf, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 29, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(bMandarMail, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 29, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(bInsertarArticuloAntes, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 29, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(bInsertarArticuloDespues, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 29, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(bInsertarArticuloPrincipio, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 29, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(bInsertarArticuloFinal, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 29, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(bInsertarNotaAntes, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 29, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(bInsertarNotaDespues, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 29, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(bInsertarNotaPrincipio, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 29, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(bInsertarNotaFinal, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 29, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(bDatosConversion, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 29, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(bFlujoDatos, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 29, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                    .add(jTabbedPane1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 946, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(jPanel1Layout.createSequentialGroup()
                        .add(ltotalbruto)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(lPrecioTotalBruto, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 60, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(tdto, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 37, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(ldto)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(limporte_dto, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 61, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(lSubTotal)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(lprecio, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 55, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(tIva, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 60, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(lIva)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(limporte_iva, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 46, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(lTotal)
                        .add(6, 6, 6)
                        .add(lprecio_final, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 62, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                        .add(bMandarMail, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 23, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(bCrearPdf, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 23, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(bImprimir, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 23, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                    .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                        .add(bInsertarArticuloPrincipio, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 23, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(bInsertarArticuloDespues, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 23, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(bInsertarArticuloAntes, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 23, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                    .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                        .add(bInsertarNotaDespues, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 23, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(bInsertarNotaAntes, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 23, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(bInsertarArticuloFinal, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 23, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                    .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                        .add(bInsertarNotaFinal, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 23, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(bInsertarNotaPrincipio, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 23, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(bDatosConversion, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 23, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(bFlujoDatos, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 23, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jPanel1Layout.createSequentialGroup()
                        .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                            .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                                .add(tCodCliente, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                .add(binsertarCliente)
                                .add(lCliente))
                            .add(bVerNotasCliente, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 23, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(tNombreCliente, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(lnombre))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(tDireccionCliente, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(ldomicilio))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(tLocalidadCliente, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(tProvincia)
                            .add(tProvinciaCliente, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(lLocalidad))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(tEmailCliente, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(lEmailCliente))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(bGuardarCliente))
                    .add(jPanel1Layout.createSequentialGroup()
                        .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                            .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                                .add(lfecha)
                                .add(tfecha, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                            .add(cSeries, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                                .add(tnumero, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                .add(bAnadirNotas)
                                .add(bVerNotas)
                                .add(lnumero))
                            .add(bHayNotas, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(cestado, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(lAlmacen)
                            .add(lestado)
                            .add(cAlmacen, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(lReferencia)
                            .add(tReferencia, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(lconvertido, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 16, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                    .add(jPanel1Layout.createSequentialGroup()
                        .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(ldni)
                            .add(tDniCliente, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(ltelefono)
                            .add(tTelefonoCliente, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(lCpCliente)
                            .add(tCpCliente, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(lPais)
                            .add(tPaisCliente, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 19, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))))
                .add(11, 11, 11)
                .add(jTabbedPane1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 341, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(ltotalbruto)
                    .add(lPrecioTotalBruto)
                    .add(tdto, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(ldto)
                    .add(limporte_dto)
                    .add(lSubTotal)
                    .add(lprecio)
                    .add(tIva, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(lIva)
                    .add(limporte_iva)
                    .add(lTotal)
                    .add(lprecio_final))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(lObservaciones)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jScrollPane4, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 47, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        //if(this.p.getClase_documento().getDescripcion().equals("Presupuesto"))
        if (cd.getDescripcion().equals(Constantes.PEDIDOC)){

            List lestadod = BaseDatos.getListaEstadoDocumento("PC");
            EstadoDocumento ed;
            for (Iterator it = lestadod.iterator(); it.hasNext();) {
                ed = (EstadoDocumento) it.next();
                cestado.addItem(ed.getDescripcion());
            }

        }else if(cd.getDescripcion().equals(Constantes.ALBARANC)){

            List lestadod = BaseDatos.getListaEstadoDocumento("AL");
            EstadoDocumento ed;
            for (Iterator it = lestadod.iterator(); it.hasNext();) {
                ed = (EstadoDocumento) it.next();
                cestado.addItem(ed.getDescripcion());
            }

        }else if (cd.getDescripcion().equals(Constantes.FACTURAC)){

            List lestadod = BaseDatos.getListaEstadoDocumento("FC");
            EstadoDocumento ed;
            for (Iterator it = lestadod.iterator(); it.hasNext();) {
                ed = (EstadoDocumento) it.next();
                cestado.addItem(ed.getDescripcion());
            }

        }
        List la = BaseDatos.getListaAlmacenes();
        Almacen am;
        for (Iterator it = la.iterator(); it.hasNext();) {
            am = (Almacen) it.next();
            cAlmacen.addItem(am.getNombre());
        }

        jScrollPane14.setViewportView(jPanel1);

        baceptar.setText("Aceptar");
        baceptar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                baceptarActionPerformed(evt);
            }
        });

        bguardar.setText("Guardar");
        bguardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bguardarActionPerformed(evt);
            }
        });

        bmodificar.setText("Modificar");
        bmodificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bmodificarActionPerformed(evt);
            }
        });

        bcancelar.setText("Cancelar");
        bcancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bcancelarActionPerformed(evt);
            }
        });

        jMenuOpciones69.setText("Opciones");

        jMenuAlbaran.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F8, 0));
        jMenuAlbaran.setText("Convertir");
        jMenuAlbaran.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuAlbaranActionPerformed(evt);
            }
        });
        jMenuOpciones69.add(jMenuAlbaran);

        jMenuPDF.setText("Crear PDF");
        jMenuPDF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuPDFActionPerformed(evt);
            }
        });
        jMenuOpciones69.add(jMenuPDF);

        jMenuPagado.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F9, 0));
        jMenuPagado.setText("Establecer Pagado");
        jMenuPagado.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuPagadoActionPerformed(evt);
            }
        });
        jMenuOpciones69.add(jMenuPagado);

        jMenuImpagado.setText("Establecer como impagado");
        jMenuImpagado.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuImpagadoActionPerformed(evt);
            }
        });
        jMenuOpciones69.add(jMenuImpagado);

        jMenuImprimirRecibos.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F7, 0));
        jMenuImprimirRecibos.setText("Imprimir recibos");
        jMenuImprimirRecibos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuImprimirRecibosActionPerformed(evt);
            }
        });
        jMenuOpciones69.add(jMenuImprimirRecibos);
        jMenuOpciones69.add(jSeparator3);
        jMenuOpciones69.add(jSeparator1);

        jMenuItemNotaPrincipio.setText("Añadir nota informativa al principio");
        jMenuItemNotaPrincipio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItemNotaPrincipioActionPerformed(evt);
            }
        });
        jMenuOpciones69.add(jMenuItemNotaPrincipio);

        jMenuItemNotaFinal.setText("Añadir nota informativa al final");
        jMenuItemNotaFinal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItemNotaFinalActionPerformed(evt);
            }
        });
        jMenuOpciones69.add(jMenuItemNotaFinal);

        jMenuItemNotaAntes.setText("Añadir nota informativa antes de");
        jMenuItemNotaAntes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItemNotaAntesActionPerformed(evt);
            }
        });
        jMenuOpciones69.add(jMenuItemNotaAntes);

        jMenuItemNotaDespues.setText("Añadir nota informativa despues de");
        jMenuItemNotaDespues.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItemNotaDespuesActionPerformed(evt);
            }
        });
        jMenuOpciones69.add(jMenuItemNotaDespues);
        jMenuOpciones69.add(jSeparator2);

        jMenuItemLineaPrincipio.setText("Añadir línea al principio");
        jMenuItemLineaPrincipio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItemLineaPrincipioActionPerformed(evt);
            }
        });
        jMenuOpciones69.add(jMenuItemLineaPrincipio);

        jMenuItemLineaFinal.setText("Añadir línea al final");
        jMenuItemLineaFinal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItemLineaFinalActionPerformed(evt);
            }
        });
        jMenuOpciones69.add(jMenuItemLineaFinal);

        jMenuItemLineaAntes.setText("Añadir línea antes de");
        jMenuItemLineaAntes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItemLineaAntesActionPerformed(evt);
            }
        });
        jMenuOpciones69.add(jMenuItemLineaAntes);

        jMenuItemLineaDespues.setText("Añadir línea despues de");
        jMenuItemLineaDespues.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItemLineaDespuesActionPerformed(evt);
            }
        });
        jMenuOpciones69.add(jMenuItemLineaDespues);

        jMenuBar70.add(jMenuOpciones69);

        setJMenuBar(jMenuBar70);

        org.jdesktop.layout.GroupLayout layout = new org.jdesktop.layout.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(layout.createSequentialGroup()
                .addContainerGap()
                .add(baceptar)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(bguardar)
                .add(10, 10, 10)
                .add(bmodificar, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 103, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(bcancelar))
            .add(jScrollPane14)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, layout.createSequentialGroup()
                .add(jScrollPane14, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 668, Short.MAX_VALUE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(bcancelar)
                    .add(bmodificar)
                    .add(baceptar)
                    .add(bguardar))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

private void binsertarClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_binsertarClienteActionPerformed
    ListaDeClientes ldci = new ListaDeClientes(this, e);
    ldci.setDefaultCloseOperation(ListaDeClientes.DISPOSE_ON_CLOSE);
    ldci.setLocationRelativeTo(null);
    ldci.setVisible(true);
}//GEN-LAST:event_binsertarClienteActionPerformed

private void cformapagoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cformapagoActionPerformed
    String sfp = (String) cformapago.getSelectedItem();

    if (!creacion) {
        limpiarPlazosAdelantados();
        limpiarVencimientos();
        if (!sfp.equals(Constantes.VACIO)) {
            fp = BaseDatos.obtenerFormaPago(sfp);
            fp2 = new FormaPago2(fp);
            tformapago.setText(fp2.getDescripcioncliente());
            rellenarPlazosAdelantados();
            rellenarVencimientos();
        } else {
            bcrearplazo.setEnabled(false);
            beliminarplazo.setEnabled(false);
            bmodificarplazo.setEnabled(false);
            bCrearVencimiento.setEnabled(false);
            beliminarvencimiento.setEnabled(false);
            bmodificarvencimiento.setEnabled(false);

            fp = null;
            fp2 = null;
        }
    }

    if (!sfp.equals(Constantes.VACIO)) {
        bcrearplazo.setEnabled(true);
        beliminarplazo.setEnabled(true);
        bmodificarplazo.setEnabled(true);
        bCrearVencimiento.setEnabled(true);
        beliminarvencimiento.setEnabled(true);
        bmodificarvencimiento.setEnabled(true);
    }
}//GEN-LAST:event_cformapagoActionPerformed

private void bmodificarplazoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bmodificarplazoActionPerformed
    visualizarPlazoAdelantado();
}//GEN-LAST:event_bmodificarplazoActionPerformed

    private void visualizarPlazoAdelantado() {
        
        int indice = tplazosadelantados.getSelectedRow();
        if (indice >= 0) {
            String cobrado = (String) tplazosadelantados.getValueAt(indice, 4);
            String porcentaje = String.valueOf(tplazosadelantados.getValueAt(indice, 1));
            String tipoRecibo = (String) tplazosadelantados.getValueAt(indice, 3);
            String nombre = (String) tplazosadelantados.getValueAt(indice, 0);
            String simporte = String.valueOf(tplazosadelantados.getValueAt(indice, 2));
            double importe = Double.parseDouble(Util.convertirComaAPunto(simporte));

            String emitido;
            String recibo;
            String imputado;
            Long fecha;

            if (indice == 0) {
                emitido = fp2.getEmitido1();
                recibo = fp2.getRecibo1();
                imputado = fp2.getImputado1();
                fecha =  fp2.getFechaPlazo1();
            } else if (indice == 1) {
                emitido = fp2.getEmitido2();
                recibo = fp2.getRecibo2();
                imputado = fp2.getImputado2();
                fecha =  fp2.getFechaPlazo2();
            } else if (indice == 2) {
                emitido = fp2.getEmitido3();
                recibo = fp2.getRecibo3();
                imputado = fp2.getImputado3();
                fecha =  fp2.getFechaPlazo3();
            } else if (indice == 3) {
                emitido = fp2.getEmitido4();
                recibo = fp2.getRecibo4();
                imputado = fp2.getImputado4();
                fecha =  fp2.getFechaPlazo4();
            } else if (indice == 4) {
                emitido = fp2.getEmitido5();
                recibo = fp2.getRecibo5();
                imputado = fp2.getImputado5();
                fecha =  fp2.getFechaPlazo5();
            } else if (indice == 5) {
                emitido = fp2.getEmitido6();
                recibo = fp2.getRecibo6();
                imputado = fp2.getImputado6();
                fecha =  fp2.getFechaPlazo6();
            } else if (indice == 6) {
                emitido = fp2.getEmitido7();
                recibo = fp2.getRecibo7();
                imputado = fp2.getImputado7();
                fecha =  fp2.getFechaPlazo7();
            } else if (indice == 7) {
                emitido = fp2.getEmitido8();
                recibo = fp2.getRecibo8();
                imputado = fp2.getImputado8();
                fecha =  fp2.getFechaPlazo8();
            } else if (indice == 8) {
                emitido = fp2.getEmitido9();
                recibo = fp2.getRecibo9();
                imputado = fp2.getImputado9();
                fecha =  fp2.getFechaPlazo9();
            } else {
                emitido = fp2.getEmitido10();
                recibo = fp2.getRecibo10();
                imputado = fp2.getImputado10();
                fecha =  fp2.getFechaPlazo10();
            }

            if (fecha == null) {
                try {
                    fecha = getFechaLong();
                } catch (ParseException ex) {
                    Logger.getLogger(NuevoCompras.class.getName()).log(Level.SEVERE, null, ex);
                }
            }

             PlazoC pl = new PlazoC(indice, porcentaje, cobrado, tipoRecibo, nombre, importe_total, importe, fp2, imputado, recibo, emitido, this, fecha);
             pl.setDefaultCloseOperation(PlazoC.DISPOSE_ON_CLOSE);
             pl.setLocationRelativeTo(null);
             pl.setVisible(true);  
        }
    }

private void bcrearplazoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bcrearplazoActionPerformed

    double importeParaPlazo = Double.valueOf(Util.convertirComaAPunto(this.lprecio_final.getText()));
    PlazoC pl = new PlazoC(importeParaPlazo, fp2, this);
    pl.setDefaultCloseOperation(PlazoC.DISPOSE_ON_CLOSE);
    pl.setLocationRelativeTo(null);
    pl.setVisible(true);
}//GEN-LAST:event_bcrearplazoActionPerformed

private void bcancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bcancelarActionPerformed
    cerrarPresupuesto();
}//GEN-LAST:event_bcancelarActionPerformed

private void bmodificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bmodificarActionPerformed
    boolean enabled = true;
    if (bmodificar.getText().equals("Modificar")) {
        //Si el botón tiene el texto Modificar
        URL urlModificar = getClass().getResource("/iconos/buscar.gif");
        ImageIcon iconoModificar = new ImageIcon(urlModificar);
        bmodificar.setIcon(iconoModificar);
        bmodificar.setText("Visualizar");
        bmodificar.setToolTipText("Visualizar campos");
    } else {

        enabled = false;
        URL urlModificar = getClass().getResource("/iconos/editar.png");
        ImageIcon iconoModificar = new ImageIcon(urlModificar);
        bmodificar.setIcon(iconoModificar);
        //si el botón tiene el texto Visualizar
        bmodificar.setText("Modificar");
        bmodificar.setToolTipText("Modificar campos");
    }
    habilitarControles(enabled);
}//GEN-LAST:event_bmodificarActionPerformed

    private void habilitarControles(boolean enabled) {

        this.bcrearplazo.setEnabled(enabled);
        this.beliminarplazo.setEnabled(enabled);
        this.beliminarvencimiento.setEnabled(enabled);
        this.bmodificarplazo.setEnabled(enabled);
        this.bmodificarvencimiento.setEnabled(enabled);
        this.cformapago.setEnabled(enabled);
        this.tObservaciones.setEnabled(enabled);
        this.tplazosadelantados.setEnabled(enabled);
        this.tvencimientos.setEnabled(enabled);
        this.tdto.setEnabled(enabled);
        this.tIva.setEnabled(enabled);
        this.tReferencia.setEnabled(enabled);
        this.cestado.setEnabled(enabled);
        this.cSeries.setEnabled(enabled);
        this.tCodCliente.setEnabled(enabled);
        this.binsertarCliente.setEnabled(enabled);
        this.tNombreCliente.setEnabled(enabled);
        this.tDireccionCliente.setEnabled(enabled);
        this.tLocalidadCliente.setEnabled(enabled);
        this.tProvinciaCliente.setEnabled(enabled);
        this.tEmailCliente.setEnabled(enabled);
        this.tDniCliente.setEnabled(enabled);
        this.tTelefonoCliente.setEnabled(enabled);
        this.tCpCliente.setEnabled(enabled);
        this.tPaisCliente.setEnabled(enabled);
        this.binsertarCliente.setEnabled(enabled);
        this.bGuardarCliente.setEnabled(enabled);
        this.panel.setEnabled(enabled);
        this.bCrearVencimiento.setEnabled(enabled);
        this.beliminarvencimiento.setEnabled(enabled);
        this.bmodificarvencimiento.setEnabled(enabled);
    }

private void baceptarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_baceptarActionPerformed
    if (actualizarPresupuesto()) {
        if (BaseDatos.guardarDocumento(p, fp2, cod_fp2, fp2_aux, listaArticulos, crear, cd, null)) {
            String accion = p.getClase_documento().getDescripcion() + " Modificado";
            if (crear) {
                accion = "Nuevo " + p.getClase_documento().getDescripcion();
            }
            audi(p, accion, this.e, this.u);
            JOptionPane.showMessageDialog(null, "Documento guardado", "Guardado", JOptionPane.INFORMATION_MESSAGE);
            cerrarPresupuesto();
            if(this.ldc != null){
                ldc.realizarBusqueda();
            }
        } else {
            String mensaje = "No se puede ha podido modificar el elemento";
            if (crear) {
                mensaje = "No se puede ha podido insertar el elemento";
            }
            JOptionPane.showMessageDialog(null, mensaje, "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}//GEN-LAST:event_baceptarActionPerformed

    private void teclaF9() {
        boolean enabled = true;
        if (bmodificar.getText().equals("Modificar")) {
            //Si el botón tiene el texto Modificar
            URL urlModificar = getClass().getResource("/iconos/buscar.gif");
            ImageIcon iconoModificar = new ImageIcon(urlModificar);
            bmodificar.setIcon(iconoModificar);
            bmodificar.setText("Visualizar");
            bmodificar.setToolTipText("Visualizar campos");
            enabled = true;
        } else {

            enabled = false;
            URL urlModificar = getClass().getResource("/iconos/editar.png");
            ImageIcon iconoModificar = new ImageIcon(urlModificar);
            bmodificar.setIcon(iconoModificar);
            //si el botón tiene el texto Visualizar
            bmodificar.setText("Modificar");
            bmodificar.setToolTipText("Modificar campos");
        }

        habilitarControles(enabled);
    }

    private void cerrarPresupuesto() {
        removeAll();
        dispose();
    }

    private void audi(Presupuesto p, String accion, Empresa e, Usuario u) {

       /* Auditoria au = new Auditoria();
        Calendar calendario = Calendar.getInstance();
        int hora, minutos;
        hora = calendario.get(Calendar.HOUR_OF_DAY);
        minutos = calendario.get(Calendar.MINUTE);

        au.setfecha(p.getFecha());
        au.sethora(hora + ":" + minutos);
        au.setcodigo_objeto(p.getNumero());
        au.setaccion(accion);
        au.setusuario(u.getNombre());
        au.setempresa(e.getDesc_empresa());
        BaseDatos.insertarElemento(au);*/

    }

    private boolean actualizarPresupuesto() {

        boolean hayLineasErroneas = false;
        Iterator iter = this.listaArticulos.iterator();
        boolean seguir = true;
        NuevaLineaCompra nlip;
        
        
        
        while (iter.hasNext() && seguir) {
            nlip = (NuevaLineaCompra) iter.next();
            seguir = nlip.esLineaCorrecta();
        }

        if (!seguir) {
            hayLineasErroneas = true;
        }

        EstadoDocumento ed = BaseDatos.obtenerEstadoDocumentoPorDesc((String) cestado.getSelectedItem());
        String serie = (String) cSeries.getSelectedItem();
        String fecha = tfecha.getText();
        String dto1 = tdto.getText();
        String observaciones = tObservaciones.getText();
        if (observaciones != null) {
            if (observaciones.length() >= Constantes.TAM_OBSERVACIONES_PRESUPUESTO) {
                observaciones = observaciones.substring(0, Constantes.TAM_OBSERVACIONES_PRESUPUESTO);
            }
        }

        boolean mensajeError = false;
        boolean mensajeFechaEntrega = false;
        boolean mensajeComercial = false;
        boolean mensajeAlmacen = false;

        if (hayLineasErroneas) {
            mensajeError = true;
        }

        if (fp2 == null) {
            mensajeError = true;
        }

        if (cAlmacen.getItemCount() <= 0) {
            mensajeError = true;
            mensajeAlmacen = true;
        }

        if (mensajeError) {
            String mensajeErr = "";
            if (mensajeComercial && mensajeFechaEntrega) {
                mensajeErr = "Debe seleccionar la fecha de entrega, la forma de pago y el comercial.";
            } else if (mensajeComercial) {
                mensajeErr = "Debe seleccionar la forma de pago y el comercial.";
            } else if (mensajeFechaEntrega) {
                mensajeErr = "Debe seleccionar la fecha de entrega y la forma de pago.";
            } else {
                mensajeErr = "Debe seleccionar la forma de pago.";
            }

            if (mensajeAlmacen) {
                mensajeErr += " No hay seleccionado ningún almacén.";
            }

            if (hayLineasErroneas) {
                mensajeErr += " Hay Líneas Erroneas en el documento.";
            }

            JOptionPane.showMessageDialog(null, mensajeErr, "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            SimpleDateFormat formatoFecha = new SimpleDateFormat("dd/MM/yyyy");
            p.setClase_documento(cd);
            try {
                p.setFecha(formatoFecha.parse(fecha).getTime());
            } catch (ParseException ex) {
                Logger.getLogger(NuevoCompras.class.getName()).log(Level.SEVERE, null, ex);
            }
            p.setEstado(ed);
            p.setSerie(serie);
            p.setDto(Double.valueOf(Util.convertirComaAPunto(dto1)));
            p.setImporte_total(precio_final);
            p.setEmpresa(e);
            p.setConvertido(false);
            p.setIva(iva);
            p.setReferencia(tReferencia.getText());
            p.setCifCliente(tDniCliente.getText());
            p.setCodigoCliente(tCodCliente.getText());
            p.setDomicilioCliente(tDireccionCliente.getText());
            p.setLocalidadCliente(tLocalidadCliente.getText());
            p.setNombreCliente(tNombreCliente.getText());
            p.setPaisCliente(tPaisCliente.getText());
            p.setProvinciaCliente(tProvinciaCliente.getText());
            p.setTelefonoCliente(tTelefonoCliente.getText());
            p.setCpCliente(tCpCliente.getText());
            p.setPagado(pagado);
            p.setImpagado(impagado);
            p.setComercial(comercial);
            p.setObservaciones(observaciones);
            p.setEmailCliente(tEmailCliente.getText());
            p.setAlmacen(BaseDatos.obtenerAlmacen((String) cAlmacen.getSelectedItem()));
        }

        return !mensajeError;
    }

private void beliminarplazoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_beliminarplazoActionPerformed
    borrarPlazoAdelantado();
}//GEN-LAST:event_beliminarplazoActionPerformed

    private void borrarPlazoAdelantado() {
        int plazo = tplazosadelantados.getSelectedRow() + 1;
        Double porcentajeNegativo = null;
        if (plazo > 0) {

            if (plazo == 1) {

                porcentajeNegativo = fp2.getPorcentajepago1() * -1;

                //REORGANIZACION
                fp2.setNombreplazo1(fp2.getNombreplazo2());
                fp2.setPorcentajepago1(fp2.getPorcentajepago2());
                fp2.setIid_tr_p1(fp2.getIid_tr_p2());
                fp2.setCobrado1(fp2.getCobrado2());
                fp2.setImportep1(fp2.getImportep2());
                fp2.setFechap1(fp2.getFechap2());
                fp2.setEmitido1(fp2.getEmitido2());
                fp2.setRecibo1(fp2.getRecibo2());

                fp2.setNombreplazo2(fp2.getNombreplazo3());
                fp2.setPorcentajepago2(fp2.getPorcentajepago3());
                fp2.setIid_tr_p2(fp2.getIid_tr_p3());
                fp2.setCobrado2(fp2.getCobrado3());
                fp2.setImportep2(fp2.getImportep3());
                fp2.setFechap2(fp2.getFechap3());
                fp2.setEmitido2(fp2.getEmitido3());
                fp2.setRecibo2(fp2.getRecibo3());

                fp2.setNombreplazo3(fp2.getNombreplazo3());
                fp2.setPorcentajepago3(fp2.getPorcentajepago3());
                fp2.setIid_tr_p3(fp2.getIid_tr_p3());
                fp2.setCobrado3(fp2.getCobrado3());
                fp2.setImportep3(fp2.getImportep3());
                fp2.setFechap3(fp2.getFechap3());
                fp2.setEmitido3(fp2.getEmitido3());
                fp2.setRecibo3(fp2.getRecibo3());

                fp2.setNombreplazo4(fp2.getNombreplazo5());
                fp2.setPorcentajepago4(fp2.getPorcentajepago5());
                fp2.setIid_tr_p4(fp2.getIid_tr_p5());
                fp2.setCobrado4(fp2.getCobrado5());
                fp2.setImportep4(fp2.getImportep5());
                fp2.setFechap4(fp2.getFechap5());
                fp2.setEmitido4(fp2.getEmitido5());
                fp2.setRecibo4(fp2.getRecibo5());

                fp2.setNombreplazo5(fp2.getNombreplazo6());
                fp2.setPorcentajepago5(fp2.getPorcentajepago6());
                fp2.setIid_tr_p5(fp2.getIid_tr_p6());
                fp2.setCobrado5(fp2.getCobrado6());
                fp2.setImportep5(fp2.getImportep6());
                fp2.setFechap5(fp2.getFechap6());
                fp2.setEmitido5(fp2.getEmitido6());
                fp2.setRecibo5(fp2.getRecibo6());

                fp2.setNombreplazo6(fp2.getNombreplazo7());
                fp2.setPorcentajepago6(fp2.getPorcentajepago7());
                fp2.setIid_tr_p6(fp2.getIid_tr_p7());
                fp2.setCobrado6(fp2.getCobrado7());
                fp2.setImportep6(fp2.getImportep7());
                fp2.setFechap6(fp2.getFechap7());
                fp2.setEmitido6(fp2.getEmitido7());
                fp2.setRecibo6(fp2.getRecibo7());

                fp2.setNombreplazo7(fp2.getNombreplazo8());
                fp2.setPorcentajepago7(fp2.getPorcentajepago8());
                fp2.setIid_tr_p7(fp2.getIid_tr_p8());
                fp2.setCobrado7(fp2.getCobrado8());
                fp2.setImportep7(fp2.getImportep8());
                fp2.setFechap7(fp2.getFechap8());
                fp2.setEmitido7(fp2.getEmitido8());
                fp2.setRecibo7(fp2.getRecibo8());

                fp2.setNombreplazo8(fp2.getNombreplazo9());
                fp2.setPorcentajepago8(fp2.getPorcentajepago9());
                fp2.setIid_tr_p8(fp2.getIid_tr_p9());
                fp2.setCobrado8(fp2.getCobrado9());
                fp2.setImportep8(fp2.getImportep9());
                fp2.setFechap8(fp2.getFechap9());
                fp2.setEmitido8(fp2.getEmitido9());
                fp2.setRecibo8(fp2.getRecibo9());

            } else if (plazo == 2) {

                porcentajeNegativo = fp2.getPorcentajepago2() * -1;

                //REORGANIZACION
                fp2.setNombreplazo2(fp2.getNombreplazo3());
                fp2.setPorcentajepago2(fp2.getPorcentajepago3());
                fp2.setIid_tr_p2(fp2.getIid_tr_p3());
                fp2.setCobrado2(fp2.getCobrado3());
                fp2.setImportep2(fp2.getImportep3());
                fp2.setFechap2(fp2.getFechap3());
                fp2.setEmitido2(fp2.getEmitido3());
                fp2.setRecibo2(fp2.getRecibo3());

                fp2.setNombreplazo3(fp2.getNombreplazo3());
                fp2.setPorcentajepago3(fp2.getPorcentajepago3());
                fp2.setIid_tr_p3(fp2.getIid_tr_p3());
                fp2.setCobrado3(fp2.getCobrado3());
                fp2.setImportep3(fp2.getImportep3());
                fp2.setFechap3(fp2.getFechap3());
                fp2.setEmitido3(fp2.getEmitido3());
                fp2.setRecibo3(fp2.getRecibo3());

                fp2.setNombreplazo4(fp2.getNombreplazo5());
                fp2.setPorcentajepago4(fp2.getPorcentajepago5());
                fp2.setIid_tr_p4(fp2.getIid_tr_p5());
                fp2.setCobrado4(fp2.getCobrado5());
                fp2.setImportep4(fp2.getImportep5());
                fp2.setFechap4(fp2.getFechap5());
                fp2.setEmitido4(fp2.getEmitido5());
                fp2.setRecibo4(fp2.getRecibo5());

                fp2.setNombreplazo5(fp2.getNombreplazo6());
                fp2.setPorcentajepago5(fp2.getPorcentajepago6());
                fp2.setIid_tr_p5(fp2.getIid_tr_p6());
                fp2.setCobrado5(fp2.getCobrado6());
                fp2.setImportep5(fp2.getImportep6());
                fp2.setFechap5(fp2.getFechap6());
                fp2.setEmitido5(fp2.getEmitido6());
                fp2.setRecibo5(fp2.getRecibo6());

                fp2.setNombreplazo6(fp2.getNombreplazo7());
                fp2.setPorcentajepago6(fp2.getPorcentajepago7());
                fp2.setIid_tr_p6(fp2.getIid_tr_p7());
                fp2.setCobrado6(fp2.getCobrado7());
                fp2.setImportep6(fp2.getImportep7());
                fp2.setFechap6(fp2.getFechap7());
                fp2.setEmitido6(fp2.getEmitido7());
                fp2.setRecibo6(fp2.getRecibo7());

                fp2.setNombreplazo7(fp2.getNombreplazo8());
                fp2.setPorcentajepago7(fp2.getPorcentajepago8());
                fp2.setIid_tr_p7(fp2.getIid_tr_p8());
                fp2.setCobrado7(fp2.getCobrado8());
                fp2.setImportep7(fp2.getImportep8());
                fp2.setFechap7(fp2.getFechap8());
                fp2.setEmitido7(fp2.getEmitido8());
                fp2.setRecibo7(fp2.getRecibo8());

                fp2.setNombreplazo8(fp2.getNombreplazo9());
                fp2.setPorcentajepago8(fp2.getPorcentajepago9());
                fp2.setIid_tr_p8(fp2.getIid_tr_p9());
                fp2.setCobrado8(fp2.getCobrado9());
                fp2.setImportep8(fp2.getImportep9());
                fp2.setFechap8(fp2.getFechap9());
                fp2.setEmitido8(fp2.getEmitido9());
                fp2.setRecibo8(fp2.getRecibo9());

            } else if (plazo == 3) {

                porcentajeNegativo = fp2.getPorcentajepago3() * -1;

                //REORGANIZACION
                fp2.setNombreplazo3(fp2.getNombreplazo4());
                fp2.setPorcentajepago3(fp2.getPorcentajepago4());
                fp2.setIid_tr_p3(fp2.getIid_tr_p4());
                fp2.setCobrado3(fp2.getCobrado4());
                fp2.setImportep3(fp2.getImportep4());
                fp2.setFechap3(fp2.getFechap4());
                fp2.setEmitido3(fp2.getEmitido4());
                fp2.setRecibo3(fp2.getRecibo4());

                fp2.setNombreplazo4(fp2.getNombreplazo5());
                fp2.setPorcentajepago4(fp2.getPorcentajepago5());
                fp2.setIid_tr_p4(fp2.getIid_tr_p5());
                fp2.setCobrado4(fp2.getCobrado5());
                fp2.setImportep4(fp2.getImportep5());
                fp2.setFechap4(fp2.getFechap5());
                fp2.setEmitido4(fp2.getEmitido5());
                fp2.setRecibo4(fp2.getRecibo5());

                fp2.setNombreplazo5(fp2.getNombreplazo6());
                fp2.setPorcentajepago5(fp2.getPorcentajepago6());
                fp2.setIid_tr_p5(fp2.getIid_tr_p6());
                fp2.setCobrado5(fp2.getCobrado6());
                fp2.setImportep5(fp2.getImportep6());
                fp2.setFechap5(fp2.getFechap6());
                fp2.setEmitido5(fp2.getEmitido6());
                fp2.setRecibo5(fp2.getRecibo6());

                fp2.setNombreplazo6(fp2.getNombreplazo7());
                fp2.setPorcentajepago6(fp2.getPorcentajepago7());
                fp2.setIid_tr_p6(fp2.getIid_tr_p7());
                fp2.setCobrado6(fp2.getCobrado7());
                fp2.setImportep6(fp2.getImportep7());
                fp2.setFechap6(fp2.getFechap7());
                fp2.setEmitido6(fp2.getEmitido7());
                fp2.setRecibo6(fp2.getRecibo7());

                fp2.setNombreplazo7(fp2.getNombreplazo8());
                fp2.setPorcentajepago7(fp2.getPorcentajepago8());
                fp2.setIid_tr_p7(fp2.getIid_tr_p8());
                fp2.setCobrado7(fp2.getCobrado8());
                fp2.setImportep7(fp2.getImportep8());
                fp2.setFechap7(fp2.getFechap8());
                fp2.setEmitido7(fp2.getEmitido8());
                fp2.setRecibo7(fp2.getRecibo8());

                fp2.setNombreplazo8(fp2.getNombreplazo9());
                fp2.setPorcentajepago8(fp2.getPorcentajepago9());
                fp2.setIid_tr_p8(fp2.getIid_tr_p9());
                fp2.setCobrado8(fp2.getCobrado9());
                fp2.setImportep8(fp2.getImportep9());
                fp2.setFechap8(fp2.getFechap9());
                fp2.setEmitido8(fp2.getEmitido9());
                fp2.setRecibo8(fp2.getRecibo9());

            } else if (plazo == 4) {

                porcentajeNegativo = fp2.getPorcentajepago4() * -1;

                //REORGANIZACION
                fp2.setNombreplazo4(fp2.getNombreplazo5());
                fp2.setPorcentajepago4(fp2.getPorcentajepago5());
                fp2.setIid_tr_p4(fp2.getIid_tr_p5());
                fp2.setCobrado4(fp2.getCobrado5());
                fp2.setImportep4(fp2.getImportep5());
                fp2.setFechap4(fp2.getFechap5());
                fp2.setEmitido4(fp2.getEmitido5());
                fp2.setRecibo4(fp2.getRecibo5());

                fp2.setNombreplazo5(fp2.getNombreplazo6());
                fp2.setPorcentajepago5(fp2.getPorcentajepago6());
                fp2.setIid_tr_p5(fp2.getIid_tr_p6());
                fp2.setCobrado5(fp2.getCobrado6());
                fp2.setImportep5(fp2.getImportep6());
                fp2.setFechap5(fp2.getFechap6());
                fp2.setEmitido5(fp2.getEmitido6());
                fp2.setRecibo5(fp2.getRecibo6());

                fp2.setNombreplazo6(fp2.getNombreplazo7());
                fp2.setPorcentajepago6(fp2.getPorcentajepago7());
                fp2.setIid_tr_p6(fp2.getIid_tr_p7());
                fp2.setCobrado6(fp2.getCobrado7());
                fp2.setImportep6(fp2.getImportep7());
                fp2.setFechap6(fp2.getFechap7());
                fp2.setEmitido6(fp2.getEmitido7());
                fp2.setRecibo6(fp2.getRecibo7());

                fp2.setNombreplazo7(fp2.getNombreplazo8());
                fp2.setPorcentajepago7(fp2.getPorcentajepago8());
                fp2.setIid_tr_p7(fp2.getIid_tr_p8());
                fp2.setCobrado7(fp2.getCobrado8());
                fp2.setImportep7(fp2.getImportep8());
                fp2.setFechap7(fp2.getFechap8());
                fp2.setEmitido7(fp2.getEmitido8());
                fp2.setRecibo7(fp2.getRecibo8());

                fp2.setNombreplazo8(fp2.getNombreplazo9());
                fp2.setPorcentajepago8(fp2.getPorcentajepago9());
                fp2.setIid_tr_p8(fp2.getIid_tr_p9());
                fp2.setCobrado8(fp2.getCobrado9());
                fp2.setImportep8(fp2.getImportep9());
                fp2.setFechap8(fp2.getFechap9());
                fp2.setEmitido8(fp2.getEmitido9());
                fp2.setRecibo8(fp2.getRecibo9());

            } else if (plazo == 5) {

                porcentajeNegativo = fp2.getPorcentajepago5() * -1;

                //REORGANIZACION
                fp2.setNombreplazo5(fp2.getNombreplazo6());
                fp2.setPorcentajepago5(fp2.getPorcentajepago6());
                fp2.setIid_tr_p5(fp2.getIid_tr_p6());
                fp2.setCobrado5(fp2.getCobrado6());
                fp2.setImportep5(fp2.getImportep6());
                fp2.setFechap5(fp2.getFechap6());
                fp2.setEmitido5(fp2.getEmitido6());
                fp2.setRecibo5(fp2.getRecibo6());

                fp2.setNombreplazo6(fp2.getNombreplazo7());
                fp2.setPorcentajepago6(fp2.getPorcentajepago7());
                fp2.setIid_tr_p6(fp2.getIid_tr_p7());
                fp2.setCobrado6(fp2.getCobrado7());
                fp2.setImportep6(fp2.getImportep7());
                fp2.setFechap6(fp2.getFechap7());
                fp2.setEmitido6(fp2.getEmitido7());
                fp2.setRecibo6(fp2.getRecibo7());

                fp2.setNombreplazo7(fp2.getNombreplazo8());
                fp2.setPorcentajepago7(fp2.getPorcentajepago8());
                fp2.setIid_tr_p7(fp2.getIid_tr_p8());
                fp2.setCobrado7(fp2.getCobrado8());
                fp2.setImportep7(fp2.getImportep8());
                fp2.setFechap7(fp2.getFechap8());
                fp2.setEmitido7(fp2.getEmitido8());
                fp2.setRecibo7(fp2.getRecibo8());

                fp2.setNombreplazo8(fp2.getNombreplazo9());
                fp2.setPorcentajepago8(fp2.getPorcentajepago9());
                fp2.setIid_tr_p8(fp2.getIid_tr_p9());
                fp2.setCobrado8(fp2.getCobrado9());
                fp2.setImportep8(fp2.getImportep9());
                fp2.setFechap8(fp2.getFechap9());
                fp2.setEmitido8(fp2.getEmitido9());
                fp2.setRecibo8(fp2.getRecibo9());

            } else if (plazo == 6) {

                porcentajeNegativo = fp2.getPorcentajepago6() * -1;

                //REORGANIZACION
                fp2.setNombreplazo6(fp2.getNombreplazo7());
                fp2.setPorcentajepago6(fp2.getPorcentajepago7());
                fp2.setIid_tr_p6(fp2.getIid_tr_p7());
                fp2.setCobrado6(fp2.getCobrado7());
                fp2.setImportep6(fp2.getImportep7());
                fp2.setFechap6(fp2.getFechap7());
                fp2.setEmitido6(fp2.getEmitido7());
                fp2.setRecibo6(fp2.getRecibo7());

                fp2.setNombreplazo7(fp2.getNombreplazo8());
                fp2.setPorcentajepago7(fp2.getPorcentajepago8());
                fp2.setIid_tr_p7(fp2.getIid_tr_p8());
                fp2.setCobrado7(fp2.getCobrado8());
                fp2.setImportep7(fp2.getImportep8());
                fp2.setFechap7(fp2.getFechap8());
                fp2.setEmitido7(fp2.getEmitido8());
                fp2.setRecibo7(fp2.getRecibo8());

                fp2.setNombreplazo8(fp2.getNombreplazo9());
                fp2.setPorcentajepago8(fp2.getPorcentajepago9());
                fp2.setIid_tr_p8(fp2.getIid_tr_p9());
                fp2.setCobrado8(fp2.getCobrado9());
                fp2.setImportep8(fp2.getImportep9());
                fp2.setFechap8(fp2.getFechap9());
                fp2.setEmitido8(fp2.getEmitido9());
                fp2.setRecibo8(fp2.getRecibo9());

            } else if (plazo == 7) {

                porcentajeNegativo = fp2.getPorcentajepago7() * -1;

                //REORGANIZACION
                fp2.setNombreplazo7(fp2.getNombreplazo8());
                fp2.setPorcentajepago7(fp2.getPorcentajepago8());
                fp2.setIid_tr_p7(fp2.getIid_tr_p8());
                fp2.setCobrado7(fp2.getCobrado8());
                fp2.setImportep7(fp2.getImportep8());
                fp2.setFechap7(fp2.getFechap8());
                fp2.setEmitido7(fp2.getEmitido8());
                fp2.setRecibo7(fp2.getRecibo8());

                fp2.setNombreplazo8(fp2.getNombreplazo9());
                fp2.setPorcentajepago8(fp2.getPorcentajepago9());
                fp2.setIid_tr_p8(fp2.getIid_tr_p9());
                fp2.setCobrado8(fp2.getCobrado9());
                fp2.setImportep8(fp2.getImportep9());
                fp2.setFechap8(fp2.getFechap9());
                fp2.setEmitido8(fp2.getEmitido9());
                fp2.setRecibo8(fp2.getRecibo9());

            } else if (plazo == 8) {

                porcentajeNegativo = fp2.getPorcentajepago8() * -1;

                //REORGANIZACION
                fp2.setNombreplazo8(fp2.getNombreplazo9());
                fp2.setPorcentajepago8(fp2.getPorcentajepago9());
                fp2.setIid_tr_p8(fp2.getIid_tr_p9());
                fp2.setCobrado8(fp2.getCobrado9());
                fp2.setImportep8(fp2.getImportep9());
                fp2.setFechap8(fp2.getFechap9());
                fp2.setEmitido8(fp2.getEmitido9());
                fp2.setRecibo8(fp2.getRecibo9());

            } else if (plazo == 9) {
                porcentajeNegativo = fp2.getPorcentajepago9() * -1;
                fp2.setNombreplazo9(null);
                fp2.setPorcentajepago9(null);
                fp2.setIid_tr_p9(null);
                fp2.setCobrado9(null);
                fp2.setImportep9(null);
                fp2.setFechap9(null);
                fp2.setEmitido9(null);
                fp2.setRecibo9(null);

            } else {
            }

            fp2.setNombreplazo9(null);
            fp2.setPorcentajepago9(null);
            fp2.setIid_tr_p9(null);
            fp2.setCobrado9(null);
            fp2.setImportep9(null);
            fp2.setFechap9(null);
            fp2.setEmitido9(null);
            fp2.setRecibo9(null);

            fp2.setNumplazosadelantados(fp2.getNumplazosadelantados() - 1);
            disminuirVencimientos(porcentajeNegativo);

            limpiarPlazosAdelantados();
            limpiarVencimientos();
            rellenarPlazosAdelantados();
            rellenarVencimientos();

            if (tplazosadelantados.getSelectedRowCount() == 0) {
                beliminarplazo.setEnabled(false);
            }
            if (tplazosadelantados.getSelectedRowCount() == 0) {
                bmodificarplazo.setEnabled(false);
            }
        }
    }

private void tdtoKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tdtoKeyReleased
    int tamaño = tdto.getText().length();
    if (tamaño > 0) {
        char c = tdto.getText().charAt(tamaño - 1);

        if (c == '.') {
            String contenidoAntiguo = tdto.getText().replace(".", ",");
            tdto.setText(contenidoAntiguo);
            c = ',';
        }

        if (!((c >= '0' && c <= '9') || c == ',')) {
            String str = tdto.getText().substring(0, tamaño - 1);
            tdto.setText(str);
        } else if (c == ',') {
            int indicePunto = tdto.getText().indexOf(',');
            if (indicePunto != (tamaño - 1)) {
                String str = tdto.getText().substring(0, tamaño - 1);
                tdto.setText(str);
            }
        }
    } else {
        tdto.setText("0");
    }
    try {
        calcularPrecio();
    } catch (Exception ex) {
        JOptionPane.showMessageDialog(null, "El descuento no es un Nº correcto", "Error", JOptionPane.ERROR_MESSAGE);
    }
}//GEN-LAST:event_tdtoKeyReleased

private void jMenuAlbaranActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuAlbaranActionPerformed
    //Hay que convertir el presupuesto a albaran
    convertirDocumento(Constantes.PEDIDOC);
}//GEN-LAST:event_jMenuAlbaranActionPerformed

private void bAnadirNotasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bAnadirNotasActionPerformed
    NuevaNotaDocumento nnd = new NuevaNotaDocumento(p, this);
    nnd.setDefaultCloseOperation(NuevaNotaDocumento.DISPOSE_ON_CLOSE);
    nnd.setLocationRelativeTo(null);
    nnd.setVisible(true);
}//GEN-LAST:event_bAnadirNotasActionPerformed

private void cSeriesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cSeriesActionPerformed
    String cifCliente = tDniCliente.getText();
    if (cifCliente != null && !cifCliente.equals("")) {
        calcularNuevoIva(cifCliente);
    }
}//GEN-LAST:event_cSeriesActionPerformed

private void jMenuPDFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuPDFActionPerformed

    HashMap parameters = new HashMap();
    FamiliaVenta fve;
    TipoControl tco;
    TipoMedida tme;
    double precio;
    
    parameters.put("e.cod_empresa", e.getCod_empresa());
    parameters.put("e.desc_empresa", e.getDesc_empresa());
    parameters.put("e.dire_empresa", e.getDire_empresa());
    parameters.put("e.pobla_empresa", e.getPobla_empresa());
    parameters.put("e.cp_empresa", e.getCp_empresa());
    parameters.put("tipoDocumento", cd.getDescripcion());

    parameters.put("c.codigo", this.tCodCliente.getText());
    parameters.put("c.dni", this.tDniCliente.getText());
    parameters.put("c.nombreComercial", this.tNombreCliente.getText());
    parameters.put("c.direccion", this.tDireccionCliente.getText());
    parameters.put("c.cp", this.tCpCliente.getText());
    parameters.put("c.poblacion", this.tLocalidadCliente.getText());
    parameters.put("c.provincia", this.tProvinciaCliente.getText());
    parameters.put("c.telefono", this.tTelefonoCliente.getText());

    parameters.put("logo", new ByteArrayInputStream(e.getImagen()));
    parameters.put("referencia", tReferencia.getText());
    parameters.put("numero", tnumero.getText());
    parameters.put("fecha", tfecha.getText());

    HashMap hashPrecio = new HashMap();
    hashPrecio.put("precio_bruto", lprecio.getText());
    hashPrecio.put("precio_final", lprecio_final.getText());
    hashPrecio.put("precio_iva", limporte_iva.getText());
    hashPrecio.put("iva", tIva.getText());

    parameters.put("hashPrecio", hashPrecio);
    parameters.put("precio_bruto", lprecio.getText());
    parameters.put("precio_final", lprecio_final.getText());
    parameters.put("precio_iva", limporte_iva.getText());

    List<LineaPresupuesto> listaProducto = new ArrayList<LineaPresupuesto>();
    NuevaLineaCompra nlip;
    Articulo arti;
    Iterator it = listaArticulos.iterator();
    LineaPresupuesto lip;
    while (it.hasNext()) {
        nlip = (NuevaLineaCompra) it.next();
        arti = nlip.getArticulo();
        if (arti != null) {
            lip = new LineaPresupuesto();
            lip.setArticulo_iid(arti);
            fve = BaseDatos.obtenerFamiliaVentaPorIid(nlip.getArticulo().getIid_fam_venta().getIid());
            tco = BaseDatos.obtenerTipoControlPorIid(fve.getIid_tipo_control().getIid());
            tme = BaseDatos.obtenerTipoMedidaByIid(tco.getIid_tipo_medida().getIid());
            lip.setNummedidas(tme.getNum_dimensiones());
            lip.setCodigo(nlip.getCodigo());
            lip.setPrecio(nlip.getPrecio());
            lip.setPresupuesto_iid(p);
            lip.setDescuento(nlip.getDescuento());
            lip.setCantidad(nlip.getCantidad());
            lip.setMedida1(nlip.getMedida1());
            lip.setMedida2(nlip.getMedida2());
            lip.setMedida3(nlip.getMedida3());
            lip.setMedida4(nlip.getMedida4());
            lip.setMedida5(nlip.getMedida5());
            lip.setMedidares(nlip.getMedidares());
            lip.setDescripcion(nlip.getDescripcion());
            lip.setCantidadStr(Util.convertirPuntoAComa(String.valueOf(nlip.getCantidad())));
            lip.setImporteStr(Util.convertirPuntoAComa(String.valueOf(nlip.getImporte())));
            precio = ((100 - lip.getDescuento()) * nlip.getPrecio()) / 100;
            lip.setPrecioStr(Util.convertirPuntoAComa(String.valueOf(matematico.Matematico.redondear2decimales(precio))));
            listaProducto.add(lip);
        } else if (!nlip.isLineaArticulo() && nlip.getDescripcion() != null && !nlip.getDescripcion().equals("")) {
            lip = new LineaPresupuesto();
            lip.setDescripcion(nlip.getDescripcion());
            listaProducto.add(lip);
        }
    }
    parameters.put("lineaPresupuesto", new JRBeanCollectionDataSource(listaProducto));

    List<Objeto2Elementos> lista = fp2.getPlazos();
    parameters.put("formaPago", new JRBeanCollectionDataSource(lista));
    parameters.put("formaPagoStr", fp2.getCodigo());

    Informe.imprimirPresupuesto(parameters);
}//GEN-LAST:event_jMenuPDFActionPerformed

private void bImprimirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bImprimirActionPerformed
    jMenuPDFActionPerformed(null);
}//GEN-LAST:event_bImprimirActionPerformed

private void bCrearPdfActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bCrearPdfActionPerformed
    if (fp2 == null) {
        JOptionPane.showMessageDialog(null, "Debe seleccionar la forma de pago", "Error", JOptionPane.ERROR_MESSAGE);
    } else {

        JFileChooser example = new JFileChooser() {
            @Override
            public void approveSelection() {
                File f = getSelectedFile();
                if (f.exists() && getDialogType() == SAVE_DIALOG) {
                    int result = JOptionPane.showConfirmDialog(this, "El archivo ya existe, ¿Desea sobreescribirlo?", "El archivo ya existe", JOptionPane.YES_NO_CANCEL_OPTION);
                    switch (result) {
                        case JOptionPane.YES_OPTION:
                            super.approveSelection();
                            return;
                        case JOptionPane.NO_OPTION:
                            return;
                        case JOptionPane.CANCEL_OPTION:
                            cancelSelection:
                            return;
                    }
                }
                super.approveSelection();
            }
        };
        example.setDialogTitle("Guardar");
        example.setMultiSelectionEnabled(false);
        example.setAcceptAllFileFilterUsed(false);
        example.setFileSelectionMode(JFileChooser.FILES_ONLY);
        PdfFilter pf = new PdfFilter();
        example.setFileFilter(pf);
        int sel = example.showSaveDialog(this);
        if (sel == JFileChooser.APPROVE_OPTION) {
            File selectedFile = example.getSelectedFile();
            HashMap parametros = crearHashMapParametros();
            String ruta = selectedFile.getAbsolutePath();
            if (!ruta.endsWith(".pdf")) {
                ruta += ".pdf";
            }
            Informe.guardarPresupuesto(parametros, ruta);
        }
    }

}//GEN-LAST:event_bCrearPdfActionPerformed

private void bMandarMailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bMandarMailActionPerformed

    if (tEmailCliente.getText() != null && !tEmailCliente.getText().equals("")) {
        int guardar = 1;
        guardar = JOptionPane.showConfirmDialog(null, "Para mandar el mail primero debe guardar el presupuesto ¿Desea guardarlo?", "¿Guardar Presupuesto?", JOptionPane.YES_NO_OPTION);
        //hacerCambios = -1 ==> se ha pulsado la "x" de cancelar;
        //hacerCambios =  0 ==> se ha pulsado el "sí"
        //hacerCambios =  1 ==> se ha pulsado el "no"
        if (guardar == 0) {
            if(actualizarPresupuesto()){
                boolean correcto = true;
                if (BaseDatos.guardarDocumento(p, fp2, cod_fp2, fp2_aux, listaArticulos, crear, cd, null)) {
                    String accion = "Presupuesto Modificado";
                    if (crear) {
                        accion = "Nuevo Presupuesto";
                    }
                    audi(p, accion, this.e, this.u);
                } else {
                    String mensaje = "No se puede ha podido modificar el elemento";
                    if (crear) {
                        mensaje = "No se puede ha podido insertar el elemento";
                    }
                    JOptionPane.showMessageDialog(null, mensaje, "Error", JOptionPane.ERROR_MESSAGE);
                    correcto = false;
                }

                if (correcto) {
                    crear = false;
                    HashMap parametros = crearHashMapParametros();
                    String rutaPresupuesto = Informe.crearPresupuestoEmail(parametros);
                    EnviarMail nnd = new EnviarMail("Presupuesto Toldos Víctor Manuel", this.tEmailCliente.getText(), rutaPresupuesto, p, u.getPie() ,e.getUrlWeb());
                    nnd.setDefaultCloseOperation(NuevaNotaDocumento.DISPOSE_ON_CLOSE);
                    nnd.setLocationRelativeTo(null);
                    nnd.setVisible(true);
                }
            }
        }
    } else {
        JOptionPane.showMessageDialog(null, "No hay seleccionado ningúna dirección de correo", "Error", JOptionPane.ERROR_MESSAGE);
    }
}//GEN-LAST:event_bMandarMailActionPerformed

private void jMenuPagadoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuPagadoActionPerformed

    if (pagado) {
        JOptionPane.showMessageDialog(null, "Este documento ya ha sido dado por pagado", "Error", JOptionPane.ERROR_MESSAGE);
    } else {
        int pagar = 1;
        pagar = JOptionPane.showConfirmDialog(null, "¿Está seguro de que desea dar por pagado el documento?", "¿Dar por pagado?", JOptionPane.YES_NO_OPTION);
        //hacerCambios = -1 ==> se ha pulsado la "x" de cancelar;
        //hacerCambios =  0 ==> se ha pulsado el "sí"
        //hacerCambios =  1 ==> se ha pulsado el "no"

        if (pagar == 0) {
            pagado = true;
            if (p.getClase_documento().getDescripcion().equals(Constantes.FACTURA)) {
                cestado.setSelectedItem("Pagado");
            }
        }
    }
}//GEN-LAST:event_jMenuPagadoActionPerformed

private void bguardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bguardarActionPerformed
    if (actualizarPresupuesto()) {

        if (BaseDatos.guardarDocumento(p, fp2, cod_fp2, fp2_aux, listaArticulos, crear, cd, null)) {
            //Insertar movimientos de almacen si estamos tratando con un albarán de compra
            //Primero eliminamos los posibles movimientos anteriores
            if (p.getClase_documento().getDescripcion().equals(Constantes.ALBARANC)) {
                BaseDatos.elimnarMovimientoAlmacenDocumento(p);

                //Obtener lineas del documento
                List<LineaPresupuesto> nlp = BaseDatos.getListaLineaPresupuesto(p.getIid());
                Iterator i = nlp.iterator();
                LineaPresupuesto mlp;
                MovimientoAlmacen ma = new MovimientoAlmacen();

                Date fecha = new Date(); // fecha y hora locales
                Caracteristica nCar = new Caracteristica();

                while (i.hasNext()) {
                    // Creamos movimientos de almacen
                    mlp = (LineaPresupuesto) i.next();
                    ma.setAlmacen(p.getAlmacen());
                    ma.setArticulo(mlp.getArticulo_iid());
                    ma.setCantidad(Float.parseFloat(mlp.getCantidad().toString()));
                    ma.setCantidad1(Float.parseFloat(mlp.getMedida1().toString()));
                    ma.setCantidad2(Float.parseFloat(mlp.getMedida2().toString()));
                    ma.setCantidad3(Float.parseFloat(mlp.getMedida3().toString()));
                    ma.setCantidad4(Float.parseFloat(mlp.getMedida4().toString()));
                    ma.setCantidad5(Float.parseFloat(mlp.getMedida5().toString()));
                    if(mlp.getCaracteristica()!=null){
                        nCar = BaseDatos.obtenerCaracteristicaPorIid(mlp.getCaracteristica().getIid());
                        ma.setCaracteristica(nCar);
                    }
                    

                    ma.setConcepto("Inventario por documento de compras");
                    ma.setEmpresa(e);

                    ma.setFecha(fecha.getTime());

                    ma.setModificable(false);

                    TipoMovimientoAlmacen tma = BaseDatos.obtenerTipoMovimientoAlmacen(Constantes.TIPO_MOVIMIENTO_ALMACEN_COMPRA);

                    ma.setTipoMovimiento(tma);
                    ma.setPresupuesto(p);


                    BaseDatos.insertarMovimientoExistencia(ma);
                }
            }

            tnumero.setText(p.getNumero());
            String accion = "Presupuesto Modificado";
            if (crear) {
                accion = "Nuevo Presupuesto";
            }
            audi(p, accion, this.e, this.u);
            JOptionPane.showMessageDialog(null, "Documento guardado", "Guardado", JOptionPane.INFORMATION_MESSAGE);
            crear = false;
        } else {
            String mensaje = "No se puede ha podido modificar el elemento";
            if (crear) {
                mensaje = "No se puede ha podido insertar el elemento";
            }
            JOptionPane.showMessageDialog(null, mensaje, "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}//GEN-LAST:event_bguardarActionPerformed

private void tplazosadelantadosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tplazosadelantadosMouseClicked
    if (tplazosadelantados.getSelectedRowCount() != 0) {
        beliminarplazo.setEnabled(true);
    }
    if (tplazosadelantados.getSelectedRowCount() != 0) {
        bmodificarplazo.setEnabled(true);
    }

    if (evt.getClickCount() == 2) {
        visualizarPlazoAdelantado();
    }
}//GEN-LAST:event_tplazosadelantadosMouseClicked

private void bmodificarvencimientoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bmodificarvencimientoActionPerformed
        visualizarVencimiento();
    }

    private void visualizarVencimiento() {
        int indice = tvencimientos.getSelectedRow();
        if (indice >= 0) {
            String porcentaje = (String) tvencimientos.getValueAt(indice, 1);
            String tipoRecibo = (String) tvencimientos.getValueAt(indice, 3);
            String simporte = (String) tvencimientos.getValueAt(indice, 2);
            String fechaStr = (String) tvencimientos.getValueAt(indice, 4);
            double importe = Double.parseDouble(Util.convertirComaAPunto(simporte));

            String recibo;
            String cobrado;
            String emitido;
            String imputado;

            if (indice == 0) {
                recibo = fp2.getReciboVencimiento1();
                cobrado = fp2.getCobradoVencimiento1();
                emitido = fp2.getEmitidoVencimiento1();
                imputado = fp2.getImputadoVencimiento1();
            } else if (indice == 1) {
                recibo = fp2.getReciboVencimiento2();
                cobrado = fp2.getCobradoVencimiento2();
                emitido = fp2.getEmitidoVencimiento2();
                imputado = fp2.getImputadoVencimiento2();
            } else if (indice == 2) {
                recibo = fp2.getReciboVencimiento3();
                cobrado = fp2.getCobradoVencimiento3();
                emitido = fp2.getEmitidoVencimiento3();
                imputado = fp2.getImputadoVencimiento3();
            } else if (indice == 3) {
                recibo = fp2.getReciboVencimiento4();
                cobrado = fp2.getCobradoVencimiento4();
                emitido = fp2.getEmitidoVencimiento4();
                imputado = fp2.getImputadoVencimiento4();
            } else if (indice == 4) {
                recibo = fp2.getReciboVencimiento5();
                cobrado = fp2.getCobradoVencimiento5();
                emitido = fp2.getEmitidoVencimiento5();
                imputado = fp2.getImputadoVencimiento5();
            } else if (indice == 5) {
                recibo = fp2.getReciboVencimiento6();
                cobrado = fp2.getCobradoVencimiento6();
                emitido = fp2.getEmitidoVencimiento6();
                imputado = fp2.getImputadoVencimiento6();
            } else if (indice == 6) {
                recibo = fp2.getReciboVencimiento7();
                cobrado = fp2.getCobradoVencimiento7();
                emitido = fp2.getEmitidoVencimiento7();
                imputado = fp2.getImputadoVencimiento7();
            } else if (indice == 7) {
                recibo = fp2.getReciboVencimiento8();
                cobrado = fp2.getCobradoVencimiento8();
                emitido = fp2.getEmitidoVencimiento8();
                imputado = fp2.getImputadoVencimiento8();
            } else if (indice == 8) {
                recibo = fp2.getReciboVencimiento9();
                cobrado = fp2.getCobradoVencimiento9();
                emitido = fp2.getEmitidoVencimiento9();
                imputado = fp2.getImputadoVencimiento9();
            } else {
                recibo = fp2.getReciboVencimiento10();
                cobrado = fp2.getCobradoVencimiento10();
                emitido = fp2.getEmitidoVencimiento10();
                imputado = fp2.getImputadoVencimiento10();
            }

             double importeParaVencimiento = Double.valueOf(Util.convertirComaAPunto(this.lprecio_final.getText()));
             VencimientoC pl = new VencimientoC(indice, porcentaje, tipoRecibo, fechaStr, importeParaVencimiento, importe, fp2, recibo, this, tvencimientos.getRowCount() > 1, cobrado, emitido, imputado);
             pl.setDefaultCloseOperation(PlazoC.DISPOSE_ON_CLOSE);
             pl.setLocationRelativeTo(null);
             pl.setVisible(true);
                     
        }
}//GEN-LAST:event_bmodificarvencimientoActionPerformed

private void beliminarvencimientoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_beliminarvencimientoActionPerformed
    eliminarVencimiento();
}//GEN-LAST:event_beliminarvencimientoActionPerformed

    private void eliminarVencimiento() {

        int numVencimientos = tvencimientos.getRowCount();
        if (numVencimientos == 1) {
            JOptionPane.showMessageDialog(null, "No se puede eliminar el único vencimiento existente", "Error", JOptionPane.ERROR_MESSAGE);
        } else if (numVencimientos > 1) {
            int indice = tvencimientos.getSelectedRow();
            if (indice >= 0) {
                String porcentaje = (String) tvencimientos.getValueAt(indice, 1);
                String importe = (String) tvencimientos.getValueAt(indice, 2);
                disminuirVencimientosModificacion((-1) * Double.valueOf(Util.convertirComaAPunto(porcentaje)), (-1) * Double.valueOf(Util.convertirComaAPunto(importe)));
                fp2.setNumplazosvencimiento(fp2.getNumplazosvencimiento() - 1);
                reorganizarVencimientos(indice);
                limpiarVencimientos();
                rellenarVencimientos();
            }
        }
    }

    private void reorganizarVencimientos(int indiceBorrado) {

        if (indiceBorrado == 0) {
            fp2.setCobradoVencimiento1(fp2.getCobradoVencimiento2());
            fp2.setEmitidoVencimiento1(fp2.getEmitidoVencimiento2());
            fp2.setReciboVencimiento1(fp2.getReciboVencimiento2());
            fp2.setImputadoVencimiento1(fp2.getImputadoVencimiento2());
            fp2.setIid_tr_v1(fp2.getIid_tr_v2());
            fp2.setImportev1(fp2.getImportev2());
            fp2.setPlazovm1(fp2.getPlazovm2());
            fp2.setPlazopm1(fp2.getPlazopm2());

            fp2.setCobradoVencimiento2(fp2.getCobradoVencimiento3());
            fp2.setEmitidoVencimiento2(fp2.getEmitidoVencimiento3());
            fp2.setReciboVencimiento2(fp2.getReciboVencimiento3());
            fp2.setImputadoVencimiento2(fp2.getImputadoVencimiento3());
            fp2.setIid_tr_v2(fp2.getIid_tr_v3());
            fp2.setImportev2(fp2.getImportev3());
            fp2.setPlazovm2(fp2.getPlazovm3());
            fp2.setPlazopm2(fp2.getPlazopm3());

            fp2.setCobradoVencimiento3(fp2.getCobradoVencimiento4());
            fp2.setEmitidoVencimiento3(fp2.getEmitidoVencimiento4());
            fp2.setReciboVencimiento3(fp2.getReciboVencimiento4());
            fp2.setImputadoVencimiento3(fp2.getImputadoVencimiento4());
            fp2.setIid_tr_v3(fp2.getIid_tr_v4());
            fp2.setImportev3(fp2.getImportev4());
            fp2.setPlazovm3(fp2.getPlazovm4());
            fp2.setPlazopm3(fp2.getPlazopm4());

            fp2.setCobradoVencimiento4(fp2.getCobradoVencimiento5());
            fp2.setEmitidoVencimiento4(fp2.getEmitidoVencimiento5());
            fp2.setReciboVencimiento4(fp2.getReciboVencimiento5());
            fp2.setImputadoVencimiento4(fp2.getImputadoVencimiento5());
            fp2.setIid_tr_v4(fp2.getIid_tr_v5());
            fp2.setImportev4(fp2.getImportev5());
            fp2.setPlazovm4(fp2.getPlazovm5());
            fp2.setPlazopm4(fp2.getPlazopm5());

            fp2.setCobradoVencimiento5(fp2.getCobradoVencimiento6());
            fp2.setEmitidoVencimiento5(fp2.getEmitidoVencimiento6());
            fp2.setReciboVencimiento5(fp2.getReciboVencimiento6());
            fp2.setImputadoVencimiento5(fp2.getImputadoVencimiento6());
            fp2.setIid_tr_v5(fp2.getIid_tr_v6());
            fp2.setImportev5(fp2.getImportev6());
            fp2.setPlazovm5(fp2.getPlazovm6());
            fp2.setPlazopm5(fp2.getPlazopm6());

            fp2.setCobradoVencimiento6(fp2.getCobradoVencimiento7());
            fp2.setEmitidoVencimiento6(fp2.getEmitidoVencimiento7());
            fp2.setReciboVencimiento6(fp2.getReciboVencimiento7());
            fp2.setImputadoVencimiento6(fp2.getImputadoVencimiento7());
            fp2.setIid_tr_v6(fp2.getIid_tr_v7());
            fp2.setImportev6(fp2.getImportev7());
            fp2.setPlazovm6(fp2.getPlazovm7());
            fp2.setPlazopm6(fp2.getPlazopm7());

            fp2.setCobradoVencimiento7(fp2.getCobradoVencimiento8());
            fp2.setEmitidoVencimiento7(fp2.getEmitidoVencimiento8());
            fp2.setReciboVencimiento7(fp2.getReciboVencimiento8());
            fp2.setImputadoVencimiento7(fp2.getImputadoVencimiento8());
            fp2.setIid_tr_v7(fp2.getIid_tr_v8());
            fp2.setImportev7(fp2.getImportev8());
            fp2.setPlazovm7(fp2.getPlazovm8());
            fp2.setPlazopm7(fp2.getPlazopm8());

            fp2.setCobradoVencimiento8(fp2.getCobradoVencimiento9());
            fp2.setEmitidoVencimiento8(fp2.getEmitidoVencimiento9());
            fp2.setReciboVencimiento8(fp2.getReciboVencimiento9());
            fp2.setImputadoVencimiento8(fp2.getImputadoVencimiento9());
            fp2.setIid_tr_v8(fp2.getIid_tr_v9());
            fp2.setImportev8(fp2.getImportev9());
            fp2.setPlazovm8(fp2.getPlazovm9());
            fp2.setPlazopm8(fp2.getPlazopm9());

            fp2.setCobradoVencimiento9(fp2.getCobradoVencimiento10());
            fp2.setEmitidoVencimiento9(fp2.getEmitidoVencimiento10());
            fp2.setReciboVencimiento9(fp2.getReciboVencimiento10());
            fp2.setImputadoVencimiento9(fp2.getImputadoVencimiento10());
            fp2.setIid_tr_v9(fp2.getIid_tr_v10());
            fp2.setImportev9(fp2.getImportev10());
            fp2.setPlazovm9(fp2.getPlazovm10());
            fp2.setPlazopm9(fp2.getPlazopm10());
        } else if (indiceBorrado == 1) {
            fp2.setCobradoVencimiento2(fp2.getCobradoVencimiento3());
            fp2.setEmitidoVencimiento2(fp2.getEmitidoVencimiento3());
            fp2.setReciboVencimiento2(fp2.getReciboVencimiento3());
            fp2.setImputadoVencimiento2(fp2.getImputadoVencimiento3());
            fp2.setIid_tr_v2(fp2.getIid_tr_v3());
            fp2.setImportev2(fp2.getImportev3());
            fp2.setPlazovm2(fp2.getPlazovm3());
            fp2.setPlazopm2(fp2.getPlazopm3());

            fp2.setCobradoVencimiento3(fp2.getCobradoVencimiento4());
            fp2.setEmitidoVencimiento3(fp2.getEmitidoVencimiento4());
            fp2.setReciboVencimiento3(fp2.getReciboVencimiento4());
            fp2.setImputadoVencimiento3(fp2.getImputadoVencimiento4());
            fp2.setIid_tr_v3(fp2.getIid_tr_v4());
            fp2.setImportev3(fp2.getImportev4());
            fp2.setPlazovm3(fp2.getPlazovm4());
            fp2.setPlazopm3(fp2.getPlazopm4());

            fp2.setCobradoVencimiento4(fp2.getCobradoVencimiento5());
            fp2.setEmitidoVencimiento4(fp2.getEmitidoVencimiento5());
            fp2.setReciboVencimiento4(fp2.getReciboVencimiento5());
            fp2.setImputadoVencimiento4(fp2.getImputadoVencimiento5());
            fp2.setIid_tr_v4(fp2.getIid_tr_v5());
            fp2.setImportev4(fp2.getImportev5());
            fp2.setPlazovm4(fp2.getPlazovm5());
            fp2.setPlazopm4(fp2.getPlazopm5());

            fp2.setCobradoVencimiento5(fp2.getCobradoVencimiento6());
            fp2.setEmitidoVencimiento5(fp2.getEmitidoVencimiento6());
            fp2.setReciboVencimiento5(fp2.getReciboVencimiento6());
            fp2.setImputadoVencimiento5(fp2.getImputadoVencimiento6());
            fp2.setIid_tr_v5(fp2.getIid_tr_v6());
            fp2.setImportev5(fp2.getImportev6());
            fp2.setPlazovm5(fp2.getPlazovm6());
            fp2.setPlazopm5(fp2.getPlazopm6());

            fp2.setCobradoVencimiento6(fp2.getCobradoVencimiento7());
            fp2.setEmitidoVencimiento6(fp2.getEmitidoVencimiento7());
            fp2.setReciboVencimiento6(fp2.getReciboVencimiento7());
            fp2.setImputadoVencimiento6(fp2.getImputadoVencimiento7());
            fp2.setIid_tr_v6(fp2.getIid_tr_v7());
            fp2.setImportev6(fp2.getImportev7());
            fp2.setPlazovm6(fp2.getPlazovm7());
            fp2.setPlazopm6(fp2.getPlazopm7());

            fp2.setCobradoVencimiento7(fp2.getCobradoVencimiento8());
            fp2.setEmitidoVencimiento7(fp2.getEmitidoVencimiento8());
            fp2.setReciboVencimiento7(fp2.getReciboVencimiento8());
            fp2.setImputadoVencimiento7(fp2.getImputadoVencimiento8());
            fp2.setIid_tr_v7(fp2.getIid_tr_v8());
            fp2.setImportev7(fp2.getImportev8());
            fp2.setPlazovm7(fp2.getPlazovm8());
            fp2.setPlazopm7(fp2.getPlazopm8());

            fp2.setCobradoVencimiento8(fp2.getCobradoVencimiento9());
            fp2.setEmitidoVencimiento8(fp2.getEmitidoVencimiento9());
            fp2.setReciboVencimiento8(fp2.getReciboVencimiento9());
            fp2.setImputadoVencimiento8(fp2.getImputadoVencimiento9());
            fp2.setIid_tr_v8(fp2.getIid_tr_v9());
            fp2.setImportev8(fp2.getImportev9());
            fp2.setPlazovm8(fp2.getPlazovm9());
            fp2.setPlazopm8(fp2.getPlazopm9());

            fp2.setCobradoVencimiento9(fp2.getCobradoVencimiento10());
            fp2.setEmitidoVencimiento9(fp2.getEmitidoVencimiento10());
            fp2.setReciboVencimiento9(fp2.getReciboVencimiento10());
            fp2.setImputadoVencimiento9(fp2.getImputadoVencimiento10());
            fp2.setIid_tr_v9(fp2.getIid_tr_v10());
            fp2.setImportev9(fp2.getImportev10());
            fp2.setPlazovm9(fp2.getPlazovm10());
            fp2.setPlazopm9(fp2.getPlazopm10());
        } else if (indiceBorrado == 2) {
            fp2.setCobradoVencimiento3(fp2.getCobradoVencimiento4());
            fp2.setEmitidoVencimiento3(fp2.getEmitidoVencimiento4());
            fp2.setReciboVencimiento3(fp2.getReciboVencimiento4());
            fp2.setImputadoVencimiento3(fp2.getImputadoVencimiento4());
            fp2.setIid_tr_v3(fp2.getIid_tr_v4());
            fp2.setImportev3(fp2.getImportev4());
            fp2.setPlazovm3(fp2.getPlazovm4());
            fp2.setPlazopm3(fp2.getPlazopm4());

            fp2.setCobradoVencimiento4(fp2.getCobradoVencimiento5());
            fp2.setEmitidoVencimiento4(fp2.getEmitidoVencimiento5());
            fp2.setReciboVencimiento4(fp2.getReciboVencimiento5());
            fp2.setImputadoVencimiento4(fp2.getImputadoVencimiento5());
            fp2.setIid_tr_v4(fp2.getIid_tr_v5());
            fp2.setImportev4(fp2.getImportev5());
            fp2.setPlazovm4(fp2.getPlazovm5());
            fp2.setPlazopm4(fp2.getPlazopm5());

            fp2.setCobradoVencimiento5(fp2.getCobradoVencimiento6());
            fp2.setEmitidoVencimiento5(fp2.getEmitidoVencimiento6());
            fp2.setReciboVencimiento5(fp2.getReciboVencimiento6());
            fp2.setImputadoVencimiento5(fp2.getImputadoVencimiento6());
            fp2.setIid_tr_v5(fp2.getIid_tr_v6());
            fp2.setImportev5(fp2.getImportev6());
            fp2.setPlazovm5(fp2.getPlazovm6());
            fp2.setPlazopm5(fp2.getPlazopm6());

            fp2.setCobradoVencimiento6(fp2.getCobradoVencimiento7());
            fp2.setEmitidoVencimiento6(fp2.getEmitidoVencimiento7());
            fp2.setReciboVencimiento6(fp2.getReciboVencimiento7());
            fp2.setImputadoVencimiento6(fp2.getImputadoVencimiento7());
            fp2.setIid_tr_v6(fp2.getIid_tr_v7());
            fp2.setImportev6(fp2.getImportev7());
            fp2.setPlazovm6(fp2.getPlazovm7());
            fp2.setPlazopm6(fp2.getPlazopm7());

            fp2.setCobradoVencimiento7(fp2.getCobradoVencimiento8());
            fp2.setEmitidoVencimiento7(fp2.getEmitidoVencimiento8());
            fp2.setReciboVencimiento7(fp2.getReciboVencimiento8());
            fp2.setImputadoVencimiento7(fp2.getImputadoVencimiento8());
            fp2.setIid_tr_v7(fp2.getIid_tr_v8());
            fp2.setImportev7(fp2.getImportev8());
            fp2.setPlazovm7(fp2.getPlazovm8());
            fp2.setPlazopm7(fp2.getPlazopm8());

            fp2.setCobradoVencimiento8(fp2.getCobradoVencimiento9());
            fp2.setEmitidoVencimiento8(fp2.getEmitidoVencimiento9());
            fp2.setReciboVencimiento8(fp2.getReciboVencimiento9());
            fp2.setImputadoVencimiento8(fp2.getImputadoVencimiento9());
            fp2.setIid_tr_v8(fp2.getIid_tr_v9());
            fp2.setImportev8(fp2.getImportev9());
            fp2.setPlazovm8(fp2.getPlazovm9());
            fp2.setPlazopm8(fp2.getPlazopm9());

            fp2.setCobradoVencimiento9(fp2.getCobradoVencimiento10());
            fp2.setEmitidoVencimiento9(fp2.getEmitidoVencimiento10());
            fp2.setReciboVencimiento9(fp2.getReciboVencimiento10());
            fp2.setImputadoVencimiento9(fp2.getImputadoVencimiento10());
            fp2.setIid_tr_v9(fp2.getIid_tr_v10());
            fp2.setImportev9(fp2.getImportev10());
            fp2.setPlazovm9(fp2.getPlazovm10());
            fp2.setPlazopm9(fp2.getPlazopm10());
        } else if (indiceBorrado == 3) {
            fp2.setCobradoVencimiento4(fp2.getCobradoVencimiento5());
            fp2.setEmitidoVencimiento4(fp2.getEmitidoVencimiento5());
            fp2.setReciboVencimiento4(fp2.getReciboVencimiento5());
            fp2.setImputadoVencimiento4(fp2.getImputadoVencimiento5());
            fp2.setIid_tr_v4(fp2.getIid_tr_v5());
            fp2.setImportev4(fp2.getImportev5());
            fp2.setPlazovm4(fp2.getPlazovm5());
            fp2.setPlazopm4(fp2.getPlazopm5());

            fp2.setCobradoVencimiento5(fp2.getCobradoVencimiento6());
            fp2.setEmitidoVencimiento5(fp2.getEmitidoVencimiento6());
            fp2.setReciboVencimiento5(fp2.getReciboVencimiento6());
            fp2.setImputadoVencimiento5(fp2.getImputadoVencimiento6());
            fp2.setIid_tr_v5(fp2.getIid_tr_v6());
            fp2.setImportev5(fp2.getImportev6());
            fp2.setPlazovm5(fp2.getPlazovm6());
            fp2.setPlazopm5(fp2.getPlazopm6());

            fp2.setCobradoVencimiento6(fp2.getCobradoVencimiento7());
            fp2.setEmitidoVencimiento6(fp2.getEmitidoVencimiento7());
            fp2.setReciboVencimiento6(fp2.getReciboVencimiento7());
            fp2.setImputadoVencimiento6(fp2.getImputadoVencimiento7());
            fp2.setIid_tr_v6(fp2.getIid_tr_v7());
            fp2.setImportev6(fp2.getImportev7());
            fp2.setPlazovm6(fp2.getPlazovm7());
            fp2.setPlazopm6(fp2.getPlazopm7());

            fp2.setCobradoVencimiento7(fp2.getCobradoVencimiento8());
            fp2.setEmitidoVencimiento7(fp2.getEmitidoVencimiento8());
            fp2.setReciboVencimiento7(fp2.getReciboVencimiento8());
            fp2.setImputadoVencimiento7(fp2.getImputadoVencimiento8());
            fp2.setIid_tr_v7(fp2.getIid_tr_v8());
            fp2.setImportev7(fp2.getImportev8());
            fp2.setPlazovm7(fp2.getPlazovm8());
            fp2.setPlazopm7(fp2.getPlazopm8());

            fp2.setCobradoVencimiento8(fp2.getCobradoVencimiento9());
            fp2.setEmitidoVencimiento8(fp2.getEmitidoVencimiento9());
            fp2.setReciboVencimiento8(fp2.getReciboVencimiento9());
            fp2.setImputadoVencimiento8(fp2.getImputadoVencimiento9());
            fp2.setIid_tr_v8(fp2.getIid_tr_v9());
            fp2.setImportev8(fp2.getImportev9());
            fp2.setPlazovm8(fp2.getPlazovm9());
            fp2.setPlazopm8(fp2.getPlazopm9());

            fp2.setCobradoVencimiento9(fp2.getCobradoVencimiento10());
            fp2.setEmitidoVencimiento9(fp2.getEmitidoVencimiento10());
            fp2.setReciboVencimiento9(fp2.getReciboVencimiento10());
            fp2.setImputadoVencimiento9(fp2.getImputadoVencimiento10());
            fp2.setIid_tr_v9(fp2.getIid_tr_v10());
            fp2.setImportev9(fp2.getImportev10());
            fp2.setPlazovm9(fp2.getPlazovm10());
            fp2.setPlazopm9(fp2.getPlazopm10());
        } else if (indiceBorrado == 4) {
            fp2.setCobradoVencimiento5(fp2.getCobradoVencimiento6());
            fp2.setEmitidoVencimiento5(fp2.getEmitidoVencimiento6());
            fp2.setReciboVencimiento5(fp2.getReciboVencimiento6());
            fp2.setImputadoVencimiento5(fp2.getImputadoVencimiento6());
            fp2.setIid_tr_v5(fp2.getIid_tr_v6());
            fp2.setImportev5(fp2.getImportev6());
            fp2.setPlazovm5(fp2.getPlazovm6());
            fp2.setPlazopm5(fp2.getPlazopm6());

            fp2.setCobradoVencimiento6(fp2.getCobradoVencimiento7());
            fp2.setEmitidoVencimiento6(fp2.getEmitidoVencimiento7());
            fp2.setReciboVencimiento6(fp2.getReciboVencimiento7());
            fp2.setImputadoVencimiento6(fp2.getImputadoVencimiento7());
            fp2.setIid_tr_v6(fp2.getIid_tr_v7());
            fp2.setImportev6(fp2.getImportev7());
            fp2.setPlazovm6(fp2.getPlazovm7());
            fp2.setPlazopm6(fp2.getPlazopm7());

            fp2.setCobradoVencimiento7(fp2.getCobradoVencimiento8());
            fp2.setEmitidoVencimiento7(fp2.getEmitidoVencimiento8());
            fp2.setReciboVencimiento7(fp2.getReciboVencimiento8());
            fp2.setImputadoVencimiento7(fp2.getImputadoVencimiento8());
            fp2.setIid_tr_v7(fp2.getIid_tr_v8());
            fp2.setImportev7(fp2.getImportev8());
            fp2.setPlazovm7(fp2.getPlazovm8());
            fp2.setPlazopm7(fp2.getPlazopm8());

            fp2.setCobradoVencimiento8(fp2.getCobradoVencimiento9());
            fp2.setEmitidoVencimiento8(fp2.getEmitidoVencimiento9());
            fp2.setReciboVencimiento8(fp2.getReciboVencimiento9());
            fp2.setImputadoVencimiento8(fp2.getImputadoVencimiento9());
            fp2.setIid_tr_v8(fp2.getIid_tr_v9());
            fp2.setImportev8(fp2.getImportev9());
            fp2.setPlazovm8(fp2.getPlazovm9());
            fp2.setPlazopm8(fp2.getPlazopm9());

            fp2.setCobradoVencimiento9(fp2.getCobradoVencimiento10());
            fp2.setEmitidoVencimiento9(fp2.getEmitidoVencimiento10());
            fp2.setReciboVencimiento9(fp2.getReciboVencimiento10());
            fp2.setImputadoVencimiento9(fp2.getImputadoVencimiento10());
            fp2.setIid_tr_v9(fp2.getIid_tr_v10());
            fp2.setImportev9(fp2.getImportev10());
            fp2.setPlazovm9(fp2.getPlazovm10());
            fp2.setPlazopm9(fp2.getPlazopm10());
        } else if (indiceBorrado == 5) {
            fp2.setCobradoVencimiento6(fp2.getCobradoVencimiento7());
            fp2.setEmitidoVencimiento6(fp2.getEmitidoVencimiento7());
            fp2.setReciboVencimiento6(fp2.getReciboVencimiento7());
            fp2.setImputadoVencimiento6(fp2.getImputadoVencimiento7());
            fp2.setIid_tr_v6(fp2.getIid_tr_v7());
            fp2.setImportev6(fp2.getImportev7());
            fp2.setPlazovm6(fp2.getPlazovm7());
            fp2.setPlazopm6(fp2.getPlazopm7());

            fp2.setCobradoVencimiento7(fp2.getCobradoVencimiento8());
            fp2.setEmitidoVencimiento7(fp2.getEmitidoVencimiento8());
            fp2.setReciboVencimiento7(fp2.getReciboVencimiento8());
            fp2.setImputadoVencimiento7(fp2.getImputadoVencimiento8());
            fp2.setIid_tr_v7(fp2.getIid_tr_v8());
            fp2.setImportev7(fp2.getImportev8());
            fp2.setPlazovm7(fp2.getPlazovm8());
            fp2.setPlazopm7(fp2.getPlazopm8());

            fp2.setCobradoVencimiento8(fp2.getCobradoVencimiento9());
            fp2.setEmitidoVencimiento8(fp2.getEmitidoVencimiento9());
            fp2.setReciboVencimiento8(fp2.getReciboVencimiento9());
            fp2.setImputadoVencimiento8(fp2.getImputadoVencimiento9());
            fp2.setIid_tr_v8(fp2.getIid_tr_v9());
            fp2.setImportev8(fp2.getImportev9());
            fp2.setPlazovm8(fp2.getPlazovm9());
            fp2.setPlazopm8(fp2.getPlazopm9());

            fp2.setCobradoVencimiento9(fp2.getCobradoVencimiento10());
            fp2.setEmitidoVencimiento9(fp2.getEmitidoVencimiento10());
            fp2.setReciboVencimiento9(fp2.getReciboVencimiento10());
            fp2.setImputadoVencimiento9(fp2.getImputadoVencimiento10());
            fp2.setIid_tr_v9(fp2.getIid_tr_v10());
            fp2.setImportev9(fp2.getImportev10());
            fp2.setPlazovm9(fp2.getPlazovm10());
            fp2.setPlazopm9(fp2.getPlazopm10());
        } else if (indiceBorrado == 6) {
            fp2.setCobradoVencimiento7(fp2.getCobradoVencimiento8());
            fp2.setEmitidoVencimiento7(fp2.getEmitidoVencimiento8());
            fp2.setReciboVencimiento7(fp2.getReciboVencimiento8());
            fp2.setImputadoVencimiento7(fp2.getImputadoVencimiento8());
            fp2.setIid_tr_v7(fp2.getIid_tr_v8());
            fp2.setImportev7(fp2.getImportev8());
            fp2.setPlazovm7(fp2.getPlazovm8());
            fp2.setPlazopm7(fp2.getPlazopm8());

            fp2.setCobradoVencimiento8(fp2.getCobradoVencimiento9());
            fp2.setEmitidoVencimiento8(fp2.getEmitidoVencimiento9());
            fp2.setReciboVencimiento8(fp2.getReciboVencimiento9());
            fp2.setImputadoVencimiento8(fp2.getImputadoVencimiento9());
            fp2.setIid_tr_v8(fp2.getIid_tr_v9());
            fp2.setImportev8(fp2.getImportev9());
            fp2.setPlazovm8(fp2.getPlazovm9());
            fp2.setPlazopm8(fp2.getPlazopm9());

            fp2.setCobradoVencimiento9(fp2.getCobradoVencimiento10());
            fp2.setEmitidoVencimiento9(fp2.getEmitidoVencimiento10());
            fp2.setReciboVencimiento9(fp2.getReciboVencimiento10());
            fp2.setImputadoVencimiento9(fp2.getImputadoVencimiento10());
            fp2.setIid_tr_v9(fp2.getIid_tr_v10());
            fp2.setImportev9(fp2.getImportev10());
            fp2.setPlazovm9(fp2.getPlazovm10());
            fp2.setPlazopm9(fp2.getPlazopm10());
        } else if (indiceBorrado == 7) {
            fp2.setCobradoVencimiento8(fp2.getCobradoVencimiento9());
            fp2.setEmitidoVencimiento8(fp2.getEmitidoVencimiento9());
            fp2.setReciboVencimiento8(fp2.getReciboVencimiento9());
            fp2.setImputadoVencimiento8(fp2.getImputadoVencimiento9());
            fp2.setIid_tr_v8(fp2.getIid_tr_v9());
            fp2.setImportev8(fp2.getImportev9());
            fp2.setPlazovm8(fp2.getPlazovm9());
            fp2.setPlazopm8(fp2.getPlazopm9());

            fp2.setCobradoVencimiento9(fp2.getCobradoVencimiento10());
            fp2.setEmitidoVencimiento9(fp2.getEmitidoVencimiento10());
            fp2.setReciboVencimiento9(fp2.getReciboVencimiento10());
            fp2.setImputadoVencimiento9(fp2.getImputadoVencimiento10());
            fp2.setIid_tr_v9(fp2.getIid_tr_v10());
            fp2.setImportev9(fp2.getImportev10());
            fp2.setPlazovm9(fp2.getPlazovm10());
            fp2.setPlazopm9(fp2.getPlazopm10());
        } else if (indiceBorrado == 8) {
            fp2.setCobradoVencimiento9(fp2.getCobradoVencimiento10());
            fp2.setEmitidoVencimiento9(fp2.getEmitidoVencimiento10());
            fp2.setReciboVencimiento9(fp2.getReciboVencimiento10());
            fp2.setImputadoVencimiento9(fp2.getImputadoVencimiento10());
            fp2.setIid_tr_v9(fp2.getIid_tr_v10());
            fp2.setImportev9(fp2.getImportev10());
            fp2.setPlazovm9(fp2.getPlazovm10());
            fp2.setPlazopm9(fp2.getPlazopm10());
        }
    }
private void tvencimientosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tvencimientosMouseClicked
    if (tvencimientos.getSelectedRowCount() != 0) {
        beliminarvencimiento.setEnabled(true);
    }
    if (tvencimientos.getSelectedRowCount() != 0) {
        bmodificarvencimiento.setEnabled(true);
    }

    if (evt.getClickCount() == 2) {
        visualizarVencimiento();
    }
}//GEN-LAST:event_tvencimientosMouseClicked

private void bVerNotasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bVerNotasActionPerformed
    NuevaNotaDocumento nnd = new NuevaNotaDocumento(p, "vis");
    nnd.setDefaultCloseOperation(NuevaNotaDocumento.DISPOSE_ON_CLOSE);
    nnd.setLocationRelativeTo(null);
    nnd.setVisible(true);
}//GEN-LAST:event_bVerNotasActionPerformed

private void tObservacionesKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tObservacionesKeyReleased
    String observaciones = tObservaciones.getText();
    if (observaciones.length() >= Constantes.TAM_OBSERVACIONES_PRESUPUESTO) {
        JOptionPane.showMessageDialog(null, "El tamaÃ±o de las observaciones no puede pasar de " + Constantes.TAM_OBSERVACIONES_PRESUPUESTO + " caracteres", "Error", JOptionPane.ERROR_MESSAGE);
        observaciones = observaciones.substring(0, Constantes.TAM_OBSERVACIONES_PRESUPUESTO);
        tObservaciones.setText(observaciones);
    }

}//GEN-LAST:event_tObservacionesKeyReleased

private void bGuardarClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bGuardarClienteActionPerformed

    boolean isCPnumerico = true;
    Integer cpNumerico = -1;

    String nombreCliente = this.tNombreCliente.getText();
    String codigoCliente = this.tCodCliente.getText();
    
    if (nombreCliente != null && !nombreCliente.equals("") && codigoCliente != null && !codigoCliente.equals("")) {

        Agentes clienteTemp = BaseDatos.obtenerAgentesPorCodigo(codigoCliente, "", e);
        if (clienteTemp == null) {
            try {

                if (!tCpCliente.getText().equals("")) {
                    cpNumerico = new Integer(this.tCpCliente.getText());
                }
            } catch (Exception ex) {
                isCPnumerico = false;
            }

            if (isCPnumerico) {
                TipoAgente tipo = BaseDatos.obtenerTipoAgente("Proveedor");
                Agentes nuevoCliente = new Agentes();
                nuevoCliente.setCod_agente(this.tCodCliente.getText());
                nuevoCliente.setCif_nif(this.tDniCliente.getText());
                nuevoCliente.setNombre_comercial(this.tNombreCliente.getText());
                nuevoCliente.setNombre_fiscal(this.tNombreCliente.getText());
                nuevoCliente.setTelefono(this.tTelefonoCliente.getText());
                nuevoCliente.setDireccion(this.tDireccionCliente.getText());
                nuevoCliente.setCodigo_postal(new Integer(this.tCpCliente.getText()));
                nuevoCliente.setProvincia(this.tProvinciaCliente.getText());
                nuevoCliente.setPoblacion(this.tLocalidadCliente.getText());
                nuevoCliente.setPais(this.tPaisCliente.getText());
                nuevoCliente.setEmail(this.tEmailCliente.getText());
                nuevoCliente.setTipo_agente(tipo);
                nuevoCliente.setIid_empresa(e);

                if (BaseDatos.insertarElemento(nuevoCliente)) {
                    JOptionPane.showMessageDialog(null, "proveedor almacenado correctamente", "InformaciÃ³n", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(null, "Se ha producido un error al almacenar el proveedor", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(null, "El CÃ³digo postal del proveedor debe ser numÃ©rico", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(null, "El proveedor introducido ya existe", "Error", JOptionPane.ERROR_MESSAGE);
        }
    } else {
        JOptionPane.showMessageDialog(null, "Debe introducir el nombre y el cÃ³digo", "Error", JOptionPane.ERROR_MESSAGE);
    }
}//GEN-LAST:event_bGuardarClienteActionPerformed

private void jMenuItemLineaDespuesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItemLineaDespuesActionPerformed
    insertarLineaNueva(lineaActiva, true);
}//GEN-LAST:event_jMenuItemLineaDespuesActionPerformed

private void jMenuItemNotaFinalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItemNotaFinalActionPerformed
    insertarLineaNueva(this.listaArticulos.size(), false);
}//GEN-LAST:event_jMenuItemNotaFinalActionPerformed

private void jMenuItemNotaAntesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItemNotaAntesActionPerformed
    insertarLineaNueva(lineaActiva - 1, false);
    lineaActiva++;
}//GEN-LAST:event_jMenuItemNotaAntesActionPerformed

private void jMenuItemNotaDespuesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItemNotaDespuesActionPerformed
    insertarLineaNueva(lineaActiva, false);
}//GEN-LAST:event_jMenuItemNotaDespuesActionPerformed

private void jMenuItemLineaPrincipioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItemLineaPrincipioActionPerformed
    insertarLineaNueva(0, true);
}//GEN-LAST:event_jMenuItemLineaPrincipioActionPerformed

private void jMenuItemLineaFinalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItemLineaFinalActionPerformed
    insertarLineaNueva(listaArticulos.size(), true);
}//GEN-LAST:event_jMenuItemLineaFinalActionPerformed

private void jMenuItemLineaAntesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItemLineaAntesActionPerformed
    insertarLineaNueva(lineaActiva - 1, true);
    lineaActiva++;
}//GEN-LAST:event_jMenuItemLineaAntesActionPerformed

private void jMenuItemNotaPrincipioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItemNotaPrincipioActionPerformed
    insertarLineaNueva(0, false);
}//GEN-LAST:event_jMenuItemNotaPrincipioActionPerformed

private void tCodClienteKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tCodClienteKeyReleased
    String campo = tCodCliente.getText();
    if (campo.length() > Constantes.TAM_CODIGO_CLIENTE_PRESUPUESTO) {
        JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_CODIGO_CLIENTE_PRESUPUESTO, "Error", JOptionPane.ERROR_MESSAGE);
        tCodCliente.setText(campo.substring(0, Constantes.TAM_CODIGO_CLIENTE_PRESUPUESTO));
    }
}//GEN-LAST:event_tCodClienteKeyReleased

private void tNombreClienteKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tNombreClienteKeyReleased
    String campo = tNombreCliente.getText();
    if (campo.length() > Constantes.TAM_NOMBRE_CLIENTE_PRESUPUESTO) {
        JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_NOMBRE_CLIENTE_PRESUPUESTO, "Error", JOptionPane.ERROR_MESSAGE);
        tNombreCliente.setText(campo.substring(0, Constantes.TAM_NOMBRE_CLIENTE_PRESUPUESTO));
    }
}//GEN-LAST:event_tNombreClienteKeyReleased

private void tTelefonoClienteKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tTelefonoClienteKeyReleased
    String campo = tTelefonoCliente.getText();
    if (campo.length() > Constantes.TAM_TELEFONO_CLIENTE_PRESUPUESTO) {
        JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_TELEFONO_CLIENTE_PRESUPUESTO, "Error", JOptionPane.ERROR_MESSAGE);
        tTelefonoCliente.setText(campo.substring(0, Constantes.TAM_TELEFONO_CLIENTE_PRESUPUESTO));
    }
}//GEN-LAST:event_tTelefonoClienteKeyReleased

private void tCpClienteKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tCpClienteKeyReleased
    String campo = tCpCliente.getText();
    if (campo.length() > Constantes.TAM_CP_CLIENTE_PRESUPUESTO) {
        JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_CP_CLIENTE_PRESUPUESTO, "Error", JOptionPane.ERROR_MESSAGE);
        tCpCliente.setText(campo.substring(0, Constantes.TAM_CP_CLIENTE_PRESUPUESTO));
    }
}//GEN-LAST:event_tCpClienteKeyReleased

private void tPaisClienteKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tPaisClienteKeyReleased
    String campo = tPaisCliente.getText();
    if (campo.length() > Constantes.TAM_PAIS_CLIENTE_PRESUPUESTO) {
        JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_PAIS_CLIENTE_PRESUPUESTO, "Error", JOptionPane.ERROR_MESSAGE);
        tPaisCliente.setText(campo.substring(0, Constantes.TAM_PAIS_CLIENTE_PRESUPUESTO));
    }
}//GEN-LAST:event_tPaisClienteKeyReleased

private void tEmailClienteKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tEmailClienteKeyReleased
    String campo = tEmailCliente.getText();
    if (campo.length() > Constantes.TAM_EMAIL_CLIENTE_PRESUPUESTO) {
        JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_EMAIL_CLIENTE_PRESUPUESTO, "Error", JOptionPane.ERROR_MESSAGE);
        tEmailCliente.setText(campo.substring(0, Constantes.TAM_EMAIL_CLIENTE_PRESUPUESTO));
    }
}//GEN-LAST:event_tEmailClienteKeyReleased

private void tLocalidadClienteKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tLocalidadClienteKeyReleased
    String campo = tLocalidadCliente.getText();
    if (campo.length() > Constantes.TAM_LOCALIDAD_CLIENTE_PRESUPUESTO) {
        JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_LOCALIDAD_CLIENTE_PRESUPUESTO, "Error", JOptionPane.ERROR_MESSAGE);
        tLocalidadCliente.setText(campo.substring(0, Constantes.TAM_LOCALIDAD_CLIENTE_PRESUPUESTO));
    }
}//GEN-LAST:event_tLocalidadClienteKeyReleased

private void tProvinciaClienteKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tProvinciaClienteKeyReleased
    String campo = tProvinciaCliente.getText();
    if (campo.length() > Constantes.TAM_PROVINCIA_CLIENTE_PRESUPUESTO) {
        JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_PROVINCIA_CLIENTE_PRESUPUESTO, "Error", JOptionPane.ERROR_MESSAGE);
        tProvinciaCliente.setText(campo.substring(0, Constantes.TAM_PROVINCIA_CLIENTE_PRESUPUESTO));
    }
}//GEN-LAST:event_tProvinciaClienteKeyReleased

private void tDireccionClienteKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tDireccionClienteKeyReleased
    String campo = tDireccionCliente.getText();
    if (campo.length() > Constantes.TAM_DIRECCION_CLIENTE_PRESUPUESTO) {
        JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_DIRECCION_CLIENTE_PRESUPUESTO, "Error", JOptionPane.ERROR_MESSAGE);
        tDireccionCliente.setText(campo.substring(0, Constantes.TAM_DIRECCION_CLIENTE_PRESUPUESTO));
    }
}//GEN-LAST:event_tDireccionClienteKeyReleased

private void tReferenciaKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tReferenciaKeyReleased
    String campo = tReferencia.getText();
    if (campo.length() > Constantes.TAM_REFERENCIA_PRESUPUESTO) {
        JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_REFERENCIA_PRESUPUESTO, "Error", JOptionPane.ERROR_MESSAGE);
        tReferencia.setText(campo.substring(0, Constantes.TAM_REFERENCIA_PRESUPUESTO));
    }
}//GEN-LAST:event_tReferenciaKeyReleased

private void tplazosadelantadosKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tplazosadelantadosKeyPressed
    if (evt.getKeyChar() == KeyEvent.VK_ENTER) {
        visualizarPlazoAdelantado();
    } else if (evt.getKeyChar() == KeyEvent.VK_DELETE) {
        borrarPlazoAdelantado();
    }
}//GEN-LAST:event_tplazosadelantadosKeyPressed

private void tvencimientosKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tvencimientosKeyPressed
    if (evt.getKeyChar() == KeyEvent.VK_ENTER) {
        visualizarVencimiento();
    } else if (evt.getKeyChar() == KeyEvent.VK_DELETE) {
        eliminarVencimiento();
    }
}//GEN-LAST:event_tvencimientosKeyPressed

private void jMenuImpagadoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuImpagadoActionPerformed
    if (impagado) {
        JOptionPane.showMessageDialog(null, "Este documento ya ha sido dado por impagado", "Error", JOptionPane.ERROR_MESSAGE);
    } else {
        int impagar = 1;
        impagar = JOptionPane.showConfirmDialog(null, "¿Está seguro de que desea dar por impagado el documento?", "¿Dar por impagado?", JOptionPane.YES_NO_OPTION);
        //hacerCambios = -1 ==> se ha pulsado la "x" de cancelar;
        //hacerCambios =  0 ==> se ha pulsado el "sí"
        //hacerCambios =  1 ==> se ha pulsado el "no"

        if (impagar == 0) {
            impagado = true;
            if (p.getClase_documento().getDescripcion().equals(Constantes.FACTURA)) {
                cestado.setSelectedItem("Impagado");
            }
        }
    }
}//GEN-LAST:event_jMenuImpagadoActionPerformed

private void bCrearVencimientoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bCrearVencimientoActionPerformed

    double importeParaVencimiento = Double.valueOf(Util.convertirComaAPunto(this.lprecio_final.getText()));
    int numFilasVencimiento = tvencimientos.getRowCount();
    if (numFilasVencimiento > 0 && numFilasVencimiento < 10) {
         VencimientoC pl = new VencimientoC(numFilasVencimiento, importeParaVencimiento, fp2, this);
         pl.setDefaultCloseOperation(PlazoC.DISPOSE_ON_CLOSE);
         pl.setLocationRelativeTo(null);
         pl.setVisible(true);
    } else if (numFilasVencimiento == 0) {
        JOptionPane.showMessageDialog(null, "Debe haber al menos algún vencimiento", "Error", JOptionPane.ERROR_MESSAGE);
    } else if (numFilasVencimiento > 9) {
        JOptionPane.showMessageDialog(null, "Ya tiene creados 10 vencimientos", "Error", JOptionPane.ERROR_MESSAGE);
    }
}//GEN-LAST:event_bCrearVencimientoActionPerformed

private void jMenuImprimirRecibosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuImprimirRecibosActionPerformed
    if (this.tvencimientos.getRowCount() < 1) {
        JOptionPane.showMessageDialog(null, "No hay ningún vencimiento", "Error", JOptionPane.ERROR_MESSAGE);
    } else {

        HashMap parameters = new HashMap();
        List<VencimientoImpreso> listaVencimientos = new ArrayList<VencimientoImpreso>();
        VencimientoImpreso vi;

        int indice;
        int hasta = tvencimientos.getRowCount();
        String simporte;
        String fechaStr;
        String cuenta = "";
        String entidad = "";
        String codPostalLocalidad = "";

        if (!tCpCliente.getText().equals("") && !tLocalidadCliente.getText().equals("")) {
            codPostalLocalidad = tCpCliente.getText() + " - " + tLocalidadCliente.getText();
        } else if (tCpCliente.getText().equals("")) {
            codPostalLocalidad = tLocalidadCliente.getText();
        } else {
            codPostalLocalidad = tCpCliente.getText();
        }

        Agentes age = BaseDatos.obtenerAgentesPorCodigo(tCodCliente.getText(), "cli", e);
        if (age != null) {
            cuenta = age.getCuenta();
            entidad = age.getEntidad();
        }

        Double dimporte;
        String cadenaEuros = "";
        String cadenaEurosEntera = "";
        String cadenaEurosDecimal = "";
        String tipoRecibo = "";

        for (indice = 1; indice <= hasta; indice++) {

            simporte = (String) tvencimientos.getValueAt(indice - 1, 2);
            fechaStr = (String) tvencimientos.getValueAt(indice - 1, 4);
            tipoRecibo = (String) tvencimientos.getValueAt(indice - 1, 3);

            if (tipoRecibo.equals("Domiciliado")) {
                dimporte = new Double(Util.convertirComaAPunto(simporte));

                cadenaEurosEntera = util.NumLetrasJ.convierte(String.valueOf(dimporte.intValue())).toUpperCase();
                cadenaEurosDecimal = util.NumLetrasJ.convierte(String.valueOf(matematico.Matematico.redondear2decimales(dimporte - dimporte.intValue())).substring(2)).toUpperCase();
                cadenaEuros = cadenaEurosEntera + " CON " + cadenaEurosDecimal;

                vi = new VencimientoImpreso("Ejemplar para la empresa", tnumero.getText() + "-" + indice, tfecha.getText(), fechaStr, "# " + simporte + " #", cadenaEuros, entidad, cuenta, tNombreCliente.getText(), tDireccionCliente.getText(), codPostalLocalidad, tProvinciaCliente.getText(), tTelefonoCliente.getText(), tDniCliente.getText(), e.getDesc_empresa(), e.getCif());
                listaVencimientos.add(vi);
                vi = new VencimientoImpreso("Ejemplar para la empresa", tnumero.getText() + "-" + indice, tfecha.getText(), fechaStr, "# " + simporte + " #", cadenaEuros, entidad, cuenta, tNombreCliente.getText(), tDireccionCliente.getText(), codPostalLocalidad, tProvinciaCliente.getText(), tTelefonoCliente.getText(), tDniCliente.getText(), e.getDesc_empresa(), e.getCif());
                listaVencimientos.add(vi);
                vi = new VencimientoImpreso("Ejemplar para el cliente", tnumero.getText() + "-" + indice, tfecha.getText(), fechaStr, "# " + simporte + " #", cadenaEuros, entidad, cuenta, tNombreCliente.getText(), tDireccionCliente.getText(), codPostalLocalidad, tProvinciaCliente.getText(), tTelefonoCliente.getText(), tDniCliente.getText(), e.getDesc_empresa(), e.getCif());
                listaVencimientos.add(vi);
            }
        }

        parameters.put("vencimiento", new JRBeanCollectionDataSource(listaVencimientos));

        Recibo.imprimirRecibo(parameters);
    }
}//GEN-LAST:event_jMenuImprimirRecibosActionPerformed

private void bVerNotasClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bVerNotasClienteActionPerformed

    String codigo = tCodCliente.getText();
    String tipo = "";
    String tipoCompleto = "";

    if ((cd.getDescripcion().equals(Constantes.PEDIDOC))
            || (cd.getDescripcion().equals(Constantes.ALBARANC))
            || (cd.getDescripcion().equals(Constantes.FACTURAC))) {

        tipo = "prov";
        tipoCompleto = "proveedor";
    } else {
        tipo = "cli";
        tipoCompleto = "cliente";
    }

    Agentes ag = BaseDatos.obtenerAgentesPorCodigo(codigo, tipo, e);
    if (ag == null) {
        JOptionPane.showMessageDialog(null, "El " + tipoCompleto + " no está almacenado en la base de datos", "Error", JOptionPane.ERROR_MESSAGE);
    } else {
        String obs = ag.getObservaciones();
        if (obs != null && !obs.equals("")) {
            VerNotaCliente vnc = new VerNotaCliente(obs);
            vnc.setDefaultCloseOperation(VerNotaCliente.DISPOSE_ON_CLOSE);
            vnc.setLocationRelativeTo(null);
            vnc.setVisible(true);
        } else {
            JOptionPane.showMessageDialog(null, "El " + tipoCompleto + " no tiene observaciones asociadas", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}//GEN-LAST:event_bVerNotasClienteActionPerformed

private void bInsertarArticuloAntesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bInsertarArticuloAntesActionPerformed
    lineaAntes();
}//GEN-LAST:event_bInsertarArticuloAntesActionPerformed

private void bInsertarArticuloDespuesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bInsertarArticuloDespuesActionPerformed
    lineaDespues();
}//GEN-LAST:event_bInsertarArticuloDespuesActionPerformed

private void bInsertarArticuloPrincipioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bInsertarArticuloPrincipioActionPerformed
    lineaPrincipio();
}//GEN-LAST:event_bInsertarArticuloPrincipioActionPerformed

private void bInsertarArticuloFinalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bInsertarArticuloFinalActionPerformed
    lineaFinal();
}//GEN-LAST:event_bInsertarArticuloFinalActionPerformed

private void bInsertarNotaAntesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bInsertarNotaAntesActionPerformed
    notaAntes();
}//GEN-LAST:event_bInsertarNotaAntesActionPerformed

private void bInsertarNotaDespuesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bInsertarNotaDespuesActionPerformed
    notaDespues();
}//GEN-LAST:event_bInsertarNotaDespuesActionPerformed

private void bInsertarNotaPrincipioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bInsertarNotaPrincipioActionPerformed
    notaPrincipio();
}//GEN-LAST:event_bInsertarNotaPrincipioActionPerformed

private void bInsertarNotaFinalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bInsertarNotaFinalActionPerformed
    notaFinal();
}//GEN-LAST:event_bInsertarNotaFinalActionPerformed

private void tIvaKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tIvaKeyReleased
    int tamaño = tIva.getText().length();
    if (tamaño > 0) {
        char cc = tIva.getText().charAt(tamaño - 1);

        if (cc == '.') {
            String contenidoAntiguo = tIva.getText().replace(".", ",");
            tIva.setText(contenidoAntiguo);
            cc = ',';
        }

        if (!((cc >= '0' && cc <= '9') || cc == ',')) {
            String str = tIva.getText().substring(0, tamaño - 1);
            tIva.setText(str);
        } else if (cc == ',') {
            int indicePunto = tIva.getText().indexOf(',');
            if (indicePunto != (tamaño - 1)) {
                String str = tIva.getText().substring(0, tamaño - 1);
                tIva.setText(str);
            }
        }
    } else {
        tIva.setText("0");
    }
    try {
        calcularPrecio();
    } catch (Exception ex) {
        JOptionPane.showMessageDialog(null, "El iva no es un Nº correcto", "Error", JOptionPane.ERROR_MESSAGE);
    }
}//GEN-LAST:event_tIvaKeyReleased

private void bDatosConversionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bDatosConversionActionPerformed
    convertirDocumento(Constantes.PEDIDOC);
}//GEN-LAST:event_bDatosConversionActionPerformed

private void bFlujoDatosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bFlujoDatosActionPerformed
    if (crear) {
        JOptionPane.showMessageDialog(null, "El " + Constantes.PEDIDOC + " aún no ha sido guardado", "Error", JOptionPane.ERROR_MESSAGE);
    } else {
        flujoDatosCompra fd = new flujoDatosCompra(this.p, e, u);
        fd.setDefaultCloseOperation(NuevoPresupuesto.DISPOSE_ON_CLOSE);
        fd.setLocationRelativeTo(null);
        fd.setVisible(true);
    }  
}//GEN-LAST:event_bFlujoDatosActionPerformed

    private void tCodClienteKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tCodClienteKeyPressed
        if (evt.getKeyChar() == KeyEvent.VK_ENTER) {
                
            Agentes c = BaseDatos.obtenerAgentesPorCodigo(tCodCliente.getText(), "prov", e);
            rellenarCliente(c);
        }
    }//GEN-LAST:event_tCodClienteKeyPressed

private void lineaDespues() {                                                      
    insertarLineaNueva(lineaActiva, true);
}                                                     

private void notaFinal() {                                                   
    insertarLineaNueva(this.listaArticulos.size(), false);
}                                                  

private void notaAntes() {                                                   
    insertarLineaNueva(lineaActiva - 1, false);
    lineaActiva++;
}                                                  

private void notaDespues() {                                                     
    insertarLineaNueva(lineaActiva, false);
}                                                    

private void lineaPrincipio() {                                                        
    insertarLineaNueva(0, true);
}                                                       

private void lineaFinal() {                                                    
    insertarLineaNueva(listaArticulos.size(), true);
}                                                   

private void lineaAntes() {                                                    
    insertarLineaNueva(lineaActiva - 1, true);
    lineaActiva++;
}                                                   

private void notaPrincipio() {                                                       
    insertarLineaNueva(0, false);
} 

//Si linea = true ==> se está insertando una linea de articulo
//Si linea = false ==> se está insertando una nota informativa
    private void insertarLineaNueva(int indice, boolean isLineaArticulo) {

        if (indice < 0) {
            indice = 0;
        } else if (indice > num_articulos) {
            indice = num_articulos;
        }

        //  Crear linea para ventas
        NuevaLineaCompra lip = new NuevaLineaCompra(this, indice, e, isLineaArticulo,u);
        panel.add(lip, indice);
        //panel.setVisible(true);
        panel.repaint();
        this.pack();
        Dimension dim = Util.getDimensiones(this.getSize());
        if(dim != null){
            setResizable(true);
            setSize(dim);
            setResizable(false);
        }
        num_articulos++;
        listaArticulos.add(indice, lip);
        cambiarCodigos();
        reCalcularLineasVacias();
    }

    public void setLineaActiva(int indice) {
        lineaActiva = indice;
    }

    private HashMap crearHashMapParametros() {
        
        FamiliaVenta fve;
        TipoControl tco;
        TipoMedida tme;
        double precio;
        HashMap parameters = new HashMap();

        parameters.put("e.cod_empresa", e.getCod_empresa());
        parameters.put("e.desc_empresa", e.getDesc_empresa());
        parameters.put("e.dire_empresa", e.getDire_empresa());
        parameters.put("e.pobla_empresa", e.getPobla_empresa());
        parameters.put("e.cp_empresa", e.getCp_empresa());
        parameters.put("tipoDocumento", cd.getDescripcion());

        parameters.put("c.codigo", this.tCodCliente.getText());
        parameters.put("c.dni", this.tDniCliente.getText());
        parameters.put("c.nombreComercial", this.tNombreCliente.getText());
        parameters.put("c.direccion", this.tDireccionCliente.getText());
        parameters.put("c.cp", this.tCpCliente.getText());
        parameters.put("c.poblacion", this.tLocalidadCliente.getText());
        parameters.put("c.provincia", this.tProvinciaCliente.getText());
        parameters.put("c.telefono", this.tTelefonoCliente.getText());

        parameters.put("logo", new ByteArrayInputStream(e.getImagen()));
        parameters.put("referencia", tReferencia.getText());
        parameters.put("numero", tnumero.getText());
        parameters.put("fecha", tfecha.getText());

        HashMap hashPrecio = new HashMap();
        hashPrecio.put("precio_bruto", lprecio.getText());
        hashPrecio.put("precio_final", lprecio_final.getText());
        hashPrecio.put("precio_iva", limporte_iva.getText());
        hashPrecio.put("iva", tIva.getText());

        parameters.put("hashPrecio", hashPrecio);
        parameters.put("precio_bruto", lprecio.getText());
        parameters.put("precio_final", lprecio_final.getText());
        parameters.put("precio_iva", limporte_iva.getText());

        List<LineaPresupuesto> listaProducto = new ArrayList<LineaPresupuesto>();
        NuevaLineaCompra nlip;
        Articulo arti;
        Iterator it = listaArticulos.iterator();
        LineaPresupuesto lip;
        while (it.hasNext()) {
            nlip = (NuevaLineaCompra) it.next();
            arti = nlip.getArticulo();
            if (arti != null) {
                lip = new LineaPresupuesto();
                lip.setArticulo_iid(arti);
                fve = BaseDatos.obtenerFamiliaVentaPorIid(nlip.getArticulo().getIid_fam_venta().getIid());
                tco = BaseDatos.obtenerTipoControlPorIid(fve.getIid_tipo_control().getIid());
                tme = BaseDatos.obtenerTipoMedidaByIid(tco.getIid_tipo_medida().getIid());
                lip.setNummedidas(tme.getNum_dimensiones());
                lip.setCodigo(nlip.getCodigo());
                lip.setPrecio(nlip.getPrecio());
                lip.setPresupuesto_iid(p);
                lip.setDescuento(nlip.getDescuento());
                lip.setCantidad(nlip.getCantidad());
                lip.setMedida1(nlip.getMedida1());
                lip.setMedida2(nlip.getMedida2());
                lip.setMedida3(nlip.getMedida3());
                lip.setMedida4(nlip.getMedida4());
                lip.setMedida5(nlip.getMedida5());
                lip.setMedidares(nlip.getMedidares());
                lip.setDescripcion(nlip.getDescripcion());
                lip.setImporte(nlip.getImporte());
                lip.setCantidadStr(Util.convertirPuntoAComa(String.valueOf((nlip.getCantidad()))));
                precio = ((100 - lip.getDescuento()) * nlip.getPrecio()) / 100;
                lip.setPrecioStr(Util.convertirPuntoAComa(String.valueOf(matematico.Matematico.redondear2decimales(precio))));
                lip.setImporteStr(Util.convertirPuntoAComa(String.valueOf((nlip.getImporte()))));
                listaProducto.add(lip);
            } else if (!nlip.isLineaArticulo() && nlip.getDescripcion() != null && !nlip.getDescripcion().equals("")) {
                lip = new LineaPresupuesto();
                lip.setDescripcion(nlip.getDescripcion());
                listaProducto.add(lip);
            }
        }
        parameters.put("lineaPresupuesto", new JRBeanCollectionDataSource(listaProducto));

        List<Objeto2Elementos> lista = fp2.getPlazos();
        parameters.put("formaPago", new JRBeanCollectionDataSource(lista));
        parameters.put("formaPagoStr", fp2.getCodigo());

        return parameters;
    }

    private void convertirDocumento(String tipo) {
        if (crear) {
            JOptionPane.showMessageDialog(null, "El " + tipo + " aún no ha sido guardado", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            int eliminar = JOptionPane.showConfirmDialog(null, "Está seguro de que desea convertir el " + cd.getDescripcion(), "¿Convertir?", JOptionPane.YES_NO_OPTION);
            //hacerCambios = -1 ==> se ha pulsado la "x" de cancelar;
            //hacerCambios =  0 ==> se ha pulsado el "sí"
            //hacerCambios =  1 ==> se ha pulsado el "no"
            if (eliminar == 0) {
                DatosConversion sa = new DatosConversion(p, "directo", this.e, this.u);
                sa.setDefaultCloseOperation(DatosConversion.DISPOSE_ON_CLOSE);
                sa.setLocationRelativeTo(null);
                sa.setVisible(true);
                cerrarPresupuesto();
            }
        }
    }

    private void cargarLineasPresupuesto() {
        mapaNuevoClaves = new HashMap<Integer, Integer>();
        List lps = BaseDatos.getListaLineaPresupuesto(p.getIid());
        LineaPresupuesto lip;
        Iterator it;
        for (it = lps.iterator(); it.hasNext();) {
            lip = (LineaPresupuesto) it.next();
            anadirLineaPresupuesto(lip);
        }
        anadirLineaPresupuesto();
    }

    protected void limpiarVencimientos() {
        Modelo m = (Modelo) tvencimientos.getModel();
        int i, j;

        j = m.getRowCount();
        for (i = 0; i < j; i++) {
            m.removeRow(0);
        }
    }

    protected void limpiarPlazosAdelantados() {
        Modelo m = (Modelo) tplazosadelantados.getModel();
        int i, j;

        j = m.getRowCount();
        for (i = 0; i < j; i++) {
            m.removeRow(0);
        }
    }

    protected void rellenarVencimientos() {
        if (fp2 != null) {
            Modelo modelovencimientos = (Modelo) tvencimientos.getModel();
            int num_vencimientos = fp2.getNumplazosvencimiento();

            if (num_vencimientos > 0) {
                if (num_vencimientos == 1) {
                    modelovencimientos.addRow(rellenarVencimiento1());
                } else if (num_vencimientos == 2) {
                    modelovencimientos.addRow(rellenarVencimiento1());
                    modelovencimientos.addRow(rellenarVencimiento2());
                } else if (num_vencimientos == 3) {
                    modelovencimientos.addRow(rellenarVencimiento1());
                    modelovencimientos.addRow(rellenarVencimiento2());
                    modelovencimientos.addRow(rellenarVencimiento3());
                } else if (num_vencimientos == 4) {
                    modelovencimientos.addRow(rellenarVencimiento1());
                    modelovencimientos.addRow(rellenarVencimiento2());
                    modelovencimientos.addRow(rellenarVencimiento3());
                    modelovencimientos.addRow(rellenarVencimiento4());
                } else if (num_vencimientos == 5) {
                    modelovencimientos.addRow(rellenarVencimiento1());
                    modelovencimientos.addRow(rellenarVencimiento2());
                    modelovencimientos.addRow(rellenarVencimiento3());
                    modelovencimientos.addRow(rellenarVencimiento4());
                    modelovencimientos.addRow(rellenarVencimiento5());
                } else if (num_vencimientos == 6) {
                    modelovencimientos.addRow(rellenarVencimiento1());
                    modelovencimientos.addRow(rellenarVencimiento2());
                    modelovencimientos.addRow(rellenarVencimiento3());
                    modelovencimientos.addRow(rellenarVencimiento4());
                    modelovencimientos.addRow(rellenarVencimiento5());
                    modelovencimientos.addRow(rellenarVencimiento6());
                } else if (num_vencimientos == 7) {
                    modelovencimientos.addRow(rellenarVencimiento1());
                    modelovencimientos.addRow(rellenarVencimiento2());
                    modelovencimientos.addRow(rellenarVencimiento3());
                    modelovencimientos.addRow(rellenarVencimiento4());
                    modelovencimientos.addRow(rellenarVencimiento5());
                    modelovencimientos.addRow(rellenarVencimiento6());
                    modelovencimientos.addRow(rellenarVencimiento7());
                } else if (num_vencimientos == 8) {
                    modelovencimientos.addRow(rellenarVencimiento1());
                    modelovencimientos.addRow(rellenarVencimiento2());
                    modelovencimientos.addRow(rellenarVencimiento3());
                    modelovencimientos.addRow(rellenarVencimiento4());
                    modelovencimientos.addRow(rellenarVencimiento5());
                    modelovencimientos.addRow(rellenarVencimiento6());
                    modelovencimientos.addRow(rellenarVencimiento7());
                    modelovencimientos.addRow(rellenarVencimiento8());
                } else if (num_vencimientos == 9) {
                    modelovencimientos.addRow(rellenarVencimiento1());
                    modelovencimientos.addRow(rellenarVencimiento2());
                    modelovencimientos.addRow(rellenarVencimiento3());
                    modelovencimientos.addRow(rellenarVencimiento4());
                    modelovencimientos.addRow(rellenarVencimiento5());
                    modelovencimientos.addRow(rellenarVencimiento6());
                    modelovencimientos.addRow(rellenarVencimiento7());
                    modelovencimientos.addRow(rellenarVencimiento8());
                    modelovencimientos.addRow(rellenarVencimiento9());
                } else {
                    modelovencimientos.addRow(rellenarVencimiento1());
                    modelovencimientos.addRow(rellenarVencimiento2());
                    modelovencimientos.addRow(rellenarVencimiento3());
                    modelovencimientos.addRow(rellenarVencimiento4());
                    modelovencimientos.addRow(rellenarVencimiento5());
                    modelovencimientos.addRow(rellenarVencimiento6());
                    modelovencimientos.addRow(rellenarVencimiento7());
                    modelovencimientos.addRow(rellenarVencimiento8());
                    modelovencimientos.addRow(rellenarVencimiento9());
                    modelovencimientos.addRow(rellenarVencimiento10());
                }
            }
        }
    }

    private String calcularFecha(int diasSumar, String tipoCalculo) {
        Date fechaV = null;
        Date fechaError = null;
        SimpleDateFormat formatoFecha = new SimpleDateFormat("dd/MM/yyyy");
        try {
            Date fechaP = null;
            if (tfecha.getText().equals("")) {
                fechaP = formatoFecha.parse("01/01/1900");
            } else {
                fechaP = formatoFecha.parse(tfecha.getText());
            }
            fechaError = formatoFecha.parse("01/01/1900");

            Agentes ag = BaseDatos.obtenerAgentesPorCodigo(tCodCliente.getText(), "", e);
            List<Integer> listaDiasOrdenada;
            if (ag != null) {
                listaDiasOrdenada = ag.ordenarDiasCobro();
            } else {
                listaDiasOrdenada = null;
            }


            if (diasSumar % 30 == 0 && fp2.getTipodecalculo().equals(Constantes.MESES_ENTEROS)) {
                Calendar c1 = Calendar.getInstance();
                c1.setTime(fechaP);
                c1.add(Calendar.MONTH, diasSumar / 30);

                if (listaDiasOrdenada != null && listaDiasOrdenada.get(0) != 32) {
                    if (c1.get(Calendar.DATE) <= listaDiasOrdenada.get(0)) {
                        c1.add(Calendar.DATE, listaDiasOrdenada.get(0) - c1.get(Calendar.DATE));
                    } else {
                        if (listaDiasOrdenada.get(1) != 32) {
                            if (listaDiasOrdenada.get(1) >= c1.get(Calendar.DATE)) {
                                c1.add(Calendar.DATE, listaDiasOrdenada.get(1) - c1.get(Calendar.DATE));
                            } else {
                                if (listaDiasOrdenada.get(2) != 32) {
                                    if (listaDiasOrdenada.get(2) >= c1.get(Calendar.DATE)) {
                                        c1.add(Calendar.DATE, listaDiasOrdenada.get(2) - c1.get(Calendar.DATE));
                                    } else {
                                        c1.set(Calendar.MONTH, c1.get(Calendar.MONTH) + 1);
                                        c1.set(Calendar.DATE, listaDiasOrdenada.get(0));
                                    }
                                } else {
                                    c1.set(Calendar.MONTH, c1.get(Calendar.MONTH) + 1);
                                    c1.set(Calendar.DATE, listaDiasOrdenada.get(0));
                                }
                            }
                        } else {
                            c1.set(Calendar.MONTH, c1.get(Calendar.MONTH) + 1);
                            c1.set(Calendar.DATE, listaDiasOrdenada.get(0));
                        }
                    }
                }
                fechaV = c1.getTime();
            } else {
                Calendar c1 = Calendar.getInstance();
                c1.setTime(fechaP);
                c1.add(Calendar.DATE, diasSumar);
                if (listaDiasOrdenada != null && listaDiasOrdenada.get(0) != 32) {
                    if (c1.get(Calendar.DATE) <= listaDiasOrdenada.get(0)) {
                        c1.add(Calendar.DATE, listaDiasOrdenada.get(0) - c1.get(Calendar.DATE));
                    } else {
                        if (listaDiasOrdenada.get(1) != 32) {
                            if (listaDiasOrdenada.get(1) >= c1.get(Calendar.DATE)) {
                                c1.add(Calendar.DATE, listaDiasOrdenada.get(1) - c1.get(Calendar.DATE));
                            } else {
                                if (listaDiasOrdenada.get(2) != 32) {
                                    if (listaDiasOrdenada.get(2) >= c1.get(Calendar.DATE)) {
                                        c1.add(Calendar.DATE, listaDiasOrdenada.get(2) - c1.get(Calendar.DATE));
                                    } else {
                                        c1.set(Calendar.MONTH, c1.get(Calendar.MONTH) + 1);
                                        c1.set(Calendar.DATE, listaDiasOrdenada.get(0));
                                    }
                                } else {
                                    c1.set(Calendar.MONTH, c1.get(Calendar.MONTH) + 1);
                                    c1.set(Calendar.DATE, listaDiasOrdenada.get(0));
                                }
                            }
                        } else {
                            c1.set(Calendar.MONTH, c1.get(Calendar.MONTH) + 1);
                            c1.set(Calendar.DATE, listaDiasOrdenada.get(0));
                        }
                    }
                }
                fechaV = c1.getTime();
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            fechaV = fechaError;
        }



        return formatoFecha.format(fechaV);
    }

    private Object[] rellenarVencimiento1() {
        Object[] fila1 = new Object[5];
        fila1[0] = fp2.getPlazovm1();
        fila1[1] = Util.convertirPuntoAComa(String.valueOf(matematico.Matematico.redondear2decimales(fp2.getPlazopm1())));
        fila1[2] = matematico.Matematico.redondear2decimales(precio_final * fp2.getPlazopm1() / 100);
        fp2.setImportev1((Double) fila1[2]);
        fila1[2] = Util.convertirPuntoAComa(String.valueOf(matematico.Matematico.redondear2decimales(precio_final * fp2.getPlazopm1() / 100)));
        fila1[3] = fp2.getIid_tr_v1().getDescripcion();
        fila1[4] = calcularFecha(fp2.getPlazovm1(), fp2.getTipodecalculo());
        return fila1;
    }

    private Object[] rellenarVencimiento2() {
        Object[] fila1 = new Object[5];
        fila1[0] = fp2.getPlazovm2();
        fila1[1] = Util.convertirPuntoAComa(String.valueOf(matematico.Matematico.redondear2decimales(fp2.getPlazopm2())));
        fila1[2] = matematico.Matematico.redondear2decimales(precio_final * fp2.getPlazopm2() / 100);
        fp2.setImportev2((Double) fila1[2]);
        fila1[2] = Util.convertirPuntoAComa(String.valueOf(matematico.Matematico.redondear2decimales(precio_final * fp2.getPlazopm2() / 100)));
        fila1[3] = fp2.getIid_tr_v2().getDescripcion();
        fila1[4] = calcularFecha(fp2.getPlazovm2(), fp2.getTipodecalculo());
        return fila1;
    }

    private Object[] rellenarVencimiento3() {
        Object[] fila1 = new Object[5];
        fila1[0] = fp2.getPlazovm3();
        fila1[1] = Util.convertirPuntoAComa(String.valueOf(matematico.Matematico.redondear2decimales(fp2.getPlazopm3())));
        fila1[2] = matematico.Matematico.redondear2decimales(precio_final * fp2.getPlazopm3() / 100);
        fp2.setImportev3((Double) fila1[2]);
        fila1[2] = Util.convertirPuntoAComa(String.valueOf(matematico.Matematico.redondear2decimales(precio_final * fp2.getPlazopm3() / 100)));
        fila1[3] = fp2.getIid_tr_v3().getDescripcion();
        fila1[4] = calcularFecha(fp2.getPlazovm3(), fp2.getTipodecalculo());
        return fila1;
    }

    private Object[] rellenarVencimiento4() {
        Object[] fila1 = new Object[5];
        fila1[0] = fp2.getPlazovm4();
        fila1[1] = Util.convertirPuntoAComa(String.valueOf(matematico.Matematico.redondear2decimales(fp2.getPlazopm4())));
        fila1[2] = matematico.Matematico.redondear2decimales(precio_final * fp2.getPlazopm4() / 100);
        fp2.setImportev4((Double) fila1[2]);
        fila1[2] = Util.convertirPuntoAComa(String.valueOf(matematico.Matematico.redondear2decimales(precio_final * fp2.getPlazopm4() / 100)));
        fila1[3] = fp2.getIid_tr_v4().getDescripcion();
        fila1[4] = calcularFecha(fp2.getPlazovm4(), fp2.getTipodecalculo());
        return fila1;
    }

    private Object[] rellenarVencimiento5() {
        Object[] fila1 = new Object[5];
        fila1[0] = fp2.getPlazovm5();
        fila1[1] = Util.convertirPuntoAComa(String.valueOf(matematico.Matematico.redondear2decimales(fp2.getPlazopm5())));
        fila1[2] = matematico.Matematico.redondear2decimales(precio_final * fp2.getPlazopm5() / 100);
        fp2.setImportev5((Double) fila1[2]);
        fila1[2] = Util.convertirPuntoAComa(String.valueOf(matematico.Matematico.redondear2decimales(precio_final * fp2.getPlazopm5() / 100)));
        fila1[3] = fp2.getIid_tr_v5().getDescripcion();
        fila1[4] = calcularFecha(fp2.getPlazovm5(), fp2.getTipodecalculo());
        return fila1;
    }

    private Object[] rellenarVencimiento6() {
        Object[] fila1 = new Object[5];
        fila1[0] = fp2.getPlazovm6();
        fila1[1] = Util.convertirPuntoAComa(String.valueOf(matematico.Matematico.redondear2decimales(fp2.getPlazopm6())));
        fila1[2] = matematico.Matematico.redondear2decimales(precio_final * fp2.getPlazopm6() / 100);
        fp2.setImportev6((Double) fila1[2]);
        fila1[2] = Util.convertirPuntoAComa(String.valueOf(matematico.Matematico.redondear2decimales(precio_final * fp2.getPlazopm6() / 100)));
        fila1[3] = fp2.getIid_tr_v6().getDescripcion();
        fila1[4] = calcularFecha(fp2.getPlazovm6(), fp2.getTipodecalculo());
        return fila1;
    }

    private Object[] rellenarVencimiento7() {
        Object[] fila1 = new Object[5];
        fila1[0] = fp2.getPlazovm7();
        fila1[1] = Util.convertirPuntoAComa(String.valueOf(matematico.Matematico.redondear2decimales(fp2.getPlazopm7())));
        fila1[2] = matematico.Matematico.redondear2decimales(precio_final * fp2.getPlazopm7() / 100);
        fp2.setImportev7((Double) fila1[2]);
        fila1[2] = Util.convertirPuntoAComa(String.valueOf(matematico.Matematico.redondear2decimales(precio_final * fp2.getPlazopm7() / 100)));
        fila1[3] = fp2.getIid_tr_v7().getDescripcion();
        fila1[4] = calcularFecha(fp2.getPlazovm7(), fp2.getTipodecalculo());
        return fila1;
    }

    private Object[] rellenarVencimiento8() {
        Object[] fila1 = new Object[5];
        fila1[0] = fp2.getPlazovm8();
        fila1[1] = Util.convertirPuntoAComa(String.valueOf(matematico.Matematico.redondear2decimales(fp2.getPlazopm8())));
        fila1[2] = matematico.Matematico.redondear2decimales(precio_final * fp2.getPlazopm8() / 100);
        fp2.setImportev8((Double) fila1[2]);
        fila1[2] = Util.convertirPuntoAComa(String.valueOf(matematico.Matematico.redondear2decimales(precio_final * fp2.getPlazopm8() / 100)));
        fila1[3] = fp2.getIid_tr_v8().getDescripcion();
        fila1[4] = calcularFecha(fp2.getPlazovm8(), fp2.getTipodecalculo());
        return fila1;
    }

    private Object[] rellenarVencimiento9() {
        Object[] fila1 = new Object[5];
        fila1[0] = fp2.getPlazovm9();
        fila1[1] = Util.convertirPuntoAComa(String.valueOf(matematico.Matematico.redondear2decimales(fp2.getPlazopm9())));
        fila1[2] = matematico.Matematico.redondear2decimales(precio_final * fp2.getPlazopm9() / 100);
        fp2.setImportev9((Double) fila1[2]);
        fila1[2] = Util.convertirPuntoAComa(String.valueOf(matematico.Matematico.redondear2decimales(precio_final * fp2.getPlazopm9() / 100)));
        fila1[3] = fp2.getIid_tr_v9().getDescripcion();
        fila1[4] = calcularFecha(fp2.getPlazovm9(), fp2.getTipodecalculo());
        return fila1;
    }

    private Object[] rellenarVencimiento10() {
        Object[] fila1 = new Object[5];
        fila1[0] = fp2.getPlazovm10();
        fila1[1] = Util.convertirPuntoAComa(String.valueOf(matematico.Matematico.redondear2decimales(fp2.getPlazopm10())));
        fila1[2] = matematico.Matematico.redondear2decimales(precio_final * fp2.getPlazopm10() / 100);
        fp2.setImportev10((Double) fila1[2]);
        fila1[2] = Util.convertirPuntoAComa(String.valueOf(matematico.Matematico.redondear2decimales(precio_final * fp2.getPlazopm10() / 100)));
        fila1[3] = fp2.getIid_tr_v10().getDescripcion();
        fila1[4] = calcularFecha(fp2.getPlazovm10(), fp2.getTipodecalculo());
        return fila1;
    }

    protected void rellenarPlazosAdelantados() {
        if (fp2 != null) {
            Modelo modeloplazosadelantados = (Modelo) tplazosadelantados.getModel();
            int num_plazos_adelantados = fp2.getNumplazosadelantados();

            if (num_plazos_adelantados > 0) {
                if (num_plazos_adelantados == 1) {
                    modeloplazosadelantados.addRow(rellenarPlazoAdelantado1());
                } else if (num_plazos_adelantados == 2) {
                    modeloplazosadelantados.addRow(rellenarPlazoAdelantado1());
                    modeloplazosadelantados.addRow(rellenarPlazoAdelantado2());
                } else if (num_plazos_adelantados == 3) {
                    modeloplazosadelantados.addRow(rellenarPlazoAdelantado1());
                    modeloplazosadelantados.addRow(rellenarPlazoAdelantado2());
                    modeloplazosadelantados.addRow(rellenarPlazoAdelantado3());
                } else if (num_plazos_adelantados == 4) {
                    modeloplazosadelantados.addRow(rellenarPlazoAdelantado1());
                    modeloplazosadelantados.addRow(rellenarPlazoAdelantado2());
                    modeloplazosadelantados.addRow(rellenarPlazoAdelantado3());
                    modeloplazosadelantados.addRow(rellenarPlazoAdelantado4());
                } else if (num_plazos_adelantados == 5) {
                    modeloplazosadelantados.addRow(rellenarPlazoAdelantado1());
                    modeloplazosadelantados.addRow(rellenarPlazoAdelantado2());
                    modeloplazosadelantados.addRow(rellenarPlazoAdelantado3());
                    modeloplazosadelantados.addRow(rellenarPlazoAdelantado4());
                    modeloplazosadelantados.addRow(rellenarPlazoAdelantado5());
                } else if (num_plazos_adelantados == 6) {
                    modeloplazosadelantados.addRow(rellenarPlazoAdelantado1());
                    modeloplazosadelantados.addRow(rellenarPlazoAdelantado2());
                    modeloplazosadelantados.addRow(rellenarPlazoAdelantado3());
                    modeloplazosadelantados.addRow(rellenarPlazoAdelantado4());
                    modeloplazosadelantados.addRow(rellenarPlazoAdelantado5());
                    modeloplazosadelantados.addRow(rellenarPlazoAdelantado6());
                } else if (num_plazos_adelantados == 7) {
                    modeloplazosadelantados.addRow(rellenarPlazoAdelantado1());
                    modeloplazosadelantados.addRow(rellenarPlazoAdelantado2());
                    modeloplazosadelantados.addRow(rellenarPlazoAdelantado3());
                    modeloplazosadelantados.addRow(rellenarPlazoAdelantado4());
                    modeloplazosadelantados.addRow(rellenarPlazoAdelantado5());
                    modeloplazosadelantados.addRow(rellenarPlazoAdelantado6());
                    modeloplazosadelantados.addRow(rellenarPlazoAdelantado7());
                } else if (num_plazos_adelantados == 8) {
                    modeloplazosadelantados.addRow(rellenarPlazoAdelantado1());
                    modeloplazosadelantados.addRow(rellenarPlazoAdelantado2());
                    modeloplazosadelantados.addRow(rellenarPlazoAdelantado3());
                    modeloplazosadelantados.addRow(rellenarPlazoAdelantado4());
                    modeloplazosadelantados.addRow(rellenarPlazoAdelantado5());
                    modeloplazosadelantados.addRow(rellenarPlazoAdelantado6());
                    modeloplazosadelantados.addRow(rellenarPlazoAdelantado7());
                    modeloplazosadelantados.addRow(rellenarPlazoAdelantado8());
                } else if (num_plazos_adelantados == 9) {
                    modeloplazosadelantados.addRow(rellenarPlazoAdelantado1());
                    modeloplazosadelantados.addRow(rellenarPlazoAdelantado2());
                    modeloplazosadelantados.addRow(rellenarPlazoAdelantado3());
                    modeloplazosadelantados.addRow(rellenarPlazoAdelantado4());
                    modeloplazosadelantados.addRow(rellenarPlazoAdelantado5());
                    modeloplazosadelantados.addRow(rellenarPlazoAdelantado6());
                    modeloplazosadelantados.addRow(rellenarPlazoAdelantado7());
                    modeloplazosadelantados.addRow(rellenarPlazoAdelantado8());
                    modeloplazosadelantados.addRow(rellenarPlazoAdelantado9());
                } else {
                    modeloplazosadelantados.addRow(rellenarPlazoAdelantado1());
                    modeloplazosadelantados.addRow(rellenarPlazoAdelantado2());
                    modeloplazosadelantados.addRow(rellenarPlazoAdelantado3());
                    modeloplazosadelantados.addRow(rellenarPlazoAdelantado4());
                    modeloplazosadelantados.addRow(rellenarPlazoAdelantado5());
                    modeloplazosadelantados.addRow(rellenarPlazoAdelantado6());
                    modeloplazosadelantados.addRow(rellenarPlazoAdelantado7());
                    modeloplazosadelantados.addRow(rellenarPlazoAdelantado8());
                    modeloplazosadelantados.addRow(rellenarPlazoAdelantado9());
                    modeloplazosadelantados.addRow(rellenarPlazoAdelantado10());
                }
            }
        }
    }

    private Object[] rellenarPlazoAdelantado1() {
        Object[] fila1 = new Object[5];
        fila1[0] = fp2.getNombreplazo1();
        fila1[1] = Util.convertirPuntoAComa(String.valueOf(fp2.getPorcentajepago1()));
        fila1[2] = matematico.Matematico.redondear2decimales(precio_final * fp2.getPorcentajepago1() / 100);
        fp2.setImportep1((Double) fila1[2]);
        fila1[2] = Util.convertirPuntoAComa(String.valueOf(matematico.Matematico.redondear2decimales(precio_final * fp2.getPorcentajepago1() / 100)));
        fila1[3] = fp2.getIid_tr_p1().getDescripcion();
        fila1[4] = fp2.getCobrado1();
        return fila1;
    }

    private Object[] rellenarPlazoAdelantado2() {
        Object[] fila1 = new Object[5];
        fila1[0] = fp2.getNombreplazo2();
        fila1[1] = Util.convertirPuntoAComa(String.valueOf(fp2.getPorcentajepago2()));
        fila1[2] = matematico.Matematico.redondear2decimales(precio_final * fp2.getPorcentajepago2() / 100);
        fp2.setImportep2((Double) fila1[2]);
        fila1[2] = Util.convertirPuntoAComa(String.valueOf(matematico.Matematico.redondear2decimales(precio_final * fp2.getPorcentajepago2() / 100)));
        fila1[3] = fp2.getIid_tr_p2().getDescripcion();
        fila1[4] = fp2.getCobrado2();
        return fila1;
    }

    private Object[] rellenarPlazoAdelantado3() {
        Object[] fila1 = new Object[5];
        fila1[0] = fp2.getNombreplazo3();
        fila1[1] = Util.convertirPuntoAComa(String.valueOf(fp2.getPorcentajepago3()));
        fila1[2] = matematico.Matematico.redondear2decimales(precio_final * fp2.getPorcentajepago3() / 100);
        fp2.setImportep3((Double) fila1[2]);
        fila1[2] = Util.convertirPuntoAComa(String.valueOf(matematico.Matematico.redondear2decimales(precio_final * fp2.getPorcentajepago3() / 100)));
        fila1[3] = fp2.getIid_tr_p3().getDescripcion();
        fila1[4] = fp2.getCobrado3();
        return fila1;
    }

    private Object[] rellenarPlazoAdelantado4() {
        Object[] fila1 = new Object[5];
        fila1[0] = fp2.getNombreplazo4();
        fila1[1] = Util.convertirPuntoAComa(String.valueOf(fp2.getPorcentajepago4()));
        fila1[2] = matematico.Matematico.redondear2decimales(precio_final * fp2.getPorcentajepago4() / 100);
        fp2.setImportep4((Double) fila1[2]);
        fila1[2] = Util.convertirPuntoAComa(String.valueOf(matematico.Matematico.redondear2decimales(precio_final * fp2.getPorcentajepago4() / 100)));
        fila1[3] = fp2.getIid_tr_p4().getDescripcion();
        fila1[4] = fp2.getCobrado4();
        return fila1;
    }

    private Object[] rellenarPlazoAdelantado5() {
        Object[] fila1 = new Object[5];
        fila1[0] = fp2.getNombreplazo5();
        fila1[1] = Util.convertirPuntoAComa(String.valueOf(fp2.getPorcentajepago5()));
        fila1[2] = matematico.Matematico.redondear2decimales(precio_final * fp2.getPorcentajepago5() / 100);
        fp2.setImportep5((Double) fila1[2]);
        fila1[2] = Util.convertirPuntoAComa(String.valueOf(matematico.Matematico.redondear2decimales(precio_final * fp2.getPorcentajepago5() / 100)));
        fila1[3] = fp2.getIid_tr_p5().getDescripcion();
        fila1[4] = fp2.getCobrado5();
        return fila1;
    }

    private Object[] rellenarPlazoAdelantado6() {
        Object[] fila1 = new Object[5];
        fila1[0] = fp2.getNombreplazo6();
        fila1[1] = Util.convertirPuntoAComa(String.valueOf(fp2.getPorcentajepago6()));
        fila1[2] = matematico.Matematico.redondear2decimales(precio_final * fp2.getPorcentajepago6() / 100);
        fp2.setImportep6((Double) fila1[2]);
        fila1[2] = Util.convertirPuntoAComa(String.valueOf(matematico.Matematico.redondear2decimales(precio_final * fp2.getPorcentajepago6() / 100)));
        fila1[3] = fp2.getIid_tr_p6().getDescripcion();
        fila1[4] = fp2.getCobrado6();
        return fila1;
    }

    private Object[] rellenarPlazoAdelantado7() {
        Object[] fila1 = new Object[5];
        fila1[0] = fp2.getNombreplazo7();
        fila1[1] = Util.convertirPuntoAComa(String.valueOf(fp2.getPorcentajepago7()));
        fila1[2] = matematico.Matematico.redondear2decimales(precio_final * fp2.getPorcentajepago7() / 100);
        fp2.setImportep7((Double) fila1[2]);
        fila1[2] = Util.convertirPuntoAComa(String.valueOf(matematico.Matematico.redondear2decimales(precio_final * fp2.getPorcentajepago7() / 100)));
        fila1[3] = fp2.getIid_tr_p7().getDescripcion();
        fila1[4] = fp2.getCobrado7();
        return fila1;
    }

    private Object[] rellenarPlazoAdelantado8() {
        Object[] fila1 = new Object[5];
        fila1[0] = fp2.getNombreplazo8();
        fila1[1] = Util.convertirPuntoAComa(String.valueOf(fp2.getPorcentajepago8()));
        fila1[2] = matematico.Matematico.redondear2decimales(precio_final * fp2.getPorcentajepago8() / 100);
        fp2.setImportep8((Double) fila1[2]);
        fila1[2] = Util.convertirPuntoAComa(String.valueOf(matematico.Matematico.redondear2decimales(precio_final * fp2.getPorcentajepago8() / 100)));
        fila1[3] = fp2.getIid_tr_p8().getDescripcion();
        fila1[4] = fp2.getCobrado8();
        return fila1;
    }

    private Object[] rellenarPlazoAdelantado9() {
        Object[] fila1 = new Object[5];
        fila1[0] = fp2.getNombreplazo9();
        fila1[1] = Util.convertirPuntoAComa(String.valueOf(fp2.getPorcentajepago9()));
        fila1[2] = matematico.Matematico.redondear2decimales(precio_final * fp2.getPorcentajepago9() / 100);
        fp2.setImportep9((Double) fila1[2]);
        fila1[2] = Util.convertirPuntoAComa(String.valueOf(matematico.Matematico.redondear2decimales(precio_final * fp2.getPorcentajepago9() / 100)));
        fila1[3] = fp2.getIid_tr_p9().getDescripcion();
        fila1[4] = fp2.getCobrado9();
        return fila1 = new Object[5];
    }

    private Object[] rellenarPlazoAdelantado10() {
        Object[] fila1 = new Object[5];
        fila1[0] = fp2.getNombreplazo10();
        fila1[1] = Util.convertirPuntoAComa(String.valueOf(fp2.getPorcentajepago10()));
        fila1[2] = matematico.Matematico.redondear2decimales(precio_final * fp2.getPorcentajepago10() / 100);
        fp2.setImportep10((Double) fila1[2]);
        fila1[2] = Util.convertirPuntoAComa(String.valueOf(matematico.Matematico.redondear2decimales(precio_final * fp2.getPorcentajepago10() / 100)));
        fila1[3] = fp2.getIid_tr_p10().getDescripcion();
        fila1[4] = fp2.getCobrado10();
        return fila1;
    }

    protected void disminuirVencimientos(double porc) {
        double disminuir = matematico.Matematico.redondear2decimales(porc / fp2.getNumplazosvencimiento());
        int numPlazosVencimientos = fp2.getNumplazosvencimiento();

        if (numPlazosVencimientos == 1) {
            fp2.setPlazopm1(matematico.Matematico.redondear2decimales(fp2.getPlazopm1() - disminuir));
        } else if (numPlazosVencimientos == 2) {
            fp2.setPlazopm1(matematico.Matematico.redondear2decimales(fp2.getPlazopm1() - disminuir));
            fp2.setPlazopm2(matematico.Matematico.redondear2decimales(fp2.getPlazopm2() - porc + disminuir));
        } else if (numPlazosVencimientos == 3) {
            fp2.setPlazopm1(matematico.Matematico.redondear2decimales(fp2.getPlazopm1() - disminuir));
            fp2.setPlazopm2(matematico.Matematico.redondear2decimales(fp2.getPlazopm2() - disminuir));
            fp2.setPlazopm3(matematico.Matematico.redondear2decimales(fp2.getPlazopm3() - porc + disminuir + disminuir));
        } else if (numPlazosVencimientos == 4) {
            fp2.setPlazopm1(matematico.Matematico.redondear2decimales(fp2.getPlazopm1() - disminuir));
            fp2.setPlazopm2(matematico.Matematico.redondear2decimales(fp2.getPlazopm2() - disminuir));
            fp2.setPlazopm3(matematico.Matematico.redondear2decimales(fp2.getPlazopm3() - disminuir));
            fp2.setPlazopm4(matematico.Matematico.redondear2decimales(fp2.getPlazopm4() - porc + disminuir + disminuir + disminuir));
        } else if (numPlazosVencimientos == 5) {
            fp2.setPlazopm1(matematico.Matematico.redondear2decimales(fp2.getPlazopm1() - disminuir));
            fp2.setPlazopm2(matematico.Matematico.redondear2decimales(fp2.getPlazopm2() - disminuir));
            fp2.setPlazopm3(matematico.Matematico.redondear2decimales(fp2.getPlazopm3() - disminuir));
            fp2.setPlazopm4(matematico.Matematico.redondear2decimales(fp2.getPlazopm4() - disminuir));
            fp2.setPlazopm5(matematico.Matematico.redondear2decimales(fp2.getPlazopm5() - porc + disminuir + disminuir + disminuir + disminuir));
        } else if (numPlazosVencimientos == 6) {
            fp2.setPlazopm1(matematico.Matematico.redondear2decimales(fp2.getPlazopm1() - disminuir));
            fp2.setPlazopm2(matematico.Matematico.redondear2decimales(fp2.getPlazopm2() - disminuir));
            fp2.setPlazopm3(matematico.Matematico.redondear2decimales(fp2.getPlazopm3() - disminuir));
            fp2.setPlazopm4(matematico.Matematico.redondear2decimales(fp2.getPlazopm4() - disminuir));
            fp2.setPlazopm5(matematico.Matematico.redondear2decimales(fp2.getPlazopm5() - disminuir));
            fp2.setPlazopm6(matematico.Matematico.redondear2decimales(fp2.getPlazopm6() - porc + disminuir + disminuir + disminuir + disminuir + disminuir));
        } else if (numPlazosVencimientos == 7) {
            fp2.setPlazopm1(matematico.Matematico.redondear2decimales(fp2.getPlazopm1() - disminuir));
            fp2.setPlazopm2(matematico.Matematico.redondear2decimales(fp2.getPlazopm2() - disminuir));
            fp2.setPlazopm3(matematico.Matematico.redondear2decimales(fp2.getPlazopm3() - disminuir));
            fp2.setPlazopm4(matematico.Matematico.redondear2decimales(fp2.getPlazopm4() - disminuir));
            fp2.setPlazopm5(matematico.Matematico.redondear2decimales(fp2.getPlazopm5() - disminuir));
            fp2.setPlazopm6(matematico.Matematico.redondear2decimales(fp2.getPlazopm6() - disminuir));
            fp2.setPlazopm6(matematico.Matematico.redondear2decimales(fp2.getPlazopm7() - porc + disminuir + disminuir + disminuir + disminuir + disminuir + disminuir));
        } else if (numPlazosVencimientos == 8) {
            fp2.setPlazopm1(matematico.Matematico.redondear2decimales(fp2.getPlazopm1() - disminuir));
            fp2.setPlazopm2(matematico.Matematico.redondear2decimales(fp2.getPlazopm2() - disminuir));
            fp2.setPlazopm3(matematico.Matematico.redondear2decimales(fp2.getPlazopm3() - disminuir));
            fp2.setPlazopm4(matematico.Matematico.redondear2decimales(fp2.getPlazopm4() - disminuir));
            fp2.setPlazopm5(matematico.Matematico.redondear2decimales(fp2.getPlazopm5() - disminuir));
            fp2.setPlazopm6(matematico.Matematico.redondear2decimales(fp2.getPlazopm6() - disminuir));
            fp2.setPlazopm7(matematico.Matematico.redondear2decimales(fp2.getPlazopm7() - disminuir));
            fp2.setPlazopm6(matematico.Matematico.redondear2decimales(fp2.getPlazopm8() - porc + disminuir + disminuir + disminuir + disminuir + disminuir + disminuir + disminuir));
        } else if (numPlazosVencimientos == 9) {
            fp2.setPlazopm1(matematico.Matematico.redondear2decimales(fp2.getPlazopm1() - disminuir));
            fp2.setPlazopm2(matematico.Matematico.redondear2decimales(fp2.getPlazopm2() - disminuir));
            fp2.setPlazopm3(matematico.Matematico.redondear2decimales(fp2.getPlazopm3() - disminuir));
            fp2.setPlazopm4(matematico.Matematico.redondear2decimales(fp2.getPlazopm4() - disminuir));
            fp2.setPlazopm5(matematico.Matematico.redondear2decimales(fp2.getPlazopm5() - disminuir));
            fp2.setPlazopm6(matematico.Matematico.redondear2decimales(fp2.getPlazopm6() - disminuir));
            fp2.setPlazopm7(matematico.Matematico.redondear2decimales(fp2.getPlazopm7() - disminuir));
            fp2.setPlazopm8(matematico.Matematico.redondear2decimales(fp2.getPlazopm8() - disminuir));
            fp2.setPlazopm6(matematico.Matematico.redondear2decimales(fp2.getPlazopm9() - porc + disminuir + disminuir + disminuir + disminuir + disminuir + disminuir + disminuir + disminuir));
        } else if (numPlazosVencimientos == 10) {
            fp2.setPlazopm1(matematico.Matematico.redondear2decimales(fp2.getPlazopm1() - disminuir));
            fp2.setPlazopm2(matematico.Matematico.redondear2decimales(fp2.getPlazopm2() - disminuir));
            fp2.setPlazopm3(matematico.Matematico.redondear2decimales(fp2.getPlazopm3() - disminuir));
            fp2.setPlazopm4(matematico.Matematico.redondear2decimales(fp2.getPlazopm4() - disminuir));
            fp2.setPlazopm5(matematico.Matematico.redondear2decimales(fp2.getPlazopm5() - disminuir));
            fp2.setPlazopm6(matematico.Matematico.redondear2decimales(fp2.getPlazopm6() - disminuir));
            fp2.setPlazopm7(matematico.Matematico.redondear2decimales(fp2.getPlazopm7() - disminuir));
            fp2.setPlazopm8(matematico.Matematico.redondear2decimales(fp2.getPlazopm8() - disminuir));
            fp2.setPlazopm9(matematico.Matematico.redondear2decimales(fp2.getPlazopm9() - disminuir));
            fp2.setPlazopm6(matematico.Matematico.redondear2decimales(fp2.getPlazopm10() - porc + disminuir + disminuir + disminuir + disminuir + disminuir + disminuir + disminuir + disminuir + disminuir));
        }
    }

    protected void disminuirVencimientos(double porcentaje, double importe) {
        double disminuirPorcentaje = matematico.Matematico.redondear2decimales(porcentaje / fp2.getNumplazosvencimiento());
        double disminuirImporte = matematico.Matematico.redondear2decimales(importe / fp2.getNumplazosvencimiento());
        int numPlazosVencimientos = fp2.getNumplazosvencimiento();

        if (numPlazosVencimientos == 1) {
            fp2.setPlazopm1(matematico.Matematico.redondear2decimales(fp2.getPlazopm1() - disminuirPorcentaje));
            fp2.setImportev1(matematico.Matematico.redondear2decimales(fp2.getImportev1() - disminuirImporte));
        } else if (numPlazosVencimientos == 2) {
            fp2.setPlazopm1(matematico.Matematico.redondear2decimales(fp2.getPlazopm1() - disminuirPorcentaje));
            fp2.setPlazopm2(matematico.Matematico.redondear2decimales(fp2.getPlazopm2() - porcentaje + disminuirPorcentaje));

            fp2.setImportev1(matematico.Matematico.redondear2decimales(fp2.getImportev1() - disminuirImporte));
            fp2.setImportev2(matematico.Matematico.redondear2decimales(fp2.getImportev2() - importe + disminuirImporte));
        } else if (numPlazosVencimientos == 3) {
            fp2.setPlazopm1(matematico.Matematico.redondear2decimales(fp2.getPlazopm1() - disminuirPorcentaje));
            fp2.setPlazopm2(matematico.Matematico.redondear2decimales(fp2.getPlazopm2() - disminuirPorcentaje));
            fp2.setPlazopm3(matematico.Matematico.redondear2decimales(fp2.getPlazopm3() - porcentaje + disminuirPorcentaje + disminuirPorcentaje));

            fp2.setImportev1(matematico.Matematico.redondear2decimales(fp2.getImportev1() - disminuirImporte));
            fp2.setImportev2(matematico.Matematico.redondear2decimales(fp2.getImportev2() - disminuirImporte));
            fp2.setImportev3(matematico.Matematico.redondear2decimales(fp2.getImportev3() - importe + disminuirImporte + disminuirImporte));
        } else if (numPlazosVencimientos == 4) {
            fp2.setPlazopm1(matematico.Matematico.redondear2decimales(fp2.getPlazopm1() - disminuirPorcentaje));
            fp2.setPlazopm2(matematico.Matematico.redondear2decimales(fp2.getPlazopm2() - disminuirPorcentaje));
            fp2.setPlazopm3(matematico.Matematico.redondear2decimales(fp2.getPlazopm3() - disminuirPorcentaje));
            fp2.setPlazopm4(matematico.Matematico.redondear2decimales(fp2.getPlazopm4() - porcentaje + disminuirPorcentaje + disminuirPorcentaje + disminuirPorcentaje));

            fp2.setImportev1(matematico.Matematico.redondear2decimales(fp2.getImportev1() - disminuirImporte));
            fp2.setImportev2(matematico.Matematico.redondear2decimales(fp2.getImportev2() - disminuirImporte));
            fp2.setImportev3(matematico.Matematico.redondear2decimales(fp2.getImportev3() - disminuirImporte));
            fp2.setImportev4(matematico.Matematico.redondear2decimales(fp2.getImportev4() - importe + disminuirImporte + disminuirImporte + disminuirImporte));
        } else if (numPlazosVencimientos == 5) {
            fp2.setPlazopm1(matematico.Matematico.redondear2decimales(fp2.getPlazopm1() - disminuirPorcentaje));
            fp2.setPlazopm2(matematico.Matematico.redondear2decimales(fp2.getPlazopm2() - disminuirPorcentaje));
            fp2.setPlazopm3(matematico.Matematico.redondear2decimales(fp2.getPlazopm3() - disminuirPorcentaje));
            fp2.setPlazopm4(matematico.Matematico.redondear2decimales(fp2.getPlazopm4() - disminuirPorcentaje));
            fp2.setPlazopm5(matematico.Matematico.redondear2decimales(fp2.getPlazopm5() - porcentaje + disminuirPorcentaje + disminuirPorcentaje + disminuirPorcentaje + disminuirPorcentaje));

            fp2.setImportev1(matematico.Matematico.redondear2decimales(fp2.getImportev1() - disminuirImporte));
            fp2.setImportev2(matematico.Matematico.redondear2decimales(fp2.getImportev2() - disminuirImporte));
            fp2.setImportev3(matematico.Matematico.redondear2decimales(fp2.getImportev3() - disminuirImporte));
            fp2.setImportev4(matematico.Matematico.redondear2decimales(fp2.getImportev4() - disminuirImporte));
            fp2.setImportev5(matematico.Matematico.redondear2decimales(fp2.getImportev5() - importe + disminuirImporte + disminuirImporte + disminuirImporte + disminuirImporte));
        } else if (numPlazosVencimientos == 6) {
            fp2.setPlazopm1(matematico.Matematico.redondear2decimales(fp2.getPlazopm1() - disminuirPorcentaje));
            fp2.setPlazopm2(matematico.Matematico.redondear2decimales(fp2.getPlazopm2() - disminuirPorcentaje));
            fp2.setPlazopm3(matematico.Matematico.redondear2decimales(fp2.getPlazopm3() - disminuirPorcentaje));
            fp2.setPlazopm4(matematico.Matematico.redondear2decimales(fp2.getPlazopm4() - disminuirPorcentaje));
            fp2.setPlazopm5(matematico.Matematico.redondear2decimales(fp2.getPlazopm5() - disminuirPorcentaje));
            fp2.setPlazopm6(matematico.Matematico.redondear2decimales(fp2.getPlazopm6() - porcentaje + disminuirPorcentaje + disminuirPorcentaje + disminuirPorcentaje + disminuirPorcentaje + disminuirPorcentaje));

            fp2.setImportev1(matematico.Matematico.redondear2decimales(fp2.getImportev1() - disminuirImporte));
            fp2.setImportev2(matematico.Matematico.redondear2decimales(fp2.getImportev2() - disminuirImporte));
            fp2.setImportev3(matematico.Matematico.redondear2decimales(fp2.getImportev3() - disminuirImporte));
            fp2.setImportev4(matematico.Matematico.redondear2decimales(fp2.getImportev4() - disminuirImporte));
            fp2.setImportev5(matematico.Matematico.redondear2decimales(fp2.getImportev5() - disminuirImporte));
            fp2.setImportev6(matematico.Matematico.redondear2decimales(fp2.getImportev6() - importe + disminuirImporte + disminuirImporte + disminuirImporte + disminuirImporte + disminuirImporte));
        } else if (numPlazosVencimientos == 7) {
            fp2.setPlazopm1(matematico.Matematico.redondear2decimales(fp2.getPlazopm1() - disminuirPorcentaje));
            fp2.setPlazopm2(matematico.Matematico.redondear2decimales(fp2.getPlazopm2() - disminuirPorcentaje));
            fp2.setPlazopm3(matematico.Matematico.redondear2decimales(fp2.getPlazopm3() - disminuirPorcentaje));
            fp2.setPlazopm4(matematico.Matematico.redondear2decimales(fp2.getPlazopm4() - disminuirPorcentaje));
            fp2.setPlazopm5(matematico.Matematico.redondear2decimales(fp2.getPlazopm5() - disminuirPorcentaje));
            fp2.setPlazopm6(matematico.Matematico.redondear2decimales(fp2.getPlazopm6() - disminuirPorcentaje));
            fp2.setPlazopm6(matematico.Matematico.redondear2decimales(fp2.getPlazopm7() - porcentaje + disminuirPorcentaje + disminuirPorcentaje + disminuirPorcentaje + disminuirPorcentaje + disminuirPorcentaje + disminuirPorcentaje));

            fp2.setImportev1(matematico.Matematico.redondear2decimales(fp2.getImportev1() - disminuirImporte));
            fp2.setImportev2(matematico.Matematico.redondear2decimales(fp2.getImportev2() - disminuirImporte));
            fp2.setImportev3(matematico.Matematico.redondear2decimales(fp2.getImportev3() - disminuirImporte));
            fp2.setImportev4(matematico.Matematico.redondear2decimales(fp2.getImportev4() - disminuirImporte));
            fp2.setImportev5(matematico.Matematico.redondear2decimales(fp2.getImportev5() - disminuirImporte));
            fp2.setImportev6(matematico.Matematico.redondear2decimales(fp2.getImportev6() - disminuirImporte));
            fp2.setImportev7(matematico.Matematico.redondear2decimales(fp2.getImportev7() - importe + disminuirImporte + disminuirImporte + disminuirImporte + disminuirImporte + disminuirImporte + disminuirImporte));
        } else if (numPlazosVencimientos == 8) {
            fp2.setPlazopm1(matematico.Matematico.redondear2decimales(fp2.getPlazopm1() - disminuirPorcentaje));
            fp2.setPlazopm2(matematico.Matematico.redondear2decimales(fp2.getPlazopm2() - disminuirPorcentaje));
            fp2.setPlazopm3(matematico.Matematico.redondear2decimales(fp2.getPlazopm3() - disminuirPorcentaje));
            fp2.setPlazopm4(matematico.Matematico.redondear2decimales(fp2.getPlazopm4() - disminuirPorcentaje));
            fp2.setPlazopm5(matematico.Matematico.redondear2decimales(fp2.getPlazopm5() - disminuirPorcentaje));
            fp2.setPlazopm6(matematico.Matematico.redondear2decimales(fp2.getPlazopm6() - disminuirPorcentaje));
            fp2.setPlazopm7(matematico.Matematico.redondear2decimales(fp2.getPlazopm7() - disminuirPorcentaje));
            fp2.setPlazopm6(matematico.Matematico.redondear2decimales(fp2.getPlazopm8() - porcentaje + disminuirPorcentaje + disminuirPorcentaje + disminuirPorcentaje + disminuirPorcentaje + disminuirPorcentaje + disminuirPorcentaje + disminuirPorcentaje));

            fp2.setImportev1(matematico.Matematico.redondear2decimales(fp2.getImportev1() - disminuirImporte));
            fp2.setImportev2(matematico.Matematico.redondear2decimales(fp2.getImportev2() - disminuirImporte));
            fp2.setImportev3(matematico.Matematico.redondear2decimales(fp2.getImportev3() - disminuirImporte));
            fp2.setImportev4(matematico.Matematico.redondear2decimales(fp2.getImportev4() - disminuirImporte));
            fp2.setImportev5(matematico.Matematico.redondear2decimales(fp2.getImportev5() - disminuirImporte));
            fp2.setImportev6(matematico.Matematico.redondear2decimales(fp2.getImportev6() - disminuirImporte));
            fp2.setImportev7(matematico.Matematico.redondear2decimales(fp2.getImportev7() - disminuirImporte));
            fp2.setImportev8(matematico.Matematico.redondear2decimales(fp2.getImportev8() - importe + disminuirImporte + disminuirImporte + disminuirImporte + disminuirImporte + disminuirImporte + disminuirImporte + disminuirImporte));
        } else if (numPlazosVencimientos == 9) {
            fp2.setPlazopm1(matematico.Matematico.redondear2decimales(fp2.getPlazopm1() - disminuirPorcentaje));
            fp2.setPlazopm2(matematico.Matematico.redondear2decimales(fp2.getPlazopm2() - disminuirPorcentaje));
            fp2.setPlazopm3(matematico.Matematico.redondear2decimales(fp2.getPlazopm3() - disminuirPorcentaje));
            fp2.setPlazopm4(matematico.Matematico.redondear2decimales(fp2.getPlazopm4() - disminuirPorcentaje));
            fp2.setPlazopm5(matematico.Matematico.redondear2decimales(fp2.getPlazopm5() - disminuirPorcentaje));
            fp2.setPlazopm6(matematico.Matematico.redondear2decimales(fp2.getPlazopm6() - disminuirPorcentaje));
            fp2.setPlazopm7(matematico.Matematico.redondear2decimales(fp2.getPlazopm7() - disminuirPorcentaje));
            fp2.setPlazopm8(matematico.Matematico.redondear2decimales(fp2.getPlazopm8() - disminuirPorcentaje));
            fp2.setPlazopm6(matematico.Matematico.redondear2decimales(fp2.getPlazopm9() - porcentaje + disminuirPorcentaje + disminuirPorcentaje + disminuirPorcentaje + disminuirPorcentaje + disminuirPorcentaje + disminuirPorcentaje + disminuirPorcentaje + disminuirPorcentaje));

            fp2.setImportev1(matematico.Matematico.redondear2decimales(fp2.getImportev1() - disminuirImporte));
            fp2.setImportev2(matematico.Matematico.redondear2decimales(fp2.getImportev2() - disminuirImporte));
            fp2.setImportev3(matematico.Matematico.redondear2decimales(fp2.getImportev3() - disminuirImporte));
            fp2.setImportev4(matematico.Matematico.redondear2decimales(fp2.getImportev4() - disminuirImporte));
            fp2.setImportev5(matematico.Matematico.redondear2decimales(fp2.getImportev5() - disminuirImporte));
            fp2.setImportev6(matematico.Matematico.redondear2decimales(fp2.getImportev6() - disminuirImporte));
            fp2.setImportev7(matematico.Matematico.redondear2decimales(fp2.getImportev7() - disminuirImporte));
            fp2.setImportev8(matematico.Matematico.redondear2decimales(fp2.getImportev8() - disminuirImporte));
            fp2.setImportev9(matematico.Matematico.redondear2decimales(fp2.getImportev9() - importe + disminuirImporte + disminuirImporte + disminuirImporte + disminuirImporte + disminuirImporte + disminuirImporte + disminuirImporte + disminuirImporte));
        } else if (numPlazosVencimientos == 10) {
            fp2.setPlazopm1(matematico.Matematico.redondear2decimales(fp2.getPlazopm1() - disminuirPorcentaje));
            fp2.setPlazopm2(matematico.Matematico.redondear2decimales(fp2.getPlazopm2() - disminuirPorcentaje));
            fp2.setPlazopm3(matematico.Matematico.redondear2decimales(fp2.getPlazopm3() - disminuirPorcentaje));
            fp2.setPlazopm4(matematico.Matematico.redondear2decimales(fp2.getPlazopm4() - disminuirPorcentaje));
            fp2.setPlazopm5(matematico.Matematico.redondear2decimales(fp2.getPlazopm5() - disminuirPorcentaje));
            fp2.setPlazopm6(matematico.Matematico.redondear2decimales(fp2.getPlazopm6() - disminuirPorcentaje));
            fp2.setPlazopm7(matematico.Matematico.redondear2decimales(fp2.getPlazopm7() - disminuirPorcentaje));
            fp2.setPlazopm8(matematico.Matematico.redondear2decimales(fp2.getPlazopm8() - disminuirPorcentaje));
            fp2.setPlazopm9(matematico.Matematico.redondear2decimales(fp2.getPlazopm9() - disminuirPorcentaje));
            fp2.setPlazopm6(matematico.Matematico.redondear2decimales(fp2.getPlazopm10() - porcentaje + disminuirPorcentaje + disminuirPorcentaje + disminuirPorcentaje + disminuirPorcentaje + disminuirPorcentaje + disminuirPorcentaje + disminuirPorcentaje + disminuirPorcentaje + disminuirPorcentaje));

            fp2.setImportev1(matematico.Matematico.redondear2decimales(fp2.getImportev1() - disminuirImporte));
            fp2.setImportev2(matematico.Matematico.redondear2decimales(fp2.getImportev2() - disminuirImporte));
            fp2.setImportev3(matematico.Matematico.redondear2decimales(fp2.getImportev3() - disminuirImporte));
            fp2.setImportev4(matematico.Matematico.redondear2decimales(fp2.getImportev4() - disminuirImporte));
            fp2.setImportev5(matematico.Matematico.redondear2decimales(fp2.getImportev5() - disminuirImporte));
            fp2.setImportev6(matematico.Matematico.redondear2decimales(fp2.getImportev6() - disminuirImporte));
            fp2.setImportev7(matematico.Matematico.redondear2decimales(fp2.getImportev7() - disminuirImporte));
            fp2.setImportev8(matematico.Matematico.redondear2decimales(fp2.getImportev8() - disminuirImporte));
            fp2.setImportev9(matematico.Matematico.redondear2decimales(fp2.getImportev9() - disminuirImporte));
            fp2.setImportev10(matematico.Matematico.redondear2decimales(fp2.getImportev10() - importe + disminuirImporte + disminuirImporte + disminuirImporte + disminuirImporte + disminuirImporte + disminuirImporte + disminuirImporte + disminuirImporte + disminuirImporte));
        }
    }

    protected void disminuirVencimientosModificacion(double porcentaje, double importe) {

        double disminuirPorcentaje = porcentaje / (fp2.getNumplazosvencimiento() - 1);
        double disminuirImporte = importe / (fp2.getNumplazosvencimiento() - 1);

        fp2.setImportev1(matematico.Matematico.redondear2decimales(fp2.getImportev1() - disminuirImporte));
        fp2.setImportev2(matematico.Matematico.redondear2decimales(fp2.getImportev2() - disminuirImporte));
        fp2.setImportev3(matematico.Matematico.redondear2decimales(fp2.getImportev3() - disminuirImporte));
        fp2.setImportev4(matematico.Matematico.redondear2decimales(fp2.getImportev4() - disminuirImporte));
        fp2.setImportev5(matematico.Matematico.redondear2decimales(fp2.getImportev5() - disminuirImporte));
        fp2.setImportev6(matematico.Matematico.redondear2decimales(fp2.getImportev6() - disminuirImporte));
        fp2.setImportev7(matematico.Matematico.redondear2decimales(fp2.getImportev7() - disminuirImporte));
        fp2.setImportev8(matematico.Matematico.redondear2decimales(fp2.getImportev8() - disminuirImporte));
        fp2.setImportev9(matematico.Matematico.redondear2decimales(fp2.getImportev9() - disminuirImporte));
        fp2.setImportev10(matematico.Matematico.redondear2decimales(fp2.getImportev10() - disminuirImporte));

        fp2.setPlazopm1(matematico.Matematico.redondear2decimales(fp2.getPlazopm1() - disminuirPorcentaje));
        fp2.setPlazopm2(matematico.Matematico.redondear2decimales(fp2.getPlazopm2() - disminuirPorcentaje));
        fp2.setPlazopm3(matematico.Matematico.redondear2decimales(fp2.getPlazopm3() - disminuirPorcentaje));
        fp2.setPlazopm4(matematico.Matematico.redondear2decimales(fp2.getPlazopm4() - disminuirPorcentaje));
        fp2.setPlazopm5(matematico.Matematico.redondear2decimales(fp2.getPlazopm5() - disminuirPorcentaje));
        fp2.setPlazopm6(matematico.Matematico.redondear2decimales(fp2.getPlazopm6() - disminuirPorcentaje));
        fp2.setPlazopm7(matematico.Matematico.redondear2decimales(fp2.getPlazopm7() - disminuirPorcentaje));
        fp2.setPlazopm8(matematico.Matematico.redondear2decimales(fp2.getPlazopm8() - disminuirPorcentaje));
        fp2.setPlazopm9(matematico.Matematico.redondear2decimales(fp2.getPlazopm9() - disminuirPorcentaje));
        fp2.setPlazopm10(matematico.Matematico.redondear2decimales(fp2.getPlazopm10() - disminuirPorcentaje));
    }

    protected void rellenarCliente(Agentes cliente) {
        tCodCliente.setText(cliente.getCod_agente());
        tDniCliente.setText(cliente.getCif_nif());
        tNombreCliente.setText(cliente.getNombre_comercial());
        tDireccionCliente.setText(cliente.getDireccion());
        tCpCliente.setText(String.valueOf(cliente.getCodigo_postal()));
        tLocalidadCliente.setText(cliente.getPoblacion());
        tProvinciaCliente.setText(cliente.getProvincia());
        tPaisCliente.setText(cliente.getPais());
        tTelefonoCliente.setText(cliente.getTelefono());
        tEmailCliente.setText(cliente.getEmail());
        
        calcularNuevoIva(cliente);
        FormaPago ffpp = cliente.getFormaPago();

        if (ffpp != null && ffpp.getIid() != null) {
            ffpp = BaseDatos.obtenerFormaPagoPorIid(ffpp.getIid());
            cformapago.setSelectedItem(ffpp.getCodigo());
        } else {
            cformapago.setSelectedItem(Constantes.VACIO);
            tformapago.setText("");
        }
    }

    private void cambiarCodigos() {
        Iterator it;
        NuevaLineaCompra lip;
        int i = 1;

        for (it = listaArticulos.iterator(); it.hasNext();) {
            lip = (NuevaLineaCompra) it.next();
            lip.setCodigo(i);
            i++;
        }
    }

    protected void anadirLineaPresupuesto() {
        NuevaLineaCompra lip = new NuevaLineaCompra(this, num_articulos, e,u);
        panel.add(lip);
        //panel.setVisible(true);
        panel.repaint();
        this.pack();
        Dimension dim = Util.getDimensiones(this.getSize());
        if(dim != null){
            setResizable(true);
            setSize(dim);
            setResizable(false);
        }
        num_articulos++;
        listaArticulos.add(lip);
        reCalcularLineasVacias();
    }

    protected void reCalcularLineasVacias() {
        Component[] lista = panel.getComponents();
        NuevaLineaCompra nc;
        Component temp;
        List<Integer> posicionesVacias = new ArrayList<Integer>();
        int indice = 0;
        int indiceLineas = 0;
        int maxIndice = lista.length;
        while (indice < maxIndice) {
            temp = (Component) lista[indice];
            if (temp instanceof NuevaLineaCompra) {

                nc = (NuevaLineaCompra) temp;
                if (nc.getLineaOculta()) {
                    posicionesVacias.add(0, indiceLineas);
                }
                indiceLineas++;
            }
            indice++;
        }

        for (int i = 0; i < posicionesVacias.size(); i++) {
            panel.remove(posicionesVacias.get(i));
        }

        this.lineasVacias = 0;

        while (panel.getComponentCount() < Constantes.NUM_LINEAS_DOCUMENTO) {
            anadirLineaPresupuestoVacia();
        }

        panel.repaint();
        this.pack();
        Dimension dim = Util.getDimensiones(this.getSize());
        if(dim != null){
            setResizable(true);
            setSize(dim);
            setResizable(false);
        }
    }

    protected void anadirLineaPresupuestoVacia() {
        NuevaLineaCompra lip = new NuevaLineaCompra(this, -1, e,u);
        lip.ocultarTodo();
        panel.add(lip);
        //panel.setVisible(true);
        panel.repaint();
        this.pack();
        Dimension dim = Util.getDimensiones(this.getSize());
        if(dim != null){
            setResizable(true);
            setSize(dim);
            setResizable(false);
        }
        lineasVacias++;
    }
    
    protected void anadirLineaPresupuesto(LineaPresupuesto lp) {
        mapaNuevoClaves.put(lp.getCodigo(), num_articulos);
        NuevaLineaCompra lip = new NuevaLineaCompra(this, num_articulos, e, lp, lp.getLineaArticulo(),u);
        panel.add(lip);
        panel.repaint();
        this.pack();
        Dimension dim = Util.getDimensiones(this.getSize());
        if(dim != null){
            setResizable(true);
            setSize(dim);
            setResizable(false);
        }
        num_articulos++;
        listaArticulos.add(lip);
        reCalcularLineasVacias();
    }

    protected void borrarLineaDocumento(int codigo) {
        if (codigo != (num_articulos - 1)) {
            //Solo borramos el panel si no es el Ãºltimo
            panel.remove(codigo - 1);
            panel.repaint();
            this.pack();
            Dimension dim = Util.getDimensiones(this.getSize());
            if(dim != null){
                setResizable(true);
                setSize(dim);
                setResizable(false);
            }
            listaArticulos.remove(codigo - 1);
            cambiarCodigos();
            num_articulos--;
            calcularPrecio();
            reCalcularLineasVacias();
        }
    }

    protected void calcularPrecio() {
        double precio_total = 0;
        Iterator it;
        NuevaLineaCompra lip;
        for (it = listaArticulos.iterator(); it.hasNext();) {
            lip = (NuevaLineaCompra) it.next();
            precio_total += lip.getImporte();
        }
        lPrecioTotalBruto.setText(Util.convertirPuntoAComa(String.valueOf(matematico.Matematico.redondear2decimales(precio_total))));
        importe_total = precio_total;

        dto = Float.parseFloat(Util.convertirComaAPunto(tdto.getText()));
        precio_dto = matematico.Matematico.redondear2decimales(importe_total * dto / 100);
        limporte_dto.setText(Util.convertirPuntoAComa(String.valueOf(precio_dto)));

        double precio_aux = importe_total * ((100 - Double.parseDouble(Util.convertirComaAPunto(tdto.getText()))) / 100);
        lprecio.setText(Util.convertirPuntoAComa(String.valueOf(matematico.Matematico.redondear2decimales(precio_aux))));
        importe_total_dto = precio_aux;

        precio_iva = importe_total_dto * (Double.parseDouble(Util.convertirComaAPunto(tIva.getText()))) / 100;
        precio_iva = matematico.Matematico.redondear3decimales(precio_iva);
        limporte_iva.setText(Util.convertirPuntoAComa(String.valueOf(matematico.Matematico.redondear2decimales(precio_iva))));

        precio_final = importe_total_dto * (100 + Double.parseDouble(Util.convertirComaAPunto(tIva.getText()))) / 100;
        lprecio_final.setText(Util.convertirPuntoAComa(String.valueOf(matematico.Matematico.redondear2decimales(precio_final))));

    }

    protected int getNumArticulos() {
        return listaArticulos.size();
    }

    public String getCodigoCliente() {
        String res = "";
        if (this.tCodCliente.getText() != null) {
            res = tCodCliente.getText();
        }
        return res;
    }

    public String getTipoDocumento() {
        return cd.getDescripcion();
    }
    
    public String getNombreCliente() {
        String res = "";
        if (this.tNombreCliente.getText() != null && !this.tNombreCliente.getText().equals("")) {
            res = tNombreCliente.getText();
        }
        return res;
    }

    public String getReferencia() {
        String res = "";
        if (this.tReferencia.getText() != null && !this.tReferencia.getText().equals("")) {
            res = tReferencia.getText();
        }
        return res;
    }

    public String getNumero() {
        String res = "";
        if (this.tnumero.getText() != null && !this.tnumero.getText().equals("")) {
            res = tnumero.getText();
        }
        return res;
    }
    
    public ClaseDocumento getClaseDocumento() {
        ClaseDocumento res = this.cd;

        return res;
    }

    private void crearAcciones() {
        KeyStroke escapeKeyStroke = KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false);
        Action escapeAction = new AbstractAction() {
            public void actionPerformed(ActionEvent e) {
                cerrarPresupuesto();
            }
        };

        getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(escapeKeyStroke, "ESCAPE");
        getRootPane().getActionMap().put("ESCAPE", escapeAction);

        KeyStroke f9KeyStroke = KeyStroke.getKeyStroke(KeyEvent.VK_F9, 0, false);
        Action f9Action = new AbstractAction() {
            public void actionPerformed(ActionEvent ev) {
                teclaF9();

            }
        };

        getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(f9KeyStroke, "F9");
        getRootPane().getActionMap().put("F9", f9Action);
        
        Dimension dim = Util.getDimensiones(this.getSize());
        if(dim != null){
            setResizable(true);
            setSize(dim);
            setResizable(false);
        }

    }

    private void crearIconosBotones() {

        URL urlCancelar = getClass().getResource("/iconos/cancelar.gif");
        ImageIcon iconoCancelar = new ImageIcon(urlCancelar);
        bcancelar.setIcon(iconoCancelar);

        URL urlAceptar = getClass().getResource("/iconos/guardarYvolver.png");
        ImageIcon iconoAceptar = new ImageIcon(urlAceptar);
        baceptar.setIcon(iconoAceptar);

        URL urlModificar = getClass().getResource("/iconos/editar.png");
        ImageIcon iconoModificar = new ImageIcon(urlModificar);
        bmodificar.setIcon(iconoModificar);
        this.bmodificarplazo.setIcon(iconoModificar);
        this.bmodificarvencimiento.setIcon(iconoModificar);


        URL urlGuardar = getClass().getResource("/iconos/guardar.png");
        ImageIcon iconoGuardar = new ImageIcon(urlGuardar);
        this.bguardar.setIcon(iconoGuardar);

        URL urlAnadir = getClass().getResource("/iconos/anadir.png");
        ImageIcon iconoAnadir = new ImageIcon(urlAnadir);
        this.bcrearplazo.setIcon(iconoAnadir);
        this.bCrearVencimiento.setIcon(iconoAnadir);

        URL urlEliminar = getClass().getResource("/iconos/eliminar.png");
        ImageIcon iconoEliminar = new ImageIcon(urlEliminar);
        this.beliminarplazo.setIcon(iconoEliminar);
        this.beliminarvencimiento.setIcon(iconoEliminar);

        URL urlPdf = getClass().getResource("/iconos/pdf.png");
        ImageIcon iconoPdf = new ImageIcon(urlPdf);
        this.bCrearPdf.setIcon(iconoPdf);
        this.jMenuPDF.setIcon(iconoPdf);

        URL urlImprimir = getClass().getResource("/iconos/impresora.gif");
        ImageIcon iconoImprimir = new ImageIcon(urlImprimir);
        this.bImprimir.setIcon(iconoImprimir);

        URL urlMail = getClass().getResource("/iconos/mail.gif");
        ImageIcon iconoMail = new ImageIcon(urlMail);
        this.bMandarMail.setIcon(iconoMail);

        URL urlNotaCliente = getClass().getResource("/iconos/notaCliente.gif");
        ImageIcon iconoNotaCliente = new ImageIcon(urlNotaCliente);
        this.bVerNotasCliente.setIcon(iconoNotaCliente);
    }

    public Long getFechaLong() throws ParseException {
        SimpleDateFormat formatoFecha = new SimpleDateFormat("dd/MM/yyyy");
        Long fecha =  formatoFecha.parse(tfecha.getText()).getTime();
        return fecha ;
    }

    public Almacen getAlmacen() {
        return p.getAlmacen();
    }

    public Presupuesto getPresupuesto() {
        return this.p;
    }
    
    public void actualizarHayNotas(){
        if(p.getNota_documento() != null && p.getNota_documento().length() > 0){
            URL urlExclamacion = getClass().getResource("/iconos/exclamacion.PNG");
            ImageIcon iconoExclamacion = new ImageIcon(urlExclamacion);
            bHayNotas.setIcon(iconoExclamacion);
            bHayNotas.setToolTipText("Hay notas");
            bHayNotas.setVisible(true);
        } else {
            bHayNotas.setVisible(false);
        }
    }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bAnadirNotas;
    private javax.swing.JButton bCrearPdf;
    private javax.swing.JButton bCrearVencimiento;
    private javax.swing.JButton bDatosConversion;
    private javax.swing.JButton bFlujoDatos;
    private javax.swing.JButton bGuardarCliente;
    private javax.swing.JButton bHayNotas;
    private javax.swing.JButton bImprimir;
    private javax.swing.JButton bInsertarArticuloAntes;
    private javax.swing.JButton bInsertarArticuloDespues;
    private javax.swing.JButton bInsertarArticuloFinal;
    private javax.swing.JButton bInsertarArticuloPrincipio;
    private javax.swing.JButton bInsertarNotaAntes;
    private javax.swing.JButton bInsertarNotaDespues;
    private javax.swing.JButton bInsertarNotaFinal;
    private javax.swing.JButton bInsertarNotaPrincipio;
    private javax.swing.JButton bMandarMail;
    private javax.swing.JButton bVerNotas;
    private javax.swing.JButton bVerNotasCliente;
    private javax.swing.JButton baceptar;
    private javax.swing.JButton bcancelar;
    private javax.swing.JButton bcrearplazo;
    private javax.swing.JButton beliminarplazo;
    private javax.swing.JButton beliminarvencimiento;
    private javax.swing.JButton bguardar;
    private javax.swing.JButton binsertarCliente;
    private javax.swing.JButton bmodificar;
    private javax.swing.JButton bmodificarplazo;
    private javax.swing.JButton bmodificarvencimiento;
    private javax.swing.JComboBox cAlmacen;
    private javax.swing.JComboBox cSeries;
    private javax.swing.JComboBox cestado;
    private javax.swing.JComboBox cformapago;
    private javax.swing.JMenuItem jMenuAlbaran;
    private javax.swing.JMenuBar jMenuBar70;
    private javax.swing.JMenuItem jMenuImpagado;
    private javax.swing.JMenuItem jMenuImprimirRecibos;
    private javax.swing.JMenuItem jMenuItemLineaAntes;
    private javax.swing.JMenuItem jMenuItemLineaDespues;
    private javax.swing.JMenuItem jMenuItemLineaFinal;
    private javax.swing.JMenuItem jMenuItemLineaPrincipio;
    private javax.swing.JMenuItem jMenuItemNotaAntes;
    private javax.swing.JMenuItem jMenuItemNotaDespues;
    private javax.swing.JMenuItem jMenuItemNotaFinal;
    private javax.swing.JMenuItem jMenuItemNotaPrincipio;
    private javax.swing.JMenu jMenuOpciones69;
    private javax.swing.JMenuItem jMenuPDF;
    private javax.swing.JMenuItem jMenuPagado;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane14;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JLabel lAlmacen;
    private javax.swing.JLabel lCliente;
    private javax.swing.JLabel lCpCliente;
    private javax.swing.JLabel lEmailCliente;
    private javax.swing.JLabel lIva;
    private javax.swing.JLabel lLocalidad;
    private javax.swing.JLabel lObservaciones;
    private javax.swing.JLabel lPais;
    private javax.swing.JLabel lPrecioTotalBruto;
    private javax.swing.JLabel lReferencia;
    private javax.swing.JLabel lSubTotal;
    private javax.swing.JLabel lTotal;
    private javax.swing.JLabel lconvertido;
    private javax.swing.JLabel ldni;
    private javax.swing.JLabel ldomicilio;
    private javax.swing.JLabel ldto;
    private javax.swing.JLabel lestado;
    private javax.swing.JLabel lfecha;
    private javax.swing.JLabel lformapago;
    private javax.swing.JLabel lformapago1;
    private javax.swing.JLabel lformapago2;
    private javax.swing.JLabel limporte_dto;
    private javax.swing.JLabel limporte_iva;
    private javax.swing.JLabel lnombre;
    private javax.swing.JLabel lnumero;
    private javax.swing.JLabel lprecio;
    private javax.swing.JLabel lprecio_final;
    private javax.swing.JLabel ltelefono;
    private javax.swing.JLabel ltotalbruto;
    private javax.swing.JPanel panel;
    private javax.swing.JTextField tCodCliente;
    private javax.swing.JTextField tCpCliente;
    private javax.swing.JTextField tDireccionCliente;
    private javax.swing.JTextField tDniCliente;
    private javax.swing.JTextField tEmailCliente;
    private javax.swing.JTextField tIva;
    private javax.swing.JTextField tLocalidadCliente;
    private javax.swing.JTextField tNombreCliente;
    private javax.swing.JTextArea tObservaciones;
    private javax.swing.JTextField tPaisCliente;
    private javax.swing.JLabel tProvincia;
    private javax.swing.JTextField tProvinciaCliente;
    private javax.swing.JTextField tReferencia;
    private javax.swing.JTextField tTelefonoCliente;
    private javax.swing.JTextField tdto;
    private javax.swing.JTextField tfecha;
    private javax.swing.JTextField tformapago;
    private javax.swing.JTextField tnumero;
    private javax.swing.JTable tplazosadelantados;
    private javax.swing.JLabel ttitulo2;
    private javax.swing.JTable tvencimientos;
    // End of variables declaration//GEN-END:variables
}
