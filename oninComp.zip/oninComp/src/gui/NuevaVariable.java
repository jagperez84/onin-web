package gui;

import bean.Seleccion;
import bean.Variable;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JOptionPane;
import javax.swing.KeyStroke;
import org.apache.log4j.Logger;
import util.Constantes;
import util.Util;

public class NuevaVariable extends javax.swing.JFrame {

    private boolean crear;
    private NuevoDAC ndac;
    private Variable var;
    private List<Seleccion> listaSeleccion;
    private String nombreAntiguo;
    private String valorAntiguo;
    private String tipoAntiguo;
    private String condicionAntigua;
    private boolean activarPeticionAntigua;
    private String valorMaximoAntiguo;
    private String valorMinimoAntiguo;
    private boolean activarMaximoAntiguo;
    private boolean activarMinimoAntiguo;
    private String formulaAntigua;
    private boolean perimitirEditarResultadoFormlaAntigua;
    private boolean cambiadoSeleccion;
    private static Logger log = Logger.getLogger(NuevaVariable.class);

    public NuevaVariable(NuevoDAC ndac, String titulo) {
        super(titulo);
        this.ndac = ndac;
        this.crear = true;
        this.var = new Variable();
        this.listaSeleccion = new ArrayList<Seleccion>();
        this.initComponents();
        tNombre.setText("");
        tCondicion.setText("");
        tValor.setText("0");
        bmodificar.setVisible(false);
        cambiadoSeleccion = false;
        tValorMaximo.setEnabled(false);
        tValorMinimo.setEnabled(false);
        crearIconosBotones();
        crearAcciones();
    }

    public NuevaVariable(NuevoDAC ndac, String titulo, Variable var, ArrayList<Seleccion>listaSeleccion) {
        super(titulo);
        this.crear = false;
        this.ndac = ndac;
        this.var = var;
        this.listaSeleccion = listaSeleccion;

        String opcionSeleccionada = this.getVbleSeleccionada();
        
        this.initComponents();
        tNombre.setText(var.getNombre());
        bActivarPeticion.setSelected(var.getActivarPeticion());
        tValor.setText(Util.convertirPuntoAComa(String.valueOf(var.getValor())));
        tCondicion.setText(var.getCondicion());
        cTipo.setSelectedItem(var.getTipo());
        if(var.getTipo().equalsIgnoreCase(Constantes.CALCULADA)){
            valorMaximoAntiguo = Util.convertirPuntoAComa(var.getValorMaximo().toString());
            valorMinimoAntiguo = Util.convertirPuntoAComa(var.getValorMinimo().toString());
            activarMaximoAntiguo = var.getActivarMaximo();
            activarMinimoAntiguo = var.getActivarMinimo();
            formulaAntigua = var.getFormula();
            perimitirEditarResultadoFormlaAntigua = var.getEditarResultadoFormula();
        } else {
            valorMaximoAntiguo = "0";
            valorMinimoAntiguo = "0";
            activarMaximoAntiguo = false;
            activarMinimoAntiguo = false;
            formulaAntigua = "";
            perimitirEditarResultadoFormlaAntigua = false;
        }

        tValorMaximo.setText(valorMaximoAntiguo);
        tValorMinimo.setText(valorMinimoAntiguo);
        bActivarMaximo.setSelected(activarMaximoAntiguo);
        bActivarMinimo.setSelected(activarMinimoAntiguo);
        tFormula.setText(formulaAntigua);
        bEditarFormula.setSelected(perimitirEditarResultadoFormlaAntigua);
        tValorMaximo.setEnabled(false);
        tValorMinimo.setEnabled(false);
        bSeleccionarVariable.setEnabled(false);
        bEvaluarFormula.setEnabled(false);
        bActivarMaximo.setEnabled(false);
        bActivarMinimo.setEnabled(false);
        tFormula.setEnabled(false);
        bEditarFormula.setEnabled(false);
        cSeleccion.setEnabled(false);
        bCrearSeleccion.setEnabled(false);
        bEditarSeleccion.setEnabled(false);
        bBorrarSeleccion.setEnabled(false);
        tNombre.setEnabled(false);
        cTipo.setEnabled(false);
        bActivarPeticion.setEnabled(false);
        tCondicion.setEnabled(false);
        tValor.setEnabled(false);
        bcancelar.setToolTipText("Cancelar la creación de la variable");
        baceptar.setToolTipText("Realizar la modificación");
        bmodificar.setText("Modificar");
        bmodificar.setToolTipText("Modificar campos");
        
        condicionAntigua = tCondicion.getText();
        valorAntiguo = tValor.getText();
        nombreAntiguo = tNombre.getText();
        bActivarPeticion.setSelected(var.getActivarPeticion());
        tipoAntiguo = (String) cTipo.getSelectedItem();
        cambiadoSeleccion = false;
        
        if(var.getTipo().equals(Constantes.SELECCION)){
            this.setVbleSeleccionada(opcionSeleccionada);
            this.cSeleccion.setSelectedItem(opcionSeleccionada);
        }
        
        crearIconosBotones();
        crearAcciones();
    }

    private void crearAcciones() {
        KeyStroke escapeKeyStroke = KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false);
        Action escapeAction = new AbstractAction() {
            public void actionPerformed(ActionEvent e) {
                cerrarVariable();
            }
        }; 
        getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(escapeKeyStroke, "ESCAPE");
        getRootPane().getActionMap().put("ESCAPE", escapeAction);
    }
    
    private void cerrarVariable() {
        removeAll();
        dispose();
    }
    
     private void crearIconosBotones() {
        URL url = getClass().getResource("/iconos/cancelar.gif");
        ImageIcon icono = new ImageIcon(url);
        bcancelar.setIcon(icono);
        
        url = getClass().getResource("/iconos/aceptar.png");
        icono = new ImageIcon(url);
        baceptar.setIcon(icono);
        
        url = getClass().getResource("/iconos/editar.png");
        icono = new ImageIcon(url);
        bmodificar.setIcon(icono);
        
        url = getClass().getResource("/iconos/masAzul.png");
        icono = new ImageIcon(url);
        bCrearSeleccion.setIcon(icono);
        
        url = getClass().getResource("/iconos/gomaBorrar.gif");
        icono = new ImageIcon(url);
        bBorrarSeleccion.setIcon(icono);
        
        url = getClass().getResource("/iconos/editarLapiz.gif");
        icono = new ImageIcon(url);
        bEditarSeleccion.setIcon(icono);
        
        url = getClass().getResource("/iconos/calculadora.png");
        icono = new ImageIcon(url);
        bEvaluarFormula.setIcon(icono);
        bEvaluarFormula.setToolTipText("Evaluar Fórmula");
        
        url = getClass().getResource("/iconos/variable.gif");
        icono = new ImageIcon(url);
        bSeleccionarVariable.setIcon(icono);
        bSeleccionarVariable.setToolTipText("Seleccionar Variable");
        bSeleccionarVariableCondicion.setIcon(icono);
        bSeleccionarVariableCondicion.setToolTipText("Seleccionar Variable");
    }

    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lTipo = new javax.swing.JLabel();
        cTipo = new javax.swing.JComboBox();
        bActivarPeticion = new javax.swing.JCheckBox();
        baceptar = new javax.swing.JButton();
        bcancelar = new javax.swing.JButton();
        lNombre = new javax.swing.JLabel();
        lValor = new javax.swing.JLabel();
        tValor = new javax.swing.JTextField();
        bmodificar = new javax.swing.JButton();
        tNombre = new javax.swing.JTextField();
        lCondicion = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tCondicion = new javax.swing.JTextArea();
        pCalculada = new javax.swing.JPanel();
        lNombre1 = new javax.swing.JLabel();
        tValorMinimo = new javax.swing.JTextField();
        lMaximo = new javax.swing.JLabel();
        tValorMaximo = new javax.swing.JTextField();
        lFormula = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tFormula = new javax.swing.JTextArea();
        bEditarFormula = new javax.swing.JCheckBox();
        bActivarMaximo = new javax.swing.JCheckBox();
        bActivarMinimo = new javax.swing.JCheckBox();
        bEvaluarFormula = new javax.swing.JButton();
        bSeleccionarVariable = new javax.swing.JButton();
        pSeleccion = new javax.swing.JPanel();
        lSeleccion = new javax.swing.JLabel();
        cSeleccion = new javax.swing.JComboBox();
        bCrearSeleccion = new javax.swing.JButton();
        bEditarSeleccion = new javax.swing.JButton();
        bBorrarSeleccion = new javax.swing.JButton();
        bSeleccionarVariableCondicion = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        lTipo.setText("Tipo");

        cTipo.setModel(new javax.swing.DefaultComboBoxModel(new String[] {}));
        cTipo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cTipoActionPerformed(evt);
            }
        });

        bActivarPeticion.setText("Activar Petición al Explosionar");

        baceptar.setText("Aceptar");
        baceptar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                baceptarActionPerformed(evt);
            }
        });

        bcancelar.setText("Cancelar");
        bcancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bcancelarActionPerformed(evt);
            }
        });

        lNombre.setText("Nombre");

        lValor.setText("Valor");

        tValor.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tValorKeyReleased(evt);
            }
        });

        bmodificar.setText("Modificar");
        bmodificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bmodificarActionPerformed(evt);
            }
        });

        tNombre.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tNombreKeyReleased(evt);
            }
        });

        lCondicion.setText("Condición");

        tCondicion.setColumns(20);
        tCondicion.setRows(5);
        tCondicion.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tCondicionKeyReleased(evt);
            }
        });
        jScrollPane1.setViewportView(tCondicion);

        lNombre1.setText("Valor Mínimo");

        tValorMinimo.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tValorMinimoKeyReleased(evt);
            }
        });

        lMaximo.setText("Valor Máximo");

        tValorMaximo.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tValorMaximoKeyReleased(evt);
            }
        });

        lFormula.setText("Fórmula");

        tFormula.setColumns(20);
        tFormula.setRows(5);
        tFormula.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tFormulaKeyReleased(evt);
            }
        });
        jScrollPane2.setViewportView(tFormula);

        bEditarFormula.setText("Permitir editar resultado formula");

        bActivarMaximo.setText("Activar Máximo");
        bActivarMaximo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bActivarMaximoActionPerformed(evt);
            }
        });

        bActivarMinimo.setText("Activar Mínimo");
        bActivarMinimo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bActivarMinimoActionPerformed(evt);
            }
        });

        bEvaluarFormula.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bEvaluarFormulaActionPerformed(evt);
            }
        });

        bSeleccionarVariable.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bSeleccionarVariableActionPerformed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout pCalculadaLayout = new org.jdesktop.layout.GroupLayout(pCalculada);
        pCalculada.setLayout(pCalculadaLayout);
        pCalculadaLayout.setHorizontalGroup(
            pCalculadaLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(pCalculadaLayout.createSequentialGroup()
                .addContainerGap()
                .add(pCalculadaLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(lMaximo)
                    .add(lFormula)
                    .add(lNombre1))
                .add(27, 27, 27)
                .add(pCalculadaLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(bEditarFormula)
                    .add(pCalculadaLayout.createSequentialGroup()
                        .add(pCalculadaLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING, false)
                            .add(tValorMinimo)
                            .add(tValorMaximo, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 115, Short.MAX_VALUE))
                        .add(18, 18, 18)
                        .add(pCalculadaLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(bActivarMaximo)
                            .add(bActivarMinimo)))
                    .add(pCalculadaLayout.createSequentialGroup()
                        .add(jScrollPane2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 257, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(pCalculadaLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(bSeleccionarVariable)
                            .add(bEvaluarFormula))))
                .addContainerGap(22, Short.MAX_VALUE))
        );
        pCalculadaLayout.setVerticalGroup(
            pCalculadaLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(pCalculadaLayout.createSequentialGroup()
                .addContainerGap(11, Short.MAX_VALUE)
                .add(pCalculadaLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(bActivarMinimo)
                    .add(lNombre1)
                    .add(tValorMinimo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                .add(pCalculadaLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(lMaximo)
                    .add(bActivarMaximo)
                    .add(tValorMaximo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .add(pCalculadaLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(pCalculadaLayout.createSequentialGroup()
                        .add(18, 18, 18)
                        .add(lFormula))
                    .add(pCalculadaLayout.createSequentialGroup()
                        .add(10, 10, 10)
                        .add(pCalculadaLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(pCalculadaLayout.createSequentialGroup()
                                .add(bEvaluarFormula, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 22, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                .add(bSeleccionarVariable, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 22, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                            .add(jScrollPane2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(bEditarFormula, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 16, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        lSeleccion.setText("Selección");

        cSeleccion.setModel(new javax.swing.DefaultComboBoxModel(new String[] {}));
        cSeleccion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cSeleccionActionPerformed(evt);
            }
        });

        bCrearSeleccion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bCrearSeleccionActionPerformed(evt);
            }
        });

        bEditarSeleccion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bEditarSeleccionActionPerformed(evt);
            }
        });

        bBorrarSeleccion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bBorrarSeleccionActionPerformed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout pSeleccionLayout = new org.jdesktop.layout.GroupLayout(pSeleccion);
        pSeleccion.setLayout(pSeleccionLayout);
        pSeleccionLayout.setHorizontalGroup(
            pSeleccionLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, pSeleccionLayout.createSequentialGroup()
                .addContainerGap()
                .add(lSeleccion)
                .add(41, 41, 41)
                .add(cSeleccion, 0, 182, Short.MAX_VALUE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                .add(bCrearSeleccion)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(bEditarSeleccion)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(bBorrarSeleccion)
                .addContainerGap())
        );
        pSeleccionLayout.setVerticalGroup(
            pSeleccionLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(pSeleccionLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                .add(lSeleccion)
                .add(cSeleccion, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 22, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
            .add(pSeleccionLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                .add(bBorrarSeleccion, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 22, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .add(bEditarSeleccion, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 22, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .add(bCrearSeleccion, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 22, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
        );

        bSeleccionarVariableCondicion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bSeleccionarVariableCondicionActionPerformed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout layout = new org.jdesktop.layout.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(layout.createSequentialGroup()
                .addContainerGap()
                .add(lValor)
                .add(61, 61, 61)
                .add(tValor, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 262, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(61, Short.MAX_VALUE))
            .add(layout.createSequentialGroup()
                .addContainerGap()
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(layout.createSequentialGroup()
                        .add(90, 90, 90)
                        .add(bActivarPeticion))
                    .add(layout.createSequentialGroup()
                        .add(lCondicion)
                        .add(44, 44, 44)
                        .add(jScrollPane1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 258, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                        .add(bSeleccionarVariableCondicion)))
                .add(17, 17, 17))
            .add(org.jdesktop.layout.GroupLayout.TRAILING, layout.createSequentialGroup()
                .addContainerGap(123, Short.MAX_VALUE)
                .add(baceptar)
                .add(18, 18, 18)
                .add(bmodificar, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 103, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .add(18, 18, 18)
                .add(bcancelar)
                .addContainerGap())
            .add(org.jdesktop.layout.GroupLayout.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(lNombre)
                    .add(layout.createSequentialGroup()
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(lTipo)))
                .add(47, 47, 47)
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(tNombre, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 266, Short.MAX_VALUE)
                    .add(cTipo, 0, 266, Short.MAX_VALUE))
                .add(58, 58, 58))
            .add(org.jdesktop.layout.GroupLayout.TRAILING, layout.createSequentialGroup()
                .add(pSeleccion, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
            .add(pCalculada, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(layout.createSequentialGroup()
                .addContainerGap()
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(lNombre)
                    .add(tNombre, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .add(18, 18, 18)
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(lTipo)
                    .add(cTipo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                .add(pSeleccion, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 25, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .add(18, 18, 18)
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(lValor)
                    .add(tValor, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(pCalculada, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(bActivarPeticion)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(lCondicion)
                    .add(jScrollPane1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 56, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(bSeleccionarVariableCondicion, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 22, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED, 28, Short.MAX_VALUE)
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(bcancelar)
                    .add(bmodificar)
                    .add(baceptar))
                .addContainerGap())
        );

        cTipo.addItem(Constantes.NUMERICA);
        cTipo.addItem(Constantes.SELECCION);
        cTipo.addItem(Constantes.CALCULADA);

        pack();
    }// </editor-fold>//GEN-END:initComponents

private void bcancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bcancelarActionPerformed
    cerrarVariable();
}//GEN-LAST:event_bcancelarActionPerformed

private void baceptarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_baceptarActionPerformed
    try {
        boolean insertar = true;
        String mensajeError = "";
        
        String tipo = (String)cTipo.getSelectedItem();

        var.setActivarPeticion(bActivarPeticion.isSelected());
        var.setNombre(tNombre.getText());
        var.setCondicion(tCondicion.getText());
        var.setTipo(tipo);
        
        if(var.getNombre() != null && var.getNombre().length() > 0){
            if(tipo.equalsIgnoreCase(Constantes.CALCULADA)){
                var.setValor(0d);
                var.setActivarMaximo(bActivarMaximo.isSelected());
                var.setActivarMinimo(bActivarMinimo.isSelected());
                var.setEditarResultadoFormula(bEditarFormula.isSelected());

                String sValorMax = tValorMaximo.getText();
                if(sValorMax.length() == 0){
                    sValorMax = "0";
                }
                var.setValorMaximo(Double.parseDouble(Util.convertirComaAPunto(sValorMax))); 
                
                String sValorMin = tValorMinimo.getText();
                if(sValorMin.length() == 0){
                    sValorMin = "0";
                }
                var.setValorMinimo(Double.parseDouble(Util.convertirComaAPunto(sValorMin)));

                String sFormula = tFormula.getText();
                var.setFormula(sFormula);
                
                if(sFormula == null || sFormula.length() == 0){
                    insertar = false;
                    mensajeError = "La fórmula está vacía";
                } else {
                    Double resultadoFormula = ndac.evaluar(Util.convertirComaAPunto(sFormula), Constantes.DECIMALES2, false);
                    if(resultadoFormula == null){
                        insertar = false;
                        mensajeError = "La fórmula contiene errores";
                    }
                }
            } else if(tipo.equalsIgnoreCase(Constantes.SELECCION)){
                if(this.listaSeleccion == null || this.listaSeleccion.size() == 0){
                    insertar = false;
                    mensajeError = "Debe crear algún valor de selección";
                } 
            } else {
                String sValor = tValor.getText();
                if(sValor.length() == 0){
                    sValor = "0";
                }
                var.setValor(Double.parseDouble(Util.convertirComaAPunto(sValor)));
                var.setActivarMaximo(false);
                var.setActivarMinimo(false);
                var.setEditarResultadoFormula(false);
                var.setValorMaximo(0d);
                var.setValorMinimo(0d);
                var.setFormula("");
            }
            
            if(insertar){
                //Hay que comprobar que la condición de la variable sea correta
                String sCondicion = this.tCondicion.getText();
                if(sCondicion != null && !sCondicion.equals("")){
                    insertar = ndac.comprobarCondicion(sCondicion);
                    if(!insertar){
                        mensajeError = "La condición es incorrecta";
                    }
                }
            }
            
            if(!insertar){
               JOptionPane.showMessageDialog(null, mensajeError, "Error", JOptionPane.ERROR_MESSAGE); 
            } else if (crear) {
                //Creamos la variable
                if(!tipo.equalsIgnoreCase(Constantes.SELECCION)){
                    borrarSeleccion();
                }
                if (ndac.insertarVariable(var)) {
                    cerrarVariable();
                }
            } else {
                if(!tipo.equalsIgnoreCase(Constantes.SELECCION)){
                    borrarSeleccion();
                }
                if (ndac.modificarVariable(var)) {
                    cerrarVariable();
                }
            }
        } else {
            JOptionPane.showMessageDialog(null, "El campo \"Nombre\" es obligatorio", "Error", JOptionPane.ERROR_MESSAGE);
        }
    } catch (NumberFormatException exc) {
        //Error, los campos numéricos no contienen números
        JOptionPane.showMessageDialog(null, "Los campos \"Valor\", \"Valor Minimo\" y \"Valor Maximo\"  deben ser numéricos", "Error", JOptionPane.ERROR_MESSAGE);
    }
}//GEN-LAST:event_baceptarActionPerformed

private void bmodificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bmodificarActionPerformed
    if (bmodificar.getText().equals("Modificar")) {
        //Si el botón tiene el texto Modificar
        cTipo.setEnabled(true);
        bActivarPeticion.setEnabled(true);
        bActivarPeticion.setEnabled(true);
        tNombre.setEnabled(true);
        tCondicion.setEnabled(true);
        bActivarMaximo.setEnabled(true);
        bActivarMinimo.setEnabled(true);
        bEditarFormula.setEnabled(true);
        tFormula.setEnabled(true);
        cSeleccion.setEnabled(true);
        bCrearSeleccion.setEnabled(true);
        bEditarSeleccion.setEnabled(true);
        bBorrarSeleccion.setEnabled(true);
        bSeleccionarVariable.setEnabled(true);
        bEvaluarFormula.setEnabled(true);
        tValorMaximo.setEnabled(bActivarMaximo.isSelected());
        tValorMinimo.setEnabled(bActivarMinimo.isSelected());
        
        if(this.cTipo.getSelectedItem().equals(Constantes.NUMERICA)){
            tValor.setEnabled(true);
        }
        
        bmodificar.setText("Visualizar");
        bmodificar.setToolTipText("Visualizar campos");
        
        URL urlModificar = getClass().getResource("/iconos/buscar.gif");
        ImageIcon iconoModificar = new ImageIcon(urlModificar);
        bmodificar.setIcon(iconoModificar);
        
    } else {
        //si el botón tiene el texto Visualizar
        cTipo.setEnabled(false);
        bActivarPeticion.setEnabled(false);
        bActivarPeticion.setEnabled(false);
        tNombre.setEnabled(false);
        tCondicion.setEnabled(false);
        tValorMaximo.setEnabled(false);
        tValorMinimo.setEnabled(false);
        bActivarMaximo.setEnabled(false);
        bActivarMinimo.setEnabled(false);
        bEditarFormula.setEnabled(false);
        tFormula.setEnabled(false);
        cSeleccion.setEnabled(false);
        bCrearSeleccion.setEnabled(false);
        bEditarSeleccion.setEnabled(false);
        bBorrarSeleccion.setEnabled(false);
        bSeleccionarVariable.setEnabled(false);
        bEvaluarFormula.setEnabled(false);
        
        if(this.cTipo.getSelectedItem().equals(Constantes.NUMERICA)){
            tValor.setEnabled(true);
        }
        
        bmodificar.setText("Modificar");
        bmodificar.setToolTipText("Modificar campos");
        
        URL urlModificar = getClass().getResource("/iconos/editar.png");
        ImageIcon iconoModificar = new ImageIcon(urlModificar);
        bmodificar.setIcon(iconoModificar);
    }
}//GEN-LAST:event_bmodificarActionPerformed

private void cTipoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cTipoActionPerformed
    int heigth = 357;
    int heigthMaximoCalculada = 470;
    int heigthMaximoSeleccion = 320;
    int heigthMaximoNumerica = 290;

    String sTipo = (String) cTipo.getSelectedItem();

    if(sTipo.equalsIgnoreCase(Constantes.CALCULADA)){
        heigth = heigthMaximoCalculada;
        tValor.setEnabled(false);
        bEditarFormula.setSelected(false);
        pCalculada.setVisible(true);
        pSeleccion.setVisible(false);
        tFormula.setText("");
        
    } else if(sTipo.equalsIgnoreCase(Constantes.SELECCION)){
        heigth = heigthMaximoSeleccion;
        tValor.setEnabled(true);
        pCalculada.setVisible(false);
        pSeleccion.setVisible(true);
        Iterator iter = this.listaSeleccion.iterator();
        Seleccion sel;
        int indice = 0;
        int seleccionar = -1;
        double valor = 0;
        while(iter.hasNext()){
            sel = (Seleccion)iter.next();
            cSeleccion.addItem(sel.getNombre());
            if(sel.getSeleccionada()){
                seleccionar = indice;
                valor = sel.getValor();
            }
            indice++;
        }
        if(seleccionar >= 0){
            cSeleccion.setSelectedIndex(seleccionar);
            tValor.setText(String.valueOf(valor));
        }
        tValor.setEnabled(false);
        
        boolean mostrar = false;
        if(listaSeleccion.size() > 0){
            mostrar = true;
        } 
        bEditarSeleccion.setEnabled(mostrar);
        bBorrarSeleccion.setEnabled(mostrar);
        
    } else {
        heigth = heigthMaximoNumerica;
        pCalculada.setVisible(false);
        pSeleccion.setVisible(false);
        tValor.setEnabled(true);
    }
 
    setSize(this.getWidth(), heigth);
}//GEN-LAST:event_cTipoActionPerformed

private void borrarSeleccion(){
    //se borrarán todas las selecciones de la variable
    Iterator iter = this.listaSeleccion.iterator();
    Seleccion aux;
    while(iter.hasNext()){
        aux = (Seleccion)iter.next();
        ndac.eliminarSeleccion(nombreAntiguo, aux.getNombre());
    }
    
    int indice;
    int longMax = listaSeleccion.size();
    for(indice = 0; indice < longMax; indice++){
        listaSeleccion.remove(0);
    }
}


public boolean insertarSeleccion(Seleccion sel){
    boolean res = true;
    int indSeleccion = indiceSeleccion(sel.getNombre());
    if(indSeleccion >= 0){
        res = false;
        JOptionPane.showMessageDialog(null, "Esta Selección ya existe", "Error", JOptionPane.ERROR_MESSAGE);
    } else {
        
        String opcionSeleccionada = "";
        if (this.listaSeleccion != null && this.listaSeleccion.size() > 0) {
            opcionSeleccionada = this.getVbleSeleccionada();
        } else if (this.listaSeleccion != null) {
            opcionSeleccionada = sel.getNombre();
        }   
        
        ndac.insertarSeleccion(sel);
        this.cSeleccion.removeAllItems();
        this.listaSeleccion.add(sel);
        Seleccion s;
        Iterator iter = this.listaSeleccion.iterator();
        while(iter.hasNext()){
            s = (Seleccion)iter.next();
            cSeleccion.addItem(s.getNombre());
        }
        this.bEditarSeleccion.setEnabled(true);
        this.bBorrarSeleccion.setEnabled(true);
        cambiadoSeleccion = true;
        this.setVbleSeleccionada(opcionSeleccionada);
        cSeleccion.setSelectedItem(opcionSeleccionada);
    }
    
    return res;
}

private String getVbleSeleccionada(){
    String res = "";
    if(this.listaSeleccion != null && this.listaSeleccion.size() > 0){
        Iterator iter = this.listaSeleccion.iterator();
        Seleccion selTemp;
        boolean seguir = true;
        while(iter.hasNext() && seguir){
            selTemp = (Seleccion)iter.next();
            if(selTemp.getSeleccionada()){
                res = selTemp.getNombre();
                seguir = false;
            }
        }
    }
    return res;
}

private void setVbleSeleccionada(String nombreVble){
    Iterator iter = this.listaSeleccion.iterator();
    Seleccion selTemp;
    boolean seguir = true;
    while(iter.hasNext() && seguir){
        selTemp = (Seleccion)iter.next();
        if(selTemp.getNombre().equals(nombreVble)){
            selTemp.setSeleccionada(true);
        } else {
            selTemp.setSeleccionada(false);
        }
    }
}

protected Variable getVariable(){
    return this.var;
}

public boolean modificarSeleccion(Seleccion sel,String nombreSeleccionAntiguo){
    boolean res = true;
    int indice = 0;
    int indiceSeleccion = -1;
    boolean seguir = true;
    Iterator iter = listaSeleccion.iterator();
    Seleccion selAux = null;
    while(seguir && iter.hasNext()){
        selAux = (Seleccion)iter.next();
        if(selAux.getNombre().equalsIgnoreCase(nombreSeleccionAntiguo)){
            seguir = false;
            indiceSeleccion = indice;
        } else {
            indice++;
        }
    }
    
    if(!seguir){
        //Se modifica la seleccion en la lista de seleccion de la variable
        listaSeleccion.remove(indiceSeleccion);
        listaSeleccion.add(indiceSeleccion, sel);
        int indiceSeleccionSeleccionada = cSeleccion.getSelectedIndex();
        cSeleccion.removeItemAt(indiceSeleccionSeleccionada);
        cSeleccion.insertItemAt(sel.getNombre(), indiceSeleccionSeleccionada);
        cSeleccion.setSelectedIndex(indiceSeleccionSeleccionada);
        tValor.setText(sel.getValor().toString());
        
        //Ahora se ha de modificar la seleccion en la lista de seleccion del dac
        ndac.eliminarSeleccion(sel.getNombre(), nombreSeleccionAntiguo);
        ndac.insertarSeleccion(sel);
        cambiadoSeleccion = true;
    }
    
    return res;
}

public int indiceSeleccion(String nombreSeleccion){
    int res = -1;
    int indice = 0;
    Seleccion sel;
    Iterator it= this.listaSeleccion.iterator();
    while(it.hasNext()&& res < 0){
        sel = (Seleccion)it.next();
        if(sel.getNombre().equalsIgnoreCase(nombreSeleccion)){
            res = indice;
        }
        indice++;
    }
    return res;
}

private void cSeleccionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cSeleccionActionPerformed
    //Hay que tomar el campo Valor de la selección escogida
    Iterator iter = this.listaSeleccion.iterator();
    Double valor = 0d;
    boolean seguir = true;
    Seleccion temp;
    String seleccion = (String)cSeleccion.getSelectedItem();
    while(seguir && iter.hasNext()){
        temp = (Seleccion)iter.next();
        if(temp.getNombre().equalsIgnoreCase(seleccion)){
            seguir = false;
            valor = temp.getValor();
        }
    }
    
    tValor.setText(Util.convertirPuntoAComa(String.valueOf(valor)));
    seleccionarSeleccion(seleccion);
}//GEN-LAST:event_cSeleccionActionPerformed

private void seleccionarSeleccion(String nombre){
    Iterator iter = listaSeleccion.iterator();
    Seleccion temp;
    while(iter.hasNext()){
        temp = (Seleccion)iter.next();
        if(temp.getNombre().equals(nombre)){
            temp.setSeleccionada(true);
        } else {
            temp.setSeleccionada(false);
        }
    }
}

private void bEditarSeleccionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bEditarSeleccionActionPerformed

    String nombreSeleccion = (String) cSeleccion.getSelectedItem();
    int indice = 0;
    Iterator iter = listaSeleccion.iterator();
    boolean seguir = true;
    Seleccion sel = null;
    while(seguir && iter.hasNext()){
        sel = (Seleccion)iter.next();
        if(sel.getNombre().equalsIgnoreCase(nombreSeleccion)){
            seguir = false;
        } else {
            indice++;
        }
    }
    
    if(!seguir){
        Seleccion selClonada = sel.clonar();
        NuevaSeleccion ns = new NuevaSeleccion(this, selClonada, "Selección - Modificación");
        ns.setDefaultCloseOperation(NuevaSeleccion.DISPOSE_ON_CLOSE);
        ns.setLocationRelativeTo(null);
        ns.setVisible(true);
    }
}//GEN-LAST:event_bEditarSeleccionActionPerformed

private void bCrearSeleccionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bCrearSeleccionActionPerformed
    NuevaSeleccion ns = new NuevaSeleccion(this, "Selección - Creación");
    ns.setDefaultCloseOperation(NuevaSeleccion.DISPOSE_ON_CLOSE);
    ns.setLocationRelativeTo(null);
    ns.setVisible(true);
}//GEN-LAST:event_bCrearSeleccionActionPerformed

private void bBorrarSeleccionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bBorrarSeleccionActionPerformed
    int eliminar = 1;
    eliminar = JOptionPane.showConfirmDialog(null, "Está seguro de que desea eliminar el elemento seleccionado?", "¿Eliminar?", JOptionPane.YES_NO_OPTION);
    //hacerCambios = -1 ==> se ha pulsado la "x" de cancelar;
    //hacerCambios =  0 ==> se ha pulsado el "sí"
    //hacerCambios =  1 ==> se ha pulsado el "no"

    if (eliminar == 0) {
        String nombre = (String)cSeleccion.getSelectedItem();
        int indiceBorrar = indiceSeleccionPorNombre(nombre);
        listaSeleccion.remove(indiceBorrar);
        cSeleccion.removeItem(nombre);
        ndac.eliminarSeleccion(nombreAntiguo, nombre);
        
        if(cSeleccion.getItemCount() > 0){
            nombre = (String)cSeleccion.getSelectedItem();
            int indiceSeleccion = indiceSeleccionPorNombre(nombre);
            Seleccion sel = listaSeleccion.get(indiceSeleccion);
            this.tValor.setText(String.valueOf(sel.getValor()));
        } else {
            bEditarSeleccion.setEnabled(false);
            bBorrarSeleccion.setEnabled(false);
        }
    }
}//GEN-LAST:event_bBorrarSeleccionActionPerformed

private void bActivarMinimoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bActivarMinimoActionPerformed
    tValorMinimo.setEnabled(bActivarMinimo.isSelected());
    if(bActivarMinimo.isSelected()){
        tValorMinimo.setText("0.0");
    } else {
        tValorMinimo.setText("");
    }
}//GEN-LAST:event_bActivarMinimoActionPerformed

private void bActivarMaximoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bActivarMaximoActionPerformed
    tValorMaximo.setEnabled(bActivarMaximo.isSelected());
    if(bActivarMaximo.isSelected()){
        tValorMaximo.setText("0.0");
    } else {
        tValorMaximo.setText("");
    }
}//GEN-LAST:event_bActivarMaximoActionPerformed

private void bEvaluarFormulaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bEvaluarFormulaActionPerformed
    Double minimo = null;
    Double maximo = null;
    boolean hayErrores = false;
    try{
        
		String tValorMinimoS = tValorMinimo.getText();
        if(tValorMinimoS.length() > 0){
            minimo = Double.parseDouble(Util.convertirComaAPunto(tValorMinimoS));
        }
        String tValorMaximoS = tValorMaximo.getText();
        if(tValorMaximoS.length() > 0){
            maximo = Double.parseDouble(Util.convertirComaAPunto(tValorMaximoS));
        }
        
    } catch (Exception ex){
        hayErrores = true;
        JOptionPane.showMessageDialog(null, "Los campos \"Valor Minimo\" y \"Valor Maximo\" deben ser numéricos", "Error", JOptionPane.ERROR_MESSAGE);
    }
    
    if(!hayErrores){
        Double resultadoFormula = ndac.evaluar(Util.convertirComaAPunto(tFormula.getText()), Constantes.DECIMALES2, true);
        if(resultadoFormula != null){
            Double resDefinitivo;
            
            if(minimo != null && resultadoFormula < minimo){
                resDefinitivo = minimo;
            } else if(maximo != null && resultadoFormula > maximo){
                resDefinitivo = maximo;
            } else {
                resDefinitivo = resultadoFormula;
            }
            
            JOptionPane.showMessageDialog(null, Util.convertirPuntoAComa(resDefinitivo.toString()), "Resultado", JOptionPane.INFORMATION_MESSAGE);
            tValor.setText(resDefinitivo.toString());
        } else {
            tValor.setText("0");
        }
    }
}//GEN-LAST:event_bEvaluarFormulaActionPerformed

private void bSeleccionarVariableActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bSeleccionarVariableActionPerformed
    SeleccionarVariable sv = new SeleccionarVariable(this, "Variable - Seleccionar", this.tFormula);
    sv.setDefaultCloseOperation(SeleccionarVariable.DISPOSE_ON_CLOSE);
    sv.setLocationRelativeTo(null);
    sv.setVisible(true);
}//GEN-LAST:event_bSeleccionarVariableActionPerformed

private void tNombreKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tNombreKeyReleased
    String nombre = tNombre.getText();
    if(nombre.length() > Constantes.TAM_NOMBRE_VARIABLE){
        JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_NOMBRE_VARIABLE, "Error", JOptionPane.ERROR_MESSAGE);
        tNombre.setText(nombre.substring(0, Constantes.TAM_NOMBRE_VARIABLE));
    }
}//GEN-LAST:event_tNombreKeyReleased

private void tFormulaKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tFormulaKeyReleased
    String formula = tFormula.getText();
    if(formula.length() > Constantes.TAM_FORMULA_VARIABLE){
        JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_FORMULA_VARIABLE, "Error", JOptionPane.ERROR_MESSAGE);
        tFormula.setText(formula.substring(0, Constantes.TAM_FORMULA_VARIABLE));
    }
}//GEN-LAST:event_tFormulaKeyReleased

private void tCondicionKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tCondicionKeyReleased
    String condicion = tCondicion.getText();
    if(condicion.length() > Constantes.TAM_CONDICION_VARIABLE){
        JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_CONDICION_VARIABLE, "Error", JOptionPane.ERROR_MESSAGE);
        tCondicion.setText(condicion.substring(0, Constantes.TAM_CONDICION_VARIABLE));
    }
}//GEN-LAST:event_tCondicionKeyReleased

private void tValorKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tValorKeyReleased
    int tamaño = tValor.getText().length();
    if (tamaño > 0) {
        char c = tValor.getText().charAt(tamaño - 1);
        
        if(c == '.'){
            String contenidoAntiguo = tValor.getText().replace(".", ",");
            tValor.setText(contenidoAntiguo);
            c = ',';
        }
        
        if (!((c >= '0' && c <= '9') || c == ',')) {
            String str = tValor.getText().substring(0, tamaño - 1);
            tValor.setText(str);
        } else if (c == ',') {
            int indicePunto = tValor.getText().indexOf(',');
            if (indicePunto != (tamaño - 1)) {
                String str = tValor.getText().substring(0, tamaño - 1);
                tValor.setText(str);
            }
        }
    }
}//GEN-LAST:event_tValorKeyReleased

private void tValorMinimoKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tValorMinimoKeyReleased
    int tamaño = tValorMinimo.getText().length();
    if (tamaño > 0) {
        char c = tValorMinimo.getText().charAt(tamaño - 1);
        
        if(c == '.'){
            String contenidoAntiguo = tValorMinimo.getText().replace(".", ",");
            tValorMinimo.setText(contenidoAntiguo);
            c = ',';
        }
        
        if (!((c >= '0' && c <= '9') || c == ',')) {
            String str = tValorMinimo.getText().substring(0, tamaño - 1);
            tValorMinimo.setText(str);
        } else if (c == ',') {
            int indicePunto = tValorMinimo.getText().indexOf(',');
            if (indicePunto != (tamaño - 1)) {
                String str = tValorMinimo.getText().substring(0, tamaño - 1);
                tValorMinimo.setText(str);
            }
        }
    }
}//GEN-LAST:event_tValorMinimoKeyReleased

private void tValorMaximoKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tValorMaximoKeyReleased
    int tamaño = tValorMaximo.getText().length();
    if (tamaño > 0) {
        char c = tValorMaximo.getText().charAt(tamaño - 1);
        
        if(c == '.'){
            String contenidoAntiguo = tValorMaximo.getText().replace(".", ",");
            tValorMaximo.setText(contenidoAntiguo);
            c = ',';
        }
        
        if (!((c >= '0' && c <= '9') || c == ',')) {
            String str = tValorMaximo.getText().substring(0, tamaño - 1);
            tValorMaximo.setText(str);
        } else if (c == ',') {
            int indicePunto = tValorMaximo.getText().indexOf(',');
            if (indicePunto != (tamaño - 1)) {
                String str = tValorMaximo.getText().substring(0, tamaño - 1);
                tValorMaximo.setText(str);
            }
        }
    }
}//GEN-LAST:event_tValorMaximoKeyReleased

private void bSeleccionarVariableCondicionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bSeleccionarVariableCondicionActionPerformed
    SeleccionarVariable sv = new SeleccionarVariable(this, "Variable - Seleccionar", this.tCondicion);
    sv.setDefaultCloseOperation(SeleccionarVariable.DISPOSE_ON_CLOSE);
    sv.setLocationRelativeTo(null);
    sv.setVisible(true);
}//GEN-LAST:event_bSeleccionarVariableCondicionActionPerformed

public List<Variable> getListaVbles() {
    return ndac.getListaVbles();
}

public int getNumeroDimensiones() {
    return ndac.getNumeroDimensiones();
}

public void insertarValorFormula(String variable, javax.swing.JTextArea medida){
    medida.insert(variable, medida.getCaretPosition());
}

    private int indiceSeleccionPorNombre(String nombre){
        int indiceBorrar = -1;
        int indice = 0;
        Iterator<Seleccion> iter = this.listaSeleccion.iterator();
        boolean seguir = true;
        Seleccion sel;
        while(seguir && iter.hasNext()){
            sel = iter.next();
            if(sel.getNombre().equalsIgnoreCase(nombre)){
                seguir = false;
                indiceBorrar = indice;
            } else {
                indice++;
            }
        }
        return indiceBorrar;
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JCheckBox bActivarMaximo;
    private javax.swing.JCheckBox bActivarMinimo;
    private javax.swing.JCheckBox bActivarPeticion;
    private javax.swing.JButton bBorrarSeleccion;
    private javax.swing.JButton bCrearSeleccion;
    private javax.swing.JCheckBox bEditarFormula;
    private javax.swing.JButton bEditarSeleccion;
    private javax.swing.JButton bEvaluarFormula;
    private javax.swing.JButton bSeleccionarVariable;
    private javax.swing.JButton bSeleccionarVariableCondicion;
    private javax.swing.JButton baceptar;
    private javax.swing.JButton bcancelar;
    private javax.swing.JButton bmodificar;
    private javax.swing.JComboBox cSeleccion;
    private javax.swing.JComboBox cTipo;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel lCondicion;
    private javax.swing.JLabel lFormula;
    private javax.swing.JLabel lMaximo;
    private javax.swing.JLabel lNombre;
    private javax.swing.JLabel lNombre1;
    private javax.swing.JLabel lSeleccion;
    private javax.swing.JLabel lTipo;
    private javax.swing.JLabel lValor;
    private javax.swing.JPanel pCalculada;
    private javax.swing.JPanel pSeleccion;
    private javax.swing.JTextArea tCondicion;
    private javax.swing.JTextArea tFormula;
    private javax.swing.JTextField tNombre;
    private javax.swing.JTextField tValor;
    private javax.swing.JTextField tValorMaximo;
    private javax.swing.JTextField tValorMinimo;
    // End of variables declaration//GEN-END:variables
}
