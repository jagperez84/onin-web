package gui;

import acceso.BaseDatos;
import bean.Agentes;
import bean.ClaseDocumento;
import bean.Contactos;
import bean.Empresa;
import bean.EstadoDocumento;
import bean.Presupuesto;
import bean.Usuario;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JOptionPane;
import javax.swing.KeyStroke;
import matematico.Matematico;
import modelo.Modelo;
import util.Constantes;
import util.Util;

public class ListaClientes extends javax.swing.JFrame {

    private String tipo;
    private Empresa e;
    private List pc;
    private List<Presupuesto> lPresupuesto;
    private Usuario u;

    public ListaClientes() {
        super("Agente - Mantenimiento");
        initComponents();
        //pContactos.setVisible(false);
        //pDocumentos.setVisible(false);
        //pDatos.setVisible(false);
        pDatos.disable();
        crearIconosBotones();
        crearAcciones();
        fInicio.setDateFormatString("dd/MM/yyyy");
        fFin.setDateFormatString("dd/MM/yyyy");
    }

    public ListaClientes(String tipo, Empresa e, Usuario u) {
        super("Agente - Mantenimiento");
        if (tipo.equals("cli")) {
            this.setTitle("Cliente - Mantenimiento");
        } else if (tipo.equals("prov")) {
            this.setTitle("Proveedor - Mantenimiento");
        }
        this.tipo = tipo;
        this.e = e;
        this.u = u;

        initComponents();

        fInicio.setDateFormatString("dd/MM/yyyy");
        fFin.setDateFormatString("dd/MM/yyyy");

        //pContactos.setVisible(false);
        //pDocumentos.setVisible(false);
        //pDatos.setVisible(false);
        pDatos.disable();

        crearIconosBotones();
        crearAcciones();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        grupo = new javax.swing.ButtonGroup();
        bcrear = new javax.swing.JButton();
        bborrar = new javax.swing.JButton();
        bvisualizar = new javax.swing.JButton();
        bcerrar = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        jPanel2 = new javax.swing.JPanel();
        rComercial = new javax.swing.JRadioButton();
        rDireccion = new javax.swing.JRadioButton();
        rFiscal = new javax.swing.JRadioButton();
        tbusqueda1 = new javax.swing.JTextField();
        rCodigo = new javax.swing.JRadioButton();
        rTelefono = new javax.swing.JRadioButton();
        pContactos = new javax.swing.JPanel();
        jScrollPane7 = new javax.swing.JScrollPane();
        Modelo modelo2 = new Modelo();
        tcontacto = new javax.swing.JTable(modelo2);
        pDocumentos = new javax.swing.JPanel();
        jScrollPane6 = new javax.swing.JScrollPane();
        Modelo modelo3 = new Modelo();
        tdocumento = new javax.swing.JTable(modelo3);
        pDatos = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        tNumero = new javax.swing.JTextField();
        tImporte = new javax.swing.JTextField();
        pPeriodo = new javax.swing.JPanel();
        bRango = new javax.swing.JButton();
        jLabel14 = new javax.swing.JLabel();
        fInicio = new com.toedter.calendar.JDateChooser();
        jLabel15 = new javax.swing.JLabel();
        fFin = new com.toedter.calendar.JDateChooser();
        lDocumentos = new javax.swing.JComboBox();
        jLabel3 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        Modelo modelo = new Modelo();
        tcliente1 = new javax.swing.JTable(modelo);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        bcrear.setToolTipText("Crear (F1)");
        bcrear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bcrearActionPerformed(evt);
            }
        });

        bborrar.setToolTipText("Borrar (F2)");
        bborrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bborrarActionPerformed(evt);
            }
        });

        bvisualizar.setToolTipText("Visualizar (F3)");
        bvisualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bvisualizarActionPerformed(evt);
            }
        });

        bcerrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bcerrarActionPerformed(evt);
            }
        });

        grupo.add(rComercial);
        rComercial.setSelected(true);
        rComercial.setText("N. Comercial");
        rComercial.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rComercialActionPerformed(evt);
            }
        });

        grupo.add(rDireccion);
        rDireccion.setText("Dirección");
        rDireccion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rDireccionActionPerformed(evt);
            }
        });

        grupo.add(rFiscal);
        rFiscal.setText("N. Fiscal");
        rFiscal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rFiscalActionPerformed(evt);
            }
        });

        tbusqueda1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tbusqueda1KeyReleased(evt);
            }
        });

        grupo.add(rCodigo);
        rCodigo.setText("Código");
        rCodigo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rCodigoActionPerformed(evt);
            }
        });

        grupo.add(rTelefono);
        rTelefono.setText("Teléfono");
        rTelefono.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rTelefonoActionPerformed(evt);
            }
        });

        pContactos.setBorder(javax.swing.BorderFactory.createTitledBorder("Contactos"));

        modelo2.addColumn("Nombre");
        modelo2.addColumn("Apellidos");
        modelo2.addColumn("Cargo");
        modelo2.addColumn("Departamento");
        modelo2.addColumn("Email");
        modelo2.addColumn("Teléfono");
        modelo2.addColumn("Móvil");
        tcontacto.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        Object[] fila2;
        if ((pc != null)&&(pc.size()>0)){
            Contactos c1;
            Iterator it2 = pc.iterator();

            if(pc != null){
                for (it2 = pc.iterator(); it2.hasNext();) {
                    fila2 = new Object[7];
                    c1 = (Contactos) it2.next();
                    fila2[0] = c1.getNombre();
                    fila2[1] = c1.getApellidos();
                    fila2[2] = c1.getCargo();
                    fila2[3] = c1.getDepartamento();
                    fila2[4] = c1.getEmail();
                    fila2[5] = c1.getTelefono();
                    fila2[6] = c1.getMovil();

                    modelo2.addRow(fila2);
                }
            }

            tcontacto.getColumnModel().getColumn(0).setPreferredWidth(100);
            tcontacto.getColumnModel().getColumn(1).setPreferredWidth(120);
            tcontacto.getColumnModel().getColumn(2).setPreferredWidth(100);
            tcontacto.getColumnModel().getColumn(3).setPreferredWidth(100);
            tcontacto.getColumnModel().getColumn(4).setPreferredWidth(180);
            tcontacto.getColumnModel().getColumn(5).setPreferredWidth(70);
            tcontacto.getColumnModel().getColumn(6).setPreferredWidth(80);

        }
        jScrollPane7.setViewportView(tcontacto);

        org.jdesktop.layout.GroupLayout pContactosLayout = new org.jdesktop.layout.GroupLayout(pContactos);
        pContactos.setLayout(pContactosLayout);
        pContactosLayout.setHorizontalGroup(
            pContactosLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jScrollPane7, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 371, Short.MAX_VALUE)
        );
        pContactosLayout.setVerticalGroup(
            pContactosLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jScrollPane7, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 295, Short.MAX_VALUE)
        );

        pDocumentos.setBorder(javax.swing.BorderFactory.createTitledBorder("Documentos"));

        modelo3.addColumn("Documento");
        modelo3.addColumn("Número");
        modelo3.addColumn("Serie");
        modelo3.addColumn("Fecha");
        modelo3.addColumn("Imp. Total");
        modelo3.addColumn("Estado");

        SimpleDateFormat formatoFecha = new SimpleDateFormat("dd/MM/yyyy");

        if (lPresupuesto!=null){
            Object [] fila;
            Iterator it;
            for (it = lPresupuesto.iterator(); it.hasNext();) {
                fila = (Object [])it.next();
                fila[3] = formatoFecha.format(fila[3]);
                fila[4] = Util.convertirPuntoAComa(String.valueOf((Double)fila[4]));
                modelo3.addRow(fila);
            }

            tdocumento.getColumnModel().getColumn(0).setPreferredWidth(200);
            tdocumento.getColumnModel().getColumn(1).setPreferredWidth(90);
            tdocumento.getColumnModel().getColumn(2).setPreferredWidth(120);
            tdocumento.getColumnModel().getColumn(3).setPreferredWidth(100);
            tdocumento.getColumnModel().getColumn(4).setPreferredWidth(87);
            tdocumento.getColumnModel().getColumn(5).setPreferredWidth(200);
        }
        tdocumento.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        tdocumento.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tdocumentoMouseClicked(evt);
            }
        });
        tdocumento.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tdocumentoKeyPressed(evt);
            }
        });
        jScrollPane6.setViewportView(tdocumento);

        pDatos.setBorder(javax.swing.BorderFactory.createTitledBorder("Información adicional"));

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 12));
        jLabel1.setText("Número de Documentos:");

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 12));
        jLabel2.setText("Importe total documentos:");

        tNumero.setFont(new java.awt.Font("Lucida Sans Typewriter", 3, 12));
        tNumero.setEnabled(false);

        tImporte.setFont(new java.awt.Font("Lucida Sans Typewriter", 3, 12));
        tImporte.setEnabled(false);

        pPeriodo.setBorder(javax.swing.BorderFactory.createTitledBorder("Periodo"));

        bRango.setText("Ir");
        bRango.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bRangoActionPerformed(evt);
            }
        });

        jLabel14.setFont(new java.awt.Font("Tahoma", 1, 14));
        jLabel14.setText("Desde:");

        jLabel15.setFont(new java.awt.Font("Tahoma", 1, 14));
        jLabel15.setText("Hasta:");

        org.jdesktop.layout.GroupLayout pPeriodoLayout = new org.jdesktop.layout.GroupLayout(pPeriodo);
        pPeriodo.setLayout(pPeriodoLayout);
        pPeriodoLayout.setHorizontalGroup(
            pPeriodoLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(pPeriodoLayout.createSequentialGroup()
                .add(jLabel14)
                .add(12, 12, 12)
                .add(fInicio, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jLabel15)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(fFin, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(bRango, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 51, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
        );
        pPeriodoLayout.setVerticalGroup(
            pPeriodoLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jLabel14)
            .add(fFin, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
            .add(jLabel15)
            .add(fInicio, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
            .add(bRango)
        );

        org.jdesktop.layout.GroupLayout pDatosLayout = new org.jdesktop.layout.GroupLayout(pDatos);
        pDatos.setLayout(pDatosLayout);
        pDatosLayout.setHorizontalGroup(
            pDatosLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(pPeriodo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
            .add(pDatosLayout.createSequentialGroup()
                .addContainerGap()
                .add(pDatosLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jLabel2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 176, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(jLabel1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 161, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(pDatosLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                    .add(tImporte)
                    .add(tNumero, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 98, Short.MAX_VALUE)))
        );
        pDatosLayout.setVerticalGroup(
            pDatosLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(pDatosLayout.createSequentialGroup()
                .add(pPeriodo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(pDatosLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(jLabel1)
                    .add(tNumero, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 16, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(pDatosLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(jLabel2)
                    .add(tImporte, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 15, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
        );

        lDocumentos.addItem("Todos");
        if (this.tipo.equals("cli")){
            lDocumentos.addItem(Constantes.PRESUPUESTO);
            lDocumentos.addItem(Constantes.PEDIDO);
            lDocumentos.addItem(Constantes.ALBARAN);
            lDocumentos.addItem(Constantes.FACTURA);
        }else if (this.tipo.equals("prov")) {
            lDocumentos.addItem(Constantes.PEDIDOC);
            lDocumentos.addItem(Constantes.ALBARANC);
        }
        lDocumentos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                lDocumentosActionPerformed(evt);
            }
        });

        jLabel3.setText("Clase documento");

        org.jdesktop.layout.GroupLayout pDocumentosLayout = new org.jdesktop.layout.GroupLayout(pDocumentos);
        pDocumentos.setLayout(pDocumentosLayout);
        pDocumentosLayout.setHorizontalGroup(
            pDocumentosLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(pDocumentosLayout.createSequentialGroup()
                .add(jScrollPane6, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 385, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(pDocumentosLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(pDocumentosLayout.createSequentialGroup()
                        .add(jLabel3)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(lDocumentos, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 167, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                    .add(pDatos, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(12, Short.MAX_VALUE))
        );
        pDocumentosLayout.setVerticalGroup(
            pDocumentosLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jScrollPane6, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 169, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
            .add(pDocumentosLayout.createSequentialGroup()
                .add(pDocumentosLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(jLabel3)
                    .add(lDocumentos, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(pDatos, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
        );

        modelo.addColumn("N. Comercial");
        modelo.addColumn("Código");
        modelo.addColumn("N. Fiscal");
        modelo.addColumn("Dirección");
        modelo.addColumn("Población");
        modelo.addColumn("Provincia");
        modelo.addColumn("Pais");
        modelo.addColumn("Teléfono");
        modelo.addColumn("Teléfono 2");
        modelo.addColumn("Teléfono 3");
        modelo.addColumn("Fax");
        modelo.addColumn("E-mail");
        modelo.addColumn("CIF/DNI");
        modelo.addColumn("");

        List lagentes = null;

        if (tipo.equals("cli")){
            lagentes = BaseDatos.getListaClientesReducido(e.getIid());
        }else if (tipo.equals("prov")){
            lagentes = BaseDatos.getListaProveedoresReducido(e.getIid());
        }

        Iterator it1;
        if(lagentes != null){
            for (it1 = lagentes.iterator(); it1.hasNext();) {
                modelo.addRow((Object[]) it1.next());
            }
        }

        tcliente1.getColumnModel().getColumn(0).setPreferredWidth(230);
        tcliente1.getColumnModel().getColumn(1).setPreferredWidth(80);
        tcliente1.getColumnModel().getColumn(2).setPreferredWidth(150);
        tcliente1.getColumnModel().getColumn(3).setPreferredWidth(150);
        tcliente1.getColumnModel().getColumn(4).setPreferredWidth(70);
        tcliente1.getColumnModel().getColumn(5).setPreferredWidth(70);
        tcliente1.getColumnModel().getColumn(6).setPreferredWidth(80);
        tcliente1.getColumnModel().getColumn(7).setPreferredWidth(80);
        tcliente1.getColumnModel().getColumn(8).setPreferredWidth(80);
        tcliente1.getColumnModel().getColumn(9).setPreferredWidth(80);
        tcliente1.getColumnModel().getColumn(10).setPreferredWidth(80);
        tcliente1.getColumnModel().getColumn(11).setPreferredWidth(150);
        tcliente1.getColumnModel().getColumn(12).setPreferredWidth(80);
        tcliente1.getColumnModel().getColumn(13).setWidth(0);
        tcliente1.getColumnModel().getColumn(13).setMaxWidth(0);
        tcliente1.getColumnModel().getColumn(13).setMinWidth(0);
        tcliente1.getColumnModel().getColumn(13).setPreferredWidth(0);
        tcliente1.getColumnModel().getColumn(13).setResizable(false);
        tcliente1.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        tcliente1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tcliente1MouseClicked(evt);
            }
        });
        tcliente1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tcliente1KeyPressed(evt);
            }
        });
        jScrollPane1.setViewportView(tcliente1);

        org.jdesktop.layout.GroupLayout jPanel3Layout = new org.jdesktop.layout.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jScrollPane1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 411, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, jScrollPane1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 322, Short.MAX_VALUE)
        );

        org.jdesktop.layout.GroupLayout jPanel2Layout = new org.jdesktop.layout.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jPanel2Layout.createSequentialGroup()
                        .add(pDocumentos, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap())
                    .add(jPanel2Layout.createSequentialGroup()
                        .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(tbusqueda1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 411, Short.MAX_VALUE)
                            .add(jPanel3, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(jPanel2Layout.createSequentialGroup()
                                .add(rComercial)
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                .add(rFiscal)
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                .add(rCodigo)
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                .add(rTelefono)
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                .add(rDireccion))
                            .add(jPanel2Layout.createSequentialGroup()
                                .add(2, 2, 2)
                                .add(pContactos, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                        .addContainerGap())))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(tbusqueda1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(rComercial)
                    .add(rFiscal)
                    .add(rCodigo)
                    .add(rTelefono)
                    .add(rDireccion))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(pContactos, 0, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .add(jPanel3, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(pDocumentos, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
        );

        jScrollPane2.setViewportView(jPanel2);

        org.jdesktop.layout.GroupLayout layout = new org.jdesktop.layout.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, layout.createSequentialGroup()
                .addContainerGap(637, Short.MAX_VALUE)
                .add(bcrear, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 42, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(bborrar, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 41, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(bvisualizar, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 43, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(bcerrar, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 46, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
            .add(jScrollPane2, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 837, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, layout.createSequentialGroup()
                .add(jScrollPane2, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 579, Short.MAX_VALUE)
                .add(10, 10, 10)
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                    .add(bcerrar, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 31, Short.MAX_VALUE)
                    .add(bvisualizar, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .add(bcrear, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .add(bborrar, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void crearAcciones() {
        KeyStroke escapeKeyStroke = KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false);
        Action escapeAction = new AbstractAction() {
            public void actionPerformed(ActionEvent e) {
                cerrarListado();
            }
        };
        getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(escapeKeyStroke, "ESCAPE");
        getRootPane().getActionMap().put("ESCAPE", escapeAction);

        KeyStroke f1KeyStroke = KeyStroke.getKeyStroke(KeyEvent.VK_F1, 0, false);
        Action f1Action = new AbstractAction() {
            public void actionPerformed(ActionEvent ev) {
                crearAgente();
            }
        };
        getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(f1KeyStroke, "F1");
        getRootPane().getActionMap().put("F1", f1Action);
        
        KeyStroke enterKeyStroke = KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0, false);
        Action enterAction = new AbstractAction() {
            public void actionPerformed(ActionEvent ev) {
               if (fInicio.getDate()!=null){
                  calculoImporte();
               }
            }
        };
        getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(enterKeyStroke, "Enter");
        getRootPane().getActionMap().put("Enter", enterAction);
        
        Dimension dim = Util.getDimensiones(this.getSize());
        if(dim != null){
            setResizable(true);
            setSize(dim);
        }
    }

    private void cerrarListado() {
        removeAll();
        dispose();
    }

    private void obtenerResultado() {

        if (rComercial.isSelected()) {
            String nombre = tbusqueda1.getText().toLowerCase();
            List lc = BaseDatos.busquedaRapidaAgentesPorNombreComercialReducido(nombre, tipo, e.getIid());
            actualizarClientes1(lc);
        } else if (rFiscal.isSelected()) {
            String nombre = tbusqueda1.getText().toLowerCase();
            List lc = BaseDatos.busquedaRapidaClientesPorNombreFiscalReducido(nombre, tipo, e.getIid());
            actualizarClientes1(lc);
        } else if (rCodigo.isSelected()) {
            String nombre = tbusqueda1.getText().toLowerCase();
            List lc = BaseDatos.busquedaRapidaClientesPorCodigoReducido(nombre, tipo, e.getIid());
            actualizarClientes1(lc);
        } else if (rTelefono.isSelected()) {
            String nombre = tbusqueda1.getText().toLowerCase();
            List lc = BaseDatos.busquedaRapidaClientesPorTelefonoReducido(nombre, tipo, e.getIid());
            actualizarClientes1(lc);
        } else if (rDireccion.isSelected()) {
            String nombre = tbusqueda1.getText().toLowerCase();
            List lc = BaseDatos.busquedaRapidaClientesPorDireccionReducida(nombre, tipo, e.getIid());
            actualizarClientes1(lc);
        }
    }
private void bcrearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bcrearActionPerformed
    crearAgente();
}//GEN-LAST:event_bcrearActionPerformed

private void bborrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bborrarActionPerformed
    borrarAgente();
}//GEN-LAST:event_bborrarActionPerformed

    private void crearAgente() {
        NuevoCliente np = null;

        if (tipo.equals("cli")) {
            np = new NuevoCliente("Cliente - Creación", tipo, e);
        } else if (tipo.equals("prov")) {
            np = new NuevoCliente("Proveedor - Creación", tipo, e);
        }

        np.setDefaultCloseOperation(NuevoCliente.DISPOSE_ON_CLOSE);
        np.setLocationRelativeTo(null);
        np.setVisible(true);
        cerrarListado();
    }

    private void borrarAgente() {
        try {
            int indiceFila = this.tcliente1.getSelectedRow();
            if (indiceFila >= 0) {

                int eliminar = 1;
                eliminar = JOptionPane.showConfirmDialog(null, "¿Está seguro de que desea eliminar el elemento seleccionado?", "¿Eliminar?", JOptionPane.YES_NO_OPTION);
                //hacerCambios = -1 ==> se ha pulsado la "x" de cancelar;
                //hacerCambios =  0 ==> se ha pulsado el "sí"
                //hacerCambios =  1 ==> se ha pulsado el "no"

                if (eliminar == 0) {

                    //obtenemos el codigo del cliente
                    String codigo = codigo = (String) tcliente1.getModel().getValueAt(indiceFila, 1);
                    Agentes a = BaseDatos.obtenerAgentesPorCodigo(codigo, tipo, e);

                    if (BaseDatos.eliminarElemento(a.getClass(), a.getIid())) {
                        completarPantalla();
                    } else {
                        JOptionPane.showMessageDialog(null, "No se ha podido eliminar el elemento seleccionado", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
            } else {
                JOptionPane.showMessageDialog(null, "No hay seleccionado ningún elemento", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Este elemento no se puede eliminar", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

private void bvisualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bvisualizarActionPerformed
    visualizarAgente();
}//GEN-LAST:event_bvisualizarActionPerformed

private void bcerrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bcerrarActionPerformed
    cerrarListado();
}//GEN-LAST:event_bcerrarActionPerformed

    private void rDireccionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rDireccionActionPerformed
        obtenerResultado();
    }//GEN-LAST:event_rDireccionActionPerformed

    private void rTelefonoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rTelefonoActionPerformed
        obtenerResultado();
    }//GEN-LAST:event_rTelefonoActionPerformed

    private void rCodigoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rCodigoActionPerformed
        obtenerResultado();
    }//GEN-LAST:event_rCodigoActionPerformed

    private void rFiscalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rFiscalActionPerformed
        obtenerResultado();
    }//GEN-LAST:event_rFiscalActionPerformed

    private void rComercialActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rComercialActionPerformed
        obtenerResultado();
    }//GEN-LAST:event_rComercialActionPerformed

    private void tdocumentoKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tdocumentoKeyPressed
        if (evt.getKeyChar() == KeyEvent.VK_ENTER) {
            visualizarDocumento();
        }
    }//GEN-LAST:event_tdocumentoKeyPressed

    private void tdocumentoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tdocumentoMouseClicked
        if (evt.getClickCount() == 2) {
            visualizarDocumento();
        }
    }//GEN-LAST:event_tdocumentoMouseClicked

    private void visualizarDocumento() {
        //obtenemos el número del documento
        int indiceFila = this.tdocumento.getSelectedRow();

        String numero = (String) tdocumento.getModel().getValueAt(indiceFila, 1);
        String cDocumento = (String) tdocumento.getModel().getValueAt(indiceFila, 0);

        Presupuesto p = BaseDatos.obtenerPresupuestoPorNumeroPorClaseDocumento(numero, cDocumento, e);

        NuevoPresupuesto np = new NuevoPresupuesto(e, p, u, null);
        np.setDefaultCloseOperation(NuevoPresupuesto.DISPOSE_ON_CLOSE);
        np.setLocationRelativeTo(null);
        np.setVisible(true);
    }
    
    private void tcliente1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tcliente1KeyPressed
        if (evt.getKeyChar() == KeyEvent.VK_ENTER) {
            visualizarAgente();
        } else if (evt.getKeyChar() == KeyEvent.VK_DELETE) {
            borrarAgente();
        } else {
            cargarContactos();
            cargarDocumentos();
        }
    }//GEN-LAST:event_tcliente1KeyPressed

    private void tcliente1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tcliente1MouseClicked
        if (evt.getClickCount() == 2) {
            visualizarAgente();
        } else {
            cargarContactos();
            cargarDocumentos();
        }
    }//GEN-LAST:event_tcliente1MouseClicked

    private void tbusqueda1KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tbusqueda1KeyReleased
        //pContactos.setVisible(false);
        //pDocumentos.setVisible(false);
        obtenerResultado();
    }//GEN-LAST:event_tbusqueda1KeyReleased

    private void lDocumentosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_lDocumentosActionPerformed

        Double importe = 0.0;
        Object[] elemento;
        Iterator it;
        
        ClaseDocumento cd = BaseDatos.getClaseDocumentosByDescripcion((String) lDocumentos.getSelectedItem());
        
        int indiceFila = this.tcliente1.getSelectedRow();
        String codigoAgente = (String) tcliente1.getModel().getValueAt(indiceFila, 1);
        
        if (cd != null) {

            
            lPresupuesto = BaseDatos.getListaPresupuestoByIdAgenteyClase(codigoAgente, cd.getIid());
            it = lPresupuesto.iterator();

            //pDatos.setVisible(true);
            pDatos.setEnabled(true);
            tNumero.setText(String.valueOf(lPresupuesto.size()));

            for (it = lPresupuesto.iterator(); it.hasNext();) {
                elemento = (Object[]) it.next();
                importe += (Double) elemento[4];
            }

            tImporte.setText(Util.convertirPuntoAComa(String.valueOf(Matematico.redondear2decimales(importe)) + " €"));
        } else {
            //lPresupuesto = BaseDatos.getListaPresupuestoByIdAgente(a.getCod_agente(),e.getIid());
            lPresupuesto = BaseDatos.getListaPresupuestoByIdAgenteReducido(codigoAgente, e.getIid());
            //pDatos.setVisible(false);
            pDatos.disable();
        }

        Modelo modelo = (Modelo) tdocumento.getModel();
        int j = modelo.getRowCount();
        for (int i = 0; i < j; i++) {
            modelo.removeRow(0);
        }

        SimpleDateFormat formatoFecha = new SimpleDateFormat("dd/MM/yyyy");

        Object[] fila;
        it = lPresupuesto.iterator();

        if (lPresupuesto != null) {
            for (it = lPresupuesto.iterator(); it.hasNext();) {
                fila = (Object[]) it.next();
                fila[3] = formatoFecha.format(fila[3]);
                modelo.addRow(fila);
            }
        }
    }//GEN-LAST:event_lDocumentosActionPerformed

    private void bRangoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bRangoActionPerformed
        calculoImporte();
    }//GEN-LAST:event_bRangoActionPerformed
    
    private void calculoImporte() {
        //Filtrar por documentos y fecha
        int indiceFila = -1;
        int i = 0;
        Presupuesto p1;
        Double importe = 0.0;

        if (fInicio.getDate() == null) {
            JOptionPane.showMessageDialog(null, "Indicar fecha de selección", "Error", JOptionPane.ERROR_MESSAGE);
        }

        if (fFin.getDate() == null) {
            fFin.setDate(fInicio.getDate());
        }

        String codigo = "";
        indiceFila = this.tcliente1.getSelectedRow();
        codigo = (String) tcliente1.getModel().getValueAt(indiceFila, 1);
        ClaseDocumento cd = BaseDatos.getClaseDocumentosByDescripcion((String) lDocumentos.getSelectedItem());
        Agentes a = BaseDatos.obtenerAgentePorEmpresaYCodigo(e.getIid(), codigo);
        if (cd != null) {
            lPresupuesto = BaseDatos.getListaPresupuestoByIdAgenteyClaseyFecha(a.getCod_agente(), cd, fInicio.getDate().getTime(), fFin.getDate().getTime());

            Iterator itI = lPresupuesto.iterator();

            //pDatos.setVisible(true);
            pDatos.enable();
            tNumero.setText(String.valueOf(lPresupuesto.size()));

            //Cálculo del importe total
            for (itI = lPresupuesto.iterator(); itI.hasNext();) {
                p1 = (Presupuesto) itI.next();
                importe = importe + p1.getImporte_total();
            }

            tImporte.setText(Util.convertirPuntoAComa(String.valueOf(Matematico.redondear2decimales(importe)) + " €"));


        } else {
            //pDatos.setVisible(false);
            pDatos.disable();
        }

        Modelo modelo = (Modelo) tdocumento.getModel();
        
        //obtenemos el nº de filas;
        int j = modelo.getRowCount();
        
        //eliminamos todas las filas
        for (i = 0; i < j; i++) {
            modelo.removeRow(0);
        }

        SimpleDateFormat formatoFecha = new SimpleDateFormat("dd/MM/yyyy");
        Date fecha = null;

        Object[] fila3;
        Iterator it2 = lPresupuesto.iterator();
        Integer cdId;
        HashMap<Integer, String> listaCd = new HashMap<Integer, String>();
        ClaseDocumento cdl = new ClaseDocumento();

        HashMap<Integer, String> listaEst = new HashMap<Integer, String>();
        Integer estId;
        EstadoDocumento es = new EstadoDocumento();

        if (lPresupuesto != null) {
            for (it2 = lPresupuesto.iterator(); it2.hasNext();) {
                fila3 = new Object[6];

                p1 = (Presupuesto) it2.next();
                fecha = new Date(p1.getFecha());

                cdId = p1.getClase_documento().getIid();
                if (listaCd.containsKey(cdId)) {
                    fila3[0] = listaCd.get(cdId);
                } else {
                    cdl = BaseDatos.getClaseDocumentosByIid(cdId);
                    listaCd.put(cdId, cdl.getDescripcion());
                    fila3[0] = cdl.getDescripcion();
                }

                fila3[1] = p1.getNumero();
                fila3[2] = p1.getSerie();
                fila3[3] = formatoFecha.format(fecha);
                fila3[4] = Util.convertirPuntoAComa(String.valueOf(Matematico.redondear2decimales(p1.getImporte_total())));

                estId = p1.getEstado().getIid();
                if (listaEst.containsKey(estId)) {
                    fila3[5] = listaEst.get(estId);
                } else {
                    es = BaseDatos.obtenerEstadoPorIid(estId);
                    listaEst.put(estId, es.getDescripcion());
                    fila3[5] = es.getDescripcion();
                }
                modelo.addRow(fila3);
            }
        }
    }

    private void cargarContactos() {
        
        int indiceFila = this.tcliente1.getSelectedRow();
        Integer iidAgente = (Integer) tcliente1.getModel().getValueAt(indiceFila, 13);
        
        pc = BaseDatos.getContactoAgenteReducido(iidAgente);
        
//        if (pc.size() > 0) {
//            pContactos.setVisible(true);
//        } else {
//            pContactos.setVisible(false);
//        }
        Modelo modelo = (Modelo) tcontacto.getModel();
        
        int j = modelo.getRowCount();
        for (int i = 0; i < j; i++) {
            modelo.removeRow(0);
        }

        Iterator it = pc.iterator();
        if (pc != null) {
            for (it = pc.iterator(); it.hasNext();) {
                modelo.addRow((Object[]) it.next());
            }
        }
    }

    private void cargarDocumentos() {
        
        int indiceFila = this.tcliente1.getSelectedRow();
        String codigoAgente = (String) tcliente1.getModel().getValueAt(indiceFila, 1);
        lPresupuesto = BaseDatos.getListaPresupuestoByIdAgenteReducido(codigoAgente, e.getIid());
        
        if (lPresupuesto.size() > 0) {
            //pDocumentos.setVisible(true);
            //pDatos.setVisible(true);
            pDatos.setEnabled(true);
        } else {
            //pDocumentos.setVisible(false);
            //pDatos.setVisible(false);
            pDatos.disable();
        }
        
        Modelo modelo = (Modelo) tdocumento.getModel();
        //obtenemos el nº de filas;
        int j = modelo.getRowCount();
        int i = 0;

        //eliminamos todas las filas
        for (i = 0; i < j; i++) {
            modelo.removeRow(0);
        }

        Object[] elemento;
        Iterator it = lPresupuesto.iterator();
        SimpleDateFormat formatoFecha = new SimpleDateFormat("dd/MM/yyyy");

        if (lPresupuesto != null) {
            for (it = lPresupuesto.iterator(); it.hasNext();) {
                elemento = (Object[]) it.next();
                elemento[3] = formatoFecha.format(elemento[3]);
                elemento[4] = Util.convertirPuntoAComa(String.valueOf((Double)elemento[4]));
                modelo.addRow(elemento);
            }
        }
    }

    private void visualizarAgente() {

        int indiceFila = indiceFila = this.tcliente1.getSelectedRow();
        if (indiceFila >= 0) {
            String codigo = codigo = (String) tcliente1.getModel().getValueAt(indiceFila, 1);
            Agentes a = BaseDatos.obtenerAgentesPorCodigo(codigo, tipo, e);

            NuevoCliente nc = null;

            if (tipo.equals("cli")) {
                nc = new NuevoCliente("Cliente - Modificación", a, tipo, e);
            } else if (tipo.equals("prov")) {
                nc = new NuevoCliente("Proveedor - Modificación", a, tipo, e);
            }
            nc.setDefaultCloseOperation(NuevoCliente.DISPOSE_ON_CLOSE);
            nc.setLocationRelativeTo(null);
            nc.setVisible(true);
            cerrarListado();
        } else {
            JOptionPane.showMessageDialog(null, "No hay seleccionado ningún elemento", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void actualizarClientes1(List lagentes) {
        Modelo modelo1 = (Modelo) tcliente1.getModel();
        int i, j;

        //obtenemos el nº de filas;
        j = modelo1.getRowCount();

        //eliminamos todas las filas
        for (i = 0; i < j; i++) {
            modelo1.removeRow(0);
        }

        if (lagentes == null) {
            lagentes = new ArrayList();
        }

        Iterator it1;

        if (lagentes != null) {
            for (it1 = lagentes.iterator(); it1.hasNext();) {
                modelo1.addRow((Object [])it1.next());
            }
        }
    }

    
    private void completarPantalla() {
        List lp = null;

        String nombre = tbusqueda1.getText().toLowerCase();
        lp = BaseDatos.busquedaRapidaClientesPorNombreComercial(nombre, e);

        if (tipo.equals("cli")) {
            lp = BaseDatos.getListaClientes(e);
        } else if (tipo.equals("prov")) {
            lp = BaseDatos.getListaProveedores(e);
        }

        actualizarClientes1(lp);

    }

    private void crearIconosBotones() {
        URL urlVisualizar = getClass().getResource("/iconos/detalle.png");
        ImageIcon iconoVisualizar = new ImageIcon(urlVisualizar);
        bvisualizar.setIcon(iconoVisualizar);

        URL urlBorrar = getClass().getResource("/iconos/borrar32.png");
        ImageIcon iconoBorrar = new ImageIcon(urlBorrar);
        bborrar.setIcon(iconoBorrar);

        URL urlCerrar = getClass().getResource("/iconos/eliminar.png");
        ImageIcon iconoCerrar = new ImageIcon(urlCerrar);
        bcerrar.setIcon(iconoCerrar);

        URL urlCrear = getClass().getResource("/iconos/aceptar.png");
        ImageIcon iconoCrear = new ImageIcon(urlCrear);
        bcrear.setIcon(iconoCrear);
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bRango;
    private javax.swing.JButton bborrar;
    private javax.swing.JButton bcerrar;
    private javax.swing.JButton bcrear;
    private javax.swing.JButton bvisualizar;
    private com.toedter.calendar.JDateChooser fFin;
    private com.toedter.calendar.JDateChooser fInicio;
    private javax.swing.ButtonGroup grupo;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JComboBox lDocumentos;
    private javax.swing.JPanel pContactos;
    private javax.swing.JPanel pDatos;
    private javax.swing.JPanel pDocumentos;
    private javax.swing.JPanel pPeriodo;
    private javax.swing.JRadioButton rCodigo;
    private javax.swing.JRadioButton rComercial;
    private javax.swing.JRadioButton rDireccion;
    private javax.swing.JRadioButton rFiscal;
    private javax.swing.JRadioButton rTelefono;
    private javax.swing.JTextField tImporte;
    private javax.swing.JTextField tNumero;
    private javax.swing.JTextField tbusqueda1;
    private javax.swing.JTable tcliente1;
    private javax.swing.JTable tcontacto;
    private javax.swing.JTable tdocumento;
    // End of variables declaration//GEN-END:variables
}
