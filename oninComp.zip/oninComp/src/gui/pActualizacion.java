/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;


import java.awt.Color;
import java.awt.FlowLayout;
import javax.swing.JFrame;
import javax.swing.JProgressBar;
import util.HiloProgreso;

public class pActualizacion {
   
    Thread hilo;
    static Integer max;
    static JFrame ventana;
    static JProgressBar barra;
    
    public pActualizacion(Integer max) {
        
        //initComponents();
        ventana = new JFrame("Barra de Progreso");
        barra = new JProgressBar(0,max);
        barra.setBorderPainted(true);
        barra.setForeground(new Color(90, 80, 153, 100));
        barra.setStringPainted(true);
        ventana.setLayout(new FlowLayout());
        ventana.add(barra);                                     
        
        
        hilo = new Thread(new HiloProgreso(barra));
        hilo.start();

        //Le damos tamaño y posición a nuestro Frame
        ventana.setLocation(200, 200);
        ventana.setSize(472, 249);
        
        ventana.setVisible(true);
        ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    
    public void updatepgrBarra(Integer valor){
               
        hilo.run();   
    }
    
    public void cerrar(){
        //Cerramos el hilo
        hilo.stop();
        
    }
              
}
  

