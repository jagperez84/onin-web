package gui;

import acceso.BaseDatos;
import bean.TipoControl;
import bean.TipoMedida;
import bean.UnidadMedida;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.net.URL;
import java.util.Iterator;
import java.util.List;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JOptionPane;
import javax.swing.KeyStroke;
import util.Constantes;

public class NuevoTipoControl extends javax.swing.JFrame {

    private TipoControl tc;
    private String codigoAntiguo;
    private String nombreAntiguo;
    private String tipoMedidaAntigua;
    private String unidadResultadoAntigua;
    private String unidad1Antigua;
    private String unidad2Antigua;
    private String unidad3Antigua;
    private String unidad4Antigua;
    private String unidad5Antigua;
    private String numdec1Antiguo;
    private String numdec2Antiguo;
    private String numdec3Antiguo;
    private String numdec4Antiguo;
    private String numdec5Antiguo;
    private String numdecresAntiguo;
    private String tipoRedondeoAntiguo;
    private boolean crear;

    public NuevoTipoControl(String titulo) {
        super(titulo);
        crear = true;
        tc = new TipoControl();
        initComponents();
        rellenarUnidades();
        habilitarUnidades(0);
        bcancelar.setToolTipText("Cancelar la creación del tipo de control");
        baceptar.setToolTipText("Realizar la modificación");
        bmodificar.setVisible(false);
        crearIconosBotones();
        crearAcciones();
    }

    public NuevoTipoControl(TipoControl tc, String titulo) {
        super(titulo);
        this.tc = tc;
        initComponents();
        rellenarUnidades();
        bcancelar.setToolTipText("Cancelar la creación del tipo de medida");
        baceptar.setToolTipText("Realizar la modificación");
        bmodificar.setToolTipText("Modificar campos");
        crear = false;

        tcodigo.setText(tc.getCodigo());
        codigoAntiguo = tc.getCodigo();

        tnombre.setText(tc.getNombre());
        nombreAntiguo = tc.getNombre();

        if (tc.getNdec1() != null) {
            tnumdec1.setText(String.valueOf(tc.getNdec1()));
            numdec1Antiguo = (String.valueOf(tc.getNdec1()));
        }

        if (tc.getNdec2() != null) {
            tnumdec2.setText(String.valueOf(tc.getNdec2()));
            numdec2Antiguo = (String.valueOf(tc.getNdec2()));
        }

        if (tc.getNdec3() != null) {
            tnumdec3.setText(String.valueOf(tc.getNdec3()));
            numdec3Antiguo = (String.valueOf(tc.getNdec3()));
        }

        if (tc.getNdec4() != null) {
            tnumdec4.setText(String.valueOf(tc.getNdec4()));
            numdec4Antiguo = (String.valueOf(tc.getNdec4()));
        }

        if (tc.getNdec5() != null) {
            tnumdec5.setText(String.valueOf(tc.getNdec5()));
            numdec5Antiguo = (String.valueOf(tc.getNdec5()));
        }

        if (tc.getNdecResultado() != null) {
            tnumdecres.setText(String.valueOf(tc.getNdecResultado()));
            numdecresAntiguo = (String.valueOf(tc.getNdecResultado()));
        }

        ctiporedondeo.setSelectedItem(tc.getTipoRedondeo());
        tipoRedondeoAntiguo = tc.getTipoRedondeo();

        if (tc.getIid_tipo_medida() != null && !tc.getIid_tipo_medida().getNombre().equals(Constantes.VACIO)) {
            TipoMedida tm = tc.getIid_tipo_medida();
            tdimensiones.setText(String.valueOf(tm.getNum_dimensiones()));
            tcodigotm.setText(tm.getCodigo());
            cnombretm.setSelectedItem(tm.getNombre());
            tipoMedidaAntigua = tc.getIid_tipo_medida().getNombre();

            if (tc.getUnidad1() != null) {
                cunidad1.setSelectedItem(tc.getUnidad1().getNombre());
                unidad1Antigua = tc.getUnidad1().getNombre();
            }

            if (tc.getUnidad2() != null) {
                cunidad2.setSelectedItem(tc.getUnidad2().getNombre());
                unidad2Antigua = tc.getUnidad2().getNombre();
            }

            if (tc.getUnidad3() != null) {
                cunidad3.setSelectedItem(tc.getUnidad3().getNombre());
                unidad3Antigua = tc.getUnidad3().getNombre();
            }

            if (tc.getUnidad4() != null) {
                cunidad4.setSelectedItem(tc.getUnidad4().getNombre());
                unidad4Antigua = tc.getUnidad4().getNombre();
            }

            if (tc.getUnidad5() != null) {
                cunidad5.setSelectedItem(tc.getUnidad5().getNombre());
                unidad5Antigua = tc.getUnidad5().getNombre();
            }

            if (tc.getUnidadResultado() != null) {
                cunidadres.setSelectedItem(tc.getUnidadResultado().getNombre());
                unidadResultadoAntigua = tc.getUnidadResultado().getNombre();
            }
        }

        tnombre.setEnabled(false);
        tcodigo.setEnabled(false);
        cnombretm.setEnabled(false);
        cunidad1.setEnabled(false);
        cunidad2.setEnabled(false);
        cunidad3.setEnabled(false);
        cunidad4.setEnabled(false);
        cunidad5.setEnabled(false);
        cunidadres.setEnabled(false);
        tnumdec1.setEnabled(false);
        tnumdec2.setEnabled(false);
        tnumdec3.setEnabled(false);
        tnumdec4.setEnabled(false);
        tnumdec5.setEnabled(false);
        ctiporedondeo.setEnabled(false);
        cunidadres.setEnabled(false);
        tnumdecres.setEnabled(false);
        
        crearIconosBotones();
        crearAcciones();
    }

    private void crearAcciones() {
        KeyStroke escapeKeyStroke = KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false);
        Action escapeAction = new AbstractAction() {
            public void actionPerformed(ActionEvent e) {
                cerrarVentana();
            }
        }; 
        getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(escapeKeyStroke, "ESCAPE");
        getRootPane().getActionMap().put("ESCAPE", escapeAction);
    }
    
    private void cerrarVentana(){
        removeAll();
        dispose();
    }
    
    private void crearIconosBotones() {
        
        URL urlCancelar = getClass().getResource("/iconos/cancelar.gif");
        ImageIcon iconoCancelar = new ImageIcon(urlCancelar);
        bcancelar.setIcon(iconoCancelar);
        
        URL urlAceptar = getClass().getResource("/iconos/guardarYvolver.png");
        ImageIcon iconoAceptar = new ImageIcon(urlAceptar);
        baceptar.setIcon(iconoAceptar);
        
        URL urlModificar = getClass().getResource("/iconos/editar.png");
        ImageIcon iconoModificar = new ImageIcon(urlModificar);
        bmodificar.setIcon(iconoModificar);
    }

    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lcodigo = new javax.swing.JLabel();
        tnombre = new javax.swing.JTextField();
        baceptar = new javax.swing.JButton();
        bcancelar = new javax.swing.JButton();
        tcodigo = new javax.swing.JTextField();
        ldim1 = new javax.swing.JLabel();
        ldim2 = new javax.swing.JLabel();
        ldim3 = new javax.swing.JLabel();
        ldim4 = new javax.swing.JLabel();
        ldim5 = new javax.swing.JLabel();
        lnombre = new javax.swing.JLabel();
        bmodificar = new javax.swing.JButton();
        lunidaddimension = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        lnombreum = new javax.swing.JLabel();
        cnombretm = new javax.swing.JComboBox();
        ldimensiones = new javax.swing.JLabel();
        tdimensiones = new javax.swing.JTextField();
        lcodigoum = new javax.swing.JLabel();
        tcodigotm = new javax.swing.JTextField();
        cunidad1 = new javax.swing.JComboBox();
        tnumdec1 = new javax.swing.JFormattedTextField();
        lnumdec = new javax.swing.JLabel();
        cunidad2 = new javax.swing.JComboBox();
        tnumdec2 = new javax.swing.JFormattedTextField();
        cunidad3 = new javax.swing.JComboBox();
        tnumdec3 = new javax.swing.JFormattedTextField();
        cunidad4 = new javax.swing.JComboBox();
        tnumdec4 = new javax.swing.JFormattedTextField();
        cunidad5 = new javax.swing.JComboBox();
        tnumdec5 = new javax.swing.JFormattedTextField();
        jPanel2 = new javax.swing.JPanel();
        lunidaddimension1 = new javax.swing.JLabel();
        cunidadres = new javax.swing.JComboBox();
        lnumdecres = new javax.swing.JLabel();
        tnumdecres = new javax.swing.JFormattedTextField();
        ltiporedondeo = new javax.swing.JLabel();
        ctiporedondeo = new javax.swing.JComboBox();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        lcodigo.setText("Codigo");

        tnombre.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tnombreKeyReleased(evt);
            }
        });

        baceptar.setText("Aceptar");
        baceptar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                baceptarActionPerformed(evt);
            }
        });

        bcancelar.setText("Cancelar");
        bcancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bcancelarActionPerformed(evt);
            }
        });

        tcodigo.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tcodigoKeyReleased(evt);
            }
        });

        ldim1.setText("Dimensión 1");

        ldim2.setText("Dimensión 2");

        ldim3.setText("Dimensión 3");

        ldim4.setText("Dimensión 4");

        ldim5.setText("Dimensión 5");

        lnombre.setText("Nombre");

        bmodificar.setText("Modificar");
        bmodificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bmodificarActionPerformed(evt);
            }
        });

        lunidaddimension.setText("Unidad");

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder("Tipo de Medida"));

        lnombreum.setText("Nombre");

        cnombretm.setModel(new javax.swing.DefaultComboBoxModel(new String[] {}));
        List ltipomedidas = BaseDatos.getListaTipoMedidas();
        TipoMedida tm;
        Iterator it1;
        cnombretm.addItem(Constantes.VACIO);
        for (it1 = ltipomedidas.iterator(); it1.hasNext();) {
            tm = (TipoMedida) it1.next();
            cnombretm.addItem(tm.getNombre());
        }

        if(tc.getIid_tipo_medida() == null){
            cnombretm.setSelectedIndex(0);
        }
        else{
            cnombretm.setSelectedItem(tc.getIid_tipo_medida().getNombre());
        }
        cnombretm.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cnombretmActionPerformed(evt);
            }
        });

        ldimensiones.setText("Nº de Dimensiones");

        tdimensiones.setEnabled(false);

        lcodigoum.setText("Código");

        tcodigotm.setEnabled(false);

        org.jdesktop.layout.GroupLayout jPanel1Layout = new org.jdesktop.layout.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(lnombreum)
                    .add(lcodigoum))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jPanel1Layout.createSequentialGroup()
                        .add(tcodigotm, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 211, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(28, 28, 28)
                        .add(ldimensiones)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                        .add(tdimensiones, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 29, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                    .add(cnombretm, 0, 577, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(lnombreum)
                    .add(cnombretm, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(lcodigoum)
                    .add(tcodigotm, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(ldimensiones)
                    .add(tdimensiones, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(23, Short.MAX_VALUE))
        );

        cunidad1.setModel(new javax.swing.DefaultComboBoxModel(new String[] {}));

        tnumdec1.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(java.text.NumberFormat.getIntegerInstance())));
        tnumdec1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tnumdec1KeyReleased(evt);
            }
        });

        lnumdec.setText("Nº dec.");

        cunidad2.setModel(new javax.swing.DefaultComboBoxModel(new String[] {}));

        tnumdec2.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(java.text.NumberFormat.getIntegerInstance())));
        tnumdec2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tnumdec2KeyReleased(evt);
            }
        });

        cunidad3.setModel(new javax.swing.DefaultComboBoxModel(new String[] {}));

        tnumdec3.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(java.text.NumberFormat.getIntegerInstance())));
        tnumdec3.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tnumdec3KeyReleased(evt);
            }
        });

        cunidad4.setModel(new javax.swing.DefaultComboBoxModel(new String[] {}));

        tnumdec4.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(java.text.NumberFormat.getIntegerInstance())));
        tnumdec4.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tnumdec4KeyReleased(evt);
            }
        });

        cunidad5.setModel(new javax.swing.DefaultComboBoxModel(new String[] {}));

        tnumdec5.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(java.text.NumberFormat.getIntegerInstance())));
        tnumdec5.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tnumdec5KeyReleased(evt);
            }
        });

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder("Resultado"));

        lunidaddimension1.setText("Unidad");

        cunidadres.setModel(new javax.swing.DefaultComboBoxModel(new String[] {}));

        lnumdecres.setText("Nº decimales");

        tnumdecres.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(java.text.NumberFormat.getIntegerInstance())));
        tnumdecres.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tnumdecresKeyReleased(evt);
            }
        });

        ltiporedondeo.setText("Tipo de redondeo");

        ctiporedondeo.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Exceso", "Matemático", "Truncamiento"}));

        org.jdesktop.layout.GroupLayout jPanel2Layout = new org.jdesktop.layout.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .add(lunidaddimension1)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                .add(cunidadres, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 206, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .add(18, 18, 18)
                .add(lnumdecres)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(tnumdecres, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 38, Short.MAX_VALUE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(ltiporedondeo)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(ctiporedondeo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 145, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .add(21, 21, 21))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(lunidaddimension1)
                    .add(cunidadres, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(ltiporedondeo)
                    .add(lnumdecres)
                    .add(tnumdecres, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(ctiporedondeo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        org.jdesktop.layout.GroupLayout layout = new org.jdesktop.layout.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(layout.createSequentialGroup()
                .addContainerGap()
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                        .add(layout.createSequentialGroup()
                            .add(lcodigo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 41, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                            .add(tcodigo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 137, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(46, 46, 46)
                            .add(lnombre)
                            .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                            .add(tnombre, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 286, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .addContainerGap(105, Short.MAX_VALUE))
                        .add(layout.createSequentialGroup()
                            .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                                .add(ldim5)
                                .add(ldim4)
                                .add(ldim3)
                                .add(ldim2)
                                .add(ldim1))
                            .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                            .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                                .add(cunidad5, 0, 224, Short.MAX_VALUE)
                                .add(cunidad4, 0, 224, Short.MAX_VALUE)
                                .add(cunidad3, 0, 224, Short.MAX_VALUE)
                                .add(org.jdesktop.layout.GroupLayout.LEADING, layout.createSequentialGroup()
                                    .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED, 27, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                    .add(lunidaddimension))
                                .add(org.jdesktop.layout.GroupLayout.LEADING, cunidad1, 0, 224, Short.MAX_VALUE)
                                .add(org.jdesktop.layout.GroupLayout.LEADING, cunidad2, 0, 224, Short.MAX_VALUE))
                            .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                            .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                                .add(tnumdec2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 87, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                .add(tnumdec1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 87, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                .add(tnumdec3, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 87, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                .add(tnumdec4, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 87, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                .add(tnumdec5, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 87, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                .add(lnumdec))
                            .add(282, 282, 282))
                        .add(layout.createSequentialGroup()
                            .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING, false)
                                .add(org.jdesktop.layout.GroupLayout.LEADING, jPanel1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .add(org.jdesktop.layout.GroupLayout.LEADING, jPanel2, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .add(org.jdesktop.layout.GroupLayout.TRAILING, layout.createSequentialGroup()
                        .add(baceptar)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                        .add(bmodificar, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 103, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                        .add(bcancelar)
                        .addContainerGap())))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(layout.createSequentialGroup()
                .addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(lcodigo)
                    .add(lnombre)
                    .add(tnombre, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(tcodigo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                .add(jPanel1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(lunidaddimension)
                    .add(lnumdec))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(ldim1)
                    .add(cunidad1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(tnumdec1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(ldim2)
                    .add(cunidad2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(tnumdec2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(ldim3)
                    .add(cunidad3, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(tnumdec3, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(ldim4)
                    .add(cunidad4, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(tnumdec4, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(ldim5)
                    .add(cunidad5, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(tnumdec5, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                .add(jPanel2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .add(18, 18, 18)
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(bcancelar)
                    .add(bmodificar)
                    .add(baceptar))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

private void baceptarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_baceptarActionPerformed

    String nombre = tnombre.getText();
    String codigo = tcodigo.getText();
    String tipoMedida = (String) cnombretm.getSelectedItem();

    if (nombre != null && nombre.length() > 0 &&
            codigo != null && codigo.length() > 0 &&
            tipoMedida != null && !tipoMedida.equalsIgnoreCase(Constantes.VACIO)) {

        tc.setCodigo(codigo);
        tc.setNombre(nombre);

        String numdecimales;
        
        int numDimensiones = Integer.valueOf(this.tdimensiones.getText());

        numdecimales = (String) tnumdec1.getText();
        if (!numdecimales.equals("")) {
            tc.setNdec1(Integer.valueOf(numdecimales));
        } else {
            if(numDimensiones >= 1){
                tc.setNdec1(0);
            }
        }

        numdecimales = (String) tnumdec2.getText();
        if (!numdecimales.equals("")) {
            tc.setNdec2(Integer.valueOf(numdecimales));
        } else {
            if(numDimensiones >= 2){
                tc.setNdec2(0);
            }
        }

        numdecimales = (String) tnumdec3.getText();
        if (!numdecimales.equals("")) {
            tc.setNdec3(Integer.valueOf(numdecimales));
        } else {
            if(numDimensiones >= 3){
                tc.setNdec3(0);
            }
        }
        
        numdecimales = (String) tnumdec4.getText();
        if (!numdecimales.equals("")) {
            tc.setNdec4(Integer.valueOf(numdecimales));
        } else {
            if(numDimensiones >= 4){
                tc.setNdec4(0);
            }
        }
        numdecimales = (String) tnumdec5.getText();
        if (!numdecimales.equals("")) {
            tc.setNdec5(Integer.valueOf(numdecimales));
        } else {
            if(numDimensiones >= 5){
                tc.setNdec5(0);
            }
        }
        
        
        numdecimales = (String) tnumdecres.getText();
        if (!numdecimales.equals("")) {
            tc.setNdecResultado(Integer.valueOf(numdecimales));
        } else {
            tc.setNdecResultado(0);
        }
        tc.setTipoRedondeo((String) ctiporedondeo.getSelectedItem());

        if (!((String) cunidad1.getSelectedItem()).equals(Constantes.VACIO)) {
            tc.setUnidad1(BaseDatos.obtenerUnidadMedidaNombre((String) cunidad1.getSelectedItem()));
        }

        if (!((String) cunidad2.getSelectedItem()).equals(Constantes.VACIO)) {
            tc.setUnidad2(BaseDatos.obtenerUnidadMedidaNombre((String) cunidad2.getSelectedItem()));
        }

        if (!((String) cunidad3.getSelectedItem()).equals(Constantes.VACIO)) {
            tc.setUnidad3(BaseDatos.obtenerUnidadMedidaNombre((String) cunidad3.getSelectedItem()));
        }

        if (!((String) cunidad4.getSelectedItem()).equals(Constantes.VACIO)) {
            tc.setUnidad4(BaseDatos.obtenerUnidadMedidaNombre((String) cunidad4.getSelectedItem()));
        }

        if (!((String) cunidad5.getSelectedItem()).equals(Constantes.VACIO)) {
            tc.setUnidad5(BaseDatos.obtenerUnidadMedidaNombre((String) cunidad5.getSelectedItem()));
        }

        if (!((String) cunidadres.getSelectedItem()).equals(Constantes.VACIO)) {
            tc.setUnidadResultado(BaseDatos.obtenerUnidadMedidaNombre((String) cunidadres.getSelectedItem()));
        }

        if (!((String) cnombretm.getSelectedItem()).equals(Constantes.VACIO)) {
            tc.setIid_tipo_medida(BaseDatos.obtenerTipoMedidaPorNombre((String) cnombretm.getSelectedItem()));
        }

        if (crear) {
            TipoControl temp = BaseDatos.obtenerTipoControl(codigo);
            if(temp == null){
                if (BaseDatos.insertarElemento(tc)) {
                    cerrarVentana();
                } else {
                    JOptionPane.showMessageDialog(null, "No se puede ha podido insertar el elemento", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(null, "Ya hay un tipo de control con el código " + codigo, "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            int hacerCambios = 1;

            if (hayCambios()) {
                hacerCambios = JOptionPane.showConfirmDialog(null, "Está seguro de que desea realizar los cambios?", "¿Realizar cambios?", JOptionPane.YES_NO_OPTION);
                //hacerCambios = -1 ==> se ha pulsado la "x" de cancelar;
                //hacerCambios =  0 ==> se ha pulsado el "sí"
                //hacerCambios =  1 ==> se ha pulsado el "no"
                if (hacerCambios == 0) {
                    TipoControl temp = null;
                    
                    if(!codigo.equalsIgnoreCase(codigoAntiguo)){
                        temp = BaseDatos.obtenerTipoControl(codigo);
                    }
                    
                    if(temp == null){
                        if (BaseDatos.modificarElemento(tc)) {
                            cerrarVentana();
                        } else {
                            JOptionPane.showMessageDialog(null, "No se puede ha podido modificar el elemento", "Error", JOptionPane.ERROR_MESSAGE);
                        }
                    } else {
                        JOptionPane.showMessageDialog(null, "Ya hay un tipo de control con el código " + codigo, "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
            } else {
                //no hay cambios que realizar
                JOptionPane.showMessageDialog(null, "No hay cambios que realizar", "Sin cambios", JOptionPane.ERROR_MESSAGE);
            }
        }
    } else {
        //Error, hay que rellenar todos los campos
        JOptionPane.showMessageDialog(null, "Debe rellenar el código, nombre y tipo de medida", "Error", JOptionPane.ERROR_MESSAGE);
    }
}//GEN-LAST:event_baceptarActionPerformed

private void bcancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bcancelarActionPerformed
    cerrarVentana();
}//GEN-LAST:event_bcancelarActionPerformed

private void bmodificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bmodificarActionPerformed
    if (bmodificar.getText().equals("Modificar")) {
        //Si el botón tiene el texto Modificar
        tnombre.setEnabled(true);
        tcodigo.setEnabled(true);
        cnombretm.setEnabled(true);
        cunidadres.setEnabled(true);
        tnumdecres.setEnabled(true);
        tnumdec1.setEnabled(true);
        tnumdec2.setEnabled(true);
        tnumdec3.setEnabled(true);
        tnumdec4.setEnabled(true);
        tnumdec5.setEnabled(true);
        ctiporedondeo.setEnabled(true);
        cunidadres.setEnabled(true);
        bmodificar.setText("Visualizar");
        bmodificar.setToolTipText("Visualizar campos");
        URL urlModificar = getClass().getResource("/iconos/buscar.gif");
        ImageIcon iconoModificar = new ImageIcon(urlModificar);
        bmodificar.setIcon(iconoModificar);
    } else {
        //si el botón tiene el texto Visualizar
        tnombre.setEnabled(false);
        tcodigo.setEnabled(false);
        cnombretm.setEnabled(false);
        cunidadres.setEnabled(false);
        tnumdecres.setEnabled(false);
        tnumdec1.setEnabled(false);
        tnumdec2.setEnabled(false);
        tnumdec3.setEnabled(false);
        tnumdec4.setEnabled(false);
        tnumdec5.setEnabled(false);
        ctiporedondeo.setEnabled(false);
        cunidadres.setEnabled(false);
        bmodificar.setText("Modificar");
        bmodificar.setToolTipText("Modificar campos");
        URL urlModificar = getClass().getResource("/iconos/editar.png");
        ImageIcon iconoModificar = new ImageIcon(urlModificar);
        bmodificar.setIcon(iconoModificar);
    }
    habilitarUnidades(Integer.valueOf(tdimensiones.getText()));
}//GEN-LAST:event_bmodificarActionPerformed

private void cnombretmActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cnombretmActionPerformed
    String tipoMedida = (String) cnombretm.getSelectedItem();

    if (!tipoMedida.equals(Constantes.VACIO)) {
        TipoMedida tipom = BaseDatos.obtenerTipoMedidaPorNombre(tipoMedida);
        if (tipom != null) {
            int dimensiones = tipom.getNum_dimensiones();
            tdimensiones.setText(String.valueOf(dimensiones));
            tcodigotm.setText(tipom.getCodigo());
            habilitarUnidades(dimensiones);
            if (tipom.getUnidad_dim_1() != null) {
                cunidad1.setSelectedItem(tipom.getUnidad_dim_1().getNombre());
            } else {
                cunidad1.setSelectedIndex(0);
            }
            if (tipom.getUnidad_dim_2() != null) {
                cunidad2.setSelectedItem(tipom.getUnidad_dim_2().getNombre());
            } else {
                cunidad2.setSelectedIndex(0);
            }
            if (tipom.getUnidad_dim_3() != null) {
                cunidad3.setSelectedItem(tipom.getUnidad_dim_3().getNombre());
            } else {
                cunidad3.setSelectedIndex(0);
            }
            if (tipom.getUnidad_dim_4() != null) {
                cunidad4.setSelectedItem(tipom.getUnidad_dim_4().getNombre());
            } else {
                cunidad4.setSelectedIndex(0);
            }
            if (tipom.getUnidad_dim_5() != null) {
                cunidad5.setSelectedItem(tipom.getUnidad_dim_5().getNombre());
            } else {
                cunidad5.setSelectedIndex(0);
            }
            if (tipom.getUnidad_resultado() != null) {
                cunidadres.setSelectedItem(tipom.getUnidad_resultado().getNombre());
            } else {
                cunidadres.setSelectedIndex(0);
            }
        }
    }
}//GEN-LAST:event_cnombretmActionPerformed

private void tcodigoKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tcodigoKeyReleased
    String codigo = tcodigo.getText();
    if(codigo.length() > Constantes.TAM_CODIGO_TIPO_CONTROL){
        JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_CODIGO_TIPO_CONTROL, "Error", JOptionPane.ERROR_MESSAGE);
        tcodigo.setText(codigo.substring(0, Constantes.TAM_CODIGO_TIPO_CONTROL));
    }
}//GEN-LAST:event_tcodigoKeyReleased

private void tnombreKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tnombreKeyReleased
    String nombre = tnombre.getText();
    if(nombre.length() > Constantes.TAM_NOMBRE_TIPO_CONTROL){
        JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_NOMBRE_TIPO_CONTROL, "Error", JOptionPane.ERROR_MESSAGE);
        tnombre.setText(nombre.substring(0, Constantes.TAM_NOMBRE_TIPO_CONTROL));
    }
}//GEN-LAST:event_tnombreKeyReleased

private void tnumdec1KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tnumdec1KeyReleased
    int tamaño = tnumdec1.getText().length();
    if (tamaño > 0) {
        char c = tnumdec1.getText().charAt(tamaño - 1);
        if (!(c >= '0' && c <= '9')) {
            String str = tnumdec1.getText().substring(0, tamaño - 1);
            tnumdec1.setText(str);
        }
    }
}//GEN-LAST:event_tnumdec1KeyReleased

private void tnumdec2KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tnumdec2KeyReleased
    int tamaño = tnumdec2.getText().length();
    if (tamaño > 0) {
        char c = tnumdec2.getText().charAt(tamaño - 1);
        if (!(c >= '0' && c <= '9')) {
            String str = tnumdec2.getText().substring(0, tamaño - 1);
            tnumdec2.setText(str);
        }
    }
}//GEN-LAST:event_tnumdec2KeyReleased

private void tnumdec3KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tnumdec3KeyReleased
    int tamaño = tnumdec3.getText().length();
    if (tamaño > 0) {
        char c = tnumdec3.getText().charAt(tamaño - 1);
        if (!(c >= '0' && c <= '9')) {
            String str = tnumdec3.getText().substring(0, tamaño - 1);
            tnumdec3.setText(str);
        }
    }
}//GEN-LAST:event_tnumdec3KeyReleased

private void tnumdec4KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tnumdec4KeyReleased
    int tamaño = tnumdec4.getText().length();
    if (tamaño > 0) {
        char c = tnumdec4.getText().charAt(tamaño - 1);
        if (!(c >= '0' && c <= '9')) {
            String str = tnumdec4.getText().substring(0, tamaño - 1);
            tnumdec4.setText(str);
        }
    }
}//GEN-LAST:event_tnumdec4KeyReleased

private void tnumdec5KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tnumdec5KeyReleased
    int tamaño = tnumdec5.getText().length();
    if (tamaño > 0) {
        char c = tnumdec5.getText().charAt(tamaño - 1);
        if (!(c >= '0' && c <= '9')) {
            String str = tnumdec5.getText().substring(0, tamaño - 1);
            tnumdec5.setText(str);
        }
    }
}//GEN-LAST:event_tnumdec5KeyReleased

private void tnumdecresKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tnumdecresKeyReleased
    int tamaño = tnumdecres.getText().length();
    if (tamaño > 0) {
        char c = tnumdecres.getText().charAt(tamaño - 1);
        if (!(c >= '0' && c <= '9')) {
            String str = tnumdecres.getText().substring(0, tamaño - 1);
            tnumdecres.setText(str);
        }
    }
}//GEN-LAST:event_tnumdecresKeyReleased

    private void habilitarUnidades(int numDim) {
        if (numDim == 0) {
            cunidad1.setEnabled(false);
            cunidad2.setEnabled(false);
            cunidad3.setEnabled(false);
            cunidad4.setEnabled(false);
            cunidad5.setEnabled(false);
            tnumdec1.setEnabled(false);
            tnumdec2.setEnabled(false);
            tnumdec3.setEnabled(false);
            tnumdec4.setEnabled(false);
            tnumdec5.setEnabled(false);
        } else if (numDim == 1) {
            cunidad1.setEnabled(true);
            cunidad2.setEnabled(false);
            cunidad3.setEnabled(false);
            cunidad4.setEnabled(false);
            cunidad5.setEnabled(false);
            tnumdec1.setEnabled(true);
            tnumdec2.setEnabled(false);
            tnumdec3.setEnabled(false);
            tnumdec4.setEnabled(false);
            tnumdec5.setEnabled(false);
        } else if (numDim == 2) {
            cunidad1.setEnabled(true);
            cunidad2.setEnabled(true);
            cunidad3.setEnabled(false);
            cunidad4.setEnabled(false);
            cunidad5.setEnabled(false);
            tnumdec1.setEnabled(true);
            tnumdec2.setEnabled(true);
            tnumdec3.setEnabled(false);
            tnumdec4.setEnabled(false);
            tnumdec5.setEnabled(false);
        } else if (numDim == 3) {
            cunidad1.setEnabled(true);
            cunidad2.setEnabled(true);
            cunidad3.setEnabled(true);
            cunidad4.setEnabled(false);
            cunidad5.setEnabled(false);
            tnumdec1.setEnabled(true);
            tnumdec2.setEnabled(true);
            tnumdec3.setEnabled(true);
            tnumdec4.setEnabled(false);
            tnumdec5.setEnabled(false);
        } else if (numDim == 4) {
            cunidad1.setEnabled(true);
            cunidad2.setEnabled(true);
            cunidad3.setEnabled(true);
            cunidad4.setEnabled(true);
            cunidad5.setEnabled(false);
            tnumdec1.setEnabled(true);
            tnumdec2.setEnabled(true);
            tnumdec3.setEnabled(true);
            tnumdec4.setEnabled(true);
            tnumdec5.setEnabled(false);
        } else {
            cunidad1.setEnabled(true);
            cunidad2.setEnabled(true);
            cunidad3.setEnabled(true);
            cunidad4.setEnabled(true);
            cunidad5.setEnabled(true);
            tnumdec1.setEnabled(true);
            tnumdec2.setEnabled(true);
            tnumdec3.setEnabled(true);
            tnumdec4.setEnabled(true);
            tnumdec5.setEnabled(true);
        }
    }

    private void rellenarUnidades() {
        List lunidades = BaseDatos.getListaUnidadMedidas();
        UnidadMedida um;

        cunidad1.addItem(Constantes.VACIO);
        cunidad2.addItem(Constantes.VACIO);
        cunidad3.addItem(Constantes.VACIO);
        cunidad4.addItem(Constantes.VACIO);
        cunidad5.addItem(Constantes.VACIO);
        cunidadres.addItem(Constantes.VACIO);

        for (Iterator it = lunidades.iterator(); it.hasNext();) {
            um = (UnidadMedida) it.next();
            cunidad1.addItem(um.getNombre());
            cunidad2.addItem(um.getNombre());
            cunidad3.addItem(um.getNombre());
            cunidad4.addItem(um.getNombre());
            cunidad5.addItem(um.getNombre());
            cunidadres.addItem(um.getNombre());
        }
    }

    private boolean hayCambios() {
        return !tcodigo.getText().equals(codigoAntiguo) ||
                !tnombre.getText().equals(nombreAntiguo) ||
                !((String) cnombretm.getSelectedItem()).equals(tipoMedidaAntigua) ||
                !tnumdec1.getText().equals(numdec1Antiguo) ||
                !tnumdec2.getText().equals(numdec2Antiguo) ||
                !tnumdec3.getText().equals(numdec3Antiguo) ||
                !tnumdec4.getText().equals(numdec4Antiguo) ||
                !tnumdec5.getText().equals(numdec5Antiguo) ||
                !tnumdecres.getText().equals(numdecresAntiguo) ||
                !((String) ctiporedondeo.getSelectedItem()).equals(tipoRedondeoAntiguo) ||
                !((String) cunidad1.getSelectedItem()).equals(unidad1Antigua) ||
                !((String) cunidad2.getSelectedItem()).equals(unidad2Antigua) ||
                !((String) cunidad3.getSelectedItem()).equals(unidad3Antigua) ||
                !((String) cunidad4.getSelectedItem()).equals(unidad4Antigua) ||
                !((String) cunidad5.getSelectedItem()).equals(unidad5Antigua) ||
                !((String) cunidadres.getSelectedItem()).equals(unidadResultadoAntigua);
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton baceptar;
    private javax.swing.JButton bcancelar;
    private javax.swing.JButton bmodificar;
    private javax.swing.JComboBox cnombretm;
    private javax.swing.JComboBox ctiporedondeo;
    private javax.swing.JComboBox cunidad1;
    private javax.swing.JComboBox cunidad2;
    private javax.swing.JComboBox cunidad3;
    private javax.swing.JComboBox cunidad4;
    private javax.swing.JComboBox cunidad5;
    private javax.swing.JComboBox cunidadres;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JLabel lcodigo;
    private javax.swing.JLabel lcodigoum;
    private javax.swing.JLabel ldim1;
    private javax.swing.JLabel ldim2;
    private javax.swing.JLabel ldim3;
    private javax.swing.JLabel ldim4;
    private javax.swing.JLabel ldim5;
    private javax.swing.JLabel ldimensiones;
    private javax.swing.JLabel lnombre;
    private javax.swing.JLabel lnombreum;
    private javax.swing.JLabel lnumdec;
    private javax.swing.JLabel lnumdecres;
    private javax.swing.JLabel ltiporedondeo;
    private javax.swing.JLabel lunidaddimension;
    private javax.swing.JLabel lunidaddimension1;
    private javax.swing.JTextField tcodigo;
    private javax.swing.JTextField tcodigotm;
    private javax.swing.JTextField tdimensiones;
    private javax.swing.JTextField tnombre;
    private javax.swing.JFormattedTextField tnumdec1;
    private javax.swing.JFormattedTextField tnumdec2;
    private javax.swing.JFormattedTextField tnumdec3;
    private javax.swing.JFormattedTextField tnumdec4;
    private javax.swing.JFormattedTextField tnumdec5;
    private javax.swing.JFormattedTextField tnumdecres;
    // End of variables declaration//GEN-END:variables
}
