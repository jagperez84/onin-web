package gui;

import acceso.BaseDatos;
import bean.TipoMedida;
import bean.UnidadMedida;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.net.URL;
import java.util.Iterator;
import java.util.List;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JOptionPane;
import javax.swing.KeyStroke;
import util.Constantes;

public class NuevoTipoMedida extends javax.swing.JFrame {
    private TipoMedida tm;
    private String codigoAntiguo;
    private String nombreAntiguo;
    private Integer numDimAntigua;
    private String nombreUnidad1Antiguo;
    private String nombreUnidad2Antiguo;
    private String nombreUnidad3Antiguo;
    private String nombreUnidad4Antiguo;
    private String nombreUnidad5Antiguo;
    private String unidadResultadoAntigua;
    private String unidad1Antigua;
    private String unidad2Antigua;
    private String unidad3Antigua;
    private String unidad4Antigua;
    private String unidad5Antigua;
    private String tipoCalculoAntiguo;
    private String formulaAntigua;
    private boolean crear;

    public NuevoTipoMedida(String titulo) {
        super(titulo);
        crear = true;
        tm = new TipoMedida();
        initComponents();
        rellenarUnidades();
        habilitarUnidades(0);
        habilitarFormula(Constantes.VACIO);
        tformula.setEnabled(false);
        bcancelar.setToolTipText("Cancelar la creación del tipo de medida");
        baceptar.setToolTipText("Realizar la modificación");
        bmodificar.setVisible(false);
        crearIconosBotones();
        crearAcciones();
    }

    public NuevoTipoMedida(TipoMedida tm, String titulo) {
        super(titulo);
        this.tm = tm;
        initComponents();
        rellenarUnidades();
        bcancelar.setToolTipText("Cancelar la creación del tipo de medida");
        baceptar.setToolTipText("Realizar la modificación");
        bmodificar.setToolTipText("Modificar campos");
        crear = false;
        tcodigo.setText(tm.getCodigo());
        tnombre.setText(tm.getNombre());
        cdimensiones.setSelectedIndex(tm.getNum_dimensiones());
        habilitarUnidades(tm.getNum_dimensiones());
        tformula.setText(tm.getFormula());
        ctipocalculo.setSelectedItem(tm.getTipo_calculo());
        habilitarFormula(tm.getTipo_calculo());
        tnomdim1.setText(tm.getNombre_dim_1());
        tnomdim2.setText(tm.getNombre_dim_2());
        tnomdim3.setText(tm.getNombre_dim_3());
        tnomdim4.setText(tm.getNombre_dim_4());
        tnomdim5.setText(tm.getNombre_dim_5());

        if (tm.getUnidad_dim_1() != null) {
            cunidad1.setSelectedItem(tm.getUnidad_dim_1().getNombre());
        }
        if (tm.getUnidad_dim_2() != null) {
            cunidad2.setSelectedItem(tm.getUnidad_dim_2().getNombre());
        }
        if (tm.getUnidad_dim_3() != null) {
            cunidad3.setSelectedItem(tm.getUnidad_dim_3().getNombre());
        }
        if (tm.getUnidad_dim_4() != null) {
            cunidad4.setSelectedItem(tm.getUnidad_dim_4().getNombre());
        }
        if (tm.getUnidad_dim_5() != null) {
            cunidad5.setSelectedItem(tm.getUnidad_dim_5().getNombre());
        }
        if (tm.getUnidad_resultado() != null) {
            cunidadresultado.setSelectedItem(tm.getUnidad_resultado().getNombre());
        }

        tnombre.setEnabled(false);
        tcodigo.setEnabled(false);
        cdimensiones.setEnabled(false);
        tnomdim1.setEnabled(false);
        tnomdim2.setEnabled(false);
        tnomdim3.setEnabled(false);
        tnomdim4.setEnabled(false);
        tnomdim5.setEnabled(false);
        cunidad1.setEnabled(false);
        cunidad2.setEnabled(false);
        cunidad3.setEnabled(false);
        cunidad4.setEnabled(false);
        cunidad5.setEnabled(false);
        cunidadresultado.setEnabled(false);
        ctipocalculo.setEnabled(false);
        tformula.setEnabled(false);

        codigoAntiguo = tm.getCodigo();
        nombreAntiguo = tm.getNombre();
        numDimAntigua = tm.getNum_dimensiones();
        nombreUnidad1Antiguo = tm.getNombre_dim_1();
        if (!nombreUnidad1Antiguo.equals("") && tm.getUnidad_dim_1() != null) {
            unidad1Antigua = tm.getUnidad_dim_1().getNombre();
        } else {
            unidad1Antigua = Constantes.VACIO;
        }
        nombreUnidad2Antiguo = tm.getNombre_dim_2();
        if (!nombreUnidad2Antiguo.equals("") && tm.getUnidad_dim_2() != null) {
            unidad2Antigua = tm.getUnidad_dim_2().getNombre();
        } else {
            unidad2Antigua = Constantes.VACIO;
        }
        nombreUnidad3Antiguo = tm.getNombre_dim_3();
        if (!nombreUnidad3Antiguo.equals("") && tm.getUnidad_dim_3() != null) {
            unidad3Antigua = tm.getUnidad_dim_3().getNombre();
        } else {
            unidad3Antigua = Constantes.VACIO;
        }
        nombreUnidad4Antiguo = tm.getNombre_dim_4();
        if (!nombreUnidad4Antiguo.equals("") && tm.getUnidad_dim_4() != null) {
            unidad4Antigua = tm.getUnidad_dim_4().getNombre();
        } else {
            unidad4Antigua = Constantes.VACIO;
        }
        nombreUnidad5Antiguo = tm.getNombre_dim_5();
        if (!nombreUnidad5Antiguo.equals("") && tm.getUnidad_dim_5() != null) {
            unidad5Antigua = tm.getUnidad_dim_5().getNombre();
        } else {
            unidad5Antigua = Constantes.VACIO;
        }

        if (tm.getUnidad_resultado() != null) {
            unidadResultadoAntigua = tm.getUnidad_resultado().getNombre();
        } else {
            unidadResultadoAntigua = Constantes.VACIO;
        }

        formulaAntigua = tm.getFormula();
        tipoCalculoAntiguo = tm.getTipo_calculo();
        crearIconosBotones();
        crearAcciones();
    }

    private void crearAcciones() {
        KeyStroke escapeKeyStroke = KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false);
        Action escapeAction = new AbstractAction() {
            public void actionPerformed(ActionEvent e) {
                cerrarVentana();
            }
        }; 
        getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(escapeKeyStroke, "ESCAPE");
        getRootPane().getActionMap().put("ESCAPE", escapeAction);
    }
    
    private void cerrarVentana(){
        removeAll();
        dispose();
    }

    private void crearIconosBotones() {
        URL urlCancelar = getClass().getResource("/iconos/cancelar.gif");
        ImageIcon iconoCancelar = new ImageIcon(urlCancelar);
        bcancelar.setIcon(iconoCancelar);
        
        URL urlAceptar = getClass().getResource("/iconos/guardarYvolver.png");
        ImageIcon iconoAceptar = new ImageIcon(urlAceptar);
        baceptar.setIcon(iconoAceptar);
        
        URL urlModificar = getClass().getResource("/iconos/editar.png");
        ImageIcon iconoModificar = new ImageIcon(urlModificar);
        bmodificar.setIcon(iconoModificar);
    }

    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lcodigo = new javax.swing.JLabel();
        tnombre = new javax.swing.JTextField();
        baceptar = new javax.swing.JButton();
        bcancelar = new javax.swing.JButton();
        lnumd = new javax.swing.JLabel();
        tcodigo = new javax.swing.JTextField();
        ldim1 = new javax.swing.JLabel();
        ldim2 = new javax.swing.JLabel();
        ldim3 = new javax.swing.JLabel();
        ldim4 = new javax.swing.JLabel();
        ldim5 = new javax.swing.JLabel();
        lnombre = new javax.swing.JLabel();
        lnombredimension = new javax.swing.JLabel();
        tnomdim1 = new javax.swing.JTextField();
        tnomdim2 = new javax.swing.JTextField();
        tnomdim3 = new javax.swing.JTextField();
        tnomdim4 = new javax.swing.JTextField();
        tnomdim5 = new javax.swing.JTextField();
        tmag1 = new javax.swing.JTextField();
        tmag2 = new javax.swing.JTextField();
        tmag3 = new javax.swing.JTextField();
        tmag4 = new javax.swing.JTextField();
        tmag5 = new javax.swing.JTextField();
        bmodificar = new javax.swing.JButton();
        lunidaddimension = new javax.swing.JLabel();
        lmagnituddimension = new javax.swing.JLabel();
        cunidad1 = new javax.swing.JComboBox();
        cunidad2 = new javax.swing.JComboBox();
        cunidad3 = new javax.swing.JComboBox();
        cunidad4 = new javax.swing.JComboBox();
        cunidad5 = new javax.swing.JComboBox();
        lresultado = new javax.swing.JLabel();
        cunidadresultado = new javax.swing.JComboBox();
        tmag6 = new javax.swing.JTextField();
        ltipocalculo = new javax.swing.JLabel();
        ctipocalculo = new javax.swing.JComboBox();
        lformula = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tformula = new javax.swing.JTextArea();
        jSeparator1 = new javax.swing.JSeparator();
        jSeparator2 = new javax.swing.JSeparator();
        lformula1 = new javax.swing.JLabel();
        cdimensiones = new javax.swing.JComboBox();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        lcodigo.setText("Codigo");

        tnombre.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tnombreKeyReleased(evt);
            }
        });

        baceptar.setText("Aceptar");
        baceptar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                baceptarActionPerformed(evt);
            }
        });

        bcancelar.setText("Cancelar");
        bcancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bcancelarActionPerformed(evt);
            }
        });

        lnumd.setText("Nº de Dimensiones");

        tcodigo.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tcodigoKeyReleased(evt);
            }
        });

        ldim1.setText("Dimensión 1");

        ldim2.setText("Dimensión 2");

        ldim3.setText("Dimensión 3");

        ldim4.setText("Dimensión 4");

        ldim5.setText("Dimensión 5");

        lnombre.setText("Nombre");

        lnombredimension.setText("Nombre");

        tnomdim1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tnomdim1KeyReleased(evt);
            }
        });

        tnomdim2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tnomdim2KeyReleased(evt);
            }
        });

        tnomdim3.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tnomdim3KeyReleased(evt);
            }
        });

        tnomdim4.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tnomdim4KeyReleased(evt);
            }
        });

        tnomdim5.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tnomdim5KeyReleased(evt);
            }
        });

        tmag1.setEnabled(false);

        tmag2.setEnabled(false);

        tmag3.setEnabled(false);

        tmag4.setEnabled(false);

        tmag5.setEnabled(false);

        bmodificar.setText("Modificar");
        bmodificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bmodificarActionPerformed(evt);
            }
        });

        lunidaddimension.setText("Unidad por defecto");

        lmagnituddimension.setText("Magnitud");

        cunidad1.setModel(new javax.swing.DefaultComboBoxModel(new String[] {}));
        cunidad1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cunidad1ActionPerformed(evt);
            }
        });

        cunidad2.setModel(new javax.swing.DefaultComboBoxModel(new String[] {}));
        cunidad2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cunidad2ActionPerformed(evt);
            }
        });

        cunidad3.setModel(new javax.swing.DefaultComboBoxModel(new String[] {}));
        cunidad3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cunidad3ActionPerformed(evt);
            }
        });

        cunidad4.setModel(new javax.swing.DefaultComboBoxModel(new String[] {}));
        cunidad4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cunidad4ActionPerformed(evt);
            }
        });

        cunidad5.setModel(new javax.swing.DefaultComboBoxModel(new String[] {}));
        cunidad5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cunidad5ActionPerformed(evt);
            }
        });

        lresultado.setText("Resultado");

        cunidadresultado.setModel(new javax.swing.DefaultComboBoxModel(new String[] {}));
        cunidadresultado.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cunidadresultadoActionPerformed(evt);
            }
        });

        tmag6.setEnabled(false);

        ltipocalculo.setText("Tipo de cálculo");

        ctipocalculo.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "-- Vacío --", "Fórmula", "Producto"}));
        ctipocalculo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ctipocalculoActionPerformed(evt);
            }
        });

        lformula.setText("Formula");

        tformula.setColumns(20);
        tformula.setRows(5);
        tformula.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tformulaKeyReleased(evt);
            }
        });
        jScrollPane1.setViewportView(tformula);

        lformula1.setText("Ejemplo:      (((Dim1 + Dim2) * Dim3) - Dim5) / Dim4");

        cdimensiones.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "0", "1", "2", "3", "4", "5" }));
        cdimensiones.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cdimensionesActionPerformed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout layout = new org.jdesktop.layout.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(layout.createSequentialGroup()
                .addContainerGap()
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(layout.createSequentialGroup()
                        .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(layout.createSequentialGroup()
                                .add(lnumd)
                                .add(10, 10, 10)
                                .add(cdimensiones, 0, 96, Short.MAX_VALUE))
                            .add(layout.createSequentialGroup()
                                .add(lcodigo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 41, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                .add(tcodigo, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 150, Short.MAX_VALUE)))
                        .add(18, 18, 18)
                        .add(lnombre)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(tnombre, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 324, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(86, 86, 86))
                    .add(org.jdesktop.layout.GroupLayout.TRAILING, layout.createSequentialGroup()
                        .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                            .add(layout.createSequentialGroup()
                                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                                    .add(layout.createSequentialGroup()
                                        .add(ldim3)
                                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                        .add(tnomdim3, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 192, Short.MAX_VALUE))
                                    .add(layout.createSequentialGroup()
                                        .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                                            .add(ldim2)
                                            .add(ldim1))
                                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                        .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                                            .add(org.jdesktop.layout.GroupLayout.TRAILING, layout.createSequentialGroup()
                                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                                .add(lnombredimension)
                                                .add(155, 155, 155))
                                            .add(org.jdesktop.layout.GroupLayout.TRAILING, tnomdim1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 192, Short.MAX_VALUE)
                                            .add(tnomdim2, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 192, Short.MAX_VALUE))))
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                                    .add(layout.createSequentialGroup()
                                        .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                                            .add(cunidad2, 0, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .add(cunidad3, 0, 204, Short.MAX_VALUE))
                                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                        .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                                            .add(tmag2, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 175, Short.MAX_VALUE)
                                            .add(tmag3, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 175, Short.MAX_VALUE)))
                                    .add(layout.createSequentialGroup()
                                        .add(lunidaddimension)
                                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                        .add(lmagnituddimension))
                                    .add(layout.createSequentialGroup()
                                        .add(cunidad1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 204, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                        .add(tmag1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 175, Short.MAX_VALUE))))
                            .add(layout.createSequentialGroup()
                                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                                    .add(org.jdesktop.layout.GroupLayout.LEADING, layout.createSequentialGroup()
                                        .add(lresultado)
                                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED, 212, Short.MAX_VALUE)
                                        .add(cunidadresultado, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 204, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                                    .add(org.jdesktop.layout.GroupLayout.LEADING, layout.createSequentialGroup()
                                        .add(ldim5)
                                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                        .add(tnomdim5, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 193, Short.MAX_VALUE)
                                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                        .add(cunidad5, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 204, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                                    .add(layout.createSequentialGroup()
                                        .add(ldim4)
                                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                        .add(tnomdim4, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 193, Short.MAX_VALUE)
                                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                        .add(cunidad4, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 204, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                                .add(6, 6, 6)
                                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                                    .add(tmag6, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 174, Short.MAX_VALUE)
                                    .add(tmag5, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 174, Short.MAX_VALUE)
                                    .add(tmag4, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 174, Short.MAX_VALUE))))
                        .add(20, 20, 20)))
                .add(0, 0, 0))
            .add(jSeparator1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 674, Short.MAX_VALUE)
            .add(layout.createSequentialGroup()
                .addContainerGap()
                .add(jSeparator2, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 654, Short.MAX_VALUE)
                .addContainerGap())
            .add(layout.createSequentialGroup()
                .addContainerGap()
                .add(ltipocalculo)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(ctipocalculo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 204, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .add(45, 45, 45)
                .add(lformula1)
                .addContainerGap(97, Short.MAX_VALUE))
            .add(org.jdesktop.layout.GroupLayout.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .add(lformula)
                .add(36, 36, 36)
                .add(jScrollPane1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 580, Short.MAX_VALUE)
                .addContainerGap())
            .add(org.jdesktop.layout.GroupLayout.TRAILING, layout.createSequentialGroup()
                .addContainerGap(395, Short.MAX_VALUE)
                .add(baceptar)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                .add(bmodificar, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 103, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                .add(bcancelar)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(layout.createSequentialGroup()
                .addContainerGap()
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(lcodigo)
                    .add(tcodigo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(lnombre)
                    .add(tnombre, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(lnumd)
                    .add(cdimensiones, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jSeparator1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .add(14, 14, 14)
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(lmagnituddimension)
                    .add(lnombredimension)
                    .add(lunidaddimension))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(ldim1)
                    .add(cunidad1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(tnomdim1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 21, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(tmag1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .add(6, 6, 6)
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(ldim2)
                    .add(tnomdim2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 21, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(cunidad2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(tmag2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(ldim3)
                    .add(cunidad3, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(tmag3, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(tnomdim3, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 21, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(ldim4)
                    .add(tnomdim4, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 21, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(cunidad4, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(tmag4, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(ldim5)
                    .add(cunidad5, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(tnomdim5, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(tmag5, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                    .add(lresultado)
                    .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                        .add(tmag6, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(cunidadresultado, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                .add(9, 9, 9)
                .add(jSeparator2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(layout.createSequentialGroup()
                        .add(18, 18, 18)
                        .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(ltipocalculo)
                            .add(ctipocalculo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                        .add(17, 17, 17))
                    .add(layout.createSequentialGroup()
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED, 35, Short.MAX_VALUE)
                        .add(lformula1)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jScrollPane1)
                    .add(lformula))
                .add(18, 18, 18)
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(bcancelar)
                    .add(bmodificar)
                    .add(baceptar))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

private void baceptarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_baceptarActionPerformed
    String nombre = tnombre.getText(), codigo = tcodigo.getText();
    Integer numDim = Integer.parseInt((String) cdimensiones.getSelectedItem());
    int numDImRellenas = 0, numDimRellenasNombres = 0, dimResultado = 0;

    if (nombre != null && nombre.length() > 0 && codigo != null && codigo.length() > 0) {
        try {
            if (!comprobarFormula()) {
                JOptionPane.showMessageDialog(null, "Debe introducir la fórmula correspondiente", "Error", JOptionPane.ERROR_MESSAGE);
            } else {
                tm.setCodigo(codigo);
                tm.setNombre(nombre);
                tm.setNum_dimensiones(numDim);
                tm.setNombre_dim_1(tnomdim1.getText());
                tm.setNombre_dim_2(tnomdim2.getText());
                tm.setNombre_dim_3(tnomdim3.getText());
                tm.setNombre_dim_4(tnomdim4.getText());
                tm.setNombre_dim_5(tnomdim5.getText());

                String unidad1 = (String) cunidad1.getSelectedItem();
                if (!unidad1.equals(Constantes.VACIO)) {
                    tm.setUnidad_dim_1(BaseDatos.obtenerUnidadMedidaNombre(unidad1));
                    numDImRellenas++;
                } else {
                    tm.setUnidad_dim_1(null);
                }

                String unidad2 = (String) cunidad2.getSelectedItem();
                if (!unidad2.equals(Constantes.VACIO)) {
                    tm.setUnidad_dim_2(BaseDatos.obtenerUnidadMedidaNombre(unidad2));
                    numDImRellenas++;
                } else {
                    tm.setUnidad_dim_2(null);
                }

                String unidad3 = (String) cunidad3.getSelectedItem();
                if (!unidad3.equals(Constantes.VACIO)) {
                    tm.setUnidad_dim_3(BaseDatos.obtenerUnidadMedidaNombre(unidad3));
                    numDImRellenas++;
                } else {
                    tm.setUnidad_dim_3(null);
                }

                String unidad4 = (String) cunidad4.getSelectedItem();
                if (!unidad4.equals(Constantes.VACIO)) {
                    tm.setUnidad_dim_4(BaseDatos.obtenerUnidadMedidaNombre(unidad4));
                    numDImRellenas++;
                } else {
                    tm.setUnidad_dim_4(null);
                }

                String unidad5 = (String) cunidad5.getSelectedItem();
                if (!unidad5.equals(Constantes.VACIO)) {
                    tm.setUnidad_dim_5(BaseDatos.obtenerUnidadMedidaNombre(unidad5));
                    numDImRellenas++;
                } else {
                    tm.setUnidad_dim_5(null);
                }
                
                String resultado = (String) this.cunidadresultado.getSelectedItem();
                if (!resultado.equals(Constantes.VACIO)) {
                    tm.setUnidad_resultado(BaseDatos.obtenerUnidadMedidaNombre(resultado));
                    dimResultado++;
                }
                
                if(tnomdim1.getText() != null && !this.tnomdim1.getText().equals("")){
                    numDimRellenasNombres++;
                }
                
                if(tnomdim2.getText() != null && !this.tnomdim2.getText().equals("")){
                    numDimRellenasNombres++;
                }
                
                if(tnomdim3.getText() != null && !this.tnomdim3.getText().equals("")){
                    numDimRellenasNombres++;
                }
                
                if(tnomdim4.getText() != null && !this.tnomdim4.getText().equals("")){
                    numDimRellenasNombres++;
                }
                
                if(tnomdim5.getText() != null && !this.tnomdim5.getText().equals("")){
                    numDimRellenasNombres++;
                }
                
                if(!((numDImRellenas + numDimRellenasNombres + dimResultado) == (numDim * 2 + 1))){
                    JOptionPane.showMessageDialog(null, "Debe rellenar las magnitudes correspondientes", "Error", JOptionPane.ERROR_MESSAGE);
                } else {
                    tm.setTipo_calculo((String) ctipocalculo.getSelectedItem());
                    tm.setFormula(tformula.getText());
                    if (crear) {
                        if(BaseDatos.obtenerTipoMedida(codigo) == null){
                            if (BaseDatos.insertarElemento(tm)) {
                                cerrarVentana();
                            } else {
                                JOptionPane.showMessageDialog(null, "No se puede ha podido insertar el elemento", "Error", JOptionPane.ERROR_MESSAGE);
                            }
                        } else {
                            JOptionPane.showMessageDialog(null, "Ya hay un tipo de medida con el código " + codigo, "Error", JOptionPane.ERROR_MESSAGE);
                        }
                    } else {
                        if (hayCambios()) {
                            int hacerCambios = JOptionPane.showConfirmDialog(null, "Está seguro de que desea realizar los cambios?", "¿Realizar cambios?", JOptionPane.YES_NO_OPTION);
                            if (hacerCambios == 0) {
                                TipoMedida temp = null;
                                if(!codigoAntiguo.equals(codigo)){
                                    temp = BaseDatos.obtenerTipoMedida(codigo);
                                }

                                if(temp == null){
                                    if (BaseDatos.modificarElemento(tm)) {
                                        cerrarVentana();
                                    } else {
                                        JOptionPane.showMessageDialog(null, "No se puede ha podido modificar el elemento", "Error", JOptionPane.ERROR_MESSAGE);
                                    }
                                } else {
                                    JOptionPane.showMessageDialog(null, "Ya hay un tipo de medida con el código " + codigo, "Error", JOptionPane.ERROR_MESSAGE);
                                }
                            }
                        } else {
                            JOptionPane.showMessageDialog(null, "No hay cambios que realizar", "Sin cambios", JOptionPane.ERROR_MESSAGE);
                        }
                    }
                }
            }
        } catch (NumberFormatException e) {
            //Error, los campos numéricos no contienen números
            JOptionPane.showMessageDialog(null, "El campo \"Nº de dimensiones\" deben ser numérico", "Error", JOptionPane.ERROR_MESSAGE);
        }
    } else {
        JOptionPane.showMessageDialog(null, "Debe rellenar el Código y el Nombre", "Error", JOptionPane.ERROR_MESSAGE);
    }
}//GEN-LAST:event_baceptarActionPerformed

private void bcancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bcancelarActionPerformed
    cerrarVentana();
}//GEN-LAST:event_bcancelarActionPerformed

private void bmodificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bmodificarActionPerformed
    if (bmodificar.getText().equals("Modificar")) {
        //Si el botón tiene el texto Modificar
        tnombre.setEnabled(true);
        tcodigo.setEnabled(true);
        cdimensiones.setEnabled(true);
        tnomdim1.setEnabled(true);
        tnomdim2.setEnabled(true);
        tnomdim3.setEnabled(true);
        tnomdim4.setEnabled(true);
        tnomdim5.setEnabled(true);
        cunidad1.setEnabled(true);
        cunidad2.setEnabled(true);
        cunidad3.setEnabled(true);
        cunidad4.setEnabled(true);
        cunidad5.setEnabled(true);
        cunidadresultado.setEnabled(true);
        ctipocalculo.setEnabled(true);
        tformula.setEnabled(true);
        bmodificar.setText("Visualizar");
        bmodificar.setToolTipText("Visualizar campos");
        bmodificar.setToolTipText("Modificar campos");
        String numDim = (String) this.cdimensiones.getSelectedItem();
        habilitarUnidades(Integer.valueOf(numDim));
        habilitarFormula((String) ctipocalculo.getSelectedItem());
        
        URL urlModificar = getClass().getResource("/iconos/buscar.gif");
        ImageIcon iconoModificar = new ImageIcon(urlModificar);
        bmodificar.setIcon(iconoModificar);

    } else {
        //si el botón tiene el texto Visualizar
        tnombre.setEnabled(false);
        tcodigo.setEnabled(false);
        cdimensiones.setEnabled(false);
        tnomdim1.setEnabled(false);
        tnomdim2.setEnabled(false);
        tnomdim3.setEnabled(false);
        tnomdim4.setEnabled(false);
        tnomdim5.setEnabled(false);
        cunidad1.setEnabled(false);
        cunidad2.setEnabled(false);
        cunidad3.setEnabled(false);
        cunidad4.setEnabled(false);
        cunidad5.setEnabled(false);
        cunidadresultado.setEnabled(false);
        ctipocalculo.setEnabled(false);
        tformula.setEnabled(false);
        tformula.setEnabled(false);
        bmodificar.setText("Modificar");
        
        URL urlModificar = getClass().getResource("/iconos/editar.png");
        ImageIcon iconoModificar = new ImageIcon(urlModificar);
        bmodificar.setIcon(iconoModificar);
    }
}//GEN-LAST:event_bmodificarActionPerformed

private void cdimensionesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cdimensionesActionPerformed
    int numDim = Integer.valueOf((String) cdimensiones.getSelectedItem());
    habilitarUnidades(numDim);
    limpiarUnidades(numDim);
}//GEN-LAST:event_cdimensionesActionPerformed

private void cunidad1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cunidad1ActionPerformed
    String unidad1 = (String) cunidad1.getSelectedItem();
    if (unidad1.equals(Constantes.VACIO)) {
        tmag1.setText("");
    } else {
        UnidadMedida um = BaseDatos.obtenerUnidadMedidaNombre(unidad1);
        if (um.getMagnitud() != null) {
            tmag1.setText(um.getMagnitud().getNombre());
        } else {
            tmag1.setText(Constantes.VACIO);
        }
    }
}//GEN-LAST:event_cunidad1ActionPerformed

private void cunidad2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cunidad2ActionPerformed
    String unidad2 = (String) cunidad2.getSelectedItem();
    if (unidad2.equals(Constantes.VACIO)) {
        tmag2.setText("");
    } else {
        UnidadMedida um = BaseDatos.obtenerUnidadMedidaNombre(unidad2);
        if (um.getMagnitud() != null) {
            tmag2.setText(um.getMagnitud().getNombre());
        } else {
            tmag2.setText(Constantes.VACIO);
        }
    }
}//GEN-LAST:event_cunidad2ActionPerformed

private void cunidad3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cunidad3ActionPerformed
    String unidad3 = (String) cunidad3.getSelectedItem();
    if (unidad3.equals(Constantes.VACIO)) {
        tmag3.setText("");
    } else {
        UnidadMedida um = BaseDatos.obtenerUnidadMedidaNombre(unidad3);
        if (um.getMagnitud() != null) {
            tmag3.setText(um.getMagnitud().getNombre());
        } else {
            tmag3.setText(Constantes.VACIO);
        }
    }
}//GEN-LAST:event_cunidad3ActionPerformed

private void cunidad4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cunidad4ActionPerformed
    String unidad4 = (String) cunidad4.getSelectedItem();
    if (unidad4.equals(Constantes.VACIO)) {
        tmag4.setText("");
    } else {
        UnidadMedida um = BaseDatos.obtenerUnidadMedidaNombre(unidad4);
        if (um.getMagnitud() != null) {
            tmag4.setText(um.getMagnitud().getNombre());
        } else {
            tmag4.setText(Constantes.VACIO);
        }
    }
}//GEN-LAST:event_cunidad4ActionPerformed

private void cunidad5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cunidad5ActionPerformed
    String unidad5 = (String) cunidad5.getSelectedItem();
    if (unidad5.equals(Constantes.VACIO)) {
        tmag5.setText("");
    } else {
        UnidadMedida um = BaseDatos.obtenerUnidadMedidaNombre(unidad5);
        if (um.getMagnitud() != null) {
            tmag5.setText(um.getMagnitud().getNombre());
        } else {
            tmag5.setText(Constantes.VACIO);
        }
    }
}//GEN-LAST:event_cunidad5ActionPerformed

private void cunidadresultadoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cunidadresultadoActionPerformed
    String resultado = (String) cunidadresultado.getSelectedItem();
    if (resultado.equals(Constantes.VACIO)) {
        this.tmag6.setText("");
    } else {
        UnidadMedida um = BaseDatos.obtenerUnidadMedidaNombre(resultado);
        if (um.getMagnitud() != null) {
            tmag6.setText(um.getMagnitud().getNombre());
        } else {
            tmag6.setText(Constantes.VACIO);
        }
    }
}//GEN-LAST:event_cunidadresultadoActionPerformed

private void ctipocalculoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ctipocalculoActionPerformed
    habilitarFormula((String) this.ctipocalculo.getSelectedItem());
}//GEN-LAST:event_ctipocalculoActionPerformed

private void tcodigoKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tcodigoKeyReleased
    String codigo = tcodigo.getText();
    if(codigo.length() > Constantes.TAM_CODIGO_TIPO_MEDIDA){
        JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_CODIGO_TIPO_MEDIDA, "Error", JOptionPane.ERROR_MESSAGE);
        tcodigo.setText(codigo.substring(0, Constantes.TAM_CODIGO_TIPO_MEDIDA));
    }
}//GEN-LAST:event_tcodigoKeyReleased

private void tnombreKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tnombreKeyReleased
    String nombre = tnombre.getText();
    if(nombre.length() > Constantes.TAM_NOMBRE_TIPO_MEDIDA){
        JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_NOMBRE_TIPO_MEDIDA, "Error", JOptionPane.ERROR_MESSAGE);
        tnombre.setText(nombre.substring(0, Constantes.TAM_NOMBRE_TIPO_MEDIDA));
    }
}//GEN-LAST:event_tnombreKeyReleased

private void tnomdim1KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tnomdim1KeyReleased
    String nombre = tnomdim1.getText();
    if(nombre.length() > Constantes.TAM_NOMBRE_DIM_1_TIPO_MEDIDA){
        JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_NOMBRE_DIM_1_TIPO_MEDIDA, "Error", JOptionPane.ERROR_MESSAGE);
        tnomdim1.setText(nombre.substring(0, Constantes.TAM_NOMBRE_DIM_1_TIPO_MEDIDA));
    }
}//GEN-LAST:event_tnomdim1KeyReleased

private void tnomdim2KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tnomdim2KeyReleased
    String nombre = tnomdim2.getText();
    if(nombre.length() > Constantes.TAM_NOMBRE_DIM_2_TIPO_MEDIDA){
        JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_NOMBRE_DIM_2_TIPO_MEDIDA, "Error", JOptionPane.ERROR_MESSAGE);
        tnomdim2.setText(nombre.substring(0, Constantes.TAM_NOMBRE_DIM_2_TIPO_MEDIDA));
    }
}//GEN-LAST:event_tnomdim2KeyReleased

private void tnomdim3KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tnomdim3KeyReleased
    String nombre = tnomdim3.getText();
    if(nombre.length() > Constantes.TAM_NOMBRE_DIM_3_TIPO_MEDIDA){
        JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_NOMBRE_DIM_3_TIPO_MEDIDA, "Error", JOptionPane.ERROR_MESSAGE);
        tnomdim3.setText(nombre.substring(0, Constantes.TAM_NOMBRE_DIM_3_TIPO_MEDIDA));
    }
}//GEN-LAST:event_tnomdim3KeyReleased

private void tnomdim4KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tnomdim4KeyReleased
    String nombre = tnomdim4.getText();
    if(nombre.length() > Constantes.TAM_NOMBRE_DIM_4_TIPO_MEDIDA){
        JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_NOMBRE_DIM_4_TIPO_MEDIDA, "Error", JOptionPane.ERROR_MESSAGE);
        tnomdim4.setText(nombre.substring(0, Constantes.TAM_NOMBRE_DIM_4_TIPO_MEDIDA));
    }
}//GEN-LAST:event_tnomdim4KeyReleased

private void tnomdim5KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tnomdim5KeyReleased
    String nombre = tnomdim5.getText();
    if(nombre.length() > Constantes.TAM_NOMBRE_DIM_5_TIPO_MEDIDA){
        JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_NOMBRE_DIM_5_TIPO_MEDIDA, "Error", JOptionPane.ERROR_MESSAGE);
        tnomdim5.setText(nombre.substring(0, Constantes.TAM_NOMBRE_DIM_5_TIPO_MEDIDA));
    }
}//GEN-LAST:event_tnomdim5KeyReleased

private void tformulaKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tformulaKeyReleased
    String formula = tformula.getText();
    if(formula.length() > Constantes.TAM_FORMULA_TIPO_MEDIDA){
        JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_FORMULA_TIPO_MEDIDA, "Error", JOptionPane.ERROR_MESSAGE);
        tformula.setText(formula.substring(0, Constantes.TAM_FORMULA_TIPO_MEDIDA));
    }
}//GEN-LAST:event_tformulaKeyReleased

    private void rellenarUnidades() {
        List lunidades = BaseDatos.getListaUnidadMedidas();
        UnidadMedida um;
        cunidad1.addItem(Constantes.VACIO);
        cunidad2.addItem(Constantes.VACIO);
        cunidad3.addItem(Constantes.VACIO);
        cunidad4.addItem(Constantes.VACIO);
        cunidad5.addItem(Constantes.VACIO);
        cunidadresultado.addItem(Constantes.VACIO);

        for (Iterator<UnidadMedida> it = lunidades.iterator(); it.hasNext();) {
            um = it.next();
            cunidad1.addItem(um.getNombre());
            cunidad2.addItem(um.getNombre());
            cunidad3.addItem(um.getNombre());
            cunidad4.addItem(um.getNombre());
            cunidad5.addItem(um.getNombre());
            cunidadresultado.addItem(um.getNombre());
        }
    }

    private void habilitarFormula(String tc) {
		tformula.setEnabled(tc.equals(Constantes.FORMULA));
    }

    private void limpiarUnidades(int numDim) {
        if (numDim == 0) {
            tnomdim1.setEnabled(false);
            cunidad1.setEnabled(false);
            tnomdim1.setText("");
            cunidad1.setSelectedIndex(0);
            tnomdim2.setEnabled(false);
            cunidad2.setEnabled(false);
            cunidad2.setSelectedIndex(0);
            tnomdim2.setText("");
            tnomdim3.setEnabled(false);
            cunidad3.setEnabled(false);
            cunidad3.setSelectedIndex(0);
            tnomdim3.setText("");
            tnomdim4.setEnabled(false);
            cunidad4.setEnabled(false);
            cunidad4.setSelectedIndex(0);
            tnomdim4.setText("");
            tnomdim5.setEnabled(false);
            cunidad5.setEnabled(false);
            cunidad5.setSelectedIndex(0);
            tnomdim5.setText("");
        } else if (numDim == 1) {
            tnomdim1.setEnabled(true);
            cunidad1.setEnabled(true);
            tnomdim2.setEnabled(false);
            cunidad2.setEnabled(false);
            cunidad2.setSelectedIndex(0);
            tnomdim2.setText("");
            tnomdim3.setEnabled(false);
            cunidad3.setEnabled(false);
            cunidad3.setSelectedIndex(0);
            tnomdim3.setText("");
            tnomdim4.setEnabled(false);
            cunidad4.setEnabled(false);
            cunidad4.setSelectedIndex(0);
            tnomdim4.setText("");
            tnomdim5.setEnabled(false);
            cunidad5.setEnabled(false);
            cunidad5.setSelectedIndex(0);
            tnomdim5.setText("");
        } else if (numDim == 2) {
            tnomdim1.setEnabled(true);
            cunidad1.setEnabled(true);
            tnomdim2.setEnabled(true);
            cunidad2.setEnabled(true);
            tnomdim3.setEnabled(false);
            cunidad3.setEnabled(false);
            cunidad3.setSelectedIndex(0);
            tnomdim3.setText("");
            tnomdim4.setEnabled(false);
            cunidad4.setEnabled(false);
            cunidad4.setSelectedIndex(0);
            tnomdim4.setText("");
            tnomdim5.setEnabled(false);
            cunidad5.setEnabled(false);
            cunidad5.setSelectedIndex(0);
            tnomdim5.setText("");
        } else if (numDim == 3) {
            tnomdim1.setEnabled(true);
            cunidad1.setEnabled(true);
            tnomdim2.setEnabled(true);
            cunidad2.setEnabled(true);
            tnomdim3.setEnabled(true);
            cunidad3.setEnabled(true);
            tnomdim4.setEnabled(false);
            cunidad4.setEnabled(false);
            cunidad4.setSelectedIndex(0);
            tnomdim4.setText("");
            tnomdim5.setEnabled(false);
            cunidad5.setEnabled(false);
            cunidad5.setSelectedIndex(0);
            tnomdim5.setText("");
        } else if (numDim == 4) {
            tnomdim1.setEnabled(true);
            cunidad1.setEnabled(true);
            tnomdim2.setEnabled(true);
            cunidad2.setEnabled(true);
            tnomdim3.setEnabled(true);
            cunidad3.setEnabled(true);
            tnomdim4.setEnabled(true);
            cunidad4.setEnabled(true);
            tnomdim5.setEnabled(false);
            cunidad5.setEnabled(false);
            cunidad5.setSelectedIndex(0);
            tnomdim5.setText("");
        } else {
            tnomdim1.setEnabled(true);
            cunidad1.setEnabled(true);
            tnomdim2.setEnabled(true);
            cunidad2.setEnabled(true);
            tnomdim3.setEnabled(true);
            cunidad3.setEnabled(true);
            tnomdim4.setEnabled(true);
            cunidad4.setEnabled(true);
            tnomdim5.setEnabled(true);
            cunidad5.setEnabled(true);
        }
    }
    
    private void habilitarUnidades(int numDim) {
        if (numDim == 0) {
            tnomdim1.setEnabled(false);
            cunidad1.setEnabled(false);
            tnomdim2.setEnabled(false);
            cunidad2.setEnabled(false);
            tnomdim3.setEnabled(false);
            cunidad3.setEnabled(false);
            tnomdim4.setEnabled(false);
            cunidad4.setEnabled(false);
            tnomdim5.setEnabled(false);
            cunidad5.setEnabled(false);
        } else if (numDim == 1) {
            tnomdim1.setEnabled(true);
            cunidad1.setEnabled(true);
            tnomdim2.setEnabled(false);
            cunidad2.setEnabled(false);
            tnomdim3.setEnabled(false);
            cunidad3.setEnabled(false);
            tnomdim4.setEnabled(false);
            cunidad4.setEnabled(false);
            tnomdim5.setEnabled(false);
            cunidad5.setEnabled(false);
        } else if (numDim == 2) {
            tnomdim1.setEnabled(true);
            cunidad1.setEnabled(true);
            tnomdim2.setEnabled(true);
            cunidad2.setEnabled(true);
            tnomdim3.setEnabled(false);
            cunidad3.setEnabled(false);
            tnomdim4.setEnabled(false);
            cunidad4.setEnabled(false);
            tnomdim5.setEnabled(false);
            cunidad5.setEnabled(false);
        } else if (numDim == 3) {
            tnomdim1.setEnabled(true);
            cunidad1.setEnabled(true);
            tnomdim2.setEnabled(true);
            cunidad2.setEnabled(true);
            tnomdim3.setEnabled(true);
            cunidad3.setEnabled(true);
            tnomdim4.setEnabled(false);
            cunidad4.setEnabled(false);
            tnomdim5.setEnabled(false);
            cunidad5.setEnabled(false);
        } else if (numDim == 4) {
            tnomdim1.setEnabled(true);
            cunidad1.setEnabled(true);
            tnomdim2.setEnabled(true);
            cunidad2.setEnabled(true);
            tnomdim3.setEnabled(true);
            cunidad3.setEnabled(true);
            tnomdim4.setEnabled(true);
            cunidad4.setEnabled(true);
            tnomdim5.setEnabled(false);
            cunidad5.setEnabled(false);
        } else {
            tnomdim1.setEnabled(true);
            cunidad1.setEnabled(true);
            tnomdim2.setEnabled(true);
            cunidad2.setEnabled(true);
            tnomdim3.setEnabled(true);
            cunidad3.setEnabled(true);
            tnomdim4.setEnabled(true);
            cunidad4.setEnabled(true);
            tnomdim5.setEnabled(true);
            cunidad5.setEnabled(true);
        }
    }

    private boolean comprobarFormula() {
        return !((String) ctipocalculo.getSelectedItem()).equals("Fórmula") ||
                ((String) ctipocalculo.getSelectedItem()).equals("Fórmula") && !((String) tformula.getText()).equals("");
    }

    private boolean hayCambios() {
        return !tcodigo.getText().equals(codigoAntiguo) ||
                !tnombre.getText().equals(nombreAntiguo) ||
                !((String) cdimensiones.getSelectedItem()).equals(numDimAntigua.toString()) ||
                !tnomdim1.getText().equals(nombreUnidad1Antiguo) ||
                !tnomdim2.getText().equals(nombreUnidad2Antiguo) ||
                !tnomdim3.getText().equals(nombreUnidad3Antiguo) ||
                !tnomdim4.getText().equals(nombreUnidad4Antiguo) ||
                !tnomdim5.getText().equals(nombreUnidad5Antiguo) ||
                !((String) ctipocalculo.getSelectedItem()).equals(tipoCalculoAntiguo) ||
                !tformula.getText().equals(formulaAntigua) ||
                !((String) cunidad1.getSelectedItem()).equals(unidad1Antigua) ||
                !((String) cunidad2.getSelectedItem()).equals(unidad2Antigua) ||
                !((String) cunidad3.getSelectedItem()).equals(unidad3Antigua) ||
                !((String) cunidad4.getSelectedItem()).equals(unidad4Antigua) ||
                !((String) cunidad5.getSelectedItem()).equals(unidad5Antigua) ||
                !((String) cunidadresultado.getSelectedItem()).equals(unidadResultadoAntigua);
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton baceptar;
    private javax.swing.JButton bcancelar;
    private javax.swing.JButton bmodificar;
    private javax.swing.JComboBox cdimensiones;
    private javax.swing.JComboBox ctipocalculo;
    private javax.swing.JComboBox cunidad1;
    private javax.swing.JComboBox cunidad2;
    private javax.swing.JComboBox cunidad3;
    private javax.swing.JComboBox cunidad4;
    private javax.swing.JComboBox cunidad5;
    private javax.swing.JComboBox cunidadresultado;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JLabel lcodigo;
    private javax.swing.JLabel ldim1;
    private javax.swing.JLabel ldim2;
    private javax.swing.JLabel ldim3;
    private javax.swing.JLabel ldim4;
    private javax.swing.JLabel ldim5;
    private javax.swing.JLabel lformula;
    private javax.swing.JLabel lformula1;
    private javax.swing.JLabel lmagnituddimension;
    private javax.swing.JLabel lnombre;
    private javax.swing.JLabel lnombredimension;
    private javax.swing.JLabel lnumd;
    private javax.swing.JLabel lresultado;
    private javax.swing.JLabel ltipocalculo;
    private javax.swing.JLabel lunidaddimension;
    private javax.swing.JTextField tcodigo;
    private javax.swing.JTextArea tformula;
    private javax.swing.JTextField tmag1;
    private javax.swing.JTextField tmag2;
    private javax.swing.JTextField tmag3;
    private javax.swing.JTextField tmag4;
    private javax.swing.JTextField tmag5;
    private javax.swing.JTextField tmag6;
    private javax.swing.JTextField tnombre;
    private javax.swing.JTextField tnomdim1;
    private javax.swing.JTextField tnomdim2;
    private javax.swing.JTextField tnomdim3;
    private javax.swing.JTextField tnomdim4;
    private javax.swing.JTextField tnomdim5;
    // End of variables declaration//GEN-END:variables
}
