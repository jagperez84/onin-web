package gui;

import bean.Agentes;
import acceso.*;
import bean.Empresa;
import bean.FormaPago;
import bean.Iva;
import bean.TipoAgente;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Iterator;
import java.util.List;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JOptionPane;
import javax.swing.KeyStroke;
import modelo.Modelo;
import util.Constantes;
import util.Util;

public class NuevoAgente extends javax.swing.JFrame {

    private Agentes a;
    private boolean crear;
    private String codigoAntiguo;
    private String nombreComercialAntiguo;
    private String nombreFiscalAntiguo;
    private String cifAntiguo;
    private String paisAntiguo;
    private String provinciaAntigua;
    private String poblacionAntigua;
    private String direccionAntigua;
    private String cpAntiguo;
    private String tlfAntiguo;
    private String tlf2Antiguo;
    private String tlf3Antiguo;
    private String faxAntiguo;
    private String mailAntiguo;
    private String tipoAntiguo;
    private String ivaAntiguo;
    private String formaPagoAntigua;
    private String diaCobro1Antiguo;
    private String diaCobro2Antiguo;
    private String diaCobro3Antiguo;
    private Empresa e;

    public NuevoAgente(String titulo, Empresa e) {
        super(titulo);
        crear = true;
        a = new Agentes();
        this.e = e;
        initComponents();
        bcancelar.setToolTipText("Cancelar la creación");
        baceptar.setToolTipText("Realizar la modificación");
        bmodificar.setVisible(false);

        remove(pLista);
        repaint();
        pack();
        iniciarDiasCobro();
        crearIconosBotones();
        crearAcciones();
    }

    public NuevoAgente(String titulo, Agentes a, Empresa e) {
        super(titulo);
        this.a = a;
        this.e = e;
        crear = false;
        initComponents();
        iniciarDiasCobro();
        bcancelar.setToolTipText("Cancelar la creación");
        baceptar.setToolTipText("Realizar la modificación");
        bmodificar.setToolTipText("Modificar campos");

        tcodigo.setText(a.getCod_agente());
        tnombreFiscal.setText(a.getNombre_fiscal());
        tnombrecomercial.setText(a.getNombre_comercial());
        tCif.setText(a.getCif_nif());
        tpais.setText(a.getPais());
        tprovincia.setText(a.getProvincia());
        tpoblacion.setText(a.getPoblacion());
        tdireccion.setText(a.getDireccion());
        tcp.setText(String.valueOf(a.getCodigo_postal()));
        ttlf.setText(a.getTelefono());
        ttlf2.setText(a.getTelefono2());
        ttlf3.setText(a.getTelefono3());
        tmail.setText(a.getEmail());
        tfax.setText(a.getFax());
        ctipo.setSelectedItem(a.getTipo_agente().getDescripcion());

        if (a.getIva() != null) {
            String sPorcentaje = a.getIva().getPorcentaje() + "%";
            cIva.setSelectedItem(sPorcentaje);
            ivaAntiguo = sPorcentaje;
        } else {
            ivaAntiguo = "-- Vacío -- ";
        }

        if (a.getDiaCobro1() != null) {
            cDiaCobro1.setSelectedItem((String) a.getDiaCobro1().toString());
            diaCobro1Antiguo = (String) a.getDiaCobro1().toString();
        } else {
            diaCobro1Antiguo = "--";
        }

        if (a.getDiaCobro2() != null) {
            cDiaCobro2.setSelectedItem((String) a.getDiaCobro2().toString());
            diaCobro2Antiguo = (String) a.getDiaCobro2().toString();
        } else {
            diaCobro2Antiguo = "--";
        }

        if (a.getDiaCobro3() != null) {
            cDiaCobro3.setSelectedItem((String) a.getDiaCobro3().toString());
            diaCobro3Antiguo = (String) a.getDiaCobro3().toString();
        } else {
            diaCobro3Antiguo = "--";
        }

        cDiaCobro1.setEnabled(false);
        cDiaCobro2.setEnabled(false);
        cDiaCobro3.setEnabled(false);

        tcodigo.setEnabled(false);
        tnombreFiscal.setEnabled(false);
        tnombrecomercial.setEnabled(false);
        tCif.setEnabled(false);
        tpais.setEnabled(false);
        tprovincia.setEnabled(false);
        tpoblacion.setEnabled(false);
        tdireccion.setEnabled(false);
        tcp.setEnabled(false);
        ttlf.setEnabled(false);
        ttlf2.setEnabled(false);
        ttlf3.setEnabled(false);
        tmail.setEnabled(false);
        tfax.setEnabled(false);
        ctipo.setEnabled(false);
        cIva.setEnabled(false);

        codigoAntiguo = a.getCod_agente();
        nombreComercialAntiguo = a.getNombre_comercial();
        nombreFiscalAntiguo = a.getNombre_fiscal();
        cifAntiguo = a.getCif_nif();
        paisAntiguo = a.getPais();
        provinciaAntigua = a.getProvincia();
        poblacionAntigua = a.getPoblacion();
        direccionAntigua = a.getDireccion();
        cpAntiguo = String.valueOf(a.getCodigo_postal());
        tlfAntiguo = a.getTelefono();
        tlf2Antiguo = a.getTelefono2();
        tlf3Antiguo = a.getTelefono3();
        faxAntiguo = a.getFax();
        mailAntiguo = a.getEmail();
        tipoAntiguo = a.getTipo_agente().getDescripcion();

        if (a.getFormaPago() != null) {
            FormaPago fp = BaseDatos.obtenerFormaPagoPorIid(a.getFormaPago().getIid());
            formaPagoAntigua = fp.getCodigo();
            cFormaPago.setSelectedItem(formaPagoAntigua);
        } else {
            formaPagoAntigua = Constantes.VACIO;
        }
        cFormaPago.setEnabled(false);

        crearIconosBotones();
        crearAcciones();
    }

    private void crearAcciones() {
        KeyStroke escapeKeyStroke = KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false);
        Action escapeAction = new AbstractAction() {
            public void actionPerformed(ActionEvent e) {
                cerrarAgente();
            }
        };
        getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(escapeKeyStroke, "ESCAPE");
        getRootPane().getActionMap().put("ESCAPE", escapeAction);
    }

    private void crearIconosBotones() {
        URL urlCancelar = getClass().getResource("/iconos/cancelar.gif");
        ImageIcon iconoCancelar = new ImageIcon(urlCancelar);
        bcancelar.setIcon(iconoCancelar);

        URL urlAceptar = getClass().getResource("/iconos/guardarYvolver.png");
        ImageIcon iconoAceptar = new ImageIcon(urlAceptar);
        baceptar.setIcon(iconoAceptar);

        URL urlModificar = getClass().getResource("/iconos/editar.png");
        ImageIcon iconoModificar = new ImageIcon(urlModificar);
        bmodificar.setIcon(iconoModificar);
    }

    private void cerrarAgente() {
        removeAll();
        dispose();
    }

    private void iniciarDiasCobro() {
        cDiaCobro1.addItem("--");
        cDiaCobro2.addItem("--");
        cDiaCobro3.addItem("--");
        for (Integer i = 1; i < 32; i++) {
            cDiaCobro1.addItem(i.toString());
            cDiaCobro2.addItem(i.toString());
            cDiaCobro3.addItem(i.toString());
        }
    }

    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        bcancelar = new javax.swing.JButton();
        baceptar = new javax.swing.JButton();
        bmodificar = new javax.swing.JButton();
        pGeneral = new javax.swing.JPanel();
        tnombreFiscal = new javax.swing.JTextField();
        lcp = new javax.swing.JLabel();
        tnombrecomercial = new javax.swing.JTextField();
        lcif = new javax.swing.JLabel();
        ltipo = new javax.swing.JLabel();
        tprovincia = new javax.swing.JTextField();
        tCif = new javax.swing.JTextField();
        tpais = new javax.swing.JTextField();
        lpoblacion = new javax.swing.JLabel();
        tdireccion = new javax.swing.JTextField();
        ltelefono2 = new javax.swing.JLabel();
        lmail = new javax.swing.JLabel();
        lnombrecomercial = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        lnombrefiscal = new javax.swing.JLabel();
        tcodigo = new javax.swing.JTextField();
        lprovincia = new javax.swing.JLabel();
        ttlf2 = new javax.swing.JTextField();
        ltelefono = new javax.swing.JLabel();
        lcodigo = new javax.swing.JLabel();
        lpais = new javax.swing.JLabel();
        ltelefono3 = new javax.swing.JLabel();
        tfax = new javax.swing.JTextField();
        tmail = new javax.swing.JTextField();
        tpoblacion = new javax.swing.JTextField();
        ttlf = new javax.swing.JTextField();
        ttlf3 = new javax.swing.JTextField();
        tcp = new javax.swing.JTextField();
        ldireccion = new javax.swing.JLabel();
        ctipo = new javax.swing.JComboBox();
        lfax = new javax.swing.JLabel();
        lIva = new javax.swing.JLabel();
        cIva = new javax.swing.JComboBox();
        lFormaPago = new javax.swing.JLabel();
        cFormaPago = new javax.swing.JComboBox();
        cDiaCobro1 = new javax.swing.JComboBox();
        cDiaCobro3 = new javax.swing.JComboBox();
        cDiaCobro2 = new javax.swing.JComboBox();
        lDiaCobro = new javax.swing.JLabel();
        pLista = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        Modelo modelo = new Modelo();
        tPresupuestos = new javax.swing.JTable(modelo);

        bcancelar.setText("Cancelar");
        bcancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bcancelarActionPerformed(evt);
            }
        });

        baceptar.setText("Aceptar");
        baceptar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                baceptarActionPerformed(evt);
            }
        });

        bmodificar.setText("Modificar");
        bmodificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bmodificarActionPerformed(evt);
            }
        });

        tnombreFiscal.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tnombreFiscalKeyReleased(evt);
            }
        });

        lcp.setText("Código Postal");

        tnombrecomercial.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tnombrecomercialKeyReleased(evt);
            }
        });

        lcif.setText("C.I.F.");

        ltipo.setText("Tipo Agente");

        tprovincia.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tprovinciaKeyReleased(evt);
            }
        });

        tCif.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tCifKeyReleased(evt);
            }
        });

        tpais.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tpaisKeyReleased(evt);
            }
        });

        lpoblacion.setText("Población");

        tdireccion.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tdireccionKeyReleased(evt);
            }
        });

        ltelefono2.setText("Telefono 2");

        lmail.setText("E-mail");

        lnombrecomercial.setText("Nombre Comercial");

        lnombrefiscal.setText("Nombre Fiscal");

        tcodigo.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tcodigoKeyReleased(evt);
            }
        });

        lprovincia.setText("Provincia");

        ttlf2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                ttlf2KeyReleased(evt);
            }
        });

        ltelefono.setText("Teléfono");

        lcodigo.setText("Código");

        lpais.setText("Pais");

        ltelefono3.setText("Teléfono 3");

        tfax.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tfaxKeyReleased(evt);
            }
        });

        tmail.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tmailKeyReleased(evt);
            }
        });

        tpoblacion.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tpoblacionKeyReleased(evt);
            }
        });

        ttlf.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                ttlfKeyReleased(evt);
            }
        });

        ttlf3.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                ttlf3KeyReleased(evt);
            }
        });

        tcp.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tcpKeyReleased(evt);
            }
        });

        ldireccion.setText("Dirección");

        ctipo.setModel(new javax.swing.DefaultComboBoxModel(new String[] { }));

        lfax.setText("Fax");

        lIva.setText("Iva");

        cIva.setModel(new javax.swing.DefaultComboBoxModel(new String[] { }));

        lFormaPago.setText("Forma de pago");

        cFormaPago.setModel(new javax.swing.DefaultComboBoxModel(new String[] {}));
        //Creamos la lista de formas de pago
        cFormaPago.addItem(Constantes.VACIO);
        List lfp = BaseDatos.getListaFormaPago();
        FormaPago fpaux;
        for (Iterator it = lfp.iterator(); it.hasNext();) {
            fpaux = (FormaPago) it.next();
            cFormaPago.addItem(fpaux.getCodigo());
        }

        cDiaCobro1.setModel(new javax.swing.DefaultComboBoxModel(new String[] {}));

        cDiaCobro3.setModel(new javax.swing.DefaultComboBoxModel(new String[] {}));

        cDiaCobro2.setModel(new javax.swing.DefaultComboBoxModel(new String[] {}));

        lDiaCobro.setText("Días de cobro");

        org.jdesktop.layout.GroupLayout pGeneralLayout = new org.jdesktop.layout.GroupLayout(pGeneral);
        pGeneral.setLayout(pGeneralLayout);
        pGeneralLayout.setHorizontalGroup(
            pGeneralLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(pGeneralLayout.createSequentialGroup()
                .addContainerGap()
                .add(pGeneralLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(org.jdesktop.layout.GroupLayout.TRAILING, pGeneralLayout.createSequentialGroup()
                        .add(pGeneralLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                            .add(org.jdesktop.layout.GroupLayout.LEADING, pGeneralLayout.createSequentialGroup()
                                .add(ltipo, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 86, Short.MAX_VALUE)
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                .add(ctipo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 213, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                            .add(pGeneralLayout.createSequentialGroup()
                                .add(pGeneralLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                                    .add(lcif, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 86, Short.MAX_VALUE)
                                    .add(lcodigo)
                                    .add(lnombrefiscal, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 86, Short.MAX_VALUE)
                                    .add(lnombrecomercial, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                .add(pGeneralLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING, false)
                                    .add(tCif)
                                    .add(org.jdesktop.layout.GroupLayout.LEADING, tnombrecomercial, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 213, Short.MAX_VALUE)
                                    .add(org.jdesktop.layout.GroupLayout.LEADING, tnombreFiscal)
                                    .add(org.jdesktop.layout.GroupLayout.LEADING, tcodigo))))
                        .add(43, 43, 43)
                        .add(pGeneralLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(pGeneralLayout.createSequentialGroup()
                                .add(lIva, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 58, Short.MAX_VALUE)
                                .add(18, 18, 18)
                                .add(cIva, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 135, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                            .add(org.jdesktop.layout.GroupLayout.TRAILING, pGeneralLayout.createSequentialGroup()
                                .add(pGeneralLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                                    .add(lDiaCobro, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 72, Short.MAX_VALUE)
                                    .add(lFormaPago))
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                .add(pGeneralLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                                    .add(cFormaPago, 0, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .add(org.jdesktop.layout.GroupLayout.TRAILING, pGeneralLayout.createSequentialGroup()
                                        .add(cDiaCobro1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 41, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                        .add(cDiaCobro2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 41, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                        .add(cDiaCobro3, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 41, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))))
                        .add(123, 123, 123))
                    .add(org.jdesktop.layout.GroupLayout.TRAILING, pGeneralLayout.createSequentialGroup()
                        .add(pGeneralLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(pGeneralLayout.createSequentialGroup()
                                .add(pGeneralLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                                    .add(ldireccion, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 88, Short.MAX_VALUE)
                                    .add(lpais)
                                    .add(lpoblacion, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 88, Short.MAX_VALUE)
                                    .add(lprovincia, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 88, Short.MAX_VALUE))
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                .add(pGeneralLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING, false)
                                    .add(tdireccion)
                                    .add(org.jdesktop.layout.GroupLayout.LEADING, tpoblacion)
                                    .add(tprovincia)
                                    .add(tpais, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 205, Short.MAX_VALUE))
                                .add(30, 30, 30))
                            .add(pGeneralLayout.createSequentialGroup()
                                .add(lcp, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 80, Short.MAX_VALUE)
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                                .add(tcp, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 209, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                .add(28, 28, 28)))
                        .add(13, 13, 13)
                        .add(pGeneralLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(lmail, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 66, Short.MAX_VALUE)
                            .add(lfax, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 66, Short.MAX_VALUE)
                            .add(ltelefono)
                            .add(ltelefono3, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 66, Short.MAX_VALUE)
                            .add(ltelefono2, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 66, Short.MAX_VALUE))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(pGeneralLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING, false)
                            .add(tmail)
                            .add(tfax)
                            .add(org.jdesktop.layout.GroupLayout.LEADING, ttlf2, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 213, Short.MAX_VALUE)
                            .add(org.jdesktop.layout.GroupLayout.LEADING, ttlf3)
                            .add(org.jdesktop.layout.GroupLayout.LEADING, ttlf))
                        .add(57, 57, 57))
                    .add(jSeparator1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 640, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );
        pGeneralLayout.setVerticalGroup(
            pGeneralLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(pGeneralLayout.createSequentialGroup()
                .addContainerGap()
                .add(pGeneralLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(pGeneralLayout.createSequentialGroup()
                        .add(pGeneralLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(lcodigo)
                            .add(tcodigo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(pGeneralLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(lnombrecomercial)
                            .add(tnombrecomercial, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(pGeneralLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(lnombrefiscal)
                            .add(tnombreFiscal, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(pGeneralLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(lcif)
                            .add(tCif, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(pGeneralLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(ltipo)
                            .add(ctipo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                    .add(pGeneralLayout.createSequentialGroup()
                        .add(pGeneralLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(lIva)
                            .add(cIva, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(pGeneralLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(lFormaPago)
                            .add(cFormaPago, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(pGeneralLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(lDiaCobro)
                            .add(cDiaCobro1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(cDiaCobro2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(cDiaCobro3, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jSeparator1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 3, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .add(11, 11, 11)
                .add(pGeneralLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(pGeneralLayout.createSequentialGroup()
                        .add(pGeneralLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(lpais)
                            .add(tpais, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(pGeneralLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(lprovincia)
                            .add(tprovincia, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(pGeneralLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(lpoblacion)
                            .add(tpoblacion, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(pGeneralLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(ldireccion)
                            .add(tdireccion, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(pGeneralLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                            .add(lcp)
                            .add(tcp, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                    .add(pGeneralLayout.createSequentialGroup()
                        .add(pGeneralLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(ltelefono)
                            .add(ttlf, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(pGeneralLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(ltelefono2)
                            .add(ttlf2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(pGeneralLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(ltelefono3)
                            .add(ttlf3, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(pGeneralLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(lfax)
                            .add(tfax, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(pGeneralLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(lmail)
                            .add(tmail, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap())
        );

        List ltipoAgente = BaseDatos.getListaTipoAgentes();
        TipoAgente ta;
        for (Iterator it = ltipoAgente.iterator(); it.hasNext();) {
            ta = (TipoAgente) it.next();
            ctipo.addItem(ta.getDescripcion());
        }
        List lIva = BaseDatos.getListaIva();
        Iva iva;
        cIva.addItem(Constantes.VACIO);
        for (Iterator it = lIva.iterator(); it.hasNext();) {
            iva = (Iva) it.next();
            cIva.addItem(iva.getPorcentaje()+"%");
        }

        pLista.setBorder(javax.swing.BorderFactory.createTitledBorder("Elementos Asociados"));

        modelo.addColumn("Documento");
        modelo.addColumn("Número");
        modelo.addColumn("Serie");
        modelo.addColumn("Fecha");
        modelo.addColumn("Imp. Total");
        modelo.addColumn("Estado");
        SimpleDateFormat formatoFecha = new SimpleDateFormat("dd/MM/yyyy");
        List lPresupuesto = BaseDatos.getListaPresupuestoByIdAgenteReducido(a.getCod_agente(),e.getIid());
        Object [] fila;
        Iterator it;

        if(lPresupuesto != null){
            for (it = lPresupuesto.iterator(); it.hasNext();) {
                fila = (Object [])it.next();
                fila[3] = formatoFecha.format(fila[3]);
                fila[4] = Util.convertirPuntoAComa(String.valueOf((Double)fila[4]));
                modelo.addRow(fila);
            }
        }
        tPresupuestos.getColumnModel().getColumn(0).setPreferredWidth(95);
        tPresupuestos.getColumnModel().getColumn(1).setPreferredWidth(80);
        tPresupuestos.getColumnModel().getColumn(2).setPreferredWidth(125);
        tPresupuestos.getColumnModel().getColumn(3).setPreferredWidth(75);
        tPresupuestos.getColumnModel().getColumn(4).setPreferredWidth(95);
        tPresupuestos.getColumnModel().getColumn(5).setPreferredWidth(175);
        tPresupuestos.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        jScrollPane1.setViewportView(tPresupuestos);

        org.jdesktop.layout.GroupLayout pListaLayout = new org.jdesktop.layout.GroupLayout(pLista);
        pLista.setLayout(pListaLayout);
        pListaLayout.setHorizontalGroup(
            pListaLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jScrollPane1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 656, Short.MAX_VALUE)
        );
        pListaLayout.setVerticalGroup(
            pListaLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jScrollPane1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 93, Short.MAX_VALUE)
        );

        org.jdesktop.layout.GroupLayout layout = new org.jdesktop.layout.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(layout.createSequentialGroup()
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(org.jdesktop.layout.GroupLayout.TRAILING, layout.createSequentialGroup()
                        .addContainerGap()
                        .add(baceptar)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(bmodificar, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 103, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                        .add(bcancelar))
                    .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING, false)
                        .add(org.jdesktop.layout.GroupLayout.LEADING, pLista, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .add(org.jdesktop.layout.GroupLayout.LEADING, pGeneral, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 668, Short.MAX_VALUE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, layout.createSequentialGroup()
                .add(pGeneral, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .add(15, 15, 15)
                .add(pLista, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(bcancelar)
                    .add(bmodificar)
                    .add(baceptar))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

private void bmodificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bmodificarActionPerformed
    if (bmodificar.getText().equals("Modificar")) {
        //Si el botón tiene el texto Modificar
        tcodigo.setEnabled(true);
        tnombreFiscal.setEnabled(true);
        tnombrecomercial.setEnabled(true);
        tCif.setEnabled(true);
        tpais.setEnabled(true);
        tprovincia.setEnabled(true);
        tpoblacion.setEnabled(true);
        tdireccion.setEnabled(true);
        tcp.setEnabled(true);
        ttlf.setEnabled(true);
        ttlf2.setEnabled(true);
        ttlf3.setEnabled(true);
        tmail.setEnabled(true);
        tfax.setEnabled(true);
        ctipo.setEnabled(true);
        cIva.setEnabled(true);
        cFormaPago.setEnabled(true);
        cDiaCobro1.setEnabled(true);
        cDiaCobro2.setEnabled(true);
        cDiaCobro3.setEnabled(true);
        bmodificar.setText("Visualizar");
        bmodificar.setToolTipText("Visualizar campos");
        bmodificar.setToolTipText("Modificar campos");
    } else {
        //si el botón tiene el texto Visualizar
        tcodigo.setEnabled(false);
        tnombreFiscal.setEnabled(false);
        tnombrecomercial.setEnabled(false);
        tCif.setEnabled(false);
        tpais.setEnabled(false);
        tprovincia.setEnabled(false);
        tpoblacion.setEnabled(false);
        tdireccion.setEnabled(false);
        tcp.setEnabled(false);
        ttlf.setEnabled(false);
        ttlf2.setEnabled(false);
        ttlf3.setEnabled(false);
        tmail.setEnabled(false);
        tfax.setEnabled(false);
        ctipo.setEnabled(false);
        cIva.setEnabled(false);
        cFormaPago.setEnabled(false);
        cDiaCobro1.setEnabled(false);
        cDiaCobro2.setEnabled(false);
        cDiaCobro3.setEnabled(false);
        bmodificar.setText("Modificar");
    }
}//GEN-LAST:event_bmodificarActionPerformed

private void baceptarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_baceptarActionPerformed
    String nombreFiscal = tnombreFiscal.getText();
    String nombreComercial = tnombrecomercial.getText();
    String cif = tCif.getText();
    String codigo = tcodigo.getText();

    if (codigo != null && codigo.length() > 0
            && cif != null && cif.length() > 0
            && nombreFiscal != null && nombreFiscal.length() > 0
            && nombreComercial != null && nombreComercial.length() > 0) {

        try {
            FormaPago fp = BaseDatos.obtenerFormaPago((String) cFormaPago.getSelectedItem());
            if (Util.isNifNie(cif)) {
                String sPorcentaje = (String) cIva.getSelectedItem();
                String sPor = sPorcentaje.substring(0, sPorcentaje.length() - 1);

                a.setCod_agente(codigo);
                a.setNombre_comercial(nombreComercial);
                a.setNombre_fiscal(nombreFiscal);
                a.setCif_nif(cif);
                a.setPais(tpais.getText());
                a.setProvincia(tprovincia.getText());
                a.setPoblacion(tpoblacion.getText());
                a.setDireccion(tdireccion.getText());
                a.setCodigo_postal(Integer.parseInt(tcp.getText()));
                a.setTelefono(ttlf.getText());
                a.setTelefono2(ttlf2.getText());
                a.setTelefono3(ttlf3.getText());
                a.setEmail(tmail.getText());
                a.setFax(tfax.getText());
                a.setTipo_agente(BaseDatos.obtenerTipoAgente((String) ctipo.getSelectedItem()));
                a.setIva(BaseDatos.obtenerIvaPorPorcentaje(sPor));
                a.setFormaPago(fp);
                a.setIid_empresa(e);
                String sCobro = (String) cDiaCobro1.getSelectedItem();
                if (!sCobro.equals("--")) {
                    a.setDiaCobro1(new Integer(sCobro));
                } else {
                    a.setDiaCobro1(null);
                }

                sCobro = (String) cDiaCobro2.getSelectedItem();
                if (!sCobro.equals("--")) {
                    a.setDiaCobro2(new Integer(sCobro));
                } else {
                    a.setDiaCobro2(null);
                }

                sCobro = (String) cDiaCobro3.getSelectedItem();
                if (!sCobro.equals("--")) {
                    a.setDiaCobro3(new Integer(sCobro));
                } else {
                    a.setDiaCobro3(null);
                }

                if (crear) {
                    Agentes temp = temp = BaseDatos.obtenerAgentePorEmpresaYCodigo(e.getIid(), codigo);

                    if (temp == null) {

                        if (BaseDatos.insertarElemento(a)) {
                            cerrarAgente();
                        } else {
                            JOptionPane.showMessageDialog(null, "No se ha podido insertar el agente", "Error", JOptionPane.ERROR_MESSAGE);
                        }
                    } else {
                        JOptionPane.showMessageDialog(null, "Ya hay un agente con el codigo " + codigo, "Error", JOptionPane.ERROR_MESSAGE);
                    }
                } else {
                    int hacerCambios = 1;
                    if (hayCambios()) {
                        hacerCambios = JOptionPane.showConfirmDialog(null, "Está seguro de que desea realizar los cambios?", "¿Realizar cambios?", JOptionPane.YES_NO_OPTION);
                        //hacerCambios = -1 ==> se ha pulsado la "x" de cancelar;
                        //hacerCambios =  0 ==> se ha pulsado el "sí"
                        //hacerCambios =  1 ==> se ha pulsado el "no"
                        if (hacerCambios == 0) {
                            Agentes temp = null;

                            if (!codigo.equalsIgnoreCase(codigoAntiguo)) {
                                temp = BaseDatos.obtenerAgentePorEmpresaYCodigo(e.getIid(), codigo);
                            }

                            if (temp == null) {

                                if (BaseDatos.modificarElemento(a)) {
                                    cerrarAgente();
                                } else {
                                    JOptionPane.showMessageDialog(null, "No se ha podido modificar el agente", "Error", JOptionPane.ERROR_MESSAGE);
                                }
                            } else {
                                JOptionPane.showMessageDialog(null, "Ya hay un agente con el codigo " + codigo, "Error", JOptionPane.ERROR_MESSAGE);
                            }
                        }
                    } else {
                        JOptionPane.showMessageDialog(null, "No hay cambios que realizar", "Sin cambios", JOptionPane.ERROR_MESSAGE);
                    }
                }
            } else {
                JOptionPane.showMessageDialog(null, "El CIF introducido es incorrecto", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException ne) {
            JOptionPane.showMessageDialog(null, "El campo \"Código Postal\" debe ser numérico", "Error", JOptionPane.ERROR_MESSAGE);
        }
    } else {
        JOptionPane.showMessageDialog(null, "Debe rellenar el Código, Nombre Comercial, Nombre Fiscal y CIF", "Error", JOptionPane.ERROR_MESSAGE);
    }
}//GEN-LAST:event_baceptarActionPerformed

private void bcancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bcancelarActionPerformed
    cerrarAgente();
}//GEN-LAST:event_bcancelarActionPerformed

private void tcodigoKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tcodigoKeyReleased
    String codigo = tcodigo.getText();
    if (codigo.length() > Constantes.TAM_CODIGO_AGENTE) {
        JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_CODIGO_AGENTE, "Error", JOptionPane.ERROR_MESSAGE);
        tcodigo.setText(codigo.substring(0, Constantes.TAM_CODIGO_AGENTE));
    }
}//GEN-LAST:event_tcodigoKeyReleased

private void tnombrecomercialKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tnombrecomercialKeyReleased
    String nombre = tnombrecomercial.getText();
    if (nombre.length() > Constantes.TAM_NOMBRE_COMERCIAL_AGENTE) {
        JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_NOMBRE_COMERCIAL_AGENTE, "Error", JOptionPane.ERROR_MESSAGE);
        tnombrecomercial.setText(nombre.substring(0, Constantes.TAM_NOMBRE_COMERCIAL_AGENTE));
    }
}//GEN-LAST:event_tnombrecomercialKeyReleased

private void tnombreFiscalKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tnombreFiscalKeyReleased
    String nombre = tnombreFiscal.getText();
    if (nombre.length() > Constantes.TAM_NOMBRE_FISCAL_AGENTE) {
        JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_NOMBRE_FISCAL_AGENTE, "Error", JOptionPane.ERROR_MESSAGE);
        tnombreFiscal.setText(nombre.substring(0, Constantes.TAM_NOMBRE_FISCAL_AGENTE));
    }
}//GEN-LAST:event_tnombreFiscalKeyReleased

private void tCifKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tCifKeyReleased
    String cif = tCif.getText();
    if (cif.length() > Constantes.TAM_CIF_AGENTE) {
        JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_CIF_AGENTE, "Error", JOptionPane.ERROR_MESSAGE);
        tCif.setText(cif.substring(0, Constantes.TAM_CIF_AGENTE));
    }
}//GEN-LAST:event_tCifKeyReleased

private void tpaisKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tpaisKeyReleased
    String pais = tpais.getText();
    if (pais.length() > Constantes.TAM_PAIS_AGENTE) {
        JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_PAIS_AGENTE, "Error", JOptionPane.ERROR_MESSAGE);
        tpais.setText(pais.substring(0, Constantes.TAM_PAIS_AGENTE));
    }
}//GEN-LAST:event_tpaisKeyReleased

private void tprovinciaKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tprovinciaKeyReleased
    String provincia = tprovincia.getText();
    if (provincia.length() > Constantes.TAM_PROVINCIA_AGENTE) {
        JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_PROVINCIA_AGENTE, "Error", JOptionPane.ERROR_MESSAGE);
        tprovincia.setText(provincia.substring(0, Constantes.TAM_PROVINCIA_AGENTE));
    }
}//GEN-LAST:event_tprovinciaKeyReleased

private void tpoblacionKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tpoblacionKeyReleased
    String poblacion = tpoblacion.getText();
    if (poblacion.length() > Constantes.TAM_POBLACION_AGENTE) {
        JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_POBLACION_AGENTE, "Error", JOptionPane.ERROR_MESSAGE);
        tpoblacion.setText(poblacion.substring(0, Constantes.TAM_POBLACION_AGENTE));
    }
}//GEN-LAST:event_tpoblacionKeyReleased

private void tdireccionKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tdireccionKeyReleased
    String direccion = tdireccion.getText();
    if (direccion.length() > Constantes.TAM_DIRECCION_AGENTE) {
        JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_DIRECCION_AGENTE, "Error", JOptionPane.ERROR_MESSAGE);
        tdireccion.setText(direccion.substring(0, Constantes.TAM_DIRECCION_AGENTE));
    }
}//GEN-LAST:event_tdireccionKeyReleased

private void tcpKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tcpKeyReleased
    String cp = tcp.getText();
    if (cp.length() > Constantes.TAM_CP_AGENTE) {
        JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_CP_AGENTE, "Error", JOptionPane.ERROR_MESSAGE);
        tcp.setText(cp.substring(0, Constantes.TAM_CP_AGENTE));
    }
}//GEN-LAST:event_tcpKeyReleased

private void ttlfKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_ttlfKeyReleased
    String tlf = ttlf.getText();
    if (tlf.length() > Constantes.TAM_TLF_AGENTE) {
        JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_TLF_AGENTE, "Error", JOptionPane.ERROR_MESSAGE);
        ttlf.setText(tlf.substring(0, Constantes.TAM_TLF_AGENTE));
    }
}//GEN-LAST:event_ttlfKeyReleased

private void ttlf2KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_ttlf2KeyReleased
    String tlf2 = ttlf2.getText();
    if (tlf2.length() > Constantes.TAM_TLF_AGENTE) {
        JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_TLF2_AGENTE, "Error", JOptionPane.ERROR_MESSAGE);
        ttlf2.setText(tlf2.substring(0, Constantes.TAM_TLF2_AGENTE));
    }
}//GEN-LAST:event_ttlf2KeyReleased

private void ttlf3KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_ttlf3KeyReleased
    String tlf3 = ttlf3.getText();
    if (tlf3.length() > Constantes.TAM_TLF3_AGENTE) {
        JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_TLF3_AGENTE, "Error", JOptionPane.ERROR_MESSAGE);
        ttlf3.setText(tlf3.substring(0, Constantes.TAM_TLF3_AGENTE));
    }
}//GEN-LAST:event_ttlf3KeyReleased

private void tfaxKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tfaxKeyReleased
    String fax = tfax.getText();
    if (fax.length() > Constantes.TAM_FAX_AGENTE) {
        JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_FAX_AGENTE, "Error", JOptionPane.ERROR_MESSAGE);
        tfax.setText(fax.substring(0, Constantes.TAM_FAX_AGENTE));
    }
}//GEN-LAST:event_tfaxKeyReleased

private void tmailKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tmailKeyReleased
    String mail = tmail.getText();
    if (mail.length() > Constantes.TAM_EMAIL_AGENTE) {
        JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_EMAIL_AGENTE, "Error", JOptionPane.ERROR_MESSAGE);
        tmail.setText(mail.substring(0, Constantes.TAM_EMAIL_AGENTE));
    }
}//GEN-LAST:event_tmailKeyReleased
//BOTON ACEPTAR
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton baceptar;
    private javax.swing.JButton bcancelar;
    private javax.swing.JButton bmodificar;
    private javax.swing.JComboBox cDiaCobro1;
    private javax.swing.JComboBox cDiaCobro2;
    private javax.swing.JComboBox cDiaCobro3;
    private javax.swing.JComboBox cFormaPago;
    private javax.swing.JComboBox cIva;
    private javax.swing.JComboBox ctipo;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JLabel lDiaCobro;
    private javax.swing.JLabel lFormaPago;
    private javax.swing.JLabel lIva;
    private javax.swing.JLabel lcif;
    private javax.swing.JLabel lcodigo;
    private javax.swing.JLabel lcp;
    private javax.swing.JLabel ldireccion;
    private javax.swing.JLabel lfax;
    private javax.swing.JLabel lmail;
    private javax.swing.JLabel lnombrecomercial;
    private javax.swing.JLabel lnombrefiscal;
    private javax.swing.JLabel lpais;
    private javax.swing.JLabel lpoblacion;
    private javax.swing.JLabel lprovincia;
    private javax.swing.JLabel ltelefono;
    private javax.swing.JLabel ltelefono2;
    private javax.swing.JLabel ltelefono3;
    private javax.swing.JLabel ltipo;
    private javax.swing.JPanel pGeneral;
    private javax.swing.JPanel pLista;
    private javax.swing.JTextField tCif;
    private javax.swing.JTable tPresupuestos;
    private javax.swing.JTextField tcodigo;
    private javax.swing.JTextField tcp;
    private javax.swing.JTextField tdireccion;
    private javax.swing.JTextField tfax;
    private javax.swing.JTextField tmail;
    private javax.swing.JTextField tnombreFiscal;
    private javax.swing.JTextField tnombrecomercial;
    private javax.swing.JTextField tpais;
    private javax.swing.JTextField tpoblacion;
    private javax.swing.JTextField tprovincia;
    private javax.swing.JTextField ttlf;
    private javax.swing.JTextField ttlf2;
    private javax.swing.JTextField ttlf3;
    // End of variables declaration//GEN-END:variables

    private boolean hayCambios() {
        return !tcodigo.getText().equals(codigoAntiguo)
                || !tnombrecomercial.getText().equals(nombreComercialAntiguo)
                || !tnombreFiscal.getText().equals(nombreFiscalAntiguo)
                || !tCif.getText().equals(cifAntiguo)
                || !tpais.getText().equals(paisAntiguo)
                || !tprovincia.getText().equals(provinciaAntigua)
                || !tpoblacion.getText().equals(poblacionAntigua)
                || !tdireccion.getText().equals(direccionAntigua)
                || !tcp.getText().equals(cpAntiguo)
                || !ttlf.getText().equals(tlfAntiguo)
                || !ttlf2.getText().equals(tlf2Antiguo)
                || !ttlf2.getText().equals(tlf3Antiguo)
                || !tfax.getText().equals(faxAntiguo)
                || !tmail.getText().equals(mailAntiguo)
                || !((String) ctipo.getSelectedItem()).equals(tipoAntiguo)
                || !((String) cFormaPago.getSelectedItem()).equals(formaPagoAntigua)
                || !((String) cIva.getSelectedItem()).equals(ivaAntiguo)
                || !((String) cDiaCobro1.getSelectedItem()).equals(diaCobro1Antiguo)
                || !((String) cDiaCobro2.getSelectedItem()).equals(diaCobro2Antiguo)
                || !((String) cDiaCobro3.getSelectedItem()).equals(diaCobro3Antiguo);
    }
}
