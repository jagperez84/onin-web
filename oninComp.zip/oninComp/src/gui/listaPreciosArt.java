/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;

import acceso.BaseDatos;
import bean.Articulo;
import bean.Empresa;
import bean.Colores;
import bean.Precios;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.JComponent;
import javax.swing.KeyStroke;
import modelo.Modelo;

/**
 *
 * @author Jose
 */
public class listaPreciosArt extends javax.swing.JFrame {

    private int color;
    private Empresa e;
    private Articulo art;

    public listaPreciosArt(Empresa e, Articulo art, int color) {
        super("Registro de precios");
        this.color = color;
        this.art = art;
        this.e = e;

        initComponents();
        crearAcciones();

    }

    private void crearAcciones() {
        KeyStroke escapeKeyStroke = KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false);
        Action escapeAction = new AbstractAction() {
            public void actionPerformed(ActionEvent e) {

                removeAll();
                dispose();
            }
        };
        getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(escapeKeyStroke, "ESCAPE");
        getRootPane().getActionMap().put("ESCAPE", escapeAction);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        Modelo modelo1 = new Modelo();
        tlineas = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        tlineas = new javax.swing.JTable(modelo1);

        modelo1.addColumn("Artículo");
        modelo1.addColumn("Color");
        modelo1.addColumn("PVP");
        modelo1.addColumn("PTC");
        modelo1.addColumn("UPC");
        modelo1.addColumn("Inc.");
        modelo1.addColumn("Fecha");
        modelo1.addColumn("Acción");
        modelo1.addColumn("Usuario");
        modelo1.addColumn("Fórmula");
        //Obtenemos el registro de precios para articulo/car
        List     lp = BaseDatos.obtenerRegistroPreciosTotal(e, art);
        Articulo a = BaseDatos.obtenerArticuloPorIid(art.getIid());

        Object[] fila1;
        Iterator it1;
        Precios p;
        Date fecha;
        SimpleDateFormat sd = new SimpleDateFormat("dd/MM/yyyy - HH:mm:ss");

        if(lp != null){
            for (it1 = lp.iterator(); it1.hasNext();) {
                fila1 = new Object[10];
                p = (Precios)it1.next();
                fecha = new Date(p.getFecha());
                fila1[0] = a.getCod_articulo();

                Colores  c = new Colores();
                if(p.getIid_car()!=0){
                    c = BaseDatos.obtenerColorPorIid(p.getIid_car());
                }else{
                    c.setDescripcion("Sin color");
                }

                fila1[1] = c.getDescripcion();
                fila1[2] = p.getPvp();
                fila1[3] = p.getPtc();
                fila1[4] = p.getUpc();
                fila1[5] = p.getPi();
                fila1[6] = sd.format(fecha);
                if(p.getAccion()!=null){
                    fila1[7] = p.getAccion();
                }
                if(p.getUsuario()!=null){
                    fila1[8] = p.getUsuario();
                }
                fila1[9] = "Pediente";

                modelo1.addRow(fila1);

            }
        }
        tlineas.getColumnModel().getColumn(0).setPreferredWidth(300);
        tlineas.getColumnModel().getColumn(1).setPreferredWidth(300);
        tlineas.getColumnModel().getColumn(2).setPreferredWidth(100);
        tlineas.getColumnModel().getColumn(3).setPreferredWidth(100);
        tlineas.getColumnModel().getColumn(4).setPreferredWidth(100);
        tlineas.getColumnModel().getColumn(5).setPreferredWidth(100);
        tlineas.getColumnModel().getColumn(6).setPreferredWidth(350);
        tlineas.getColumnModel().getColumn(7).setPreferredWidth(300);
        tlineas.getColumnModel().getColumn(8).setPreferredWidth(300);
        tlineas.getColumnModel().getColumn(9).setPreferredWidth(300);
        jScrollPane1.setViewportView(tlineas);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 939, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 193, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(40, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tlineas;
    // End of variables declaration//GEN-END:variables
}
