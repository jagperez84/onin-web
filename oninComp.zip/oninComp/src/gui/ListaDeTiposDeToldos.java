package gui;

import acceso.*;
import modelo.*;
import bean.*;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JOptionPane;
import javax.swing.KeyStroke;

public class ListaDeTiposDeToldos extends javax.swing.JFrame {

    public ListaDeTiposDeToldos() {
        super("Tipos de Toldos - Mantenimiento");
        initComponents();
        crearIconosBotones();
        crearAcciones();
    }
    
    private void crearAcciones(){
        KeyStroke escapeKeyStroke = KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false);
        Action escapeAction = new AbstractAction() {
            public void actionPerformed(ActionEvent e) {
                cerrarVentana();
            }
        }; 
        getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(escapeKeyStroke, "ESCAPE");
        getRootPane().getActionMap().put("ESCAPE", escapeAction);
        
        KeyStroke f1KeyStroke = KeyStroke.getKeyStroke (KeyEvent.VK_F1, 0, false);
        Action f1Action = new AbstractAction() {
            public void actionPerformed(ActionEvent ev) {
                crearTipoToldo();
            }
        }; 
        getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(f1KeyStroke, "F1");
        getRootPane().getActionMap().put("F1", f1Action);
    }
    
    private void crearIconosBotones(){
        URL urlVisualizar = getClass().getResource("/iconos/buscar.gif");
        ImageIcon iconoVisualizar = new ImageIcon(urlVisualizar);
        bModificar.setIcon(iconoVisualizar);

        URL urlBorrar = getClass().getResource("/iconos/eliminar.png");
        ImageIcon iconoBorrar = new ImageIcon(urlBorrar);
        bEliminar.setIcon(iconoBorrar);

        URL urlCerrar = getClass().getResource("/iconos/cancelar.gif");
        ImageIcon iconoCerrar = new ImageIcon(urlCerrar);
        bCerrar.setIcon(iconoCerrar);

        URL urlCrear = getClass().getResource("/iconos/aceptar.png");
        ImageIcon iconoCrear = new ImageIcon(urlCrear);
        bNuevo.setIcon(iconoCrear);
    }
    
    private void cerrarVentana(){
        removeAll();
        dispose();
    }

    private void crearTipoToldo() {
        NuevoTipoToldo ntt = new NuevoTipoToldo("Tipo de Toldo - Creación");
        ntt.setDefaultCloseOperation(NuevoTipoToldo.DISPOSE_ON_CLOSE);
        ntt.setLocationRelativeTo(null);
        ntt.setVisible(true);
        cerrarVentana();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        Modelo modelo = new Modelo();
        tTipos = new javax.swing.JTable(modelo);

        modelo.addColumn("Código");
        modelo.addColumn("Descripción");

        List lTipos = BaseDatos.getListaTipoToldo();
        TipoToldo tt;
        for (Iterator it = lTipos.iterator(); it.hasNext();) {
            Object[] fila = new Object[2];
            tt = (TipoToldo) it.next();
            fila[0] = tt.getCodigo();
            fila[1] = tt.getDescripcion();
            modelo.addRow(fila);
        }
        ;
        bNuevo = new javax.swing.JButton();
        bModificar = new javax.swing.JButton();
        bEliminar = new javax.swing.JButton();
        bCerrar = new javax.swing.JButton();
        lBusqueda = new javax.swing.JLabel();
        tBusqueda = new javax.swing.JTextField();
        bBusquedaRapida = new javax.swing.JCheckBox();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        tTipos.getColumnModel().getColumn(0).setPreferredWidth(150);
        tTipos.getColumnModel().getColumn(1).setPreferredWidth(400);
        tTipos.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        tTipos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tTiposMouseClicked(evt);
            }
        });
        tTipos.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tTiposKeyPressed(evt);
            }
        });
        jScrollPane1.setViewportView(tTipos);

        bNuevo.setText("Crear");
        bNuevo.setAutoscrolls(true);
        bNuevo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bNuevoActionPerformed(evt);
            }
        });

        bModificar.setText("Visualizar");
        bModificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bModificarActionPerformed(evt);
            }
        });

        bEliminar.setText("Borrar");
        bEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bEliminarActionPerformed(evt);
            }
        });

        bCerrar.setText("Cerrar");
        bCerrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bCerrarActionPerformed(evt);
            }
        });

        lBusqueda.setText("Búsqueda rápida");

        tBusqueda.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tBusquedaKeyReleased(evt);
            }
        });

        bBusquedaRapida.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bBusquedaRapidaActionPerformed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout layout = new org.jdesktop.layout.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, layout.createSequentialGroup()
                .addContainerGap(151, Short.MAX_VALUE)
                .add(bNuevo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 93, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                .add(bEliminar, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 90, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                .add(bModificar, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 101, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                .add(bCerrar, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 88, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
            .add(layout.createSequentialGroup()
                .addContainerGap()
                .add(lBusqueda, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 89, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(tBusqueda, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 424, Short.MAX_VALUE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(bBusquedaRapida, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 21, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .add(13, 13, 13))
            .add(jScrollPane1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 563, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(lBusqueda)
                    .add(bBusquedaRapida)
                    .add(tBusqueda, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jScrollPane1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 221, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(bCerrar)
                    .add(bModificar)
                    .add(bEliminar)
                    .add(bNuevo))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

private void bModificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bModificarActionPerformed
   visualizarTipoToldo();
}//GEN-LAST:event_bModificarActionPerformed

private void bEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bEliminarActionPerformed
    borrarTipoToldo();
}//GEN-LAST:event_bEliminarActionPerformed

private void bNuevoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bNuevoActionPerformed
    crearTipoToldo();
}//GEN-LAST:event_bNuevoActionPerformed

private void borrarTipoToldo(){
    try{    
        int indice = tTipos.getSelectedRow();
        if (indice >= 0) {

            int eliminar = 1;
            eliminar = JOptionPane.showConfirmDialog(null, "Está seguro de que desea eliminar el elemento seleccionado?", "¿Eliminar?", JOptionPane.YES_NO_OPTION);
            //hacerCambios = -1 ==> se ha pulsado la "x" de cancelar;
            //hacerCambios =  0 ==> se ha pulsado el "sí"
            //hacerCambios =  1 ==> se ha pulsado el "no"

            if (eliminar == 0) {
                String cod = (String) tTipos.getModel().getValueAt(indice, 0);
                TipoToldo tt = BaseDatos.obtenerTipoToldoPorCodigo(cod);
                if (BaseDatos.eliminarElemento(tt.getClass(),tt.getIid())) {
                    completarPantalla();
                } else {
                    JOptionPane.showMessageDialog(null, "No se ha podido eliminar el elemento", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        } else {
            JOptionPane.showMessageDialog(null, "No hay seleccionado ningún elemento", "Error", JOptionPane.ERROR_MESSAGE);
        }
    } catch(Exception e){
        JOptionPane.showMessageDialog(null, "Este elemento no se puede eliminar", "Error", JOptionPane.ERROR_MESSAGE);
    }
}

private void bCerrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bCerrarActionPerformed
    cerrarVentana();
}//GEN-LAST:event_bCerrarActionPerformed

private void bBusquedaRapidaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bBusquedaRapidaActionPerformed
    List lTipoToldos;
    if (bBusquedaRapida.isSelected()) {
        String codigo = tBusqueda.getText().toLowerCase();
        lTipoToldos = BaseDatos.busquedaRapidaTipoToldo(codigo);
    } else{
        lTipoToldos = BaseDatos.getListaTipoToldo();
    }
    actualizarTiposToldos(lTipoToldos);
}//GEN-LAST:event_bBusquedaRapidaActionPerformed

private void tBusquedaKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tBusquedaKeyReleased
    if (bBusquedaRapida.isSelected()) {
        String codigo = tBusqueda.getText().toLowerCase();
        List lTipoToldos = BaseDatos.busquedaRapidaTipoToldo(codigo);
        actualizarTiposToldos(lTipoToldos);
    }
}//GEN-LAST:event_tBusquedaKeyReleased

private void visualizarTipoToldo(){
    int indice = tTipos.getSelectedRow();
    if (indice >= 0) {
        String codigo = (String) tTipos.getModel().getValueAt(indice, 0);
        TipoToldo tt = BaseDatos.obtenerTipoToldoPorCodigo(codigo);
        NuevoTipoToldo ntt = new NuevoTipoToldo("Tipo de Toldo - Modificación", tt);
        ntt.setDefaultCloseOperation(NuevoColor.DISPOSE_ON_CLOSE);
        ntt.setLocationRelativeTo(null);
        ntt.setVisible(true);
        cerrarVentana();
    } else {
        JOptionPane.showMessageDialog(null, "No hay seleccionado ningún elemento", "Error", JOptionPane.ERROR_MESSAGE);
    }
}

private void tTiposMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tTiposMouseClicked
    if(evt.getClickCount() == 2){
        visualizarTipoToldo();
    }
}//GEN-LAST:event_tTiposMouseClicked

private void tTiposKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tTiposKeyPressed
    if (evt.getKeyChar() == KeyEvent.VK_ENTER) {
        visualizarTipoToldo();
    } else if(evt.getKeyChar() == KeyEvent.VK_DELETE){
        borrarTipoToldo();
    }
}//GEN-LAST:event_tTiposKeyPressed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JCheckBox bBusquedaRapida;
    private javax.swing.JButton bCerrar;
    private javax.swing.JButton bEliminar;
    private javax.swing.JButton bModificar;
    private javax.swing.JButton bNuevo;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lBusqueda;
    private javax.swing.JTextField tBusqueda;
    private javax.swing.JTable tTipos;
    // End of variables declaration//GEN-END:variables

    private void completarPantalla(){
        List ltt;
        //Si la búsqueda rápida está seleccionada la mostramos
        //en otro caso mostramos toda la lista
        if (bBusquedaRapida.isSelected()) {
            String codigo = tBusqueda.getText().toLowerCase();
            ltt = BaseDatos.busquedaRapidaTipoToldo(codigo);
        } else {
            ltt = BaseDatos.getListaTipoToldo();
        }
        actualizarTiposToldos(ltt);
    }

    public void actualizarTiposToldos(List lTiposToldos) {
        Modelo modelo = (Modelo) tTipos.getModel();
        int i, j;

        //obtenemos el nº de filas;
        j = modelo.getRowCount();

        //eliminamos todas las filas
        for (i = 0; i < j; i++) {
            modelo.removeRow(0);
        }

        if(lTiposToldos == null){
            lTiposToldos = new ArrayList();
        }
        TipoToldo tt;
        Object[] fila = new Object[2];

        for (Iterator it = lTiposToldos.iterator(); it.hasNext();) {
            tt = (TipoToldo) it.next();
            fila[0] = tt.getCodigo();
            fila[1] = tt.getDescripcion();
            modelo.addRow(fila);
        }
    }
}
