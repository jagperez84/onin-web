package gui;

import acceso.BaseDatos;
import bean.Agentes;
import bean.Empresa;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JOptionPane;
import javax.swing.KeyStroke;
import modelo.Modelo;

public class ListaDeAgentes extends javax.swing.JFrame {

    private List<Agentes> listaInicial;
    private Empresa e;
    
    public ListaDeAgentes(Empresa e) {
        super("Agentes - Mantenimiento");
        this.e = e;
        listaInicial = BaseDatos.getListaAgentesReducido(e.getIid());
        initComponents();
        crearIconosBotones();
        crearAcciones();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        buttonGroup2 = new javax.swing.ButtonGroup();
        bcerrar = new javax.swing.JButton();
        bvisualizar = new javax.swing.JButton();
        bborrar = new javax.swing.JButton();
        bcrear = new javax.swing.JButton();
        tBusqueda = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        rbNombreComercial = new javax.swing.JRadioButton();
        rbCodigo = new javax.swing.JRadioButton();
        rbNombreFiscal = new javax.swing.JRadioButton();
        rbTelefono = new javax.swing.JRadioButton();
        rbDireccion = new javax.swing.JRadioButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        Modelo modelo1 = new Modelo();
        tagentes1 = new javax.swing.JTable(modelo1);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        bcerrar.setText("Cerrar");
        bcerrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bcerrarActionPerformed(evt);
            }
        });

        bvisualizar.setText("Visualizar");
        bvisualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bvisualizarActionPerformed(evt);
            }
        });

        bborrar.setText("Borrar");
        bborrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bborrarActionPerformed(evt);
            }
        });

        bcrear.setText("Crear");
        bcrear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bcrearActionPerformed(evt);
            }
        });

        tBusqueda.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tBusquedaKeyReleased(evt);
            }
        });

        jLabel1.setText("Búsqueda rápida");

        buttonGroup1.add(rbNombreComercial);
        rbNombreComercial.setText("N. Comercial");
        rbNombreComercial.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbNombreComercialActionPerformed(evt);
            }
        });

        buttonGroup1.add(rbCodigo);
        rbCodigo.setText("Código");
        rbCodigo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbCodigoActionPerformed(evt);
            }
        });

        buttonGroup1.add(rbNombreFiscal);
        rbNombreFiscal.setText("N. Fiscal");
        rbNombreFiscal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbNombreFiscalActionPerformed(evt);
            }
        });

        buttonGroup1.add(rbTelefono);
        rbTelefono.setText("Teléfono");
        rbTelefono.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbTelefonoActionPerformed(evt);
            }
        });

        buttonGroup1.add(rbDireccion);
        rbDireccion.setText("Dirección");
        rbDireccion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbDireccionActionPerformed(evt);
            }
        });

        modelo1.addColumn("N. Comercial");
        modelo1.addColumn("Código");
        modelo1.addColumn("N. Fiscal");
        modelo1.addColumn("Tipo");
        modelo1.addColumn("Dirección");
        modelo1.addColumn("Población");
        modelo1.addColumn("Provincia");
        modelo1.addColumn("Pais");
        modelo1.addColumn("Teléfono");
        modelo1.addColumn("Teléfono 2");
        modelo1.addColumn("Teléfono 3");
        modelo1.addColumn("Fax");
        modelo1.addColumn("E-mail");
        modelo1.addColumn("CIF/DNI");

        List lagentes1 = listaInicial;
        Iterator it1;
        if(lagentes1 != null){
            for (it1 = lagentes1.iterator(); it1.hasNext();) {
                modelo1.addRow((Object[]) it1.next());
            }
        }

        tagentes1.getColumnModel().getColumn(0).setPreferredWidth(230);
        tagentes1.getColumnModel().getColumn(1).setPreferredWidth(80);
        tagentes1.getColumnModel().getColumn(2).setPreferredWidth(100);
        tagentes1.getColumnModel().getColumn(3).setPreferredWidth(100);
        tagentes1.getColumnModel().getColumn(4).setPreferredWidth(150);
        tagentes1.getColumnModel().getColumn(5).setPreferredWidth(70);
        tagentes1.getColumnModel().getColumn(6).setPreferredWidth(70);
        tagentes1.getColumnModel().getColumn(7).setPreferredWidth(80);
        tagentes1.getColumnModel().getColumn(8).setPreferredWidth(80);
        tagentes1.getColumnModel().getColumn(9).setPreferredWidth(80);
        tagentes1.getColumnModel().getColumn(10).setPreferredWidth(80);
        tagentes1.getColumnModel().getColumn(11).setPreferredWidth(80);
        tagentes1.getColumnModel().getColumn(12).setPreferredWidth(150);
        tagentes1.getColumnModel().getColumn(13).setPreferredWidth(80);
        tagentes1.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        tagentes1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tagentes1MouseClicked(evt);
            }
        });
        tagentes1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tagentes1KeyPressed(evt);
            }
        });
        jScrollPane1.setViewportView(tagentes1);

        org.jdesktop.layout.GroupLayout layout = new org.jdesktop.layout.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(layout.createSequentialGroup()
                .addContainerGap()
                .add(jLabel1)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(tBusqueda, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 302, Short.MAX_VALUE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(rbNombreComercial)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(rbCodigo)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(rbNombreFiscal)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(rbTelefono)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(rbDireccion)
                .add(62, 62, 62))
            .add(org.jdesktop.layout.GroupLayout.TRAILING, jScrollPane1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 805, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, layout.createSequentialGroup()
                .addContainerGap(405, Short.MAX_VALUE)
                .add(bcrear, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 93, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(bborrar, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 90, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(bvisualizar, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 101, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(bcerrar, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 88, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(layout.createSequentialGroup()
                .addContainerGap()
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(jLabel1)
                    .add(tBusqueda, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(rbNombreComercial)
                    .add(rbCodigo)
                    .add(rbNombreFiscal)
                    .add(rbTelefono)
                    .add(rbDireccion))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jScrollPane1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 373, Short.MAX_VALUE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(bcerrar)
                    .add(bvisualizar)
                    .add(bborrar)
                    .add(bcrear))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void crearIconosBotones(){
        URL urlVisualizar = getClass().getResource("/iconos/buscar.gif");
        ImageIcon iconoVisualizar = new ImageIcon(urlVisualizar);
        bvisualizar.setIcon(iconoVisualizar);
        
        URL urlBorrar = getClass().getResource("/iconos/eliminar.png");
        ImageIcon iconoBorrar = new ImageIcon(urlBorrar);
        bborrar.setIcon(iconoBorrar);
        
        URL urlCerrar = getClass().getResource("/iconos/cancelar.gif");
        ImageIcon iconoCerrar = new ImageIcon(urlCerrar);
        bcerrar.setIcon(iconoCerrar);
        
        URL urlCrear = getClass().getResource("/iconos/aceptar.png");
        ImageIcon iconoCrear = new ImageIcon(urlCrear);
        bcrear.setIcon(iconoCrear);
    }
    
    private void crearAcciones() {
        KeyStroke escapeKeyStroke = KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false);
        Action escapeAction = new AbstractAction() {
            public void actionPerformed(ActionEvent e) {
                cerrarListaDeAgentes();
            }
        }; 
        getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(escapeKeyStroke, "ESCAPE");
        getRootPane().getActionMap().put("ESCAPE", escapeAction);
        
        KeyStroke f1KeyStroke = KeyStroke.getKeyStroke (KeyEvent.VK_F1, 0, false);
        Action f1Action = new AbstractAction() {
            public void actionPerformed(ActionEvent ev) {
                crearAgente();
            }
        }; 
        getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(f1KeyStroke, "F1");
        getRootPane().getActionMap().put("F1", f1Action);
    }
    
    private void crearAgente(){
        NuevoAgente na = new NuevoAgente("Agente - Creación", e);
        na.setDefaultCloseOperation(NuevoAgente.DISPOSE_ON_CLOSE);
        na.setLocationRelativeTo(null);
        na.setVisible(true);
        cerrarListaDeAgentes();
    }
            
    private void cerrarListaDeAgentes(){
        listaInicial = null;
        removeAll();
        dispose();
    }
    
private void bcrearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bcrearActionPerformed
    crearAgente();
}//GEN-LAST:event_bcrearActionPerformed

private void bborrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bborrarActionPerformed
    try {
        int indiceFila = tagentes1.getSelectedRow();

        if (indiceFila >= 0) {

            int eliminar = 1;
            eliminar = JOptionPane.showConfirmDialog(null, "¿Está seguro de que desea eliminar el elemento seleccionado?", "¿Eliminar?", JOptionPane.YES_NO_OPTION);
            //hacerCambios = -1 ==> se ha pulsado la "x" de cancelar;
            //hacerCambios =  0 ==> se ha pulsado el "sí"
            //hacerCambios =  1 ==> se ha pulsado el "no"

            if (eliminar == 0) {

                String codigo = (String) tagentes1.getModel().getValueAt(indiceFila, 1);

                Agentes a = BaseDatos.obtenerAgentesPorCodigo(codigo,"",e);

                if (BaseDatos.eliminarElemento(a.getClass(), a.getIid())) {
                    obtenerResultado();
                } else {
                    JOptionPane.showMessageDialog(null, "No se ha podido eliminar el elemento seleccionado", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        } else {
            JOptionPane.showMessageDialog(null, "No hay seleccionado ningún elemento", "Error", JOptionPane.ERROR_MESSAGE);
        }
    } catch (Exception ex) {
        JOptionPane.showMessageDialog(null, "Este elemento no se puede eliminar", "Error", JOptionPane.ERROR_MESSAGE);
    }
}//GEN-LAST:event_bborrarActionPerformed

private void bvisualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bvisualizarActionPerformed
    visualizarAgente();
}//GEN-LAST:event_bvisualizarActionPerformed

private void bcerrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bcerrarActionPerformed
    cerrarListaDeAgentes();
}//GEN-LAST:event_bcerrarActionPerformed

private void rbDireccionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbDireccionActionPerformed
    obtenerResultado();
}//GEN-LAST:event_rbDireccionActionPerformed

private void rbTelefonoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbTelefonoActionPerformed
    obtenerResultado();
}//GEN-LAST:event_rbTelefonoActionPerformed

private void rbNombreFiscalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbNombreFiscalActionPerformed
    obtenerResultado();
}//GEN-LAST:event_rbNombreFiscalActionPerformed

private void rbCodigoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbCodigoActionPerformed
    obtenerResultado();
}//GEN-LAST:event_rbCodigoActionPerformed

private void rbNombreComercialActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbNombreComercialActionPerformed
    obtenerResultado();
}//GEN-LAST:event_rbNombreComercialActionPerformed

private void tagentes1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tagentes1KeyPressed
    if (evt.getKeyChar() == KeyEvent.VK_ENTER) {
        visualizarAgente();
    }
}//GEN-LAST:event_tagentes1KeyPressed

private void tagentes1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tagentes1MouseClicked
if (evt.getClickCount() == 2) {
        visualizarAgente();
    }
}//GEN-LAST:event_tagentes1MouseClicked

private void tBusquedaKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tBusquedaKeyReleased
    obtenerResultado();
}//GEN-LAST:event_tBusquedaKeyReleased

    private void obtenerResultado() {

        List lc = null;
  
        if (rbNombreComercial.isSelected()) {
            String nombre = tBusqueda.getText().toLowerCase();
            lc = BaseDatos.busquedaRapidaAgentesPorNombreComercialReducidoTipoAgente(nombre, "", e.getIid());
        }

        if (rbNombreFiscal.isSelected()) {
            String nombre = tBusqueda.getText().toLowerCase();
            lc = BaseDatos.busquedaRapidaClientesPorNombreFiscalReducidoTipoAgente(nombre, "", e.getIid());
        }

        if (rbCodigo.isSelected()) {
            String nombre = tBusqueda.getText().toLowerCase();
            lc = BaseDatos.busquedaRapidaClientesPorCodigoReducidoTipoAgente(nombre, "", e.getIid());
        }

        if (rbTelefono.isSelected()) {
            String nombre = tBusqueda.getText().toLowerCase();
            lc = BaseDatos.busquedaRapidaClientesPorTelefonoReducidoTipoAgente(nombre, "", e.getIid());
        }

        if (rbDireccion.isSelected()) {
            String nombre = tBusqueda.getText().toLowerCase();
            lc = BaseDatos.busquedaRapidaClientesPorDireccionReducidaTipoAgente(nombre, "", e.getIid());
        }
        
        actualizarAgentes(lc);
    }
    
    private void actualizarAgentes(List lagentes) {
        Modelo modelo = (Modelo) tagentes1.getModel();
        int i, j;
        Iterator it;

        //obtenemos el nº de filas;
        j = modelo.getRowCount();

        //eliminamos todas las filas
        for (i = 0; i < j; i++) {
            modelo.removeRow(0);
        }

        if (lagentes == null) {
            lagentes = new ArrayList();
        }

        if (lagentes != null) {
            for (it = lagentes.iterator(); it.hasNext();) {
                modelo.addRow((Object[]) it.next());
            }
        }
    }

    private void visualizarAgente() {

        int indiceFila = this.tagentes1.getSelectedRow();
        if (indiceFila >= 0) {

            String codigo = (String) tagentes1.getModel().getValueAt(indiceFila, 1);

            Agentes a = BaseDatos.obtenerAgentePorEmpresaYCodigo(e.getIid(), codigo);
            
            NuevoAgente na = new NuevoAgente("Agente - Modificación", a, e);
            na.setDefaultCloseOperation(NuevoAgente.DISPOSE_ON_CLOSE);
            na.setLocationRelativeTo(null);
            na.setVisible(true);
            cerrarListaDeAgentes();
        } else {
            JOptionPane.showMessageDialog(null, "No hay seleccionado ningún elemento", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bborrar;
    private javax.swing.JButton bcerrar;
    private javax.swing.JButton bcrear;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.ButtonGroup buttonGroup2;
    private javax.swing.JButton bvisualizar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JRadioButton rbCodigo;
    private javax.swing.JRadioButton rbDireccion;
    private javax.swing.JRadioButton rbNombreComercial;
    private javax.swing.JRadioButton rbNombreFiscal;
    private javax.swing.JRadioButton rbTelefono;
    private javax.swing.JTextField tBusqueda;
    private javax.swing.JTable tagentes1;
    // End of variables declaration//GEN-END:variables
}
