package gui;

import acceso.BaseDatos;
import auxiliar.CorteLona;
import bean.DespiecePresupuesto;
import bean.LineaCorteLona;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.awt.event.WindowEvent;
import java.net.URL;
import java.util.Iterator;
import java.util.List;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JOptionPane;
import javax.swing.KeyStroke;


public class NuevoCorteLona extends javax.swing.JFrame {

    private List<CorteLona> listaCorteLona;
    private NuevoPresupuesto nuevoPresupuesto;
    private int lonasMostradas;
    private List<Integer> listaIdentificadoresExistenciasRestosUsados;

    public NuevoCorteLona(NuevoPresupuesto nuevoPresupuesto, List<CorteLona> listaCorteLona) {
        this.listaCorteLona = listaCorteLona;
        this.nuevoPresupuesto = nuevoPresupuesto;
        
        initComponents();

        bCancelar.setToolTipText("Cancelar");
        bFinalizar.setToolTipText("Finalizar");
        rellenarCortesLona();
        crearIconosBotones();
        crearAcciones();
        
    }

    private void rellenarCortesLona(){
        Iterator iter = listaCorteLona.iterator();
        NuevaLineaCorteDeLona nlcl;
        lonasMostradas = 0;
        LineaCorteLona lcl;
        CorteLona cl;
        List listaTemporalCortesLona = BaseDatos.getListaLineaCorteLona(nuevoPresupuesto.getPresupuesto().getIid());
        
        listaIdentificadoresExistenciasRestosUsados = BaseDatos.getListaRestosUsados(nuevoPresupuesto.getPresupuesto().getIid());
        
        while(iter.hasNext()){
            cl = (CorteLona) iter.next();
            lcl = getLineaCorteLona(cl, listaTemporalCortesLona);
            if(lcl == null){
                nlcl = new NuevaLineaCorteDeLona(this, nuevoPresupuesto, cl);
            } else {
                nlcl = new NuevaLineaCorteDeLona(this, nuevoPresupuesto, cl, lcl);
            }
            panelCorteLona.add(nlcl);
            panelCorteLona.setVisible(true);
            panelCorteLona.repaint();
            lonasMostradas++;
        }
        
        for(int contadorLonas = lonasMostradas + 1; contadorLonas < 10; contadorLonas ++){
            NuevaLineaCorteDeLonaVacia nlclv = new NuevaLineaCorteDeLonaVacia();
            panelCorteLona.add(nlclv);
        }
        
        panelCorteLona.setSize(500, 500);
        panelCorteLona.setLayout(new GridLayout(0, 1));
        
        panelCorteLona.setVisible(true);
        panelCorteLona.repaint();
    }
    
    
    private LineaCorteLona getLineaCorteLona(CorteLona cl, List listaTemporalCortesLona) {
        LineaCorteLona lcl = null;
        boolean seguir = true;
        Iterator iter = listaTemporalCortesLona.iterator();
        while(iter.hasNext() && seguir){
            lcl = (LineaCorteLona)iter.next();
            if(!lcl.getEsDespiece() && cl.getIndiceElemento() == null && lcl.getLineaPresupuesto().getIid().equals(cl.getIddNuevaLineaPresupuesto())){
                seguir = false;
            } else if(lcl.getEsDespiece() && cl.getIndiceElemento() != null && lcl.getLineaPresupuesto().getIid().equals(cl.getIddNuevaLineaPresupuesto())){
                DespiecePresupuesto dp = lcl.getDespiece();
                dp = BaseDatos.obtenerDespiecePresupuestoByIid(dp.getIid());
                if(dp != null && dp.getOrden().equals(cl.getIndiceElemento())){
                     seguir = false;
                }
            }
        }
        
        if(seguir){
            lcl = null;
        }
        
        return lcl;
    }

    
    public void actualizarLineas() {
        panelCorteLona.setVisible(true);
        panelCorteLona.repaint();
        pack();
    }
    
    private void crearAcciones() {
        KeyStroke escapeKeyStroke = KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false);
        Action escapeAction = new AbstractAction() {
            public void actionPerformed(ActionEvent e) {
                nuevoPresupuesto.setConfeccionado(false);
                cerrarVentana();
            }
        }; 
        getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(escapeKeyStroke, "ESCAPE");
        getRootPane().getActionMap().put("ESCAPE", escapeAction);
    }
    
    private void cerrarVentana(){
        removeAll();
        dispose();
    }
    
    protected void salir(){
        nuevoPresupuesto.setConfeccionado(false);
        removeAll();
        dispose();
    }

    private void crearIconosBotones() {
        URL urlCancelar = getClass().getResource("/iconos/cancelar.gif");
        ImageIcon iconoCancelar = new ImageIcon(urlCancelar);
        bCancelar.setIcon(iconoCancelar);
        
        URL urlFinalizar = getClass().getResource("/iconos/aceptar.png");
        ImageIcon iconoFinalizar = new ImageIcon(urlFinalizar);
        bFinalizar.setIcon(iconoFinalizar);
        
    }

    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        bCancelar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        panelCorteLona = new javax.swing.JPanel();
        lTitulo = new javax.swing.JLabel();
        bFinalizar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        bCancelar.setText("Cancelar");
        bCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bCancelarActionPerformed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout panelCorteLonaLayout = new org.jdesktop.layout.GroupLayout(panelCorteLona);
        panelCorteLona.setLayout(panelCorteLonaLayout);
        panelCorteLonaLayout.setHorizontalGroup(
            panelCorteLonaLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(0, 779, Short.MAX_VALUE)
        );
        panelCorteLonaLayout.setVerticalGroup(
            panelCorteLonaLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(0, 327, Short.MAX_VALUE)
        );

        jScrollPane1.setViewportView(panelCorteLona);

        lTitulo.setFont(new java.awt.Font("Tahoma", 1, 11));
        lTitulo.setText("     C.Linea      Cantidad                        Artículo                           Salida        Línea           T. Corte      Autom.   Doblad.  Solape       Ancho");

        bFinalizar.setText("Finalizar");
        bFinalizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bFinalizarActionPerformed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout layout = new org.jdesktop.layout.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(layout.createSequentialGroup()
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(org.jdesktop.layout.GroupLayout.TRAILING, layout.createSequentialGroup()
                        .addContainerGap()
                        .add(bFinalizar, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 103, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED, 583, Short.MAX_VALUE)
                        .add(bCancelar))
                    .add(lTitulo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 711, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
            .add(jScrollPane1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 781, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, layout.createSequentialGroup()
                .add(lTitulo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 21, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jScrollPane1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 329, Short.MAX_VALUE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(bCancelar)
                    .add(bFinalizar))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

private void bCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bCancelarActionPerformed
    nuevoPresupuesto.setConfeccionado(false);
    cerrarVentana();
}//GEN-LAST:event_bCancelarActionPerformed

protected List getListaIdentificadoresExistenciasRestosUsados(){
    return this.listaIdentificadoresExistenciasRestosUsados;
}

private void bFinalizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bFinalizarActionPerformed
    boolean finalizarOperacion = true;
    NuevaLineaCorteDeLona nlcl;
    for(int i = 0; (i < lonasMostradas) && finalizarOperacion; i++){
        nlcl = (NuevaLineaCorteDeLona)panelCorteLona.getComponent(i);
        finalizarOperacion = nlcl.finalizable();
    }
    
    if(finalizarOperacion){
        if(BaseDatos.realizarCorteLona(nuevoPresupuesto.getPresupuesto(), panelCorteLona, lonasMostradas)){
            JOptionPane.showMessageDialog(null, "Proceso de corte de lonas realizado correctamente", "Información", JOptionPane.INFORMATION_MESSAGE);
            cerrarVentana();
            nuevoPresupuesto.setConfeccionado(true);
        } else {
            JOptionPane.showMessageDialog(null, "No se ha podido realizar el corte de lona. Es posible que no haya lonas suficiente", "Error", JOptionPane.ERROR_MESSAGE);
            nuevoPresupuesto.setConfeccionado(false);
        }
    } else {
        JOptionPane.showMessageDialog(null, "Hay anchos o restos sin seleccionar", "Error", JOptionPane.ERROR_MESSAGE);
    }
}//GEN-LAST:event_bFinalizarActionPerformed
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bCancelar;
    private javax.swing.JButton bFinalizar;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lTitulo;
    private javax.swing.JPanel panelCorteLona;
    // End of variables declaration//GEN-END:variables
}
