package gui;

import acceso.*;
import java.awt.HeadlessException;
import modelo.*;
import bean.*;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JOptionPane;
import javax.swing.KeyStroke;

public class ListaUsuarios extends javax.swing.JFrame {

    private Usuario u;
    
    public ListaUsuarios(Usuario u) {
        super("Usuarios - Mantenimiento");
        initComponents();
        crearIconosBotones();
        crearAcciones();
        this.u = u;
    }

    private void crearAcciones() {
        KeyStroke escapeKeyStroke = KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false);
        Action escapeAction = new AbstractAction() {
            public void actionPerformed(ActionEvent e) {
                cerrarVentana();
            }
        }; 
        getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(escapeKeyStroke, "ESCAPE");
        getRootPane().getActionMap().put("ESCAPE", escapeAction);
        
        KeyStroke f1KeyStroke = KeyStroke.getKeyStroke (KeyEvent.VK_F1, 0, false);
        Action f1Action = new AbstractAction() {
            public void actionPerformed(ActionEvent ev) {
                crearUsuario();
            }
        }; 
        getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(f1KeyStroke, "F1");
        getRootPane().getActionMap().put("F1", f1Action);
    }

    private void crearIconosBotones() {
        URL urlVisualizar = getClass().getResource("/iconos/buscar.gif");
        ImageIcon iconoVisualizar = new ImageIcon(urlVisualizar);
        bmodificar.setIcon(iconoVisualizar);

        URL urlBorrar = getClass().getResource("/iconos/eliminar.png");
        ImageIcon iconoBorrar = new ImageIcon(urlBorrar);
        beliminar.setIcon(iconoBorrar);

        URL urlCerrar = getClass().getResource("/iconos/cancelar.gif");
        ImageIcon iconoCerrar = new ImageIcon(urlCerrar);
        bcerrar.setIcon(iconoCerrar);

        URL urlCrear = getClass().getResource("/iconos/aceptar.png");
        ImageIcon iconoCrear = new ImageIcon(urlCrear);
        bnuevo.setIcon(iconoCrear);
    }
    
    private void cerrarVentana(){
        removeAll();
        dispose();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        Modelo modelo = new Modelo();
        tusuarios = new javax.swing.JTable(modelo);

        // Creamos las columnas.
        modelo.addColumn("Nombre");
        modelo.addColumn("Departamento");

        List lusuarios = BaseDatos.getListaUsuarios();
        bean.Usuario u;
        for (Iterator it = lusuarios.iterator(); it.hasNext();) {
            Object[] fila = new Object[2];
            u = (bean.Usuario) it.next();
            fila[0] = u.getNombre();
            fila[1] = u.getDepartamento();
            modelo.addRow(fila);
        }
        ;
        bnuevo = new javax.swing.JButton();
        bmodificar = new javax.swing.JButton();
        beliminar = new javax.swing.JButton();
        bcerrar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        tusuarios.getColumnModel().getColumn(0).setPreferredWidth(100);
        tusuarios.getColumnModel().getColumn(1).setPreferredWidth(300);
        tusuarios.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        tusuarios.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tusuariosMouseClicked(evt);
            }
        });
        tusuarios.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tusuariosKeyPressed(evt);
            }
        });
        jScrollPane1.setViewportView(tusuarios);

        bnuevo.setText("Crear");
        bnuevo.setAutoscrolls(true);
        bnuevo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bnuevoActionPerformed(evt);
            }
        });

        bmodificar.setText("Visualizar");
        bmodificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bmodificarActionPerformed(evt);
            }
        });

        beliminar.setText("Borrar");
        beliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                beliminarActionPerformed(evt);
            }
        });

        bcerrar.setText("Cerrar");
        bcerrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bcerrarActionPerformed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout layout = new org.jdesktop.layout.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(layout.createSequentialGroup()
                .addContainerGap(87, Short.MAX_VALUE)
                .add(bnuevo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 93, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .add(18, 18, 18)
                .add(beliminar, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 90, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .add(30, 30, 30)
                .add(bmodificar, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 101, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(bcerrar, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 88, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
            .add(org.jdesktop.layout.GroupLayout.TRAILING, jScrollPane1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 523, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, layout.createSequentialGroup()
                .add(jScrollPane1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 312, Short.MAX_VALUE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(bcerrar)
                    .add(beliminar)
                    .add(bnuevo)
                    .add(bmodificar))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

private void bmodificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bmodificarActionPerformed
        visualizarUsuario();
}//GEN-LAST:event_bmodificarActionPerformed

private void beliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_beliminarActionPerformed
    borrarUsuario();
}//GEN-LAST:event_beliminarActionPerformed

private void bnuevoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bnuevoActionPerformed
    crearUsuario();
}//GEN-LAST:event_bnuevoActionPerformed

private void crearUsuario(){
    NuevoUsuario nu = new NuevoUsuario("Usuario - Creación");
    nu.setDefaultCloseOperation(NuevoUsuario.DISPOSE_ON_CLOSE);
    nu.setLocationRelativeTo(null);
    nu.setVisible(true);
    cerrarVentana();
}
        
private void bcerrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bcerrarActionPerformed
    cerrarVentana();
}//GEN-LAST:event_bcerrarActionPerformed

private void tusuariosKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tusuariosKeyPressed
    if (evt.getKeyChar() == KeyEvent.VK_ENTER) {
        visualizarUsuario();
    } else if(evt.getKeyChar() == KeyEvent.VK_DELETE){
        borrarUsuario();
    }
}//GEN-LAST:event_tusuariosKeyPressed

private void tusuariosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tusuariosMouseClicked
    if (evt.getClickCount() == 2) {
        visualizarUsuario();
    }
}//GEN-LAST:event_tusuariosMouseClicked

private void borrarUsuario(){
    int indice = tusuarios.getSelectedRow();
    if (indice >= 0) {
        
        String nombre = (String) tusuarios.getModel().getValueAt(indice, 0);
        
        if(u != null && u.getNombre().equals(nombre)){
            JOptionPane.showMessageDialog(null, "No se puede eliminar el usuario activo", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            int eliminar = 1;
            eliminar = JOptionPane.showConfirmDialog(null, "Está seguro de que desea eliminar el usuario seleccionado?", "¿Eliminar?", JOptionPane.YES_NO_OPTION);
            //hacerCambios = -1 ==> se ha pulsado la "x" de cancelar;
            //hacerCambios =  0 ==> se ha pulsado el "sí"
            //hacerCambios =  1 ==> se ha pulsado el "no"

            if (eliminar == 0) {
                Usuario usuario = BaseDatos.obtenerUsuarioNombre(nombre);

                if (BaseDatos.eliminarUsuario(usuario)){
                    completarPantalla();
                } else {
                    JOptionPane.showMessageDialog(null, "No se ha podido eliminar el elemento", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        }
    } else {
        JOptionPane.showMessageDialog(null, "No hay seleccionado ningún elemento", "Error", JOptionPane.ERROR_MESSAGE);
    }
}
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bcerrar;
    private javax.swing.JButton beliminar;
    private javax.swing.JButton bmodificar;
    private javax.swing.JButton bnuevo;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tusuarios;
    // End of variables declaration//GEN-END:variables

    private void completarPantalla(){
        List lu;
        
        //Si la búsqueda rápida está seleccionada la mostramos
        //en otro caso mostramos toda la lista
        lu = BaseDatos.getListaUsuarios();
        
        actualizarUsuarios(lu);
    }

    public void actualizarUsuarios(List lusuarios) {

        Modelo modelo = (Modelo) tusuarios.getModel();
        int i, j;

        //obtenemos el nº de filas;
        j = modelo.getRowCount();

        //eliminamos todas las filas
        for (i = 0; i < j; i++) {
            modelo.removeRow(0);
        }

        if(lusuarios == null){
            lusuarios = new ArrayList();
        }
        Usuario us;
        Object[] fila = new Object[2];

        for (Iterator it = lusuarios.iterator(); it.hasNext();) {
            us = (Usuario) it.next();
            fila[0] = us.getNombre();
            fila[1] = us.getDepartamento();
            modelo.addRow(fila);
        }
    }

    private void visualizarUsuario() throws HeadlessException {
        int indice = tusuarios.getSelectedRow();
        if (indice >= 0) {

            String nombre = (String) tusuarios.getModel().getValueAt(indice, 0);

            Usuario usuario = BaseDatos.obtenerUsuarioNombre(nombre);
            NuevoUsuario nu = new NuevoUsuario("Usuario - Modificación", usuario, u);
            nu.setDefaultCloseOperation(NuevoUsuario.DISPOSE_ON_CLOSE);
            nu.setLocationRelativeTo(null);
            nu.setVisible(true);
            cerrarVentana();
        } else {
            JOptionPane.showMessageDialog(null, "No hay seleccionado ningún elemento", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
