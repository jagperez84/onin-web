package gui;

import acceso.BaseDatos;
import bean.AgenteArticuloCodigo;
import bean.Agentes;
import bean.Articulo;
import bean.Caracteristica;
import bean.ClaseDocumento;
import bean.Colores;
import bean.Empresa;
import bean.FamiliaVenta;
import bean.LineaCorteLona;
import bean.LineaPresupuesto;
import bean.TipoControl;
import bean.TipoMedida;
import bean.Usuario;
import java.awt.Color;
import java.awt.event.KeyEvent;
import java.util.List;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.swing.JOptionPane;
import util.Constantes;
import util.Util;

public class NuevaLineaCompra extends javax.swing.JPanel {

    private int codigo;
    private Articulo a;
    private Caracteristica car;
    private Empresa e;
    private int numMedidas;
    private Double precio;
    private Double cantidad;
    private Double cantidadRec;
    private Double descuento;
    private Double importe;
    private NuevoCompras p;
    private Integer iid;
    private Boolean isLineaArticulo;
    private boolean isDac;
    private boolean lineaOculta = false;
    private Double cantidadAntesFoco;
    private Double cantidadDespuesFoco;
    private Double medida1AntesFoco;
    private Double medida1DespuesFoco;
    private Double medida2AntesFoco;
    private Double medida2DespuesFoco;
    private AgenteArticuloCodigo agAc;
    private Usuario u;

    public NuevaLineaCompra(NuevoCompras p, int codigo, Empresa e, Usuario u) {
        this(p, codigo, e, true, u);
        lineaOculta = false;
    }

    public NuevaLineaCompra(NuevoCompras p, int codigo, Empresa e, boolean isLineaArticulo, Usuario u) {
        initComponents();
        ClaseDocumento cd = BaseDatos.getClaseDocumentosByIid(p.getClaseDocumento().getIid());
        
        if (!cd.getDescripcion().equals(Constantes.PEDIDOC)) {
            tRecibido.setVisible(false);
            tPendiente.setVisible(false);
        } 
        
        this.codigo = codigo;
        this.e = e;
        this.p = p;
        this.u = u;

        setNumMedidas(0);
        tmedidaResultado.setEnabled(false);

        precio = 0.0;
        a = null;
        car = null;
        iid = null;

        mostrarCamposLineaArticulo(isLineaArticulo);
        this.isLineaArticulo = isLineaArticulo;
        lineaOculta = false;
    }

    public NuevaLineaCompra(NuevoCompras p, int codigo, Empresa e, LineaPresupuesto lp, boolean isLineaArticulo, Usuario u) {
         initComponents();
         ClaseDocumento cd = BaseDatos.getClaseDocumentosByIid(p.getClaseDocumento().getIid());
        
        if (!cd.getDescripcion().equals(Constantes.PEDIDOC)) {
            tRecibido.setVisible(false);
            tPendiente.setVisible(false);
        } 
        
        this.codigo = codigo;
        this.e = e;
        this.p = p;
        this.u = u;
        this.iid = lp.getIid();
        setNumMedidas(0);
        tmedidaResultado.setEnabled(false);
        precio = 0.0;
        a = null;
        car = null;

        if (lp.getArticulo_iid() != null) {
            Articulo ar = BaseDatos.obtenerArticuloPorIid(lp.getArticulo_iid().getIid());

            if (lp.getCaracteristica() != null) {
                car = BaseDatos.obtenerCaracteristicaPorIid(lp.getCaracteristica().getIid());
            }
            Double m1 = lp.getMedida1();
            Double m2 = lp.getMedida2();
            Double m3 = lp.getMedida3();
            Double m4 = lp.getMedida4();
            Double m5 = lp.getMedida5();
            Double mr = lp.getMedidares();

            precio = lp.getPrecioArticulo();
            if (precio != null) {
                tPrecio.setText(Util.convertirPuntoAComa(String.valueOf(precio)));
            }
            numMedidas = lp.getNummedidas();

            cantidad = lp.getCantidad();
            if (cantidad != null) {
                tCantidad.setText(Util.convertirPuntoAComa(String.valueOf(cantidad)));
            }

            descuento = lp.getDescuento();
            if (descuento != null) {
                tDescuento.setText(Util.convertirPuntoAComa(String.valueOf(descuento)));
            }
            
            cantidadRec = lp.getCantidadRec();
            if (cantidadRec != null) {
                tRecibido.setText(Util.convertirPuntoAComa(String.valueOf(cantidadRec)));
                tPendiente.setText(Util.convertirPuntoAComa(String.valueOf(cantidad - cantidadRec)));
            }

            a = ar;

            if (m1 != null) {
                this.tMedida1.setText(Util.convertirPuntoAComa(String.valueOf(m1)));
            }

            if (m2 != null) {
                this.tMedida2.setText(Util.convertirPuntoAComa(String.valueOf(m2)));
            }

            if (m3 != null) {
                this.tMedida3.setText(Util.convertirPuntoAComa(String.valueOf(m3)));
            }

            if (m4 != null) {
                this.tMedida4.setText(Util.convertirPuntoAComa(String.valueOf(m4)));
            }

            if (m5 != null) {
                this.tMedida5.setText(Util.convertirPuntoAComa(String.valueOf(m5)));
            }

            if (mr != null) {
                this.tmedidaResultado.setText(Util.convertirPuntoAComa(String.valueOf(mr)));
            }

            setNumMedidas(numMedidas);

            insertarArticulo(a, car, BaseDatos.obtenerAgentesPorCodigo(p.getCodigoCliente(), "prov", e));

            precio = lp.getPrecioArticulo();
            if (precio != null) {
                tPrecio.setText(Util.convertirPuntoAComa(String.valueOf(precio)));
            }

            descuento = lp.getDescuento();
            if (descuento != null) {
                tDescuento.setText(Util.convertirPuntoAComa(String.valueOf(descuento)));
            }

            importe = lp.getImporte();
            if (importe != null) {
                timporte.setText(Util.convertirPuntoAComa(String.valueOf(importe)));
            }

            iid = lp.getIid();
        }

        if (lp.getDescripcion() != null && !lp.getDescripcion().equals("")) {
            tdescripcion.setText(lp.getDescripcion());
        }

        mostrarCamposLineaArticulo(isLineaArticulo);
        this.isLineaArticulo = isLineaArticulo;

        lineaOculta = false;
    }

    public NuevaLineaCompra(NuevoCompras p, int codigo, Empresa e, LineaPresupuesto lp, Usuario u) {
        this(p, codigo, e, lp, true, u);
        lineaOculta = false;
    }

    public Integer getIid() {
        return iid;
    }

    public void setIid(Integer iid) {
        this.iid = iid;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public double getPrecio() {
        if (this.tPrecio.getText() == null || this.tPrecio.getText().equals("")) {
            precio = 0D;
        } else if (this.tPrecio.getText() != null && !this.tPrecio.getText().equals("")) {
            precio = Double.parseDouble(Util.convertirComaAPunto(tPrecio.getText()));
        } else {
            precio = 0D;
        }

        return precio;
    }

    public double getCantidad() {
        if (this.tCantidad.getText() == null || this.tCantidad.getText().equals("")) {
            cantidad = 0D;
        } else if (this.tCantidad.getText() != null && !this.tCantidad.getText().equals("")) {
            if (this.tCantidad.getText().equals("-")) {
                cantidad = 0D;
            } else {
                cantidad = Double.parseDouble(Util.convertirComaAPunto(tCantidad.getText()));
            }
        } else {
            cantidad = 0D;
        }

        return cantidad;
    }

    public double getDescuento() {
        if (this.tDescuento.getText() == null || this.tDescuento.getText().equals("")) {
            descuento = 0D;
        } else if (this.tDescuento.getText() != null && !this.tDescuento.getText().equals("")) {
            descuento = Double.parseDouble(Util.convertirComaAPunto(tDescuento.getText()));
        } else {
            descuento = 0D;
        }

        return descuento;
    }

    public double getImporte() {
        if (this.importe != null) {
            return importe;
        } else {
            if (this.timporte.getText() == null || this.timporte.getText().equals("")) {
                importe = 0D;
            } else if (this.timporte.getText() != null && !this.timporte.getText().equals("")) {
                importe = Double.parseDouble(Util.convertirComaAPunto(timporte.getText()));
            } else {
                importe = 0D;
            }

            return importe;
        }
    }

    public double getPrecioArticulo() {
        return Double.valueOf(Util.convertirComaAPunto(tPrecio.getText()));
    }

    public double getMedida1() {
        double m = 0;
        String smedida = Util.convertirComaAPunto(tMedida1.getText());
        if (smedida != null && !smedida.equals("")) {
            m = Double.valueOf(smedida);
        }
        return m;
    }

    public double getMedida2() {
        double m = 0;
        String smedida = Util.convertirComaAPunto(tMedida2.getText());
        if (smedida != null && !smedida.equals("")) {
            m = Double.valueOf(smedida);
        }
        return m;
    }

    public double getMedida3() {
        double m = 0;
        String smedida = Util.convertirComaAPunto(tMedida3.getText());
        if (smedida != null && !smedida.equals("")) {
            m = Double.valueOf(smedida);
        }
        return m;
    }

    public double getMedida4() {
        double m = 0;
        String smedida = Util.convertirComaAPunto(tMedida4.getText());
        if (smedida != null && !smedida.equals("")) {
            m = Double.valueOf(smedida);
        }
        return m;
    }

    public double getMedida5() {
        double m = 0;
        String smedida = Util.convertirComaAPunto(tMedida5.getText());
        if (smedida != null && !smedida.equals("")) {
            m = Double.valueOf(smedida);
        }
        return m;
    }

    public double getMedidares() {
        double m = 0;
        String smedida = Util.convertirComaAPunto(tmedidaResultado.getText());
        if (smedida != null && !smedida.equals("")) {
            m = Double.valueOf(smedida);
        }
        return m;
    }

    public void setNumMedidas(int numMedidas) {
        if (numMedidas == 0) {
            tMedida1.setEnabled(false);
            tMedida2.setEnabled(false);
            tMedida3.setEnabled(false);
            tMedida4.setEnabled(false);
            tMedida5.setEnabled(false);

            tMedida1.setText("");
            tMedida2.setText("");
            tMedida3.setText("");
            tMedida4.setText("");
            tMedida5.setText("");
        } else if (numMedidas == 1) {
            tMedida1.setEnabled(true);
            tMedida2.setEnabled(false);
            tMedida3.setEnabled(false);
            tMedida4.setEnabled(false);
            tMedida5.setEnabled(false);

            if (tMedida1.getText() != null && tMedida1.getText().length() == 0) {
                tMedida1.setText("0");
            }

            tMedida2.setText("");
            tMedida3.setText("");
            tMedida4.setText("");
            tMedida5.setText("");
        } else if (numMedidas == 2) {
            tMedida1.setEnabled(true);
            tMedida2.setEnabled(true);
            tMedida3.setEnabled(false);
            tMedida4.setEnabled(false);
            tMedida5.setEnabled(false);

            if (tMedida1.getText() != null && tMedida1.getText().length() == 0) {
                tMedida1.setText("0");
            }

            if (tMedida2.getText() != null && tMedida2.getText().length() == 0) {
                tMedida2.setText("0");
            }
            tMedida3.setText("");
            tMedida4.setText("");
            tMedida5.setText("");
        } else if (numMedidas == 3) {
            tMedida1.setEnabled(true);
            tMedida2.setEnabled(true);
            tMedida3.setEnabled(true);
            tMedida4.setEnabled(false);
            tMedida5.setEnabled(false);

            if (tMedida1.getText() != null && tMedida1.getText().length() == 0) {
                tMedida1.setText("0");
            }

            if (tMedida2.getText() != null && tMedida2.getText().length() == 0) {
                tMedida2.setText("0");
            }

            if (tMedida3.getText() != null && tMedida3.getText().length() == 0) {
                tMedida3.setText("0");
            }

            tMedida4.setText("");
            tMedida5.setText("");
        } else if (numMedidas == 4) {
            tMedida1.setEnabled(true);
            tMedida2.setEnabled(true);
            tMedida3.setEnabled(true);
            tMedida4.setEnabled(true);
            tMedida5.setEnabled(false);

            if (tMedida1.getText() != null && tMedida1.getText().length() == 0) {
                tMedida1.setText("0");
            }

            if (tMedida2.getText() != null && tMedida2.getText().length() == 0) {
                tMedida2.setText("0");
            }

            if (tMedida3.getText() != null && tMedida3.getText().length() == 0) {
                tMedida3.setText("0");
            }

            if (tMedida4.getText() != null && tMedida4.getText().length() == 0) {
                tMedida4.setText("0");
            }

            tMedida5.setText("");
        } else {
            tMedida1.setEnabled(true);
            tMedida2.setEnabled(true);
            tMedida3.setEnabled(true);
            tMedida4.setEnabled(true);
            tMedida5.setEnabled(true);

            if (tMedida1.getText() != null && tMedida1.getText().length() == 0) {
                tMedida1.setText("0");
            }

            if (tMedida2.getText() != null && tMedida2.getText().length() == 0) {
                tMedida2.setText("0");
            }

            if (tMedida3.getText() != null && tMedida3.getText().length() == 0) {
                tMedida3.setText("0");
            }

            if (tMedida4.getText() != null && tMedida4.getText().length() == 0) {
                tMedida4.setText("0");
            }

            if (tMedida5.getText() != null && tMedida5.getText().length() == 0) {
                tMedida5.setText("0");
            }

        }
    }

    public Articulo getArticulo() {
        return a;
    }

    public boolean isLineaArticulo() {
        return isLineaArticulo;
    }

    public Caracteristica getCaracteristica() {
        return car;
    }

    public boolean isDac() {
        boolean res = isDac;
        if (!res && a != null) {
            res = BaseDatos.obtenerDacPorCodigoArticulo(a.getCod_articulo(), e.getIid()) != null;
        }
        return res;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        tCantidad = new javax.swing.JTextField();
        tcodigo = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tdescripcion = new javax.swing.JTextArea();
        tMedida1 = new javax.swing.JTextField();
        tMedida2 = new javax.swing.JTextField();
        tMedida3 = new javax.swing.JTextField();
        tMedida4 = new javax.swing.JTextField();
        tMedida5 = new javax.swing.JTextField();
        tmedidaResultado = new javax.swing.JTextField();
        bseleccionArticulo = new javax.swing.JButton();
        tPrecio = new javax.swing.JTextField();
        tDescuento = new javax.swing.JTextField();
        ldto = new javax.swing.JLabel();
        timporte = new javax.swing.JTextField();
        bborrar = new javax.swing.JButton();
        jSeparator1 = new javax.swing.JSeparator();
        jSeparator2 = new javax.swing.JSeparator();
        jSeparator3 = new javax.swing.JSeparator();
        jSeparator4 = new javax.swing.JSeparator();
        jSeparator5 = new javax.swing.JSeparator();
        tRecibido = new javax.swing.JTextField();
        tPendiente = new javax.swing.JTextField();

        setBackground(new java.awt.Color(204, 204, 204));
        setAutoscrolls(true);

        tCantidad.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                tCantidadFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                tCantidadFocusLost(evt);
            }
        });
        tCantidad.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tCantidadKeyReleased(evt);
            }
        });

        tcodigo.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tcodigoKeyReleased(evt);
            }
        });

        tdescripcion.setColumns(20);
        tdescripcion.setRows(5);
        tdescripcion.setAutoscrolls(false);
        tdescripcion.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                tdescripcionFocusGained(evt);
            }
        });
        tdescripcion.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tdescripcionKeyReleased(evt);
            }
        });
        jScrollPane1.setViewportView(tdescripcion);

        tMedida1.setFont(new java.awt.Font("Tahoma", 1, 11));
        tMedida1.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                tMedida1FocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                tMedida1FocusLost(evt);
            }
        });
        tMedida1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tMedida1KeyReleased(evt);
            }
        });

        tMedida2.setFont(new java.awt.Font("Tahoma", 1, 11));
        tMedida2.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                tMedida2FocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                tMedida2FocusLost(evt);
            }
        });
        tMedida2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tMedida2KeyReleased(evt);
            }
        });

        tMedida3.setFont(new java.awt.Font("Tahoma", 1, 11));
        tMedida3.setToolTipText("0");
        tMedida3.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                tMedida3FocusGained(evt);
            }
        });
        tMedida3.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tMedida3KeyReleased(evt);
            }
        });

        tMedida4.setFont(new java.awt.Font("Tahoma", 1, 11));
        tMedida4.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                tMedida4FocusGained(evt);
            }
        });
        tMedida4.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tMedida4KeyReleased(evt);
            }
        });

        tMedida5.setFont(new java.awt.Font("Tahoma", 1, 11));
        tMedida5.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                tMedida5FocusGained(evt);
            }
        });
        tMedida5.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tMedida5KeyReleased(evt);
            }
        });

        tmedidaResultado.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                tmedidaResultadoFocusGained(evt);
            }
        });

        bseleccionArticulo.setText("...");
        bseleccionArticulo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bseleccionArticuloActionPerformed(evt);
            }
        });

        tPrecio.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                tPrecioFocusGained(evt);
            }
        });
        tPrecio.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tPrecioKeyReleased(evt);
            }
        });

        tDescuento.setFont(new java.awt.Font("Tahoma", 1, 11));
        tDescuento.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                tDescuentoFocusGained(evt);
            }
        });
        tDescuento.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tDescuentoKeyReleased(evt);
            }
        });

        ldto.setText("Dto:");

        timporte.setEditable(false);
        timporte.setFont(new java.awt.Font("Tahoma", 1, 11));

        bborrar.setText("Borrar");
        bborrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bborrarActionPerformed(evt);
            }
        });

        jSeparator1.setOrientation(javax.swing.SwingConstants.VERTICAL);

        jSeparator2.setOrientation(javax.swing.SwingConstants.VERTICAL);

        jSeparator3.setOrientation(javax.swing.SwingConstants.VERTICAL);

        jSeparator4.setOrientation(javax.swing.SwingConstants.VERTICAL);

        tRecibido.setBackground(new java.awt.Color(204, 255, 204));
        tRecibido.setFont(new java.awt.Font("Tahoma", 1, 9)); // NOI18N
        tRecibido.setText("0");
        tRecibido.setToolTipText("Cantidad recibida");
        tRecibido.setDisabledTextColor(new java.awt.Color(0, 0, 0));
        tRecibido.setEnabled(false);

        tPendiente.setBackground(new java.awt.Color(255, 204, 204));
        tPendiente.setFont(new java.awt.Font("Tahoma", 1, 9)); // NOI18N
        tPendiente.setText("0");
        tPendiente.setToolTipText("Cantidad pendiente");
        tPendiente.setDisabledTextColor(new java.awt.Color(0, 0, 0));
        tPendiente.setEnabled(false);

        org.jdesktop.layout.GroupLayout layout = new org.jdesktop.layout.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(layout.createSequentialGroup()
                .addContainerGap()
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(layout.createSequentialGroup()
                        .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(org.jdesktop.layout.GroupLayout.TRAILING, layout.createSequentialGroup()
                                .add(tRecibido, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 30, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                .add(42, 42, 42))
                            .add(layout.createSequentialGroup()
                                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                                    .add(tCantidad, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 58, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                    .add(bborrar, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 62, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                    .add(layout.createSequentialGroup()
                                        .add(36, 36, 36)
                                        .add(tPendiente, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 30, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                                .add(6, 6, 6)))
                        .add(jSeparator1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                        .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                            .add(layout.createSequentialGroup()
                                .add(tcodigo, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 307, Short.MAX_VALUE)
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                .add(bseleccionArticulo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 23, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                            .add(jScrollPane1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 336, Short.MAX_VALUE))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                        .add(jSeparator2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                            .add(tMedida4)
                            .add(tMedida1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 51, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                        .add(6, 6, 6)
                        .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                            .add(tMedida5)
                            .add(tMedida2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 50, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                            .add(tMedida3, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 56, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(org.jdesktop.layout.GroupLayout.LEADING, tmedidaResultado, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 56, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jSeparator3, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(tDescuento, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 67, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(ldto)
                            .add(org.jdesktop.layout.GroupLayout.TRAILING, tPrecio, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 67, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jSeparator4, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(20, 20, 20)
                        .add(timporte, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 66, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(14, 14, 14))
                    .add(layout.createSequentialGroup()
                        .add(jSeparator5, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 786, Short.MAX_VALUE)
                        .addContainerGap())))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(layout.createSequentialGroup()
                .add(6, 6, 6)
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                        .add(jSeparator4)
                        .add(jSeparator3)
                        .add(layout.createSequentialGroup()
                            .add(tPrecio, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(18, 18, 18)
                            .add(ldto)
                            .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                            .add(tDescuento, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                        .add(layout.createSequentialGroup()
                            .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                                .add(layout.createSequentialGroup()
                                    .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                                        .add(tMedida2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                        .add(tMedida3, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                                    .add(26, 26, 26))
                                .add(layout.createSequentialGroup()
                                    .add(tMedida1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                    .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                                        .add(tMedida4, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                        .add(tMedida5, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))))
                            .add(11, 11, 11)
                            .add(tmedidaResultado, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                        .add(timporte, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(layout.createSequentialGroup()
                            .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                                    .add(bseleccionArticulo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 21, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                    .add(tcodigo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                                .add(tCantidad, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                            .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                            .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                                .add(layout.createSequentialGroup()
                                    .add(bborrar)
                                    .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                    .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                                        .add(tRecibido, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                        .add(tPendiente, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                                .add(jScrollPane1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 79, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                        .add(jSeparator2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 106, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                    .add(jSeparator1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 106, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jSeparator5, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
        );
    }// </editor-fold>//GEN-END:initComponents

private void bseleccionArticuloActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bseleccionArticuloActionPerformed

    String coP = p.getCodigoCliente();
    String tiP = "prov";
    Agentes ag = new Agentes();

    ag = BaseDatos.obtenerAgentesPorCodigo(coP, tiP, e);

    ListaSeleccionArticulosCompras frame = new ListaSeleccionArticulosCompras(e, this, ag, u);
    frame.setDefaultCloseOperation(ListaSeleccionArticulos.DISPOSE_ON_CLOSE);
    frame.setLocationRelativeTo(null);
    frame.setVisible(true);
    p.setLineaActiva(codigo);
    anadirLineaDocumento();


}//GEN-LAST:event_bseleccionArticuloActionPerformed

private void tCantidadFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_tCantidadFocusGained
    cantidadAntesFoco = 0D;
    if (!tCantidad.getText().equals("")) {
        cantidadAntesFoco = new Double(Util.convertirComaAPunto(tCantidad.getText()));
    }
    anadirLineaDocumento();
    p.setLineaActiva(codigo);
}//GEN-LAST:event_tCantidadFocusGained

private void tMedida1KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tMedida1KeyReleased

    int tamaño = tMedida1.getText().length();
    if (tamaño > 0) {
        char c = tMedida1.getText().charAt(tamaño - 1);

        if (c == '.') {
            String contenidoAntiguo = tMedida1.getText().replace(".", ",");
            tMedida1.setText(contenidoAntiguo);
            c = ',';
        }

        if (!((c >= '0' && c <= '9') || c == ',')) {
            String str = tMedida1.getText().substring(0, tamaño - 1);
            tMedida1.setText(str);
        } else if (c == ',') {
            int indicePunto = tMedida1.getText().indexOf(',');
            if (indicePunto != (tamaño - 1)) {
                String str = tMedida1.getText().substring(0, tamaño - 1);
                tMedida1.setText(str);
            }
        }
        tPrecio.setText(Util.convertirPuntoAComa(String.valueOf(calcularPrecioEscalado(agAc))));
    }
    calcularPrecioArticulo();
    p.setLineaActiva(codigo);
    anadirLineaDocumento();
}//GEN-LAST:event_tMedida1KeyReleased

private void tMedida2KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tMedida2KeyReleased
    int tamaño = tMedida2.getText().length();
    if (tamaño > 0) {
        char c = tMedida2.getText().charAt(tamaño - 1);

        if (c == '.') {
            String contenidoAntiguo = tMedida2.getText().replace(".", ",");
            tMedida2.setText(contenidoAntiguo);
            c = ',';
        }

        if (!((c >= '0' && c <= '9') || c == ',')) {
            String str = tMedida2.getText().substring(0, tamaño - 1);
            tMedida2.setText(str);
        } else if (c == ',') {
            int indicePunto = tMedida2.getText().indexOf(',');
            if (indicePunto != (tamaño - 1)) {
                String str = tMedida2.getText().substring(0, tamaño - 1);
                tMedida2.setText(str);
            }
        }

        tPrecio.setText(Util.convertirPuntoAComa(String.valueOf(calcularPrecioEscalado(agAc))));
    }

    calcularPrecioArticulo();
    p.setLineaActiva(codigo);
    anadirLineaDocumento();
}//GEN-LAST:event_tMedida2KeyReleased

private void tMedida3KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tMedida3KeyReleased
    int tamaño = tMedida3.getText().length();
    if (tamaño > 0) {
        char c = tMedida3.getText().charAt(tamaño - 1);

        if (c == '.') {
            String contenidoAntiguo = tMedida3.getText().replace(".", ",");
            tMedida3.setText(contenidoAntiguo);
            c = ',';
        }

        if (!((c >= '0' && c <= '9') || c == ',')) {
            String str = tMedida3.getText().substring(0, tamaño - 1);
            tMedida3.setText(str);
        } else if (c == ',') {
            int indicePunto = tMedida3.getText().indexOf(',');
            if (indicePunto != (tamaño - 1)) {
                String str = tMedida3.getText().substring(0, tamaño - 1);
                tMedida3.setText(str);
            }
        }

        tPrecio.setText(Util.convertirPuntoAComa(String.valueOf(calcularPrecioEscalado(agAc))));
    }

    calcularPrecioArticulo();
    p.setLineaActiva(codigo);
    anadirLineaDocumento();
}//GEN-LAST:event_tMedida3KeyReleased

private void tMedida4KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tMedida4KeyReleased
    int tamaño = tMedida4.getText().length();
    if (tamaño > 0) {
        char c = tMedida4.getText().charAt(tamaño - 1);

        if (c == '.') {
            String contenidoAntiguo = tMedida4.getText().replace(".", ",");
            tMedida4.setText(contenidoAntiguo);
            c = ',';
        }

        if (!((c >= '0' && c <= '9') || c == ',')) {
            String str = tMedida4.getText().substring(0, tamaño - 1);
            tMedida4.setText(str);
        } else if (c == ',') {
            int indicePunto = tMedida4.getText().indexOf(',');
            if (indicePunto != (tamaño - 1)) {
                String str = tMedida4.getText().substring(0, tamaño - 1);
                tMedida4.setText(str);
            }
        }

        tPrecio.setText(Util.convertirPuntoAComa(String.valueOf(calcularPrecioEscalado(agAc))));
    }

    calcularPrecioArticulo();
    p.setLineaActiva(codigo);
    anadirLineaDocumento();
}//GEN-LAST:event_tMedida4KeyReleased

private void tMedida5KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tMedida5KeyReleased
    int tamaño = tMedida5.getText().length();
    if (tamaño > 0) {
        char c = tMedida5.getText().charAt(tamaño - 1);

        if (c == '.') {
            String contenidoAntiguo = tMedida5.getText().replace(".", ",");
            tMedida5.setText(contenidoAntiguo);
            c = ',';
        }

        if (!((c >= '0' && c <= '9') || c == ',')) {
            String str = tMedida5.getText().substring(0, tamaño - 1);
            tMedida5.setText(str);
        } else if (c == ',') {
            int indicePunto = tMedida5.getText().indexOf(',');
            if (indicePunto != (tamaño - 1)) {
                String str = tMedida5.getText().substring(0, tamaño - 1);
                tMedida5.setText(str);
            }
        }

        tPrecio.setText(Util.convertirPuntoAComa(String.valueOf(calcularPrecioEscalado(agAc))));
    }

    calcularPrecioArticulo();
    p.setLineaActiva(codigo);
    anadirLineaDocumento();
}//GEN-LAST:event_tMedida5KeyReleased

private void tCantidadKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tCantidadKeyReleased

    int tamaño = tCantidad.getText().length();
    if (tamaño > 0) {
        char c = tCantidad.getText().charAt(tamaño - 1);

        if (c == '.') {
            String contenidoAntiguo = tCantidad.getText().replace(".", ",");
            tCantidad.setText(contenidoAntiguo);
            c = ',';
        }

        if (c == '-' && tamaño == 1) {
            //Se perminte, así que no se hace nada
        } else if (!((c >= '0' && c <= '9') || c == ',')) {
            String str = tCantidad.getText().substring(0, tamaño - 1);
            tCantidad.setText(str);
        } else if (c == ',') {
            int indicePunto = tCantidad.getText().indexOf(',');
            if (indicePunto != (tamaño - 1)) {
                String str = tCantidad.getText().substring(0, tamaño - 1);
                tCantidad.setText(str);
            }
        }
    }

    calcularPrecioArticulo();
    p.setLineaActiva(codigo);
    anadirLineaDocumento();
}//GEN-LAST:event_tCantidadKeyReleased

private void tPrecioKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tPrecioKeyReleased

    int tamaño = tPrecio.getText().length();
    if (tamaño > 0) {
        
        char c = tPrecio.getText().charAt(tamaño - 1);
        
        if (c == '.') {
            String contenidoAntiguo = tPrecio.getText().replace(".", ",");
            tPrecio.setText(contenidoAntiguo);
            c = ',';
        }

        if (!((c >= '0' && c <= '9') || c == ',')) {
            String str = tPrecio.getText().substring(0, tamaño - 1);
            tPrecio.setText(str);
        } else if (c == ',') {
            int indicePunto = tPrecio.getText().indexOf(',');
            if (indicePunto != (tamaño - 1)) {
                String str = tPrecio.getText().substring(0, tamaño - 1);
                tPrecio.setText(str);
            }
        }
    }
    
    calcularPrecioArticulo();
    p.setLineaActiva(codigo);
    anadirLineaDocumento();
}//GEN-LAST:event_tPrecioKeyReleased

private void tDescuentoKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tDescuentoKeyReleased

    int tamaño = tDescuento.getText().length();
    if (tamaño > 0) {
        char c = tDescuento.getText().charAt(tamaño - 1);

        if (c == '.') {
            String contenidoAntiguo = tDescuento.getText().replace(".", ",");
            tDescuento.setText(contenidoAntiguo);
            c = ',';
        }

        if (!((c >= '0' && c <= '9') || c == ',')) {
            String str = tDescuento.getText().substring(0, tamaño - 1);
            tDescuento.setText(str);
        } else if (c == ',') {
            int indicePunto = tDescuento.getText().indexOf(',');
            if (indicePunto != (tamaño - 1)) {
                String str = tDescuento.getText().substring(0, tamaño - 1);
                tDescuento.setText(str);
            }
        }
    }
    
    calcularPrecioArticulo();
    p.setLineaActiva(codigo);
    anadirLineaDocumento();
}//GEN-LAST:event_tDescuentoKeyReleased

private void bborrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bborrarActionPerformed
    p.borrarLineaDocumento(codigo);
    p.setLineaActiva(codigo);
    anadirLineaDocumento();
}//GEN-LAST:event_bborrarActionPerformed

private void tMedida1FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_tMedida1FocusGained
    medida1AntesFoco = 0D;
    if (!tMedida1.getText().equals("")) {
        medida1AntesFoco = new Double(Util.convertirComaAPunto(tMedida1.getText()));
    }
    p.setLineaActiva(codigo);
    anadirLineaDocumento();
}//GEN-LAST:event_tMedida1FocusGained

private void tMedida2FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_tMedida2FocusGained
    medida2AntesFoco = 0D;
    if (!tMedida2.getText().equals("")) {
        medida2AntesFoco = new Double(Util.convertirComaAPunto(tMedida2.getText()));
    }
    p.setLineaActiva(codigo);
    anadirLineaDocumento();
}//GEN-LAST:event_tMedida2FocusGained

private void tMedida3FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_tMedida3FocusGained
    p.setLineaActiva(codigo);
}//GEN-LAST:event_tMedida3FocusGained

private void tMedida4FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_tMedida4FocusGained
    p.setLineaActiva(codigo);
    anadirLineaDocumento();
}//GEN-LAST:event_tMedida4FocusGained

private void tMedida5FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_tMedida5FocusGained
    p.setLineaActiva(codigo);
    anadirLineaDocumento();
}//GEN-LAST:event_tMedida5FocusGained

private void tmedidaResultadoFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_tmedidaResultadoFocusGained
    p.setLineaActiva(codigo);
    anadirLineaDocumento();
}//GEN-LAST:event_tmedidaResultadoFocusGained

private void tPrecioFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_tPrecioFocusGained
    p.setLineaActiva(codigo);
    anadirLineaDocumento();
}//GEN-LAST:event_tPrecioFocusGained

private void tDescuentoFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_tDescuentoFocusGained
    p.setLineaActiva(codigo);
    anadirLineaDocumento();
}//GEN-LAST:event_tDescuentoFocusGained

private void tdescripcionKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tdescripcionKeyReleased
    String descripcion = tdescripcion.getText();
    if (descripcion.length() > Constantes.TAM_DESCRIPCION_ARTICULO_PRESUPUESTO) {
        JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_DESCRIPCION_ARTICULO_PRESUPUESTO, "Error", JOptionPane.ERROR_MESSAGE);
        tdescripcion.setText(descripcion.substring(0, Constantes.TAM_DESCRIPCION_ARTICULO_PRESUPUESTO));
    }
    p.setLineaActiva(codigo);
    anadirLineaDocumento();
}//GEN-LAST:event_tdescripcionKeyReleased

private void tdescripcionFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_tdescripcionFocusGained
    p.setLineaActiva(codigo);
    anadirLineaDocumento();
}//GEN-LAST:event_tdescripcionFocusGained

private void tcodigoKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tcodigoKeyReleased
    importe = 0D;

    if (evt.getKeyChar() == KeyEvent.VK_ENTER) {

        importe = 0D;
        String sCodigo = tcodigo.getText();
        if (!sCodigo.equals("")) {
            String codigoArticulo = "";
            String codigoCaracteristica = "";

            if (sCodigo.contains("/")) {
                codigoArticulo = sCodigo.substring(0, sCodigo.indexOf('/'));
                codigoCaracteristica = sCodigo.substring(sCodigo.indexOf('/') + 1);
            } else {
                codigoArticulo = sCodigo;
                codigoCaracteristica = "";
            }

            Articulo artT = BaseDatos.obtenerArticulo(codigoArticulo, e.getIid());
            Colores colorT = null;
            Caracteristica cT = null;
            boolean operacionOK = true;

            if (artT == null) {
                //Error, el articulo no existe
                tcodigo.setForeground(Color.RED);
                tdescripcion.setText("El artículo introducido no existe");
                operacionOK = false;

            } else {
                List listaC = BaseDatos.getListaCaracteristicas(e, artT);
                if (listaC != null && listaC.size() > 0) {
                    if (codigoCaracteristica.equals("")) {
                        //Error
                        tdescripcion.setText("El artículo introducido tiene características");
                        operacionOK = false;
                    } else {
                        //Ok
                        colorT = BaseDatos.obtenerColor(codigoCaracteristica);
                        if (colorT == null) {
                            //Error
                            tdescripcion.setText("La característica introducida no existe");
                            operacionOK = false;
                        } else {
                            cT = BaseDatos.obtenerCaracteristica(artT, e, colorT);
                            if (cT == null) {
                                //Error
                                tdescripcion.setText("La característica introducida no existe");
                                operacionOK = false;
                            } else {
                                tcodigo.setForeground(Color.BLACK);
                                tdescripcion.setText("");
                            }
                        }
                    }
                } else {
                    if (!codigoCaracteristica.equals("")) {
                        //Error
                        tdescripcion.setText("El artículo introducido no tiene características");
                        operacionOK = false;
                    } else {
                        //Ok
                        colorT = null;
                        cT = null;
                    }
                }

                if (operacionOK) {
                    this.a = artT;
                    this.car = cT;
                    tdescripcion.setText("");
                    tcodigo.setForeground(Color.BLACK);

                    insertarArticulo(artT, cT, null);
                    anadirLineaDocumento();
                    FamiliaVenta fv = BaseDatos.obtenerFamiliaVentaPorIid(artT.getIid_fam_venta().getIid());
                    TipoControl tc = BaseDatos.obtenerTipoControlPorIid(fv.getIid_tipo_control().getIid());
                    TipoMedida tm = BaseDatos.obtenerTipoMedidaByIid(tc.getIid_tipo_medida().getIid());
                    setNumMedidas(tm.getNum_dimensiones());
                    //}
                } else {
                    tcodigo.setForeground(Color.red);
                    tCantidad.setText("");
                    tMedida1.setText("");
                    tMedida2.setText("");
                    tMedida3.setText("");
                    tMedida4.setText("");
                    tMedida5.setText("");
                    tmedidaResultado.setText("");
                    tPrecio.setText("");
                    tDescuento.setText("");
                    timporte.setText("");
                }

            }
        }
    }
    p.calcularPrecio();
}//GEN-LAST:event_tcodigoKeyReleased

private void tCantidadFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_tCantidadFocusLost
    if (p.getTipoDocumento().equalsIgnoreCase(Constantes.PEDIDO)) {
        cantidadDespuesFoco = 0D;
        if (!tCantidad.getText().equals("")) {
            cantidadDespuesFoco = new Double(Util.convertirComaAPunto(tCantidad.getText()));
        }
        if (iid != null && !cantidadAntesFoco.equals(cantidadDespuesFoco)) {
            //Si la linea ya está almacenada en la BBDD y esta linea tiene cortes de lona entonces se han de borrar
            List<LineaCorteLona> llcl = BaseDatos.getListaLineaCorteLonaByLineaPresupuesto(iid);
            if (llcl != null && llcl.size() > 0) {
                //Las lonas cortadas serán deshechas
                JOptionPane.showMessageDialog(null, "Los cortes de lona de esta linea serán eliminados", "Información", JOptionPane.INFORMATION_MESSAGE);
                BaseDatos.eliminarCorteLonaByLineaPresupuesto(iid);
            }
        }
    }
}//GEN-LAST:event_tCantidadFocusLost

private void tMedida1FocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_tMedida1FocusLost
    if (p.getTipoDocumento().equalsIgnoreCase(Constantes.PEDIDO)) {
        medida1DespuesFoco = 0D;
        if (!tMedida1.getText().equals("")) {
            medida1DespuesFoco = new Double(Util.convertirComaAPunto(tMedida1.getText()));
        }
        if (iid != null && !medida1AntesFoco.equals(medida1DespuesFoco)) {
            //Si la linea ya está almacenada en la BBDD y esta linea tiene cortes de lona entonces se han de borrar
            List<LineaCorteLona> llcl = BaseDatos.getListaLineaCorteLonaByLineaPresupuesto(iid);
            if (llcl != null && llcl.size() > 0) {
                //Las lonas cortadas serán deshechas
                JOptionPane.showMessageDialog(null, "Los cortes de lona de esta linea serán eliminados", "Información", JOptionPane.INFORMATION_MESSAGE);
                BaseDatos.eliminarCorteLonaByLineaPresupuesto(iid);
            }
        }
    }
}//GEN-LAST:event_tMedida1FocusLost

private void tMedida2FocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_tMedida2FocusLost
    if (p.getTipoDocumento().equalsIgnoreCase(Constantes.PEDIDO)) {
        medida2DespuesFoco = 0D;
        if (!tMedida2.getText().equals("")) {
            medida2DespuesFoco = new Double(Util.convertirComaAPunto(tMedida2.getText()));
        }
        if (iid != null && !medida2AntesFoco.equals(medida2DespuesFoco)) {
            //Si la linea ya está almacenada en la BBDD y esta linea tiene cortes de lona entonces se han de borrar
            List<LineaCorteLona> llcl = BaseDatos.getListaLineaCorteLonaByLineaPresupuesto(iid);
            if (llcl != null && llcl.size() > 0) {
                //Las lonas cortadas serán deshechas
                JOptionPane.showMessageDialog(null, "Los cortes de lona de esta linea serán eliminados", "Información", JOptionPane.INFORMATION_MESSAGE);
                BaseDatos.eliminarCorteLonaByLineaPresupuesto(iid);
            }
        }
    }
}//GEN-LAST:event_tMedida2FocusLost

    private void calcularPrecioArticulo() {

        ScriptEngineManager manager = new ScriptEngineManager();
        ScriptEngine engine = manager.getEngineByName("js");

        String scantidad;
        String sprecio;
        String sdescuento;

        if (tCantidad.getText().equals("") || tCantidad.getText().equals("-")) {
            scantidad = "0";
        } else {
            scantidad = Util.convertirComaAPunto(tCantidad.getText());
        }

        if (tPrecio.getText().equals("")) {
            sprecio = "0";
        } else {
            sprecio = Util.convertirComaAPunto(tPrecio.getText());
        }

        if (tDescuento.getText().equals("")) {
            sdescuento = "0";
        } else {
            sdescuento = Util.convertirComaAPunto(tDescuento.getText());
        }

        if (!scantidad.equals("") && !sprecio.equals("")) {
            try {
                if (sdescuento.equals("")) {
                    sdescuento = "0";
                }
                if (sprecio.equals("")) {
                    sprecio = "0";
                }
                if (scantidad.equals("")) {
                    scantidad = "0";
                }
                cantidad = Double.valueOf(scantidad);
                float fprecio = Float.valueOf(sprecio);
                if (!sdescuento.equals("")) {
                    descuento = Double.valueOf(sdescuento);
                }

                engine.put("Dim1", Util.convertirComaAPunto(tMedida1.getText()));
                engine.put("Dim2", Util.convertirComaAPunto(tMedida2.getText()));
                engine.put("Dim3", Util.convertirComaAPunto(tMedida3.getText()));
                engine.put("Dim4", Util.convertirComaAPunto(tMedida4.getText()));
                engine.put("Dim5", Util.convertirComaAPunto(tMedida5.getText()));

                FamiliaVenta fv = BaseDatos.obtenerFamiliaVentaPorIid(a.getIid_fam_venta().getIid());
                TipoControl tc = BaseDatos.obtenerTipoControlPorIid(fv.getIid_tipo_control().getIid());
                TipoMedida tm = BaseDatos.obtenerTipoMedidaByIid(tc.getIid_tipo_medida().getIid());

                String tipoCalculo = tm.getTipo_calculo();
                Float medidaTotal;

                if (tipoCalculo.equals("Fórmula")) {
                    Double medidaTotalDouble = (Double) engine.eval(tm.getFormula());
                    medidaTotal = Float.parseFloat(String.valueOf(medidaTotalDouble));
                } else {
                    medidaTotal = Float.parseFloat(Util.convertirComaAPunto(tMedida1.getText())) / 100;
                }

                tmedidaResultado.setText(Util.convertirPuntoAComa(String.valueOf(medidaTotal)));

                if (a.getEscalado() || a.getEscaladoCaracteristica()) {
                    medidaTotal = 1F;
                }

                precio = cantidad * fprecio * medidaTotal * (100 - descuento) / 100;
                precio = matematico.Matematico.redondear2decimales(precio);
                timporte.setText(Util.convertirPuntoAComa(String.valueOf(precio)));
                importe = precio;
                p.calcularPrecio();

            } catch (Exception ex) {
                timporte.setText("");
                importe = 0d;
                this.precio = 0d;
                p.calcularPrecio();
                //Error, los campos numéricos no contienen números
                //JOptionPane.showMessageDialog(null, "El campo \"Precio\", \"Descuento\" e \"Iva\" deben ser numérico", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            timporte.setText("");
            importe = 0d;
            this.precio = 0d;
            p.calcularPrecio();
        }
    }

    protected void anadirLineaDocumento() {
        if (isUltimoPanel()) {
            p.anadirLineaPresupuesto();
        }
    }

    public String getTcantidad() {
        return tCantidad.getText();
    }

    public String getDescripcion() {
        return tdescripcion.getText();
    }

    private Float calcularPrecioEscalado(AgenteArticuloCodigo aac) {
        Float res = 0F;

        Float fMedida1 = -1F;
        Float fMedida2 = -1F;

        //Primero buscamos el precio por proveedor
        if (aac != null) {
            res = aac.getPrecio();
        }

        if (aac == null) {
            if (car != null) {
                if (car.getUpc() != null) {
                    res = car.getUpc();
                } else {
                    res = 0F;
                }
            } else {
                if (a.getUpc() != null) {
                    res = a.getUpc();
                } else {
                    res = 0F;
                }
            }
        }
        return res;
    }

    protected void insertarArticulo(Articulo ar, Caracteristica c, Agentes a) {
        isDac = false;
        insertarElemento(ar, c, a);

        if (tCantidad.getText() == null || tCantidad.getText().length() == 0) {
            tCantidad.setText("0");
        }
        calcularPrecioArticulo();
    }

    private void insertarElemento(Articulo ar, Caracteristica c, Agentes proveedor) {
        AgenteArticuloCodigo aAc = null;
        a = ar;
        car = c;
        String codigoArticulo = "";

        //lp.setMedida1(0.0);
        FamiliaVenta fv = BaseDatos.obtenerFamiliaVentaPorIid(a.getIid_fam_venta().getIid());
        TipoControl tp = BaseDatos.obtenerTipoControlPorIid(fv.getIid_tipo_control().getIid());
        TipoMedida tm = BaseDatos.obtenerTipoMedidaByIid(tp.getIid_tipo_medida().getIid());

        numMedidas = tm.getNum_dimensiones();

        if (proveedor != null) {

            if (c != null) {
                aAc = BaseDatos.obtenerAgenteArticuloCodigoPorColor(ar, proveedor, c.getIid_color().getIid());
            } else {
                aAc = BaseDatos.obtenerAgenteArticuloCodigoPorAgente(ar, proveedor);
            }
            if (aAc != null) {
                codigoArticulo = aAc.getCodigo();
                tcodigo.setForeground(Color.pink);

            } else {
                codigoArticulo = ar.getCod_articulo();
                if (c != null) {
                    codigoArticulo += "/" + c.getIid_color().getCod_color();
                }
            }

        } else {
            codigoArticulo = ar.getCod_articulo();

            if (c != null) {
                codigoArticulo += "/" + c.getIid_color().getCod_color();
            }

        }


        tcodigo.setText(codigoArticulo);
        tPrecio.setText(Util.convertirPuntoAComa(String.valueOf(calcularPrecioEscalado(aAc))));

        tdescripcion.setText(a.getDes_inf());

        this.agAc = aAc;

        //Se ha de calcular el descuento segun la siguiente prioridad:
        //1.- Se usará el descuento que la empresa tenga para ese artículo

        //Si el proveedor esta informado buscamos los datos para el artículo definido en el proveedor
        if (proveedor != null) {
            //Tenemos en cuenta las caracteristicas

            if (c != null) {
                aAc = BaseDatos.obtenerAgenteArticuloCodigoPorColor(ar, proveedor, c.getIid_color().getIid());
                if (aAc != null && aAc.getDescuento() != null) {
                    this.tDescuento.setText(Util.convertirPuntoAComa(aAc.getDescuento().toString()));
                }

            } else {
                //Obtener precios proveedor sin color
                //Buscamos el precio por proveedor
                aAc = BaseDatos.obtenerAgenteArticuloCodigoPorAgente(a, proveedor);

                if (aAc != null && aAc.getDescuento() != null) {
                    if (aAc.getCheckDto()) {
                        this.tDescuento.setText(Util.convertirPuntoAComa(aAc.getDescuento().toString()));
                    }
                } else if (ar != null && ar.getDescuento() != null) {
                    this.tDescuento.setText(Util.convertirPuntoAComa(ar.getDescuento().toString()));
                }
            }

        } else if (ar != null && ar.getDescuento() != null) {
            //Si no hay miramos si tenemos descuento definido en el artículo
            this.tDescuento.setText(Util.convertirPuntoAComa(ar.getDescuento().toString()));
        }


        //Creamos los ToolTipText de cada unidad de medida
        //Creamos los ToolTipText de cada unidad de medida

        //TipoControl tc = BaseDatos.obtenerTipoControlPorIid(ar.getIid_fam_venta().getIid_tipo_control().getIid());
       TipoControl tc = tp;
 
        if (tc.getUnidad1() != null) {
            tMedida1.setToolTipText(tc.getUnidad1().getNombre());
        }
        if (tc.getUnidad2() != null) {
            tMedida2.setToolTipText(tc.getUnidad2().getNombre());
        }
        if (tc.getUnidad3() != null) {
            tMedida3.setToolTipText(tc.getUnidad3().getNombre());
        }
        if (tc.getUnidad4() != null) {
            tMedida4.setToolTipText(tc.getUnidad4().getNombre());
        }
        if (tc.getUnidad5() != null) {
            tMedida5.setToolTipText(tc.getUnidad5().getNombre());
        }
    }

    private boolean isUltimoPanel() {
        return codigo == p.getNumArticulos();
    }

    public void ocultarTodo() {
        tCantidad.setVisible(false);
        tRecibido.setVisible(false);
        tPendiente.setVisible(false);
        bborrar.setVisible(false);
        this.tcodigo.setVisible(false);
        this.jScrollPane1.setVisible(false);
        bseleccionArticulo.setVisible(false);
        tMedida1.setVisible(false);
        tMedida2.setVisible(false);
        tMedida3.setVisible(false);
        tMedida4.setVisible(false);
        tMedida5.setVisible(false);
        tmedidaResultado.setVisible(false);
        tDescuento.setVisible(false);
        tPrecio.setVisible(false);
        ldto.setVisible(false);
        this.timporte.setVisible(false);
        jSeparator1.setVisible(false);
        jSeparator2.setVisible(false);
        jSeparator3.setVisible(false);
        jSeparator4.setVisible(false);
        jSeparator5.setVisible(false);
        lineaOculta = true;

    }

    public boolean getLineaOculta() {
        return lineaOculta;
    }

    private void mostrarCamposLineaArticulo(boolean isLineaArticulo) {
        jSeparator2.setVisible(isLineaArticulo);
        jSeparator3.setVisible(isLineaArticulo);
        jSeparator4.setVisible(isLineaArticulo);
        timporte.setVisible(isLineaArticulo);
        tPrecio.setVisible(isLineaArticulo);
        tDescuento.setVisible(isLineaArticulo);
        ldto.setVisible(isLineaArticulo);
        tmedidaResultado.setVisible(isLineaArticulo);
        tMedida1.setVisible(isLineaArticulo);
        tMedida2.setVisible(isLineaArticulo);
        tMedida3.setVisible(isLineaArticulo);
        tMedida4.setVisible(isLineaArticulo);
        tMedida5.setVisible(isLineaArticulo);
        tcodigo.setVisible(isLineaArticulo);
        bseleccionArticulo.setVisible(isLineaArticulo);
        tCantidad.setVisible(isLineaArticulo);
        
        ClaseDocumento cd = BaseDatos.getClaseDocumentosByIid(p.getClaseDocumento().getIid());

        if (!cd.getDescripcion().equals(Constantes.PEDIDOC)) {
            tRecibido.setVisible(false);
            tPendiente.setVisible(false);
        } 

    }

    public boolean esLineaCorrecta() {
        boolean res = true;
        String sCodigo = tcodigo.getText();

        if (!sCodigo.equals("")) {
            String codigoArticulo = "";
            String codigoCaracteristica = "";

            if (sCodigo.contains("/")) {
                codigoArticulo = sCodigo.substring(0, sCodigo.indexOf('/'));
                codigoCaracteristica = sCodigo.substring(sCodigo.indexOf('/') + 1);
            } else {
                codigoArticulo = sCodigo;
                codigoCaracteristica = "";
            }
        }
        return res;
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bborrar;
    private javax.swing.JButton bseleccionArticulo;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JSeparator jSeparator4;
    private javax.swing.JSeparator jSeparator5;
    private javax.swing.JLabel ldto;
    private javax.swing.JTextField tCantidad;
    private javax.swing.JTextField tDescuento;
    private javax.swing.JTextField tMedida1;
    private javax.swing.JTextField tMedida2;
    private javax.swing.JTextField tMedida3;
    private javax.swing.JTextField tMedida4;
    private javax.swing.JTextField tMedida5;
    private javax.swing.JTextField tPendiente;
    private javax.swing.JTextField tPrecio;
    private javax.swing.JTextField tRecibido;
    private javax.swing.JTextField tcodigo;
    private javax.swing.JTextArea tdescripcion;
    private javax.swing.JTextField timporte;
    private javax.swing.JTextField tmedidaResultado;
    // End of variables declaration//GEN-END:variables
}
