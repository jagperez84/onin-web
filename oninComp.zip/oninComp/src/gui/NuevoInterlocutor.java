package gui;

import acceso.BaseDatos;
import bean.Agentes;
import bean.Empresa;
import bean.Interlocutor;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.net.URL;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JOptionPane;
import javax.swing.KeyStroke;
import modelo.Modelo;
import util.Constantes;

public class NuevoInterlocutor extends javax.swing.JFrame {

    private Empresa e;
    private List listaEmpresas;
    private boolean actualizarFamilias;
    private Agentes cliente;

    public NuevoInterlocutor(Empresa e) {
        super("Interlocutor - Mantenimiento");
        this.e = e;
        actualizarFamilias = false;
        listaEmpresas = BaseDatos.getListaEmpresas();

        initComponents();
        iniciarEmpresas();
        iniciarDatos();

        bcancelar.setToolTipText("Cancelar");
        bInsertar.setToolTipText("Realizar la modificación");
        
        actualizarFamilias = true;
        
        crearIconosBotones();
        crearAcciones();
    }

    private void crearIconosBotones() {
        URL urlCancelar = getClass().getResource("/iconos/cancelar.gif");
        ImageIcon iconoCancelar = new ImageIcon(urlCancelar);
        bcancelar.setIcon(iconoCancelar);
        
        URL urlAceptar = getClass().getResource("/iconos/guardarYvolver.png");
        ImageIcon iconoAceptar = new ImageIcon(urlAceptar);
        bInsertar.setIcon(iconoAceptar);
    }
    
    private void cerrarVentana(){
        removeAll();
        dispose();
    }
    
    private void crearAcciones(){
        KeyStroke escapeKeyStroke = KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false);
        Action escapeAction = new AbstractAction() {
            public void actionPerformed(ActionEvent e) {
                cerrarVentana();
            }
        }; 
        getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(escapeKeyStroke, "ESCAPE");
        getRootPane().getActionMap().put("ESCAPE", escapeAction);
    }

    private void iniciarDatos(){
        cFamiliaVenta.removeAllItems();
        cFamiliaVenta.addItem(Constantes.VACIO);
        String empresaSeleccionada = (String) cEmpresa.getSelectedItem();
        if(!empresaSeleccionada.equals(Constantes.VACIO)){
            empresaSeleccionada = empresaSeleccionada.substring(0, empresaSeleccionada.indexOf("[(") - 3);
        }
        
        limpiarListadoFamilias();
        
        if(actualizarFamilias && !empresaSeleccionada.equals(Constantes.VACIO)){
            Empresa emp = BaseDatos.obtenerEmpresa(empresaSeleccionada);
            List listaInterlocutorFamiliaVenta = BaseDatos.obtenerFamiliaVentasSinInterlocutores(e.getIid(), emp.getIid());
            if(listaInterlocutorFamiliaVenta != null && listaInterlocutorFamiliaVenta.size() > 0){
                Iterator iter = listaInterlocutorFamiliaVenta.iterator();
                Object[] fila;
                while(iter.hasNext()){
                    fila = (Object[]) iter.next();
                    cFamiliaVenta.addItem(fila[0] + "   [(" + fila[1] + ")]");
                }
            }

            List listaFamiliasConInterlocutores = BaseDatos.obtenerFamiliaVentasConInterlocutores(e.getIid(), emp.getIid());
            if (listaFamiliasConInterlocutores == null) {
                listaFamiliasConInterlocutores = new ArrayList();
            }

            Modelo modelo = (Modelo) this.tFamilias.getModel();
            Iterator it;
            Object[] elemento;
                    
            if (listaFamiliasConInterlocutores != null) {
                for (it = listaFamiliasConInterlocutores.iterator(); it.hasNext();) {
                    elemento = (Object[]) it.next();
                    modelo.addRow(elemento);
                }
            }
            
            tCliente.setText("");
            Interlocutor inter = BaseDatos.obtenerInterlocutor(e.getIid(), emp.getIid());
            if(inter != null && inter.getIidCliente() != null){
                cliente = BaseDatos.obtenerAgenteByIid(inter.getIidCliente().getIid());
                if(cliente != null){
                    tCliente.setText(cliente.getNombre_comercial());
                }
            }
        }
    }
    
    public void rellenarCliente(Agentes a){
        cliente = a;
        tCliente.setText(a.getNombre_comercial());
    }
    
    private void limpiarListadoFamilias(){
        Modelo modelo = (Modelo) this.tFamilias.getModel();
        int i, j;

        //obtenemos el nº de filas;
        j = modelo.getRowCount();

        //eliminamos todas las filas
        for (i = 0; i < j; i++) {
            modelo.removeRow(0);
        }
    }
    
    private void iniciarEmpresas(){
        cEmpresa.addItem(Constantes.VACIO);
        if(listaEmpresas != null && listaEmpresas.size() > 0){
            Iterator iter = listaEmpresas.iterator();
            Empresa emp;
            while(iter.hasNext()){
                emp = (Empresa) iter.next();
                if(emp.getCod_empresa() != null && !emp.getCod_empresa().equals(e.getCod_empresa())){
                     cEmpresa.addItem(emp.getCod_empresa() + "   [(" + emp.getDesc_empresa() + ")]");
                }
               
            }
        }
    }

    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lcodigo = new javax.swing.JLabel();
        bInsertar = new javax.swing.JButton();
        bcancelar = new javax.swing.JButton();
        lfactor = new javax.swing.JLabel();
        lnombre = new javax.swing.JLabel();
        cEmpresa = new javax.swing.JComboBox();
        jScrollPane1 = new javax.swing.JScrollPane();
        tFactor = new javax.swing.JTextArea();
        cFamiliaVenta = new javax.swing.JComboBox();
        jScrollPane2 = new javax.swing.JScrollPane();
        Modelo modelo = new Modelo();
        tFamilias = new javax.swing.JTable(modelo);
        bBorrarFamilia = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        lnombre1 = new javax.swing.JLabel();
        tCliente = new javax.swing.JTextField();
        bCliente = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        lcodigo.setText("Empresa");

        bInsertar.setText("Añadir");
        bInsertar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bInsertarActionPerformed(evt);
            }
        });

        bcancelar.setText("Salir");
        bcancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bcancelarActionPerformed(evt);
            }
        });

        lfactor.setText("Formula");

        lnombre.setText("Familia venta");

        cEmpresa.setModel(new javax.swing.DefaultComboBoxModel(new String[] {}));
        cEmpresa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cEmpresaActionPerformed(evt);
            }
        });

        tFactor.setColumns(20);
        tFactor.setRows(5);
        tFactor.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tFactorKeyReleased(evt);
            }
        });
        jScrollPane1.setViewportView(tFactor);

        cFamiliaVenta.setModel(new javax.swing.DefaultComboBoxModel(new String[] {}));

        modelo.addColumn("Código");
        modelo.addColumn("Descripción");
        modelo.addColumn("Formula");

        tFamilias.getColumnModel().getColumn(0).setPreferredWidth(50);
        tFamilias.getColumnModel().getColumn(1).setPreferredWidth(200);
        tFamilias.getColumnModel().getColumn(2).setPreferredWidth(210);
        tFamilias.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        tFamilias.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tFamiliasKeyPressed(evt);
            }
        });
        jScrollPane2.setViewportView(tFamilias);

        bBorrarFamilia.setText("Eliminar");
        bBorrarFamilia.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bBorrarFamiliaActionPerformed(evt);
            }
        });

        jLabel1.setText("Listado de familias relacionadas");

        lnombre1.setText("Cliente");

        tCliente.setEditable(false);

        bCliente.setText("jButton1");
        bCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bClienteActionPerformed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout layout = new org.jdesktop.layout.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(layout.createSequentialGroup()
                .addContainerGap()
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(lcodigo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 41, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(jLabel1)
                    .add(layout.createSequentialGroup()
                        .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(lnombre)
                            .add(lfactor)
                            .add(lnombre1))
                        .add(21, 21, 21)
                        .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                            .add(org.jdesktop.layout.GroupLayout.LEADING, layout.createSequentialGroup()
                                .add(tCliente, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 336, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                .add(bCliente, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 26, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                            .add(org.jdesktop.layout.GroupLayout.LEADING, layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING, false)
                                .add(org.jdesktop.layout.GroupLayout.LEADING, jScrollPane1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 412, Short.MAX_VALUE)
                                .add(bInsertar, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 101, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                .add(org.jdesktop.layout.GroupLayout.LEADING, cFamiliaVenta, 0, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .add(org.jdesktop.layout.GroupLayout.LEADING, cEmpresa, 0, 391, Short.MAX_VALUE))))
                    .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                        .add(bcancelar)
                        .add(layout.createSequentialGroup()
                            .add(jScrollPane2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 414, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                            .add(bBorrarFamilia))))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(layout.createSequentialGroup()
                .addContainerGap()
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(lcodigo)
                    .add(cEmpresa, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(lnombre)
                    .add(cFamiliaVenta, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(lnombre1)
                    .add(tCliente, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(bCliente))
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(layout.createSequentialGroup()
                        .add(19, 19, 19)
                        .add(lfactor))
                    .add(layout.createSequentialGroup()
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jScrollPane1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                .add(18, 18, 18)
                .add(bInsertar)
                .add(19, 19, 19)
                .add(jLabel1)
                .add(18, 18, 18)
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jScrollPane2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 209, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(bBorrarFamilia))
                .add(13, 13, 13)
                .add(bcancelar)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

private void bInsertarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bInsertarActionPerformed

        String empresa = "";
        String familia = "";
        String factor = "";
        String clienteS = "";
 
        empresa = (String) cEmpresa.getSelectedItem();
        familia = (String) cFamiliaVenta.getSelectedItem();
        factor = tFactor.getText();
        Date fecha = new Date();
        clienteS = tCliente.getText();

        if (factor != null && factor.length() > 0 &&
                empresa != null && !empresa.equals(Constantes.VACIO) &&
                familia != null && !familia.equals(Constantes.VACIO) &&
                clienteS != null && clienteS.length() > 0) {
            
            familia = familia.substring(0, familia.indexOf("[(") - 3);
            empresa = empresa.substring(0, empresa.indexOf("[(") - 3);

            if (BaseDatos.crearInterlocutor(e, empresa, familia, factor, cliente)) {
                iniciarDatos();
                this.tFactor.setText("");
            } else {
                JOptionPane.showMessageDialog(null, "No se puede ha podido insertar el elemento", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            //Error, hay que rellenar todos los campos
            JOptionPane.showMessageDialog(null, "Debe rellenar los campos Empresa, familia de venta, cliente y factor", "Error", JOptionPane.ERROR_MESSAGE);
        }
}//GEN-LAST:event_bInsertarActionPerformed

private void bcancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bcancelarActionPerformed
    cerrarVentana();
}//GEN-LAST:event_bcancelarActionPerformed

private void tFactorKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tFactorKeyReleased
    String factor = tFactor.getText();
    if (factor.length() > Constantes.TAM_FACTOR_INTERLOCUTOR_FAMILIA_VENTA) {
        JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_FACTOR_INTERLOCUTOR_FAMILIA_VENTA, "Error", JOptionPane.ERROR_MESSAGE);
        tFactor.setText(factor.substring(0, Constantes.TAM_FACTOR_INTERLOCUTOR_FAMILIA_VENTA));
    }
}//GEN-LAST:event_tFactorKeyReleased

private void cEmpresaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cEmpresaActionPerformed
    iniciarDatos();
}//GEN-LAST:event_cEmpresaActionPerformed

private void bBorrarFamiliaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bBorrarFamiliaActionPerformed
    
    int indiceFila = tFamilias.getSelectedRow();
    if (indiceFila >= 0) {
        int eliminar = 1;
        eliminar = JOptionPane.showConfirmDialog(null, "¿Está seguro de que desea eliminar el elemento seleccionado?", "¿Eliminar?", JOptionPane.YES_NO_OPTION);
        //hacerCambios = -1 ==> se ha pulsado la "x" de cancelar;
        //hacerCambios =  0 ==> se ha pulsado el "sí"
        //hacerCambios =  1 ==> se ha pulsado el "no"

        if (eliminar == 0) {

            //obtenemos el codigo de la familia de venta
            String codigoFamilia = (String) tFamilias.getModel().getValueAt(indiceFila, 0);
            String codigoEmpresaHija = (String) cEmpresa.getSelectedItem();
            codigoEmpresaHija = codigoEmpresaHija.substring(0, codigoEmpresaHija.indexOf("[(") - 3);

            if (BaseDatos.eliminarInterlocutorFamiliaVenta(e.getIid(), codigoEmpresaHija, codigoFamilia)) {
                iniciarDatos();
            } else {
                JOptionPane.showMessageDialog(null, "No se ha podido eliminar el elemento seleccionado", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    } else {
        JOptionPane.showMessageDialog(null, "No hay seleccionado ningún elemento", "Error", JOptionPane.ERROR_MESSAGE);
    }
       
}//GEN-LAST:event_bBorrarFamiliaActionPerformed

private void tFamiliasKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tFamiliasKeyPressed
    if (evt.getKeyChar() == KeyEvent.VK_DELETE) {
        bBorrarFamiliaActionPerformed(null);
    }
}//GEN-LAST:event_tFamiliasKeyPressed

private void bClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bClienteActionPerformed
    ListaDeClientesInterlocutores ldc = new ListaDeClientesInterlocutores(this, e);
    ldc.setDefaultCloseOperation(ListaDeClientesInterlocutores.DISPOSE_ON_CLOSE);
    ldc.setLocationRelativeTo(null);
    ldc.setVisible(true);
}//GEN-LAST:event_bClienteActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bBorrarFamilia;
    private javax.swing.JButton bCliente;
    private javax.swing.JButton bInsertar;
    private javax.swing.JButton bcancelar;
    private javax.swing.JComboBox cEmpresa;
    private javax.swing.JComboBox cFamiliaVenta;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel lcodigo;
    private javax.swing.JLabel lfactor;
    private javax.swing.JLabel lnombre;
    private javax.swing.JLabel lnombre1;
    private javax.swing.JTextField tCliente;
    private javax.swing.JTextArea tFactor;
    private javax.swing.JTable tFamilias;
    // End of variables declaration//GEN-END:variables
}
