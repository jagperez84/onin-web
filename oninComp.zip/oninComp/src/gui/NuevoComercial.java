package gui;

import gui.*;
import acceso.*;
import auxiliar.Objeto2Elementos;
import bean.Articulo;
import bean.ClaseDocumento;
import bean.Comercial;
import bean.Empresa;
import bean.EstadoDocumento;
import bean.FormaPago2;
import bean.Iva;
import bean.LineaPresupuesto;
import bean.Presupuesto;
import informes.comerciales.InformeComercial;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.io.ByteArrayInputStream;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JOptionPane;
import javax.swing.KeyStroke;
import modelo.ModeloCheck;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import util.Constantes;
import util.Util;

public class NuevoComercial extends javax.swing.JFrame {

    private Comercial c;
    private boolean crear;
    private String codigoAntiguo;
    private String nombreAntiguo;
    private String nifAntiguo;
    private String paisAntiguo;
    private String provinciaAntigua;
    private String poblacionAntigua;
    private String direccionAntigua;
    private String cpAntiguo;
    private String tlfAntiguo;
    private String tlf2Antiguo;
    private String faxAntiguo;
    private String mailAntiguo;
    private String porcentajeAntiguo;
    private Empresa e;

    public NuevoComercial(String titulo, Empresa e) {
        super(titulo);
        this.e = e;
        crear = true;
        c = new Comercial();
        initComponents();
        bCancelar.setToolTipText("Cancelar la creación");
        bAceptar.setToolTipText("Realizar la modificación");
        bModificar.setVisible(false);
        bImprimir.setVisible(false);

        remove(pLista);
        repaint();
        pack();

        crearIconosBotones();
        crearAcciones();
    }

    public NuevoComercial(String titulo, Comercial c, Empresa e) {
        super(titulo);
        this.c = c;
        this.e = e;
        crear = false;
        initComponents();
        bCancelar.setToolTipText("Cancelar la creación");
        bAceptar.setToolTipText("Realizar la modificación");
        bModificar.setToolTipText("Modificar campos");
        bImprimir.setToolTipText("Imprimir documento");

        tCodigo.setText(c.getCodigo());
        tNombre.setText(c.getNombre());
        tNif.setText(c.getNif());
        tpais.setText(c.getPais());
        tprovincia.setText(c.getProvincia());
        tpoblacion.setText(c.getPoblacion());
        tdireccion.setText(c.getDireccion());
        tcp.setText(c.getCodigoPostal());
        ttlf.setText(c.getTelefono());
        ttlf2.setText(c.getTelefono2());
        tmail.setText(c.getEmail());
        tfax.setText(c.getFax());
        tPorcentaje.setText(Util.convertirPuntoAComa(c.getPorcentaje().toString()));

        tCodigo.setEnabled(false);
        tNombre.setEnabled(false);
        tNif.setEnabled(false);
        tpais.setEnabled(false);
        tprovincia.setEnabled(false);
        tpoblacion.setEnabled(false);
        tdireccion.setEnabled(false);
        tcp.setEnabled(false);
        ttlf.setEnabled(false);
        ttlf2.setEnabled(false);
        tmail.setEnabled(false);
        tfax.setEnabled(false);
        tPorcentaje.setEnabled(false);

        codigoAntiguo = c.getCodigo();
        nombreAntiguo = c.getNombre();
        nifAntiguo = c.getNif();
        paisAntiguo = c.getPais();
        provinciaAntigua = c.getProvincia();
        poblacionAntigua = c.getPoblacion();
        direccionAntigua = c.getDireccion();
        cpAntiguo = c.getCodigoPostal();
        tlfAntiguo = c.getTelefono();
        tlf2Antiguo = c.getTelefono2();
        faxAntiguo = c.getFax();
        mailAntiguo = c.getEmail();
        porcentajeAntiguo = c.getPorcentaje().toString();

        crearIconosBotones();
        crearAcciones();
    }

    private void crearAcciones() {
        KeyStroke escapeKeyStroke = KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false);
        Action escapeAction = new AbstractAction() {
            public void actionPerformed(ActionEvent e) {
                cerrarComercial();
            }
        };
        getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(escapeKeyStroke, "ESCAPE");
        getRootPane().getActionMap().put("ESCAPE", escapeAction);
        
        Dimension dim = Util.getDimensiones(this.getSize());
        if(dim != null){
            setResizable(true);
            setSize(dim);
        }
    }

    private void crearIconosBotones() {
        URL urlCancelar = getClass().getResource("/iconos/cancelar.gif");
        ImageIcon iconoCancelar = new ImageIcon(urlCancelar);
        bCancelar.setIcon(iconoCancelar);

        URL urlAceptar = getClass().getResource("/iconos/guardarYvolver.png");
        ImageIcon iconoAceptar = new ImageIcon(urlAceptar);
        bAceptar.setIcon(iconoAceptar);

        URL urlModificar = getClass().getResource("/iconos/editar.png");
        ImageIcon iconoModificar = new ImageIcon(urlModificar);
        bModificar.setIcon(iconoModificar);

        URL urlImprimir = getClass().getResource("/iconos/impresora.gif");
        ImageIcon iconoImprimir = new ImageIcon(urlImprimir);
        bImprimir.setIcon(iconoImprimir);
    }

    private void cerrarComercial() {
        removeAll();
        dispose();
    }

    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        bCancelar = new javax.swing.JButton();
        bAceptar = new javax.swing.JButton();
        bModificar = new javax.swing.JButton();
        bImprimir = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        pGeneral = new javax.swing.JPanel();
        lcp = new javax.swing.JLabel();
        tNombre = new javax.swing.JTextField();
        lNif = new javax.swing.JLabel();
        tprovincia = new javax.swing.JTextField();
        tNif = new javax.swing.JTextField();
        tpais = new javax.swing.JTextField();
        lpoblacion = new javax.swing.JLabel();
        tdireccion = new javax.swing.JTextField();
        ltelefono2 = new javax.swing.JLabel();
        lmail = new javax.swing.JLabel();
        lNombre = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        tCodigo = new javax.swing.JTextField();
        lprovincia = new javax.swing.JLabel();
        ttlf2 = new javax.swing.JTextField();
        ltelefono = new javax.swing.JLabel();
        lcodigo = new javax.swing.JLabel();
        lpais = new javax.swing.JLabel();
        tpoblacion = new javax.swing.JTextField();
        ttlf = new javax.swing.JTextField();
        tcp = new javax.swing.JTextField();
        ldireccion = new javax.swing.JLabel();
        lfax = new javax.swing.JLabel();
        pLista = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        List listaIndicesBooleanos = new ArrayList();
        listaIndicesBooleanos.add(6);
        listaIndicesBooleanos.add(7);
        ModeloCheck modelo = new ModeloCheck(listaIndicesBooleanos, 7);
        tDocumentos = new javax.swing.JTable(modelo);
        lPorcentaje = new javax.swing.JLabel();
        tPorcentaje = new javax.swing.JTextField();
        tfax = new javax.swing.JTextField();
        tmail = new javax.swing.JTextField();

        bCancelar.setText("Cancelar");
        bCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bCancelarActionPerformed(evt);
            }
        });

        bAceptar.setText("Aceptar");
        bAceptar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bAceptarActionPerformed(evt);
            }
        });

        bModificar.setText("Modificar");
        bModificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bModificarActionPerformed(evt);
            }
        });

        bImprimir.setText("Imprimir");
        bImprimir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bImprimirActionPerformed(evt);
            }
        });

        pGeneral.setRequestFocusEnabled(false);
        pGeneral.setVerifyInputWhenFocusTarget(false);

        lcp.setText("Código Postal");

        tNombre.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tNombreKeyReleased(evt);
            }
        });

        lNif.setText("N.I.F");

        tprovincia.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tprovinciaKeyReleased(evt);
            }
        });

        tNif.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tNifKeyReleased(evt);
            }
        });

        tpais.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tpaisKeyReleased(evt);
            }
        });

        lpoblacion.setText("Población");

        tdireccion.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tdireccionKeyReleased(evt);
            }
        });

        ltelefono2.setText("Telefono 2");

        lmail.setText("E-mail");

        lNombre.setText("Nombre");

        tCodigo.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tCodigoKeyReleased(evt);
            }
        });

        lprovincia.setText("Provincia");

        ttlf2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                ttlf2KeyReleased(evt);
            }
        });

        ltelefono.setText("Teléfono");

        lcodigo.setText("Código");

        lpais.setText("Pais");

        tpoblacion.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tpoblacionKeyReleased(evt);
            }
        });

        ttlf.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                ttlfKeyReleased(evt);
            }
        });

        tcp.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tcpKeyReleased(evt);
            }
        });

        ldireccion.setText("Dirección");

        lfax.setText("Fax");

        pLista.setBorder(javax.swing.BorderFactory.createTitledBorder("Documentos Asociados"));

        modelo.addColumn("Documento");
        modelo.addColumn("Número");
        modelo.addColumn("Serie");
        modelo.addColumn("Fecha");
        modelo.addColumn("Imp. Bruto");
        modelo.addColumn("Estado Documento");
        modelo.addColumn("Pagado Documento");
        modelo.addColumn("Pagado Comercial");
        modelo.addColumn("% Comercial");
        modelo.addColumn("% Precio");
        if(c.getIid() != null){
            List lPresupuesto = BaseDatos.getListaPresupuestoPorComercial(c.getIid(),e.getIid());
            Presupuesto p;
            Iterator it;
            Object[] fila;

            ClaseDocumento cd = new ClaseDocumento();
            HashMap<Integer, String> listaCD  = new HashMap<Integer, String>();
            HashMap<Integer, Float>  listaIva = new HashMap<Integer, Float>();
            HashMap<Integer, String> listaEst = new HashMap<Integer, String>();
            Iva iva = new Iva();
            EstadoDocumento es = new EstadoDocumento();
            Float ivaCa = 0F;
            Integer cdId  = 0;
            Integer ivaId = 0;
            Integer estId = 0;
            String cdDesc;
            String estado;
            double importeTotal;

            SimpleDateFormat formatoFecha = new SimpleDateFormat("dd/MM/yyyy");
            String fecha;

            if(lPresupuesto != null){
                for (it = lPresupuesto.iterator(); it.hasNext();) {
                    fila = new Object[10];
                    p = (Presupuesto) it.next();

                    cdId = p.getClase_documento().getIid();
                    if(listaCD.containsKey(cdId)){
                        cdDesc = listaCD.get(cdId);
                    } else {
                        cd = BaseDatos.getClaseDocumentosByIid(cdId);
                        listaCD.put(cdId, cd.getDescripcion());
                        cdDesc  = cd.getDescripcion();
                    }

                    ivaId = p.getIva().getIid();
                    if(listaIva.containsKey(ivaId)){
                        ivaCa = listaIva.get(ivaId);
                    } else {
                        iva = BaseDatos.obtenerIvaPorIid(ivaId);
                        listaIva.put(ivaId, iva.getPorcentaje());
                        ivaCa  = iva.getPorcentaje();
                    }

                    estId = p.getEstado().getIid();
                    if(listaEst.containsKey(estId)){
                        estado = listaEst.get(estId);
                    } else {
                        es = BaseDatos.obtenerEstadoPorIid(estId);
                        listaEst.put(estId, es.getDescripcion());
                        estado  = es.getDescripcion();
                    }

                    fecha = formatoFecha.format( new Date(p.getFecha()));

                    fila[0] = cdDesc;
                    fila[1] = p.getNumero();
                    fila[2] = p.getSerie();
                    fila[3] = fecha;
                    importeTotal = matematico.Matematico.redondear2decimales(100 * p.getImporte_total() / (ivaCa + 100));
                    fila[4] = Util.convertirPuntoAComa(String.valueOf(importeTotal));
                    fila[5] = estado;
                    fila[6] = p.getPagado();
                    fila[7] = p.getPagadoComercial();
                    fila[8] = Util.convertirPuntoAComa(String.valueOf(p.getPorcentajeComercial()));
                    fila[9] = Util.convertirPuntoAComa(String.valueOf(matematico.Matematico.redondear2decimales(p.getPorcentajeComercial() * importeTotal / 100)));
                    modelo.addRow(fila);
                }
            }
        }
        tDocumentos.getColumnModel().getColumn(0).setPreferredWidth(100);
        tDocumentos.getColumnModel().getColumn(1).setPreferredWidth(60);
        tDocumentos.getColumnModel().getColumn(2).setPreferredWidth(85);
        tDocumentos.getColumnModel().getColumn(3).setPreferredWidth(70);
        tDocumentos.getColumnModel().getColumn(4).setPreferredWidth(70);
        tDocumentos.getColumnModel().getColumn(5).setPreferredWidth(130);
        tDocumentos.getColumnModel().getColumn(6).setPreferredWidth(115);
        tDocumentos.getColumnModel().getColumn(7).setPreferredWidth(100);
        tDocumentos.getColumnModel().getColumn(8).setPreferredWidth(100);
        tDocumentos.getColumnModel().getColumn(9).setPreferredWidth(60);
        tDocumentos.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        tDocumentos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tDocumentosMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tDocumentos);

        org.jdesktop.layout.GroupLayout pListaLayout = new org.jdesktop.layout.GroupLayout(pLista);
        pLista.setLayout(pListaLayout);
        pListaLayout.setHorizontalGroup(
            pListaLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(pListaLayout.createSequentialGroup()
                .add(jScrollPane1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 899, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        pListaLayout.setVerticalGroup(
            pListaLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jScrollPane1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 185, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
        );

        lPorcentaje.setText("Porcentaje");

        tPorcentaje.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tPorcentajeKeyReleased(evt);
            }
        });

        tfax.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tfaxKeyReleased(evt);
            }
        });

        tmail.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tmailKeyReleased(evt);
            }
        });

        org.jdesktop.layout.GroupLayout pGeneralLayout = new org.jdesktop.layout.GroupLayout(pGeneral);
        pGeneral.setLayout(pGeneralLayout);
        pGeneralLayout.setHorizontalGroup(
            pGeneralLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(pGeneralLayout.createSequentialGroup()
                .addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .add(pGeneralLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(pLista, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(jSeparator1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 776, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(pGeneralLayout.createSequentialGroup()
                        .add(pGeneralLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(lpais)
                            .add(lprovincia)
                            .add(lpoblacion)
                            .add(lcp)
                            .add(ldireccion, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 64, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(pGeneralLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                            .add(tcp)
                            .add(tpais)
                            .add(tprovincia)
                            .add(tpoblacion, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 221, Short.MAX_VALUE)
                            .add(tdireccion))
                        .add(11, 11, 11)
                        .add(pGeneralLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                            .add(pGeneralLayout.createSequentialGroup()
                                .add(ltelefono, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 50, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                .add(ttlf))
                            .add(lPorcentaje, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 54, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(pGeneralLayout.createSequentialGroup()
                                .add(pGeneralLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                                    .add(pGeneralLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING, false)
                                        .add(org.jdesktop.layout.GroupLayout.LEADING, lfax, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .add(org.jdesktop.layout.GroupLayout.LEADING, ltelefono2))
                                    .add(lmail))
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                .add(pGeneralLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                                    .add(tmail, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 141, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                    .add(tfax, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 141, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                    .add(tPorcentaje, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 33, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                    .add(ttlf2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 141, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))))
                    .add(pGeneralLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING, false)
                        .add(org.jdesktop.layout.GroupLayout.LEADING, pGeneralLayout.createSequentialGroup()
                            .add(lcodigo)
                            .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                            .add(tCodigo))
                        .add(org.jdesktop.layout.GroupLayout.LEADING, pGeneralLayout.createSequentialGroup()
                            .add(pGeneralLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                                .add(lNombre)
                                .add(lNif))
                            .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                            .add(pGeneralLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING, false)
                                .add(org.jdesktop.layout.GroupLayout.LEADING, tNif)
                                .add(org.jdesktop.layout.GroupLayout.LEADING, tNombre, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 203, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))))))
        );
        pGeneralLayout.setVerticalGroup(
            pGeneralLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(pGeneralLayout.createSequentialGroup()
                .addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .add(pGeneralLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(lcodigo)
                    .add(tCodigo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(pGeneralLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(lNombre)
                    .add(tNombre, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(pGeneralLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(lNif)
                    .add(tNif, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jSeparator1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(pGeneralLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(lpais)
                    .add(tpais, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(ltelefono)
                    .add(ttlf, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(pGeneralLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(lprovincia)
                    .add(tprovincia, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(ltelefono2)
                    .add(ttlf2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(pGeneralLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(lpoblacion)
                    .add(tpoblacion, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(lfax)
                    .add(tfax, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(pGeneralLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(ldireccion)
                    .add(lmail)
                    .add(tmail, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(tdireccion, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .add(pGeneralLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(pGeneralLayout.createSequentialGroup()
                        .add(11, 11, 11)
                        .add(lcp))
                    .add(pGeneralLayout.createSequentialGroup()
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(pGeneralLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(lPorcentaje)
                            .add(tcp, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(tPorcentaje, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(pLista, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
        );

        jScrollPane2.setViewportView(pGeneral);

        org.jdesktop.layout.GroupLayout layout = new org.jdesktop.layout.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(layout.createSequentialGroup()
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                    .add(layout.createSequentialGroup()
                        .add(bImprimir, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 95, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(bAceptar)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(bModificar, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 103, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(bCancelar))
                    .add(jScrollPane2, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 943, Short.MAX_VALUE))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(layout.createSequentialGroup()
                .add(jScrollPane2, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 470, Short.MAX_VALUE)
                .add(18, 18, 18)
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(bCancelar)
                    .add(bModificar)
                    .add(bAceptar)
                    .add(bImprimir))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

private void bModificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bModificarActionPerformed
    if (bModificar.getText().equals("Modificar")) {
        //Si el botón tiene el texto Modificar
        tCodigo.setEnabled(true);
        tNombre.setEnabled(true);
        tNif.setEnabled(true);
        tpais.setEnabled(true);
        tprovincia.setEnabled(true);
        tpoblacion.setEnabled(true);
        tdireccion.setEnabled(true);
        tcp.setEnabled(true);
        ttlf.setEnabled(true);
        ttlf2.setEnabled(true);
        tmail.setEnabled(true);
        tfax.setEnabled(true);
        tPorcentaje.setEnabled(true);
        bModificar.setText("Visualizar");
        bModificar.setToolTipText("Visualizar campos");
    } else {
        //si el botón tiene el texto Visualizar
        tCodigo.setEnabled(false);
        tNombre.setEnabled(false);
        tNif.setEnabled(false);
        tpais.setEnabled(false);
        tprovincia.setEnabled(false);
        tpoblacion.setEnabled(false);
        tdireccion.setEnabled(false);
        tcp.setEnabled(false);
        ttlf.setEnabled(false);
        ttlf2.setEnabled(false);
        tmail.setEnabled(false);
        tfax.setEnabled(false);
        tPorcentaje.setEnabled(false);
        bModificar.setText("Modificar");
        bModificar.setToolTipText("Modificar campos");
    }
}//GEN-LAST:event_bModificarActionPerformed

private void bAceptarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bAceptarActionPerformed
    String nombre = tNombre.getText();
    String codigo = tCodigo.getText();
    String nif = tNif.getText();
    String porcentaje = tPorcentaje.getText();

    if (codigo != null && codigo.length() > 0
            && nif != null && nif.length() > 0
            && nombre != null && nombre.length() > 0
            && porcentaje != null && porcentaje.length() > 0) {

        try {
            if (Util.isNifNie(nif)) {
                c.setCodigo(codigo);
                c.setDireccion(tdireccion.getText());
                c.setEmail(tmail.getText());
                c.setFax(tfax.getText());
                c.setNif(nif);
                c.setNombre(nombre);
                c.setPais(tpais.getText());
                c.setPoblacion(tpoblacion.getText());
                c.setProvincia(tprovincia.getText());
                c.setTelefono(ttlf.getText());
                c.setTelefono2(ttlf2.getText());
                c.setPorcentaje(Float.parseFloat(porcentaje.replaceAll(",", ".")));

                if (tcp.getText() != null && tcp.getText().length() > 0) {
                    int intCodigoPostal = Integer.parseInt(tcp.getText());
                    c.setCodigoPostal(tcp.getText());
                }

                Comercial cTemp = BaseDatos.obtenerComercialPorCodigo(codigo);

                if (crear) {
                    if (cTemp != null) {
                        JOptionPane.showMessageDialog(null, "El Código introducido ya existe", "Error", JOptionPane.ERROR_MESSAGE);
                    } else {

                        if (BaseDatos.insertarElemento(c)) {
                            cerrarComercial();
                        } else {
                            JOptionPane.showMessageDialog(null, "No se puede ha podido insertar el elemento", "Error", JOptionPane.ERROR_MESSAGE);
                        }
                    }
                } else {
                    if (!codigoAntiguo.equals(tCodigo.getText()) && cTemp != null) {
                        JOptionPane.showMessageDialog(null, "El Código introducido ya existe", "Error", JOptionPane.ERROR_MESSAGE);
                    } else {
                        int hacerCambios = 1;
                        if (hayCambios()) {
                            hacerCambios = JOptionPane.showConfirmDialog(null, "Está seguro de que desea realizar los cambios?", "¿Realizar cambios?", JOptionPane.YES_NO_OPTION);
                            //hacerCambios = -1 ==> se ha pulsado la "x" de cancelar;
                            //hacerCambios =  0 ==> se ha pulsado el "sí"
                            //hacerCambios =  1 ==> se ha pulsado el "no"
                            if (hacerCambios == 0) {
                                if (BaseDatos.modificarElemento(c)) {
                                    cerrarComercial();
                                } else {
                                    JOptionPane.showMessageDialog(null, "No se puede ha podido modificar el elemento", "Error", JOptionPane.ERROR_MESSAGE);
                                }
                            }
                        } else {
                            JOptionPane.showMessageDialog(null, "No hay cambios que realizar", "Sin cambios", JOptionPane.ERROR_MESSAGE);
                        }
                    }
                }
            } else {
                JOptionPane.showMessageDialog(null, "El NIF introducido es incorrecto", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException e1) {
            JOptionPane.showMessageDialog(null, "El campo Código Postal y Porcentaje deben ser numéricos", "Error", JOptionPane.ERROR_MESSAGE);
        }
    } else {
        JOptionPane.showMessageDialog(null, "Debe rellenar el Código, Nombre, Porcentaje y NIF", "Error", JOptionPane.ERROR_MESSAGE);
    }
}//GEN-LAST:event_bAceptarActionPerformed

private void bCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bCancelarActionPerformed
    this.setVisible(false);
}//GEN-LAST:event_bCancelarActionPerformed

private void tDocumentosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tDocumentosMouseClicked

    if (evt.getClickCount() == 2) {
        imprimir();
    } else {
        int columna = tDocumentos.columnAtPoint(evt.getPoint());
        if (columna == 7) {
            int fila = tDocumentos.rowAtPoint(evt.getPoint());
            if (fila > -1) {
                boolean pagadoComercial = (Boolean) tDocumentos.getModel().getValueAt(fila, columna);
                String mensaje = "";
                if (pagadoComercial) {
                    mensaje = "¿Está seguro de dar por pagado el documento al comercial?";
                } else {
                    mensaje = "¿Está seguro de dar por no pagado el documento al comercial?";
                }

                int confirmar = JOptionPane.showConfirmDialog(null, mensaje, "¿Está seguro?", JOptionPane.YES_NO_OPTION);
                //confirmar = -1 ==> se ha pulsado la "x" de cancelar;
                //confirmar =  0 ==> se ha pulsado el "sí"
                //confirmar =  1 ==> se ha pulsado el "no"

                if (confirmar == 0) {
                    String numeroDocumento = (String) tDocumentos.getValueAt(fila, 1);
                    if (!BaseDatos.documentoActualizarPagoComercial(numeroDocumento, pagadoComercial)) {
                        tDocumentos.getModel().setValueAt(!pagadoComercial, fila, columna);
                    }
                } else {
                    tDocumentos.getModel().setValueAt(!pagadoComercial, fila, columna);
                }
            }
        }
    }
}//GEN-LAST:event_tDocumentosMouseClicked

    private void imprimir() {
        int indiceFila = this.tDocumentos.getSelectedRow();
        if (indiceFila > -1) {
            String numero    = (String) tDocumentos.getModel().getValueAt(indiceFila, 1);
            String documento = (String) tDocumentos.getModel().getValueAt(indiceFila, 0);
                     
            ClaseDocumento cd = BaseDatos.getClaseDocumentosByDescripcion(documento);
            Presupuesto p = BaseDatos.obtenerPresupuestoPorNumero(numero,e.getIid(),cd.getIid());
            Empresa e1 = BaseDatos.obtenerEmpresaPorIid(p.getEmpresa().getIid());
            
            HashMap parameters = new HashMap();
            
            SimpleDateFormat formatoFecha = new SimpleDateFormat("dd/MM/yyyy");
            String fecha = formatoFecha.format( new Date(p.getFecha()));

            parameters.put("e.cod_empresa", e1.getCod_empresa());
            parameters.put("e.desc_empresa", e1.getDesc_empresa());
            parameters.put("e.dire_empresa", e1.getDire_empresa());
            parameters.put("e.pobla_empresa", e1.getPobla_empresa());
            parameters.put("e.cp_empresa", e1.getCp_empresa());
            parameters.put("tipoDocumento", cd.getDescripcion());

            parameters.put("c.codigo", c.getNombre());
            parameters.put("c.dni", c.getNif());
            parameters.put("c.nombreComercial", c.getNombre());
            parameters.put("c.direccion", c.getDireccion());
            parameters.put("c.cp", c.getCodigoPostal());
            parameters.put("c.poblacion", c.getPoblacion());
            parameters.put("c.provincia", c.getProvincia());
            parameters.put("c.telefono", c.getTelefono());
            //}
            parameters.put("logo", new ByteArrayInputStream(e1.getImagen()));
            parameters.put("referencia", p.getReferencia());
            parameters.put("numero", p.getNumero());
            parameters.put("fecha", fecha);


            List<LineaPresupuesto> listaProducto = new ArrayList<LineaPresupuesto>();
            Articulo a;
            List listaArticulos = BaseDatos.getListaLineaPresupuesto(p.getIid());
            LineaPresupuesto lip;
            Iterator it = listaArticulos.iterator();
            double precio_total = 0;
            NuevaLineaPresupuesto nlip;
            while (it.hasNext()) {
                lip = (LineaPresupuesto) it.next();
                a = lip.getArticulo_iid();
                if (a != null) {
                    precio_total += lip.getPrecio();
                }
            }
            parameters.put("lineaPresupuesto", new JRBeanCollectionDataSource(listaArticulos));
            FormaPago2 fp = BaseDatos.obtenerFormaPago2(p.getFp().getIid());
            List<Objeto2Elementos> lista = fp.getPlazos();
            parameters.put("formaPago", new JRBeanCollectionDataSource(lista));
            parameters.put("formaPagoStr", fp.getCodigo());

            HashMap hashPrecio = new HashMap();

            double importe_total = precio_total;

            double precio_aux = importe_total * ((100 - Double.parseDouble(String.valueOf(p.getDto()))) / 100);
            precio_aux = matematico.Matematico.redondear2decimales(precio_aux);
            double importe_total_dto = precio_aux;
            
            Iva iva = BaseDatos.obtenerIvaPorIid(p.getIva().getIid());

            double precio_final = importe_total_dto * (100 + Double.parseDouble(iva.getPorcentaje().toString())) / 100;
            precio_final = matematico.Matematico.redondear2decimales(precio_final);

            double precioComercial = matematico.Matematico.redondear2decimales(p.getPorcentajeComercial() * precio_aux / 100);
            hashPrecio.put("precio_bruto", Util.convertirPuntoAComa(String.valueOf(precio_aux)));
            hashPrecio.put("precio_final", Util.convertirPuntoAComa(String.valueOf(precioComercial)));

            parameters.put("hashPrecio", hashPrecio);
            parameters.put("precio_bruto", Util.convertirPuntoAComa(String.valueOf(precio_aux)));
            parameters.put("precio_final", Util.convertirPuntoAComa(String.valueOf(precioComercial)));

            InformeComercial.imprimirPresupuesto(parameters);

        } else {
            JOptionPane.showMessageDialog(null, "No hay seleccionado ningún elemento", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
private void bImprimirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bImprimirActionPerformed
    imprimir();
}//GEN-LAST:event_bImprimirActionPerformed

private void tPorcentajeKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tPorcentajeKeyReleased
    int tamaño = tPorcentaje.getText().length();
    if (tamaño > 0) {
        char ca = tPorcentaje.getText().charAt(tamaño - 1);

        if (ca == '.') {
            String contenidoAntiguo = tPorcentaje.getText().replace(".", ",");
            tPorcentaje.setText(contenidoAntiguo);
            ca = ',';
        }

        if (!((ca >= '0' && ca <= '9') || ca == ',')) {
            String str = tPorcentaje.getText().substring(0, tamaño - 1);
            tPorcentaje.setText(str);
        } else if (ca == ',') {
            int indicePunto = tPorcentaje.getText().indexOf(',');
            if (indicePunto != (tamaño - 1)) {
                String str = tPorcentaje.getText().substring(0, tamaño - 1);
                tPorcentaje.setText(str);
            }
        }
    }
}//GEN-LAST:event_tPorcentajeKeyReleased

private void tCodigoKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tCodigoKeyReleased
    String descripcion =  tCodigo.getText();
    if (descripcion.length() > Constantes.TAM_CODIGO_COMERCIAL) {
        JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_CODIGO_COMERCIAL, "Error", JOptionPane.ERROR_MESSAGE);
         tCodigo.setText(descripcion.substring(0, Constantes.TAM_CODIGO_COMERCIAL));
    }
}//GEN-LAST:event_tCodigoKeyReleased

private void tNombreKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tNombreKeyReleased
    String descripcion = tNombre.getText();
    if (descripcion.length() > Constantes.TAM_NOMBRE_COMERCIAL) {
        JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_NOMBRE_COMERCIAL, "Error", JOptionPane.ERROR_MESSAGE);
        tNombre.setText(descripcion.substring(0, Constantes.TAM_NOMBRE_COMERCIAL));
    }
}//GEN-LAST:event_tNombreKeyReleased

private void tNifKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tNifKeyReleased
    String descripcion = tNif.getText();
    if (descripcion.length() > Constantes.TAM_NIF_COMERCIAL) {
        JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_NIF_COMERCIAL, "Error", JOptionPane.ERROR_MESSAGE);
        tNif.setText(descripcion.substring(0, Constantes.TAM_NIF_COMERCIAL));
    }
}//GEN-LAST:event_tNifKeyReleased

private void tpaisKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tpaisKeyReleased
    String descripcion = tpais.getText();
    if (descripcion.length() > Constantes.TAM_PAIS_COMERCIAL) {
        JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_PAIS_COMERCIAL, "Error", JOptionPane.ERROR_MESSAGE);
        tpais.setText(descripcion.substring(0, Constantes.TAM_PAIS_COMERCIAL));
    }
}//GEN-LAST:event_tpaisKeyReleased

private void tprovinciaKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tprovinciaKeyReleased
    String descripcion = tprovincia.getText();
    if (descripcion.length() > Constantes.TAM_PROVINCIA_COMERCIAL) {
        JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_PROVINCIA_COMERCIAL, "Error", JOptionPane.ERROR_MESSAGE);
        tprovincia.setText(descripcion.substring(0, Constantes.TAM_PROVINCIA_COMERCIAL));
    }
}//GEN-LAST:event_tprovinciaKeyReleased

private void tpoblacionKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tpoblacionKeyReleased
    String descripcion = tpoblacion.getText();
    if (descripcion.length() > Constantes.TAM_POBLACION_COMERCIAL) {
        JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_POBLACION_COMERCIAL, "Error", JOptionPane.ERROR_MESSAGE);
        tpoblacion.setText(descripcion.substring(0, Constantes.TAM_POBLACION_COMERCIAL));
    }
}//GEN-LAST:event_tpoblacionKeyReleased

private void tdireccionKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tdireccionKeyReleased
    String descripcion = tdireccion.getText();
    if (descripcion.length() > Constantes.TAM_DIRECCION_COMERCIAL) {
        JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_DIRECCION_COMERCIAL, "Error", JOptionPane.ERROR_MESSAGE);
        tdireccion.setText(descripcion.substring(0, Constantes.TAM_DIRECCION_COMERCIAL));
    }
}//GEN-LAST:event_tdireccionKeyReleased

private void tcpKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tcpKeyReleased
    String descripcion = tcp.getText();
    if (descripcion.length() > Constantes.TAM_CP_COMERCIAL) {
        JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_CP_COMERCIAL, "Error", JOptionPane.ERROR_MESSAGE);
        tcp.setText(descripcion.substring(0, Constantes.TAM_CP_COMERCIAL));
    }
}//GEN-LAST:event_tcpKeyReleased

private void ttlfKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_ttlfKeyReleased
    String descripcion = ttlf.getText();
    if (descripcion.length() > Constantes.TAM_TLF_COMERCIAL) {
        JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_TLF_COMERCIAL, "Error", JOptionPane.ERROR_MESSAGE);
        ttlf.setText(descripcion.substring(0, Constantes.TAM_TLF_COMERCIAL));
    }
}//GEN-LAST:event_ttlfKeyReleased

private void ttlf2KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_ttlf2KeyReleased
    String descripcion = ttlf2.getText();
    if (descripcion.length() > Constantes.TAM_TLF2_COMERCIAL) {
        JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_TLF2_COMERCIAL, "Error", JOptionPane.ERROR_MESSAGE);
        ttlf2.setText(descripcion.substring(0, Constantes.TAM_TLF2_COMERCIAL));
    }
}//GEN-LAST:event_ttlf2KeyReleased

private void tfaxKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tfaxKeyReleased
    String descripcion = tfax.getText();
    if (descripcion.length() > Constantes.TAM_FAX_COMERCIAL) {
        JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_FAX_COMERCIAL, "Error", JOptionPane.ERROR_MESSAGE);
        tfax.setText(descripcion.substring(0, Constantes.TAM_FAX_COMERCIAL));
    }
}//GEN-LAST:event_tfaxKeyReleased

private void tmailKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tmailKeyReleased
    String descripcion = tmail.getText();
    if (descripcion.length() > Constantes.TAM_MAIL_COMERCIAL) {
        JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_MAIL_COMERCIAL, "Error", JOptionPane.ERROR_MESSAGE);
        tmail.setText(descripcion.substring(0, Constantes.TAM_MAIL_COMERCIAL));
    }
}//GEN-LAST:event_tmailKeyReleased

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bAceptar;
    private javax.swing.JButton bCancelar;
    private javax.swing.JButton bImprimir;
    private javax.swing.JButton bModificar;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JLabel lNif;
    private javax.swing.JLabel lNombre;
    private javax.swing.JLabel lPorcentaje;
    private javax.swing.JLabel lcodigo;
    private javax.swing.JLabel lcp;
    private javax.swing.JLabel ldireccion;
    private javax.swing.JLabel lfax;
    private javax.swing.JLabel lmail;
    private javax.swing.JLabel lpais;
    private javax.swing.JLabel lpoblacion;
    private javax.swing.JLabel lprovincia;
    private javax.swing.JLabel ltelefono;
    private javax.swing.JLabel ltelefono2;
    private javax.swing.JPanel pGeneral;
    private javax.swing.JPanel pLista;
    private javax.swing.JTextField tCodigo;
    private javax.swing.JTable tDocumentos;
    private javax.swing.JTextField tNif;
    private javax.swing.JTextField tNombre;
    private javax.swing.JTextField tPorcentaje;
    private javax.swing.JTextField tcp;
    private javax.swing.JTextField tdireccion;
    private javax.swing.JTextField tfax;
    private javax.swing.JTextField tmail;
    private javax.swing.JTextField tpais;
    private javax.swing.JTextField tpoblacion;
    private javax.swing.JTextField tprovincia;
    private javax.swing.JTextField ttlf;
    private javax.swing.JTextField ttlf2;
    // End of variables declaration//GEN-END:variables

    private boolean hayCambios() {
        return !tCodigo.getText().equals(codigoAntiguo)
                || !tNombre.getText().equals(nombreAntiguo)
                || !tNif.getText().equals(nifAntiguo)
                || !tpais.getText().equals(paisAntiguo)
                || !tprovincia.getText().equals(provinciaAntigua)
                || !tpoblacion.getText().equals(poblacionAntigua)
                || !tdireccion.getText().equals(direccionAntigua)
                || !tcp.getText().equals(cpAntiguo)
                || !ttlf.getText().equals(tlfAntiguo)
                || !ttlf2.getText().equals(tlf2Antiguo)
                || !tfax.getText().equals(faxAntiguo)
                || !tPorcentaje.getText().equals(porcentajeAntiguo)
                || !tmail.getText().equals(mailAntiguo);
    }
}
