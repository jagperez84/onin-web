package gui;

import acceso.*;
import bean.AgenteArticuloCodigo;
import bean.Articulo;
import bean.Colores;
import bean.Caracteristica;
import bean.Empresa;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.net.URL;
import java.util.Iterator;
import java.util.List;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JOptionPane;
import javax.swing.KeyStroke;
import util.Constantes;
import util.Util;
import bean.Precios;
import java.text.SimpleDateFormat;
import java.util.Date;

public class NuevaCaracteristica extends javax.swing.JFrame {

    private boolean crear;
    private NuevoArticulo nar;
    private Caracteristica car;
    private Articulo ar;
    private Empresa e;
    private String colorAntiguo;
    private String upcAntiguo;
    private String ptcAntiguo;
    private boolean stockMaxAntiguo;
    private boolean stockMinAntiguo;
    private boolean condicionAntigua;
    private String pvpAntiguo;
    private String cantidadStockMinimaAntigua;
    private Precios preAnt = new Precios();
    private String precioIncrementoAntiguo;
    private List<AgenteArticuloCodigo> lAgenteArticuloCodigo;

    public NuevaCaracteristica() {
        initComponents();
    }

    public NuevaCaracteristica(NuevoArticulo nar, String titulo, Articulo ar, Empresa e) {
        super(titulo);
        this.e = e;
        this.ar = ar;
        this.nar = nar;
        crear = true;
        car = new Caracteristica();
        this.initComponents();
        this.tarticulo.setText(ar.getCod_articulo());
        tarticulo.setEnabled(false);
        bModificar.setVisible(false);
        crearIconosBotones();
        crearAcciones();

    }

    public NuevaCaracteristica(NuevoArticulo nar, String titulo, Caracteristica car, List lprecios) {
        super(titulo);
        crear = false;
        this.nar = nar;
        this.car = car;
        this.ar = car.getIid_articulo();
        this.e = car.getIid_empresa();
        this.initComponents();
        tarticulo.setText(car.getIid_articulo().getCod_articulo());
        bstockmax.setSelected(car.getStock_max());
        bstockmin.setSelected(car.getStock_min());
        bCondicion.setSelected(car.getCond_pedir());
        lAgenteArticuloCodigo = BaseDatos.getListaAgenteArticuloCodigo(car.getIid());

        if (lprecios == null || lprecios.size() == 0) {
            preAnt = BaseDatos.obtenerPrecioActivo(e, ar, car.getIid_color().getIid());
        } else if (lprecios.size() != 0) {
            Iterator i = lprecios.iterator();
            Boolean seguir = true;
            while (i.hasNext() && seguir) {
                Precios p = (Precios) i.next();
                if (p.getIid_car().equals(car.getIid_color().getIid())) {
                    //El precio de la caracteristica  
                    preAnt.setIid(p.getIid());
                    preAnt.setIid_art(p.getIid_art());

                    if (p.getIid_car() != null) {
                        preAnt.setIid_car(car.getIid_color().getIid());
                    }
                    if (p.getPtc() != null) {
                        preAnt.setPtc(p.getPtc());
                    }
                    if (p.getPvp() != null) {
                        preAnt.setPvp(p.getPvp());
                    }
                    if (p.getUpc() != null) {
                        preAnt.setUpc(p.getUpc());
                    }
                    if (p.getPi() != null) {
                        preAnt.setPi(p.getPi());
                    }

                    if (p.getFecha() != null) {

                        preAnt.setFecha(p.getFecha());
                    }
                    
                    seguir = false;
                }
            }

        }

        if (preAnt != null && preAnt.getPtc() != null) {
            tPtc.setText(Util.convertirPuntoAComa(String.valueOf(preAnt.getPtc())));
        }
        if (preAnt != null && preAnt.getUpc() != null) {
            tUpc.setText(Util.convertirPuntoAComa(String.valueOf(preAnt.getUpc())));
        }

        if (preAnt != null && preAnt.getPvp() != null) {
            tPvp.setText(Util.convertirPuntoAComa(String.valueOf(preAnt.getPvp())));
        }

        if (preAnt != null && preAnt.getPi() != null) {
            tPrecioIncremento.setText(Util.convertirPuntoAComa(String.valueOf(preAnt.getPi())));
        }

        if (preAnt != null && preAnt.getFecha() != null) {
            Date fecha = new Date(preAnt.getFecha());
            SimpleDateFormat sfecha = new SimpleDateFormat("dd/MM/yyyy");
            tfc.setText(sfecha.format(fecha));
        }

        try{        //Obtener pmc
        Double pmc = BaseDatos.getPMP(ar.getIid(), car.getIid(), e.getIid()); //Sin caracteristica
        if (pmc!=null){
            tPmc.setText(Util.convertirPuntoAComa(String.valueOf(pmc)));
        }

        } catch (Exception ex) {
            ex.printStackTrace();
        }

        tarticulo.setEnabled(false);
        ccolores.setEnabled(false);
        bstockmax.setEnabled(false);
        bstockmin.setEnabled(false);
        bCondicion.setEnabled(false);
        tUpc.setEnabled(false);
        tPtc.setEnabled(false);
        tPvp.setEnabled(false);
        tPrecioIncremento.setEnabled(false);
        tStockMinimo.setEnabled(false);
        bCancelar.setToolTipText("Cancelar la creación del color");
        bAceptar.setToolTipText("Realizar la modificación");
        bModificar.setText("Modificar");
        bModificar.setToolTipText("Modificar campos");
        tarticulo.setText(car.getIid_articulo().getCod_articulo());

        if (bstockmin.isSelected()) {
            tStockMinimo.setText(String.valueOf(car.getCantidad_stock_minimo()));
        }

        colorAntiguo = (String) ccolores.getSelectedItem();
        stockMaxAntiguo = bstockmax.isSelected();
        stockMinAntiguo = bstockmin.isSelected();
        condicionAntigua = bCondicion.isSelected();
        upcAntiguo = tUpc.getText();
        ptcAntiguo = tPtc.getText();
        pvpAntiguo = tPvp.getText();
        precioIncrementoAntiguo = tPrecioIncremento.getText();
        cantidadStockMinimaAntigua = tStockMinimo.getText();

        crearIconosBotones();
        crearAcciones();


    }

    private void crearAcciones() {
        KeyStroke escapeKeyStroke = KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false);
        Action escapeAction = new AbstractAction() {
            public void actionPerformed(ActionEvent e) {
                cerrarCaracteristica();
            }
        };
        getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(escapeKeyStroke, "ESCAPE");
        getRootPane().getActionMap().put("ESCAPE", escapeAction);
    }

    private void cerrarCaracteristica() {
        removeAll();
        dispose();
    }

    private void crearIconosBotones() {
        URL urlCancelar = getClass().getResource("/iconos/cancelar.gif");
        ImageIcon iconoCancelar = new ImageIcon(urlCancelar);
        bCancelar.setIcon(iconoCancelar);

        URL urlAceptar = getClass().getResource("/iconos/guardarYvolver.png");
        ImageIcon iconoAceptar = new ImageIcon(urlAceptar);
        bAceptar.setIcon(iconoAceptar);

        URL urlModificar = getClass().getResource("/iconos/editar.png");
        ImageIcon iconoModificar = new ImageIcon(urlModificar);
        bModificar.setIcon(iconoModificar);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lcolor = new javax.swing.JLabel();
        ccolores = new javax.swing.JComboBox();
        bstockmax = new javax.swing.JCheckBox();
        bstockmin = new javax.swing.JCheckBox();
        bCondicion = new javax.swing.JCheckBox();
        bAceptar = new javax.swing.JButton();
        bCancelar = new javax.swing.JButton();
        larticulo = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        lupc = new javax.swing.JLabel();
        lptc = new javax.swing.JLabel();
        tUpc = new javax.swing.JTextField();
        tPtc = new javax.swing.JTextField();
        jSeparator2 = new javax.swing.JSeparator();
        bModificar = new javax.swing.JButton();
        tarticulo = new javax.swing.JTextField();
        lstockMinimo = new javax.swing.JLabel();
        tStockMinimo = new javax.swing.JTextField();
        lPvp = new javax.swing.JLabel();
        tPvp = new javax.swing.JTextField();
        lPrecioIncremento = new javax.swing.JLabel();
        tPrecioIncremento = new javax.swing.JTextField();
        bPprov = new javax.swing.JButton();
        lupc1 = new javax.swing.JLabel();
        tPmc = new javax.swing.JTextField();
        lupc2 = new javax.swing.JLabel();
        tfc = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        lcolor.setText("Color");

        ccolores.setModel(new javax.swing.DefaultComboBoxModel(new String[] {}));

        bstockmax.setText("Stock Máximo Permitido");

        bstockmin.setText("Stock Mínimo Permitido");
        bstockmin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bstockminActionPerformed(evt);
            }
        });

        bCondicion.setText("Condición Para Pedir");

        bAceptar.setText("Aceptar");
        bAceptar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bAceptarActionPerformed(evt);
            }
        });

        bCancelar.setText("Cancelar");
        bCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bCancelarActionPerformed(evt);
            }
        });

        larticulo.setText("Artículo");

        lupc.setText("UPC");

        lptc.setText("PTC");

        tUpc.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tUpcKeyReleased(evt);
            }
        });

        tPtc.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tPtcKeyReleased(evt);
            }
        });

        jSeparator2.setOrientation(javax.swing.SwingConstants.VERTICAL);

        bModificar.setText("Modificar");
        bModificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bModificarActionPerformed(evt);
            }
        });

        lstockMinimo.setText("Stock Mínimo");

        tStockMinimo.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tStockMinimoKeyReleased(evt);
            }
        });

        lPvp.setText("PVP");

        tPvp.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tPvpKeyReleased(evt);
            }
        });

        lPrecioIncremento.setText("Precio Incremento");

        tPrecioIncremento.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tPrecioIncrementoKeyReleased(evt);
            }
        });

        bPprov.setText("Precios por proveedor");
        bPprov.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bPprovActionPerformed(evt);
            }
        });

        lupc1.setText("PMC");

        tPmc.setEnabled(false);
        tPmc.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tPmcKeyReleased(evt);
            }
        });

        lupc2.setText("FC");

        tfc.setEnabled(false);
        tfc.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tfcKeyReleased(evt);
            }
        });

        org.jdesktop.layout.GroupLayout layout = new org.jdesktop.layout.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(layout.createSequentialGroup()
                .addContainerGap()
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(layout.createSequentialGroup()
                        .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(larticulo)
                            .add(lcolor))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                            .add(tarticulo)
                            .add(ccolores, 0, 205, Short.MAX_VALUE)))
                    .add(layout.createSequentialGroup()
                        .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(layout.createSequentialGroup()
                                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING, false)
                                    .add(org.jdesktop.layout.GroupLayout.LEADING, layout.createSequentialGroup()
                                        .add(lupc)
                                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                        .add(tUpc, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 63, Short.MAX_VALUE))
                                    .add(org.jdesktop.layout.GroupLayout.LEADING, layout.createSequentialGroup()
                                        .add(lptc)
                                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                        .add(tPtc))
                                    .add(org.jdesktop.layout.GroupLayout.LEADING, layout.createSequentialGroup()
                                        .add(lPvp)
                                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                        .add(tPvp)))
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                                    .add(lupc1)
                                    .add(lupc2))
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                                    .add(tfc)
                                    .add(tPmc)))
                            .add(layout.createSequentialGroup()
                                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING, false)
                                    .add(lstockMinimo, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .add(lPrecioIncremento, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                                    .add(tPrecioIncremento, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 54, Short.MAX_VALUE)
                                    .add(tStockMinimo))))
                        .add(24, 24, 24)
                        .add(jSeparator2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(bCondicion)
                            .add(bstockmin)
                            .add(bstockmax))
                        .add(35, 35, 35))
                    .add(jSeparator1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 367, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(org.jdesktop.layout.GroupLayout.TRAILING, layout.createSequentialGroup()
                        .add(bPprov)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .add(bAceptar)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(bModificar)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                        .add(bCancelar, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 77, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(layout.createSequentialGroup()
                .addContainerGap()
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(larticulo)
                    .add(tarticulo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .add(18, 18, 18)
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(lcolor)
                    .add(ccolores, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .add(18, 18, 18)
                .add(jSeparator1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(layout.createSequentialGroup()
                        .add(23, 23, 23)
                        .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                                .add(lupc1)
                                .add(tPmc, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                            .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                                .add(lupc)
                                .add(tUpc, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                                .add(lupc2)
                                .add(tfc, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                            .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                                .add(lptc)
                                .add(tPtc, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(lPvp)
                            .add(tPvp, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(lPrecioIncremento)
                            .add(tPrecioIncremento, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(lstockMinimo)
                            .add(tStockMinimo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                    .add(layout.createSequentialGroup()
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(jSeparator2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 144, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(layout.createSequentialGroup()
                                .add(41, 41, 41)
                                .add(bstockmax)
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                                .add(bstockmin)
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                                .add(bCondicion)))))
                .add(18, 18, 18)
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(bCancelar)
                    .add(bModificar)
                    .add(bPprov)
                    .add(bAceptar))
                .addContainerGap(14, Short.MAX_VALUE))
        );

        List lcolores = BaseDatos.obtenerCodigoColores();
        ccolores.addItem(Constantes.VACIO);
        for (Iterator it = lcolores.iterator(); it.hasNext();) {
            ccolores.addItem((String) it.next());
        }
        if(crear || car.getIid_color() == null){
            ccolores.setSelectedIndex(0);
        }
        else{
            ccolores.setSelectedItem(car.getIid_color().getCod_color());
        }

        pack();
    }// </editor-fold>//GEN-END:initComponents

private void bCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bCancelarActionPerformed
    cerrarCaracteristica();
}//GEN-LAST:event_bCancelarActionPerformed

private void bAceptarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bAceptarActionPerformed

    try {

        if (((String) ccolores.getSelectedItem()).equals((Constantes.VACIO))) {
            //debe seleccionar el color correspondiente a la característica
            JOptionPane.showMessageDialog(null, "Debe seleccionar el color", "Sin cambios", JOptionPane.ERROR_MESSAGE);
        } else {

            Colores c = null;
            car.setIid_empresa(e);
            car.setIid_articulo(ar);

            if (!((String) ccolores.getSelectedItem()).equals(Constantes.VACIO)) {
                c = BaseDatos.obtenerColor((String) ccolores.getSelectedItem());
            }
            car.setIid_color(c);
            
            if (preAnt==null){
                preAnt = new Precios();
            }
            
            if (!tUpc.getText().equals("")) {
                preAnt.setUpc(Float.parseFloat(Util.convertirComaAPunto(tUpc.getText())));
            } else {
                preAnt.setUpc(0F);
            }

            if (!tPtc.getText().equals("")) {
                preAnt.setPtc(Float.parseFloat(Util.convertirComaAPunto(tPtc.getText())));
            } else {
                preAnt.setPtc(0F);
            }

            if (!tPvp.getText().equals("")) {
                preAnt.setPvp(Float.parseFloat(Util.convertirComaAPunto(tPvp.getText())));
            } else {
                preAnt.setPvp(0F);
            }

            if (tPrecioIncremento.getText() != null && !tPrecioIncremento.getText().equals("")) {
                preAnt.setPi(Float.parseFloat(Util.convertirComaAPunto(tPrecioIncremento.getText())));
            } else {
                preAnt.setPi(null);
            }

            preAnt.setIid_empresa(e);
            preAnt.setIid_art(ar);
            preAnt.setIid_car(car.getIid_color().getIid());

            Date fecha = new Date();
            preAnt.setFecha(fecha.getTime());

            car.setCond_pedir(bCondicion.isSelected());
            car.setStock_max(bstockmax.isSelected());
            car.setStock_min(bstockmin.isSelected());

            boolean comprobarCheckStockMinimo = true;
            if (bstockmin.isSelected()) {
                if (tStockMinimo.getText() == null || this.tStockMinimo.getText().equals("")) {
                    //Error, si ha seleccionado StockMinimo debe indicar la cantidad de stock mínimo
                    comprobarCheckStockMinimo = false;
                    JOptionPane.showMessageDialog(null, "Si ha seleccionado Stock Mínimo debe indicar dicha cantidad", "Error", JOptionPane.ERROR_MESSAGE);
                } else {
                    car.setCantidad_stock_minimo(Integer.valueOf(tStockMinimo.getText()));
                }
            }

            if (comprobarCheckStockMinimo) {
                if (crear) {
                    //Creamos el elemento
                    if (nar.insertarCaracteristica(car, preAnt)) {
                        cerrarCaracteristica();
                    }
                } else {
                    int hacerCambios = 1;

                    if (hayCambios()) {
                        hacerCambios = JOptionPane.showConfirmDialog(null, "Está seguro de que desea realizar los cambios?", "¿Realizar cambios?", JOptionPane.YES_NO_OPTION);
                        //hacerCambios = -1 ==> se ha pulsado la "x" de cancelar;
                        //hacerCambios =  0 ==> se ha pulsado el "sí"
                        //hacerCambios =  1 ==> se ha pulsado el "no"
                        if (hacerCambios == 0) {
                            if (nar.modificarCaracteristica(car, preAnt)) {
                                cerrarCaracteristica();
                            }
                        }
                    } else {
                        //no hay cambios que realizar
                        JOptionPane.showMessageDialog(null, "No hay cambios que realizar", "Sin cambios", JOptionPane.ERROR_MESSAGE);
                    }
                }
            }
        }
    } catch (NumberFormatException exc) {
        //Error, los campos numéricos no contienen números
        JOptionPane.showMessageDialog(null, "Los campos \"Upc\" ,\"Pvp\" y  \"Ptc\" deben ser numéricos", "Error", JOptionPane.ERROR_MESSAGE);
    }
}//GEN-LAST:event_bAceptarActionPerformed

private void bModificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bModificarActionPerformed
// TODO add your handling code here:
    if (bModificar.getText().equals("Modificar")) {
        //Si el botón tiene el texto Modificar
        ccolores.setEnabled(true);
        bstockmax.setEnabled(true);
        bstockmin.setEnabled(true);
        if (bstockmin.isSelected()) {
            tStockMinimo.setEnabled(true);
        }
        bCondicion.setEnabled(true);
        tUpc.setEnabled(true);
        tPtc.setEnabled(true);
        tPvp.setEnabled(true);
        tPrecioIncremento.setEnabled(true);
        bModificar.setText("Visualizar");
        bModificar.setToolTipText("Visualizar campos");
        URL urlModificar = getClass().getResource("/iconos/buscar.gif");
        ImageIcon iconoModificar = new ImageIcon(urlModificar);
        bModificar.setIcon(iconoModificar);
    } else {
        //si el botón tiene el texto Visualizar
        ccolores.setEnabled(false);
        bstockmax.setEnabled(false);
        bstockmin.setEnabled(false);
        bCondicion.setEnabled(false);
        tStockMinimo.setEnabled(false);
        tUpc.setEnabled(false);
        tPtc.setEnabled(false);
        tPvp.setEnabled(false);
        tPrecioIncremento.setEnabled(false);
        bModificar.setText("Modificar");
        bModificar.setToolTipText("Modificar campos");
        URL urlModificar = getClass().getResource("/iconos/editar.png");
        ImageIcon iconoModificar = new ImageIcon(urlModificar);
        bModificar.setIcon(iconoModificar);
    }
}//GEN-LAST:event_bModificarActionPerformed

private void bstockminActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bstockminActionPerformed
    if (this.bstockmin.isSelected()) {
        tStockMinimo.setEnabled(true);
    } else {
        tStockMinimo.setEnabled(false);
        tStockMinimo.setText("");
    }
}//GEN-LAST:event_bstockminActionPerformed

private void tUpcKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tUpcKeyReleased
    int tamaño = tUpc.getText().length();
    if (tamaño > 0) {
        char c = tUpc.getText().charAt(tamaño - 1);

        if (c == '.') {
            String contenidoAntiguo = tUpc.getText().replace(".", ",");
            tUpc.setText(contenidoAntiguo);
            c = ',';
        }

        if (!((c >= '0' && c <= '9') || c == ',')) {
            String str = tUpc.getText().substring(0, tamaño - 1);
            tUpc.setText(str);
        } else if (c == ',') {
            int indicePunto = tUpc.getText().indexOf(',');
            if (indicePunto != (tamaño - 1)) {
                String str = tUpc.getText().substring(0, tamaño - 1);
                tUpc.setText(str);
            }
        }
    }
}//GEN-LAST:event_tUpcKeyReleased

private void tPtcKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tPtcKeyReleased
    int tamaño = tPtc.getText().length();
    if (tamaño > 0) {
        char c = tPtc.getText().charAt(tamaño - 1);

        if (c == '.') {
            String contenidoAntiguo = tPtc.getText().replace(".", ",");
            tPtc.setText(contenidoAntiguo);
            c = ',';
        }

        if (!((c >= '0' && c <= '9') || c == ',')) {
            String str = tPtc.getText().substring(0, tamaño - 1);
            tPtc.setText(str);
        } else if (c == ',') {
            int indicePunto = tPtc.getText().indexOf(',');
            if (indicePunto != (tamaño - 1)) {
                String str = tPtc.getText().substring(0, tamaño - 1);
                tPtc.setText(str);
            }
        }
    }
}//GEN-LAST:event_tPtcKeyReleased

private void tPvpKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tPvpKeyReleased
    int tamaño = tPvp.getText().length();
    if (tamaño > 0) {
        char c = tPvp.getText().charAt(tamaño - 1);

        if (c == '.') {
            String contenidoAntiguo = tPvp.getText().replace(".", ",");
            tPvp.setText(contenidoAntiguo);
            c = ',';
        }

        if (!((c >= '0' && c <= '9') || c == ',')) {
            String str = tPvp.getText().substring(0, tamaño - 1);
            tPvp.setText(str);
        } else if (c == ',') {
            int indicePunto = tPvp.getText().indexOf(',');
            if (indicePunto != (tamaño - 1)) {
                String str = tPvp.getText().substring(0, tamaño - 1);
                tPvp.setText(str);
            }
        }
    }
}//GEN-LAST:event_tPvpKeyReleased

private void tStockMinimoKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tStockMinimoKeyReleased
    int tamaño = tStockMinimo.getText().length();
    if (tamaño > 0) {
        char c = tStockMinimo.getText().charAt(tamaño - 1);
        if (!(c >= '0' && c <= '9')) {
            String str = tStockMinimo.getText().substring(0, tamaño - 1);
            tStockMinimo.setText(str);
        }
    }
}//GEN-LAST:event_tStockMinimoKeyReleased

private void tPrecioIncrementoKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tPrecioIncrementoKeyReleased
    int tamaño = tPrecioIncremento.getText().length();
    if (tamaño > 0) {
        char c = tPrecioIncremento.getText().charAt(tamaño - 1);

        if (c == '.') {
            String contenidoAntiguo = tPrecioIncremento.getText().replace(".", ",");
            tPrecioIncremento.setText(contenidoAntiguo);
            c = ',';
        }

        if (!((c >= '0' && c <= '9') || c == ',')) {
            String str = tPrecioIncremento.getText().substring(0, tamaño - 1);
            tPrecioIncremento.setText(str);
        } else if (c == ',') {
            int indicePunto = tPrecioIncremento.getText().indexOf(',');
            if (indicePunto != (tamaño - 1)) {
                String str = tPrecioIncremento.getText().substring(0, tamaño - 1);
                tPrecioIncremento.setText(str);
            }
        }
    }
}//GEN-LAST:event_tPrecioIncrementoKeyReleased

private void bPprovActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bPprovActionPerformed
    /* ListaAgenteCarCodigo laac = new ListaAgenteCarCodigo(ar, this, lAgenteArticuloCodigo,e);
     laac.setDefaultCloseOperation(ListaAgenteArticuloCodigo.DISPOSE_ON_CLOSE);
     laac.setLocationRelativeTo(null);
     laac.setVisible(true);
     laac = null;*/
}//GEN-LAST:event_bPprovActionPerformed

    private void tPmcKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tPmcKeyReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_tPmcKeyReleased

    private void tfcKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tfcKeyReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_tfcKeyReleased

    private boolean hayCambios() {
        return !((String) ccolores.getSelectedItem()).equals(colorAntiguo)
                || !tUpc.getText().equals(upcAntiguo)
                || !tPtc.getText().equals(ptcAntiguo)
                || !stockMaxAntiguo == bstockmax.isSelected()
                || !stockMinAntiguo == bstockmin.isSelected()
                || !condicionAntigua == bCondicion.isSelected()
                || !tPvp.getText().equals(pvpAntiguo)
                || !tPrecioIncremento.getText().equals(precioIncrementoAntiguo)
                || !cantidadStockMinimaAntigua.equals(tStockMinimo.getText());
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bAceptar;
    private javax.swing.JButton bCancelar;
    private javax.swing.JCheckBox bCondicion;
    private javax.swing.JButton bModificar;
    private javax.swing.JButton bPprov;
    private javax.swing.JCheckBox bstockmax;
    private javax.swing.JCheckBox bstockmin;
    private javax.swing.JComboBox ccolores;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JLabel lPrecioIncremento;
    private javax.swing.JLabel lPvp;
    private javax.swing.JLabel larticulo;
    private javax.swing.JLabel lcolor;
    private javax.swing.JLabel lptc;
    private javax.swing.JLabel lstockMinimo;
    private javax.swing.JLabel lupc;
    private javax.swing.JLabel lupc1;
    private javax.swing.JLabel lupc2;
    private javax.swing.JTextField tPmc;
    private javax.swing.JTextField tPrecioIncremento;
    private javax.swing.JTextField tPtc;
    private javax.swing.JTextField tPvp;
    private javax.swing.JTextField tStockMinimo;
    private javax.swing.JTextField tUpc;
    private javax.swing.JTextField tarticulo;
    private javax.swing.JTextField tfc;
    // End of variables declaration//GEN-END:variables
}
