package gui;

import acceso.BaseDatos;
import auxiliar.CorteLona;
import auxiliar.CorteLonaSimulado;
import auxiliar.CortePerfil;
import auxiliar.DesUnidades;
import bean.Dac;
import bean.Empresa;
import bean.Articulo;
import bean.Caracteristica;
import bean.Colores;
import bean.DacPresupuesto;
import bean.Despiece;
import bean.DespiecePresupuesto;
import bean.FamiliaVenta;
import bean.LineaCorteLona;
import bean.LineaCortePerfil;
import bean.LineaPresupuesto;
import bean.MovimientoPresupuesto;
import bean.Seleccion;
import bean.SeleccionPresupuesto;
import bean.TipoControl;
import bean.TipoMedida;
import bean.UnidadMedida;
import bean.Variable;
import bean.VariablePresupuesto;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import javax.swing.JOptionPane;
import modelo.Modelo;
import util.Constantes;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.KeyStroke;
import util.Util;
import java.awt.Color;
import javax.swing.JFrame;
import org.apache.log4j.Logger;

public class RellenarDac extends javax.swing.JFrame {

    private Empresa e;
    private List<Variable> listaVbles;
    private List<Seleccion> listaSeleccion;
    private List<Despiece> listaDespiece;
    private Dac dac;
    private Caracteristica car;
    private NuevaLineaPresupuesto lPresupuesto;
    private Articulo ar;
    private String codigoArticuloAntiguo;
    private boolean verTodos = false;
    private Dac dacBase = null;
    private Double cantidadAntesFoco;
    private Double cantidadDespuesFoco;
    private Double medida1AntesFoco;
    private Double medida1DespuesFoco;
    private Double medida2AntesFoco;
    private Double medida2DespuesFoco;
    private Double medida3AntesFoco;
    private Double medida3DespuesFoco;
    private Double medida4AntesFoco;
    private Double medida4DespuesFoco;
    private Double medida5AntesFoco;
    private Double medida5DespuesFoco;
    private boolean eliminarCortes;
    private boolean actualizarCaracteristicas = false;
    private ScriptEngine engineGlobal;
    private int numMedidasArticuloDac;
    private static Logger log = Logger.getLogger(RellenarDac.class);

    public RellenarDac(DacPresupuesto dp, NuevaLineaPresupuesto nlp, String titulo, Dac dacBase) {
        super(titulo);
        this.lPresupuesto = nlp;
        this.dac = dp.convertToDac();
        this.ar = BaseDatos.obtenerArticuloPorIid(dac.getArticulo().getIid());
        this.e = ar.getIid_empresa();
        this.dacBase = dacBase;

        if (nlp.getCaracteristica() != null) {
            this.car = BaseDatos.obtenerCaracteristicaPorIid(nlp.getCaracteristica().getIid());
        }

        listaVbles = new ArrayList();
        listaSeleccion = new ArrayList();
        listaDespiece = new ArrayList();

        List<VariablePresupuesto> listaV = BaseDatos.getListaVariablePresupuestoByDacPresupuesto(dp.getIid());
        List<SeleccionPresupuesto> listaS = BaseDatos.getListaSeleccionPresupuestoByDacPresupuesto(dp.getIid());
        List<DespiecePresupuesto> listaD = BaseDatos.getListaDespiecePresupuestoByDacPresupuesto(dp.getIid());
        
        if (listaV != null) {
            Iterator<VariablePresupuesto> iterV = listaV.iterator();
            while (iterV.hasNext()) {
                listaVbles.add(iterV.next().clonar());
            }
        }

        if (listaS != null) {
            Iterator<SeleccionPresupuesto> iterS = listaS.iterator();
            while (iterS.hasNext()) {
                listaSeleccion.add(iterS.next().clonar());
            }
        }

        if (listaD != null) {
            Iterator<DespiecePresupuesto> iterD = listaD.iterator();
            while (iterD.hasNext()) {
                listaDespiece.add(iterD.next().clonar());
            }
        }
        
        engineGlobal = new ScriptEngineManager().getEngineByName("js");

        initComponents();
        autoCompletarDatos();
        crearAcciones();
        eliminarCortes = false;
        actualizarCaracteristicas = true;
    }

    public RellenarDac(RellenarDac rdac, NuevoPresupuesto p, String titulo) {
        super(titulo);

        this.e = rdac.getEmpresa();
        this.lPresupuesto = rdac.getLPresupuesto();
        this.dac = rdac.getDacBase();
        this.ar = BaseDatos.obtenerArticuloPorIid(dac.getArticulo().getIid());
        this.car = rdac.getCaracteristica();
        this.dacBase = this.dac;
        listaVbles = rdac.getListaVbles();
        listaSeleccion = rdac.getListaSeleccion();
        listaDespiece = rdac.getListaDespiece();
        engineGlobal = new ScriptEngineManager().getEngineByName("js");

        initComponents();
        autoCompletarDatos();
        crearAcciones();
        eliminarCortes = false;
        cLacado.setSelectedItem(rdac.getStringColorLacado());
        cAccesorios.setSelectedItem(rdac.getStringColorAccesorios());
        actualizarCaracteristicas = true;
    }

    public RellenarDac(NuevaLineaPresupuesto lPresupuesto, Empresa e, Dac dac, Caracteristica car, String titulo) {
        super(titulo);
        this.e = e;
        this.lPresupuesto = lPresupuesto;
        this.dac = dac;
        this.ar = BaseDatos.obtenerArticuloPorIid(dac.getArticulo().getIid());
        this.car = car;
        this.dacBase = dac;
        listaVbles = BaseDatos.getListaVariables(dac.getIid());
        listaSeleccion = BaseDatos.getListaSeleccion(dac.getIid());
        listaDespiece = BaseDatos.getListaDespiece(dac.getIid());
        engineGlobal = new ScriptEngineManager().getEngineByName("js");

        initComponents();
        autoCompletarDatos();
        crearAcciones();
        eliminarCortes = false;
        actualizarCaracteristicas = true;
    }

    void setDacBase(Dac dacBase) {
        this.dacBase = dacBase;
    }

    private void autoCompletarDatos() {
        
        numMedidasArticuloDac = 5;
        codigoArticuloAntiguo = ar.getCod_articulo();

        tCodigo.setText(codigoArticuloAntiguo);
        tDescripcion.setText(ar.getDes_inf());

        bCancelar.setToolTipText("Cancelar");
        bAceptar.setToolTipText("Aceptar");

        tCantidad.setText(Util.convertirPuntoAComa(this.lPresupuesto.getTcantidad()));
        engineGlobal.put("Cantidad", Double.valueOf(Util.convertirComaAPunto(getCantidad())));
        FamiliaVenta fv = BaseDatos.obtenerFamiliaVentaPorIid(ar.getIid_fam_venta().getIid());
        TipoControl tc = BaseDatos.obtenerTipoControlPorIid(fv.getIid_tipo_control().getIid());

        if (tc != null) {
            UnidadMedida um;
            TipoMedida tm = BaseDatos.obtenerTipoMedidaByIid(tc.getIid_tipo_medida().getIid());
            numMedidasArticuloDac = tm.getNum_dimensiones();

            if (tc.getUnidad1() != null) {
                um = BaseDatos.obtenerUnidadMedidaIid(tc.getUnidad1().getIid());
                if (um != null) {
                    lUnidad1.setText(tm.getNombre_dim_1());
                    lMagnitud1.setText(um.getCod_unidad_medida());
                    tMedida1.setText(lPresupuesto.getTMedida1());
                    engineGlobal.put("Dim1", Double.valueOf(Util.convertirComaAPunto(getDim1())));
                }
            } else {
                lUnidad1.setVisible(false);
                lMagnitud1.setVisible(false);
                tMedida1.setVisible(false);
            }
            if (tc.getUnidad2() != null) {
                um = BaseDatos.obtenerUnidadMedidaIid(tc.getUnidad2().getIid());
                if (um != null) {
                    lUnidad2.setText(tm.getNombre_dim_2());
                    lMagnitud2.setText(um.getCod_unidad_medida());
                    tMedida2.setText(lPresupuesto.getTMedida2());
                    engineGlobal.put("Dim2", Double.valueOf(Util.convertirComaAPunto(getDim2())));
                }
            } else {
                lUnidad2.setVisible(false);
                lMagnitud2.setVisible(false);
                tMedida2.setVisible(false);
            }
            if (tc.getUnidad3() != null) {
                um = BaseDatos.obtenerUnidadMedidaIid(tc.getUnidad3().getIid());
                if (um != null) {
                    lUnidad3.setText(tm.getNombre_dim_3());
                    lMagnitud3.setText(um.getCod_unidad_medida());
                    tMedida3.setText(lPresupuesto.getTMedida3());
                    engineGlobal.put("Dim3", Double.valueOf(Util.convertirComaAPunto(getDim3())));
                }
            } else {
                lUnidad3.setVisible(false);
                lMagnitud3.setVisible(false);
                tMedida3.setVisible(false);
            }
            if (tc.getUnidad4() != null) {
                um = BaseDatos.obtenerUnidadMedidaIid(tc.getUnidad4().getIid());
                if (um != null) {
                    lUnidad4.setText(tm.getNombre_dim_4());
                    lMagnitud4.setText(um.getCod_unidad_medida());
                    tMedida4.setText(lPresupuesto.getTMedida4());
                    engineGlobal.put("Dim4", Double.valueOf(Util.convertirComaAPunto(getDim4())));
                }
            } else {
                lUnidad4.setVisible(false);
                lMagnitud4.setVisible(false);
                tMedida4.setVisible(false);
            }
            if (tc.getUnidad5() != null) {
                um = BaseDatos.obtenerUnidadMedidaIid(tc.getUnidad5().getIid());
                if (um != null) {
                    lUnidad5.setText(tm.getNombre_dim_5());
                    lMagnitud5.setText(um.getCod_unidad_medida());
                    tMedida5.setText(lPresupuesto.getTMedida5());
                    engineGlobal.put("Dim5", Double.valueOf(Util.convertirComaAPunto(getDim5())));
                }
            } else {
                lUnidad5.setVisible(false);
                lMagnitud5.setVisible(false);
                tMedida5.setVisible(false);
            }
        }

        if (dacBase.getTipoPlantilla().equals(Constantes.PLANTILLA_TOLDO_ENRROLLADO)) {
            this.panelesToldos.remove(1);
        } else if (dacBase.getTipoPlantilla().equals(Constantes.PLANTILLA_TOLDO_GENERAL)) {
            this.panelesToldos.remove(1);
            this.panelesToldos.remove(0);
            this.panelesToldos.add("Toldo General", pDespiece);
        } else {
            this.panelesToldos.remove(0);
        }

        rellenarCombosColores();

        if (dac.getDescripcion() != null) {
            tDescripcionDac.setText(dac.getDescripcion());
        }

        Colores temp;
        if (dac.getClacado() != null) {
            temp = BaseDatos.obtenerColorPorIid(dac.getClacado().getIid());
            if (temp != null) {
                cLacado.setSelectedItem(temp.getDescripcion());
            }
        }
        if (dac.getCaccesorios() != null) {
            temp = BaseDatos.obtenerColorPorIid(dac.getCaccesorios().getIid());
            if (temp != null) {
                cAccesorios.setSelectedItem(temp.getDescripcion());
            }
        }

        iniciarVariables();
        rellenarArticulosDespiece();

        tBrazoIzquierdoArea.setEnabled(false);
        tBrazoDerechoArea.setEnabled(false);
        tTelaArea.setEnabled(false);
        tTelaAreaMedida.setEnabled(false);
        tTuboEnrrolleArea.setEnabled(false);
        tTuboEnrrolleAreaMedida.setEnabled(false);
        tSoporteIzquierdoArea.setEnabled(false);
        tSoporteDerechoArea.setEnabled(false);
        tCasquilloIzquierdoArea.setEnabled(false);
        tCasquilloDerechoArea.setEnabled(false);
        tMaquinaIzquierdaArea.setEnabled(false);
        tMaquinaDerechaArea.setEnabled(false);
        tPerfilArea.setEnabled(false);
        tPerfilAreaMedida.setEnabled(false);
        tTerminalIzquierdoArea.setEnabled(false);
        tTerminalDerechoArea.setEnabled(false);
        tTapaIzquierdaArea.setEnabled(false);
        tTapaDerechaArea.setEnabled(false);
        tBambolinaArea.setEnabled(false);
        tBambolinaAreaMedida.setEnabled(false);
        tPerfilArea.setEnabled(false);
        tPerfilAreaMedida.setEnabled(false);
        tAtacuerdaParedArea.setEnabled(false);
        tManivelaArea.setEnabled(false);
        tCarruchaDobleArea.setEnabled(false);
        tCarruchaSimpleArea.setEnabled(false);
        tPerfilPlanoArea.setEnabled(false);
        tPerfilPlanoAreaMedida.setEnabled(false);
        tGanchoDerechaArea.setEnabled(false);
        tGanchoIzquierdoArea.setEnabled(false);
        tPoleaIzquierdaArea.setEnabled(false);
        tPoleaDerechaArea.setEnabled(false);
        tAtacuerdaArea.setEnabled(false);
        tBambolinaPlanoArea.setEnabled(false);
        tBambolinaPlanoAreaMedida.setEnabled(false);
        tCantidadGuias.setEnabled(false);
        tMedidasGuias.setEnabled(false);
        tPerfilCofreArea.setEnabled(false);
        tPerfilCofreAreaMedida.setEnabled(false);

        if (!dacBase.getPerfilCofre()) {
            bPerfilCofre.setVisible(false);
            tPerfilCofreArea.setBackground(Color.white);
            jScrollPane30.setBorder(null);
        }

        if (!dacBase.getAtacuerda()) {
            bAtacuerda.setVisible(false);
            tAtacuerdaArea.setBackground(Color.white);
            jScrollPane27.setBorder(null);
        }

        if (!dacBase.getAtacuerdaPared()) {
            bCarruchaDoble.setVisible(false);
            tCarruchaDobleArea.setBackground(Color.white);
            jScrollPane21.setBorder(null);
        }
        if (!dacBase.getBambolina()) {
            if (dacBase.getTipoPlantilla().equals(Constantes.PLANTILLA_TOLDO_ENRROLLADO)) {
                tBambolinaAreaMedida.setText(" ");
                bBambolina.setVisible(false);
                tBambolinaArea.setBackground(Color.white);
                jScrollPane15.setBorder(null);
            } else if (dacBase.getTipoPlantilla().equals(Constantes.PLANTILLA_TOLDO_PLANO)) {
                tBambolinaPlanoAreaMedida.setText(" ");
                bBambolinaPlano.setVisible(false);
                tBambolinaPlanoArea.setBackground(Color.white);
                jScrollPane28.setBorder(null);
            }
        }

        if (!dacBase.getTuboEnrrolle()) {
            bTuboEnrrolle.setVisible(false);
            tTuboEnrrolleArea.setBackground(Color.white);
            tTuboEnrrolleAreaMedida.setText(" ");
            jScrollPane6.setBorder(null);
        }

        if (!dacBase.getBrazo()) {
            bBrazo.setVisible(false);
            tBrazoIzquierdoArea.setBackground(Color.white);
            tBrazoDerechoArea.setBackground(Color.white);
            jScrollPane11.setBorder(null);
            jScrollPane12.setBorder(null);
        }

        if (!dacBase.getCarruchaDoble()) {
            bAtacuerdaPared.setVisible(false);
            tAtacuerdaParedArea.setBackground(Color.white);
            jScrollPane20.setBorder(null);
        }

        if (!dacBase.getCarruchaSimple()) {
            bCarruchaSimple.setVisible(false);
            tCarruchaSimpleArea.setBackground(Color.white);
            jScrollPane29.setBorder(null);
        }

        if (!dacBase.getCasquillo()) {
            bCasquillo.setVisible(false);
            tCasquilloIzquierdoArea.setBackground(Color.white);
            tCasquilloDerechoArea.setBackground(Color.white);
            jScrollPane5.setBorder(null);
            jScrollPane7.setBorder(null);
        }

        if (!dacBase.getGancho()) {
            bGancho.setVisible(false);
            tGanchoIzquierdoArea.setBackground(Color.white);
            tGanchoDerechaArea.setBackground(Color.white);
            jScrollPane23.setBorder(null);
            jScrollPane24.setBorder(null);
        }

        if (!dacBase.getLona()) {
            bLona.setVisible(false);
            tTelaArea.setBackground(Color.white);
            tTelaAreaMedida.setText(" ");
            jScrollPane13.setBorder(null);
        }

        if (!dacBase.getManivela()) {
            bManivela.setVisible(false);
            tManivelaArea.setBackground(Color.white);
            jScrollPane10.setBorder(null);
        }

        if (!dacBase.getMaquina()) {
            bMaquina.setVisible(false);
            tMaquinaIzquierdaArea.setBackground(Color.white);
            tMaquinaDerechaArea.setBackground(Color.white);
            jScrollPane4.setBorder(null);
            jScrollPane8.setBorder(null);
        }

        if (!dacBase.getPerfil()) {
            if (dacBase.getTipoPlantilla().equals(Constantes.PLANTILLA_TOLDO_ENRROLLADO)) {
                tPerfilAreaMedida.setText(" ");
                bPerfil.setVisible(false);
                tPerfilArea.setBackground(Color.white);
                jScrollPane14.setBorder(null);
            } else if (dacBase.getTipoPlantilla().equals(Constantes.PLANTILLA_TOLDO_PLANO)) {
                tPerfilPlanoAreaMedida.setText(" ");
                bPerfilPlano.setVisible(false);
                tPerfilPlanoArea.setBackground(Color.white);
                jScrollPane22.setBorder(null);
            }
        }

        if (!dacBase.getPoleaDerecha()) {
            bPoleaDerecha.setVisible(false);
            tPoleaDerechaArea.setBackground(Color.white);
            jScrollPane26.setBorder(null);
        }

        if (!dacBase.getPoleaIzquierda()) {
            bPoleaIzquierda.setVisible(false);
            tPoleaIzquierdaArea.setBackground(Color.white);
            jScrollPane25.setBorder(null);
        }

        if (!dacBase.getSoporte()) {
            bSoporte.setVisible(false);
            tSoporteIzquierdoArea.setBackground(Color.white);
            tSoporteDerechoArea.setBackground(Color.white);
            jScrollPane3.setBorder(null);
            jScrollPane9.setBorder(null);
        }

        if (!dacBase.getTapa()) {
            bTapa.setVisible(false);
            tTapaIzquierdaArea.setBackground(Color.white);
            tTapaDerechaArea.setBackground(Color.white);
            jScrollPane17.setBorder(null);
            jScrollPane18.setBorder(null);
        }

        if (!dacBase.getTerminal()) {
            bTerminal.setVisible(false);
            tTerminalIzquierdoArea.setBackground(Color.white);
            tTerminalDerechoArea.setBackground(Color.white);
            jScrollPane16.setBorder(null);
            jScrollPane19.setBorder(null);
        }

        actualizarListaDespiece();
        crearIconosBotones();
        this.panelFondoToldoEnrrollado.setSize(400, 400);
        this.pack();
    }

    private void crearAcciones() {
        KeyStroke escapeKeyStroke = KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false);
        Action escapeAction = new AbstractAction() {

            public void actionPerformed(ActionEvent e) {
                cerrarDac();
            }
        };
        getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(escapeKeyStroke, "ESCAPE");
        getRootPane().getActionMap().put("ESCAPE", escapeAction);
    }

    private void configurar(JFrame frame) {
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    private void cerrarDac() {
        removeAll();
        dispose();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        bAceptar = new javax.swing.JButton();
        bCancelar = new javax.swing.JButton();
        pSeleccionArticulo = new javax.swing.JPanel();
        lCodigo = new javax.swing.JLabel();
        tCodigo = new javax.swing.JTextField();
        lDescripcion = new javax.swing.JLabel();
        tDescripcion = new javax.swing.JTextField();
        tDescripcionDac = new javax.swing.JTextField();
        pMedidas = new javax.swing.JPanel();
        lUnidad1 = new javax.swing.JLabel();
        tMedida1 = new javax.swing.JTextField();
        lUnidad2 = new javax.swing.JLabel();
        tMedida2 = new javax.swing.JTextField();
        lMagnitud1 = new javax.swing.JLabel();
        lMagnitud2 = new javax.swing.JLabel();
        lUnidad3 = new javax.swing.JLabel();
        tMedida3 = new javax.swing.JTextField();
        lMagnitud3 = new javax.swing.JLabel();
        lUnidad4 = new javax.swing.JLabel();
        tMedida4 = new javax.swing.JTextField();
        lMagnitud4 = new javax.swing.JLabel();
        lUnidad5 = new javax.swing.JLabel();
        tMedida5 = new javax.swing.JTextField();
        lMagnitud5 = new javax.swing.JLabel();
        lCantidad = new javax.swing.JLabel();
        tCantidad = new javax.swing.JTextField();
        lMagnitudCantidad = new javax.swing.JLabel();
        pSeleccionArticulo2 = new javax.swing.JPanel();
        lLacado = new javax.swing.JLabel();
        cLacado = new javax.swing.JComboBox();
        lAccesorios = new javax.swing.JLabel();
        cAccesorios = new javax.swing.JComboBox();
        pDespiece = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        modelo.Modelo modeloD = new Modelo();
        tDespiece = new javax.swing.JTable();
        bSubir = new javax.swing.JButton();
        bBajar = new javax.swing.JButton();
        bAñadir = new javax.swing.JButton();
        bInsertar = new javax.swing.JButton();
        bModificarDespiece = new javax.swing.JButton();
        bBorrar = new javax.swing.JButton();
        bVerTodos = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        pVariables = new javax.swing.JPanel();
        panelesToldos = new javax.swing.JTabbedPane();
        String fondoEscogido = "";

        if(dacBase.getTipoPlantilla().equals(Constantes.PLANTILLA_TOLDO_ENRROLLADO)){
            fondoEscogido = "plantillaToldoEnrrollado.GIF";
        } else if (dacBase.getTipoPlantilla().equals(Constantes.PLANTILLA_TOLDO_GENERAL)){
            fondoEscogido = "plantillaToldoGeneral.GIF";
        } else {
            fondoEscogido = "plantillaToldoPlano.GIF";
        }
        panelFondoToldoEnrrollado = new PanelConFondo(new ImageIcon(fondoEscogido).getImage());
        bCasquillo = new javax.swing.JButton();
        bSoporte = new javax.swing.JButton();
        bMaquina = new javax.swing.JButton();
        bTuboEnrrolle = new javax.swing.JButton();
        bManivela = new javax.swing.JButton();
        bBrazo = new javax.swing.JButton();
        bLona = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        tSoporteIzquierdoArea = new javax.swing.JTextArea();
        jScrollPane4 = new javax.swing.JScrollPane();
        tMaquinaIzquierdaArea = new javax.swing.JTextArea();
        jScrollPane5 = new javax.swing.JScrollPane();
        tCasquilloIzquierdoArea = new javax.swing.JTextArea();
        jScrollPane6 = new javax.swing.JScrollPane();
        tTuboEnrrolleArea = new javax.swing.JTextArea();
        jScrollPane7 = new javax.swing.JScrollPane();
        tCasquilloDerechoArea = new javax.swing.JTextArea();
        jScrollPane8 = new javax.swing.JScrollPane();
        tMaquinaDerechaArea = new javax.swing.JTextArea();
        jScrollPane9 = new javax.swing.JScrollPane();
        tSoporteDerechoArea = new javax.swing.JTextArea();
        jScrollPane10 = new javax.swing.JScrollPane();
        tManivelaArea = new javax.swing.JTextArea();
        jScrollPane11 = new javax.swing.JScrollPane();
        tBrazoIzquierdoArea = new javax.swing.JTextArea();
        jScrollPane12 = new javax.swing.JScrollPane();
        tBrazoDerechoArea = new javax.swing.JTextArea();
        jScrollPane13 = new javax.swing.JScrollPane();
        tTelaArea = new javax.swing.JTextArea();
        jScrollPane14 = new javax.swing.JScrollPane();
        tPerfilArea = new javax.swing.JTextArea();
        bPerfil = new javax.swing.JButton();
        jScrollPane15 = new javax.swing.JScrollPane();
        tBambolinaArea = new javax.swing.JTextArea();
        bBambolina = new javax.swing.JButton();
        bTerminal = new javax.swing.JButton();
        jScrollPane16 = new javax.swing.JScrollPane();
        tTerminalIzquierdoArea = new javax.swing.JTextArea();
        bTapa = new javax.swing.JButton();
        jScrollPane17 = new javax.swing.JScrollPane();
        tTapaIzquierdaArea = new javax.swing.JTextArea();
        jScrollPane18 = new javax.swing.JScrollPane();
        tTapaDerechaArea = new javax.swing.JTextArea();
        jScrollPane19 = new javax.swing.JScrollPane();
        tTerminalDerechoArea = new javax.swing.JTextArea();
        tTuboEnrrolleAreaMedida = new javax.swing.JLabel();
        tTelaAreaMedida = new javax.swing.JLabel();
        tPerfilAreaMedida = new javax.swing.JLabel();
        tBambolinaAreaMedida = new javax.swing.JLabel();
        tBambolinaEnrrolladoModelo = new javax.swing.JLabel();
        tBambolinaEnrrolladoRibete = new javax.swing.JLabel();
        tPerfilCofreAreaMedida = new javax.swing.JLabel();
        jScrollPane30 = new javax.swing.JScrollPane();
        tPerfilCofreArea = new javax.swing.JTextArea();
        bPerfilCofre = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        String fondoEscogido2 = "";

        if(dacBase.getTipoPlantilla().equals(Constantes.PLANTILLA_TOLDO_ENRROLLADO)){
            fondoEscogido2 = "plantillaToldoEnrrollado.GIF";
        } else if (dacBase.getTipoPlantilla().equals(Constantes.PLANTILLA_TOLDO_GENERAL)){
            fondoEscogido2 = "plantillaToldoGeneral.GIF";
        } else {
            fondoEscogido2 = "plantillaToldoPlano.GIF";
        }
        panelFondoToldoPlano = new PanelConFondo(new ImageIcon(fondoEscogido2).getImage());
        bAtacuerdaPared = new javax.swing.JButton();
        jScrollPane20 = new javax.swing.JScrollPane();
        tAtacuerdaParedArea = new javax.swing.JTextArea();
        bCarruchaDoble = new javax.swing.JButton();
        jScrollPane21 = new javax.swing.JScrollPane();
        tCarruchaDobleArea = new javax.swing.JTextArea();
        jScrollPane22 = new javax.swing.JScrollPane();
        tPerfilPlanoArea = new javax.swing.JTextArea();
        bPerfilPlano = new javax.swing.JButton();
        tPerfilPlanoAreaMedida = new javax.swing.JLabel();
        bGancho = new javax.swing.JButton();
        jScrollPane23 = new javax.swing.JScrollPane();
        tGanchoIzquierdoArea = new javax.swing.JTextArea();
        jScrollPane24 = new javax.swing.JScrollPane();
        tGanchoDerechaArea = new javax.swing.JTextArea();
        bPoleaIzquierda = new javax.swing.JButton();
        jScrollPane25 = new javax.swing.JScrollPane();
        tPoleaIzquierdaArea = new javax.swing.JTextArea();
        jScrollPane26 = new javax.swing.JScrollPane();
        tPoleaDerechaArea = new javax.swing.JTextArea();
        bPoleaDerecha = new javax.swing.JButton();
        jScrollPane27 = new javax.swing.JScrollPane();
        tAtacuerdaArea = new javax.swing.JTextArea();
        bAtacuerda = new javax.swing.JButton();
        bBambolinaPlano = new javax.swing.JButton();
        jScrollPane28 = new javax.swing.JScrollPane();
        tBambolinaPlanoArea = new javax.swing.JTextArea();
        tBambolinaPlanoAreaMedida = new javax.swing.JLabel();
        jScrollPane29 = new javax.swing.JScrollPane();
        tCarruchaSimpleArea = new javax.swing.JTextArea();
        bCarruchaSimple = new javax.swing.JButton();
        panelMedidaGuias = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        tCantidadGuias = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        tMedidasGuias = new javax.swing.JTextField();
        tBambolinaPlanoRibete = new javax.swing.JLabel();
        tBambolinaPlanoModelo = new javax.swing.JLabel();
        tVV = new javax.swing.JLabel();
        tCantidadPalillos = new javax.swing.JLabel();
        tTipoLona = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        bAceptar.setText("Aceptar");
        bAceptar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bAceptarActionPerformed(evt);
            }
        });

        bCancelar.setText("Cancelar");
        bCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bCancelarActionPerformed(evt);
            }
        });

        pSeleccionArticulo.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.LineBorder(new java.awt.Color(153, 153, 255), 1, true), "Artículo"));

        lCodigo.setText("Codigo");

        tCodigo.setEditable(false);

        lDescripcion.setText("Descripción");

        tDescripcion.setEditable(false);

        tDescripcionDac.setEditable(false);

        org.jdesktop.layout.GroupLayout pSeleccionArticuloLayout = new org.jdesktop.layout.GroupLayout(pSeleccionArticulo);
        pSeleccionArticulo.setLayout(pSeleccionArticuloLayout);
        pSeleccionArticuloLayout.setHorizontalGroup(
            pSeleccionArticuloLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(pSeleccionArticuloLayout.createSequentialGroup()
                .add(pSeleccionArticuloLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(pSeleccionArticuloLayout.createSequentialGroup()
                        .add(lCodigo)
                        .add(35, 35, 35)
                        .add(pSeleccionArticuloLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(tDescripcion, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 368, Short.MAX_VALUE)
                            .add(tCodigo, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 368, Short.MAX_VALUE)))
                    .add(org.jdesktop.layout.GroupLayout.TRAILING, pSeleccionArticuloLayout.createSequentialGroup()
                        .add(4, 4, 4)
                        .add(lDescripcion)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                        .add(tDescripcionDac, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 368, Short.MAX_VALUE)))
                .addContainerGap())
        );
        pSeleccionArticuloLayout.setVerticalGroup(
            pSeleccionArticuloLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(pSeleccionArticuloLayout.createSequentialGroup()
                .add(pSeleccionArticuloLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(lCodigo)
                    .add(tCodigo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(tDescripcion, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .add(pSeleccionArticuloLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(tDescripcionDac, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(lDescripcion)))
        );

        pMedidas.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.LineBorder(new java.awt.Color(153, 153, 255), 1, true), "Medidas"));

        lUnidad1.setText("Unidad1");

        tMedida1.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                tMedida1FocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                tMedida1FocusLost(evt);
            }
        });
        tMedida1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tMedida1KeyReleased(evt);
            }
        });

        lUnidad2.setText("Unidad2");

        tMedida2.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                tMedida2FocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                tMedida2FocusLost(evt);
            }
        });
        tMedida2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tMedida2KeyReleased(evt);
            }
        });

        lMagnitud1.setText("Magnitud1");

        lMagnitud2.setText("Magnitud2");

        lUnidad3.setText("Unidad3");

        tMedida3.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                tMedida3FocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                tMedida3FocusLost(evt);
            }
        });
        tMedida3.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tMedida3KeyReleased(evt);
            }
        });

        lMagnitud3.setText("Magnitud3");

        lUnidad4.setText("Unidad4");

        tMedida4.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                tMedida4FocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                tMedida4FocusLost(evt);
            }
        });
        tMedida4.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tMedida4KeyReleased(evt);
            }
        });

        lMagnitud4.setText("Magnitud4");

        lUnidad5.setText("Unidad5");

        tMedida5.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                tMedida5FocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                tMedida5FocusLost(evt);
            }
        });
        tMedida5.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tMedida5KeyReleased(evt);
            }
        });

        lMagnitud5.setText("Magnitud5");

        lCantidad.setText("Cantidad");

        tCantidad.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                tCantidadFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                tCantidadFocusLost(evt);
            }
        });
        tCantidad.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tCantidadKeyReleased(evt);
            }
        });

        lMagnitudCantidad.setText("ud");

        org.jdesktop.layout.GroupLayout pMedidasLayout = new org.jdesktop.layout.GroupLayout(pMedidas);
        pMedidas.setLayout(pMedidasLayout);
        pMedidasLayout.setHorizontalGroup(
            pMedidasLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(pMedidasLayout.createSequentialGroup()
                .add(pMedidasLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(lCantidad)
                    .add(pMedidasLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING, false)
                        .add(org.jdesktop.layout.GroupLayout.LEADING, lUnidad4, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .add(org.jdesktop.layout.GroupLayout.LEADING, lUnidad5, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .add(pMedidasLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING, false)
                        .add(org.jdesktop.layout.GroupLayout.LEADING, lUnidad3, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .add(org.jdesktop.layout.GroupLayout.LEADING, lUnidad2, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .add(org.jdesktop.layout.GroupLayout.LEADING, lUnidad1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED, 7, Short.MAX_VALUE)
                .add(pMedidasLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING, false)
                    .add(tMedida5)
                    .add(tMedida4)
                    .add(tMedida3)
                    .add(tMedida2)
                    .add(tMedida1)
                    .add(tCantidad, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 77, Short.MAX_VALUE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(pMedidasLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(pMedidasLayout.createSequentialGroup()
                        .add(pMedidasLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(pMedidasLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                                .add(lMagnitud5)
                                .add(lMagnitud4, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 53, Short.MAX_VALUE)
                                .add(lMagnitud3, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 53, Short.MAX_VALUE)
                                .add(lMagnitud2, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 53, Short.MAX_VALUE))
                            .add(lMagnitudCantidad))
                        .add(20, 20, 20))
                    .add(pMedidasLayout.createSequentialGroup()
                        .add(lMagnitud1)
                        .addContainerGap())))
        );
        pMedidasLayout.setVerticalGroup(
            pMedidasLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(pMedidasLayout.createSequentialGroup()
                .add(pMedidasLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(lMagnitudCantidad)
                    .add(lCantidad)
                    .add(tCantidad, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(pMedidasLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(lUnidad1)
                    .add(pMedidasLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                        .add(lMagnitud1)
                        .add(tMedida1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .add(pMedidasLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(lMagnitud2)
                    .add(lUnidad2)
                    .add(tMedida2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(pMedidasLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(lMagnitud3)
                    .add(lUnidad3)
                    .add(tMedida3, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(pMedidasLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(lMagnitud4)
                    .add(lUnidad4)
                    .add(tMedida4, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(pMedidasLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(lMagnitud5)
                    .add(lUnidad5)
                    .add(tMedida5, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        pSeleccionArticulo2.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.LineBorder(new java.awt.Color(153, 153, 255), 1, true), "Colores"));

        lLacado.setText("Lacado");

        cLacado.setModel(new javax.swing.DefaultComboBoxModel(new String[] { }));
        cLacado.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cLacadoActionPerformed(evt);
            }
        });

        lAccesorios.setText("Accesorios");

        cAccesorios.setModel(new javax.swing.DefaultComboBoxModel(new String[] { }));
        cAccesorios.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cAccesoriosActionPerformed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout pSeleccionArticulo2Layout = new org.jdesktop.layout.GroupLayout(pSeleccionArticulo2);
        pSeleccionArticulo2.setLayout(pSeleccionArticulo2Layout);
        pSeleccionArticulo2Layout.setHorizontalGroup(
            pSeleccionArticulo2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(pSeleccionArticulo2Layout.createSequentialGroup()
                .add(pSeleccionArticulo2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(lAccesorios)
                    .add(lLacado, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 48, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(cLacado, 0, 216, Short.MAX_VALUE)
                    .add(cAccesorios, 0, 216, Short.MAX_VALUE))
                .addContainerGap())
        );
        pSeleccionArticulo2Layout.setVerticalGroup(
            pSeleccionArticulo2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(pSeleccionArticulo2Layout.createSequentialGroup()
                .add(lLacado)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(cLacado, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .add(18, 18, 18)
                .add(lAccesorios)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(cAccesorios, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(28, Short.MAX_VALUE))
        );

        pDespiece.setBorder(javax.swing.BorderFactory.createTitledBorder("Despiece"));

        tDespiece.setModel(modeloD);

        //Creamos las columnas
        modeloD.addColumn("Cantidad");
        modeloD.addColumn("Código");
        modeloD.addColumn("Descripción");
        modeloD.addColumn("Medidas");
        tDespiece.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tDespieceMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(tDespiece);

        bSubir.setText("Subir");
        bSubir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bSubirActionPerformed(evt);
            }
        });

        bBajar.setText("Bajar");
        bBajar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bBajarActionPerformed(evt);
            }
        });

        bAñadir.setText("Añadir");
        bAñadir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bAñadirActionPerformed(evt);
            }
        });

        bInsertar.setText("Insertar");
        bInsertar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bInsertarActionPerformed(evt);
            }
        });

        bModificarDespiece.setText("Modificar");
        bModificarDespiece.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bModificarDespieceActionPerformed(evt);
            }
        });

        bBorrar.setText("Borrar");
        bBorrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bBorrarActionPerformed(evt);
            }
        });

        bVerTodos.setText("Ver todos");
        bVerTodos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bVerTodosActionPerformed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout pDespieceLayout = new org.jdesktop.layout.GroupLayout(pDespiece);
        pDespiece.setLayout(pDespieceLayout);
        pDespieceLayout.setHorizontalGroup(
            pDespieceLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, pDespieceLayout.createSequentialGroup()
                .add(jScrollPane2, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 357, Short.MAX_VALUE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(pDespieceLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(bBajar, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 81, Short.MAX_VALUE)
                    .add(bAñadir, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 81, Short.MAX_VALUE)
                    .add(bInsertar, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 81, Short.MAX_VALUE)
                    .add(bModificarDespiece, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 81, Short.MAX_VALUE)
                    .add(bBorrar, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 81, Short.MAX_VALUE)
                    .add(bSubir, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 81, Short.MAX_VALUE)
                    .add(org.jdesktop.layout.GroupLayout.TRAILING, bVerTodos, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 81, Short.MAX_VALUE)))
        );
        pDespieceLayout.setVerticalGroup(
            pDespieceLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(pDespieceLayout.createSequentialGroup()
                .add(bSubir)
                .add(1, 1, 1)
                .add(bBajar)
                .add(1, 1, 1)
                .add(bAñadir)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(bInsertar)
                .add(4, 4, 4)
                .add(bModificarDespiece)
                .add(1, 1, 1)
                .add(bBorrar)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(bVerTodos)
                .addContainerGap())
            .add(org.jdesktop.layout.GroupLayout.TRAILING, jScrollPane2, 0, 0, Short.MAX_VALUE)
        );

        pVariables.setAutoscrolls(true);

        org.jdesktop.layout.GroupLayout pVariablesLayout = new org.jdesktop.layout.GroupLayout(pVariables);
        pVariables.setLayout(pVariablesLayout);
        pVariablesLayout.setHorizontalGroup(
            pVariablesLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(0, 876, Short.MAX_VALUE)
        );
        pVariablesLayout.setVerticalGroup(
            pVariablesLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(0, 264, Short.MAX_VALUE)
        );

        jScrollPane1.setViewportView(pVariables);
        pVariables.getAccessibleContext().setAccessibleParent(jScrollPane2);

        bCasquillo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bCasquilloActionPerformed(evt);
            }
        });

        bSoporte.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bSoporteActionPerformed(evt);
            }
        });

        bMaquina.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bMaquinaActionPerformed(evt);
            }
        });

        bTuboEnrrolle.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bTuboEnrrolleActionPerformed(evt);
            }
        });

        bManivela.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bManivelaActionPerformed(evt);
            }
        });

        bBrazo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bBrazoActionPerformed(evt);
            }
        });

        bLona.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bLonaActionPerformed(evt);
            }
        });

        tSoporteIzquierdoArea.setColumns(20);
        tSoporteIzquierdoArea.setLineWrap(true);
        tSoporteIzquierdoArea.setRows(4);
        jScrollPane3.setViewportView(tSoporteIzquierdoArea);

        tMaquinaIzquierdaArea.setColumns(20);
        tMaquinaIzquierdaArea.setLineWrap(true);
        tMaquinaIzquierdaArea.setRows(4);
        jScrollPane4.setViewportView(tMaquinaIzquierdaArea);

        tCasquilloIzquierdoArea.setColumns(20);
        tCasquilloIzquierdoArea.setLineWrap(true);
        tCasquilloIzquierdoArea.setRows(4);
        jScrollPane5.setViewportView(tCasquilloIzquierdoArea);

        tTuboEnrrolleArea.setColumns(20);
        tTuboEnrrolleArea.setLineWrap(true);
        tTuboEnrrolleArea.setRows(4);
        jScrollPane6.setViewportView(tTuboEnrrolleArea);

        tCasquilloDerechoArea.setColumns(20);
        tCasquilloDerechoArea.setLineWrap(true);
        tCasquilloDerechoArea.setRows(4);
        jScrollPane7.setViewportView(tCasquilloDerechoArea);

        tMaquinaDerechaArea.setColumns(20);
        tMaquinaDerechaArea.setLineWrap(true);
        tMaquinaDerechaArea.setRows(4);
        jScrollPane8.setViewportView(tMaquinaDerechaArea);

        tSoporteDerechoArea.setColumns(20);
        tSoporteDerechoArea.setLineWrap(true);
        tSoporteDerechoArea.setRows(4);
        jScrollPane9.setViewportView(tSoporteDerechoArea);

        tManivelaArea.setColumns(20);
        tManivelaArea.setLineWrap(true);
        tManivelaArea.setRows(4);
        jScrollPane10.setViewportView(tManivelaArea);

        tBrazoIzquierdoArea.setColumns(20);
        tBrazoIzquierdoArea.setLineWrap(true);
        tBrazoIzquierdoArea.setRows(4);
        jScrollPane11.setViewportView(tBrazoIzquierdoArea);

        tBrazoDerechoArea.setColumns(20);
        tBrazoDerechoArea.setLineWrap(true);
        tBrazoDerechoArea.setRows(4);
        jScrollPane12.setViewportView(tBrazoDerechoArea);

        tTelaArea.setColumns(20);
        tTelaArea.setLineWrap(true);
        tTelaArea.setRows(4);
        jScrollPane13.setViewportView(tTelaArea);

        tPerfilArea.setColumns(20);
        tPerfilArea.setLineWrap(true);
        tPerfilArea.setRows(4);
        jScrollPane14.setViewportView(tPerfilArea);

        bPerfil.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bPerfilActionPerformed(evt);
            }
        });

        tBambolinaArea.setColumns(20);
        tBambolinaArea.setLineWrap(true);
        tBambolinaArea.setRows(4);
        jScrollPane15.setViewportView(tBambolinaArea);

        bBambolina.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bBambolinaActionPerformed(evt);
            }
        });

        bTerminal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bTerminalActionPerformed(evt);
            }
        });

        tTerminalIzquierdoArea.setColumns(20);
        tTerminalIzquierdoArea.setLineWrap(true);
        tTerminalIzquierdoArea.setRows(4);
        tTerminalIzquierdoArea.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        jScrollPane16.setViewportView(tTerminalIzquierdoArea);

        bTapa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bTapaActionPerformed(evt);
            }
        });

        tTapaIzquierdaArea.setColumns(20);
        tTapaIzquierdaArea.setLineWrap(true);
        tTapaIzquierdaArea.setRows(4);
        jScrollPane17.setViewportView(tTapaIzquierdaArea);

        tTapaDerechaArea.setColumns(20);
        tTapaDerechaArea.setLineWrap(true);
        tTapaDerechaArea.setRows(4);
        jScrollPane18.setViewportView(tTapaDerechaArea);

        tTerminalDerechoArea.setColumns(20);
        tTerminalDerechoArea.setLineWrap(true);
        tTerminalDerechoArea.setRows(4);
        jScrollPane19.setViewportView(tTerminalDerechoArea);

        tTuboEnrrolleAreaMedida.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        tTuboEnrrolleAreaMedida.setText("   ");

        tTelaAreaMedida.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        tTelaAreaMedida.setText("   ");

        tPerfilAreaMedida.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        tPerfilAreaMedida.setText("   ");

        tBambolinaAreaMedida.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        tBambolinaAreaMedida.setText("   ");

        tBambolinaEnrrolladoModelo.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        tBambolinaEnrrolladoModelo.setText("   ");

        tBambolinaEnrrolladoRibete.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        tBambolinaEnrrolladoRibete.setText("   ");

        tPerfilCofreAreaMedida.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        tPerfilCofreAreaMedida.setText("   ");

        tPerfilCofreArea.setColumns(20);
        tPerfilCofreArea.setLineWrap(true);
        tPerfilCofreArea.setRows(4);
        jScrollPane30.setViewportView(tPerfilCofreArea);

        bPerfilCofre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bPerfilCofreActionPerformed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout panelFondoToldoEnrrolladoLayout = new org.jdesktop.layout.GroupLayout(panelFondoToldoEnrrollado);
        panelFondoToldoEnrrollado.setLayout(panelFondoToldoEnrrolladoLayout);
        panelFondoToldoEnrrolladoLayout.setHorizontalGroup(
            panelFondoToldoEnrrolladoLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(panelFondoToldoEnrrolladoLayout.createSequentialGroup()
                .addContainerGap()
                .add(panelFondoToldoEnrrolladoLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(org.jdesktop.layout.GroupLayout.TRAILING, panelFondoToldoEnrrolladoLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                        .add(panelFondoToldoEnrrolladoLayout.createSequentialGroup()
                            .add(36, 36, 36)
                            .add(panelFondoToldoEnrrolladoLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                                .add(bTerminal, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                .add(jScrollPane16, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 76, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                            .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                            .add(panelFondoToldoEnrrolladoLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                                .add(bTapa, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                .add(jScrollPane17, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 76, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                            .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                            .add(panelFondoToldoEnrrolladoLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                                .add(bPerfil, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                .add(tPerfilAreaMedida, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 186, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                .add(bBambolina, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                .add(jScrollPane15, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 363, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                .add(tBambolinaAreaMedida, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 186, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                .add(jScrollPane14, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 363, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                            .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                            .add(panelFondoToldoEnrrolladoLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                                .add(panelFondoToldoEnrrolladoLayout.createSequentialGroup()
                                    .add(jScrollPane18, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 76, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                    .add(jScrollPane19, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 76, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                                .add(tBambolinaEnrrolladoModelo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 186, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                .add(tBambolinaEnrrolladoRibete, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 186, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                        .add(org.jdesktop.layout.GroupLayout.TRAILING, panelFondoToldoEnrrolladoLayout.createSequentialGroup()
                            .add(80, 80, 80)
                            .add(panelFondoToldoEnrrolladoLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                                .add(bManivela, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                .add(jScrollPane10, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 76, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                            .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                            .add(panelFondoToldoEnrrolladoLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                                .add(jScrollPane11, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 76, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                .add(bBrazo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                            .add(11, 11, 11)
                            .add(panelFondoToldoEnrrolladoLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                                .add(org.jdesktop.layout.GroupLayout.TRAILING, panelFondoToldoEnrrolladoLayout.createSequentialGroup()
                                    .add(tTuboEnrrolleAreaMedida, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 186, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                    .add(82, 82, 82))
                                .add(org.jdesktop.layout.GroupLayout.TRAILING, panelFondoToldoEnrrolladoLayout.createSequentialGroup()
                                    .add(panelFondoToldoEnrrolladoLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                                        .add(tTelaAreaMedida, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 186, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                        .add(jScrollPane13, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 261, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                        .add(bLona, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                                    .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                    .add(jScrollPane12, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 76, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                            .add(163, 163, 163)))
                    .add(panelFondoToldoEnrrolladoLayout.createSequentialGroup()
                        .add(panelFondoToldoEnrrolladoLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                            .add(bSoporte, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(jScrollPane3, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 76, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(panelFondoToldoEnrrolladoLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                            .add(jScrollPane4, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 75, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(bMaquina, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(panelFondoToldoEnrrolladoLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                            .add(jScrollPane5, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 75, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(bCasquillo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(panelFondoToldoEnrrolladoLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                            .add(jScrollPane6, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 276, Short.MAX_VALUE)
                            .add(bTuboEnrrolle, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jScrollPane7, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 72, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jScrollPane8, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 64, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jScrollPane9, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 65, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(16, 16, 16)))
                .addContainerGap())
            .add(org.jdesktop.layout.GroupLayout.TRAILING, panelFondoToldoEnrrolladoLayout.createSequentialGroup()
                .add(panelFondoToldoEnrrolladoLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                    .add(panelFondoToldoEnrrolladoLayout.createSequentialGroup()
                        .addContainerGap()
                        .add(tPerfilCofreAreaMedida, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 186, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                    .add(panelFondoToldoEnrrolladoLayout.createSequentialGroup()
                        .add(252, 252, 252)
                        .add(panelFondoToldoEnrrolladoLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                            .add(jScrollPane30, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 276, Short.MAX_VALUE)
                            .add(bPerfilCofre, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))))
                .add(241, 241, 241))
        );
        panelFondoToldoEnrrolladoLayout.setVerticalGroup(
            panelFondoToldoEnrrolladoLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, panelFondoToldoEnrrolladoLayout.createSequentialGroup()
                .add(bPerfilCofre, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .add(9, 9, 9)
                .add(jScrollPane30, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 88, Short.MAX_VALUE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(tPerfilCofreAreaMedida)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(panelFondoToldoEnrrolladoLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                    .add(bMaquina, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(bSoporte, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(bCasquillo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(bTuboEnrrolle, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .add(9, 9, 9)
                .add(panelFondoToldoEnrrolladoLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jScrollPane4, 0, 92, Short.MAX_VALUE)
                    .add(org.jdesktop.layout.GroupLayout.TRAILING, jScrollPane5, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 92, Short.MAX_VALUE)
                    .add(jScrollPane3, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 92, Short.MAX_VALUE)
                    .add(org.jdesktop.layout.GroupLayout.TRAILING, panelFondoToldoEnrrolladoLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                        .add(org.jdesktop.layout.GroupLayout.TRAILING, jScrollPane7)
                        .add(org.jdesktop.layout.GroupLayout.TRAILING, jScrollPane6, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 84, Short.MAX_VALUE)
                        .add(org.jdesktop.layout.GroupLayout.TRAILING, jScrollPane8)
                        .add(org.jdesktop.layout.GroupLayout.TRAILING, jScrollPane9)))
                .add(6, 6, 6)
                .add(tTuboEnrrolleAreaMedida)
                .add(30, 30, 30)
                .add(panelFondoToldoEnrrolladoLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                    .add(panelFondoToldoEnrrolladoLayout.createSequentialGroup()
                        .add(panelFondoToldoEnrrolladoLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                            .add(bManivela, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(bBrazo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(panelFondoToldoEnrrolladoLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING, false)
                            .add(jScrollPane11, 0, 0, Short.MAX_VALUE)
                            .add(jScrollPane10, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 84, Short.MAX_VALUE)))
                    .add(panelFondoToldoEnrrolladoLayout.createSequentialGroup()
                        .add(bLona, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(panelFondoToldoEnrrolladoLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                            .add(jScrollPane13, 0, 0, Short.MAX_VALUE)
                            .add(jScrollPane12, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 86, Short.MAX_VALUE))))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(tTelaAreaMedida)
                .add(18, 18, 18)
                .add(panelFondoToldoEnrrolladoLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(bPerfil, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(panelFondoToldoEnrrolladoLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                        .add(bTapa, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(bTerminal, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(panelFondoToldoEnrrolladoLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                    .add(jScrollPane16, 0, 0, Short.MAX_VALUE)
                    .add(jScrollPane19, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 84, Short.MAX_VALUE)
                    .add(jScrollPane18, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 84, Short.MAX_VALUE)
                    .add(org.jdesktop.layout.GroupLayout.TRAILING, jScrollPane17, 0, 0, Short.MAX_VALUE)
                    .add(org.jdesktop.layout.GroupLayout.TRAILING, jScrollPane14, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 84, Short.MAX_VALUE))
                .add(6, 6, 6)
                .add(tPerfilAreaMedida)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(bBambolina, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(panelFondoToldoEnrrolladoLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(panelFondoToldoEnrrolladoLayout.createSequentialGroup()
                        .add(jScrollPane15, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(tBambolinaAreaMedida))
                    .add(panelFondoToldoEnrrolladoLayout.createSequentialGroup()
                        .add(tBambolinaEnrrolladoRibete)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(tBambolinaEnrrolladoModelo))))
        );

        panelesToldos.addTab("Toldo Enrollado", panelFondoToldoEnrrollado);
        panelFondoToldoEnrrollado.setOpaque(false);
        panelFondoToldoEnrrollado.setFocusable(false);

        panelFondoToldoEnrrollado.setMaximumSize(new java.awt.Dimension(780, 728));

        bAtacuerdaPared.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bAtacuerdaParedActionPerformed(evt);
            }
        });

        tAtacuerdaParedArea.setColumns(20);
        tAtacuerdaParedArea.setLineWrap(true);
        tAtacuerdaParedArea.setRows(3);
        jScrollPane20.setViewportView(tAtacuerdaParedArea);

        bCarruchaDoble.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bCarruchaDobleActionPerformed(evt);
            }
        });

        tCarruchaDobleArea.setColumns(20);
        tCarruchaDobleArea.setLineWrap(true);
        tCarruchaDobleArea.setRows(3);
        jScrollPane21.setViewportView(tCarruchaDobleArea);

        tPerfilPlanoArea.setColumns(20);
        tPerfilPlanoArea.setLineWrap(true);
        tPerfilPlanoArea.setRows(3);
        jScrollPane22.setViewportView(tPerfilPlanoArea);

        bPerfilPlano.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bPerfilPlanoActionPerformed(evt);
            }
        });

        tPerfilPlanoAreaMedida.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        tPerfilPlanoAreaMedida.setText("  ");

        bGancho.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bGanchoActionPerformed(evt);
            }
        });

        tGanchoIzquierdoArea.setColumns(20);
        tGanchoIzquierdoArea.setLineWrap(true);
        tGanchoIzquierdoArea.setRows(3);
        jScrollPane23.setViewportView(tGanchoIzquierdoArea);

        tGanchoDerechaArea.setColumns(20);
        tGanchoDerechaArea.setLineWrap(true);
        tGanchoDerechaArea.setRows(3);
        jScrollPane24.setViewportView(tGanchoDerechaArea);

        bPoleaIzquierda.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bPoleaIzquierdaActionPerformed(evt);
            }
        });

        tPoleaIzquierdaArea.setColumns(20);
        tPoleaIzquierdaArea.setLineWrap(true);
        tPoleaIzquierdaArea.setRows(3);
        jScrollPane25.setViewportView(tPoleaIzquierdaArea);

        tPoleaDerechaArea.setColumns(20);
        tPoleaDerechaArea.setLineWrap(true);
        tPoleaDerechaArea.setRows(3);
        jScrollPane26.setViewportView(tPoleaDerechaArea);

        bPoleaDerecha.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bPoleaDerechaActionPerformed(evt);
            }
        });

        tAtacuerdaArea.setColumns(20);
        tAtacuerdaArea.setLineWrap(true);
        tAtacuerdaArea.setRows(3);
        jScrollPane27.setViewportView(tAtacuerdaArea);

        bAtacuerda.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bAtacuerdaActionPerformed(evt);
            }
        });

        bBambolinaPlano.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bBambolinaPlanoActionPerformed(evt);
            }
        });

        tBambolinaPlanoArea.setColumns(20);
        tBambolinaPlanoArea.setLineWrap(true);
        tBambolinaPlanoArea.setRows(3);
        jScrollPane28.setViewportView(tBambolinaPlanoArea);

        tBambolinaPlanoAreaMedida.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        tBambolinaPlanoAreaMedida.setText("   ");

        tCarruchaSimpleArea.setColumns(20);
        tCarruchaSimpleArea.setLineWrap(true);
        tCarruchaSimpleArea.setRows(3);
        jScrollPane29.setViewportView(tCarruchaSimpleArea);

        bCarruchaSimple.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bCarruchaSimpleActionPerformed(evt);
            }
        });

        panelMedidaGuias.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Guías", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 0, 11), java.awt.Color.blue)); // NOI18N

        jLabel3.setText("Medidas:");

        jLabel2.setText("Cantidad:");

        org.jdesktop.layout.GroupLayout panelMedidaGuiasLayout = new org.jdesktop.layout.GroupLayout(panelMedidaGuias);
        panelMedidaGuias.setLayout(panelMedidaGuiasLayout);
        panelMedidaGuiasLayout.setHorizontalGroup(
            panelMedidaGuiasLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(panelMedidaGuiasLayout.createSequentialGroup()
                .addContainerGap()
                .add(panelMedidaGuiasLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jLabel2)
                    .add(jLabel3))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(panelMedidaGuiasLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(tCantidadGuias, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 99, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(tMedidasGuias, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 99, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );
        panelMedidaGuiasLayout.setVerticalGroup(
            panelMedidaGuiasLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(panelMedidaGuiasLayout.createSequentialGroup()
                .addContainerGap()
                .add(panelMedidaGuiasLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(jLabel2)
                    .add(tCantidadGuias, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(panelMedidaGuiasLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(jLabel3)
                    .add(tMedidasGuias, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        tBambolinaPlanoRibete.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        tBambolinaPlanoRibete.setText("   ");

        tBambolinaPlanoModelo.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        tBambolinaPlanoModelo.setText("   ");

        tVV.setText("VV");

        tCantidadPalillos.setText("Cant. palillos:");

        tTipoLona.setText("Lona: ");

        org.jdesktop.layout.GroupLayout panelFondoToldoPlanoLayout = new org.jdesktop.layout.GroupLayout(panelFondoToldoPlano);
        panelFondoToldoPlano.setLayout(panelFondoToldoPlanoLayout);
        panelFondoToldoPlanoLayout.setHorizontalGroup(
            panelFondoToldoPlanoLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(panelFondoToldoPlanoLayout.createSequentialGroup()
                .add(panelFondoToldoPlanoLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(panelFondoToldoPlanoLayout.createSequentialGroup()
                        .addContainerGap()
                        .add(panelMedidaGuias, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(151, 151, 151)
                        .add(panelFondoToldoPlanoLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING, false)
                            .add(bAtacuerdaPared, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(bCarruchaDoble, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(jScrollPane21, 0, 0, Short.MAX_VALUE)
                            .add(jScrollPane20, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 120, Short.MAX_VALUE)))
                    .add(panelFondoToldoPlanoLayout.createSequentialGroup()
                        .add(213, 213, 213)
                        .add(panelFondoToldoPlanoLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING, false)
                            .add(org.jdesktop.layout.GroupLayout.LEADING, panelFondoToldoPlanoLayout.createSequentialGroup()
                                .add(31, 31, 31)
                                .add(panelFondoToldoPlanoLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                                    .add(bGancho, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                    .add(jScrollPane23, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 89, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                                .add(144, 144, 144)
                                .add(jScrollPane24, 0, 0, Short.MAX_VALUE))
                            .add(org.jdesktop.layout.GroupLayout.LEADING, panelFondoToldoPlanoLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                                .add(tPerfilPlanoAreaMedida, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 186, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                .add(jScrollPane22, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 363, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                .add(bPerfilPlano, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                        .add(18, 18, 18)
                        .add(tVV, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 147, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                .add(37, 37, 37))
            .add(panelFondoToldoPlanoLayout.createSequentialGroup()
                .add(112, 112, 112)
                .add(panelFondoToldoPlanoLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                    .add(jScrollPane29, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 120, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(bCarruchaSimple, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(panelFondoToldoPlanoLayout.createSequentialGroup()
                        .add(panelFondoToldoPlanoLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                            .add(jScrollPane25, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 90, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(bPoleaIzquierda, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                        .add(176, 176, 176)
                        .add(panelFondoToldoPlanoLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                            .add(bAtacuerda, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(jScrollPane27, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 83, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))))
                .add(panelFondoToldoPlanoLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(panelFondoToldoPlanoLayout.createSequentialGroup()
                        .add(128, 128, 128)
                        .add(panelFondoToldoPlanoLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                            .add(bPoleaDerecha, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(jScrollPane26, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 77, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap(112, Short.MAX_VALUE))
                    .add(org.jdesktop.layout.GroupLayout.TRAILING, panelFondoToldoPlanoLayout.createSequentialGroup()
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED, 111, Short.MAX_VALUE)
                        .add(panelFondoToldoPlanoLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(tTipoLona, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 147, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(tCantidadPalillos, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 147, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                        .add(59, 59, 59))))
            .add(org.jdesktop.layout.GroupLayout.TRAILING, panelFondoToldoPlanoLayout.createSequentialGroup()
                .addContainerGap(127, Short.MAX_VALUE)
                .add(panelFondoToldoPlanoLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                    .add(tBambolinaPlanoAreaMedida, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 186, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(jScrollPane28, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 363, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(bBambolinaPlano, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(panelFondoToldoPlanoLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(tBambolinaPlanoModelo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 186, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(tBambolinaPlanoRibete, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 186, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .add(96, 96, 96))
        );
        panelFondoToldoPlanoLayout.setVerticalGroup(
            panelFondoToldoPlanoLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(panelFondoToldoPlanoLayout.createSequentialGroup()
                .add(panelFondoToldoPlanoLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(panelFondoToldoPlanoLayout.createSequentialGroup()
                        .addContainerGap()
                        .add(bAtacuerdaPared, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jScrollPane20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 60, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(bCarruchaDoble, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jScrollPane21, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(bPerfilPlano, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jScrollPane22, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(tPerfilPlanoAreaMedida)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(bGancho, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                    .add(panelFondoToldoPlanoLayout.createSequentialGroup()
                        .add(66, 66, 66)
                        .add(panelMedidaGuias, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(panelFondoToldoPlanoLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jScrollPane24, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 65, Short.MAX_VALUE)
                    .add(jScrollPane23, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(tVV))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(panelFondoToldoPlanoLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(panelFondoToldoPlanoLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                        .add(panelFondoToldoPlanoLayout.createSequentialGroup()
                            .add(bPoleaIzquierda, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                            .add(jScrollPane25, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                        .add(panelFondoToldoPlanoLayout.createSequentialGroup()
                            .add(bAtacuerda, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                            .add(jScrollPane27, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                    .add(panelFondoToldoPlanoLayout.createSequentialGroup()
                        .add(bPoleaDerecha, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jScrollPane26, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(bCarruchaSimple, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(panelFondoToldoPlanoLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(panelFondoToldoPlanoLayout.createSequentialGroup()
                        .add(jScrollPane29, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(5, 5, 5)
                        .add(bBambolinaPlano, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                    .add(panelFondoToldoPlanoLayout.createSequentialGroup()
                        .add(tCantidadPalillos)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(tTipoLona)))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(panelFondoToldoPlanoLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(panelFondoToldoPlanoLayout.createSequentialGroup()
                        .add(jScrollPane28, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 66, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(tBambolinaPlanoAreaMedida))
                    .add(panelFondoToldoPlanoLayout.createSequentialGroup()
                        .add(5, 5, 5)
                        .add(tBambolinaPlanoRibete)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(tBambolinaPlanoModelo)))
                .add(25, 25, 25))
        );

        org.jdesktop.layout.GroupLayout jPanel1Layout = new org.jdesktop.layout.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel1Layout.createSequentialGroup()
                .add(panelFondoToldoPlano, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(panelFondoToldoPlano, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        panelFondoToldoEnrrollado.setOpaque(false);
        panelFondoToldoEnrrollado.setFocusable(false);

        panelFondoToldoEnrrollado.setMaximumSize(new java.awt.Dimension(780, 728));

        panelesToldos.addTab("Toldo Plano", jPanel1);

        org.jdesktop.layout.GroupLayout layout = new org.jdesktop.layout.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(layout.createSequentialGroup()
                .addContainerGap()
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(layout.createSequentialGroup()
                        .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                            .add(pDespiece, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .add(jScrollPane1, 0, 0, Short.MAX_VALUE)
                            .add(layout.createSequentialGroup()
                                .add(pMedidas, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                .add(pSeleccionArticulo2, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .add(pSeleccionArticulo, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(panelesToldos, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 773, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                    .add(org.jdesktop.layout.GroupLayout.TRAILING, layout.createSequentialGroup()
                        .add(bAceptar)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                        .add(bCancelar)))
                .addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(layout.createSequentialGroup()
                .addContainerGap()
                .add(pSeleccionArticulo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(pSeleccionArticulo2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(pMedidas, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jScrollPane1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 224, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(pDespiece, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .add(18, 18, 18)
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(bCancelar)
                    .add(bAceptar))
                .addContainerGap())
            .add(org.jdesktop.layout.GroupLayout.TRAILING, layout.createSequentialGroup()
                .add(7, 7, 7)
                .add(panelesToldos, 0, 0, Short.MAX_VALUE)
                .add(45, 45, 45))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    public Dac getDacBase() {
        return dacBase;
    }

    public Articulo getArticulo() {
        return this.ar;
    }

    public Caracteristica getCaracteristica() {
        return this.car;
    }

    public Dac getDac() {
        return this.dac;
    }

    public Empresa getEmpresa() {
        return e;
    }

    public List<Seleccion> getListaSeleccion() {
        return listaSeleccion;
    }

    public NuevaLineaPresupuesto getLPresupuesto() {
        return lPresupuesto;
    }

    protected void iniciarVariables() {
        int variablesMostradas = 0;

        pVariables.removeAll();
        pVariables.setSize(500, 500);
        pVariables.setLayout(new GridLayout(0, 1));

        if (listaVbles != null) {
            Variable vTemp;
            Iterator<Variable> lIter = listaVbles.iterator();
            double valorTemp = 0D;
            while (lIter.hasNext()) {
                vTemp = lIter.next();
                if (vTemp.getTipo().equals(Constantes.NUMERICA)) {
                    if (vTemp.getValor() == null) {
                        vTemp.setValor(0d);
                    }

                    valorTemp = vTemp.getValor();
                    engineGlobal.put(vTemp.getNombre(), valorTemp);

                    if (vTemp.getNombre().equals("cant_guias")) {
                        this.tCantidadGuias.setText(String.valueOf(valorTemp));
                    } else if (vTemp.getNombre().equals("med_guias")) {
                        this.tMedidasGuias.setText(String.valueOf(valorTemp));
                    } else if (vTemp.getNombre().equals("vv")) {
                        this.tVV.setText("VV: " + String.valueOf(valorTemp));
                    } else if (vTemp.getNombre().equals("cantidad_palillos")) {
                        this.tCantidadPalillos.setText("Cant. palillos: " + valorTemp);
                    }
                    
                    if (condicion(vTemp)) {
                        pVariables.add(new NuevaLineaVariableValor(this, vTemp.getNombre(), String.valueOf(valorTemp), true));
                        variablesMostradas++;
                    }
                } else if (vTemp.getTipo().equals(Constantes.SELECCION)) {
                    List<Seleccion> listaSeleccionTemp = obtenerSeleccionVbles(vTemp.getNombre());

                    if (listaSeleccionTemp != null) {
                        List<String> listaOpciones = new ArrayList<String>();
                        String opcionSeleccionada = "";
                        Seleccion seleccionTemp;
                        boolean vbleSeleccionada = false;
                        Iterator<Seleccion> iter = listaSeleccionTemp.iterator();
                        while (iter.hasNext()) {
                            seleccionTemp = iter.next();
                            listaOpciones.add(seleccionTemp.getNombre());
                            if (seleccionTemp.getSeleccionada()) {
                                valorTemp = seleccionTemp.getValor();
                                engineGlobal.put(vTemp.getNombre(), valorTemp);
                                opcionSeleccionada = seleccionTemp.getNombre();
                                vbleSeleccionada = true;
                            }
                        }

                        if (!vbleSeleccionada) {
                            valorTemp = Double.valueOf(0d);
                            engineGlobal.put(vTemp.getNombre(), valorTemp);
                        }

                        if (vTemp.getNombre().equals("lona")) {
                            this.tTipoLona.setText("Lona: " + opcionSeleccionada);
                        } else if (vTemp.getNombre().equals("modelo_tipo_faldon")) {
                            if (dacBase.getTipoPlantilla().equals(Constantes.PLANTILLA_TOLDO_ENRROLLADO)) {
                                this.tBambolinaEnrrolladoModelo.setText("Modelo: " + opcionSeleccionada);
                            } else if (dacBase.getTipoPlantilla().equals(Constantes.PLANTILLA_TOLDO_PLANO)) {
                                this.tBambolinaPlanoModelo.setText("Modelo: " + opcionSeleccionada);
                            }
                        } else if (vTemp.getNombre().equals("ribete")) {
                            if (dacBase.getTipoPlantilla().equals(Constantes.PLANTILLA_TOLDO_ENRROLLADO)) {
                                this.tBambolinaEnrrolladoRibete.setText("Ribete: " + opcionSeleccionada);
                            } else if (dacBase.getTipoPlantilla().equals(Constantes.PLANTILLA_TOLDO_PLANO)) {
                                this.tBambolinaPlanoRibete.setText("Ribete: " + opcionSeleccionada);
                            }
                        }

                        if (condicion(vTemp)) {
                            pVariables.add(new NuevaLineaVariableSeleccion(this, vTemp.getNombre(), listaOpciones, opcionSeleccionada));
                            variablesMostradas++;
                        }
                    }
                } else {
                    try {
                        Double resultado = matematico.Matematico.redondear2decimales((Double) engineGlobal.eval(vTemp.getFormula()));
                        if (vTemp.getActivarMinimo() && vTemp.getValorMinimo() > resultado) {
                            resultado = vTemp.getValorMinimo();
                        } else if (vTemp.getActivarMaximo() && vTemp.getValorMaximo() < resultado) {
                            resultado = vTemp.getValorMaximo();
                        }

                        vTemp.setValor(resultado);
                        engineGlobal.put(vTemp.getNombre(), resultado);

                        if (vTemp.getNombre().equals("cant_guias")) {
                            tCantidadGuias.setText(String.valueOf(resultado));
                        } else if (vTemp.getNombre().equals("med_guias")) {
                            tMedidasGuias.setText(String.valueOf(resultado));
                        } else if (vTemp.getNombre().equals("vv")) {
                            this.tVV.setText("VV: " + String.valueOf(resultado));
                        } else if (vTemp.getNombre().equals("cantidad_palillos")) {
                            this.tCantidadPalillos.setText("Cant. palillos: " + resultado);
                        }

                        if (condicion(vTemp)) {
                            pVariables.add(new NuevaLineaVariableValor(this, vTemp.getNombre(), String.valueOf(resultado), vTemp.getEditarResultadoFormula()));
                            variablesMostradas++;
                        }
                    } catch (ScriptException se) {
                        JOptionPane.showMessageDialog(null, "Hay un error al evaluar la fórmula de la variable " + vTemp.getNombre(), "Error", JOptionPane.INFORMATION_MESSAGE);
                    }
                }
            }

            for (int contadorVbles = variablesMostradas + 1; contadorVbles < 10; contadorVbles++) {
                pVariables.add(new NuevaLineaVariableVacia());
            }

            pVariables.setVisible(true);
            pVariables.repaint();
            this.pack();
        }
    }

    private boolean condicion(Variable var) {
        boolean condicion = true;
        try {
            if (var.getCondicion() != null && var.getCondicion().length() != 0) {
                condicion = (Boolean) engineGlobal.eval(var.getCondicion());
            }
        } catch (Exception ex) {
            condicion = false;
        }
        return condicion;
    }

    private void actualizarVariables() {
        pVariables.removeAll();
        pVariables.setSize(500, 500);
        pVariables.setLayout(new GridLayout(0, 1));
        int variablesMostradas = 0;

        if (listaVbles != null) {
            Variable vTemp;
            Iterator<Variable> lIter = listaVbles.iterator();
            double valorTemp = new Double(0d);
            while (lIter.hasNext()) {
                vTemp = lIter.next();
                if (vTemp.getTipo().equals(Constantes.NUMERICA)) {
                    if (vTemp.getValor() == null) {
                        vTemp.setValor(0d);
                    }

                    valorTemp = vTemp.getValor();
                    engineGlobal.put(vTemp.getNombre(), valorTemp);

                    if (vTemp.getNombre().equals("cant_guias")) {
                        tCantidadGuias.setText(String.valueOf(valorTemp));
                    } else if (vTemp.getNombre().equals("med_guias")) {
                        tMedidasGuias.setText(String.valueOf(valorTemp));
                    } else if (vTemp.getNombre().equals("vv")) {
                        this.tVV.setText("VV: " + String.valueOf(valorTemp));
                    } else if (vTemp.getNombre().equals("cantidad_palillos")) {
                        this.tCantidadPalillos.setText("Cant. palillos: " + valorTemp);
                    }
                    
                    if (condicion(vTemp)) {
                        pVariables.add(new NuevaLineaVariableValor(this, vTemp.getNombre(), String.valueOf(valorTemp), true));
                        variablesMostradas++;
                    }
                } else if (vTemp.getTipo().equals(Constantes.SELECCION)) {
                    List<Seleccion> listaSeleccionTemp = obtenerSeleccionVbles(vTemp.getNombre());
                    if (listaSeleccionTemp != null) {
                        List<String> listaOpciones = new ArrayList<String>();
                        String opcionSeleccionada = "";
                        Seleccion seleccionTemp;
                        boolean vbleSeleccionada = false;
                        Iterator<Seleccion> iter = listaSeleccionTemp.iterator();
                        while (iter.hasNext()) {
                            seleccionTemp = iter.next();
                            listaOpciones.add(seleccionTemp.getNombre());
                            if (seleccionTemp.getSeleccionada()) {
                                valorTemp = seleccionTemp.getValor();
                                engineGlobal.put(vTemp.getNombre(), valorTemp);
                                opcionSeleccionada = seleccionTemp.getNombre();
                                vbleSeleccionada = true;
                            }
                        }

                        if (!vbleSeleccionada) {
                            valorTemp = new Double(0d);
                            engineGlobal.put(vTemp.getNombre(), valorTemp);
                        }

                        if (vTemp.getNombre().equals("lona")) {
                            this.tTipoLona.setText("Lona: " + opcionSeleccionada);
                        } else if (vTemp.getNombre().equals("modelo_tipo_faldon")) {
                            if (dacBase.getTipoPlantilla().equals(Constantes.PLANTILLA_TOLDO_ENRROLLADO)) {
                                this.tBambolinaEnrrolladoModelo.setText("Modelo: " + opcionSeleccionada);
                            } else if (dacBase.getTipoPlantilla().equals(Constantes.PLANTILLA_TOLDO_PLANO)) {
                                this.tBambolinaPlanoModelo.setText("Modelo: " + opcionSeleccionada);
                            }
                        } else if (vTemp.getNombre().equals("ribete")) {
                            if (dacBase.getTipoPlantilla().equals(Constantes.PLANTILLA_TOLDO_ENRROLLADO)) {
                                this.tBambolinaEnrrolladoRibete.setText("Ribete: " + opcionSeleccionada);
                            } else if (dacBase.getTipoPlantilla().equals(Constantes.PLANTILLA_TOLDO_PLANO)) {
                                this.tBambolinaPlanoRibete.setText("Ribete: " + opcionSeleccionada);
                            }
                        }
                        
                        if (condicion(vTemp)) {
                            pVariables.add(new NuevaLineaVariableSeleccion(this, vTemp.getNombre(), listaOpciones, opcionSeleccionada));
                            variablesMostradas++;
                        }
                    }
                } else {
                    try {
                        Double resultado = null;
                        if (!vTemp.getEditarResultadoFormula()) {
                            //Si la vble no es editable ==> hay que recalcular su valor
                            resultado = matematico.Matematico.redondear2decimales((Double) engineGlobal.eval(vTemp.getFormula()));
                            if (resultado == null) {
                                resultado = 0.0;
                                JOptionPane.showMessageDialog(null, "Hay un error al evaluar la fórmula de la variable " + vTemp.getNombre() + ". Edite el DAC correspondiente", "Error", JOptionPane.INFORMATION_MESSAGE);
                            }
                        } else {
                            resultado = vTemp.getValor();
                        }

                        if (vTemp.getValor() == null) {
                            resultado = 0.0;
                        }

                        if (vTemp.getActivarMaximo() && vTemp.getValorMinimo() > resultado) {
                            resultado = vTemp.getValorMinimo();
                        } else if (vTemp.getActivarMaximo() && vTemp.getValorMaximo() < resultado) {
                            resultado = vTemp.getValorMaximo();
                        }

                        vTemp.setValor(resultado);
                        engineGlobal.put(vTemp.getNombre(), resultado);

                        if (vTemp.getNombre().equals("cant_guias")) {
                            tCantidadGuias.setText(String.valueOf(resultado));
                        } else if (vTemp.getNombre().equals("med_guias")) {
                            tMedidasGuias.setText(String.valueOf(resultado));
                        } else if (vTemp.getNombre().equals("vv")) {
                            this.tVV.setText("VV: " + String.valueOf(resultado));
                        } else if (vTemp.getNombre().equals("cantidad_palillos")) {
                            this.tCantidadPalillos.setText("Cant. palillos: " + resultado);
                        }
                        if (condicion(vTemp)) {
                            pVariables.add(new NuevaLineaVariableValor(this, vTemp.getNombre(), String.valueOf(resultado), vTemp.getEditarResultadoFormula()));
                            variablesMostradas++;
                        }
                    } catch (ScriptException se) {
                        JOptionPane.showMessageDialog(null, "Hay un error al evaluar la fórmula de la variable " + vTemp.getNombre(), "Error", JOptionPane.INFORMATION_MESSAGE);
                    }
                }
            }

            for (int contadorVbles = variablesMostradas + 1; contadorVbles < 10; contadorVbles++) {
                pVariables.add(new NuevaLineaVariableVacia());
            }

            pVariables.setVisible(true);
            pVariables.repaint();
            this.pack();
        }
    }

    private void actualizarVariables(String nombreVble, String sValor) {
        pVariables.removeAll();
        pVariables.setSize(500, 500);
        pVariables.setLayout(new GridLayout(0, 1));
        JComponent componenteFocus = null;

        int variablesMostradas = 0;
        if (listaVbles != null) {
            Variable vTemp;
            Iterator<Variable> lIter = listaVbles.iterator();
            double valorTemp;
            while (lIter.hasNext()) {
                vTemp = lIter.next();
                if (vTemp.getTipo().equals(Constantes.NUMERICA)) {
                    if (vTemp.getValor() == null) {
                        vTemp.setValor(0d);
                    }

                    valorTemp = vTemp.getValor();
                    engineGlobal.put(vTemp.getNombre(), valorTemp);

                    if (condicion(vTemp)) {
                        NuevaLineaVariableValor nlvv = new NuevaLineaVariableValor(this, vTemp.getNombre(), String.valueOf(valorTemp), true);
                        if (vTemp.getNombre().equals(nombreVble)) {
                            nlvv.setValor(Util.convertirPuntoAComa(sValor));
                            componenteFocus = nlvv.getTValor();
                        }
                        variablesMostradas++;
                        pVariables.add(nlvv);
                    }
                } else if (vTemp.getTipo().equals(Constantes.SELECCION)) {
                    List<Seleccion> listaSeleccionTemp = obtenerSeleccionVbles(vTemp.getNombre());
                    if (listaSeleccionTemp != null) {
                        List<String> listaOpciones = new ArrayList<String>();
                        String opcionSeleccionada = "";
                        Seleccion seleccionTemp;
                        boolean vbleSeleccionada = false;
                        Iterator<Seleccion> iter = listaSeleccionTemp.iterator();
                        while (iter.hasNext()) {
                            seleccionTemp = iter.next();
                            listaOpciones.add(seleccionTemp.getNombre());
                            if (seleccionTemp.getSeleccionada()) {
                                valorTemp = seleccionTemp.getValor();
                                engineGlobal.put(vTemp.getNombre(), valorTemp);
                                opcionSeleccionada = seleccionTemp.getNombre();
                                vbleSeleccionada = true;
                            }
                        }

                        if (!vbleSeleccionada) {
                            valorTemp = Double.valueOf(0d);
                            engineGlobal.put(vTemp.getNombre(), valorTemp);
                        }

                        if (condicion(vTemp)) {
                            pVariables.add(new NuevaLineaVariableSeleccion(this, vTemp.getNombre(), listaOpciones, opcionSeleccionada));
                            variablesMostradas++;
                        }
                    }

                } else if (vTemp.getTipo().equals(Constantes.CALCULADA)) {
                    try {
                        Double valorCalculado = null;

                        if (!vTemp.getEditarResultadoFormula()) {
                            //Si la vble no es editable ==> hay que recalcular su valor
                            valorCalculado = matematico.Matematico.redondear2decimales((Double) engineGlobal.eval(vTemp.getFormula()));
                            if (valorCalculado == null) {
                                valorCalculado = 0.0;
                                JOptionPane.showMessageDialog(null, "Hay un error al evaluar la fórmula de la variable " + vTemp.getNombre() + ". Edite el DAC correspondiente", "Error", JOptionPane.INFORMATION_MESSAGE);
                            }
                        } else {
                            valorCalculado = vTemp.getValor();
                        }

                        if (vTemp.getValor() == null) {
                            valorCalculado = 0.0;
                        }

                        if (vTemp.getActivarMaximo() && vTemp.getValorMinimo() > valorCalculado) {
                            vTemp.setValor(vTemp.getValorMinimo());
                        } else if (vTemp.getActivarMaximo() && vTemp.getValorMaximo() < valorCalculado) {
                            vTemp.setValor(vTemp.getValorMaximo());
                        } else {
                            vTemp.setValor(valorCalculado);
                        }

                        valorTemp = vTemp.getValor();
                        engineGlobal.put(vTemp.getNombre(), valorTemp);

                        if (condicion(vTemp)) {
                            NuevaLineaVariableValor nlvv = new NuevaLineaVariableValor(this, vTemp.getNombre(), String.valueOf(valorTemp), vTemp.getEditarResultadoFormula());
                            if (vTemp.getNombre().equals(nombreVble)) {
                                nlvv.setValor(Util.convertirPuntoAComa(sValor));
                                componenteFocus = nlvv.getTValor();
                            }

                            variablesMostradas++;
                            pVariables.add(nlvv);
                        }
                    } catch (ScriptException se) {
                        log.error("Hay un error al evaluar la fórmula de la variable " + vTemp.getNombre(), se);
                        JOptionPane.showMessageDialog(null, "Hay un error al evaluar la fórmula de la variable " + vTemp.getNombre(), "Error", JOptionPane.INFORMATION_MESSAGE);
                    }
                }
            }

            for (int contadorVbles = variablesMostradas + 1; contadorVbles < 10; contadorVbles++) {
                pVariables.add(new NuevaLineaVariableVacia());
            }

            pVariables.setVisible(true);
            pVariables.repaint();
            this.pack();
            componenteFocus.requestFocus();
        }

        eliminarCortes = true;
    }

    private void actualizarVariables(String nombreVble) {
        pVariables.removeAll();
        pVariables.setSize(500, 500);
        pVariables.setLayout(new GridLayout(0, 1));

        JComponent componenteFocus = null;
        int variablesMostradas = 0;

        if (listaVbles != null) {
            Variable vTemp;
            Iterator<Variable> lIter = listaVbles.iterator();
            double valorTemp = new Double(0d);
            while (lIter.hasNext()) {
                vTemp = lIter.next();
                if (vTemp.getTipo().equals(Constantes.NUMERICA)) {
                    if (vTemp.getValor() == null) {
                        vTemp.setValor(0d);
                    }

                    valorTemp = vTemp.getValor();
                    engineGlobal.put(vTemp.getNombre(), valorTemp);

                    if (vTemp.getNombre().equals("cant_guias")) {
                        tCantidadGuias.setText(String.valueOf(valorTemp));
                    } else if (vTemp.getNombre().equals("med_guias")) {
                        tMedidasGuias.setText(String.valueOf(valorTemp));
                    } else if (vTemp.getNombre().equals("vv")) {
                        this.tVV.setText("VV: " + String.valueOf(valorTemp));
                    } else if (vTemp.getNombre().equals("cantidad_palillos")) {
                        this.tCantidadPalillos.setText("Cant. palillos: " + valorTemp);
                    }

                    if (condicion(vTemp)) {
                        pVariables.add(new NuevaLineaVariableValor(this, vTemp.getNombre(), String.valueOf(valorTemp), true));
                        variablesMostradas++;
                    }
                } else if (vTemp.getTipo().equals(Constantes.SELECCION)) {
                    List<Seleccion> listaSeleccionTemp = obtenerSeleccionVbles(vTemp.getNombre());

                    if (listaSeleccionTemp != null) {
                        List<String> listaOpciones = new ArrayList<String>();
                        String opcionSeleccionada = "";
                        Seleccion seleccionTemp;
                        boolean vbleSeleccionada = false;
                        Iterator<Seleccion> iter = listaSeleccionTemp.iterator();
                        while (iter.hasNext()) {
                            seleccionTemp = iter.next();
                            listaOpciones.add(seleccionTemp.getNombre());
                            if (seleccionTemp.getSeleccionada()) {
                                valorTemp = seleccionTemp.getValor();
                                engineGlobal.put(vTemp.getNombre(), valorTemp);
                                opcionSeleccionada = seleccionTemp.getNombre();
                                vbleSeleccionada = true;
                            }
                        }

                        if (!vbleSeleccionada) {
                            valorTemp = Double.valueOf(0d);
                            engineGlobal.put(vTemp.getNombre(), valorTemp);
                        }

                        if (vTemp.getNombre().equals("lona")) {
                            this.tTipoLona.setText("Lona: " + opcionSeleccionada);
                        } else if (vTemp.getNombre().equals("modelo_tipo_faldon")) {
                            if (dacBase.getTipoPlantilla().equals(Constantes.PLANTILLA_TOLDO_ENRROLLADO)) {
                                this.tBambolinaEnrrolladoModelo.setText("Modelo: " + opcionSeleccionada);
                            } else if (dacBase.getTipoPlantilla().equals(Constantes.PLANTILLA_TOLDO_PLANO)) {
                                this.tBambolinaPlanoModelo.setText("Modelo: " + opcionSeleccionada);
                            }
                        } else if (vTemp.getNombre().equals("ribete")) {
                            if (dacBase.getTipoPlantilla().equals(Constantes.PLANTILLA_TOLDO_ENRROLLADO)) {
                                this.tBambolinaEnrrolladoRibete.setText("Ribete: " + opcionSeleccionada);
                            } else if (dacBase.getTipoPlantilla().equals(Constantes.PLANTILLA_TOLDO_PLANO)) {
                                this.tBambolinaPlanoRibete.setText("Ribete: " + opcionSeleccionada);
                            }
                        }

                        if (condicion(vTemp)) {
                            NuevaLineaVariableSeleccion nlvs = new NuevaLineaVariableSeleccion(this, vTemp.getNombre(), listaOpciones, opcionSeleccionada);
                            if (vTemp.getNombre().equals(nombreVble)) {
                                componenteFocus = nlvs.getCSeleccion();
                            }
                            variablesMostradas++;
                            pVariables.add(nlvs);
                        }
                    }
                } else {
                    try {
                        Double resultado = null;
                        if (!vTemp.getEditarResultadoFormula()) {
                            //Si la vble no es editable ==> hay que recalcular su valor
                            resultado = matematico.Matematico.redondear2decimales((Double) engineGlobal.eval(vTemp.getFormula()));
                            if (resultado == null) {
                                resultado = 0.0;
                                JOptionPane.showMessageDialog(null, "Hay un error al evaluar la fórmula de la variable " + vTemp.getNombre() + ". Edite el DAC correspondiente", "Error", JOptionPane.INFORMATION_MESSAGE);
                            }
                        } else {
                            resultado = vTemp.getValor();
                        }

                        if (vTemp.getValor() == null) {
                            resultado = 0.0;
                        }

                        if (vTemp.getActivarMaximo() && vTemp.getValorMinimo() > resultado) {
                            resultado = vTemp.getValorMinimo();
                        } else if (vTemp.getActivarMaximo() && vTemp.getValorMaximo() < resultado) {
                            resultado = vTemp.getValorMaximo();
                        }

                        vTemp.setValor(resultado);
                        engineGlobal.put(vTemp.getNombre(), resultado);

                        if (vTemp.getNombre().equals("cant_guias")) {
                            tCantidadGuias.setText(String.valueOf(resultado));
                        } else if (vTemp.getNombre().equals("med_guias")) {
                            tMedidasGuias.setText(String.valueOf(resultado));
                        } else if (vTemp.getNombre().equals("vv")) {
                            this.tVV.setText("VV: " + String.valueOf(resultado));
                        } else if (vTemp.getNombre().equals("cantidad_palillos")) {
                            this.tCantidadPalillos.setText("Cant. palillos: " + resultado);
                        }

                        if (condicion(vTemp)) {
                            pVariables.add(new NuevaLineaVariableValor(this, vTemp.getNombre(), String.valueOf(resultado), vTemp.getEditarResultadoFormula()));
                            variablesMostradas++;
                        }
                    } catch (ScriptException se) {
                        log.error("Hay un error al evaluar la fórmula de la variable " + vTemp.getNombre(), se);
                        JOptionPane.showMessageDialog(null, "Hay un error al evaluar la fórmula de la variable " + vTemp.getNombre(), "Error", JOptionPane.INFORMATION_MESSAGE);
                    }
                }
            }

            for (int contadorVbles = variablesMostradas + 1; contadorVbles < 10; contadorVbles++) {
                pVariables.add(new NuevaLineaVariableVacia());
            }

            pVariables.setVisible(true);
            pVariables.repaint();
            this.pack();
            componenteFocus.requestFocus();
        }
    }

    private ArrayList<Seleccion> obtenerSeleccionVbles(String nombre) {
        ArrayList<Seleccion> lres = new ArrayList<Seleccion>();
        Iterator<Seleccion> iter = listaSeleccion.iterator();
        Seleccion sel;
        Variable var;
        while (iter.hasNext()) {
            sel = iter.next();
            var = sel.getVariable();
            if (var.getNombre().equalsIgnoreCase(nombre)) {
                lres.add(sel);
            }
        }
        return lres;
    }

    protected void actualizarValoresVblesSeleccion(String nombre, String valor) {
        if (listaVbles != null) {
            Variable vTemp;
            Iterator<Variable> lIter = listaVbles.iterator();
            boolean seguir = true;
            while (lIter.hasNext() && seguir) {
                vTemp = lIter.next();
                if (vTemp.getNombre().equals(nombre)) {
                    seguir = false;
                    List<Seleccion> listaSeleccionTemp = obtenerSeleccionVbles(nombre);
                    if (listaSeleccionTemp != null) {
                        Seleccion seleccionTemp;
                        boolean vbleSeleccionada = false;
                        Iterator<Seleccion> iter = listaSeleccionTemp.iterator();
                        while (iter.hasNext() && !vbleSeleccionada) {
                            seleccionTemp = iter.next();
                            seleccionTemp.setSeleccionada(seleccionTemp.getNombre().equals(valor));
                        }
                    }
                }
            }
            actualizarVariables(nombre);
        }

        eliminarCortes = true;
    }

    protected void actualizarValoresVblesNumerica(String nombre, Double dValor, String sValor) {
        if (listaVbles != null) {
            Variable vTemp;
            Iterator<Variable> lIter = listaVbles.iterator();
            boolean seguir = true;
            while (lIter.hasNext() && seguir) {
                vTemp = lIter.next();
                if (vTemp.getNombre().equals(nombre)) {
                    vTemp.setValor(dValor);
                    seguir = false;
                }
            }
            actualizarVariables(nombre, sValor);
        }
    }

    private void rellenarCombosColores() {
        List<Colores> listaColores = BaseDatos.getListaColores();
        Iterator<Colores> it = listaColores.iterator();
        Colores c;
        cLacado.addItem(Constantes.VACIO);
        cAccesorios.addItem(Constantes.VACIO);
        while (it.hasNext()) {
            c = it.next();
            cLacado.addItem(c.getDescripcion());
            cAccesorios.addItem(c.getDescripcion());
        }
    }

    public void eliminarSeleccion(String nombreVariable, String nombreSeleccion) {
        Iterator<Seleccion> iter = listaSeleccion.iterator();
        Seleccion sel;
        Variable var;
        int indice = 0;
        int indiceBorrar = -1;
        while (iter.hasNext()) {
            sel = iter.next();
            var = sel.getVariable();
            if (var.getNombre().equalsIgnoreCase(nombreVariable) && sel.getNombre().equalsIgnoreCase(nombreSeleccion)) {
                indiceBorrar = indice;
            }
            indice++;
        }
        if (indiceBorrar != -1) {
            listaSeleccion.remove(indiceBorrar);
        }
    }

    private void eliminarCortesLonaPerfil() {
        if (this.lPresupuesto != null && lPresupuesto.getIid() != null) {
            Integer iid = lPresupuesto.getIid();
            //Si la linea ya está almacenada en la BBDD y esta linea tiene cortes de lona entonces se han de borrar
            List<LineaCorteLona> llcl = BaseDatos.getListaLineaCorteLonaByLineaPresupuesto(iid);
            List<LineaCortePerfil> llcp = BaseDatos.getListaLineaCortePerfilByLineaPresupuesto(iid);
            List<MovimientoPresupuesto> ld = BaseDatos.getListaMovimientoPresupuestoDescuentoUnidades(iid);

            StringBuffer buffer = new StringBuffer();
            if (ld != null && ld.size() > 0) {
                buffer.append("Los descuentos de unidades serán deshechos.");
            }
            if (llcl != null && llcl.size() > 0) {
                buffer.append("Los cortes de lona serán eliminados");
            }
            if (llcp != null && llcp.size() > 0) {
                buffer.append("Los cortes de perfil serán eliminados");
            }

            String mensaje = buffer.toString();
            if (mensaje != null && mensaje.length() > 0) {
                JOptionPane.showMessageDialog(null, mensaje, "Información", JOptionPane.INFORMATION_MESSAGE);
                if (ld != null && ld.size() > 0) {
                    BaseDatos.eliminarDescuentoUnidadesByLineaPresupuesto(iid);
                }
                if (llcl != null && llcl.size() > 0) {
                    BaseDatos.eliminarCorteLonaByLineaPresupuesto(iid);
                }
                if (llcp != null && llcp.size() > 0) {
                    BaseDatos.eliminarCortePerfilByLineaPresupuesto(iid);
                }
            }
        }
    }

private void bCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bCancelarActionPerformed
    cerrarDac();
}//GEN-LAST:event_bCancelarActionPerformed

    protected void accionAceptar() {
        if (eliminarCortes) {
            eliminarCortesLonaPerfil();
        }

        lPresupuesto.borrarRDAC();

        String colorLacadoStr = (String) cLacado.getSelectedItem();
        String colorAccesoriosStr = (String) cAccesorios.getSelectedItem();

        dac.setClacado(BaseDatos.obtenerColorPorDescripcion(colorLacadoStr));
        dac.setCaccesorios(BaseDatos.obtenerColorPorDescripcion(colorAccesoriosStr));
        dac.setArticulo(ar);

        String medida1Str = tMedida1.getText();
        String medida2Str = tMedida2.getText();
        String medida3Str = tMedida3.getText();
        String medida4Str = tMedida4.getText();
        String medida5Str = tMedida5.getText();
        String cantidadStr = tCantidad.getText();

        if (medida1Str.length() == 0) { medida1Str = "0"; }
        if (medida2Str.length() == 0) { medida2Str = "0"; }
        if (medida3Str.length() == 0) { medida3Str = "0"; }
        if (medida4Str.length() == 0) { medida4Str = "0"; }
        if (medida5Str.length() == 0) { medida5Str = "0"; }
        if (cantidadStr.length() == 0){ cantidadStr = "0";}

        dac.setMedida1(Double.valueOf(Util.convertirComaAPunto(medida1Str)));
        dac.setMedida2(Double.valueOf(Util.convertirComaAPunto(medida2Str)));
        dac.setMedida3(Double.valueOf(Util.convertirComaAPunto(medida3Str)));
        dac.setMedida4(Double.valueOf(Util.convertirComaAPunto(medida4Str)));
        dac.setMedida5(Double.valueOf(Util.convertirComaAPunto(medida5Str)));
        dac.setCantidad(Double.valueOf(Util.convertirComaAPunto(cantidadStr)));

        FamiliaVenta fv = BaseDatos.obtenerFamiliaVentaPorIid(ar.getIid_fam_venta().getIid());
        TipoControl tc = BaseDatos.obtenerTipoControlPorIid(fv.getIid_tipo_control().getIid());
        TipoMedida tm = BaseDatos.obtenerTipoMedidaByIid(tc.getIid_tipo_medida().getIid());

        lPresupuesto.insertarRellenarDac(this);
        lPresupuesto.anadirLineaDocumento();
        lPresupuesto.setNumMedidas(tm.getNum_dimensiones());
        lPresupuesto.mostrarBotonVerDac(true);
        cerrarDac();
    }

private void bAceptarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bAceptarActionPerformed
    try {
        accionAceptar();
    } catch (Exception ex) {
        log.error("Problemas extraños al intentar guardar el artículo compuesto ", ex);
        JOptionPane.showMessageDialog(null, "Problemas extraños", "Error", JOptionPane.ERROR_MESSAGE);
    }
}//GEN-LAST:event_bAceptarActionPerformed

    public List<Despiece> getListaDespiece() {
        return this.listaDespiece;
    }

    public Despiece getDespiecePorIndice(int indice) {
        return this.listaDespiece.get(indice);
    }

    protected void rellenarBrazos(Articulo articulo) {
        articulo = BaseDatos.obtenerArticuloPorIid(articulo.getIid());
        tBrazoIzquierdoArea.setText(articulo.getDes_inf());
        tBrazoDerechoArea.setText(articulo.getDes_inf());
    }

    protected void rellenarManivelas(Articulo articulo) {
        articulo = BaseDatos.obtenerArticuloPorIid(articulo.getIid());
        tManivelaArea.setText(articulo.getDes_inf());
    }

    protected void rellenarSoporte(Articulo articulo) {
        articulo = BaseDatos.obtenerArticuloPorIid(articulo.getIid());
        tSoporteIzquierdoArea.setText(articulo.getDes_inf());
        tSoporteDerechoArea.setText(articulo.getDes_inf());
    }

    protected void rellenarCasquillo(Articulo articulo) {
        articulo = BaseDatos.obtenerArticuloPorIid(articulo.getIid());
        tCasquilloIzquierdoArea.setText(articulo.getDes_inf());
        tCasquilloDerechoArea.setText(articulo.getDes_inf());
    }

    protected void rellenarMaquina(Articulo articulo) {
        articulo = BaseDatos.obtenerArticuloPorIid(articulo.getIid());
        tMaquinaIzquierdaArea.setText(articulo.getDes_inf());
        tMaquinaDerechaArea.setText(articulo.getDes_inf());
    }

    protected void rellenarPerfilCofre(Articulo articulo) {
        articulo = BaseDatos.obtenerArticuloPorIid(articulo.getIid());
        tPerfilCofreArea.setText(articulo.getDes_inf());
        tPerfilCofreAreaMedida.setText(calcularMedida("PerfilCofre"));
    }

    protected void rellenarPerfil(Articulo articulo) {
        articulo = BaseDatos.obtenerArticuloPorIid(articulo.getIid());
        tPerfilArea.setText(articulo.getDes_inf());
        tPerfilAreaMedida.setText(calcularMedida("Perfil"));
    }

    protected void rellenarPerfilPlano(Articulo articulo) {
        articulo = BaseDatos.obtenerArticuloPorIid(articulo.getIid());
        tPerfilPlanoArea.setText(articulo.getDes_inf());
        tPerfilPlanoAreaMedida.setText(calcularMedida("Perfil"));
    }

    protected void rellenarTerminal(Articulo articulo) {
        articulo = BaseDatos.obtenerArticuloPorIid(articulo.getIid());
        tTerminalIzquierdoArea.setText(articulo.getDes_inf());
        tTerminalDerechoArea.setText(articulo.getDes_inf());
    }

    protected void rellenarTapa(Articulo articulo) {
        articulo = BaseDatos.obtenerArticuloPorIid(articulo.getIid());
        tTapaIzquierdaArea.setText(articulo.getDes_inf());
        tTapaDerechaArea.setText(articulo.getDes_inf());
    }

    protected void rellenarBambolina(Articulo articulo) {
        articulo = BaseDatos.obtenerArticuloPorIid(articulo.getIid());
        tBambolinaArea.setText(articulo.getDes_inf());
        tBambolinaAreaMedida.setText(calcularMedida("Bambolina"));
    }

    protected void rellenarBambolinaPlano(Articulo articulo) {
        articulo = BaseDatos.obtenerArticuloPorIid(articulo.getIid());
        tBambolinaPlanoArea.setText(articulo.getDes_inf());
        tBambolinaPlanoAreaMedida.setText(calcularMedida("Bambolina"));
    }

    protected void rellenarTuboEnrolle(Articulo articulo) {
        articulo = BaseDatos.obtenerArticuloPorIid(articulo.getIid());
        tTuboEnrrolleArea.setText(articulo.getDes_inf());
        tTuboEnrrolleAreaMedida.setText(calcularMedida("TuboEnrolle"));
    }

    protected void rellenarAtacuerdaPared(Articulo articulo) {
        articulo = BaseDatos.obtenerArticuloPorIid(articulo.getIid());
        tAtacuerdaParedArea.setText(articulo.getDes_inf());
    }

    protected void rellenarCarruchaDoble(Articulo articulo) {
        articulo = BaseDatos.obtenerArticuloPorIid(articulo.getIid());
        tCarruchaDobleArea.setText(articulo.getDes_inf());
    }

    protected void rellenarCarruchaSimple(Articulo articulo) {
        articulo = BaseDatos.obtenerArticuloPorIid(articulo.getIid());
        tCarruchaSimpleArea.setText(articulo.getDes_inf());
    }

    protected void rellenarGancho(Articulo articulo) {
        articulo = BaseDatos.obtenerArticuloPorIid(articulo.getIid());
        tGanchoIzquierdoArea.setText(articulo.getDes_inf());
        tGanchoDerechaArea.setText(articulo.getDes_inf());
    }

    protected void rellenarPoleaIzquierda(Articulo articulo) {
        articulo = BaseDatos.obtenerArticuloPorIid(articulo.getIid());
        tPoleaIzquierdaArea.setText(articulo.getDes_inf());
    }

    protected void rellenarPoleaDerecha(Articulo articulo) {
        articulo = BaseDatos.obtenerArticuloPorIid(articulo.getIid());
        tPoleaDerechaArea.setText(articulo.getDes_inf());
    }

    protected void rellenarAtacuerda(Articulo articulo) {
        articulo = BaseDatos.obtenerArticuloPorIid(articulo.getIid());
        tAtacuerdaArea.setText(articulo.getDes_inf());
    }

    protected void rellenarLona(Articulo articulo) {
        articulo = BaseDatos.obtenerArticuloPorIid(articulo.getIid());
        tTelaArea.setText(articulo.getDes_inf());
        tTelaAreaMedida.setText(calcularMedida("Lona"));
    }

    protected void actualizarListaDespiece() {
        try {
            Modelo modeloTemp = (Modelo) this.tDespiece.getModel();
            int j = modeloTemp.getRowCount();
            for (int i = 0; i < j; i++) {
                modeloTemp.removeRow(0);
            }

            String sCantidad = getCantidad();
            Float cantidad = 0F;

            if (sCantidad.length() > 0) {
                cantidad = Float.valueOf(Util.convertirComaAPunto(sCantidad));
            }

            Despiece des;
            Object[] fila;
            Articulo articulo;
            Object oCantidad;
            Iterator<Despiece> iter = listaDespiece.iterator();
            while (iter.hasNext()) {
                des = iter.next();
                articulo = BaseDatos.obtenerArticuloPorIid(des.getArticulo().getIid());
                oCantidad = cantidad * evaluar(des.getFormulaCantidad(), des.getRedondeo(), false);
                fila = new Object[4];
                fila[0] = Util.convertirPuntoAComa(String.valueOf(matematico.Matematico.redondear2decimales(Float.valueOf(String.valueOf(oCantidad.toString())))));
                fila[1] = articulo.getCod_articulo();
                fila[2] = articulo.getDes_inf();
                fila[3] = calcularMedida(des);
                if (!oCantidad.toString().equals("0.0") || this.verTodos) {
                    modeloTemp.addRow(fila);
                }

                if (des.getTipoArticulo().equals("Lona")) {
                    tTelaAreaMedida.setText((String) fila[3]);
                } else if (des.getTipoArticulo().equals("TuboEnrolle")) {
                    tTuboEnrrolleAreaMedida.setText((String) fila[3]);
                } else if (des.getTipoArticulo().equals("Perfil")) {
                    tPerfilPlanoAreaMedida.setText((String) fila[3]);
                    tPerfilAreaMedida.setText((String) fila[3]);
                } else if (des.getTipoArticulo().equals("Bambolina")) {
                    tBambolinaAreaMedida.setText((String) fila[3]);
                    tBambolinaPlanoAreaMedida.setText((String) fila[3]);
                } else if (des.getTipoArticulo().equals("PerfilCofre")) {
                    tPerfilCofreAreaMedida.setText((String) fila[3]);
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            log.error("Se ha producido una excepción en el método actualizarListaDespiece", ex);
        }
    }

    public void actualizarPrecio(int linea, Float precio) {
        //Actualizamos el precio de despiece en la linea indicada
        listaDespiece.get(linea).setPrecio(precio);
        //Establecemos el precio despiece como manual
        listaDespiece.get(linea).setManual("S");
        //Establecemos la linea de presupuesto como manual
        lPresupuesto.manual = true;
    }

    private String calcularMedida(String modificador) {
        Integer indiceDespiece = obtenerIndiceDespiece(modificador);
        Despiece despiece = null;
        if (indiceDespiece != null) {
            despiece = listaDespiece.get(indiceDespiece);
            despiece = new Despiece(despiece);
            return calcularMedida(despiece);
        } else {
            return " ";
        }
    }

    private String calcularMedida(Despiece des) {
        String res = "";
        int numMedidas = des.getNumeroDimensiones();

        if (numMedidas == 1) {
            res = "" + Util.convertirPuntoAComa(String.valueOf(evaluar(des.getFormulaMedida1(), Constantes.DECIMALES2, false)));
        } else if (numMedidas == 2) {
            res = Util.convertirPuntoAComa(String.valueOf(evaluar(des.getFormulaMedida1(), Constantes.DECIMALES2, false))) + "x" + Util.convertirPuntoAComa(String.valueOf(evaluar(des.getFormulaMedida2(), Constantes.DECIMALES2, false)));
        } else if (numMedidas == 3) {
            res = Util.convertirPuntoAComa(String.valueOf(evaluar(des.getFormulaMedida1(), Constantes.DECIMALES2, false))) + "x" + Util.convertirPuntoAComa(String.valueOf(evaluar(des.getFormulaMedida2(), Constantes.DECIMALES2, false))) + "x" + Util.convertirPuntoAComa(String.valueOf(evaluar(des.getFormulaMedida3(), Constantes.DECIMALES2, false)));
        } else if (numMedidas == 4) {
            res = Util.convertirPuntoAComa(String.valueOf(evaluar(des.getFormulaMedida1(), Constantes.DECIMALES2, false))) + "x" + Util.convertirPuntoAComa(String.valueOf(evaluar(des.getFormulaMedida2(), Constantes.DECIMALES2, false))) + "x" + Util.convertirPuntoAComa(String.valueOf(evaluar(des.getFormulaMedida3(), Constantes.DECIMALES2, false))) + "x" + Util.convertirPuntoAComa(String.valueOf(evaluar(des.getFormulaMedida4(), Constantes.DECIMALES2, false)));
        } else if (numMedidas == 5) {
            res = Util.convertirPuntoAComa(String.valueOf(evaluar(des.getFormulaMedida1(), Constantes.DECIMALES2, false))) + "x" + Util.convertirPuntoAComa(String.valueOf(evaluar(des.getFormulaMedida2(), Constantes.DECIMALES2, false))) + "x" + Util.convertirPuntoAComa(String.valueOf(evaluar(des.getFormulaMedida3(), Constantes.DECIMALES2, false))) + "x" + Util.convertirPuntoAComa(String.valueOf(evaluar(des.getFormulaMedida4(), Constantes.DECIMALES2, false))) + "x" + Util.convertirPuntoAComa(String.valueOf(evaluar(des.getFormulaMedida5(), Constantes.DECIMALES2, false)));
        }
        return res;
    }

    public String calcularMedidasStr(Despiece des) {
        String res = "";
        String magnitud1 = "";
        String magnitud2 = "";
        String magnitud3 = "";
        String magnitud4 = "";
        String magnitud5 = "";

        Articulo a = BaseDatos.obtenerArticuloPorIid(des.getArticulo().getIid());
        FamiliaVenta fv = BaseDatos.obtenerFamiliaVentaPorIid(a.getIid_fam_venta().getIid());
        TipoControl tc = BaseDatos.obtenerTipoControlPorIid(fv.getIid_tipo_control().getIid());
        if (tc != null) {
            UnidadMedida um;
            TipoMedida tm = BaseDatos.obtenerTipoMedidaByIid(tc.getIid_tipo_medida().getIid());

            if (tm.getUnidad_dim_1() != null) {
                um = BaseDatos.obtenerUnidadMedidaIid(tm.getUnidad_dim_1().getIid());
                if (um != null) {
                    magnitud1 = um.getCod_unidad_medida();
                }
            }

            if (tm.getUnidad_dim_2() != null) {
                um = BaseDatos.obtenerUnidadMedidaIid(tm.getUnidad_dim_2().getIid());
                if (um != null) {
                    magnitud2 = um.getCod_unidad_medida();
                }
            }
            if (tm.getUnidad_dim_3() != null) {
                um = BaseDatos.obtenerUnidadMedidaIid(tm.getUnidad_dim_3().getIid());
                if (um != null) {
                    magnitud3 = um.getCod_unidad_medida();
                }
            }
            if (tm.getUnidad_dim_4() != null) {
                um = BaseDatos.obtenerUnidadMedidaIid(tm.getUnidad_dim_4().getIid());
                if (um != null) {
                    magnitud4 = um.getCod_unidad_medida();
                }
            }
            if (tm.getUnidad_dim_5() != null) {
                um = BaseDatos.obtenerUnidadMedidaIid(tm.getUnidad_dim_5().getIid());
                if (um != null) {
                    magnitud5 = um.getCod_unidad_medida();
                }
            }
        }

        int numMedidas = des.getNumeroDimensiones();

        if (numMedidas == 1) {
            res = "" + Util.convertirPuntoAComa(String.valueOf(evaluar(des.getFormulaMedida1(), Constantes.DECIMALES2, false))) + magnitud1;
        } else if (numMedidas == 2) {
            res = Util.convertirPuntoAComa(String.valueOf(evaluar(des.getFormulaMedida1(), Constantes.DECIMALES2, false))) + magnitud1 + "x" + Util.convertirPuntoAComa(String.valueOf(evaluar(des.getFormulaMedida2(), Constantes.DECIMALES2, false))) + magnitud2;
        } else if (numMedidas == 3) {
            res = Util.convertirPuntoAComa(String.valueOf(evaluar(des.getFormulaMedida1(), Constantes.DECIMALES2, false))) + magnitud1 + "x" + Util.convertirPuntoAComa(String.valueOf(evaluar(des.getFormulaMedida2(), Constantes.DECIMALES2, false))) + magnitud2 + "x" + Util.convertirPuntoAComa(String.valueOf(evaluar(des.getFormulaMedida3(), Constantes.DECIMALES2, false))) + magnitud3;
        } else if (numMedidas == 4) {
            res = Util.convertirPuntoAComa(String.valueOf(evaluar(des.getFormulaMedida1(), Constantes.DECIMALES2, false))) + magnitud1 + "x" + Util.convertirPuntoAComa(String.valueOf(evaluar(des.getFormulaMedida2(), Constantes.DECIMALES2, false))) + magnitud2 + "x" + Util.convertirPuntoAComa(String.valueOf(evaluar(des.getFormulaMedida3(), Constantes.DECIMALES2, false))) + magnitud3 + "x" + Util.convertirPuntoAComa(String.valueOf(evaluar(des.getFormulaMedida4(), Constantes.DECIMALES2, false))) + magnitud4;
        } else if (numMedidas == 5) {
            res = Util.convertirPuntoAComa(String.valueOf(evaluar(des.getFormulaMedida1(), Constantes.DECIMALES2, false))) + magnitud1 + "x" + Util.convertirPuntoAComa(String.valueOf(evaluar(des.getFormulaMedida2(), Constantes.DECIMALES2, false))) + magnitud2 + "x" + Util.convertirPuntoAComa(String.valueOf(evaluar(des.getFormulaMedida3(), Constantes.DECIMALES2, false))) + magnitud3 + "x" + Util.convertirPuntoAComa(String.valueOf(evaluar(des.getFormulaMedida4(), Constantes.DECIMALES2, false))) + magnitud4 + "x" + Util.convertirPuntoAComa(String.valueOf(evaluar(des.getFormulaMedida5(), Constantes.DECIMALES2, false))) + magnitud5;
        }
        return res;
    }

    private Articulo obtenerArticulo(String tipoArticulo) {
        Iterator<Despiece> iter = listaDespiece.iterator();
        Despiece temp;
        while (iter.hasNext()) {
            temp = iter.next();
            if (temp.getTipoArticulo().equals(tipoArticulo)) {
                return BaseDatos.obtenerArticuloPorIid(temp.getArticulo().getIid());
            }
        }
        return null;
    }

    private void rellenarArticulosDespiece() {
        Articulo tempArticulo;
        Iterator<Despiece> iter = listaDespiece.iterator();
        Despiece temp;
        boolean hayBrazos = false, hayLonas = false, hayTuboEnrrolle = false, hayManivela = false;
        boolean haySoporte = false, hayCasquillo = false, hayMaquina = false, hayPerfil = false;
        boolean hayTerminal = false, hayTapa = false, hayPerfilCofre = false, hayBambolina = false;
        boolean hayAtacuerdaPared = false, hayCarruchaDoble = false, hayCarruchaSimple = false;
        boolean hayGancho = false, hayPoleaIzquierda = false, hayPoleaDerecha = false, hayAtacuerda = false;

        while (iter.hasNext()) {
            temp = iter.next();
            if (temp.getTipoArticulo().equals("Brazos") && dacBase.getBrazo()) {
                tempArticulo = BaseDatos.obtenerArticuloPorIid(temp.getArticulo().getIid());
                tBrazoIzquierdoArea.setText(tempArticulo.getDes_inf());
                tBrazoDerechoArea.setText(tempArticulo.getDes_inf());
                hayBrazos = true;
            } else if (temp.getTipoArticulo().equals("Lona") && dacBase.getLona()) {
                tempArticulo = BaseDatos.obtenerArticuloPorIid(temp.getArticulo().getIid());
                tTelaArea.setText(tempArticulo.getDes_inf());
                tTelaAreaMedida.setText(calcularMedida("Lona"));
                hayLonas = true;
            } else if (temp.getTipoArticulo().equals("TuboEnrolle") && dacBase.getTuboEnrrolle()) {
                tempArticulo = BaseDatos.obtenerArticuloPorIid(temp.getArticulo().getIid());
                tTuboEnrrolleArea.setText(tempArticulo.getDes_inf());
                tTuboEnrrolleAreaMedida.setText(calcularMedida("TuboEnrolle"));
                hayTuboEnrrolle = true;
            } else if (temp.getTipoArticulo().equals("Manivelas") && dacBase.getManivela()) {
                tempArticulo = BaseDatos.obtenerArticuloPorIid(temp.getArticulo().getIid());
                tManivelaArea.setText(tempArticulo.getCod_articulo());
                hayManivela = true;
            } else if (temp.getTipoArticulo().equals("Soporte") && dacBase.getSoporte()) {
                tempArticulo = BaseDatos.obtenerArticuloPorIid(temp.getArticulo().getIid());
                tSoporteIzquierdoArea.setText(tempArticulo.getDes_inf());
                tSoporteDerechoArea.setText(tempArticulo.getDes_inf());
                haySoporte = true;
            } else if (temp.getTipoArticulo().equals("Casquillo") && dacBase.getCasquillo()) {
                tempArticulo = BaseDatos.obtenerArticuloPorIid(temp.getArticulo().getIid());
                tCasquilloIzquierdoArea.setText(tempArticulo.getDes_inf());
                tCasquilloDerechoArea.setText(tempArticulo.getDes_inf());
                hayCasquillo = true;
            } else if (temp.getTipoArticulo().equals("Maquina") && dacBase.getMaquina()) {
                tempArticulo = BaseDatos.obtenerArticuloPorIid(temp.getArticulo().getIid());
                tMaquinaIzquierdaArea.setText(tempArticulo.getDes_inf());
                tMaquinaDerechaArea.setText(tempArticulo.getDes_inf());
                hayMaquina = true;
            } else if (temp.getTipoArticulo().equals("Perfil") && dacBase.getPerfil()) {
                tempArticulo = BaseDatos.obtenerArticuloPorIid(temp.getArticulo().getIid());
                if (dacBase.getTipoPlantilla().equals(Constantes.PLANTILLA_TOLDO_ENRROLLADO)) {
                    tPerfilArea.setText(tempArticulo.getDes_inf());
                    tPerfilAreaMedida.setText(calcularMedida("Perfil"));
                } else if (dacBase.getTipoPlantilla().equals(Constantes.PLANTILLA_TOLDO_PLANO)) {
                    tPerfilPlanoArea.setText(tempArticulo.getDes_inf());
                    tPerfilPlanoAreaMedida.setText(calcularMedida("Perfil"));
                }
            } else if (temp.getTipoArticulo().equals("Terminal") && dacBase.getTerminal()) {
                tempArticulo = BaseDatos.obtenerArticuloPorIid(temp.getArticulo().getIid());
                tTerminalIzquierdoArea.setText(tempArticulo.getDes_inf());
                tTerminalDerechoArea.setText(tempArticulo.getDes_inf());
                hayTerminal = true;
            } else if (temp.getTipoArticulo().equals("Tapa") && dacBase.getTapa()) {
                tempArticulo = BaseDatos.obtenerArticuloPorIid(temp.getArticulo().getIid());
                tTapaIzquierdaArea.setText(tempArticulo.getDes_inf());
                tTapaDerechaArea.setText(tempArticulo.getDes_inf());
                hayTapa = true;
            } else if (temp.getTipoArticulo().equals("PerfilCofre") && dacBase.getPerfilCofre()) {
                tempArticulo = BaseDatos.obtenerArticuloPorIid(temp.getArticulo().getIid());
                tPerfilCofreArea.setText(tempArticulo.getDes_inf());
                tPerfilCofreAreaMedida.setText(calcularMedida("PerfilCofre"));
                hayPerfilCofre = true;
            } else if (temp.getTipoArticulo().equals("Bambolina") && dacBase.getBambolina()) {
                tempArticulo = BaseDatos.obtenerArticuloPorIid(temp.getArticulo().getIid());
                if (dacBase.getTipoPlantilla().equals(Constantes.PLANTILLA_TOLDO_ENRROLLADO)) {
                    tBambolinaArea.setText(tempArticulo.getDes_inf());
                    tBambolinaAreaMedida.setText(calcularMedida("Bambolina"));
                } else if (dacBase.getTipoPlantilla().equals(Constantes.PLANTILLA_TOLDO_PLANO)) {
                    tBambolinaPlanoArea.setText(tempArticulo.getDes_inf());
                    tBambolinaPlanoAreaMedida.setText(calcularMedida("Bambolina"));
                }
                hayBambolina = true;
            } else if (temp.getTipoArticulo().equals("AtacuerdaPared") && dacBase.getAtacuerdaPared()) {
                tempArticulo = BaseDatos.obtenerArticuloPorIid(temp.getArticulo().getIid());
                tAtacuerdaParedArea.setText(tempArticulo.getDes_inf());
                hayAtacuerdaPared = true;
            } else if (temp.getTipoArticulo().equals("CarruchaDoble") && dacBase.getCarruchaDoble()) {
                tempArticulo = BaseDatos.obtenerArticuloPorIid(temp.getArticulo().getIid());
                tCarruchaDobleArea.setText(tempArticulo.getDes_inf());
                hayCarruchaDoble = true;
            } else if (temp.getTipoArticulo().equals("CarruchaSimple") && dacBase.getCarruchaSimple()) {
                tempArticulo = BaseDatos.obtenerArticuloPorIid(temp.getArticulo().getIid());
                tCarruchaSimpleArea.setText(tempArticulo.getDes_inf());
                hayCarruchaSimple = true;
            } else if (temp.getTipoArticulo().equals("Gancho") && dacBase.getGancho()) {
                tempArticulo = BaseDatos.obtenerArticuloPorIid(temp.getArticulo().getIid());
                tGanchoIzquierdoArea.setText(tempArticulo.getDes_inf());
                tGanchoDerechaArea.setText(tempArticulo.getDes_inf());
                hayGancho = true;
            } else if (temp.getTipoArticulo().equals("PoleaIzquierda") && dacBase.getPoleaIzquierda()) {
                tempArticulo = BaseDatos.obtenerArticuloPorIid(temp.getArticulo().getIid());
                tPoleaIzquierdaArea.setText(tempArticulo.getDes_inf());
                hayPoleaIzquierda = true;
            } else if (temp.getTipoArticulo().equals("PoleaDerecha") && dacBase.getPoleaDerecha()) {
                tempArticulo = BaseDatos.obtenerArticuloPorIid(temp.getArticulo().getIid());
                tPoleaDerechaArea.setText(tempArticulo.getDes_inf());
                hayPoleaDerecha = true;
            } else if (temp.getTipoArticulo().equals("Atacuerda") && dacBase.getAtacuerda()) {
                tempArticulo = BaseDatos.obtenerArticuloPorIid(temp.getArticulo().getIid());
                tAtacuerdaArea.setText(tempArticulo.getDes_inf());
                hayAtacuerda = true;
            }
        }

        if (!hayBrazos) {
            tBrazoIzquierdoArea.setText("");
            tBrazoDerechoArea.setText("");
        }
        if (!hayLonas) {
            tTelaArea.setText("");
            tTelaAreaMedida.setText(" ");
        }
        if (!hayTuboEnrrolle) {
            tTuboEnrrolleArea.setText("");
            tTuboEnrrolleAreaMedida.setText(calcularMedida("TuboEnrolle"));
        }
        if (!hayManivela) {
            tManivelaArea.setText("");
        }
        if (!haySoporte) {
            tSoporteIzquierdoArea.setText("");
            tSoporteDerechoArea.setText("");
        }
        if (!hayCasquillo) {
            tCasquilloIzquierdoArea.setText("");
            tCasquilloDerechoArea.setText("");
        }
        if (!hayMaquina) {
            tMaquinaIzquierdaArea.setText("");
            tMaquinaDerechaArea.setText("");
        }
        if (!hayPerfil) {
            if (dacBase.getTipoPlantilla().equals(Constantes.PLANTILLA_TOLDO_ENRROLLADO)) {
                tPerfilArea.setText("");
                tPerfilAreaMedida.setText(" ");
            } else if (dacBase.getTipoPlantilla().equals(Constantes.PLANTILLA_TOLDO_PLANO)) {
                tPerfilPlanoArea.setText("");
                tPerfilPlanoAreaMedida.setText(" ");
            }
        }
        if (!hayTerminal) {
            tTerminalIzquierdoArea.setText("");
            tTerminalDerechoArea.setText("");
        }
        if (!hayTapa) {
            tTapaIzquierdaArea.setText("");
            tTapaDerechaArea.setText("");
        }
        if (!hayPerfilCofre) {
            tPerfilCofreArea.setText("");
            tPerfilCofreAreaMedida.setText(" ");
        }
        if (!hayBambolina) {
            if (dacBase.getTipoPlantilla().equals(Constantes.PLANTILLA_TOLDO_ENRROLLADO)) {
                tBambolinaArea.setText("");
                tBambolinaAreaMedida.setText(" ");
            } else if (dacBase.getTipoPlantilla().equals(Constantes.PLANTILLA_TOLDO_PLANO)) {
                tBambolinaPlanoArea.setText("");
                tBambolinaPlanoAreaMedida.setText(" ");
            }
        }
        if (!hayAtacuerdaPared) {
            tAtacuerdaParedArea.setText("");
        }
        if (!hayCarruchaSimple) {
            tCarruchaSimpleArea.setText("");
        }
        if (!hayCarruchaDoble) {
            tCarruchaDobleArea.setText("");
        }
        if (!hayGancho) {
            tGanchoIzquierdoArea.setText("");
            tGanchoDerechaArea.setText("");
        }
        if (!hayPoleaIzquierda) {
            tPoleaIzquierdaArea.setText("");
        }
        if (!hayPoleaDerecha) {
            tPoleaDerechaArea.setText("");
        }
        if (!hayAtacuerda) {
            tAtacuerdaArea.setText("");
        }
    }

private void bSubirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bSubirActionPerformed
    int indice = this.tDespiece.getSelectedRow();

    if (indice > 0) {
        //Si hay alguno seleccionado se habrá de subir y cambiar su posicion
        //en la lista de despiece
        Modelo modelo = (Modelo) tDespiece.getModel();
        modelo.moveRow(indice, indice, indice - 1);
        tDespiece.setRowSelectionInterval(indice - 1, indice - 1);

        Despiece despieceOrigen = new Despiece(this.listaDespiece.get(indice));
        despieceOrigen.setOrden(indice - 1);
        listaDespiece.remove(indice);
        listaDespiece.add(indice - 1, despieceOrigen);
        actualizarIndicesSecuencialesDespieces();
    }
}//GEN-LAST:event_bSubirActionPerformed

private void bBajarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bBajarActionPerformed
    int indice = this.tDespiece.getSelectedRow();
    Modelo modelo = (Modelo) tDespiece.getModel();

    if (indice > -1 && indice < modelo.getRowCount() - 1) {
        //Si hay alguno seleccionado se habrá de bajar y cambiar su posicion
        //en la lista de despiece
        modelo.moveRow(indice, indice, indice + 1);
        tDespiece.setRowSelectionInterval(indice + 1, indice + 1);

        Despiece despieceOrigen = new Despiece(this.listaDespiece.get(indice));
        despieceOrigen.setOrden(indice + 1);
        listaDespiece.remove(indice);
        listaDespiece.add(indice + 1, despieceOrigen);
        actualizarIndicesSecuencialesDespieces();
    }

}//GEN-LAST:event_bBajarActionPerformed

private void bAñadirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bAñadirActionPerformed
    //Se inserta al final
    insertarDespiecePosicion(listaDespiece.size());
}//GEN-LAST:event_bAñadirActionPerformed

private void bInsertarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bInsertarActionPerformed
    //Se inserta despues del seleccionado
    if (listaDespiece.size() > 0) {
        int indice = this.tDespiece.getSelectedRow();
        if (indice != -1) {
            insertarDespiecePosicion(indice);
        } else {
            JOptionPane.showMessageDialog(null, "Debe seleccionar un elemento de la lista", "Error", JOptionPane.ERROR_MESSAGE);
        }
    } else {
        insertarDespiecePosicion(0);
    }
}//GEN-LAST:event_bInsertarActionPerformed

    private void insertarDespiecePosicion(int posicion) {
        Despiece despiece = new Despiece();
        despiece.setOrden(posicion);
        configurar(new NuevoArticuloOpcion(e, dac, this, despiece));
    }

private void bModificarDespieceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bModificarDespieceActionPerformed
    modificarDespiece();
}//GEN-LAST:event_bModificarDespieceActionPerformed

    private void modificarDespiece() {
        Despiece despiece = null;
        int indice = this.tDespiece.getSelectedRow();

        if (indice < 0) {
            JOptionPane.showMessageDialog(null, "Debe seleccionar un elemento de la lista", "Error", JOptionPane.ERROR_MESSAGE);
        } else if (verTodos) {
            //despiece = listaDespiece.get(indice);
            //despiece = new Despiece(despiece);
            despiece = new Despiece(listaDespiece.get(indice));
        } else {
            int indNulo = 0;
            int indNoNulo = 0;
            boolean seguir = true;
            Iterator<Despiece> iter = listaDespiece.iterator();
            Despiece des;
            Object oCantidad;
            String sCantidad = getCantidad();
            Float cantidad = (sCantidad.length() == 0) ? 0F : Float.valueOf(Util.convertirComaAPunto(sCantidad));

            while (iter.hasNext() && seguir) {
                des = iter.next();
                oCantidad = cantidad * evaluar(des.getFormulaCantidad(), des.getRedondeo(), false);
                if ((Double) oCantidad > 0) {
                    if (indice == indNoNulo) {
                        seguir = false;
                        despiece = new Despiece(des);
                    } else {
                        indNoNulo++;
                    }
                } else {
                    indNulo++;
                }
            }
            configurar(new NuevoArticuloOpcion(e, dac, BaseDatos.obtenerArticuloPorIid(despiece.getArticulo().getIid()), despiece.getCaracteristica(), this, despiece));
        }
    }

private void bBorrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bBorrarActionPerformed
    int indice = this.tDespiece.getSelectedRow();

    if (indice > -1 && indice < tDespiece.getRowCount()) {
        Modelo modelo = (Modelo) tDespiece.getModel();
        modelo.removeRow(indice);

        Despiece d = listaDespiece.get(indice);
        String tipoArticuloAntiguo = d.getTipoArticulo();

        if (tipoArticuloAntiguo != null && tipoArticuloAntiguo.equals("TuboEnrolle")) {
            tTuboEnrrolleArea.setText("");
            tTuboEnrrolleAreaMedida.setText(" ");
        } else if (tipoArticuloAntiguo != null && tipoArticuloAntiguo.equals("Manivelas")) {
            tManivelaArea.setText("");
        } else if (tipoArticuloAntiguo != null && tipoArticuloAntiguo.equals("Lona")) {
            tTelaArea.setText("");
            tTelaAreaMedida.setText(" ");
        } else if (tipoArticuloAntiguo != null && tipoArticuloAntiguo.equals("Brazos")) {
            tBrazoIzquierdoArea.setText("");
            tBrazoDerechoArea.setText("");
        } else if (tipoArticuloAntiguo != null && tipoArticuloAntiguo.equals("Soporte")) {
            tSoporteIzquierdoArea.setText("");
            tSoporteDerechoArea.setText("");
        } else if (tipoArticuloAntiguo != null && tipoArticuloAntiguo.equals("Casquillo")) {
            tCasquilloIzquierdoArea.setText("");
            tCasquilloDerechoArea.setText("");
        } else if (tipoArticuloAntiguo != null && tipoArticuloAntiguo.equals("Maquina")) {
            tMaquinaIzquierdaArea.setText("");
            tMaquinaDerechaArea.setText("");
        } else if (tipoArticuloAntiguo != null && tipoArticuloAntiguo.equals("Terminal")) {
            tTerminalIzquierdoArea.setText("");
            tTerminalDerechoArea.setText("");
        } else if (tipoArticuloAntiguo != null && tipoArticuloAntiguo.equals("Tapa")) {
            tTapaIzquierdaArea.setText("");
            tTapaDerechaArea.setText("");
        } else if (tipoArticuloAntiguo != null && tipoArticuloAntiguo.equals("PerfilCofre")) {
            tPerfilCofreArea.setText("");
            tPerfilCofreAreaMedida.setText(" ");
        } else if (tipoArticuloAntiguo != null && tipoArticuloAntiguo.equals("Perfil")) {
            if (dacBase.getTipoPlantilla().equals(Constantes.PLANTILLA_TOLDO_ENRROLLADO)) {
                tPerfilArea.setText("");
                tPerfilAreaMedida.setText(" ");
            } else if (dacBase.getTipoPlantilla().equals(Constantes.PLANTILLA_TOLDO_PLANO)) {
                tPerfilPlanoArea.setText("");
                tPerfilPlanoAreaMedida.setText(" ");
            }
        } else if (tipoArticuloAntiguo != null && tipoArticuloAntiguo.equals("Bambolina")) {
            if (dacBase.getTipoPlantilla().equals(Constantes.PLANTILLA_TOLDO_ENRROLLADO)) {
                tBambolinaArea.setText("");
                tBambolinaAreaMedida.setText(" ");
            } else if (dacBase.getTipoPlantilla().equals(Constantes.PLANTILLA_TOLDO_PLANO)) {
                tBambolinaPlanoArea.setText("");
                tBambolinaPlanoAreaMedida.setText(" ");
            }
        } else if (tipoArticuloAntiguo != null && tipoArticuloAntiguo.equals("Gancho")) {
            tGanchoIzquierdoArea.setText(" ");
            tGanchoDerechaArea.setText(" ");
        } else if (tipoArticuloAntiguo != null && tipoArticuloAntiguo.equals("CarruchaDoble")) {
            tCarruchaDobleArea.setText(" ");
        } else if (tipoArticuloAntiguo != null && tipoArticuloAntiguo.equals("CarruchaSimple")) {
            tCarruchaSimpleArea.setText(" ");
        } else if (tipoArticuloAntiguo != null && tipoArticuloAntiguo.equals("AtacuerdaPared")) {
            tAtacuerdaParedArea.setText(" ");
        } else if (tipoArticuloAntiguo != null && tipoArticuloAntiguo.equals("PoleaIzquierda")) {
            this.tPoleaIzquierdaArea.setText(" ");
        } else if (tipoArticuloAntiguo != null && tipoArticuloAntiguo.equals("PoleaDerecha")) {
            this.tPoleaDerechaArea.setText(" ");
        } else if (tipoArticuloAntiguo != null && tipoArticuloAntiguo.equals("Atacuerda")) {
            this.tAtacuerdaArea.setText(" ");
        }

        listaDespiece.remove(indice);
        actualizarIndicesSecuencialesDespieces();
    }

}//GEN-LAST:event_bBorrarActionPerformed

    private void resetearTipoArticuloDespiece(String tipoArticuloDespiece, String tipoArticuloDespieceAntiguo) {
        if (this.listaDespiece == null) {
            listaDespiece = new ArrayList<Despiece>();
        } else {
            Iterator<Despiece> iter = listaDespiece.iterator();
            Despiece temporal;
            while (iter.hasNext()) {
                temporal = iter.next();
                if (temporal.getTipoArticulo().equals(tipoArticuloDespiece) || temporal.getTipoArticulo().equals(tipoArticuloDespieceAntiguo)) {
                    temporal.setTipoArticulo("");
                }
            }
        }
    }

    private void resetearTipoArticuloDespiece(String tipoArticuloDespiece) {
        if (this.listaDespiece == null) {
            listaDespiece = new ArrayList<Despiece>();
        } else {
            Iterator<Despiece> iter = listaDespiece.iterator();
            Despiece temporal;
            while (iter.hasNext()) {
                temporal = iter.next();
                if (temporal.getTipoArticulo().equals(tipoArticuloDespiece)) {
                    temporal.setTipoArticulo("");
                }
            }
        }
    }

    private void actualizarIndicesSecuencialesDespieces() {
        if (this.listaDespiece == null) {
            listaDespiece = new ArrayList<Despiece>();
        } else {
            Iterator<Despiece> iter = listaDespiece.iterator();
            Despiece temporal;
            int contador = 0;
            while (iter.hasNext()) {
                temporal = iter.next();
                temporal.setOrden(contador);
                contador++;
            }
        }
    }

private void bVerTodosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bVerTodosActionPerformed
    this.verTodos = !this.verTodos;
    actualizarListaDespiece();
}//GEN-LAST:event_bVerTodosActionPerformed

private void tCantidadKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tCantidadKeyReleased
    int codigo = evt.getKeyCode();
    if (codigo != KeyEvent.VK_BACK_SPACE && codigo != KeyEvent.VK_ENTER && codigo != KeyEvent.VK_DELETE && codigo != KeyEvent.VK_LEFT && codigo != KeyEvent.VK_RIGHT) {
        char c = evt.getKeyChar();
        int carePosition = tCantidad.getCaretPosition();
        String contenidoAntiguo = tCantidad.getText().replace(".", ",");
        int indiceComaPuntoUltimo = contenidoAntiguo.lastIndexOf(",");
        int indiceComaPuntoPrimero = contenidoAntiguo.indexOf(',');

        if (!(c >= '0' && c <= '9') && c != '.' && c != ',') {
            contenidoAntiguo = contenidoAntiguo.replace(String.valueOf(c), "");
            carePosition--;
        }

        if (indiceComaPuntoUltimo != indiceComaPuntoPrimero) {
            contenidoAntiguo = contenidoAntiguo.replaceFirst(",", "");
            if (indiceComaPuntoUltimo <= carePosition) {
                carePosition--;
            }
        }

        if (carePosition > contenidoAntiguo.length()) {
            carePosition = contenidoAntiguo.length();
        }

        tCantidad.setText(contenidoAntiguo);
        tCantidad.setCaretPosition(carePosition);
        engineGlobal.put("Cantidad", Double.valueOf(Util.convertirComaAPunto(getCantidad())));
        actualizarVariables();
        actualizarListaDespiece();
    } else if (codigo == KeyEvent.VK_BACK_SPACE || codigo == KeyEvent.VK_DELETE) {
        engineGlobal.put("Cantidad", Double.valueOf(Util.convertirComaAPunto(getCantidad())));
        actualizarVariables();
        actualizarListaDespiece();
    }
}//GEN-LAST:event_tCantidadKeyReleased

private void tMedida1KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tMedida1KeyReleased
    int codigo = evt.getKeyCode();
    if (codigo != KeyEvent.VK_BACK_SPACE && codigo != KeyEvent.VK_ENTER && codigo != KeyEvent.VK_DELETE && codigo != KeyEvent.VK_LEFT && codigo != KeyEvent.VK_RIGHT) {
        char c = evt.getKeyChar();
        int carePosition = tMedida1.getCaretPosition();
        String contenidoAntiguo = tMedida1.getText().replace(".", ",");
        int indiceComaPuntoUltimo = contenidoAntiguo.lastIndexOf(",");
        int indiceComaPuntoPrimero = contenidoAntiguo.indexOf(',');

        if (!(c >= '0' && c <= '9') && c != '.' && c != ',') {
            contenidoAntiguo = contenidoAntiguo.replace(String.valueOf(c), "");
            carePosition--;
        }

        if (indiceComaPuntoUltimo != indiceComaPuntoPrimero) {
            contenidoAntiguo = contenidoAntiguo.replaceFirst(",", "");
            if (indiceComaPuntoUltimo <= carePosition) {
                carePosition--;
            }
        }

        if (carePosition > contenidoAntiguo.length()) {
            carePosition = contenidoAntiguo.length();
        }
        tMedida1.setText(contenidoAntiguo);
        tMedida1.setCaretPosition(carePosition);
        engineGlobal.put("Dim1", Double.valueOf(Util.convertirComaAPunto(getDim1())));
        actualizarVariables();
        actualizarListaDespiece();
    } else if (codigo == KeyEvent.VK_BACK_SPACE || codigo == KeyEvent.VK_DELETE) {
        engineGlobal.put("Dim1", Double.valueOf(Util.convertirComaAPunto(getDim1())));
        actualizarVariables();
        actualizarListaDespiece();
    }
}//GEN-LAST:event_tMedida1KeyReleased

private void tMedida2KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tMedida2KeyReleased
    int codigo = evt.getKeyCode();
    if (codigo != KeyEvent.VK_BACK_SPACE && codigo != KeyEvent.VK_ENTER && codigo != KeyEvent.VK_DELETE && codigo != KeyEvent.VK_LEFT && codigo != KeyEvent.VK_RIGHT) {
        char c = evt.getKeyChar();
        int carePosition = tMedida2.getCaretPosition();
        String contenidoAntiguo = tMedida2.getText().replace(".", ",");
        int indiceComaPuntoUltimo = contenidoAntiguo.lastIndexOf(",");
        int indiceComaPuntoPrimero = contenidoAntiguo.indexOf(',');

        if (!(c >= '0' && c <= '9') && c != '.' && c != ',') {
            contenidoAntiguo = contenidoAntiguo.replace(String.valueOf(c), "");
            carePosition--;
        }

        if (indiceComaPuntoUltimo != indiceComaPuntoPrimero) {
            contenidoAntiguo = contenidoAntiguo.replaceFirst(",", "");
            if (indiceComaPuntoUltimo <= carePosition) {
                carePosition--;
            }
        }

        if (carePosition > contenidoAntiguo.length()) {
            carePosition = contenidoAntiguo.length();
        }

        tMedida2.setText(contenidoAntiguo);
        tMedida2.setCaretPosition(carePosition);
        engineGlobal.put("Dim2", Double.valueOf(Util.convertirComaAPunto(getDim2())));
        actualizarVariables();
        actualizarListaDespiece();
    } else if (codigo == KeyEvent.VK_BACK_SPACE || codigo == KeyEvent.VK_DELETE) {
        engineGlobal.put("Dim2", Double.valueOf(Util.convertirComaAPunto(getDim2())));
        actualizarVariables();
        actualizarListaDespiece();
    }
}//GEN-LAST:event_tMedida2KeyReleased

private void tMedida3KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tMedida3KeyReleased
    int codigo = evt.getKeyCode();
    if (codigo != KeyEvent.VK_BACK_SPACE && codigo != KeyEvent.VK_ENTER && codigo != KeyEvent.VK_DELETE && codigo != KeyEvent.VK_LEFT && codigo != KeyEvent.VK_RIGHT) {
        char c = evt.getKeyChar();
        int carePosition = tMedida3.getCaretPosition();
        String contenidoAntiguo = tMedida3.getText().replace(".", ",");
        int indiceComaPuntoUltimo = contenidoAntiguo.lastIndexOf(",");
        int indiceComaPuntoPrimero = contenidoAntiguo.indexOf(',');

        if (!(c >= '0' && c <= '9') && c != '.' && c != ',') {
            contenidoAntiguo = contenidoAntiguo.replace(String.valueOf(c), "");
            carePosition--;
        }

        if (indiceComaPuntoUltimo != indiceComaPuntoPrimero) {
            contenidoAntiguo = contenidoAntiguo.replaceFirst(",", "");
            if (indiceComaPuntoUltimo <= carePosition) {
                carePosition--;
            }
        }

        if (carePosition > contenidoAntiguo.length()) {
            carePosition = contenidoAntiguo.length();
        }

        tMedida3.setText(contenidoAntiguo);
        tMedida3.setCaretPosition(carePosition);
        engineGlobal.put("Dim3", Double.valueOf(Util.convertirComaAPunto(getDim3())));
        actualizarVariables();
        actualizarListaDespiece();
    } else if (codigo == KeyEvent.VK_BACK_SPACE || codigo == KeyEvent.VK_DELETE) {
        engineGlobal.put("Dim3", Double.valueOf(Util.convertirComaAPunto(getDim3())));
        actualizarVariables();
        actualizarListaDespiece();
    }
}//GEN-LAST:event_tMedida3KeyReleased

private void tMedida4KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tMedida4KeyReleased
    int codigo = evt.getKeyCode();
    if (codigo != KeyEvent.VK_BACK_SPACE && codigo != KeyEvent.VK_ENTER && codigo != KeyEvent.VK_DELETE && codigo != KeyEvent.VK_LEFT && codigo != KeyEvent.VK_RIGHT) {
        char c = evt.getKeyChar();
        int carePosition = tMedida4.getCaretPosition();
        String contenidoAntiguo = tMedida4.getText().replace(".", ",");
        int indiceComaPuntoUltimo = contenidoAntiguo.lastIndexOf(",");
        int indiceComaPuntoPrimero = contenidoAntiguo.indexOf(',');

        if (!(c >= '0' && c <= '9') && c != '.' && c != ',') {
            contenidoAntiguo = contenidoAntiguo.replace(String.valueOf(c), "");
            carePosition--;
        }

        if (indiceComaPuntoUltimo != indiceComaPuntoPrimero) {
            contenidoAntiguo = contenidoAntiguo.replaceFirst(",", "");
            if (indiceComaPuntoUltimo <= carePosition) {
                carePosition--;
            }
        }

        if (carePosition > contenidoAntiguo.length()) {
            carePosition = contenidoAntiguo.length();
        }

        tMedida4.setText(contenidoAntiguo);
        tMedida4.setCaretPosition(carePosition);
        engineGlobal.put("Dim4", Double.valueOf(Util.convertirComaAPunto(getDim4())));
        actualizarVariables();
        actualizarListaDespiece();
    } else if (codigo == KeyEvent.VK_BACK_SPACE || codigo == KeyEvent.VK_DELETE) {
        engineGlobal.put("Dim4", Double.valueOf(Util.convertirComaAPunto(getDim4())));
        actualizarVariables();
        actualizarListaDespiece();
    }
}//GEN-LAST:event_tMedida4KeyReleased

private void tMedida5KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tMedida5KeyReleased
    int codigo = evt.getKeyCode();
    if (codigo != KeyEvent.VK_BACK_SPACE && codigo != KeyEvent.VK_ENTER && codigo != KeyEvent.VK_DELETE && codigo != KeyEvent.VK_LEFT && codigo != KeyEvent.VK_RIGHT) {
        char c = evt.getKeyChar();
        int carePosition = tMedida5.getCaretPosition();
        String contenidoAntiguo = tMedida5.getText().replace(".", ",");
        int indiceComaPuntoUltimo = contenidoAntiguo.lastIndexOf(",");
        int indiceComaPuntoPrimero = contenidoAntiguo.indexOf(',');

        if (!(c >= '0' && c <= '9') && c != '.' && c != ',') {
            contenidoAntiguo = contenidoAntiguo.replace(String.valueOf(c), "");
            carePosition--;
        }

        if (indiceComaPuntoUltimo != indiceComaPuntoPrimero) {
            contenidoAntiguo = contenidoAntiguo.replaceFirst(",", "");
            if (indiceComaPuntoUltimo <= carePosition) {
                carePosition--;
            }
        }

        if (carePosition > contenidoAntiguo.length()) {
            carePosition = contenidoAntiguo.length();
        }

        tMedida5.setText(contenidoAntiguo);
        tMedida5.setCaretPosition(carePosition);
        engineGlobal.put("Dim5", Double.valueOf(Util.convertirComaAPunto(getDim5())));
        actualizarVariables();
        actualizarListaDespiece();
    } else if (codigo == KeyEvent.VK_BACK_SPACE || codigo == KeyEvent.VK_DELETE) {
        engineGlobal.put("Dim5", Double.valueOf(Util.convertirComaAPunto(getDim5())));
        actualizarVariables();
        actualizarListaDespiece();
    }
}//GEN-LAST:event_tMedida5KeyReleased

private void tDespieceMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tDespieceMouseClicked
    if (evt.getClickCount() == 2) {
        modificarDespiece();
    }
}//GEN-LAST:event_tDespieceMouseClicked

private void tCantidadFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_tCantidadFocusGained
    cantidadAntesFoco = 0D;
    if (tCantidad.getText().length() != 0) {
        cantidadAntesFoco = new Double(Util.convertirComaAPunto(tCantidad.getText()));
    }
}//GEN-LAST:event_tCantidadFocusGained

private void tCantidadFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_tCantidadFocusLost
    cantidadDespuesFoco = 0D;
    if (tCantidad.getText().length() != 0) {
        cantidadDespuesFoco = new Double(Util.convertirComaAPunto(tCantidad.getText()));
    }
    if (!cantidadAntesFoco.equals(cantidadDespuesFoco)) {
        eliminarCortes = true;
    }
}//GEN-LAST:event_tCantidadFocusLost

private void tMedida1FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_tMedida1FocusGained
    medida1AntesFoco = 0D;
    if (tMedida1.getText().length() != 0) {
        medida1AntesFoco = new Double(Util.convertirComaAPunto(tMedida1.getText()));
    }
}//GEN-LAST:event_tMedida1FocusGained

private void tMedida1FocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_tMedida1FocusLost
    medida1DespuesFoco = 0D;
    if (tMedida1.getText().length() != 0) {
        medida1DespuesFoco = new Double(Util.convertirComaAPunto(tMedida1.getText()));
    }
    if (!medida1AntesFoco.equals(medida1DespuesFoco)) {
        eliminarCortes = true;
    }
}//GEN-LAST:event_tMedida1FocusLost

private void tMedida2FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_tMedida2FocusGained
    medida2AntesFoco = 0D;
    if (tMedida2.getText().length() != 0) {
        medida2AntesFoco = new Double(Util.convertirComaAPunto(tMedida2.getText()));
    }
}//GEN-LAST:event_tMedida2FocusGained

private void tMedida2FocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_tMedida2FocusLost
    medida2DespuesFoco = 0D;
    if (tMedida2.getText().length() != 0) {
        medida2DespuesFoco = new Double(Util.convertirComaAPunto(tMedida2.getText()));
    }
    if (!medida2AntesFoco.equals(medida2DespuesFoco)) {
        eliminarCortes = true;
    }
}//GEN-LAST:event_tMedida2FocusLost

private void tMedida3FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_tMedida3FocusGained
    medida3AntesFoco = 0D;
    if (tMedida3.getText().length() != 0) {
        medida3AntesFoco = new Double(Util.convertirComaAPunto(tMedida3.getText()));
    }
}//GEN-LAST:event_tMedida3FocusGained

private void tMedida3FocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_tMedida3FocusLost
    medida3DespuesFoco = 0D;
    if (tMedida3.getText().length() != 0) {
        medida3DespuesFoco = new Double(Util.convertirComaAPunto(tMedida3.getText()));
    }
    if (!medida3AntesFoco.equals(medida3DespuesFoco)) {
        eliminarCortes = true;
    }
}//GEN-LAST:event_tMedida3FocusLost

private void tMedida4FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_tMedida4FocusGained
    medida4AntesFoco = 0D;
    if (tMedida4.getText().length() != 0) {
        medida4AntesFoco = new Double(Util.convertirComaAPunto(tMedida4.getText()));
    }
}//GEN-LAST:event_tMedida4FocusGained

private void tMedida4FocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_tMedida4FocusLost
    medida4DespuesFoco = 0D;
    if (tMedida4.getText().length() != 0) {
        medida4DespuesFoco = new Double(Util.convertirComaAPunto(tMedida4.getText()));
    }
    if (!medida4AntesFoco.equals(medida4DespuesFoco)) {
        eliminarCortes = true;
    }
}//GEN-LAST:event_tMedida4FocusLost

private void tMedida5FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_tMedida5FocusGained
    medida5AntesFoco = 0D;
    if (tMedida5.getText().length() != 0) {
        medida5AntesFoco = new Double(Util.convertirComaAPunto(tMedida5.getText()));
    }
}//GEN-LAST:event_tMedida5FocusGained

private void tMedida5FocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_tMedida5FocusLost
    medida5DespuesFoco = 0D;
    if (tMedida5.getText().length() != 0) {
        medida5DespuesFoco = new Double(Util.convertirComaAPunto(tMedida5.getText()));
    }
    if (!medida5AntesFoco.equals(medida5DespuesFoco)) {
        eliminarCortes = true;
    }
}//GEN-LAST:event_tMedida5FocusLost

private void bSoporteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bSoporteActionPerformed
    Integer indiceDespiece = obtenerIndiceDespiece("Soporte");
    Despiece despiece = null;
    if (indiceDespiece != null) {
        despiece = new Despiece(listaDespiece.get(indiceDespiece));
    } else {
        despiece = new Despiece();
    }
    configurar(new NuevoArticuloOpcion(e, "Soporte", obtenerArticulo("Soporte"), despiece.getCaracteristica(), dac, this, despiece, "Soporte"));
}//GEN-LAST:event_bSoporteActionPerformed

private void bMaquinaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bMaquinaActionPerformed
    Integer indiceDespiece = obtenerIndiceDespiece("Maquina");
    Despiece despiece = null;
    if (indiceDespiece != null) {
        despiece = new Despiece(listaDespiece.get(indiceDespiece));
    } else {
        despiece = new Despiece();
    }
    configurar(new NuevoArticuloOpcion(e, "Maquina", obtenerArticulo("Maquina"), despiece.getCaracteristica(), dac, this, despiece, "Máquina"));
}//GEN-LAST:event_bMaquinaActionPerformed

private void bCasquilloActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bCasquilloActionPerformed
    Integer indiceDespiece = obtenerIndiceDespiece("Casquillo");
    Despiece despiece = null;
    if (indiceDespiece != null) {
        despiece = new Despiece(listaDespiece.get(indiceDespiece));
    } else {
        despiece = new Despiece();
    }
    configurar(new NuevoArticuloOpcion(e, "Casquillo", obtenerArticulo("Casquillo"), despiece.getCaracteristica(), dac, this, despiece, "Casquillo"));
}//GEN-LAST:event_bCasquilloActionPerformed

private void bTuboEnrrolleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bTuboEnrrolleActionPerformed
    Integer indiceDespiece = obtenerIndiceDespiece("TuboEnrolle");
    Despiece despiece = null;
    if (indiceDespiece != null) {
        despiece = new Despiece(listaDespiece.get(indiceDespiece));
    } else {
        despiece = new Despiece();
    }
    configurar(new NuevoArticuloOpcion(e, "TuboEnrolle", obtenerArticulo("TuboEnrolle"), despiece.getCaracteristica(), dac, this, despiece, "Tubo enrolle"));
}//GEN-LAST:event_bTuboEnrrolleActionPerformed

private void bManivelaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bManivelaActionPerformed
    Integer indiceDespiece = obtenerIndiceDespiece("Manivelas");
    Despiece despiece = null;
    if (indiceDespiece != null) {
        despiece = new Despiece(listaDespiece.get(indiceDespiece));
    } else {
        despiece = new Despiece();
    }
    configurar(new NuevoArticuloOpcion(e, "Manivelas", obtenerArticulo("Manivelas"), despiece.getCaracteristica(), dac, this, despiece, "Manivelas"));
}//GEN-LAST:event_bManivelaActionPerformed

private void bBrazoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bBrazoActionPerformed
    Integer indiceDespiece = obtenerIndiceDespiece("Brazos");
    Despiece despiece = null;
    if (indiceDespiece != null) {
        despiece = new Despiece(listaDespiece.get(indiceDespiece));
    } else {
        despiece = new Despiece();
    }
    configurar(new NuevoArticuloOpcion(e, "Brazos", obtenerArticulo("Brazos"), despiece.getCaracteristica(), dac, this, despiece, "Brazos"));
}//GEN-LAST:event_bBrazoActionPerformed

private void bLonaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bLonaActionPerformed
    Integer indiceDespiece = obtenerIndiceDespiece("Lona");
    Despiece despiece = null;
    if (indiceDespiece != null) {
        despiece = new Despiece(listaDespiece.get(indiceDespiece));
    } else {
        despiece = new Despiece();
    }
    configurar(new NuevoArticuloOpcion(e, "Lona", obtenerArticulo("Lona"), despiece.getCaracteristica(), dac, this, despiece, "Lona"));
}//GEN-LAST:event_bLonaActionPerformed

private void bPerfilActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bPerfilActionPerformed
    Integer indiceDespiece = obtenerIndiceDespiece("Perfil");
    Despiece despiece = null;
    if (indiceDespiece != null) {
        despiece = new Despiece(listaDespiece.get(indiceDespiece));
    } else {
        despiece = new Despiece();
    }
    configurar(new NuevoArticuloOpcion(e, "Perfil", obtenerArticulo("Perfil"), despiece.getCaracteristica(), dac, this, despiece, "Perfil"));
}//GEN-LAST:event_bPerfilActionPerformed

private void bBambolinaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bBambolinaActionPerformed
    Integer indiceDespiece = obtenerIndiceDespiece("Bambolina");
    Despiece despiece = null;
    if (indiceDespiece != null) {
        despiece = new Despiece(listaDespiece.get(indiceDespiece));
    } else {
        despiece = new Despiece();
    }
    configurar(new NuevoArticuloOpcion(e, "Bambolina", obtenerArticulo("Bambolina"), despiece.getCaracteristica(), dac, this, despiece, "Bambolina"));
}//GEN-LAST:event_bBambolinaActionPerformed

private void bTerminalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bTerminalActionPerformed
    Integer indiceDespiece = obtenerIndiceDespiece("Terminal");
    Despiece despiece = null;
    if (indiceDespiece != null) {
        despiece = new Despiece(listaDespiece.get(indiceDespiece));
    } else {
        despiece = new Despiece();
    }
    configurar(new NuevoArticuloOpcion(e, "Terminal", obtenerArticulo("Terminal"), despiece.getCaracteristica(), dac, this, despiece, "Terminal"));
}//GEN-LAST:event_bTerminalActionPerformed

private void bTapaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bTapaActionPerformed
    Integer indiceDespiece = obtenerIndiceDespiece("Tapa");
    Despiece despiece = null;
    if (indiceDespiece != null) {
        despiece = new Despiece(listaDespiece.get(indiceDespiece));
    } else {
        despiece = new Despiece();
    }
    configurar(new NuevoArticuloOpcion(e, "Tapa", obtenerArticulo("Tapa"), despiece.getCaracteristica(), dac, this, despiece, "Tapa"));
}//GEN-LAST:event_bTapaActionPerformed

private void bAtacuerdaParedActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bAtacuerdaParedActionPerformed
    Integer indiceDespiece = obtenerIndiceDespiece("AtacuerdaPared");
    Despiece despiece = null;
    if (indiceDespiece != null) {
        despiece = new Despiece(listaDespiece.get(indiceDespiece));
    } else {
        despiece = new Despiece();
    }
    configurar(new NuevoArticuloOpcion(e, "AtacuerdaPared", obtenerArticulo("AtacuerdaPared"), despiece.getCaracteristica(), dac, this, despiece, "Atacuerda pared"));
}//GEN-LAST:event_bAtacuerdaParedActionPerformed

private void bCarruchaDobleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bCarruchaDobleActionPerformed
    Integer indiceDespiece = obtenerIndiceDespiece("CarruchaDoble");
    Despiece despiece = null;
    if (indiceDespiece != null) {
        despiece = new Despiece(listaDespiece.get(indiceDespiece));
    } else {
        despiece = new Despiece();
    }
    configurar(new NuevoArticuloOpcion(e, "CarruchaDoble", obtenerArticulo("CarruchaDoble"), despiece.getCaracteristica(), dac, this, despiece, "Carrucha doble"));
}//GEN-LAST:event_bCarruchaDobleActionPerformed

private void bPerfilPlanoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bPerfilPlanoActionPerformed
    Integer indiceDespiece = obtenerIndiceDespiece("Perfil");
    Despiece despiece = null;
    if (indiceDespiece != null) {
        despiece = new Despiece(listaDespiece.get(indiceDespiece));
    } else {
        despiece = new Despiece();
    }
    configurar(new NuevoArticuloOpcion(e, "Perfil", obtenerArticulo("Perfil"), despiece.getCaracteristica(), dac, this, despiece, "Perfil"));
}//GEN-LAST:event_bPerfilPlanoActionPerformed

private void bGanchoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bGanchoActionPerformed
    Integer indiceDespiece = obtenerIndiceDespiece("Gancho");
    Despiece despiece = null;
    if (indiceDespiece != null) {
        despiece = new Despiece(listaDespiece.get(indiceDespiece));
    } else {
        despiece = new Despiece();
    }
    configurar(new NuevoArticuloOpcion(e, "Gancho", obtenerArticulo("Gancho"), despiece.getCaracteristica(), dac, this, despiece, "Gancho"));
}//GEN-LAST:event_bGanchoActionPerformed

private void bPoleaIzquierdaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bPoleaIzquierdaActionPerformed
    Integer indiceDespiece = obtenerIndiceDespiece("PoleaIzquierda");
    Despiece despiece = null;
    if (indiceDespiece != null) {
        despiece = new Despiece(listaDespiece.get(indiceDespiece));
    } else {
        despiece = new Despiece();
    }
    configurar(new NuevoArticuloOpcion(e, "PoleaIzquierda", obtenerArticulo("PoleaIzquierda"), despiece.getCaracteristica(), dac, this, despiece, "Polea izquierda"));
}//GEN-LAST:event_bPoleaIzquierdaActionPerformed

private void bPoleaDerechaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bPoleaDerechaActionPerformed
    Integer indiceDespiece = obtenerIndiceDespiece("PoleaDerecha");
    Despiece despiece = null;
    if (indiceDespiece != null) {
        despiece = new Despiece(listaDespiece.get(indiceDespiece));
    } else {
        despiece = new Despiece();
    }
    configurar(new NuevoArticuloOpcion(e, "PoleaDerecha", obtenerArticulo("PoleaDerecha"), despiece.getCaracteristica(), dac, this, despiece, "Polea derecha"));
}//GEN-LAST:event_bPoleaDerechaActionPerformed

private void bAtacuerdaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bAtacuerdaActionPerformed
    Integer indiceDespiece = obtenerIndiceDespiece("Atacuerda");
    Despiece despiece = null;
    if (indiceDespiece != null) {
        despiece = new Despiece(listaDespiece.get(indiceDespiece));
    } else {
        despiece = new Despiece();
    }
    configurar(new NuevoArticuloOpcion(e, "Atacuerda", obtenerArticulo("Atacuerda"), despiece.getCaracteristica(), dac, this, despiece, "Atacuerda"));
}//GEN-LAST:event_bAtacuerdaActionPerformed

private void bBambolinaPlanoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bBambolinaPlanoActionPerformed
    Integer indiceDespiece = obtenerIndiceDespiece("Bambolina");
    Despiece despiece = null;
    if (indiceDespiece != null) {
        despiece = new Despiece(listaDespiece.get(indiceDespiece));
    } else {
        despiece = new Despiece();
    }
    configurar(new NuevoArticuloOpcion(e, "Bambolina", obtenerArticulo("Bambolina"), despiece.getCaracteristica(), dac, this, despiece, "Bambolina"));
}//GEN-LAST:event_bBambolinaPlanoActionPerformed

private void bCarruchaSimpleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bCarruchaSimpleActionPerformed
    Integer indiceDespiece = obtenerIndiceDespiece("CarruchaSimple");
    Despiece despiece = null;
    if (indiceDespiece != null) {
        despiece = new Despiece(listaDespiece.get(indiceDespiece));
    } else {
        despiece = new Despiece();
    }
    configurar(new NuevoArticuloOpcion(e, "CarruchaSimple", obtenerArticulo("CarruchaSimple"), despiece.getCaracteristica(), dac, this, despiece, "Carrucha simple"));
}//GEN-LAST:event_bCarruchaSimpleActionPerformed

private void bPerfilCofreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bPerfilCofreActionPerformed
    Integer indiceDespiece = obtenerIndiceDespiece("PerfilCobre");
    Despiece despiece = null;
    if (indiceDespiece != null) {
        despiece = new Despiece(listaDespiece.get(indiceDespiece));
    } else {
        despiece = new Despiece();
    }
    configurar(new NuevoArticuloOpcion(e, "PerfilCofre", obtenerArticulo("PerfilCofre"), despiece.getCaracteristica(), dac, this, despiece, "Perfil cofre"));
}//GEN-LAST:event_bPerfilCofreActionPerformed

private void cLacadoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cLacadoActionPerformed
    if (actualizarCaracteristicas && listaDespiece != null && listaDespiece.size() > 0) {
        Colores colorLacado = BaseDatos.obtenerColorPorDescripcion((String) cLacado.getSelectedItem());
        Despiece temp;
        Iterator<Despiece> iter = listaDespiece.iterator();
        Articulo artTemp;
        Caracteristica carTemp, carAux;
        FamiliaVenta fv;
        StringBuffer buffer = new StringBuffer();

        while (iter.hasNext()) {
            temp = iter.next();
            artTemp = BaseDatos.obtenerArticuloPorIid(temp.getArticulo().getIid());
            carTemp = temp.getCaracteristica();

            if (carTemp != null) {
                carTemp = BaseDatos.obtenerCaracteristicaPorIid(carTemp.getIid());

                if (artTemp.getMonocromo() != null && artTemp.getMonocromo() && Constantes.DESC_COLOR_BLANCO.equalsIgnoreCase((String) cLacado.getSelectedItem())) {
                    colorLacado = BaseDatos.obtenerColorPorDescripcion(Constantes.DESC_COLOR_BLANCO);
                } else if (artTemp.getMonocromo() != null && artTemp.getMonocromo()) {
                    colorLacado = BaseDatos.obtenerColorPorDescripcion(Constantes.DESC_COLOR_NEGRO);
                }
                carAux = BaseDatos.obtenerCaracteristica(artTemp, e, colorLacado);

                fv = BaseDatos.obtenerFamiliaVentaPorIid(artTemp.getIid_fam_venta().getIid());
                if (fv.getRecortable() != null && fv.getRecortable() && carAux != null) {
                    temp.setCaracteristica(carAux);
                    temp.setColor(colorLacado);
                } else if (fv.getRecortable() != null && fv.getRecortable()) {
                    buffer.append("El artículo ");
                    buffer.append(artTemp.getCod_articulo());
                    buffer.append(" no posee la característica ");
                    buffer.append(colorLacado.getDescripcion());
                    buffer.append(".\n");
                }
            }
        }

        String mensajeMostrar = buffer.toString();
        if (mensajeMostrar.length() != 0) {
            JOptionPane.showMessageDialog(null, mensajeMostrar, "Información", JOptionPane.INFORMATION_MESSAGE);
        }
    }
}//GEN-LAST:event_cLacadoActionPerformed

private void cAccesoriosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cAccesoriosActionPerformed
    if (actualizarCaracteristicas && listaDespiece != null && listaDespiece.size() > 0) {
        Colores colorAccesorio = BaseDatos.obtenerColorPorDescripcion((String) cAccesorios.getSelectedItem());
        Despiece temp;
        Iterator<Despiece> iter = listaDespiece.iterator();
        Articulo artTemp;
        Caracteristica carTemp, carAux;
        FamiliaVenta fv;
        StringBuffer buffer = new StringBuffer();

        while (iter.hasNext()) {
            temp = iter.next();
            artTemp = BaseDatos.obtenerArticuloPorIid(temp.getArticulo().getIid());
            carTemp = temp.getCaracteristica();

            if (carTemp != null) {
                carTemp = BaseDatos.obtenerCaracteristicaPorIid(carTemp.getIid());

                if (artTemp.getMonocromo() != null && artTemp.getMonocromo() && Constantes.DESC_COLOR_BLANCO.equalsIgnoreCase((String) cAccesorios.getSelectedItem())) {
                    colorAccesorio = BaseDatos.obtenerColorPorDescripcion(Constantes.DESC_COLOR_BLANCO);
                } else if (artTemp.getMonocromo() != null && artTemp.getMonocromo()) {
                    colorAccesorio = BaseDatos.obtenerColorPorDescripcion(Constantes.DESC_COLOR_NEGRO);
                }
                carAux = BaseDatos.obtenerCaracteristica(artTemp, e, colorAccesorio);
                fv = BaseDatos.obtenerFamiliaVentaPorIid(artTemp.getIid_fam_venta().getIid());
                if ((fv.getRecortable() == null || !fv.getRecortable()) && carAux != null) {
                    temp.setCaracteristica(carAux);
                    temp.setColor(colorAccesorio);
                } else if (fv.getRecortable() == null || !fv.getRecortable()) {
                    buffer.append("El artículo ");
                    buffer.append(artTemp.getCod_articulo());
                    buffer.append(" no posee la característica ");
                    buffer.append(colorAccesorio.getDescripcion());
                    buffer.append(".\n");
                }
            }
        }
        String mensajeMostrar = buffer.toString();
        if (mensajeMostrar.length() != 0) {
            JOptionPane.showMessageDialog(null, mensajeMostrar, "Información", JOptionPane.INFORMATION_MESSAGE);
        }
    }
}//GEN-LAST:event_cAccesoriosActionPerformed
    protected Integer obtenerIndiceDespiece(String tipoArticulo) {
        Integer res = null;
        Iterator<Despiece> iter = listaDespiece.iterator();
        boolean seguir = true;
        int indice = 0;
        while (iter.hasNext() && seguir) {
            if (iter.next().getTipoArticulo().equals(tipoArticulo)) {
                seguir = false;
            } else {
                indice++;
            }
        }
        if (!seguir) {
            res = indice;
        }
        return res;
    }

    public void resetarTipoDespiece(String tipoArticulo) {
        Iterator<Despiece> iter = listaDespiece.iterator();
        boolean seguir = true;
        Despiece temp = null;
        while (iter.hasNext() && seguir) {
            temp = iter.next();
            if (temp.getTipoArticulo().equals(tipoArticulo)) {
                temp.setTipoArticulo("");
            }
        }
    }

    protected void modificarDespiece(Despiece despiece, boolean crear) {
        String tipo = despiece.getTipoArticulo();
        if (tipo.length() != 0) {
            resetearTipoArticuloDespiece(tipo);
        }
        listaDespiece.add(despiece.getOrden(), despiece);
        if (!crear) {
            listaDespiece.remove(despiece.getOrden() + 1);
        }
        actualizarIndicesSecuencialesDespieces();

        if (tipo.equals("Brazos") && dacBase.getBrazo()) {
            this.rellenarBrazos(despiece.getArticulo());
        } else if (tipo.equals("Lona") && dacBase.getLona()) {
            this.rellenarLona(despiece.getArticulo());
        } else if (tipo.equals("TuboEnrolle") && dacBase.getTuboEnrrolle()) {
            this.rellenarTuboEnrolle(despiece.getArticulo());
        } else if (tipo.equals("Manivelas") && dacBase.getManivela()) {
            this.rellenarManivelas(despiece.getArticulo());
        } else if (tipo.equals("Soporte") && dacBase.getSoporte()) {
            this.rellenarSoporte(despiece.getArticulo());
        } else if (tipo.equals("Casquillo") && dacBase.getCasquillo()) {
            this.rellenarCasquillo(despiece.getArticulo());
        } else if (tipo.equals("Maquina") && dacBase.getMaquina()) {
            this.rellenarMaquina(despiece.getArticulo());
        } else if (tipo.equals("PerfilCofre") && dacBase.getPerfilCofre()) {
            this.rellenarPerfilCofre(despiece.getArticulo());
        } else if (tipo.equals("Perfil") && dacBase.getPerfil()) {
            if (dacBase.getTipoPlantilla().equals(Constantes.PLANTILLA_TOLDO_ENRROLLADO)) {
                rellenarPerfil(despiece.getArticulo());
            } else if (dacBase.getTipoPlantilla().equals(Constantes.PLANTILLA_TOLDO_PLANO)) {
                rellenarPerfilPlano(despiece.getArticulo());
            }
        } else if (tipo.equals("Terminal") && dacBase.getTerminal()) {
            rellenarTerminal(despiece.getArticulo());
        } else if (tipo.equals("Tapa") && dacBase.getTapa()) {
            rellenarTapa(despiece.getArticulo());
        } else if (tipo.equals("Bambolina") && dacBase.getBambolina()) {
            if (dacBase.getTipoPlantilla().equals(Constantes.PLANTILLA_TOLDO_ENRROLLADO)) {
                rellenarBambolina(despiece.getArticulo());
            } else if (dacBase.getTipoPlantilla().equals(Constantes.PLANTILLA_TOLDO_PLANO)) {
                rellenarBambolinaPlano(despiece.getArticulo());
            }
        } else if (tipo.equals("AtacuerdaPared") && dacBase.getAtacuerdaPared()) {
            rellenarAtacuerdaPared(despiece.getArticulo());
        } else if (tipo.equals("CarruchaDoble") && dacBase.getCarruchaDoble()) {
            rellenarCarruchaDoble(despiece.getArticulo());
        } else if (tipo.equals("CarruchaSimple") && dacBase.getCarruchaSimple()) {
            rellenarCarruchaSimple(despiece.getArticulo());
        } else if (tipo.equals("Gancho") && dacBase.getGancho()) {
            rellenarGancho(despiece.getArticulo());
        } else if (tipo.equals("PoleaIzquierda") && dacBase.getPoleaIzquierda()) {
            rellenarPoleaIzquierda(despiece.getArticulo());
        } else if (tipo.equals("PoleaDerecha") && dacBase.getPoleaDerecha()) {
            rellenarPoleaDerecha(despiece.getArticulo());
        } else if (tipo.equals("Atacuerda") && dacBase.getAtacuerda()) {
            rellenarAtacuerda(despiece.getArticulo());
        }
        actualizarListaDespiece();
    }

    protected void modificarDespiece(Despiece despiece, boolean modificarDespiece, String tipoArticuloAntiguo) {
        String tipo = despiece.getTipoArticulo();

        if (despiece.getOrden() != null) {
            int orden = despiece.getOrden();
            listaDespiece.remove(orden);
            if (tipo.length() != 0) {
                resetearTipoArticuloDespiece(tipo, tipoArticuloAntiguo);
            }
            listaDespiece.add(despiece.getOrden(), despiece);
        } else {
            if (tipo.length() != 0) {
                resetearTipoArticuloDespiece(tipo, tipoArticuloAntiguo);
            }
            listaDespiece.add(despiece);
        }
        actualizarIndicesSecuencialesDespieces();

        if (tipoArticuloAntiguo != null && tipoArticuloAntiguo.equals("TuboEnrolle")) {
            this.tTuboEnrrolleArea.setText("");
            tTuboEnrrolleAreaMedida.setText(" ");
        } else if (tipoArticuloAntiguo != null && tipoArticuloAntiguo.equals("Manivelas")) {
            tManivelaArea.setText("");
        } else if (tipoArticuloAntiguo != null && tipoArticuloAntiguo.equals("Lona")) {
            this.tTelaArea.setText("");
            tTelaAreaMedida.setText(" ");
        } else if (tipoArticuloAntiguo != null && tipoArticuloAntiguo.equals("Brazos")) {
            tBrazoIzquierdoArea.setText("");
            tBrazoDerechoArea.setText("");
        } else if (tipoArticuloAntiguo != null && tipoArticuloAntiguo.equals("Soporte")) {
            tSoporteIzquierdoArea.setText("");
            tSoporteDerechoArea.setText("");
        } else if (tipoArticuloAntiguo != null && tipoArticuloAntiguo.equals("Casquillo")) {
            tCasquilloIzquierdoArea.setText("");
            tCasquilloDerechoArea.setText("");
        } else if (tipoArticuloAntiguo != null && tipoArticuloAntiguo.equals("Maquina")) {
            tMaquinaIzquierdaArea.setText("");
            tMaquinaDerechaArea.setText("");
        } else if (tipoArticuloAntiguo != null && tipoArticuloAntiguo.equals("PerfilCofre")) {
            tPerfilCofreArea.setText("");
            tPerfilCofreAreaMedida.setText("");
        } else if (tipoArticuloAntiguo != null && tipoArticuloAntiguo.equals("Perfil")) {
            if (dacBase.getTipoPlantilla().equals(Constantes.PLANTILLA_TOLDO_ENRROLLADO)) {
                tPerfilArea.setText("");
                tPerfilAreaMedida.setText(" ");
            } else if (dacBase.getTipoPlantilla().equals(Constantes.PLANTILLA_TOLDO_PLANO)) {
                tPerfilPlanoArea.setText("");
                tPerfilPlanoAreaMedida.setText(" ");
            }
        } else if (tipoArticuloAntiguo != null && tipoArticuloAntiguo.equals("Terminal")) {
            tTerminalIzquierdoArea.setText("");
            tTerminalDerechoArea.setText("");
        } else if (tipoArticuloAntiguo != null && tipoArticuloAntiguo.equals("Tapa")) {
            tTapaIzquierdaArea.setText("");
            tTapaDerechaArea.setText("");
        } else if (tipoArticuloAntiguo != null && tipoArticuloAntiguo.equals("Bambolina")) {
            if (dacBase.getTipoPlantilla().equals(Constantes.PLANTILLA_TOLDO_ENRROLLADO)) {
                tBambolinaArea.setText("");
                tBambolinaAreaMedida.setText(" ");
            } else if (dacBase.getTipoPlantilla().equals(Constantes.PLANTILLA_TOLDO_PLANO)) {
                tBambolinaPlanoArea.setText("");
                tBambolinaPlanoAreaMedida.setText(" ");
            }
        } else if (tipoArticuloAntiguo != null && tipoArticuloAntiguo.equals("AtacuerdaPared")) {
            tAtacuerdaParedArea.setText("");
        } else if (tipoArticuloAntiguo != null && tipoArticuloAntiguo.equals("CarruchaDoble")) {
            tCarruchaDobleArea.setText("");
        } else if (tipoArticuloAntiguo != null && tipoArticuloAntiguo.equals("CarruchaSimple")) {
            tCarruchaSimpleArea.setText("");
        } else if (tipoArticuloAntiguo != null && tipoArticuloAntiguo.equals("Gancho")) {
            tGanchoIzquierdoArea.setText("");
            tGanchoDerechaArea.setText("");
        } else if (tipoArticuloAntiguo != null && tipoArticuloAntiguo.equals("PoleaIzquierda")) {
            tPoleaIzquierdaArea.setText("");
        } else if (tipoArticuloAntiguo != null && tipoArticuloAntiguo.equals("PoleaDerecha")) {
            tPoleaDerechaArea.setText("");
        } else if (tipoArticuloAntiguo != null && tipoArticuloAntiguo.equals("Atacuerda")) {
            tAtacuerdaArea.setText("");
        }

        if (tipo.equals("Brazos") && dacBase.getBrazo()) {
            this.rellenarBrazos(despiece.getArticulo());
        } else if (tipo.equals("Lona") && dacBase.getLona()) {
            this.rellenarLona(despiece.getArticulo());
        } else if (tipo.equals("TuboEnrolle") && dacBase.getTuboEnrrolle()) {
            this.rellenarTuboEnrolle(despiece.getArticulo());
        } else if (tipo.equals("Manivelas") && dacBase.getManivela()) {
            this.rellenarManivelas(despiece.getArticulo());
        } else if (tipo.equals("Soporte") && dacBase.getSoporte()) {
            this.rellenarSoporte(despiece.getArticulo());
        } else if (tipo.equals("Casquillo") && dacBase.getCasquillo()) {
            this.rellenarCasquillo(despiece.getArticulo());
        } else if (tipo.equals("Maquina") && dacBase.getMaquina()) {
            this.rellenarMaquina(despiece.getArticulo());
        } else if (tipo.equals("PerfilCofre") && dacBase.getPerfilCofre()) {
            this.rellenarPerfilCofre(despiece.getArticulo());
        } else if (tipo.equals("Perfil") && dacBase.getPerfil()) {
            if (dacBase.getTipoPlantilla().equals(Constantes.PLANTILLA_TOLDO_ENRROLLADO)) {
                rellenarPerfil(despiece.getArticulo());
            } else if (dacBase.getTipoPlantilla().equals(Constantes.PLANTILLA_TOLDO_PLANO)) {
                rellenarPerfilPlano(despiece.getArticulo());
            }
        } else if (tipo.equals("Terminal") && dacBase.getTerminal()) {
            this.rellenarTerminal(despiece.getArticulo());
        } else if (tipo.equals("Tapa") && dacBase.getTapa()) {
            this.rellenarTapa(despiece.getArticulo());
        } else if (tipo.equals("Bambolina") && dacBase.getBambolina()) {
            if (dacBase.getTipoPlantilla().equals(Constantes.PLANTILLA_TOLDO_ENRROLLADO)) {
                this.rellenarBambolina(despiece.getArticulo());
            } else if (dacBase.getTipoPlantilla().equals(Constantes.PLANTILLA_TOLDO_PLANO)) {
                this.rellenarBambolinaPlano(despiece.getArticulo());
            }
        } else if (tipo.equals("AtacuerdaPared") && dacBase.getAtacuerdaPared()) {
            this.rellenarAtacuerdaPared(despiece.getArticulo());
        } else if (tipo.equals("CarruchaDoble") && dacBase.getCarruchaDoble()) {
            this.rellenarCarruchaDoble(despiece.getArticulo());
        } else if (tipo.equals("CarruchaSimple") && dacBase.getCarruchaSimple()) {
            this.rellenarCarruchaSimple(despiece.getArticulo());
        } else if (tipo.equals("Gancho") && dacBase.getGancho()) {
            rellenarGancho(despiece.getArticulo());
        } else if (tipo.equals("PoleaIzquierda") && dacBase.getPoleaIzquierda()) {
            this.rellenarPoleaIzquierda(despiece.getArticulo());
        } else if (tipo.equals("PoleaDerecha") && dacBase.getPoleaDerecha()) {
            rellenarPoleaDerecha(despiece.getArticulo());
        } else if (tipo.equals("Atacuerda") && dacBase.getAtacuerda()) {
            rellenarAtacuerda(despiece.getArticulo());
        }

        actualizarListaDespiece();
    }

    public Double calcularValor(Variable var) {
        Double res = 0d;

        if (var.getTipo().equals(Constantes.NUMERICA)) {
            res = var.getValor();
        } else if (var.getTipo().equals(Constantes.CALCULADA)) {
            Double valorFormula = evaluar(var.getFormula(), Constantes.DECIMALES2, true);

            if (var.getActivarMaximo() && var.getValorMinimo() > valorFormula) {
                valorFormula = var.getValorMinimo();
            } else if (var.getActivarMaximo() && var.getValorMaximo() < valorFormula) {
                valorFormula = var.getValorMaximo();
            }

            res = valorFormula;
        } else {
            //Hay que buscar las seleccion de la variable y obtener la que esté a seleccionada
            Iterator<Seleccion> iter = this.listaSeleccion.iterator();
            boolean seguir = true;
            Seleccion tempSel;
            Variable tempVar;
            while (seguir && iter.hasNext()) {
                tempSel = iter.next();
                tempVar = tempSel.getVariable();

                if (tempVar.getIid() != null) {
                    tempVar = BaseDatos.obtenerVariableById(tempVar.getIid());
                }

                if (tempVar.getNombre().equals(var.getNombre())) {
                    if (tempSel.getSeleccionada()) {
                        seguir = false;
                        res = tempSel.getValor();
                    }
                }
            }
        }
        return res;
    }

    public void rellenarArticulo(Articulo ar) {
        this.ar = ar;
        tCodigo.setText(ar.getCod_articulo());
        tDescripcion.setText(ar.getDes_inf());

        //Actualizar las medidas
        TipoControl tc = this.ar.getIid_fam_venta().getIid_tipo_control();
        if (tc != null) {
            UnidadMedida um;
            TipoMedida tm = BaseDatos.obtenerTipoMedidaByIid(tc.getIid_tipo_medida().getIid());

            if (tc.getUnidad1() != null) {
                um = BaseDatos.obtenerUnidadMedidaIid(tc.getUnidad1().getIid());
                if (um != null) {
                    lUnidad1.setText(tm.getNombre_dim_1());
                    lMagnitud1.setText(um.getCod_unidad_medida());
                    tMedida1.setText("100");
                    lUnidad1.setVisible(true);
                    lMagnitud1.setVisible(true);
                    tMedida1.setVisible(true);
                    engineGlobal.put("Dim1", 100D);
                }
            } else {
                lUnidad1.setVisible(false);
                lMagnitud1.setVisible(false);
                tMedida1.setVisible(false);
            }
            if (tc.getUnidad2() != null) {
                um = BaseDatos.obtenerUnidadMedidaIid(tc.getUnidad2().getIid());
                if (um != null) {
                    lUnidad2.setText(tm.getNombre_dim_2());
                    lMagnitud2.setText(um.getCod_unidad_medida());
                    tMedida2.setText("100");
                    lUnidad2.setVisible(true);
                    lMagnitud2.setVisible(true);
                    tMedida2.setVisible(true);
                    engineGlobal.put("Dim2", 100D);
                }
            } else {
                lUnidad2.setVisible(false);
                lMagnitud2.setVisible(false);
                tMedida2.setVisible(false);
            }
            if (tc.getUnidad3() != null) {
                um = BaseDatos.obtenerUnidadMedidaIid(tc.getUnidad3().getIid());
                if (um != null) {
                    lUnidad3.setText(tm.getNombre_dim_3());
                    lMagnitud3.setText(um.getCod_unidad_medida());
                    tMedida3.setText("100");
                    lUnidad3.setVisible(true);
                    lMagnitud3.setVisible(true);
                    tMedida3.setVisible(true);
                    engineGlobal.put("Dim3", 100D);
                }
            } else {
                lUnidad3.setVisible(false);
                lMagnitud3.setVisible(false);
                tMedida3.setVisible(false);
            }
            if (tc.getUnidad4() != null) {
                um = BaseDatos.obtenerUnidadMedidaIid(tc.getUnidad4().getIid());
                if (um != null) {
                    lUnidad4.setText(tm.getNombre_dim_4());
                    lMagnitud4.setText(um.getCod_unidad_medida());
                    tMedida4.setText("100");
                    lUnidad4.setVisible(true);
                    lMagnitud4.setVisible(true);
                    tMedida4.setVisible(true);
                    engineGlobal.put("Dim4", 100D);
                }
            } else {
                lUnidad4.setVisible(false);
                lMagnitud4.setVisible(false);
                tMedida4.setVisible(false);
            }
            if (tc.getUnidad5() != null) {
                um = BaseDatos.obtenerUnidadMedidaIid(tc.getUnidad5().getIid());
                if (um != null) {
                    lUnidad5.setText(tm.getNombre_dim_5());
                    lMagnitud5.setText(um.getCod_unidad_medida());
                    tMedida5.setText("100");
                    lUnidad5.setVisible(true);
                    lMagnitud5.setVisible(true);
                    tMedida5.setVisible(true);
                    engineGlobal.put("Dim5", 100D);
                }
            } else {
                lUnidad5.setVisible(false);
                lMagnitud5.setVisible(false);
                tMedida5.setVisible(false);
            }
        }
    }

    public int getNumeroDimensiones() {
        return this.numMedidasArticuloDac;
    }

    public String getCantidad() {
        if (this.tCantidad.getText() != null && this.tCantidad.getText().length() != 0) {
            return this.tCantidad.getText();
        } else {
            return "0";
        }
    }

    public String getDim1() {
        if (this.tMedida1.isVisible()) {
            if (this.tMedida1.getText() != null && this.tMedida1.getText().length() != 0) {
                return this.tMedida1.getText();
            } else {
                return "0";
            }
        } else {
            return "0";
        }
    }

    public String getDim2() {
        if (this.tMedida2.isVisible()) {
            if (this.tMedida2.getText() != null && this.tMedida2.getText().length() != 0) {
                return this.tMedida2.getText();
            } else {
                return "0";
            }
        } else {
            return "0";
        }
    }

    public String getDim3() {
        if (this.tMedida3.isVisible()) {
            if (this.tMedida3.getText() != null && this.tMedida3.getText().length() != 0) {
                return this.tMedida3.getText();
            } else {
                return "0";
            }
        } else {
            return "0";
        }
    }

    public String getDim4() {
        if (this.tMedida4.isVisible()) {
            if (this.tMedida4.getText() != null && this.tMedida4.getText().length() != 0) {
                return this.tMedida4.getText();
            } else {
                return "0";
            }
        } else {
            return "0";
        }
    }

    public String getDim5() {
        if (this.tMedida5.isVisible()) {
            if (this.tMedida5.getText() != null && this.tMedida5.getText().length() != 0) {
                return this.tMedida5.getText();
            } else {
                return "0";
            }
        } else {
            return "0";
        }
    }

    public boolean comprobarCondicion(String condicion) {
        boolean res = true;
        //int numMedidasArticuloDac = getNumeroDimensiones();

        if (numMedidasArticuloDac == 0 && (condicion.contains("Dim1") || condicion.contains("Dim2") || condicion.contains("Dim3") || condicion.contains("Dim4") || condicion.contains("Dim5"))) {
            res = false;
        } else if (numMedidasArticuloDac == 1 && (condicion.contains("Dim2") || condicion.contains("Dim3") || condicion.contains("Dim4") || condicion.contains("Dim5"))) {
            res = false;
        } else if (numMedidasArticuloDac == 2 && (condicion.contains("Dim3") || condicion.contains("Dim4") || condicion.contains("Dim5"))) {
            res = false;
        } else if (numMedidasArticuloDac == 3 && (condicion.contains("Dim4") || condicion.contains("Dim5"))) {
            res = false;
        } else if (numMedidasArticuloDac == 4 && (condicion.contains("Dim5"))) {
            res = false;
        }

        if (res) {
            try {
                res = (Boolean) engineGlobal.eval(condicion);
            } catch (Exception se) {
                res = false;
            }
        }

        return res;
    }

    public Double calcularPrecioDespiece(Despiece des, Double desI, Float ivaF, NuevoPresupuesto p) {
        Double res = 0D;

        if (des.getPrecio() == null) {

            Articulo arTemp = des.getArticulo();
            //if (arTemp.getIid() != null) {
            //    arTemp = BaseDatos.obtenerArticuloPorIid(arTemp.getIid());
            //}

            Caracteristica carTemp = des.getCaracteristica();
            if (carTemp != null) {
                carTemp = BaseDatos.obtenerCaracteristicaPorIid(carTemp.getIid());
            }

            if (des.getArticuloBase() == null && des.getAnadirIncremento() == null && des.getAnadirPvp() == null) {
                des.setAnadirPvp(true);
            }

            //Si Articulo Base ==> el precio es 0
            if (des.getArticuloBase()) {
                res = 0D;
            } //Si es Anadir Incremento ==> el precio es el precio por incremento del articulo o caracteristica
            else if (des.getAnadirIncremento()) {
                double precioTemporal = 0D;
                if (carTemp != null) {
                    if (carTemp.getPrecioIncremento() != null) {
                        precioTemporal = carTemp.getPrecioIncremento().doubleValue();
                    } else {
                        precioTemporal = 0D;
                    }
                } else {
                    if (arTemp.getPrecioIncremento() != null) {
                        precioTemporal = arTemp.getPrecioIncremento().doubleValue();
                    } else {
                        precioTemporal = 0D;
                    }
                }

                try {
                    //FamiliaVenta fv = BaseDatos.obtenerFamiliaVentaPorIid(arTemp.getIid_fam_venta().getIid());
                    //TipoControl tc = BaseDatos.obtenerTipoControlPorIid(fv.getIid_tipo_control().getIid());
                    //TipoMedida tm = BaseDatos.obtenerTipoMedidaByIid(tc.getIid_tipo_medida().getIid());
                    //FamiliaVenta fv = des.getFamiliaVenta();
                    //TipoControl tc = des.getTipoControl();
                    TipoMedida tm = des.getTipoMedida();
                    String tipoCalculo = tm.getTipo_calculo();
                    Float medidaTotal;

                    if (tipoCalculo.equals(Constantes.FORMULA)) {
                        medidaTotal = ((Double) engineGlobal.eval(tm.getFormula())).floatValue();
                    } else {
                        medidaTotal = Float.valueOf(Util.convertirComaAPunto(tMedida1.getText())) / 100;
                    }

                    if ((arTemp.getEscalado() != null && arTemp.getEscalado()) || (arTemp.getEscaladoCaracteristica() != null && arTemp.getEscaladoCaracteristica())) {
                        medidaTotal = 1F;
                    }

                    //Descuento de interlocutor
                    if (desI != null && desI != 0.0D) {
                        //En el caso que tenga descuento lo aplicamos
                        precioTemporal = precioTemporal - (precioTemporal * Float.valueOf(desI.toString()));
                    }
                    //Iva interlocutor
                    if (ivaF != null && ivaF != 0.0F) {
                        //En el caso que tenga IVA lo aplicamos
                        precioTemporal = precioTemporal + (precioTemporal * ivaF);
                    }

                    //Añadir formula      
                    if (p != null) {
                        String formula = p.obtenerFormula(arTemp.getIid_fam_venta());
                        if (formula != null && !formula.isEmpty()) {
                            //Sustituir pvp por el precio real
                            formula = formula.replace("pvp", Double.toString(precioTemporal));
                            precioTemporal = (Double) Double.valueOf(engineGlobal.eval(formula).toString());
                        }

                    }
                    res = precioTemporal * medidaTotal * evaluar(des.getFormulaCantidad(), des.getRedondeo(), false);
                } catch (Exception ex) {
                    res = 0D;
                }

            } //Si es Anadir PVP ==> el precio es el precio ya sea por formula, escalado.. del articulo o caracteristica
            else if (des.getAnadirPvp()) {
                double precioTemporal = 0D;
                if ((arTemp.getEscalado() != null && arTemp.getEscalado()) || (arTemp.getEscaladoCaracteristica() != null && arTemp.getEscaladoCaracteristica())) {
                    Float fMedida1 = -1F;
                    Float fMedida2 = -1F;
                    if (tMedida1.getText().length() != 0) {
                        fMedida1 = evaluar(des.getFormulaMedida1(), des.getRedondeo(), false).floatValue();
                    }
                    if (tMedida2.getText().length() != 0) {
                        fMedida2 = evaluar(des.getFormulaMedida2(), des.getRedondeo(), false).floatValue();
                    }

                    if (arTemp.getEscaladoCaracteristica() == null || !arTemp.getEscaladoCaracteristica()) {
                        precioTemporal = BaseDatos.obtenerPrecioEscalado(arTemp.getIid(), null, fMedida1.intValue(), fMedida2.intValue());
                    } else {
                        precioTemporal = BaseDatos.obtenerPrecioEscalado(arTemp.getIid(), carTemp.getIid(), fMedida1.intValue(), fMedida2.intValue());
                    }
                } else {
                    if (carTemp != null) {
                        if (carTemp.getPvp() != null) {
                            precioTemporal = carTemp.getPvp().doubleValue();
                        } else {
                            precioTemporal = 0D;
                        }
                    } else {
                        if (arTemp.getPrecio_v() != null) {
                            precioTemporal = arTemp.getPrecio_v().doubleValue();
                        } else {
                            precioTemporal = 0D;
                        }
                    }
                }

                try {
                    //FamiliaVenta fv = BaseDatos.obtenerFamiliaVentaPorIid(arTemp.getIid_fam_venta().getIid());
                    //TipoControl tc = BaseDatos.obtenerTipoControlPorIid(fv.getIid_tipo_control().getIid());
                    //TipoMedida tm = BaseDatos.obtenerTipoMedidaByIid(tc.getIid_tipo_medida().getIid());
                    TipoMedida tm = des.getTipoMedida();
                    String tipoCalculo = tm.getTipo_calculo();
                    Float medidaTotal;

                    if (tipoCalculo.equals(Constantes.FORMULA)) {
                        medidaTotal = ((Double) engineGlobal.eval(tm.getFormula())).floatValue();
                    } else {
                        medidaTotal = Float.valueOf(Util.convertirComaAPunto(tMedida1.getText())) / 100;
                    }

                    if ((arTemp.getEscalado() != null && arTemp.getEscalado()) || (arTemp.getEscaladoCaracteristica() != null && arTemp.getEscaladoCaracteristica())) {
                        medidaTotal = 1F;
                    }
                    res = precioTemporal * medidaTotal * evaluar(des.getFormulaCantidad(), des.getRedondeo(), false);
                } catch (Exception ex) {
                    ex.printStackTrace();
                    res = 0D;
                }
            }
        } else {
            res = Double.valueOf(Float.toString(des.getPrecio()));
        }
        return res;
    }

    public Double calcularPrecioDespiece(Despiece des) {
        Double res = 0D;

        if (des.getPrecio() == null) {
            Articulo arTemp = des.getArticulo();
            if (arTemp.getIid() != null) {
                arTemp = BaseDatos.obtenerArticuloPorIid(arTemp.getIid());
            }

            Caracteristica carTemp = des.getCaracteristica();
            if (carTemp != null) {
                carTemp = BaseDatos.obtenerCaracteristicaPorIid(carTemp.getIid());
            }

            if (des.getArticuloBase() == null && des.getAnadirIncremento() == null && des.getAnadirPvp() == null) {
                des.setAnadirPvp(true);
            }

            //Si Articulo Base ==> el precio es 0
            if (des.getArticuloBase()) {
                res = 0D;
            } //Si es Anadir Incremento ==> el precio es el precio por incremento del articulo o caracteristica
            else if (des.getAnadirIncremento()) {
                double precioTemporal = 0D;
                if (carTemp != null) {
                    if (carTemp.getPrecioIncremento() != null) {
                        precioTemporal = carTemp.getPrecioIncremento().doubleValue();
                    } else {
                        precioTemporal = 0D;
                    }
                } else {
                    if (arTemp.getPrecioIncremento() != null) {
                        precioTemporal = arTemp.getPrecioIncremento().doubleValue();
                    } else {
                        precioTemporal = 0D;
                    }
                }

                try {
                    //TipoMedida tm = arTemp.getIid_fam_venta().getIid_tipo_control().getIid_tipo_medida();
                    TipoMedida tm = des.getTipoMedida();
                    String tipoCalculo = tm.getTipo_calculo();
                    Float medidaTotal;

                    if (tipoCalculo.equals(Constantes.FORMULA)) {
                        medidaTotal = ((Double) engineGlobal.eval(tm.getFormula())).floatValue();
                    } else {
                        medidaTotal = Float.valueOf(Util.convertirComaAPunto(tMedida1.getText())) / 100;
                    }

                    if ((arTemp.getEscalado() != null && arTemp.getEscalado()) || (arTemp.getEscaladoCaracteristica() != null && arTemp.getEscaladoCaracteristica())) {
                        medidaTotal = 1F;
                    }
                    res = precioTemporal * medidaTotal * evaluar(des.getFormulaCantidad(), des.getRedondeo(), false);
                } catch (Exception ex) {
                    res = 0D;
                }
            } //Si es Anadir PVP ==> el precio es el precio ya sea por formula, escalado.. del articulo o caracteristica
            else if (des.getAnadirPvp()) {
                double precioTemporal = 0D;
                if ((arTemp.getEscalado() != null && arTemp.getEscalado()) || (arTemp.getEscaladoCaracteristica() != null && arTemp.getEscaladoCaracteristica())) {

                    Float fMedida1 = -1F;
                    Float fMedida2 = -1F;
                    if (tMedida1.getText().length() != 0) {
                        fMedida1 = evaluar(des.getFormulaMedida1(), des.getRedondeo(), false).floatValue();
                    }
                    if (tMedida2.getText().length() != 0) {
                        fMedida2 = evaluar(des.getFormulaMedida2(), des.getRedondeo(), false).floatValue();
                    }

                    if (arTemp.getEscaladoCaracteristica() == null || !arTemp.getEscaladoCaracteristica()) {
                        precioTemporal = BaseDatos.obtenerPrecioEscalado(arTemp.getIid(), null, fMedida1.intValue(), fMedida2.intValue());
                    } else {
                        precioTemporal = BaseDatos.obtenerPrecioEscalado(arTemp.getIid(), carTemp.getIid(), fMedida1.intValue(), fMedida2.intValue());
                    }
                } else {
                    if (carTemp != null) {
                        if (carTemp.getPvp() != null) {
                            precioTemporal = carTemp.getPvp().doubleValue();
                        } else {
                            precioTemporal = 0D;
                        }
                    } else {
                        if (arTemp.getPrecio_v() != null) {
                            precioTemporal = arTemp.getPrecio_v().doubleValue();
                        } else {
                            precioTemporal = 0D;
                        }
                    }
                }

                try {
                    //FamiliaVenta fv = BaseDatos.obtenerFamiliaVentaPorIid(arTemp.getIid_fam_venta().getIid());
                    //TipoControl tc = BaseDatos.obtenerTipoControlPorIid(fv.getIid_tipo_control().getIid());
                    //TipoMedida tm = BaseDatos.obtenerTipoMedidaByIid(tc.getIid_tipo_medida().getIid());
                    TipoMedida tm = des.getTipoMedida();
                    String tipoCalculo = tm.getTipo_calculo();
                    Float medidaTotal;

                    if (tipoCalculo.equals(Constantes.FORMULA)) {
                        medidaTotal = ((Double) engineGlobal.eval(tm.getFormula())).floatValue();
                    } else {
                        medidaTotal = Float.valueOf(Util.convertirComaAPunto(tMedida1.getText())) / 100;
                    }

                    if ((arTemp.getEscalado() != null && arTemp.getEscalado()) || (arTemp.getEscaladoCaracteristica() != null && arTemp.getEscaladoCaracteristica())) {
                        medidaTotal = 1F;
                    }

                    res = precioTemporal * medidaTotal * evaluar(des.getFormulaCantidad(), des.getRedondeo(), false);
                } catch (Exception ex) {
                    ex.printStackTrace();
                    res = 0D;
                }
            }
        } else {
            res = Double.valueOf(Float.toString(des.getPrecio()));
        }
        return res;
    }

    public Double calcularCosteDespiece(Despiece des) {
        Double res = 0D;
        double precioTemporal = 0D;

        Articulo arTemp = des.getArticulo();
        if (arTemp.getIid() != null) {
            arTemp = BaseDatos.obtenerArticuloPorIid(arTemp.getIid());
        }

        Caracteristica carTemp = des.getCaracteristica();
        if (carTemp != null) {
            carTemp = BaseDatos.obtenerCaracteristicaPorIid(carTemp.getIid());
        }

        //Recuperar precios de coste del artículo o su caracteristica
        if (carTemp != null) {
            if (carTemp.getUpc() != null) {
                precioTemporal = carTemp.getUpc().doubleValue();
            } else {
                precioTemporal = 0D;
            }
        } else {
            if (arTemp.getUpc() != null) {
                precioTemporal = arTemp.getUpc().doubleValue();
            } else {
                precioTemporal = 0D;
            }
        }
        try {
            //FamiliaVenta fv = BaseDatos.obtenerFamiliaVentaPorIid(arTemp.getIid_fam_venta().getIid());
            //TipoControl tc = BaseDatos.obtenerTipoControlPorIid(fv.getIid_tipo_control().getIid());
            //TipoMedida tm = BaseDatos.obtenerTipoMedidaByIid(tc.getIid_tipo_medida().getIid());
            TipoMedida tm = des.getTipoMedida();
            String tipoCalculo = tm.getTipo_calculo();
            Float medidaTotal;

            if (tipoCalculo.equals(Constantes.FORMULA)) {
                medidaTotal = ((Double) engineGlobal.eval(tm.getFormula())).floatValue();
            } else {
                medidaTotal = Float.valueOf(Util.convertirComaAPunto(tMedida1.getText())) / 100;
            }

            res = precioTemporal * medidaTotal * evaluar(des.getFormulaCantidad(), des.getRedondeo(), false);
        } catch (Exception ex) {
            res = 0D;
        }
        return res;
    }

    public Double evaluar(String formula, String tipoRedondeo, boolean mostrarError) {
        Double resultado = null;
        boolean res = true;

        if (formula.length() == 0) {
            formula = "0.0";
        }

        if (numMedidasArticuloDac == 0 && (formula.contains("Dim1") || formula.contains("Dim2") || formula.contains("Dim3") || formula.contains("Dim4") || formula.contains("Dim5"))) {
            res = false;
        } else if (numMedidasArticuloDac == 1 && (formula.contains("Dim2") || formula.contains("Dim3") || formula.contains("Dim4") || formula.contains("Dim5"))) {
            res = false;
        } else if (numMedidasArticuloDac == 2 && (formula.contains("Dim3") || formula.contains("Dim4") || formula.contains("Dim5"))) {
            res = false;
        } else if (numMedidasArticuloDac == 3 && (formula.contains("Dim4") || formula.contains("Dim5"))) {
            res = false;
        } else if (numMedidasArticuloDac == 4 && (formula.contains("Dim5"))) {
            res = false;
        }

        if (res) {
            try {
                resultado = (Double) engineGlobal.eval(Util.convertirComaAPunto(formula));
                if (tipoRedondeo.equals(Constantes.TRUNCAR)) {
                    resultado = matematico.Matematico.truncar(resultado);
                } else if (tipoRedondeo.equals(Constantes.EXCESO)) {
                    resultado = matematico.Matematico.exceso(resultado);
                } else {
                    resultado = matematico.Matematico.redondear2decimales(resultado);
                }
            } catch (Exception se) {
                if (mostrarError) {
                    log.error("Se ha producido una excepción en el método evaluar con la formula " + formula, se);
                    JOptionPane.showMessageDialog(null, "Hay un error al evaluar la fórmula " + formula, "Error", JOptionPane.INFORMATION_MESSAGE);
                }
            }
        } else {
            JOptionPane.showMessageDialog(null, "Error, en la fórmula aparecen más medidas de las que tiene el artículo", "Error", JOptionPane.INFORMATION_MESSAGE);
        }
        return resultado;
    }

    protected String getArticulosEspecificacion() {
        Despiece despi;
        FamiliaVenta fv;
        Articulo arti;
        int indiceDespi;
        StringBuffer buffer = new StringBuffer();

        Iterator<Despiece> iter = listaDespiece.iterator();
        indiceDespi = 0;

        while (iter.hasNext()) {
            despi = iter.next();
            arti = despi.getArticulo();
            try {
                fv = arti.getIid_fam_venta();
            } catch (Exception ex) {
                arti = BaseDatos.obtenerArticuloPorIid(arti.getIid());
                fv = arti.getIid_fam_venta();
            }
            fv = BaseDatos.obtenerFamiliaVentaPorIid(fv.getIid());
            if (fv.getNombre().equals(Constantes.NOMBRE_FAM_ESPECIFICACION)) {
                if (indiceDespi > 0) {
                    buffer.append("\n");
                }
                buffer.append(despi.getFormulaCantidad());
            }
            indiceDespi++;
        }

        return buffer.toString();
    }

    protected List<CorteLona> getArticulosLona(String medida1, String medida2, String cantidad, int codigoLinea, LineaPresupuesto lp) {
        ArrayList<CorteLona> listaCorteLona = new ArrayList<CorteLona>();
        Articulo arti;
        int indiceDespi;

        tMedida1.setText(medida1);
        tMedida2.setText(medida2);
        tCantidad.setText(cantidad);

        FamiliaVenta fv = BaseDatos.obtenerFamiliaVentaPorIid(ar.getIid_fam_venta().getIid());
        if (fv.getConfeccionable() != null && fv.getConfeccionable()) {
            listaCorteLona.add(new CorteLona(codigoLinea, lp));
        }

        Iterator<Despiece> iter = listaDespiece.iterator();
        indiceDespi = 0;

        while (iter.hasNext()) {
            arti = iter.next().getArticulo();
            try {
                fv = arti.getIid_fam_venta();
            } catch (Exception ex) {
                arti = BaseDatos.obtenerArticuloPorIid(arti.getIid());
                fv = arti.getIid_fam_venta();
            }
            fv = BaseDatos.obtenerFamiliaVentaPorIid(fv.getIid());
            if (fv.getConfeccionable() != null && fv.getConfeccionable()) {
                listaCorteLona.add(new CorteLona(codigoLinea, this, indiceDespi, lp));
            }
            indiceDespi++;
        }

        return listaCorteLona;
    }

    protected List<CortePerfil> getArticulosPerfil(String medida1, String cantidad, int codigoLinea, LineaPresupuesto lp) {
        ArrayList<CortePerfil> listaCortePerfil = new ArrayList<CortePerfil>();
        Articulo arti;
        int indiceDespi;

        FamiliaVenta fv = BaseDatos.obtenerFamiliaVentaPorIid(ar.getIid_fam_venta().getIid());
        if (fv.getRecortable() != null && fv.getRecortable()) {
            listaCortePerfil.add(new CortePerfil(codigoLinea, lp));
        }

        Iterator<Despiece> iter = listaDespiece.iterator();
        indiceDespi = 0;

        while (iter.hasNext()) {
            arti = iter.next().getArticulo();
            try {
                fv = arti.getIid_fam_venta();
            } catch (Exception ex) {
                arti = BaseDatos.obtenerArticuloPorIid(arti.getIid());
                fv = arti.getIid_fam_venta();
            }
            fv = BaseDatos.obtenerFamiliaVentaPorIid(fv.getIid());
            if (fv.getRecortable() != null && fv.getRecortable()) {
                listaCortePerfil.add(new CortePerfil(codigoLinea, this, indiceDespi, lp));
            }
            indiceDespi++;
        }

        return listaCortePerfil;
    }

    protected List<CorteLonaSimulado> getArticulosLonaSimulado(String medida1, String medida2, String cantidad, int codigoLinea, NuevaLineaPresupuesto nlp) {
        ArrayList<CorteLonaSimulado> listaCorteLona = new ArrayList<CorteLonaSimulado>();
        Articulo arti;
        int indiceDespi;
        FamiliaVenta fv = BaseDatos.obtenerFamiliaVentaPorIid(ar.getIid_fam_venta().getIid());

        tMedida1.setText(medida1);
        tMedida2.setText(medida2);
        tCantidad.setText(cantidad);

        if (fv.getConfeccionable() != null && fv.getConfeccionable()) {
            listaCorteLona.add(new CorteLonaSimulado(codigoLinea, nlp));
        }

        Iterator<Despiece> iter = listaDespiece.iterator();
        indiceDespi = 0;

        while (iter.hasNext()) {
            arti = iter.next().getArticulo();
            try {
                fv = arti.getIid_fam_venta();
            } catch (Exception ex) {
                arti = BaseDatos.obtenerArticuloPorIid(arti.getIid());
                fv = arti.getIid_fam_venta();
            }
            fv = BaseDatos.obtenerFamiliaVentaPorIid(fv.getIid());
            if (fv.getConfeccionable() != null && fv.getConfeccionable()) {
                listaCorteLona.add(new CorteLonaSimulado(codigoLinea, this, indiceDespi, nlp));
            }
            indiceDespi++;
        }

        return listaCorteLona;
    }

    protected List<DesUnidades> getArticulosCantidad(String cantidad, int codigoLinea, LineaPresupuesto lp) {
        ArrayList<DesUnidades> listaArticulo = new ArrayList<DesUnidades>();
        DesUnidades unidades = new DesUnidades();
        Despiece despi;
        Articulo arti;
        int indiceDespi;
        FamiliaVenta fv = BaseDatos.obtenerFamiliaVentaPorIid(ar.getIid_fam_venta().getIid());
        Iterator<Despiece> iter = listaDespiece.iterator();
        indiceDespi = 0;

        tCantidad.setText(cantidad);

        while (iter.hasNext()) {
            despi = iter.next();
            arti = BaseDatos.obtenerArticuloPorIid(despi.getArticulo().getIid());

            fv = BaseDatos.obtenerFamiliaVentaPorIid(arti.getIid_fam_venta().getIid());
            if (fv.getIid_tipo_control().getIid_tipo_medida().getNombre().equals("Cantidad")) {
                unidades = new DesUnidades();
                unidades.setAr(arti);
                unidades.setIidLineaPresupuesto(getLPresupuesto().getIid());

                if (despi.getCaracteristica() != null) {
                    unidades.setCar(BaseDatos.obtenerCaracteristicaPorIid(despi.getCaracteristica().getIid()));
                }

                unidades.setCantidad(this.evaluar(despi.getFormulaCantidad(), despi.getRedondeo(), false) * lp.getCantidad());
                listaArticulo.add(unidades);
            }
            indiceDespi++;
        }
        return listaArticulo;
    }

    private void crearIconosBotones() {
        URL url = getClass().getResource("/iconos/cancelar.gif");
        ImageIcon icono = new ImageIcon(url);
        bCancelar.setIcon(icono);

        url = getClass().getResource("/iconos/aceptar.png");
        icono = new ImageIcon(url);
        bAceptar.setIcon(icono);

        url = getClass().getResource("/iconos/gomaBorrar.gif");
        icono = new ImageIcon(url);
        bBorrar.setIcon(icono);

        url = getClass().getResource("/iconos/ojo.png");
        icono = new ImageIcon(url);
        bVerTodos.setIcon(icono);

        url = getClass().getResource("/iconos/arriba.png");
        icono = new ImageIcon(url);
        bSubir.setIcon(icono);

        url = getClass().getResource("/iconos/abajo.png");
        icono = new ImageIcon(url);
        bBajar.setIcon(icono);

        url = getClass().getResource("/iconos/añadir.png");
        icono = new ImageIcon(url);
        bAñadir.setIcon(icono);

        url = getClass().getResource("/iconos/insertar.png");
        icono = new ImageIcon(url);
        bInsertar.setIcon(icono);

        url = getClass().getResource("/iconos/modificar_despiece.png");
        icono = new ImageIcon(url);
        bModificarDespiece.setIcon(icono);
    }

    public String getDescripcionDac() {
        return this.tDescripcionDac.getText();
    }

    public List<Variable> getListaVbles() {
        return listaVbles;
    }

    protected String getStringColorLacado() {
        return (String) cLacado.getSelectedItem();
    }

    protected String getStringColorAccesorios() {
        return (String) cAccesorios.getSelectedItem();
    }

    public String getMagnitud1() {
        return this.lMagnitud1.getText();
    }

    public String getMagnitud2() {
        return this.lMagnitud2.getText();
    }

    public String getMagnitud3() {
        return this.lMagnitud3.getText();
    }

    public String getMagnitud4() {
        return this.lMagnitud4.getText();
    }

    public String getMagnitud5() {
        return this.lMagnitud5.getText();
    }

    protected void setMedida1(String medida1) {
        tMedida1.setText(medida1);
    }

    protected void setMedida2(String medida2) {
        tMedida2.setText(medida2);
    }

    protected void setMedida3(String medida3) {
        tMedida3.setText(medida3);
    }

    protected void setMedida4(String medida4) {
        tMedida4.setText(medida4);
    }

    protected void setMedida5(String medida5) {
        tMedida5.setText(medida5);
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bAceptar;
    private javax.swing.JButton bAtacuerda;
    private javax.swing.JButton bAtacuerdaPared;
    private javax.swing.JButton bAñadir;
    private javax.swing.JButton bBajar;
    private javax.swing.JButton bBambolina;
    private javax.swing.JButton bBambolinaPlano;
    private javax.swing.JButton bBorrar;
    private javax.swing.JButton bBrazo;
    private javax.swing.JButton bCancelar;
    private javax.swing.JButton bCarruchaDoble;
    private javax.swing.JButton bCarruchaSimple;
    private javax.swing.JButton bCasquillo;
    private javax.swing.JButton bGancho;
    private javax.swing.JButton bInsertar;
    private javax.swing.JButton bLona;
    private javax.swing.JButton bManivela;
    private javax.swing.JButton bMaquina;
    private javax.swing.JButton bModificarDespiece;
    private javax.swing.JButton bPerfil;
    private javax.swing.JButton bPerfilCofre;
    private javax.swing.JButton bPerfilPlano;
    private javax.swing.JButton bPoleaDerecha;
    private javax.swing.JButton bPoleaIzquierda;
    private javax.swing.JButton bSoporte;
    private javax.swing.JButton bSubir;
    private javax.swing.JButton bTapa;
    private javax.swing.JButton bTerminal;
    private javax.swing.JButton bTuboEnrrolle;
    private javax.swing.JButton bVerTodos;
    private javax.swing.JComboBox cAccesorios;
    private javax.swing.JComboBox cLacado;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane10;
    private javax.swing.JScrollPane jScrollPane11;
    private javax.swing.JScrollPane jScrollPane12;
    private javax.swing.JScrollPane jScrollPane13;
    private javax.swing.JScrollPane jScrollPane14;
    private javax.swing.JScrollPane jScrollPane15;
    private javax.swing.JScrollPane jScrollPane16;
    private javax.swing.JScrollPane jScrollPane17;
    private javax.swing.JScrollPane jScrollPane18;
    private javax.swing.JScrollPane jScrollPane19;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane20;
    private javax.swing.JScrollPane jScrollPane21;
    private javax.swing.JScrollPane jScrollPane22;
    private javax.swing.JScrollPane jScrollPane23;
    private javax.swing.JScrollPane jScrollPane24;
    private javax.swing.JScrollPane jScrollPane25;
    private javax.swing.JScrollPane jScrollPane26;
    private javax.swing.JScrollPane jScrollPane27;
    private javax.swing.JScrollPane jScrollPane28;
    private javax.swing.JScrollPane jScrollPane29;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane30;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JScrollPane jScrollPane8;
    private javax.swing.JScrollPane jScrollPane9;
    private javax.swing.JLabel lAccesorios;
    private javax.swing.JLabel lCantidad;
    private javax.swing.JLabel lCodigo;
    private javax.swing.JLabel lDescripcion;
    private javax.swing.JLabel lLacado;
    private javax.swing.JLabel lMagnitud1;
    private javax.swing.JLabel lMagnitud2;
    private javax.swing.JLabel lMagnitud3;
    private javax.swing.JLabel lMagnitud4;
    private javax.swing.JLabel lMagnitud5;
    private javax.swing.JLabel lMagnitudCantidad;
    private javax.swing.JLabel lUnidad1;
    private javax.swing.JLabel lUnidad2;
    private javax.swing.JLabel lUnidad3;
    private javax.swing.JLabel lUnidad4;
    private javax.swing.JLabel lUnidad5;
    private javax.swing.JPanel pDespiece;
    private javax.swing.JPanel pMedidas;
    private javax.swing.JPanel pSeleccionArticulo;
    private javax.swing.JPanel pSeleccionArticulo2;
    private javax.swing.JPanel pVariables;
    private javax.swing.JPanel panelFondoToldoEnrrollado;
    private javax.swing.JPanel panelFondoToldoPlano;
    private javax.swing.JPanel panelMedidaGuias;
    private javax.swing.JTabbedPane panelesToldos;
    private javax.swing.JTextArea tAtacuerdaArea;
    private javax.swing.JTextArea tAtacuerdaParedArea;
    private javax.swing.JTextArea tBambolinaArea;
    private javax.swing.JLabel tBambolinaAreaMedida;
    private javax.swing.JLabel tBambolinaEnrrolladoModelo;
    private javax.swing.JLabel tBambolinaEnrrolladoRibete;
    private javax.swing.JTextArea tBambolinaPlanoArea;
    private javax.swing.JLabel tBambolinaPlanoAreaMedida;
    private javax.swing.JLabel tBambolinaPlanoModelo;
    private javax.swing.JLabel tBambolinaPlanoRibete;
    private javax.swing.JTextArea tBrazoDerechoArea;
    private javax.swing.JTextArea tBrazoIzquierdoArea;
    private javax.swing.JTextField tCantidad;
    private javax.swing.JTextField tCantidadGuias;
    private javax.swing.JLabel tCantidadPalillos;
    private javax.swing.JTextArea tCarruchaDobleArea;
    private javax.swing.JTextArea tCarruchaSimpleArea;
    private javax.swing.JTextArea tCasquilloDerechoArea;
    private javax.swing.JTextArea tCasquilloIzquierdoArea;
    private javax.swing.JTextField tCodigo;
    private javax.swing.JTextField tDescripcion;
    private javax.swing.JTextField tDescripcionDac;
    private javax.swing.JTable tDespiece;
    private javax.swing.JTextArea tGanchoDerechaArea;
    private javax.swing.JTextArea tGanchoIzquierdoArea;
    private javax.swing.JTextArea tManivelaArea;
    private javax.swing.JTextArea tMaquinaDerechaArea;
    private javax.swing.JTextArea tMaquinaIzquierdaArea;
    private javax.swing.JTextField tMedida1;
    private javax.swing.JTextField tMedida2;
    private javax.swing.JTextField tMedida3;
    private javax.swing.JTextField tMedida4;
    private javax.swing.JTextField tMedida5;
    private javax.swing.JTextField tMedidasGuias;
    private javax.swing.JTextArea tPerfilArea;
    private javax.swing.JLabel tPerfilAreaMedida;
    private javax.swing.JTextArea tPerfilCofreArea;
    private javax.swing.JLabel tPerfilCofreAreaMedida;
    private javax.swing.JTextArea tPerfilPlanoArea;
    private javax.swing.JLabel tPerfilPlanoAreaMedida;
    private javax.swing.JTextArea tPoleaDerechaArea;
    private javax.swing.JTextArea tPoleaIzquierdaArea;
    private javax.swing.JTextArea tSoporteDerechoArea;
    private javax.swing.JTextArea tSoporteIzquierdoArea;
    private javax.swing.JTextArea tTapaDerechaArea;
    private javax.swing.JTextArea tTapaIzquierdaArea;
    private javax.swing.JTextArea tTelaArea;
    private javax.swing.JLabel tTelaAreaMedida;
    private javax.swing.JTextArea tTerminalDerechoArea;
    private javax.swing.JTextArea tTerminalIzquierdoArea;
    private javax.swing.JLabel tTipoLona;
    private javax.swing.JTextArea tTuboEnrrolleArea;
    private javax.swing.JLabel tTuboEnrrolleAreaMedida;
    private javax.swing.JLabel tVV;
    // End of variables declaration//GEN-END:variables
}
