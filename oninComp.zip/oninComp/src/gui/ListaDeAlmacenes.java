package gui;

import acceso.*;
import java.awt.HeadlessException;
import modelo.*;
import bean.*;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JOptionPane;
import javax.swing.KeyStroke;

public class ListaDeAlmacenes extends javax.swing.JFrame {

    public ListaDeAlmacenes() {
        super("Almacén - Mantenimiento");
        initComponents();
        crearIconosBotones();
        crearAcciones();
    }

    private void borrarAlmacen() throws HeadlessException {
        try {
            int indice = talmacenes.getSelectedRow();
            if (indice >= 0) {

                int eliminar = 1;
                eliminar = JOptionPane.showConfirmDialog(null, "Está seguro de que desea eliminar el elemento seleccionado?", "¿Eliminar?", JOptionPane.YES_NO_OPTION);
                //hacerCambios = -1 ==> se ha pulsado la "x" de cancelar;
                //hacerCambios =  0 ==> se ha pulsado el "sí"
                //hacerCambios =  1 ==> se ha pulsado el "no"
                if (eliminar == 0) {

                    //obtenemos nombre del almacen seleccionado
                    String nombre = (String) talmacenes.getModel().getValueAt(indice, 0);

                    //obtenemos el almacen a través de su código
                    Almacen almacen = BaseDatos.obtenerAlmacen(nombre);

                    //Primero habría que borrar las existencias de ese almacén
                    if (BaseDatos.eliminarElemento(almacen.getClass(), almacen.getIid())) {
                        completarPantalla();
                    } else {
                        JOptionPane.showMessageDialog(null, "No se ha podido eliminar el elemento", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
            } else {
                JOptionPane.showMessageDialog(null, "No hay seleccionado ningún elemento", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Este elemento no se puede eliminar", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void crearAcciones() {
        KeyStroke escapeKeyStroke = KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false);
        Action escapeAction = new AbstractAction() {
            public void actionPerformed(ActionEvent e) {
                cerrarListado();
            }
        }; 
        getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(escapeKeyStroke, "ESCAPE");
        getRootPane().getActionMap().put("ESCAPE", escapeAction);
        
        KeyStroke f1KeyStroke = KeyStroke.getKeyStroke (KeyEvent.VK_F1, 0, false);
        Action f1Action = new AbstractAction() {
            public void actionPerformed(ActionEvent ev) {
                crearAlmacen();
            }
        }; 
        getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(f1KeyStroke, "F1");
        getRootPane().getActionMap().put("F1", f1Action);
    }
    
    private void crearAlmacen(){
        NuevoAlmacen na = new NuevoAlmacen(this, "Almacen - Creación");
        na.setDefaultCloseOperation(NuevoAlmacen.DISPOSE_ON_CLOSE);
        na.setLocationRelativeTo(null);
        na.setVisible(true);
        cerrarListado();
    }
    
    private void cerrarListado(){
        removeAll();
        dispose();
    }
    
    private void crearIconosBotones() {
        URL urlVisualizar = getClass().getResource("/iconos/buscar.gif");
        ImageIcon iconoVisualizar = new ImageIcon(urlVisualizar);
        bmodificar.setIcon(iconoVisualizar);
        
        URL urlBorrar = getClass().getResource("/iconos/eliminar.png");
        ImageIcon iconoBorrar = new ImageIcon(urlBorrar);
        beliminar.setIcon(iconoBorrar);
        
        URL urlCerrar = getClass().getResource("/iconos/cancelar.gif");
        ImageIcon iconoCerrar = new ImageIcon(urlCerrar);
        bcerrar.setIcon(iconoCerrar);
        
        URL urlCrear = getClass().getResource("/iconos/aceptar.png");
        ImageIcon iconoCrear = new ImageIcon(urlCrear);
        bnuevo.setIcon(iconoCrear);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        Modelo modelo = new Modelo();
        talmacenes = new javax.swing.JTable(modelo);

        // Creamos las columnas.
        modelo.addColumn("Nombre");
        modelo.addColumn("Descripción");

        List lalmacenes = BaseDatos.getListaAlmacenes();
        Almacen a;
        for (Iterator it = lalmacenes.iterator(); it.hasNext();) {
            Object[] fila = new Object[2];
            a = (Almacen) it.next();
            fila[0] = a.getNombre();
            fila[1] = a.getDescripcion();
            modelo.addRow(fila);
        }
        ;
        bnuevo = new javax.swing.JButton();
        bmodificar = new javax.swing.JButton();
        beliminar = new javax.swing.JButton();
        bcerrar = new javax.swing.JButton();
        lbusqueda = new javax.swing.JLabel();
        tbusqueda = new javax.swing.JTextField();
        bbusquedarapida = new javax.swing.JCheckBox();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        talmacenes.getColumnModel().getColumn(0).setPreferredWidth(100);
        talmacenes.getColumnModel().getColumn(1).setPreferredWidth(300);
        talmacenes.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        talmacenes.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                talmacenesMouseClicked(evt);
            }
        });
        talmacenes.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                talmacenesKeyPressed(evt);
            }
        });
        jScrollPane1.setViewportView(talmacenes);

        bnuevo.setText("Crear");
        bnuevo.setAutoscrolls(true);
        bnuevo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bnuevoActionPerformed(evt);
            }
        });

        bmodificar.setText("Visualizar");
        bmodificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bmodificarActionPerformed(evt);
            }
        });

        beliminar.setText("Borrar");
        beliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                beliminarActionPerformed(evt);
            }
        });

        bcerrar.setText("Cerrar");
        bcerrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bcerrarActionPerformed(evt);
            }
        });

        lbusqueda.setText("Búsqueda rápida");

        tbusqueda.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tbusquedaKeyReleased(evt);
            }
        });

        bbusquedarapida.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bbusquedarapidaActionPerformed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout layout = new org.jdesktop.layout.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, layout.createSequentialGroup()
                .addContainerGap(27, Short.MAX_VALUE)
                .add(bnuevo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 93, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                .add(beliminar, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 90, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                .add(bmodificar, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 101, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                .add(bcerrar, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 88, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
            .add(layout.createSequentialGroup()
                .addContainerGap()
                .add(lbusqueda, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 89, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(tbusqueda, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 300, Short.MAX_VALUE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(bbusquedarapida, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 21, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .add(13, 13, 13))
            .add(jScrollPane1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 439, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(lbusqueda)
                    .add(bbusquedarapida)
                    .add(tbusqueda, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jScrollPane1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 275, Short.MAX_VALUE)
                .add(18, 18, 18)
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(bcerrar)
                    .add(bmodificar)
                    .add(beliminar)
                    .add(bnuevo))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

private void bmodificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bmodificarActionPerformed
    visualizarAlmacen();
}//GEN-LAST:event_bmodificarActionPerformed

    private void visualizarAlmacen() {
        int indice = talmacenes.getSelectedRow();
        if (indice >= 0) {

            //obtenemos código del almacén seleccionado
            String nombre = (String) talmacenes.getModel().getValueAt(indice, 0);

            //obtenemos el almacén a través de su código
            Almacen almacen = BaseDatos.obtenerAlmacen(nombre);
            NuevoAlmacen na = new NuevoAlmacen(this, "Almacén - Modificación", almacen);
            na.setDefaultCloseOperation(NuevoAlmacen.DISPOSE_ON_CLOSE);
            na.setLocationRelativeTo(null);
            na.setVisible(true);
            cerrarListado();
        } else {
            JOptionPane.showMessageDialog(null, "No hay seleccionado ningún elemento", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
private void beliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_beliminarActionPerformed
        borrarAlmacen();
}//GEN-LAST:event_beliminarActionPerformed

private void bnuevoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bnuevoActionPerformed
    crearAlmacen();
}//GEN-LAST:event_bnuevoActionPerformed

private void bcerrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bcerrarActionPerformed
    cerrarListado();
}//GEN-LAST:event_bcerrarActionPerformed

private void bbusquedarapidaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bbusquedarapidaActionPerformed

    List lAlmacenes;
    if (bbusquedarapida.isSelected()) {
        String nombre = tbusqueda.getText().toLowerCase();
        lAlmacenes = BaseDatos.busquedaRapidaAlmacen(nombre);
    } else {
        lAlmacenes = BaseDatos.getListaAlmacenes();
    }
    actualizarAlmacen(lAlmacenes);
}//GEN-LAST:event_bbusquedarapidaActionPerformed

private void tbusquedaKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tbusquedaKeyReleased
    if (bbusquedarapida.isSelected()) {
        String nombre = tbusqueda.getText().toLowerCase();
        List lAlmacenes = BaseDatos.busquedaRapidaAlmacen(nombre);
        actualizarAlmacen(lAlmacenes);
    }
}//GEN-LAST:event_tbusquedaKeyReleased

private void talmacenesKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_talmacenesKeyPressed
    if (evt.getKeyChar() == KeyEvent.VK_ENTER) {
        visualizarAlmacen();
    } else if(evt.getKeyChar() == KeyEvent.VK_DELETE){
        borrarAlmacen();
    }
}//GEN-LAST:event_talmacenesKeyPressed

private void talmacenesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_talmacenesMouseClicked
    if (evt.getClickCount() == 2) {
        visualizarAlmacen();
    }
}//GEN-LAST:event_talmacenesMouseClicked

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JCheckBox bbusquedarapida;
    private javax.swing.JButton bcerrar;
    private javax.swing.JButton beliminar;
    private javax.swing.JButton bmodificar;
    private javax.swing.JButton bnuevo;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lbusqueda;
    private javax.swing.JTable talmacenes;
    private javax.swing.JTextField tbusqueda;
    // End of variables declaration//GEN-END:variables

    private void completarPantalla() {
        List la;

        //Si la búsqueda rápida está seleccionada la mostramos
        //en otro caso mostramos toda la lista
        if (bbusquedarapida.isSelected()) {
            String nombre = tbusqueda.getText().toLowerCase();
            la = BaseDatos.busquedaRapidaAlmacen(nombre);
        } else {
            la = BaseDatos.getListaAlmacenes();
        }
        actualizarAlmacen(la);
    }

    public void actualizarAlmacen(List lalmacenes) {

        Modelo modelo = (Modelo) talmacenes.getModel();
        int i, j;

        //obtenemos el nº de filas;
        j = modelo.getRowCount();

        //eliminamos todas las filas
        for (i = 0; i < j; i++) {
            modelo.removeRow(0);
        }

        //obtenemos la lista de todos los almacén
        if (lalmacenes == null) {
            lalmacenes = new ArrayList();
        }
        Almacen a;
        Object[] fila = new Object[2];

        //vamos a insertar otra vez toda la tabla almacen
        for (Iterator it = lalmacenes.iterator(); it.hasNext();) {
            a = (Almacen) it.next();
            fila[0] = a.getNombre();
            fila[1] = a.getDescripcion();
            modelo.addRow(fila);
        }
    }
}
