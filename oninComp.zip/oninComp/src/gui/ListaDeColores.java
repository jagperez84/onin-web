package gui;

import acceso.BaseDatos;
import modelo.Modelo;
import bean.Colores;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JOptionPane;
import javax.swing.KeyStroke;

public class ListaDeColores extends javax.swing.JFrame {

    public ListaDeColores() {
        super("Color - Mantenimiento");
        initComponents();
        crearIconosBotones();
        crearAcciones();
    }
    
    private void crearAcciones(){
        KeyStroke escapeKeyStroke = KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false);
        Action escapeAction = new AbstractAction() {
            public void actionPerformed(ActionEvent e) {
                cerrarListado();
            }
        }; 
        getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(escapeKeyStroke, "ESCAPE");
        getRootPane().getActionMap().put("ESCAPE", escapeAction);
        
        KeyStroke f1KeyStroke = KeyStroke.getKeyStroke (KeyEvent.VK_F1, 0, false);
        Action f1Action = new AbstractAction() {
            public void actionPerformed(ActionEvent ev) {
                crearColores();
            }
        }; 
        getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(f1KeyStroke, "F1");
        getRootPane().getActionMap().put("F1", f1Action);
    }
    
    private void cerrarListado(){
        removeAll();
        dispose();
    }

    private void crearIconosBotones() {
        URL url = getClass().getResource("/iconos/buscar.gif");
        ImageIcon icono = new ImageIcon(url);
        bmodificar.setIcon(icono);

        url = getClass().getResource("/iconos/eliminar.png");
        icono = new ImageIcon(url);
        beliminar.setIcon(icono);

        url = getClass().getResource("/iconos/cancelar.gif");
        icono = new ImageIcon(url);
        bcerrar.setIcon(icono);

        url = getClass().getResource("/iconos/aceptar.png");
        icono = new ImageIcon(url);
        bnuevo.setIcon(icono);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        Modelo modelo = new Modelo();
        tcolores = new javax.swing.JTable(modelo);

        // Creamos las columnas.
        modelo.addColumn("Código");
        modelo.addColumn("Descripción");

        List lcolores = BaseDatos.getListaColores();
        Colores c;
		Object[] fila;
        for (Iterator<Colores> it = lcolores.iterator(); it.hasNext();) {
            fila = new Object[2];
            c = it.next();
            fila[0] = c.getCod_color();
            fila[1] = c.getDescripcion();
            modelo.addRow(fila);
        }
        ;
        bnuevo = new javax.swing.JButton();
        bmodificar = new javax.swing.JButton();
        beliminar = new javax.swing.JButton();
        bcerrar = new javax.swing.JButton();
        lbusqueda = new javax.swing.JLabel();
        tbusqueda = new javax.swing.JTextField();
        bbusquedarapida = new javax.swing.JCheckBox();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        tcolores.getColumnModel().getColumn(0).setPreferredWidth(100);
        tcolores.getColumnModel().getColumn(1).setPreferredWidth(300);
        tcolores.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        tcolores.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tcoloresMouseClicked(evt);
            }
        });
        tcolores.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tcoloresKeyPressed(evt);
            }
        });
        jScrollPane1.setViewportView(tcolores);

        bnuevo.setText("Crear");
        bnuevo.setAutoscrolls(true);
        bnuevo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bnuevoActionPerformed(evt);
            }
        });

        bmodificar.setText("Visualizar");
        bmodificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bmodificarActionPerformed(evt);
            }
        });

        beliminar.setText("Borrar");
        beliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                beliminarActionPerformed(evt);
            }
        });

        bcerrar.setText("Cerrar");
        bcerrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bcerrarActionPerformed(evt);
            }
        });

        lbusqueda.setText("Búsqueda rápida");

        tbusqueda.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tbusquedaKeyReleased(evt);
            }
        });

        bbusquedarapida.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bbusquedarapidaActionPerformed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout layout = new org.jdesktop.layout.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, layout.createSequentialGroup()
                .addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .add(bnuevo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 93, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                .add(beliminar, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 90, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                .add(bmodificar, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 101, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                .add(bcerrar, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 88, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
            .add(layout.createSequentialGroup()
                .addContainerGap()
                .add(lbusqueda, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 89, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(tbusqueda, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 283, Short.MAX_VALUE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(bbusquedarapida, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 21, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .add(13, 13, 13))
            .add(jScrollPane1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 422, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(lbusqueda)
                    .add(bbusquedarapida)
                    .add(tbusqueda, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jScrollPane1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 275, Short.MAX_VALUE)
                .add(18, 18, 18)
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(bcerrar)
                    .add(bmodificar)
                    .add(beliminar)
                    .add(bnuevo))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

private void bmodificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bmodificarActionPerformed
    visualizarColor();
}//GEN-LAST:event_bmodificarActionPerformed

private void beliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_beliminarActionPerformed
    borrarColor();
}//GEN-LAST:event_beliminarActionPerformed

private void borrarColor(){
    try {
        int indice = tcolores.getSelectedRow();
        if (indice >= 0) {
            if (JOptionPane.showConfirmDialog(null, "Está seguro de que desea eliminar el elemento seleccionado?", "¿Eliminar?", JOptionPane.YES_NO_OPTION) == 0) {
                //obtenemos el color a través de su código
                Colores color = BaseDatos.obtenerColor((String) tcolores.getModel().getValueAt(indice, 0));
                if (BaseDatos.eliminarElemento(color.getClass(), color.getIid())) {
                    completarPantalla();
                } else {
                    JOptionPane.showMessageDialog(null, "No se ha podido eliminar el elemento", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        } else {
            JOptionPane.showMessageDialog(null, "No hay seleccionado ningún elemento", "Error", JOptionPane.ERROR_MESSAGE);
        }
    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "Este elemento no se puede eliminar", "Error", JOptionPane.ERROR_MESSAGE);
    }
}

private void bnuevoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bnuevoActionPerformed
    crearColores();
}//GEN-LAST:event_bnuevoActionPerformed

private void bcerrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bcerrarActionPerformed
    cerrarListado();
}//GEN-LAST:event_bcerrarActionPerformed

private void crearColores(){
    NuevoColor nc = new NuevoColor("Color - Creación");
    nc.setDefaultCloseOperation(NuevoColor.DISPOSE_ON_CLOSE);
    nc.setLocationRelativeTo(null);
    nc.setVisible(true);
    cerrarListado();
}
private void bbusquedarapidaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bbusquedarapidaActionPerformed
    if (bbusquedarapida.isSelected()) {
        actualizarColores(BaseDatos.busquedaRapidaColores(tbusqueda.getText().toLowerCase()));
    } else {
        actualizarColores(BaseDatos.getListaColores());
    }
}//GEN-LAST:event_bbusquedarapidaActionPerformed

private void tbusquedaKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tbusquedaKeyReleased
    if (bbusquedarapida.isSelected()) {
        actualizarColores(BaseDatos.busquedaRapidaColores( tbusqueda.getText().toLowerCase()));
    }
}//GEN-LAST:event_tbusquedaKeyReleased

private void tcoloresKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tcoloresKeyPressed
    if (evt.getKeyChar() == KeyEvent.VK_ENTER) {
        visualizarColor();
    } else if(evt.getKeyChar() == KeyEvent.VK_DELETE){
        borrarColor();
    }
}//GEN-LAST:event_tcoloresKeyPressed

private void tcoloresMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tcoloresMouseClicked
    if (evt.getClickCount() == 2) {
        visualizarColor();
    }
}//GEN-LAST:event_tcoloresMouseClicked

    private void visualizarColor() {
        int indice = tcolores.getSelectedRow();
        if (indice >= 0) {
            //obtenemos el color a través de su código
            Colores color = BaseDatos.obtenerColor((String) tcolores.getModel().getValueAt(indice, 0));
            NuevoColor nc = new NuevoColor("Color - Modificación", color);
            nc.setDefaultCloseOperation(NuevoColor.DISPOSE_ON_CLOSE);
            nc.setLocationRelativeTo(null);
            nc.setVisible(true);
            cerrarListado();
        } else {
            JOptionPane.showMessageDialog(null, "No hay seleccionado ningún elemento", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JCheckBox bbusquedarapida;
    private javax.swing.JButton bcerrar;
    private javax.swing.JButton beliminar;
    private javax.swing.JButton bmodificar;
    private javax.swing.JButton bnuevo;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lbusqueda;
    private javax.swing.JTextField tbusqueda;
    private javax.swing.JTable tcolores;
    // End of variables declaration//GEN-END:variables

    private void completarPantalla() {
        if (bbusquedarapida.isSelected()) {
            actualizarColores(BaseDatos.busquedaRapidaColores( tbusqueda.getText().toLowerCase()));
        } else {
            actualizarColores(BaseDatos.getListaColores());
        }
    }

    public void actualizarColores(List lcolores) {
        Modelo modelo = (Modelo) tcolores.getModel();
        int i, j = modelo.getRowCount();

        //eliminamos todas las filas
        for (i = 0; i < j; i++) {
            modelo.removeRow(0);
        }

        //obtenemos la lista de todos los colores
        if (lcolores == null) {
            lcolores = new ArrayList();
        }
        Colores c;
        Object[] fila;

        //vamos a insertar otra vez toda la tabla colores
        for (Iterator<Colores> it = lcolores.iterator(); it.hasNext();) {
            c = it.next();
            fila = new Object[2];
            fila[0] = c.getCod_color();
            fila[1] = c.getDescripcion();
            modelo.addRow(fila);
        }
    }
}
