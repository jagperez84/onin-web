package gui;

import acceso.BaseDatos;
import auxiliar.CortePerfil;
import bean.Articulo;
import bean.Caracteristica;
import bean.Existencia;
import bean.LineaCortePerfil;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import util.Util;
import util.Constantes;

public class NuevaLineaCorteDePerfil extends javax.swing.JPanel {

    NuevoPresupuesto p;
    CortePerfil cortePerfil;
    int numPañosEnteros;
    Float alto;
    Float longitud;
    Float longitudSeleccionada;
    NuevoCortePerfil ncl;
    NuevoCorteLonaSimulado ncls;
    boolean hayRestos;
    List<Existencia> listaRestosUsados;
    List<Integer> listaRestosIniciales;
    boolean crear;
    boolean inicializar;
    Integer iid;
    String longitudAntigua;
    boolean hayCambios;

    public NuevaLineaCorteDePerfil(NuevoCortePerfil ncl, NuevoPresupuesto p, CortePerfil cortePerfil) {
        this.ncl = ncl;
        this.p = p;
        this.cortePerfil = cortePerfil;
        this.crear = false;
        this.listaRestosIniciales = new ArrayList<Integer>();
        this.inicializar = false;
        this.iid = null;
        initComponents();

        tCantidad.setEnabled(false);
        tLongitud.setEnabled(false);
        tCodigoLinea.setEnabled(false);
        tCodigo.setEnabled(false);
        tLongitud.setText(cortePerfil.getMedida1());
        
        iniciarLongitud();

        tCantidad.setText(cortePerfil.getCantidad());
        tCodigo.setText(cortePerfil.getCodigoArticuloCaracterisitica());
        tCodigoLinea.setText(cortePerfil.getCodigoLinea());
        hayCambios = false;

    }

    public NuevaLineaCorteDePerfil(NuevoCorteLonaSimulado ncls, NuevoPresupuesto p, CortePerfil cortePerfil) {
        this.ncls = ncls;
        this.p = p;
        this.cortePerfil = cortePerfil;
        this.crear = false;
        this.listaRestosIniciales = new ArrayList<Integer>();
        this.inicializar = false;
        this.iid = null;
        initComponents();

        tCantidad.setEnabled(false);
        tLongitud.setEnabled(false);
        tCodigoLinea.setEnabled(false);
        tCodigo.setEnabled(false);
        tLongitud.setText(cortePerfil.getMedida1());
        iniciarLongitud();

        tCantidad.setText(cortePerfil.getCantidad());
        tCodigo.setText(cortePerfil.getCodigoArticuloCaracterisitica());
        tCodigoLinea.setText(cortePerfil.getCodigoLinea());
        hayCambios = false;

    }

    public NuevaLineaCorteDePerfil(NuevoCortePerfil ncl, NuevoPresupuesto nuevoPresupuesto, CortePerfil cl, LineaCortePerfil lcl) {
        this.ncl = ncl;
        this.p = nuevoPresupuesto;
        this.cortePerfil = cl;
        this.crear = false;
        this.listaRestosIniciales = new ArrayList<Integer>();
        this.inicializar = true;
        this.iid = lcl.getIid();
        initComponents();

        tCantidad.setEnabled(false);
        tLongitud.setEnabled(false);
        tCodigoLinea.setEnabled(false);
        tCodigo.setEnabled(false);
        tLongitud.setText(Util.convertirPuntoAComa(lcl.getLongitud().toString()));

        iniciarLongitud();
        
        cLongitud.removeItem(Util.convertirPuntoAComa(new Float(lcl.getLongitudSeleccionada().toString()).toString()));
        cLongitud.addItem(Util.convertirPuntoAComa(new Float(lcl.getLongitudSeleccionada().toString()).toString()));
        cLongitud.setSelectedItem(Util.convertirPuntoAComa(new Float(lcl.getLongitudSeleccionada().toString()).toString()));
        longitudAntigua = Util.convertirPuntoAComa(new Float(lcl.getLongitudSeleccionada().toString()).toString());
        
        tCodigoLinea.setText(cl.getCodigoLinea().toString());
        tCantidad.setText(Util.convertirPuntoAComa(lcl.getCantidad().toString()));

        tCodigo.setText(cortePerfil.getCodigoArticuloCaracterisitica());

        repaint();
        ncl.actualizarLineas();
        this.inicializar = false;
        hayCambios = false;
    }
    
    public NuevaLineaCorteDePerfil(NuevoCorteLonaSimulado ncls, NuevoPresupuesto nuevoPresupuesto, CortePerfil cl, LineaCortePerfil lcl) {
        this.ncls = ncls;
        this.p = nuevoPresupuesto;
        this.cortePerfil = cl;
        this.crear = false;
        this.listaRestosIniciales = new ArrayList<Integer>();
        this.inicializar = true;
        this.iid = lcl.getIid();
        initComponents();

        tCantidad.setEnabled(false);
        tLongitud.setEnabled(false);
        tCodigoLinea.setEnabled(false);
        tCodigo.setEnabled(false);
        tLongitud.setText(Util.convertirPuntoAComa(new Float(lcl.getLongitudSeleccionada().toString()).toString()));
        iniciarLongitud();
        
        cLongitud.setSelectedItem(Util.convertirPuntoAComa(new Float(lcl.getLongitudSeleccionada().toString()).toString()));
        longitudAntigua = Util.convertirPuntoAComa(new Float(lcl.getLongitudSeleccionada().toString()).toString());
        
        tCodigoLinea.setText(cl.getCodigoLinea().toString());
        tCantidad.setText(Util.convertirPuntoAComa(lcl.getCantidad().toString()));
        tCodigo.setText(cortePerfil.getCodigoArticuloCaracterisitica());
        tLongitud.setText(longitudAntigua);

        repaint();
        ncl.actualizarLineas();
        this.inicializar = false;
        hayCambios = false;
    }

    public Integer getCodigoLinea() {
        return new Integer(tCodigoLinea.getText());
    }

    boolean finalizable() {
        boolean res = !((String)cLongitud.getSelectedItem()).equals(Constantes.SIN_EXISTENCIAS);
        
        if(res){
            realizarOperacion();
            hayCambios = hayCambios();
        }
        return res;

    }
    
    public boolean getEsDespiece(){
        return cortePerfil.getEsDespiece();
    }
    
    public List<Existencia> getListaRestosUsados(){
        return this.listaRestosUsados;
    }
    
    public CortePerfil getCortePerfil(){
        return cortePerfil;
    }

    private void iniciarLongitud() {
        cLongitud.addItem(Constantes.SIN_EXISTENCIAS);

        Float longitudInical = Float.parseFloat(Util.convertirComaAPunto(tLongitud.getText()));
        List listaExistencias;
        Caracteristica carac = cortePerfil.getCaracteristica();
        if (carac == null) {
            listaExistencias = BaseDatos.getListaExistencias(cortePerfil.getArticulo(), p.getAlmacen());
        } else {
            listaExistencias = BaseDatos.getListaExistencias(cortePerfil.getArticulo(), carac.getIid(), p.getAlmacen());
        }

        if (listaExistencias != null && listaExistencias.size() > 0) {
            Iterator iter = listaExistencias.iterator();
            Existencia ex;
            while (iter.hasNext()) {
                ex = (Existencia) iter.next();
                if(ex.getCantidad1() >= longitudInical){
                    cLongitud.removeItem(Util.convertirPuntoAComa(ex.getCantidad1().toString()));
                    cLongitud.addItem(Util.convertirPuntoAComa(ex.getCantidad1().toString()));
                }
            }
            
            if(cLongitud.getItemCount() > 1){
                cLongitud.setSelectedIndex(1);
            } else {
                cLongitud.setSelectedIndex(0);
            }
        }
    }

    public void realizarOperacion() {
        longitudSeleccionada = new Float(Util.convertirComaAPunto((String) cLongitud.getSelectedItem()));
    }
    
    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        tCodigo = new javax.swing.JTextField();
        tLongitud = new javax.swing.JTextField();
        cLongitud = new javax.swing.JComboBox();
        tCantidad = new javax.swing.JTextField();
        tCodigoLinea = new javax.swing.JTextField();

        setBackground(new java.awt.Color(204, 204, 204));
        setAutoscrolls(true);

        tLongitud.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N

        cLongitud.setModel(new javax.swing.DefaultComboBoxModel(new String[] {}));
        cLongitud.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cLongitudActionPerformed(evt);
            }
        });

        tCantidad.setFont(new java.awt.Font("Tahoma", 1, 11));

        tCodigoLinea.setFont(new java.awt.Font("Tahoma", 1, 11));

        org.jdesktop.layout.GroupLayout layout = new org.jdesktop.layout.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(layout.createSequentialGroup()
                .addContainerGap()
                .add(tCodigoLinea, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 51, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(tCantidad, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 51, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(tCodigo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 181, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .add(18, 18, 18)
                .add(tLongitud, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 70, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                .add(cLongitud, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 130, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(layout.createSequentialGroup()
                .addContainerGap()
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(tCodigo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(tCantidad, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(tCodigoLinea, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(tLongitud, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(cLongitud, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents


private void cLongitudActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cLongitudActionPerformed
    if(ncl == null){
        ncls.actualizarLineas();
    } else {
        ncl.actualizarLineas();
    }
}//GEN-LAST:event_cLongitudActionPerformed

    public boolean medidaRellena() {
        return !((String) cLongitud.getSelectedItem()).equals(Constantes.SIN_EXISTENCIAS);
    }
    
    public Float getCantidad(){
        return new Float(Util.convertirComaAPunto(tCantidad.getText()));
    }
    
    public Float getLongitud() {
        return new Float(Util.convertirComaAPunto(tLongitud.getText()));
    }

    public Float getLongitudSeleccionada() {
        return longitudSeleccionada;
    }

    public boolean isHayRestos() {
        return hayRestos;
    }

    public int getNumPañosEnteros() {
        return numPañosEnteros;
    }

    public Articulo getArticulo(){
        return cortePerfil.getArticulo();
    }
    
    public Caracteristica getCaracteristica(){
        return cortePerfil.getCaracteristica();
    }
    
    public boolean hayCambios(){
        String anchoNuevo = (String)cLongitud.getSelectedItem();
        return !anchoNuevo.equals(longitudAntigua);
    }
    
    public Integer getIid(){
        return this.iid;
    }
    
    public boolean getHayCambios(){
        return hayCambios;
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox cLongitud;
    private javax.swing.JTextField tCantidad;
    private javax.swing.JTextField tCodigo;
    private javax.swing.JTextField tCodigoLinea;
    private javax.swing.JTextField tLongitud;
    // End of variables declaration//GEN-END:variables
}
