package gui;

import acceso.BaseDatos;
import bean.Articulo;
import bean.Caracteristica;
import bean.Colores;
import bean.Dac;
import bean.Despiece;
import bean.Empresa;
import bean.FamiliaVenta;
import bean.LineaCorteLona;
import bean.LineaCortePerfil;
import bean.TipoControl;
import bean.TipoMedida;
import bean.Variable;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.net.URL;
import java.util.Iterator;
import java.util.List;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.KeyStroke;
import util.Constantes;
import util.Util;

public class NuevoArticuloOpcion extends javax.swing.JFrame {

    private Empresa e;
    private String tipoArticulo;
    private Articulo ar;
    private Caracteristica car;
    private JPanel panel1, panel2, panel3,panel4, panel5;
    private Dac dac;
    private Despiece despiece;
    private int numMedidas;
    private NuevoDAC ndac;
    private RellenarDac rdac;
    private String modificadorAntiguo;
    private boolean desdeDespiece;
    private int posicion;
    private boolean crear = false;
    
    public NuevoArticuloOpcion(Empresa e, String tipoArticulo, Articulo ar, Caracteristica car, Dac dac, NuevoDAC ndac, Despiece despiece, String modificador) {
        //Entro en crear articulo despiece desde boton "mas" en tipo articulo DAC
        super("Componente no visual - Propiedades");
        this.e = e;
        this.ar = ar;
        this.car = car;
        this.tipoArticulo = tipoArticulo;
        this.dac = dac;
        this.ndac = ndac;
        this.despiece = despiece;
        this.modificadorAntiguo = modificador;
        this.desdeDespiece = true;
        this.crear = true;
        initComponents();

        iniciarColores();
        if(this.despiece.getColor() != null){
          Colores c = BaseDatos.obtenerColorPorIid(this.despiece.getColor().getIid());
          this.cColores.setSelectedItem(c.getDescripcion());
        } else {
            //Se selecciona el valor -- Vacio --
            this.cColores.setSelectedIndex(0);
        }
        
        this.cModificador.setSelectedIndex(0);
        this.cModificador.setSelectedItem(modificador);
        if(despiece.getRedondeo() != null && !despiece.getRedondeo().equals("")){
            this.cRedondeo.setSelectedItem(despiece.getRedondeo());
        } else {
            this.cRedondeo.setSelectedIndex(0);
        }
        
        //tCodigoArticulo.setEnabled(false);
        tDescripcionArticulo.setEnabled(false);
              
        panel1 = this.pDim1;
        panel2 = this.pDim2;
        panel3 = this.pDim3;
        panel4 = this.pDim4;
        panel5 = this.pDim5;
        
        if(ar != null){
            
            this.ar = BaseDatos.obtenerArticuloPorIid(ar.getIid());
            
            String codCar = "";
            if(this.car != null){
                this.car = BaseDatos.obtenerCaracteristicaPorIid(this.car.getIid());
                Colores col = BaseDatos.obtenerColorPorIid(this.car.getIid_color().getIid());
                codCar = col.getCod_color();
            }

            tCodigoArticulo.setText(this.ar.getCod_articulo() + "/" + codCar);
            tDescripcionArticulo.setText(this.ar.getDes_inf());
        
            FamiliaVenta fv = this.ar.getIid_fam_venta();
            fv = BaseDatos.obtenerFamiliaVentaPorIid(fv.getIid());
            
            if(fv != null){
                if(fv.getNombre().equals(Constantes.NOMBRE_FAM_ESPECIFICACION)){
                    String nombreFV = "Especificación";
                    for(int contador = 5; contador > 0; contador--){
                            panelesDimension.remove(contador);
                    }
                    panelesDimension.setTitleAt(0, nombreFV);
                } else {

                    TipoControl tc = fv.getIid_tipo_control();
                    tc = BaseDatos.obtenerTipoControl(tc.getCodigo());

                    if(tc != null){
                        TipoMedida tm = tc.getIid_tipo_medida();
                        tm = BaseDatos.obtenerTipoMedidaByIid(tm.getIid());
                        medidaCantidad.setText(despiece.getFormulaCantidad());

                        numMedidas = tm.getNum_dimensiones();

                        if(numMedidas > 0){
                            panelesDimension.setTitleAt(1, tm.getNombre_dim_1() + " (" + tm.getUnidad_dim_1().getCod_unidad_medida() + ")");
                            medida1.setText(despiece.getFormulaMedida1());
                        }
                        if(numMedidas > 1){
                            panelesDimension.setTitleAt(2, tm.getNombre_dim_2() + " (" + tm.getUnidad_dim_2().getCod_unidad_medida() + ")");
                            medida2.setText(despiece.getFormulaMedida2());
                        }
                        if(numMedidas > 2){
                            panelesDimension.setTitleAt(3, tm.getNombre_dim_3() + " (" + tm.getUnidad_dim_3().getCod_unidad_medida() + ")");
                            medida3.setText(despiece.getFormulaMedida3());
                        }
                        if(numMedidas > 3){
                            panelesDimension.setTitleAt(4, tm.getNombre_dim_4() + " (" + tm.getUnidad_dim_4().getCod_unidad_medida() + ")");
                            medida4.setText(despiece.getFormulaMedida4());
                        }
                        if(numMedidas > 4){
                            panelesDimension.setTitleAt(5, tm.getNombre_dim_5() + " (" + tm.getUnidad_dim_5().getCod_unidad_medida() + ")");
                            medida5.setText(despiece.getFormulaMedida5());
                        }

                        for(int contador = 5; contador > numMedidas; contador--){
                            panelesDimension.remove(contador);
                        }
                    }
                }
            }
   
        } else {
            this.panelesDimension.setVisible(false);
        }
        
        boolean articuloBase = false;
        boolean anadirPvp = false;
        boolean anadirIncremento = false;
        
        if(despiece.getArticuloBase() == null){
            articuloBase = false;
        } else {
            articuloBase = despiece.getArticuloBase();
        }
        
        if(despiece.getAnadirPvp() == null){
            anadirPvp = false;
        } else {
            anadirPvp = despiece.getAnadirPvp();
        }
        
        if(despiece.getAnadirIncremento() == null){
            anadirIncremento = false;
        } else {
            anadirIncremento = despiece.getAnadirIncremento();
        }
        
        if(!articuloBase && !anadirPvp && !anadirIncremento){
            articuloBase = true;
        }
        
        rbArticuloBase.setSelected(articuloBase);
        rbAnadirPvp.setSelected(anadirPvp);
        rbAnadirIncremento.setSelected(anadirIncremento);
        
        if(this.ar != null){
            boolean habilitarIncremento = true;

            if (ar.getEscalado() || ar.getEscaladoCaracteristica()) {
                habilitarIncremento = false;
            }

            this.rbAnadirIncremento.setEnabled(habilitarIncremento);

            if (!habilitarIncremento && rbAnadirIncremento.isSelected()) {
                rbAnadirIncremento.setSelected(false);
                rbAnadirPvp.setSelected(true);
            }
        }
        
        crearIconosBotones();
        crearAcciones();

    }
        
    public NuevoArticuloOpcion(Empresa e, String tipoArticulo, Articulo ar, Caracteristica car, Dac dac, RellenarDac rdac, Despiece despiece, String modificador) {
        //Entro en crear articulo despiece desde boton "mas" en tipo articulo RELLENAR DAC
        super("Componente no visual - Propiedades");
        this.e = e;
        this.ar = ar;
        this.car = car;
        this.tipoArticulo = tipoArticulo;
        this.dac = dac;
        this.rdac = rdac;
        this.despiece = despiece;
        this.modificadorAntiguo = modificador;
        this.desdeDespiece = true;
        this.crear = true;
        initComponents();

        iniciarColores();
        if(this.despiece.getColor() != null){
          Colores c = BaseDatos.obtenerColorPorIid(this.despiece.getColor().getIid());
          this.cColores.setSelectedItem(c.getDescripcion());
        } else {
            //Se selecciona el valor -- Vacio --
            this.cColores.setSelectedIndex(0);
        }
        
        this.cModificador.setSelectedIndex(0);
        this.cModificador.setSelectedItem(modificador);
        if(despiece.getRedondeo() != null && !despiece.getRedondeo().equals("")){
            this.cRedondeo.setSelectedItem(despiece.getRedondeo());
        } else {
            this.cRedondeo.setSelectedIndex(0);
        }
        
        tDescripcionArticulo.setEnabled(false);
              
        panel1 = this.pDim1;
        panel2 = this.pDim2;
        panel3 = this.pDim3;
        panel4 = this.pDim4;
        panel5 = this.pDim5;
        
        if(ar != null){
            
            this.ar = BaseDatos.obtenerArticuloPorIid(ar.getIid());
            
            String codCar = "";
            if(this.car != null){
                this.car = BaseDatos.obtenerCaracteristicaPorIid(this.car.getIid());
                Colores col = BaseDatos.obtenerColorPorIid(this.car.getIid_color().getIid());
                codCar = col.getCod_color();
            }
            tCodigoArticulo.setText(this.ar.getCod_articulo() + "/" + codCar);
            tDescripcionArticulo.setText(this.ar.getDes_inf());
        
            FamiliaVenta fv = this.ar.getIid_fam_venta();
            fv = BaseDatos.obtenerFamiliaVentaPorIid(fv.getIid());
            
            if(fv != null){
                TipoControl tc = fv.getIid_tipo_control();
                tc = BaseDatos.obtenerTipoControl(tc.getCodigo());
                
                if(tc != null){
                    TipoMedida tm = tc.getIid_tipo_medida();
                    tm = BaseDatos.obtenerTipoMedidaByIid(tm.getIid());
                    medidaCantidad.setText(despiece.getFormulaCantidad());
                    
                    numMedidas = tm.getNum_dimensiones();
                    
                    if(numMedidas > 0){
                        panelesDimension.setTitleAt(1, tm.getNombre_dim_1() + " (" + tm.getUnidad_dim_1().getCod_unidad_medida() + ")");
                        medida1.setText(despiece.getFormulaMedida1());
                    }
                    if(numMedidas > 1){
                        panelesDimension.setTitleAt(2, tm.getNombre_dim_2() + " (" + tm.getUnidad_dim_2().getCod_unidad_medida() + ")");
                        medida2.setText(despiece.getFormulaMedida2());
                    }
                    if(numMedidas > 2){
                        panelesDimension.setTitleAt(3, tm.getNombre_dim_3() + " (" + tm.getUnidad_dim_3().getCod_unidad_medida() + ")");
                        medida3.setText(despiece.getFormulaMedida3());
                    }
                    if(numMedidas > 3){
                        panelesDimension.setTitleAt(4, tm.getNombre_dim_4() + " (" + tm.getUnidad_dim_4().getCod_unidad_medida() + ")");
                        medida4.setText(despiece.getFormulaMedida4());
                    }
                    if(numMedidas > 4){
                        panelesDimension.setTitleAt(5, tm.getNombre_dim_5() + " (" + tm.getUnidad_dim_5().getCod_unidad_medida() + ")");
                        medida5.setText(despiece.getFormulaMedida5());
                    }
                    
                    for(int contador = 5; contador > numMedidas; contador--){
                        panelesDimension.remove(contador);
                    }
                }
            }
        } else {
            this.panelesDimension.setVisible(false);
        }
        

        if(this.ar == null){
            rbArticuloBase.setSelected(false);
            rbAnadirPvp.setSelected(true);
            rbAnadirIncremento.setSelected(false);
        } else {
            boolean articuloBase = false;
            boolean anadirPvp = false;
            boolean anadirIncremento = false;

            if(despiece.getArticuloBase() == null){
                articuloBase = false;
            } else {
                articuloBase = despiece.getArticuloBase();
            }

            if(despiece.getAnadirPvp() == null){
                anadirPvp = false;
            } else {
                anadirPvp = despiece.getAnadirPvp();
            }

            if(despiece.getAnadirIncremento() == null){
                anadirIncremento = false;
            } else {
                anadirIncremento = despiece.getAnadirIncremento();
            }

            if(!articuloBase && !anadirPvp && !anadirIncremento){
                articuloBase = true;
            }

            rbArticuloBase.setSelected(articuloBase);
            rbAnadirPvp.setSelected(anadirPvp);
            rbAnadirIncremento.setSelected(anadirIncremento);
            
            boolean habilitarIncremento = true;

            if (ar.getEscalado() || ar.getEscaladoCaracteristica()) {
                habilitarIncremento = false;
            }

            this.rbAnadirIncremento.setEnabled(habilitarIncremento);

            if (!habilitarIncremento && rbAnadirIncremento.isSelected()) {
                rbAnadirIncremento.setSelected(false);
                rbAnadirPvp.setSelected(true);
            }

        }
        
        crearIconosBotones();
        crearAcciones();
    }
    
    public NuevoArticuloOpcion(Empresa e, Dac dac, Articulo ar, Caracteristica car, NuevoDAC ndac, Despiece despiece) {
        //Entro en modficar articulo despiece desde crear dac
        super("Componente no visual - Propiedades");
        this.e = e;
        this.tipoArticulo = despiece.getTipoArticulo();
        this.dac = dac;
        this.ndac = ndac;
        this.despiece = despiece;
        this.ar = ar;
        this.car = car;
        this.crear = false;
        initComponents();
        
        if(this.tipoArticulo != null && !this.tipoArticulo.equals("")){
            String modificador = "";
            if(this.tipoArticulo.equals("Lona")){
                modificador = "Lona";
            } else if(this.tipoArticulo.equals("Faldon")){
                modificador = "Faldón";
            } else if(this.tipoArticulo.equals("TipoFaldon")){
                modificador = "Tipo faldón";
            } else if(this.tipoArticulo.equals("Ribete")){
                modificador = "Ribete";
            } else if(this.tipoArticulo.equals("Brazos")){
                modificador = "Brazos";
            } else if(this.tipoArticulo.equals("Motor")){
                modificador = "Motor";
            } else if(this.tipoArticulo.equals("TuboCarga")){
                modificador = "Tubo carga";
            } else if(this.tipoArticulo.equals("TuboEnrolle")){
                modificador = "Tubo enrolle";
            } else if(this.tipoArticulo.equals("Manivelas")){
                modificador = "Manivelas";
            } else if(this.tipoArticulo.equals("Maquina")){
                modificador = "Máquina";
            } else if(this.tipoArticulo.equals("Soporte")){
                modificador = "Soporte";
            } else if(this.tipoArticulo.equals("Casquillo")){
                modificador = "Casquillo";
            } else if(this.tipoArticulo.equals("Terminal")){
                modificador = "Terminal";
            }  else if(this.tipoArticulo.equals("Tapa")){
                modificador = "Tapa";
            } else if(this.tipoArticulo.equals("Perfil")){
                modificador = "Perfil";
            } else if(this.tipoArticulo.equals("Bambolina")){
                modificador = "Bambolina";
            } else if(this.tipoArticulo.equals("Gancho")){
                modificador = "Gancho";
            } else if(this.tipoArticulo.equals("PoleaIzquierda")){
                modificador = "Polea izquierda";
            } else if(this.tipoArticulo.equals("PoleaDerecha")){
                modificador = "Polea derecha";
            } else if(this.tipoArticulo.equals("Atacuerda")){
                modificador = "Atacuerda";
            } else if(this.tipoArticulo.equals("CarruchaSimple")){
                modificador = "Carrucha simple";
            } else if(this.tipoArticulo.equals("CarruchaDoble")){
                modificador = "Carrucha doble";
            }

            this.desdeDespiece = true;
            this.modificadorAntiguo = modificador;
            this.cModificador.setSelectedItem(modificador);
        } else {
            this.desdeDespiece = false;
        }
        
        iniciarColores();
        
        if(this.despiece.getColor() != null){
          Colores c = BaseDatos.obtenerColorPorIid(this.despiece.getColor().getIid());
          this.cColores.setSelectedItem(c.getDescripcion());
        } else {
            //Se selecciona el valor -- Vacio --
            this.cColores.setSelectedIndex(0);
        }
        
        if(despiece.getRedondeo() != null && !despiece.getRedondeo().equals("")){
            this.cRedondeo.setSelectedItem(despiece.getRedondeo());
        } else {
            this.cRedondeo.setSelectedIndex(0);
        }
        
        //tCodigoArticulo.setEnabled(false);
        tDescripcionArticulo.setEnabled(false);
        
        panel1 = this.pDim1;
        panel2 = this.pDim2;
        panel3 = this.pDim3;
        panel4 = this.pDim4;
        panel5 = this.pDim5;
        
        if(ar != null){
            
            this.ar = BaseDatos.obtenerArticuloPorIid(ar.getIid());
            
            String codCar = "";
            if(this.car != null){
                this.car = BaseDatos.obtenerCaracteristicaPorIid(this.car.getIid());
                Colores col = BaseDatos.obtenerColorPorIid(this.car.getIid_color().getIid());
                codCar = col.getCod_color();
            }
            tCodigoArticulo.setText(this.ar.getCod_articulo() + "/" + codCar);
            tDescripcionArticulo.setText(this.ar.getDes_inf());
        
            FamiliaVenta fv = this.ar.getIid_fam_venta();
            fv = BaseDatos.obtenerFamiliaVentaPorIid(fv.getIid());
            
            if(fv != null){
                if(fv.getNombre().equals(Constantes.NOMBRE_FAM_ESPECIFICACION)){
                    String nombreFV = "Especificación";
                    for(int contador = 5; contador > 0; contador--){
                            panelesDimension.remove(contador);
                    }
                    panelesDimension.setTitleAt(0, nombreFV);
                    medidaCantidad.setText(despiece.getFormulaCantidad());
                } else {
                    TipoControl tc = fv.getIid_tipo_control();
                    tc = BaseDatos.obtenerTipoControl(tc.getCodigo());

                    if(tc != null){
                        TipoMedida tm = tc.getIid_tipo_medida();
                        tm = BaseDatos.obtenerTipoMedidaByIid(tm.getIid());
                        medidaCantidad.setText(despiece.getFormulaCantidad());

                        numMedidas = tm.getNum_dimensiones();

                        if(numMedidas > 0){
                            panelesDimension.setTitleAt(1, tm.getNombre_dim_1() + " (" + tm.getUnidad_dim_1().getCod_unidad_medida() + ")");
                            medida1.setText(despiece.getFormulaMedida1());
                        }
                        if(numMedidas > 1){
                            panelesDimension.setTitleAt(2, tm.getNombre_dim_2() + " (" + tm.getUnidad_dim_2().getCod_unidad_medida() + ")");
                            medida2.setText(despiece.getFormulaMedida2());
                        }
                        if(numMedidas > 2){
                            panelesDimension.setTitleAt(3, tm.getNombre_dim_3() + " (" + tm.getUnidad_dim_3().getCod_unidad_medida() + ")");
                            medida3.setText(despiece.getFormulaMedida3());
                        }
                        if(numMedidas > 3){
                            panelesDimension.setTitleAt(4, tm.getNombre_dim_4() + " (" + tm.getUnidad_dim_4().getCod_unidad_medida() + ")");
                            medida4.setText(despiece.getFormulaMedida4());
                        }
                        if(numMedidas > 4){
                            panelesDimension.setTitleAt(5, tm.getNombre_dim_5() + " (" + tm.getUnidad_dim_5().getCod_unidad_medida() + ")");
                            medida5.setText(despiece.getFormulaMedida5());
                        }

                        for(int contador = 5; contador > numMedidas; contador--){
                            panelesDimension.remove(contador);
                        }
                    }
                }
            }
        } else {
            this.panelesDimension.setVisible(false);
        }
        
        boolean articuloBase = false;
        boolean anadirPvp = false;
        boolean anadirIncremento = false;
        
        if(despiece.getArticuloBase() == null){
            articuloBase = false;
        } else {
            articuloBase = despiece.getArticuloBase();
        }
        
        if(despiece.getAnadirPvp() == null){
            anadirPvp = false;
        } else {
            anadirPvp = despiece.getAnadirPvp();
        }
        
        if(despiece.getAnadirIncremento() == null){
            anadirIncremento = false;
        } else {
            anadirIncremento = despiece.getAnadirIncremento();
        }
        
        if(!articuloBase && !anadirPvp && !anadirIncremento){
            articuloBase = true;
        }
        
        rbArticuloBase.setSelected(articuloBase);
        rbAnadirPvp.setSelected(anadirPvp);
        rbAnadirIncremento.setSelected(anadirIncremento);
        
        if(this.ar != null){
            boolean habilitarIncremento = true;

            if (ar.getEscalado() || ar.getEscaladoCaracteristica()) {
                habilitarIncremento = false;
            }

            this.rbAnadirIncremento.setEnabled(habilitarIncremento);

            if (!habilitarIncremento && rbAnadirIncremento.isSelected()) {
                rbAnadirIncremento.setSelected(false);
                rbAnadirPvp.setSelected(true);
            }
        }
        
        crearIconosBotones();
        crearAcciones();

    }
    
    public NuevoArticuloOpcion(Empresa e, Dac dac, Articulo ar, Caracteristica car, RellenarDac rdac, Despiece despiece) {
        //Entro en modficar articulo despiece desde rellenar dac
        super("Componente no visual - Propiedades");
        this.e = e;
        this.tipoArticulo = despiece.getTipoArticulo();
        this.dac = dac;
        this.rdac = rdac;
        this.despiece = despiece;
        this.ar = ar;
        this.car = car;
        this.crear = false;
        initComponents();
        
        if(this.tipoArticulo != null && !this.tipoArticulo.equals("")){
            String modificador = "";
            if(this.tipoArticulo.equals("Lona")){
                modificador = "Lona";
            } else if(this.tipoArticulo.equals("Faldon")){
                modificador = "Faldón";
            } else if(this.tipoArticulo.equals("TipoFaldon")){
                modificador = "Tipo faldón";
            } else if(this.tipoArticulo.equals("Ribete")){
                modificador = "Ribete";
            } else if(this.tipoArticulo.equals("Brazos")){
                modificador = "Brazos";
            } else if(this.tipoArticulo.equals("Motor")){
                modificador = "Motor";
            } else if(this.tipoArticulo.equals("TuboCarga")){
                modificador = "Tubo carga";
            } else if(this.tipoArticulo.equals("TuboEnrolle")){
                modificador = "Tubo enrolle";
            } else if(this.tipoArticulo.equals("Manivelas")){
                modificador = "Manivelas";
            } else if(this.tipoArticulo.equals("Maquina")){
                modificador = "Máquina";
            } else if(this.tipoArticulo.equals("Soporte")){
                modificador = "Soporte";
            } else if(this.tipoArticulo.equals("Casquillo")){
                modificador = "Casquillo";
            } else if(this.tipoArticulo.equals("Terminal")){
                modificador = "Terminal";
            }  else if(this.tipoArticulo.equals("Tapa")){
                modificador = "Tapa";
            } else if(this.tipoArticulo.equals("Perfil")){
                modificador = "Perfil";
            } else if(this.tipoArticulo.equals("Bambolina")){
                modificador = "Bambolina";
            } else if(this.tipoArticulo.equals("AtacuerdaPared")){
                modificador = "Atacuerda pared";
            } else if(this.tipoArticulo.equals("Gancho")){
                modificador = "Gancho";
            } else if(this.tipoArticulo.equals("Atacuerda")){
                modificador = "Atacuerda";
            } else if(this.tipoArticulo.equals("CarruchaSimple")){
                modificador = "Carrucha simple";
            } else if(this.tipoArticulo.equals("CarruchaDoble")){
                modificador = "Carrucha doble";
            }
            
            this.desdeDespiece = true;
            this.modificadorAntiguo = modificador;
            this.cModificador.setSelectedItem(modificador);
        } else {
            this.desdeDespiece = false;
        }
        
        iniciarColores();
        
        if(this.despiece.getColor() != null){
          Colores c = BaseDatos.obtenerColorPorIid(this.despiece.getColor().getIid());
          this.cColores.setSelectedItem(c.getDescripcion());
        } else {
            //Se selecciona el valor -- Vacio --
            this.cColores.setSelectedIndex(0);
        }

        if(despiece.getRedondeo() != null && !despiece.getRedondeo().equals("")){
            this.cRedondeo.setSelectedItem(despiece.getRedondeo());
        } else {
            this.cRedondeo.setSelectedIndex(0);
        }
        
        //tCodigoArticulo.setEnabled(false);
        tDescripcionArticulo.setEnabled(false);
        
        panel1 = this.pDim1;
        panel2 = this.pDim2;
        panel3 = this.pDim3;
        panel4 = this.pDim4;
        panel5 = this.pDim5;
        
        if(ar != null){
            
            this.ar = BaseDatos.obtenerArticuloPorIid(ar.getIid());
            
            String codCar = "";
            if(this.car != null){
                this.car = BaseDatos.obtenerCaracteristicaPorIid(this.car.getIid());
                Colores col = BaseDatos.obtenerColorPorIid(this.car.getIid_color().getIid());
                codCar = col.getCod_color();
            }
            tCodigoArticulo.setText(this.ar.getCod_articulo() + "/" + codCar);
            tDescripcionArticulo.setText(this.ar.getDes_inf());
        
            FamiliaVenta fv = this.ar.getIid_fam_venta();
            fv = BaseDatos.obtenerFamiliaVentaPorIid(fv.getIid());
            
            if(fv != null){
                TipoControl tc = fv.getIid_tipo_control();
                tc = BaseDatos.obtenerTipoControl(tc.getCodigo());
                
                if(tc != null){
                    TipoMedida tm = tc.getIid_tipo_medida();
                    tm = BaseDatos.obtenerTipoMedidaByIid(tm.getIid());
                    medidaCantidad.setText(despiece.getFormulaCantidad());
                    
                    numMedidas = tm.getNum_dimensiones();
                    
                    if(numMedidas > 0){
                        panelesDimension.setTitleAt(1, tm.getNombre_dim_1() + " (" + tm.getUnidad_dim_1().getCod_unidad_medida() + ")");
                        medida1.setText(despiece.getFormulaMedida1());
                    }
                    if(numMedidas > 1){
                        panelesDimension.setTitleAt(2, tm.getNombre_dim_2() + " (" + tm.getUnidad_dim_2().getCod_unidad_medida() + ")");
                        medida2.setText(despiece.getFormulaMedida2());
                    }
                    if(numMedidas > 2){
                        panelesDimension.setTitleAt(3, tm.getNombre_dim_3() + " (" + tm.getUnidad_dim_3().getCod_unidad_medida() + ")");
                        medida3.setText(despiece.getFormulaMedida3());
                    }
                    if(numMedidas > 3){
                        panelesDimension.setTitleAt(4, tm.getNombre_dim_4() + " (" + tm.getUnidad_dim_4().getCod_unidad_medida() + ")");
                        medida4.setText(despiece.getFormulaMedida4());
                    }
                    if(numMedidas > 4){
                        panelesDimension.setTitleAt(5, tm.getNombre_dim_5() + " (" + tm.getUnidad_dim_5().getCod_unidad_medida() + ")");
                        medida5.setText(despiece.getFormulaMedida5());
                    }
                    
                    for(int contador = 5; contador > numMedidas; contador--){
                        panelesDimension.remove(contador);
                    }
                }
            }
        } else {
            this.panelesDimension.setVisible(false);
        }
        
        boolean articuloBase = false;
        boolean anadirPvp = false;
        boolean anadirIncremento = false;
        
        if(despiece.getArticuloBase() == null){
            articuloBase = false;
        } else {
            articuloBase = despiece.getArticuloBase();
        }
        
        if(despiece.getAnadirPvp() == null){
            anadirPvp = false;
        } else {
            anadirPvp = despiece.getAnadirPvp();
        }
        
        if(despiece.getAnadirIncremento() == null){
            anadirIncremento = false;
        } else {
            anadirIncremento = despiece.getAnadirIncremento();
        }
        
        if(!articuloBase && !anadirPvp && !anadirIncremento){
            articuloBase = true;
        }
        
        rbArticuloBase.setSelected(articuloBase);
        rbAnadirPvp.setSelected(anadirPvp);
        rbAnadirIncremento.setSelected(anadirIncremento);
        
        if(this.ar != null){
            boolean habilitarIncremento = true;

            if (ar.getEscalado() || ar.getEscaladoCaracteristica()) {
                habilitarIncremento = false;
            }

            this.rbAnadirIncremento.setEnabled(habilitarIncremento);

            if (!habilitarIncremento && rbAnadirIncremento.isSelected()) {
                rbAnadirIncremento.setSelected(false);
                rbAnadirPvp.setSelected(true);
            }
        }
        
        crearIconosBotones();
        crearAcciones();
    }
    
    public NuevoArticuloOpcion(Empresa e, Dac dac, NuevoDAC ndac, Despiece despiece) {
        //Entro aski en crear articulo despiece desde crear dac
        super("Componente no visual - Propiedades");
        this.e = e;
        this.dac = dac;
        this.ndac = ndac;
        this.despiece = despiece;
        this.posicion = despiece.getOrden();
        this.desdeDespiece = false;
        this.crear = true;
        initComponents();

        iniciarColores();
        
        this.cColores.setSelectedIndex(0);
        this.cModificador.setSelectedIndex(0);
        //this.tCodigoArticulo.setEnabled(false);
        this.tDescripcionArticulo.setEnabled(false);
        if(despiece.getRedondeo() != null && !despiece.getRedondeo().equals("")){
            this.cRedondeo.setSelectedItem(despiece.getRedondeo());
        } else {
            this.cRedondeo.setSelectedIndex(0);
        }
        panel1 = this.pDim1;
        panel2 = this.pDim2;
        panel3 = this.pDim3;
        panel4 = this.pDim4;
        panel5 = this.pDim5;
         
        this.panelesDimension.setVisible(false);
        
        this.rbArticuloBase.setSelected(true);
        this.rbAnadirPvp.setSelected(false);
        this.rbAnadirIncremento.setSelected(false);
        
        if(this.ar != null){
            boolean habilitarIncremento = true;

            if (ar.getEscalado() || ar.getEscaladoCaracteristica()) {
                habilitarIncremento = false;
            }

            this.rbAnadirIncremento.setEnabled(habilitarIncremento);

            if (!habilitarIncremento && rbAnadirIncremento.isSelected()) {
                rbAnadirIncremento.setSelected(false);
                rbAnadirPvp.setSelected(true);
            }
        }
        
        if(ndac.getStringColorAccesorios().equals(Constantes.VACIO) && !ndac.getStringColorLacado().equals(Constantes.VACIO)){
            cColores.setSelectedItem(ndac.getStringColorLacado());
        }
        if(!ndac.getStringColorAccesorios().equals(Constantes.VACIO) && ndac.getStringColorLacado().equals(Constantes.VACIO)){
            cColores.setSelectedItem(ndac.getStringColorAccesorios());
        } else {
            cColores.setSelectedItem(ndac.getStringColorLacado());
        }
        
        crearIconosBotones();
        crearAcciones();
    }
    
    public NuevoArticuloOpcion(Empresa e, Dac dac, RellenarDac rdac, Despiece despiece) {
        //Entro aski en crear articulo despiece desde rellenar DAC
        super("Componente no visual - Propiedades");
        this.e = e;
        this.dac = dac;
        this.rdac = rdac;
        this.despiece = despiece;
        this.posicion = despiece.getOrden();
        this.desdeDespiece = false;
        this.crear = true;
        initComponents();

        iniciarColores();
        
        this.cColores.setSelectedIndex(0);
        this.cModificador.setSelectedIndex(0);
        //this.tCodigoArticulo.setEnabled(false);
        this.tDescripcionArticulo.setEnabled(false);
        if(despiece.getRedondeo() != null && !despiece.getRedondeo().equals("")){
            this.cRedondeo.setSelectedItem(despiece.getRedondeo());
        } else {
            this.cRedondeo.setSelectedIndex(0);
        }
        panel1 = this.pDim1;
        panel2 = this.pDim2;
        panel3 = this.pDim3;
        panel4 = this.pDim4;
        panel5 = this.pDim5;
         
        this.panelesDimension.setVisible(false);
        
        this.rbArticuloBase.setSelected(false);
        this.rbAnadirPvp.setSelected(true);
        this.rbAnadirIncremento.setSelected(false);
        
        if(this.ar != null){
            boolean habilitarIncremento = true;

            if (ar.getEscalado() || ar.getEscaladoCaracteristica()) {
                habilitarIncremento = false;
            }

            this.rbAnadirIncremento.setEnabled(habilitarIncremento);

            if (!habilitarIncremento && rbAnadirIncremento.isSelected()) {
                rbAnadirIncremento.setSelected(false);
                rbAnadirPvp.setSelected(true);
            }
        }
        
        if(rdac.getStringColorAccesorios().equals(Constantes.VACIO) && !rdac.getStringColorLacado().equals(Constantes.VACIO)){
            cColores.setSelectedItem(rdac.getStringColorLacado());
        }
        if(!rdac.getStringColorAccesorios().equals(Constantes.VACIO) && rdac.getStringColorLacado().equals(Constantes.VACIO)){
            cColores.setSelectedItem(rdac.getStringColorAccesorios());
        } else {
            cColores.setSelectedItem(rdac.getStringColorLacado());
        }
        
        crearIconosBotones();
        crearAcciones();
    }
    
    private void crearIconosBotones() {
        
        URL urlCancelar = getClass().getResource("/iconos/cancelar.gif");
        ImageIcon iconoCancelar = new ImageIcon(urlCancelar);
        bCancelar.setIcon(iconoCancelar);
        
        URL urlAceptar = getClass().getResource("/iconos/aceptar.png");
        ImageIcon iconoAceptar = new ImageIcon(urlAceptar);
        bAceptar.setIcon(iconoAceptar);
        
        URL urlAyuda = getClass().getResource("/iconos/ayudaVerde.png");
        ImageIcon iconoAyuda = new ImageIcon(urlAyuda);
        bAyuda.setIcon(iconoAyuda);
        
        URL urlMasAzul = getClass().getResource("/iconos/masAzul.png");
        ImageIcon iconoMasAzul = new ImageIcon(urlMasAzul);
        bSelecionarArticulo.setIcon(iconoMasAzul);
        
        URL urlCalculadora = getClass().getResource("/iconos/calculadora.png");
        ImageIcon iconoCalculadora = new ImageIcon(urlCalculadora);
        bEvaluarDim1.setIcon(iconoCalculadora);
        bEvaluarDim2.setIcon(iconoCalculadora);
        bEvaluarDim3.setIcon(iconoCalculadora);
        bEvaluarDim4.setIcon(iconoCalculadora);
        bEvaluarDim5.setIcon(iconoCalculadora);
        bEvaluarCantidad.setIcon(iconoCalculadora);
        
        URL urlVariable = getClass().getResource("/iconos/variable.gif");
        ImageIcon iconoVariable = new ImageIcon(urlVariable);
        bSeleccionarVariableDim1.setIcon(iconoVariable);
        bSeleccionarVariableDim2.setIcon(iconoVariable);
        bSeleccionarVariableDim3.setIcon(iconoVariable);
        bSeleccionarVariableDim4.setIcon(iconoVariable);
        bSeleccionarVariableDim5.setIcon(iconoVariable);
        bSeleccionarVariableCantidad.setIcon(iconoVariable);
        
    }
    
    private void crearAcciones(){
        KeyStroke escapeKeyStroke = KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false);
        Action escapeAction = new AbstractAction() {
            public void actionPerformed(ActionEvent e) {
                cerrarNao();
            }
        }; 
        getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(escapeKeyStroke, "ESCAPE");
        getRootPane().getActionMap().put("ESCAPE", escapeAction);
    }
    
    private void cerrarNao(){
        removeAll();
        dispose();
    }

    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTabbedPane1 = new javax.swing.JTabbedPane();
        pArticulo = new javax.swing.JPanel();
        pDatosArticulo = new javax.swing.JPanel();
        lCodigoArticulo = new javax.swing.JLabel();
        tCodigoArticulo = new javax.swing.JTextField();
        tDescripcionArticulo = new javax.swing.JTextField();
        bSelecionarArticulo = new javax.swing.JButton();
        panelesDimension = new javax.swing.JTabbedPane();
        pCantidad = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        medidaCantidad = new javax.swing.JTextArea();
        bEvaluarCantidad = new javax.swing.JButton();
        bSeleccionarVariableCantidad = new javax.swing.JButton();
        pDim1 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        medida1 = new javax.swing.JTextArea();
        bEvaluarDim1 = new javax.swing.JButton();
        bSeleccionarVariableDim1 = new javax.swing.JButton();
        pDim2 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        medida2 = new javax.swing.JTextArea();
        bEvaluarDim2 = new javax.swing.JButton();
        bSeleccionarVariableDim2 = new javax.swing.JButton();
        pDim3 = new javax.swing.JPanel();
        jScrollPane4 = new javax.swing.JScrollPane();
        medida3 = new javax.swing.JTextArea();
        bEvaluarDim3 = new javax.swing.JButton();
        bSeleccionarVariableDim3 = new javax.swing.JButton();
        pDim4 = new javax.swing.JPanel();
        jScrollPane5 = new javax.swing.JScrollPane();
        medida4 = new javax.swing.JTextArea();
        bEvaluarDim4 = new javax.swing.JButton();
        bSeleccionarVariableDim4 = new javax.swing.JButton();
        pDim5 = new javax.swing.JPanel();
        jScrollPane6 = new javax.swing.JScrollPane();
        medida5 = new javax.swing.JTextArea();
        bEvaluarDim5 = new javax.swing.JButton();
        bSeleccionarVariableDim5 = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        lRedondeo = new javax.swing.JLabel();
        cRedondeo = new javax.swing.JComboBox();
        jPanel1 = new javax.swing.JPanel();
        pDespiece = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        cModificador = new javax.swing.JComboBox();
        jPanel3 = new javax.swing.JPanel();
        cColores = new javax.swing.JComboBox();
        rbArticuloBase = new javax.swing.JRadioButton();
        rbAnadirPvp = new javax.swing.JRadioButton();
        rbAnadirIncremento = new javax.swing.JRadioButton();
        bCancelar = new javax.swing.JButton();
        bAceptar = new javax.swing.JButton();
        bAyuda = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        pDatosArticulo.setBorder(javax.swing.BorderFactory.createTitledBorder("Artículo"));

        lCodigoArticulo.setText("Código");

        tCodigoArticulo.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tCodigoArticuloKeyReleased(evt);
            }
        });

        bSelecionarArticulo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bSelecionarArticuloActionPerformed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout pDatosArticuloLayout = new org.jdesktop.layout.GroupLayout(pDatosArticulo);
        pDatosArticulo.setLayout(pDatosArticuloLayout);
        pDatosArticuloLayout.setHorizontalGroup(
            pDatosArticuloLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(pDatosArticuloLayout.createSequentialGroup()
                .addContainerGap()
                .add(pDatosArticuloLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(tDescripcionArticulo, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 375, Short.MAX_VALUE)
                    .add(pDatosArticuloLayout.createSequentialGroup()
                        .add(lCodigoArticulo)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(tCodigoArticulo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 191, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(bSelecionarArticulo)))
                .addContainerGap())
        );
        pDatosArticuloLayout.setVerticalGroup(
            pDatosArticuloLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(pDatosArticuloLayout.createSequentialGroup()
                .addContainerGap()
                .add(pDatosArticuloLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                    .add(pDatosArticuloLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                        .add(lCodigoArticulo)
                        .add(tCodigoArticulo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                    .add(bSelecionarArticulo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 22, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(tDescripcionArticulo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        medidaCantidad.setColumns(20);
        medidaCantidad.setRows(5);
        jScrollPane1.setViewportView(medidaCantidad);

        bEvaluarCantidad.setText("Evaluar");
        bEvaluarCantidad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bEvaluarCantidadActionPerformed(evt);
            }
        });

        bSeleccionarVariableCantidad.setText("Variable");
        bSeleccionarVariableCantidad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bSeleccionarVariableCantidadActionPerformed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout pCantidadLayout = new org.jdesktop.layout.GroupLayout(pCantidad);
        pCantidad.setLayout(pCantidadLayout);
        pCantidadLayout.setHorizontalGroup(
            pCantidadLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jScrollPane1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 402, Short.MAX_VALUE)
            .add(pCantidadLayout.createSequentialGroup()
                .addContainerGap()
                .add(bSeleccionarVariableCantidad)
                .add(18, 18, 18)
                .add(bEvaluarCantidad)
                .addContainerGap(234, Short.MAX_VALUE))
        );
        pCantidadLayout.setVerticalGroup(
            pCantidadLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(pCantidadLayout.createSequentialGroup()
                .add(jScrollPane1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 136, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .add(18, 18, 18)
                .add(pCantidadLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(bSeleccionarVariableCantidad)
                    .add(bEvaluarCantidad))
                .addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        panelesDimension.addTab("Cantidad", pCantidad);

        medida1.setColumns(20);
        medida1.setRows(5);
        jScrollPane2.setViewportView(medida1);

        bEvaluarDim1.setText("Evaluar");
        bEvaluarDim1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bEvaluarDim1ActionPerformed(evt);
            }
        });

        bSeleccionarVariableDim1.setText("Variable");
        bSeleccionarVariableDim1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bSeleccionarVariableDim1ActionPerformed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout pDim1Layout = new org.jdesktop.layout.GroupLayout(pDim1);
        pDim1.setLayout(pDim1Layout);
        pDim1Layout.setHorizontalGroup(
            pDim1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(pDim1Layout.createSequentialGroup()
                .addContainerGap()
                .add(bSeleccionarVariableDim1)
                .add(18, 18, 18)
                .add(bEvaluarDim1)
                .addContainerGap(234, Short.MAX_VALUE))
            .add(jScrollPane2, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 402, Short.MAX_VALUE)
        );
        pDim1Layout.setVerticalGroup(
            pDim1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, pDim1Layout.createSequentialGroup()
                .add(jScrollPane2, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 136, Short.MAX_VALUE)
                .add(18, 18, 18)
                .add(pDim1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(bSeleccionarVariableDim1)
                    .add(bEvaluarDim1))
                .addContainerGap())
        );

        panelesDimension.addTab("Dim1", pDim1);

        medida2.setColumns(20);
        medida2.setRows(5);
        jScrollPane3.setViewportView(medida2);

        bEvaluarDim2.setText("Evaluar");
        bEvaluarDim2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bEvaluarDim2ActionPerformed(evt);
            }
        });

        bSeleccionarVariableDim2.setText("Variable");
        bSeleccionarVariableDim2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bSeleccionarVariableDim2ActionPerformed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout pDim2Layout = new org.jdesktop.layout.GroupLayout(pDim2);
        pDim2.setLayout(pDim2Layout);
        pDim2Layout.setHorizontalGroup(
            pDim2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(pDim2Layout.createSequentialGroup()
                .addContainerGap()
                .add(bSeleccionarVariableDim2)
                .add(18, 18, 18)
                .add(bEvaluarDim2)
                .addContainerGap(234, Short.MAX_VALUE))
            .add(jScrollPane3, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 402, Short.MAX_VALUE)
        );
        pDim2Layout.setVerticalGroup(
            pDim2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, pDim2Layout.createSequentialGroup()
                .add(jScrollPane3, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 136, Short.MAX_VALUE)
                .add(18, 18, 18)
                .add(pDim2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(bSeleccionarVariableDim2)
                    .add(bEvaluarDim2))
                .addContainerGap())
        );

        panelesDimension.addTab("Dim2", pDim2);

        medida3.setColumns(20);
        medida3.setRows(5);
        jScrollPane4.setViewportView(medida3);

        bEvaluarDim3.setText("Evaluar");
        bEvaluarDim3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bEvaluarDim3ActionPerformed(evt);
            }
        });

        bSeleccionarVariableDim3.setText("Variable");
        bSeleccionarVariableDim3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bSeleccionarVariableDim3ActionPerformed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout pDim3Layout = new org.jdesktop.layout.GroupLayout(pDim3);
        pDim3.setLayout(pDim3Layout);
        pDim3Layout.setHorizontalGroup(
            pDim3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(pDim3Layout.createSequentialGroup()
                .addContainerGap()
                .add(bSeleccionarVariableDim3)
                .add(18, 18, 18)
                .add(bEvaluarDim3)
                .addContainerGap(234, Short.MAX_VALUE))
            .add(jScrollPane4, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 402, Short.MAX_VALUE)
        );
        pDim3Layout.setVerticalGroup(
            pDim3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, pDim3Layout.createSequentialGroup()
                .add(jScrollPane4, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 136, Short.MAX_VALUE)
                .add(18, 18, 18)
                .add(pDim3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(bSeleccionarVariableDim3)
                    .add(bEvaluarDim3))
                .addContainerGap())
        );

        panelesDimension.addTab("Dim3", pDim3);

        medida4.setColumns(20);
        medida4.setRows(5);
        jScrollPane5.setViewportView(medida4);

        bEvaluarDim4.setText("Evaluar");
        bEvaluarDim4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bEvaluarDim4ActionPerformed(evt);
            }
        });

        bSeleccionarVariableDim4.setText("Variable");
        bSeleccionarVariableDim4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bSeleccionarVariableDim4ActionPerformed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout pDim4Layout = new org.jdesktop.layout.GroupLayout(pDim4);
        pDim4.setLayout(pDim4Layout);
        pDim4Layout.setHorizontalGroup(
            pDim4Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(pDim4Layout.createSequentialGroup()
                .addContainerGap()
                .add(bSeleccionarVariableDim4)
                .add(18, 18, 18)
                .add(bEvaluarDim4)
                .addContainerGap(234, Short.MAX_VALUE))
            .add(jScrollPane5, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 402, Short.MAX_VALUE)
        );
        pDim4Layout.setVerticalGroup(
            pDim4Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, pDim4Layout.createSequentialGroup()
                .add(jScrollPane5, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 136, Short.MAX_VALUE)
                .add(18, 18, 18)
                .add(pDim4Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(bSeleccionarVariableDim4)
                    .add(bEvaluarDim4))
                .addContainerGap())
        );

        panelesDimension.addTab("Dim4", pDim4);

        medida5.setColumns(20);
        medida5.setRows(5);
        jScrollPane6.setViewportView(medida5);

        bEvaluarDim5.setText("Evaluar");
        bEvaluarDim5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bEvaluarDim5ActionPerformed(evt);
            }
        });

        bSeleccionarVariableDim5.setText("Variable");
        bSeleccionarVariableDim5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bSeleccionarVariableDim5ActionPerformed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout pDim5Layout = new org.jdesktop.layout.GroupLayout(pDim5);
        pDim5.setLayout(pDim5Layout);
        pDim5Layout.setHorizontalGroup(
            pDim5Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(pDim5Layout.createSequentialGroup()
                .addContainerGap()
                .add(bSeleccionarVariableDim5)
                .add(18, 18, 18)
                .add(bEvaluarDim5)
                .addContainerGap(234, Short.MAX_VALUE))
            .add(jScrollPane6, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 402, Short.MAX_VALUE)
        );
        pDim5Layout.setVerticalGroup(
            pDim5Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, pDim5Layout.createSequentialGroup()
                .add(jScrollPane6, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 136, Short.MAX_VALUE)
                .add(18, 18, 18)
                .add(pDim5Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(bSeleccionarVariableDim5)
                    .add(bEvaluarDim5))
                .addContainerGap())
        );

        panelesDimension.addTab("Dim5", pDim5);

        jPanel4.setBorder(javax.swing.BorderFactory.createTitledBorder("Redondeo"));

        lRedondeo.setText("Tipo de redondeo");

        cRedondeo.setModel(new javax.swing.DefaultComboBoxModel(new String[] {Constantes.DECIMALES2, Constantes.TRUNCAR, Constantes.EXCESO}));

        org.jdesktop.layout.GroupLayout jPanel4Layout = new org.jdesktop.layout.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .add(lRedondeo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 96, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(cRedondeo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 210, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(75, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel4Layout.createSequentialGroup()
                .addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .add(jPanel4Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(cRedondeo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(lRedondeo)))
        );

        org.jdesktop.layout.GroupLayout pArticuloLayout = new org.jdesktop.layout.GroupLayout(pArticulo);
        pArticulo.setLayout(pArticuloLayout);
        pArticuloLayout.setHorizontalGroup(
            pArticuloLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(panelesDimension)
            .add(jPanel4, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, pDatosArticulo, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        pArticuloLayout.setVerticalGroup(
            pArticuloLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(pArticuloLayout.createSequentialGroup()
                .add(pDatosArticulo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel4, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(panelesDimension, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 216, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
        );

        jTabbedPane1.addTab("Artículo", pArticulo);

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder("Modificador"));

        cModificador.setModel(new javax.swing.DefaultComboBoxModel(new String[] { Constantes.VACIO, "Lona", "Faldón", "Tipo faldón", "Ribete", "Brazos", "Motor", "Manivelas", "Tubo enrolle", "Perfil" , "Soporte", "Casquillo", "Máquina", "Tapa", "Bambolina", "Terminal", "Atacuerda pared", "Carrucha doble", "Carrucha simple", "Gancho", "Polea izquierda", "Polea derecha", "Atacuerda", "Perfil cofre"}));

        org.jdesktop.layout.GroupLayout jPanel2Layout = new org.jdesktop.layout.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .add(cModificador, 0, 282, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .add(cModificador, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder("Color"));

        cColores.setModel(new javax.swing.DefaultComboBoxModel(new String[] { }));
        cColores.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cColoresActionPerformed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout jPanel3Layout = new org.jdesktop.layout.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel3Layout.createSequentialGroup()
                .add(cColores, 0, 218, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .add(cColores, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(23, Short.MAX_VALUE))
        );

        rbArticuloBase.setText("Articulo Base");
        rbArticuloBase.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbArticuloBaseActionPerformed(evt);
            }
        });

        rbAnadirPvp.setText("Añadir PVP");
        rbAnadirPvp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbAnadirPvpActionPerformed(evt);
            }
        });

        rbAnadirIncremento.setText("Añadir Incremento");
        rbAnadirIncremento.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbAnadirIncrementoActionPerformed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout pDespieceLayout = new org.jdesktop.layout.GroupLayout(pDespiece);
        pDespiece.setLayout(pDespieceLayout);
        pDespieceLayout.setHorizontalGroup(
            pDespieceLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(pDespieceLayout.createSequentialGroup()
                .addContainerGap()
                .add(pDespieceLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(pDespieceLayout.createSequentialGroup()
                        .add(jPanel3, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .add(156, 156, 156))
                    .add(pDespieceLayout.createSequentialGroup()
                        .add(pDespieceLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(jPanel2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(pDespieceLayout.createSequentialGroup()
                                .add(rbArticuloBase)
                                .add(18, 18, 18)
                                .add(rbAnadirPvp)
                                .add(18, 18, 18)
                                .add(rbAnadirIncremento)))
                        .addContainerGap(81, Short.MAX_VALUE))))
        );
        pDespieceLayout.setVerticalGroup(
            pDespieceLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(pDespieceLayout.createSequentialGroup()
                .add(32, 32, 32)
                .add(jPanel2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .add(18, 18, 18)
                .add(pDespieceLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(rbArticuloBase)
                    .add(rbAnadirPvp)
                    .add(rbAnadirIncremento))
                .add(18, 18, 18)
                .add(jPanel3, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(156, Short.MAX_VALUE))
        );

        org.jdesktop.layout.GroupLayout jPanel1Layout = new org.jdesktop.layout.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(0, 407, Short.MAX_VALUE)
            .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                .add(jPanel1Layout.createSequentialGroup()
                    .add(0, 0, 0)
                    .add(pDespiece, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .add(1, 1, 1)))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(0, 397, Short.MAX_VALUE)
            .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                .add(jPanel1Layout.createSequentialGroup()
                    .add(0, 0, 0)
                    .add(pDespiece, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .add(0, 0, 0)))
        );

        jTabbedPane1.addTab("Despiece", jPanel1);

        bCancelar.setText("Cancelar");
        bCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bCancelarActionPerformed(evt);
            }
        });

        bAceptar.setText("Aceptar");
        bAceptar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bAceptarActionPerformed(evt);
            }
        });

        bAyuda.setText("Ayuda");
        bAyuda.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bAyudaActionPerformed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout layout = new org.jdesktop.layout.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(layout.createSequentialGroup()
                .addContainerGap()
                .add(bAyuda)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED, 177, Short.MAX_VALUE)
                .add(bAceptar)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(bCancelar)
                .addContainerGap())
            .add(jTabbedPane1)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, layout.createSequentialGroup()
                .add(jTabbedPane1)
                .add(18, 18, 18)
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(bCancelar)
                    .add(bAyuda)
                    .add(bAceptar))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    
private void bCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bCancelarActionPerformed
    cerrarNao();
}//GEN-LAST:event_bCancelarActionPerformed

private void iniciarColores(){
    List listaColores = BaseDatos.getListaColores();
    Iterator iter = listaColores.iterator();
    Colores c;
    cColores.addItem(Constantes.VACIO);
    while(iter.hasNext()){
        c = (Colores)iter.next();
        cColores.addItem(c.getDescripcion());
    }
}
private void actualizarPestanhas(Articulo art){
    
    FamiliaVenta fv = art.getIid_fam_venta();
    fv = BaseDatos.obtenerFamiliaVentaPorIid(fv.getIid());
            
    if(fv != null){
        
        if(fv.getNombre().equals(Constantes.NOMBRE_FAM_ESPECIFICACION)){
            panelesDimension.setTitleAt(0, "Especificación");
            for(int contador = 5; contador > 0; contador--){
                panelesDimension.remove(contador);
            }
        } else {

            TipoControl tc = fv.getIid_tipo_control();
            tc = BaseDatos.obtenerTipoControl(tc.getCodigo());

            if(tc != null){
                TipoMedida tm = tc.getIid_tipo_medida();
                tm = BaseDatos.obtenerTipoMedidaByIid(tm.getIid());
                medidaCantidad.setText(despiece.getFormulaCantidad());

                numMedidas = tm.getNum_dimensiones();

                medidaCantidad.setText("");
                medida1.setText("");
                medida2.setText("");
                medida3.setText("");
                medida4.setText("");
                medida5.setText("");

                despiece.setFormulaCantidad("");
                despiece.setFormulaMedida1("");
                despiece.setFormulaMedida2("");
                despiece.setFormulaMedida3("");
                despiece.setFormulaMedida4("");
                despiece.setFormulaMedida5("");

                //Se han de borrar los paneles
                int numPaneles = panelesDimension.getTabCount();
                for(int contador = numPaneles; contador > 1; contador--){
                    panelesDimension.remove(contador-1);
                }

                if(numMedidas > 0){
                    panelesDimension.addTab(tm.getNombre_dim_1() + " (" + tm.getUnidad_dim_1().getCod_unidad_medida() + ")", panel1);
                } 

                if(numMedidas > 1){
                    panelesDimension.addTab(tm.getNombre_dim_2() + " (" + tm.getUnidad_dim_2().getCod_unidad_medida() + ")", panel2);
                }

                if(numMedidas > 2){
                    panelesDimension.addTab(tm.getNombre_dim_3() + " (" + tm.getUnidad_dim_3().getCod_unidad_medida() + ")", panel3);
                } 

                if(numMedidas > 3){
                    panelesDimension.addTab(tm.getNombre_dim_4() + " (" + tm.getUnidad_dim_4().getCod_unidad_medida() + ")", panel4);
                }

                if(numMedidas > 4){
                    panelesDimension.addTab(tm.getNombre_dim_5() + " (" + tm.getUnidad_dim_5().getCod_unidad_medida() + ")", panel5);
                }
            }
        }
    }
}

public int getNumeroDimensiones() {
    if(this.ndac != null){
        return ndac.getNumeroDimensiones();
    } else {
        return rdac.getNumeroDimensiones();
    }
}

public List<Variable> getListaVbles() {
    if(this.ndac != null){
        return ndac.getListaVbles();
    } else {
        return rdac.getListaVbles();
    }
}

protected void rellenarArticulo(Articulo art, Caracteristica car){
    this.ar = art;
    this.car = car;
    
    String codCar = "";
    if(this.car != null){
        this.car = BaseDatos.obtenerCaracteristicaPorIid(this.car.getIid());
        Colores col = BaseDatos.obtenerColorPorIid(this.car.getIid_color().getIid());
        codCar = col.getCod_color();
        cColores.setSelectedItem(car.getIid_color().getDescripcion());
    }
    
    tCodigoArticulo.setText(this.ar.getCod_articulo() + "/" + codCar);
    
    this.tDescripcionArticulo.setText(ar.getDes_inf());
    actualizarPestanhas(ar);
    panelesDimension.setVisible(true);
    
    if(ndac != null){
        FamiliaVenta fv = ar.getIid_fam_venta();
 
        if(fv != null){
            fv = BaseDatos.obtenerFamiliaVentaPorIid(fv.getIid());
            if(fv.getNombre().equalsIgnoreCase(Constantes.NOMBRE_FAM_PRECIO)){
                this.rbAnadirIncremento.setSelected(false);
                this.rbAnadirPvp.setSelected(true);
                this.rbArticuloBase.setSelected(false);
            }
        }
        
        
    }
    
    boolean habilitarIncremento = true;

    if (ar.getEscalado() || ar.getEscaladoCaracteristica()) {
        habilitarIncremento = false;
    }

    this.rbAnadirIncremento.setEnabled(habilitarIncremento);

    if (!habilitarIncremento && rbAnadirIncremento.isSelected()) {
        rbAnadirIncremento.setSelected(false);
        rbAnadirPvp.setSelected(true);
    }
    
    this.tCodigoArticulo.setForeground(Color.BLACK);
    
}



private void bAceptarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bAceptarActionPerformed
    
    if(this.tCodigoArticulo.getForeground().equals(Color.RED)){
        JOptionPane.showMessageDialog(null, "No ha seleccionado un artículo correcto", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }
    
    Double resultadoEvaluar;
    boolean hayErrorEvaluar = false;
    
    if(medidaCantidad.getText() != null && !medidaCantidad.getText().equals("")){
        if(ndac != null){
            resultadoEvaluar = ndac.evaluar(Util.convertirComaAPunto(medidaCantidad.getText()), (String) cRedondeo.getSelectedItem(), false);
        }else {
            resultadoEvaluar = rdac.evaluar(Util.convertirComaAPunto(medidaCantidad.getText()), (String) cRedondeo.getSelectedItem(), false);
        }
        hayErrorEvaluar = resultadoEvaluar == null;
    }
    
    if (!hayErrorEvaluar && numMedidas > 0 && medida1.getText() != null && !medida1.getText().equals("")){
        if(ndac != null){
            resultadoEvaluar = ndac.evaluar(Util.convertirComaAPunto(medida1.getText()), (String) cRedondeo.getSelectedItem(), false);
        }else {
            resultadoEvaluar = rdac.evaluar(Util.convertirComaAPunto(medida1.getText()), (String) cRedondeo.getSelectedItem(), false);
        }
        hayErrorEvaluar = resultadoEvaluar == null; 
    }
    if (!hayErrorEvaluar && numMedidas > 1 && medida2.getText() != null && !medida2.getText().equals("")) {
        if(ndac != null){
            resultadoEvaluar = ndac.evaluar(Util.convertirComaAPunto(medida2.getText()), (String) cRedondeo.getSelectedItem(), false);
        }else {
            resultadoEvaluar = rdac.evaluar(Util.convertirComaAPunto(medida2.getText()), (String) cRedondeo.getSelectedItem(), false);
        }
        hayErrorEvaluar = resultadoEvaluar == null; 
    }
    if (!hayErrorEvaluar && numMedidas > 2 && medida2.getText() != null && !medida3.getText().equals("")) {
        if(ndac != null){
            resultadoEvaluar = ndac.evaluar(Util.convertirComaAPunto(medida3.getText()), (String) cRedondeo.getSelectedItem(), false);
        }else {
            resultadoEvaluar = rdac.evaluar(Util.convertirComaAPunto(medida3.getText()), (String) cRedondeo.getSelectedItem(), false);
        }
        hayErrorEvaluar = resultadoEvaluar == null;  
    }
    if (!hayErrorEvaluar && numMedidas > 3 && medida3.getText() != null && !medida4.getText().equals("")) {
        if(ndac != null){
            resultadoEvaluar = ndac.evaluar(Util.convertirComaAPunto(medida4.getText()), (String) cRedondeo.getSelectedItem(), false);
        }else {
            resultadoEvaluar = rdac.evaluar(Util.convertirComaAPunto(medida4.getText()), (String) cRedondeo.getSelectedItem(), false);
        }
        hayErrorEvaluar = resultadoEvaluar == null;  
    }
    if (!hayErrorEvaluar && numMedidas > 4 && medida4.getText() != null && !medida5.getText().equals("")) {
        if(ndac != null){
            resultadoEvaluar = ndac.evaluar(Util.convertirComaAPunto(medida5.getText()), (String) cRedondeo.getSelectedItem(), false);
        }else {
            resultadoEvaluar = rdac.evaluar(Util.convertirComaAPunto(medida5.getText()), (String) cRedondeo.getSelectedItem(), false);
        }
        hayErrorEvaluar = resultadoEvaluar == null;  
    }
    
    if(hayErrorEvaluar){
        JOptionPane.showMessageDialog(null, "Error al evaluar una fórmula", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }
    
    boolean mostrarMensajeCorteLona = false;
    
    if(this.ar != null){
        boolean modificacionDespiece = true;
        
        if(despiece == null){
            despiece = new Despiece();
            modificacionDespiece = false;
        }

        String modificadorNuevo = (String)cModificador.getSelectedItem();
        if(modificadorNuevo.equals("Faldón")){
            modificadorNuevo = "Faldon";
        } else if(modificadorNuevo.equals("Tipo faldón")){
            modificadorNuevo = "TipoFaldon";
        } else if(modificadorNuevo.equals("Tubo enrolle")){
            modificadorNuevo = "TuboEnrolle";
        } else if(modificadorNuevo.equals("Tubo carga")){
            modificadorNuevo = "TuboCarga";
        } else if(modificadorNuevo.equals("Máquina")){
            modificadorNuevo = "Maquina";
        } else if(modificadorNuevo.equals("Atacuerda pared")){
            modificadorNuevo = "AtacuerdaPared";
        } else if(modificadorNuevo.equals("Carrucha doble")){
            modificadorNuevo = "CarruchaDoble";
        } else if(modificadorNuevo.equals("Carrucha simple")){
            modificadorNuevo = "CarruchaSimple";
        } else if(modificadorNuevo.equals("Polea izquierda")){
            modificadorNuevo = "PoleaIzquierda";
        } else if(modificadorNuevo.equals("Polea derecha")){
            modificadorNuevo = "PoleaDerecha";
        } else if(modificadorNuevo.equals("Perfil cofre")){
            modificadorNuevo = "PerfilCofre";
	}
        
        if(modificadorNuevo.equals(Constantes.VACIO)){
            despiece.setTipoArticulo("");
        } else {
            despiece.setTipoArticulo(modificadorNuevo);
        }

        if(numMedidas > 0){
            if(medida1.getText() == null && despiece.getFormulaMedida1() != null ||
                medida1.getText() != null && despiece.getFormulaMedida1() != null && !medida1.getText().equalsIgnoreCase(despiece.getFormulaMedida1())){
                mostrarMensajeCorteLona = true;
            }
            despiece.setFormulaMedida1(medida1.getText());
        }
        if(numMedidas > 1){
            if(medida2.getText() == null && despiece.getFormulaMedida2() != null ||
                medida2.getText() != null && despiece.getFormulaMedida2() != null && !medida2.getText().equalsIgnoreCase(despiece.getFormulaMedida2())){
                mostrarMensajeCorteLona = true;
            }
            despiece.setFormulaMedida2(medida2.getText());
        }
        if(numMedidas > 2){
            despiece.setFormulaMedida3(medida3.getText());
        }
        if(numMedidas > 3){
            despiece.setFormulaMedida4(medida4.getText());
        }
        if(numMedidas > 4){
            despiece.setFormulaMedida5(medida5.getText());
        }
        
        if(medidaCantidad.getText() == null && despiece.getFormulaCantidad() != null ||
            medidaCantidad.getText() != null && despiece.getFormulaCantidad() != null && !medidaCantidad.getText().equalsIgnoreCase(despiece.getFormulaCantidad())){
            mostrarMensajeCorteLona = true;
        }
        
        String colorSeleccionado = (String) cColores.getSelectedItem();
        Colores c = BaseDatos.obtenerColorPorDescripcion(colorSeleccionado);
        despiece.setColor(c);
        despiece.setArticulo(this.ar);
        despiece.setCaracteristica(this.car);
        despiece.setFormulaCantidad(medidaCantidad.getText());
        despiece.setRedondeo((String)cRedondeo.getSelectedItem());
        despiece.setAnadirIncremento(this.rbAnadirIncremento.isSelected());
        despiece.setAnadirPvp(this.rbAnadirPvp.isSelected());
        despiece.setArticuloBase(this.rbArticuloBase.isSelected());
        
        //Almacenar precio de coste y venta
//        despiece.setPrecio(Float.parseFloat(rdac.calcularPrecioDespiece(despiece).toString()));
//        despiece.setCoste(Float.parseFloat(rdac.calcularCosteDespiece(despiece).toString()));
        
        if(ndac != null){
            ndac.resetarTipoDespiece(tipoArticulo);
            if(desdeDespiece){
                ndac.modificarDespiece(despiece, modificacionDespiece, tipoArticulo);
            } else {
                ndac.modificarDespiece(despiece, this.crear);
            }
        } else {
            rdac.resetarTipoDespiece(tipoArticulo);
            if(desdeDespiece){
                rdac.modificarDespiece(despiece, modificacionDespiece, tipoArticulo);
            } else {
                rdac.modificarDespiece(despiece,this.crear);
            }
            
            if(mostrarMensajeCorteLona){
                
                //Si la linea ya está almacenada en la BBDD y esta linea tiene cortes de lona entonces se han de borrar
                List<LineaCorteLona> llcl = BaseDatos.getListaLineaCorteLonaByLineaPresupuesto(rdac.getLPresupuesto().getIid());
                List<LineaCortePerfil> llcp = BaseDatos.getListaLineaCortePerfilByLineaPresupuesto(rdac.getLPresupuesto().getIid());

                if (llcl != null && llcl.size() > 0 && llcp != null && llcp.size() > 0) {
                    //Las lonas y perfiles cortados serán deshechos
                    JOptionPane.showMessageDialog(null, "Los cortes de lona y perfil de esta linea serán eliminados", "Información", JOptionPane.INFORMATION_MESSAGE);
                    BaseDatos.eliminarCorteLonaByLineaPresupuesto(rdac.getLPresupuesto().getIid());
                    BaseDatos.eliminarCortePerfilByLineaPresupuesto(rdac.getLPresupuesto().getIid());
                } else if(llcl != null && llcl.size() > 0){
                    //Las lonas cortadas serán deshechas
                    JOptionPane.showMessageDialog(null, "Los cortes de lona de esta linea serán eliminados", "Información", JOptionPane.INFORMATION_MESSAGE);
                    BaseDatos.eliminarCorteLonaByLineaPresupuesto(rdac.getLPresupuesto().getIid());
                } else if(llcp != null && llcp.size() > 0){
                    //Los perfiles cortados serán deshechos
                    JOptionPane.showMessageDialog(null, "Los cortes de perfil de esta linea serán eliminados", "Información", JOptionPane.INFORMATION_MESSAGE);
                    BaseDatos.eliminarCortePerfilByLineaPresupuesto(rdac.getLPresupuesto().getIid());
                }
            }
        }
        
        cerrarNao();
    } else {
        JOptionPane.showMessageDialog(null, "Debe seleccionar un articulo", "Error", JOptionPane.INFORMATION_MESSAGE);
    }
    
}//GEN-LAST:event_bAceptarActionPerformed

private void bAyudaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bAyudaActionPerformed
    JOptionPane.showMessageDialog(null, "Ayuda", "Ayuda", JOptionPane.INFORMATION_MESSAGE);
}//GEN-LAST:event_bAyudaActionPerformed

private void bSelecionarArticuloActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bSelecionarArticuloActionPerformed
    SeleccionArticulosDac frame = new SeleccionArticulosDac(e, this, "SeleccionarArticuloDesdeDespiece");
    frame.setDefaultCloseOperation(SeleccionArticulosDac.DISPOSE_ON_CLOSE);
    frame.setLocationRelativeTo(null);
    frame.setVisible(true);
}//GEN-LAST:event_bSelecionarArticuloActionPerformed

private void bEvaluarCantidadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bEvaluarCantidadActionPerformed
    if(ndac != null){
        Double resultado = ndac.evaluar(Util.convertirComaAPunto(medidaCantidad.getText()), (String) cRedondeo.getSelectedItem(), true);
        if(resultado != null){
            JOptionPane.showMessageDialog(null, Util.convertirPuntoAComa(resultado.toString()), "Resultado", JOptionPane.INFORMATION_MESSAGE);
        }
    } else {
        Double resultado = rdac.evaluar(Util.convertirComaAPunto(medidaCantidad.getText()), (String) cRedondeo.getSelectedItem(), true);
        if(resultado != null){
            JOptionPane.showMessageDialog(null, Util.convertirPuntoAComa(resultado.toString()), "Resultado", JOptionPane.INFORMATION_MESSAGE);
        }
    }
}//GEN-LAST:event_bEvaluarCantidadActionPerformed

private void bEvaluarDim1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bEvaluarDim1ActionPerformed
    if(ndac != null){
        Double resultado = ndac.evaluar(Util.convertirComaAPunto(medida1.getText()), (String) cRedondeo.getSelectedItem(), true);
        if(resultado != null){
            JOptionPane.showMessageDialog(null, Util.convertirPuntoAComa(resultado.toString()), "Resultado", JOptionPane.INFORMATION_MESSAGE);
        }
    }else {
        Double resultado = rdac.evaluar(Util.convertirComaAPunto(medida1.getText()), (String) cRedondeo.getSelectedItem(), true);
        if(resultado != null){
            JOptionPane.showMessageDialog(null, Util.convertirPuntoAComa(resultado.toString()), "Resultado", JOptionPane.INFORMATION_MESSAGE);
        } 
    }
}//GEN-LAST:event_bEvaluarDim1ActionPerformed

private void bEvaluarDim2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bEvaluarDim2ActionPerformed
    if(ndac != null){
        Double resultado = ndac.evaluar(Util.convertirComaAPunto(medida2.getText()), (String) cRedondeo.getSelectedItem(), true);
        if(resultado != null){
            JOptionPane.showMessageDialog(null, Util.convertirPuntoAComa(resultado.toString()), "Resultado", JOptionPane.INFORMATION_MESSAGE);
        }
    }else {
        Double resultado = rdac.evaluar(Util.convertirComaAPunto(medida2.getText()), (String) cRedondeo.getSelectedItem(), true);
        if(resultado != null){
            JOptionPane.showMessageDialog(null, Util.convertirPuntoAComa(resultado.toString()), "Resultado", JOptionPane.INFORMATION_MESSAGE);
        } 
    }
}//GEN-LAST:event_bEvaluarDim2ActionPerformed

private void bEvaluarDim3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bEvaluarDim3ActionPerformed
    if(ndac != null){
        Double resultado = ndac.evaluar(Util.convertirComaAPunto(medida3.getText()), (String) cRedondeo.getSelectedItem(), true);
        if(resultado != null){
            JOptionPane.showMessageDialog(null, Util.convertirPuntoAComa(resultado.toString()), "Resultado", JOptionPane.INFORMATION_MESSAGE);
        }
    }else {
        Double resultado = rdac.evaluar(Util.convertirComaAPunto(medida3.getText()), (String) cRedondeo.getSelectedItem(), true);
        if(resultado != null){
            JOptionPane.showMessageDialog(null, Util.convertirPuntoAComa(resultado.toString()), "Resultado", JOptionPane.INFORMATION_MESSAGE);
        } 
    }
}//GEN-LAST:event_bEvaluarDim3ActionPerformed

private void bEvaluarDim4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bEvaluarDim4ActionPerformed
    if(ndac != null){
        Double resultado = ndac.evaluar(Util.convertirComaAPunto(medida4.getText()), (String) cRedondeo.getSelectedItem(), true);
        if(resultado != null){
            JOptionPane.showMessageDialog(null, Util.convertirPuntoAComa(resultado.toString()), "Resultado", JOptionPane.INFORMATION_MESSAGE);
        }
    }else {
        Double resultado = rdac.evaluar(Util.convertirComaAPunto(medida4.getText()), (String) cRedondeo.getSelectedItem(), true);
        if(resultado != null){
            JOptionPane.showMessageDialog(null, Util.convertirPuntoAComa(resultado.toString()), "Resultado", JOptionPane.INFORMATION_MESSAGE);
        } 
    }
}//GEN-LAST:event_bEvaluarDim4ActionPerformed

private void bEvaluarDim5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bEvaluarDim5ActionPerformed
    if(ndac != null){
        Double resultado = ndac.evaluar(Util.convertirComaAPunto(medida5.getText()), (String) cRedondeo.getSelectedItem(), true);
        if(resultado != null){
            JOptionPane.showMessageDialog(null, Util.convertirPuntoAComa(resultado.toString()), "Resultado", JOptionPane.INFORMATION_MESSAGE);
        }
    }else {
        Double resultado = rdac.evaluar(Util.convertirComaAPunto(medida5.getText()), (String) cRedondeo.getSelectedItem(), true);
        if(resultado != null){
            JOptionPane.showMessageDialog(null, Util.convertirPuntoAComa(resultado.toString()), "Resultado", JOptionPane.INFORMATION_MESSAGE);
        } 
    }
}//GEN-LAST:event_bEvaluarDim5ActionPerformed

private void bSeleccionarVariableCantidadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bSeleccionarVariableCantidadActionPerformed
    SeleccionarVariable sv = new SeleccionarVariable(this, "Variable - Seleccionar", medidaCantidad);
    sv.setDefaultCloseOperation(SeleccionarVariable.DISPOSE_ON_CLOSE);
    sv.setLocationRelativeTo(null);
    sv.setVisible(true);
}//GEN-LAST:event_bSeleccionarVariableCantidadActionPerformed

private void bSeleccionarVariableDim1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bSeleccionarVariableDim1ActionPerformed
    SeleccionarVariable sv = new SeleccionarVariable(this, "Variable - Seleccionar", this.medida1);
    sv.setDefaultCloseOperation(SeleccionarVariable.DISPOSE_ON_CLOSE);
    sv.setLocationRelativeTo(null);
    sv.setVisible(true);
}//GEN-LAST:event_bSeleccionarVariableDim1ActionPerformed

private void bSeleccionarVariableDim2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bSeleccionarVariableDim2ActionPerformed
    SeleccionarVariable sv = new SeleccionarVariable(this, "Variable - Seleccionar", this.medida2);
    sv.setDefaultCloseOperation(SeleccionarVariable.DISPOSE_ON_CLOSE);
    sv.setLocationRelativeTo(null);
    sv.setVisible(true);
}//GEN-LAST:event_bSeleccionarVariableDim2ActionPerformed

private void bSeleccionarVariableDim5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bSeleccionarVariableDim5ActionPerformed
    SeleccionarVariable sv = new SeleccionarVariable(this, "Variable - Seleccionar", this.medida5);
    sv.setDefaultCloseOperation(SeleccionarVariable.DISPOSE_ON_CLOSE);
    sv.setLocationRelativeTo(null);
    sv.setVisible(true);
}//GEN-LAST:event_bSeleccionarVariableDim5ActionPerformed

private void bSeleccionarVariableDim4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bSeleccionarVariableDim4ActionPerformed
    SeleccionarVariable sv = new SeleccionarVariable(this, "Variable - Seleccionar", this.medida4);
    sv.setDefaultCloseOperation(SeleccionarVariable.DISPOSE_ON_CLOSE);
    sv.setLocationRelativeTo(null);
    sv.setVisible(true);
}//GEN-LAST:event_bSeleccionarVariableDim4ActionPerformed

private void bSeleccionarVariableDim3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bSeleccionarVariableDim3ActionPerformed
    SeleccionarVariable sv = new SeleccionarVariable(this, "Variable - Seleccionar", this.medida3);
    sv.setDefaultCloseOperation(SeleccionarVariable.DISPOSE_ON_CLOSE);
    sv.setLocationRelativeTo(null);
    sv.setVisible(true);
}//GEN-LAST:event_bSeleccionarVariableDim3ActionPerformed

private void rbArticuloBaseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbArticuloBaseActionPerformed
    if(rbArticuloBase.isSelected()){
        rbAnadirPvp.setSelected(false);
        rbAnadirIncremento.setSelected(false);
    }
}//GEN-LAST:event_rbArticuloBaseActionPerformed

private void rbAnadirPvpActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbAnadirPvpActionPerformed
    if(rbAnadirPvp.isSelected()){
        rbAnadirIncremento.setSelected(false);
        rbArticuloBase.setSelected(false);
    }
}//GEN-LAST:event_rbAnadirPvpActionPerformed

private void rbAnadirIncrementoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbAnadirIncrementoActionPerformed
    if(rbAnadirIncremento.isSelected()){
        rbAnadirPvp.setSelected(false);
        rbArticuloBase.setSelected(false);
    }
}//GEN-LAST:event_rbAnadirIncrementoActionPerformed

private void tCodigoArticuloKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tCodigoArticuloKeyReleased
    if (evt.getKeyChar() == KeyEvent.VK_ENTER) {
        String sCodigo = tCodigoArticulo.getText();
        if (!sCodigo.equals("")) {
            String codigoArticulo = "";
            String codigoCaracteristica = "";

            if (sCodigo.contains("/")) {
                codigoArticulo = sCodigo.substring(0, sCodigo.indexOf('/'));
                codigoCaracteristica = sCodigo.substring(sCodigo.indexOf('/') + 1);
            } else {
                codigoArticulo = sCodigo;
                codigoCaracteristica = "";
            }

            Articulo artT = BaseDatos.obtenerArticulo(codigoArticulo, e.getIid());
            Colores colorT = null;
            Caracteristica cT = null;
            boolean operacionOK = true;

            if (artT == null) {
                //Error, el articulo no existe
                tCodigoArticulo.setForeground(Color.RED);
                tDescripcionArticulo.setText("El artículo introducido no existe");
                operacionOK = false;
            } else {
                List listaC = BaseDatos.getListaCaracteristicas(e, artT);
                if (listaC != null && listaC.size() > 0) {
                    if (codigoCaracteristica.equals("")) {
                        //Error
                        tDescripcionArticulo.setText("El artículo introducido tiene características");
                        operacionOK = false;
                    } else {
                        //Ok
                        colorT = BaseDatos.obtenerColor(codigoCaracteristica);
                        if (colorT == null) {
                            //Error
                            tDescripcionArticulo.setText("La característica introducida no existe");
                            operacionOK = false;
                        } else {
                            cT = BaseDatos.obtenerCaracteristica(artT, e, colorT);
                            if (cT == null) {
                                //Error
                                tDescripcionArticulo.setText("La característica introducida no existe");
                                operacionOK = false;
                            } else {
                                tCodigoArticulo.setForeground(Color.BLACK);
                                tDescripcionArticulo.setText("");
                            }
                        }
                    }
                } else {
                    if (!codigoCaracteristica.equals("")) {
                        //Error
                        tDescripcionArticulo.setText("El artículo introducido no tiene características");
                        operacionOK = false;
                    } else {
                        //Ok
                        colorT = null;
                        cT = null;
                    }
                }

                if (operacionOK) {
                    this.ar = artT;
                    this.car = cT;
                    tCodigoArticulo.setForeground(Color.BLACK);
                    this.tDescripcionArticulo.setText(ar.getDes_inf());
                    rellenarArticulo(ar, car);
                } else {
                    tCodigoArticulo.setForeground(Color.red);
                    this.panelesDimension.setVisible(false);
                    
                }

            }
        }
    }
}//GEN-LAST:event_tCodigoArticuloKeyReleased

private void cColoresActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cColoresActionPerformed
    String colorSeleccionado = (String) this.cColores.getSelectedItem();
    if(this.ar != null && !colorSeleccionado.equals(Constantes.VACIO)){
        Caracteristica carac = BaseDatos.obtenerCaracteristica(ar, e, BaseDatos.obtenerColorPorDescripcion(colorSeleccionado));
        if(carac != null){
            this.car = carac;
            String codCar = "";
            Colores col = BaseDatos.obtenerColorPorIid(this.car.getIid_color().getIid());
            codCar = col.getCod_color();
            tCodigoArticulo.setText(this.ar.getCod_articulo() + "/" + codCar);
        } else {
            JOptionPane.showMessageDialog(null, "El articulo seleccionado no posee la caracteristica " + colorSeleccionado, "Error", JOptionPane.ERROR_MESSAGE);
            if(this.car != null){
                cColores.setSelectedItem(this.car.getIid_color().getDescripcion());
            } else {
                cColores.setSelectedItem(Constantes.VACIO);
            }
        }
    }
}//GEN-LAST:event_cColoresActionPerformed

protected String getModificador(){
    return (String)cModificador.getSelectedItem();
}

public void insertarValorFormula(String variable, javax.swing.JTextArea medida){
    medida.insert(variable, medida.getCaretPosition());
}
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bAceptar;
    private javax.swing.JButton bAyuda;
    private javax.swing.JButton bCancelar;
    private javax.swing.JButton bEvaluarCantidad;
    private javax.swing.JButton bEvaluarDim1;
    private javax.swing.JButton bEvaluarDim2;
    private javax.swing.JButton bEvaluarDim3;
    private javax.swing.JButton bEvaluarDim4;
    private javax.swing.JButton bEvaluarDim5;
    private javax.swing.JButton bSeleccionarVariableCantidad;
    private javax.swing.JButton bSeleccionarVariableDim1;
    private javax.swing.JButton bSeleccionarVariableDim2;
    private javax.swing.JButton bSeleccionarVariableDim3;
    private javax.swing.JButton bSeleccionarVariableDim4;
    private javax.swing.JButton bSeleccionarVariableDim5;
    private javax.swing.JButton bSelecionarArticulo;
    private javax.swing.JComboBox cColores;
    private javax.swing.JComboBox cModificador;
    private javax.swing.JComboBox cRedondeo;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JLabel lCodigoArticulo;
    private javax.swing.JLabel lRedondeo;
    private javax.swing.JTextArea medida1;
    private javax.swing.JTextArea medida2;
    private javax.swing.JTextArea medida3;
    private javax.swing.JTextArea medida4;
    private javax.swing.JTextArea medida5;
    private javax.swing.JTextArea medidaCantidad;
    private javax.swing.JPanel pArticulo;
    private javax.swing.JPanel pCantidad;
    private javax.swing.JPanel pDatosArticulo;
    private javax.swing.JPanel pDespiece;
    private javax.swing.JPanel pDim1;
    private javax.swing.JPanel pDim2;
    private javax.swing.JPanel pDim3;
    private javax.swing.JPanel pDim4;
    private javax.swing.JPanel pDim5;
    private javax.swing.JTabbedPane panelesDimension;
    private javax.swing.JRadioButton rbAnadirIncremento;
    private javax.swing.JRadioButton rbAnadirPvp;
    private javax.swing.JRadioButton rbArticuloBase;
    private javax.swing.JTextField tCodigoArticulo;
    private javax.swing.JTextField tDescripcionArticulo;
    // End of variables declaration//GEN-END:variables
}
