package gui;

import acceso.BaseDatos;
import bean.AgenteArticuloCodigo;
import bean.Articulo;
import bean.Caracteristica;
import bean.Colores;
import bean.Empresa;
import bean.Existencia;
import bean.FamiliaVenta;
import bean.Interlocutor;
import bean.InterlocutorFamiliaVenta;
import bean.UnidadMedida;
import bean.Usuario;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JOptionPane;
import javax.swing.KeyStroke;
import matematico.Matematico;
import modelo.Modelo;
import util.Constantes;
import util.Util;

public class ListaDeArticulos extends javax.swing.JFrame {
    private Empresa e;
    private Articulo a;
    private Usuario u;
    private Interlocutor inter;
    private Empresa in;
    private List listaFormulas;
    private HashMap<Integer, String> listaFam = new HashMap<Integer, String>();

    public ListaDeArticulos(Empresa e, Usuario u) {
        super("Lista de Artículos");
        setExtendedState(MAXIMIZED_BOTH);

        this.e = e;
        this.u = u;
        initComponents();
        iniciarInterlocutores();

        if (tarticulos1.getRowCount() > 0) {
            tarticulos1.setRowSelectionInterval(0, 0);
            String codigo = (String) tarticulos1.getModel().getValueAt(0, 1);
            Articulo art = BaseDatos.obtenerArticulo(codigo, e.getIid());
            if (art != null) {
                rellenarCaracteristicas(e, art);
            }
        }
        tarticulos1.changeSelection(0, 0, false, false);
        tbusqueda1.requestFocus();
        bConfig.setEnabled(false);
        crearIconosBotones();
        crearAcciones();
    }

    private void crearAcciones() {
        KeyStroke escapeKeyStroke = KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false);
        Action escapeAction = new AbstractAction() {
            public void actionPerformed(ActionEvent e) {
                cerrarListaDeArticulos();
            }
        };
        getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(escapeKeyStroke, "ESCAPE");
        getRootPane().getActionMap().put("ESCAPE", escapeAction);

        KeyStroke f1KeyStroke = KeyStroke.getKeyStroke(KeyEvent.VK_F1, 0, false);
        Action f1Action = new AbstractAction() {
            public void actionPerformed(ActionEvent ev) {
                crearArticulo();
            }
        };
        getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(f1KeyStroke, "F1");
        getRootPane().getActionMap().put("F1", f1Action);

        KeyStroke f3KeyStroke = KeyStroke.getKeyStroke(KeyEvent.VK_F3, 0, false);
        Action f3Action = new AbstractAction() {
            public void actionPerformed(ActionEvent ev) {
                visualizarArticulo();
            }
        };
        getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(f3KeyStroke, "F3");
        getRootPane().getActionMap().put("F3", f3Action);

        KeyStroke f2KeyStroke = KeyStroke.getKeyStroke(KeyEvent.VK_F2, 0, false);
        Action f2Action = new AbstractAction() {
            public void actionPerformed(ActionEvent ev) {
                visualizarArticulo();
            }
        };
        getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(f2KeyStroke, "F2");
        getRootPane().getActionMap().put("F2", f2Action);
    }

    private void borrarArticulo() throws HeadlessException {
        try {
            int indiceFila = tarticulos1.getSelectedRow();
            if (indiceFila >= 0) {

                int eliminar = 1;
                eliminar = JOptionPane.showConfirmDialog(null, "¿Está seguro de que desea eliminar el elemento seleccionado?", "¿Eliminar?", JOptionPane.YES_NO_OPTION);
                //hacerCambios = -1 ==> se ha pulsado la "x" de cancelar;
                //hacerCambios =  0 ==> se ha pulsado el "sí"
                //hacerCambios =  1 ==> se ha pulsado el "no"
                if (eliminar == 0) {
                    //obtenemos el codigo de la familia de venta
                    String codigo = (String) tarticulos1.getModel().getValueAt(indiceFila, 1);

                    //obtenemos artículo a través de su código
                    Articulo ar = BaseDatos.obtenerArticulo(codigo, e.getIid());
                    if (BaseDatos.eliminarArticulo(ar.getIid())) {
                        borrarCaracteristicas();
                        completarPantalla();
                    } else {
                        JOptionPane.showMessageDialog(null, "No se ha podido eliminar el elemento", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
            } else {
                JOptionPane.showMessageDialog(null, "No hay seleccionado ningún elemento", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Este elemento no se puede eliminar", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    final void crearArticulo() {
        NuevoArticulo nar = new NuevoArticulo(e, "Artículo - Creación", u);
        nar.setDefaultCloseOperation(NuevoArticulo.DISPOSE_ON_CLOSE);
        nar.setLocationRelativeTo(null);
        nar.setVisible(true);
        cerrarListaDeArticulos();
    }

    final void cerrarListaDeArticulos() {
        removeAll();
        dispose();
    }

    private void crearIconosBotones() {
        URL url = getClass().getResource("/iconos/detalle.png");
        ImageIcon icono = new ImageIcon(url);
        bvisualizar.setIcon(icono);

        url = getClass().getResource("/iconos/borrar32.png");
        icono = new ImageIcon(url);
        bborrar.setIcon(icono);

        url = getClass().getResource("/iconos/eliminar.png");
        icono = new ImageIcon(url);
        bcerrar.setIcon(icono);

        url = getClass().getResource("/iconos/aceptar.png");
        icono = new ImageIcon(url);
        bcrear.setIcon(icono);

        url = getClass().getResource("/iconos/pprov.png");
        icono = new ImageIcon(url);
        bProv.setIcon(icono);

        url = getClass().getResource("/iconos/venta.png");
        icono = new ImageIcon(url);
        bAventa.setIcon(icono);

        url = getClass().getResource("/iconos/compra.png");
        icono = new ImageIcon(url);
        bAcompra.setIcon(icono);

        url = getClass().getResource("/iconos/config.png");
        icono = new ImageIcon(url);
        bConfig.setIcon(icono);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        gBusqueda = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        tbusqueda1 = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        Modelo modelo1 = new Modelo();
        tarticulos1 = new javax.swing.JTable(modelo1);
        jScrollPane1 = new javax.swing.JScrollPane();
        Modelo modelo = new Modelo();
        tcaracteristicas = new javax.swing.JTable(modelo);
        rCodigo = new javax.swing.JRadioButton();
        rDes = new javax.swing.JRadioButton();
        rFamilia = new javax.swing.JRadioButton();
        jPanel3 = new javax.swing.JPanel();
        bAventa = new javax.swing.JButton();
        bAcompra = new javax.swing.JButton();
        bConfig = new javax.swing.JButton();
        bProv = new javax.swing.JButton();
        cInterlocutor = new javax.swing.JComboBox();
        jLabel1 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        bcrear = new javax.swing.JButton();
        bborrar = new javax.swing.JButton();
        bvisualizar = new javax.swing.JButton();
        bcerrar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        tbusqueda1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tbusqueda1KeyReleased(evt);
            }
        });

        // Creamos las columnas.
        modelo1.addColumn("Descripción");
        modelo1.addColumn("Código");
        modelo1.addColumn("Tipo");

        List larticulos1 = BaseDatos.getListaArticulos(e.getIid());
        Articulo ar1;
        Object[] fila1;
        Iterator<Articulo> it1;
        FamiliaVenta fm;
        Integer famId;
        if(larticulos1 != null){
            for (it1 = larticulos1.iterator(); it1.hasNext();) {
                fila1 = new Object[3];
                ar1 = it1.next();
                famId = ar1.getIid_fam_venta().getIid();
                if(ar1.getIid_fam_venta() != null) {
                    if(!listaFam.containsKey(famId)){
                        fm = BaseDatos.obtenerFamiliaVentaPorIid(ar1.getIid_fam_venta().getIid());
                        listaFam.put(famId, fm.getNombre());
                    }
                }
                fila1[0] = ar1.getDes_inf();
                fila1[1] = ar1.getCod_articulo();
                fila1[2] = listaFam.get(famId);
                modelo1.addRow(fila1);
            }
        }
        tarticulos1.getColumnModel().getColumn(0).setPreferredWidth(300);
        tarticulos1.getColumnModel().getColumn(1).setPreferredWidth(100);
        tarticulos1.getColumnModel().getColumn(2).setPreferredWidth(100);;
        tarticulos1.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        tarticulos1.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        tarticulos1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tarticulos1MouseClicked(evt);
            }
        });
        tarticulos1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tarticulos1KeyPressed(evt);
            }
        });
        jScrollPane2.setViewportView(tarticulos1);

        tcaracteristicas.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        // Creamos las columnas.
        modelo.addColumn("Color");
        modelo.addColumn("UPC");
        modelo.addColumn("PMC");
        modelo.addColumn("PVP");
        modelo.addColumn("Añadido");
        modelo.addColumn("Existencias");
        modelo.addColumn("UM");
        modelo.addColumn("Precio Escalado");

        tcaracteristicas.getColumnModel().getColumn(0).setPreferredWidth(100);
        tcaracteristicas.getColumnModel().getColumn(1).setPreferredWidth(100);
        tcaracteristicas.getColumnModel().getColumn(2).setPreferredWidth(100);
        tcaracteristicas.getColumnModel().getColumn(3).setPreferredWidth(100);
        tcaracteristicas.getColumnModel().getColumn(4).setPreferredWidth(100);
        tcaracteristicas.getColumnModel().getColumn(5).setPreferredWidth(100);
        tcaracteristicas.getColumnModel().getColumn(6).setPreferredWidth(100);
        tcaracteristicas.getColumnModel().getColumn(7).setPreferredWidth(100);
        tcaracteristicas.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        jScrollPane1.setViewportView(tcaracteristicas);

        gBusqueda.add(rCodigo);
        rCodigo.setText("Código");
        rCodigo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rCodigoActionPerformed(evt);
            }
        });

        gBusqueda.add(rDes);
        rDes.setSelected(true);
        rDes.setText("Descripción");
        rDes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rDesActionPerformed(evt);
            }
        });

        gBusqueda.add(rFamilia);
        rFamilia.setText("Familia");
        rFamilia.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                rFamiliaStateChanged(evt);
            }
        });

        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED), "Usar"));

        bAventa.setToolTipText("Crear albarán");
        bAventa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bAventaActionPerformed(evt);
            }
        });

        bAcompra.setToolTipText("Pedir");
        bAcompra.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bAcompraActionPerformed(evt);
            }
        });

        bConfig.setToolTipText("Configurar Producto");
        bConfig.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bConfigActionPerformed(evt);
            }
        });

        bProv.setToolTipText("Precios por Proveedor");
        bProv.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bProvActionPerformed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout jPanel3Layout = new org.jdesktop.layout.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, jPanel3Layout.createSequentialGroup()
                .add(bAventa)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                .add(bAcompra)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(bConfig)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                .add(bProv))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                    .add(bAcompra, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .add(bAventa, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .add(bConfig, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .add(bProv, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 27, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        cInterlocutor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cInterlocutorActionPerformed(evt);
            }
        });

        jLabel1.setText("Interlocutor: ");

        bcrear.setToolTipText("Crear (F1)");
        bcrear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bcrearActionPerformed(evt);
            }
        });

        bborrar.setToolTipText("Borrar (F2)");
        bborrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bborrarActionPerformed(evt);
            }
        });

        bvisualizar.setToolTipText("Visualizar (F3)");
        bvisualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bvisualizarActionPerformed(evt);
            }
        });

        bcerrar.setToolTipText("Salir (Esc)");
        bcerrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bcerrarActionPerformed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout jPanel2Layout = new org.jdesktop.layout.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .add(bcrear, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 53, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(bborrar, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 57, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(bvisualizar, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 50, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                .add(bcerrar, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 49, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .add(18, 18, 18))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(31, Short.MAX_VALUE)
                .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                    .add(bcrear, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .add(bborrar, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .add(bvisualizar, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .add(org.jdesktop.layout.GroupLayout.TRAILING, bcerrar, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 45, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .add(24, 24, 24))
        );

        org.jdesktop.layout.GroupLayout jPanel1Layout = new org.jdesktop.layout.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                    .add(jScrollPane2, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 579, Short.MAX_VALUE)
                    .add(tbusqueda1))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jScrollPane1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 549, Short.MAX_VALUE)
                    .add(jPanel1Layout.createSequentialGroup()
                        .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(jPanel1Layout.createSequentialGroup()
                                .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                                    .add(rDes)
                                    .add(jLabel1))
                                .add(5, 5, 5)
                                .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                                    .add(jPanel1Layout.createSequentialGroup()
                                        .add(rCodigo)
                                        .add(10, 10, 10)
                                        .add(rFamilia))
                                    .add(cInterlocutor, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 209, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                            .add(jPanel3, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(jPanel2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                        .add(0, 256, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(tbusqueda1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(rCodigo)
                    .add(rDes)
                    .add(rFamilia))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jScrollPane2, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 519, Short.MAX_VALUE)
                    .add(jPanel1Layout.createSequentialGroup()
                        .add(8, 8, 8)
                        .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(cInterlocutor, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(jLabel1))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                        .add(jScrollPane1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 165, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(18, 18, 18)
                        .add(jPanel3, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 68, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED, 129, Short.MAX_VALUE)
                        .add(jPanel2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))))
        );

        org.jdesktop.layout.GroupLayout layout = new org.jdesktop.layout.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void bProvActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bProvActionPerformed
        //Recuperamos el articulo
        Articulo ar = this.obtenerArticuloSel();
        if (ar != null) {
            List<AgenteArticuloCodigo> lAgenteArticuloCodigo;
            lAgenteArticuloCodigo = BaseDatos.getListaAgenteArticuloCodigo(ar.getIid());
            String inteDesc = "";

            if (in != null) {
                inteDesc = in.getDesc_empresa() + "//";
            }

            NuevoArticulo nar = new NuevoArticulo(e, ar, inteDesc + " Artículo - Modificación", u, inter);
            ListaAgenteArticuloCodigo laac = new ListaAgenteArticuloCodigo(ar, nar, lAgenteArticuloCodigo, e, 1);
            laac.setDefaultCloseOperation(ListaAgenteArticuloCodigo.DISPOSE_ON_CLOSE);
            laac.setLocationRelativeTo(null);
            laac.setVisible(true);
            laac = null;
        } else {
            JOptionPane.showMessageDialog(null, "No hay seleccionado ningún elemento", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_bProvActionPerformed

    private void bAcompraActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bAcompraActionPerformed
        Articulo ar = this.obtenerArticuloSel();
        if (ar != null) {
            Caracteristica c = this.obtenerCarSel(ar);

            NuevoCompras np = new NuevoCompras(e, BaseDatos.getClaseDocumentosByDescripcion(Constantes.PEDIDOC), u, ar, c);
            np.setDefaultCloseOperation(NuevoPresupuesto.DISPOSE_ON_CLOSE);
            np.setLocationRelativeTo(null);
            np.setVisible(true);
            BaseDatos.desUsarArticulo(ar.getIid());
        } else {
            JOptionPane.showMessageDialog(null, "No hay seleccionado ningún elemento", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_bAcompraActionPerformed

    private void bAventaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bAventaActionPerformed
        Articulo ar = this.obtenerArticuloSel();
        if (ar != null) {
            Caracteristica c = this.obtenerCarSel(ar);
            if (inter == null || inter.getEmpresaHija() == e) {
                inter = null;
            }

            NuevoPresupuesto np = new NuevoPresupuesto(e, BaseDatos.getClaseDocumentosByDescripcion(Constantes.ALBARAN), u, ar, c, inter);
            np.setDefaultCloseOperation(NuevoPresupuesto.DISPOSE_ON_CLOSE);
            np.setLocationRelativeTo(null);
            np.setVisible(true);
            BaseDatos.desUsarArticulo(ar.getIid());
        } else {
            JOptionPane.showMessageDialog(null, "No hay seleccionado ningún elemento", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_bAventaActionPerformed

    private void rFamiliaStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_rFamiliaStateChanged
        if (rFamilia.isSelected()) {
            String familia = tbusqueda1.getText().toLowerCase();
            if (!familia.isEmpty()) {
                List larticulos1 = BaseDatos.busquedaRapidaArticuloPorFamilia(familia, e.getIid());
                actualizarArticulos1(larticulos1);
            }
        }
    }//GEN-LAST:event_rFamiliaStateChanged

    private void rDesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rDesActionPerformed
        //En el caso de que la opción descripción esté seleccionada buscamos por este campo
        if (rDes.isSelected()) {
            String descripcion = tbusqueda1.getText().toLowerCase();
            if (!descripcion.isEmpty()) {
                List larticulos1 = BaseDatos.busquedaRapidaArticuloPorDescripcion(descripcion, e.getIid());
                actualizarArticulos1(larticulos1);
            }
        }
    }//GEN-LAST:event_rDesActionPerformed

    private void bcerrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bcerrarActionPerformed
        cerrarListaDeArticulos();
    }//GEN-LAST:event_bcerrarActionPerformed

    private void bvisualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bvisualizarActionPerformed
        visualizarArticulo();
    }//GEN-LAST:event_bvisualizarActionPerformed

    private void bborrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bborrarActionPerformed
        borrarArticulo();
    }//GEN-LAST:event_bborrarActionPerformed

    private void bcrearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bcrearActionPerformed
        crearArticulo();
    }//GEN-LAST:event_bcrearActionPerformed

    private void tarticulos1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tarticulos1KeyPressed
        if (evt.getKeyChar() == KeyEvent.VK_ENTER) {
            visualizarArticulo();
        } else if (evt.getKeyChar() == KeyEvent.VK_DELETE) {
            borrarArticulo();
        } else if (evt.getKeyCode() == KeyEvent.VK_INSERT) {
            insertarArticuloALB();
        }

        int indiceFila = tarticulos1.getSelectedRow();
        if (evt.getKeyCode() == KeyEvent.VK_UP) {
            if (indiceFila != 0) {
                indiceFila--;
            }
        }
        if (evt.getKeyCode() == KeyEvent.VK_DOWN) {
            if (indiceFila != (tarticulos1.getRowCount() - 1)) {
                indiceFila++;
            }
        }

        if (indiceFila >= 0) {
            String codigo = (String) tarticulos1.getModel().getValueAt(indiceFila, 1);
            a = BaseDatos.obtenerArticulo(codigo, e.getIid());
            if (a != null) {
                rellenarCaracteristicas(e, a);
                tcaracteristicas.setRowSelectionInterval(0, 0);
            }
        }
    }//GEN-LAST:event_tarticulos1KeyPressed

    private void tarticulos1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tarticulos1MouseClicked
        int indiceFila = tarticulos1.getSelectedRow();
        if (indiceFila >= 0) {
            String codigo = (String) tarticulos1.getModel().getValueAt(indiceFila, 1);
            a = BaseDatos.obtenerArticulo(codigo, e.getIid());
            if (a != null) {
                rellenarCaracteristicas(e, a);
                tcaracteristicas.setRowSelectionInterval(0, 0);
            }
            FamiliaVenta fv = BaseDatos.obtenerFamiliaVentaPorIid(a.getIid_fam_venta().getIid());
            if (fv.getCod_familia().equals("PC")) {
                bConfig.setEnabled(true);
                bAcompra.setEnabled(false);
                bProv.setEnabled(false);
            } else {
                bConfig.setEnabled(false);
                bAcompra.setEnabled(true);
                bProv.setEnabled(true);
            }
        }

        if (evt.getClickCount() == 2) {
            visualizarArticulo();
        }
    }//GEN-LAST:event_tarticulos1MouseClicked

    private void tbusqueda1KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tbusqueda1KeyReleased
        if (rDes.isSelected()) {
            actualizarArticulos1(BaseDatos.busquedaRapidaArticuloPorDescripcion(tbusqueda1.getText().toLowerCase(), e.getIid()));
        } else if (rCodigo.isSelected()) {
            actualizarArticulos1(BaseDatos.busquedaRapidaArticuloPorCodigo(tbusqueda1.getText().toLowerCase(), e.getIid()));
        } else if (rFamilia.isSelected()) {
            actualizarArticulos1(BaseDatos.busquedaRapidaArticuloPorFamilia(tbusqueda1.getText().toLowerCase(), e.getIid()));
        }
    }//GEN-LAST:event_tbusqueda1KeyReleased

    private void cInterlocutorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cInterlocutorActionPerformed
        String empresaSeleccionada = (String) cInterlocutor.getSelectedItem();
        if (!empresaSeleccionada.equals(Constantes.VACIO)) {
            empresaSeleccionada = empresaSeleccionada.substring(0, empresaSeleccionada.indexOf("[(") - 3);
        }
        //Informamos el interlocutor y la lista de fórmulas
        in = BaseDatos.obtenerEmpresa(empresaSeleccionada);
        inter = BaseDatos.obtenerInterlocutor(in, e);
        if(inter!=null){
            listaFormulas = BaseDatos.obtenerInterFormulas(inter);
        }
        
        if (a != null) {
            rellenarCaracteristicas(e, a);
        }

    }//GEN-LAST:event_cInterlocutorActionPerformed

    private void bConfigActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bConfigActionPerformed
        Articulo ar = this.obtenerArticuloSel();
        if (ar != null) {
            NuevoDAC nd = new NuevoDAC(e, "Creación de prodcuto", ar);
            nd.setDefaultCloseOperation(NuevoPresupuesto.DISPOSE_ON_CLOSE);
            nd.setLocationRelativeTo(null);
            nd.setVisible(true);
        } else {
            JOptionPane.showMessageDialog(null, "No hay seleccionado ningún elemento", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_bConfigActionPerformed

private void rCodigoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rCodigoActionPerformed
    if (rCodigo.isSelected()) {
        String codigo = tbusqueda1.getText().toLowerCase();
        if (!codigo.isEmpty()) {
            actualizarArticulos1(BaseDatos.busquedaRapidaArticuloPorCodigo(codigo, e.getIid()));
        }
    }
}//GEN-LAST:event_rCodigoActionPerformed

    private void visualizarArticulo() {
        int indiceFila = this.tarticulos1.getSelectedRow();
        if (indiceFila >= 0) {

            //obtenemos el código
            String codigo = (String) tarticulos1.getModel().getValueAt(indiceFila, 1);

            //obtenemos el tipo de producto a través de su código
            Articulo ar = BaseDatos.obtenerArticulo(codigo, e.getIid());
            if (ar.getEnUso() != null && !ar.getEnUso().equals("")) {
                if (ar.getEnUso().equals(u.getNombre())) {
                    JOptionPane.showMessageDialog(null, "El artítulo ya está abierto por usted", "Error", JOptionPane.ERROR_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(null, "El artítulo ya está abierto por otro usuario", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                ar.setEnUso(u.getNombre());
                BaseDatos.modificarElemento(ar);
                String inteDesc = "";
                if (in != null) {
                    inteDesc = in.getDesc_empresa() + "//";
                }

                NuevoArticulo nar = new NuevoArticulo(e, ar, inteDesc + "Artículo - Modificación", u, inter);
                nar.setDefaultCloseOperation(NuevoArticulo.DISPOSE_ON_CLOSE);
                nar.setLocationRelativeTo(null);
                nar.setVisible(true);
            }
        } else {
            JOptionPane.showMessageDialog(null, "No hay seleccionado ningún elemento", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void insertarArticuloALB() {
        int indiceFila = this.tarticulos1.getSelectedRow();
        if (indiceFila >= 0) {
            //obtenemos el código
            String codigo = (String) tarticulos1.getModel().getValueAt(indiceFila, 1);
            
            //obtenemos el tipo de producto a través de su código
            Articulo ar = BaseDatos.obtenerArticulo(codigo, e.getIid());
            Caracteristica c = this.obtenerCarSel(ar);
            if (inter == null || inter.getEmpresaHija() == e) {
                inter = null;
            }
            NuevoPresupuesto np = new NuevoPresupuesto(e, BaseDatos.getClaseDocumentosByDescripcion(Constantes.ALBARAN), u, ar, c, inter);
            np.setDefaultCloseOperation(NuevoPresupuesto.DISPOSE_ON_CLOSE);
            np.setLocationRelativeTo(null);
            np.setVisible(true);
            cerrarListaDeArticulos();
        }
    }

    private Articulo obtenerArticuloSel() {
        Integer indiceFila = tarticulos1.getSelectedRow();
        Articulo ar = null;
        if (indiceFila!= -1){
            //Obtener codigo
            String codigo = (String) tarticulos1.getModel().getValueAt(indiceFila, 1);
            //obtenemos artículo a través de su código
            ar = BaseDatos.obtenerArticulo(codigo, e.getIid());
        }else{
          ar = null;
        }
        return ar;
    }

    private Caracteristica obtenerCarSel(Articulo ar) {
        Integer indiceFila = tcaracteristicas.getSelectedRow();
        //Obtener codigo
        String color = (String) tcaracteristicas.getModel().getValueAt(indiceFila, 0);
        Colores c = BaseDatos.obtenerColor(color);
        //obtenemos artículo a través de su código
        Caracteristica car = BaseDatos.obtenerCaracteristica(ar, e, c);
        return car;
    }

    private void borrarCaracteristicas() {
        Modelo modelo = (Modelo) tcaracteristicas.getModel();
        int i, j = modelo.getRowCount();

        //eliminamos todas las filas
        for (i = 0; i < j; i++) {
            modelo.removeRow(0);
        }
    }

    private void rellenarCaracteristicas(Empresa e, Articulo a) {
        Modelo modelo = (Modelo) tcaracteristicas.getModel();
        int i, j = modelo.getRowCount();

        //eliminamos todas las filas
        for (i = 0; i < j; i++) {
            modelo.removeRow(0);
        }

        List lcaracteristicas = BaseDatos.getListaCaracteristicas(e, a);
        Caracteristica car;
        Object[] fila;
        Iterator<Caracteristica> it;

        Float AcPtc = 0.0F;
        Float AcPvp = 0.0F;
        Float AcUpc = 0.0F;
        Float AcInc = 0.0F;

        ScriptEngineManager manager = new ScriptEngineManager();
        ScriptEngine engine = manager.getEngineByName("js");

        //Cargamos la formula en el caso que exista interlocutor
        String formula = "";
        FamiliaVenta fv = BaseDatos.obtenerFamiliaVentaPorIid(a.getIid_fam_venta().getIid());
        if (in != null && e != in) {
            formula = obtenerFormula(fv);
        }

        AcUpc = a.getUpc();
        AcPtc = a.getPtc();
        AcPvp = a.getPrecio_v();
        AcInc = a.getPrecioIncremento();
        AcPvp = Matematico.redondear2decimales(AcPvp);
        
        //Añadir artículo principal
        Caracteristica arC = new Caracteristica();
        arC.setIid_color(null);
        arC.setUpc(AcUpc);
        arC.setPtc(AcPtc);
        arC.setPvp(AcPvp);
        arC.setEscalado(a.getEscalado());
        arC.setPrecioIncremento(AcInc);
        arC.setEscalado(a.getEscalado());

        //Calcular existencias
        Existencia existencia = BaseDatos.getExistenciaByIid(arC.getIid());
        Float cantidad = null;

        if (existencia != null) {
            cantidad = existencia.getCantidad1();
        }

        lcaracteristicas.add(0, arC);
        try {
            if (lcaracteristicas != null) {
                for (it = lcaracteristicas.iterator(); it.hasNext();) {
                    fila = new Object[8];
                    car = it.next();
                    
                    fila[0] = (car.getIid_color() != null)?car.getIid_color().getCod_color(): "S/C";
                    if (car.getUpc() != null) {
                        if (formula == null || formula.length() == 0) {
                            fila[1] = Util.convertirPuntoAComa(car.getUpc().toString());
                        } else {
                            //Formula
                            fila[1] = Util.convertirPuntoAComa(car.getPvp().toString());
                        }
                    }
                    if (car.getPtc() != null) {
                        if (formula == null || formula.length() == 0) {
                            fila[2] = Util.convertirPuntoAComa(car.getPtc().toString());
                        } else {
                            //Formula
                            fila[2] = Util.convertirPuntoAComa(car.getPvp().toString());

                        }
                    }
                    if (car.getPvp() != null) {
                        if (formula == null || formula.length() == 0) {
                            fila[3] = Util.convertirPuntoAComa(car.getPvp().toString());
                        } else {
                            //Formula                    
                            String forc = formula.replace("pvp", car.getPvp().toString());
                            Float pvp = (Float) Float.parseFloat(engine.eval(forc).toString());
                            pvp = Matematico.redondear2decimales(pvp);
                            fila[3] = Util.convertirPuntoAComa(pvp.toString());
                        }
                    }
                    if (car.getPrecioIncremento() != null) {
                        if (formula == null || formula.length() == 0) {
                            fila[4] = Util.convertirPuntoAComa(car.getPrecioIncremento().toString());
                        } else {
                            //Formula                    
                            String forc = formula.replace("pvp", car.getPrecioIncremento().toString());
                            Float pvp = (Float) Float.parseFloat(engine.eval(forc).toString());
                            pvp = Matematico.redondear2decimales(pvp);
                            fila[4] = Util.convertirPuntoAComa(pvp.toString());
                        }
                    }
                    if (car.getIid_color() != null) {
                        Float cantC = BaseDatos.getExistenciaCaracteristica(car.getIid_articulo(), car.getIid());
                        if (cantC != null) {
                            fila[5] = cantC.toString();
                        } else if (existencia != null) {
                            fila[5] = cantidad;
                        }
                    } else {
                        fila[5] = Util.convertirPuntoAComa(BaseDatos.getExistenciaCaracteristica(a, null).toString());
                    }

                    if (car.getEscalado() != null && car.getEscalado()) {
                        fila[7] = "Sí";
                    } else {
                        fila[7] = "No";
                    }

                    if (a.getIid_unidad_medida() != null) {
                        UnidadMedida um = BaseDatos.obtenerUnidadMedidaIid(a.getIid_unidad_medida().getIid());
                        fila[6] = um.getAbreviacion();
                    }

                    modelo.addRow(fila);
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    private void actualizarArticulos1(List lar1) {
        Modelo modelo1 = (Modelo) tarticulos1.getModel();
        int i, j = modelo1.getRowCount();
        FamiliaVenta fv;
        Integer famId;
        Articulo ar1;
        Iterator<Articulo> it1;
        Object[] fila1;
        
        //eliminamos todas las filas
        for (i = 0; i < j; i++) {
            modelo1.removeRow(0);
        }

        if (lar1 == null) {
            lar1 = new ArrayList();
        }
        
        for (it1 = lar1.iterator(); it1.hasNext();) {
            fila1 = new Object[3];
            ar1 = it1.next();
            famId = ar1.getIid_fam_venta().getIid();
            if (!listaFam.containsKey(famId)) {
                fv = BaseDatos.obtenerFamiliaVentaPorIid(ar1.getIid_fam_venta().getIid());
                listaFam.put(famId, fv.getNombre());
            }
            fila1[0] = ar1.getDes_inf();
            fila1[1] = ar1.getCod_articulo();
            fila1[2] = listaFam.get(famId);
            modelo1.addRow(fila1);
        }
    }

    private void completarPantalla() {
        actualizarArticulos1(BaseDatos.getListaArticulos(e.getIid()));
    }

    private void iniciarInterlocutores() {
        List listaInterlocutores = BaseDatos.getListaInterlocutores(e);
        if (listaInterlocutores != null && listaInterlocutores.size() > 0) {
            Iterator<Interlocutor> iter = listaInterlocutores.iterator();
            Empresa emp;
            Interlocutor interl;
            //Insertamos a la empresa Madre como primer interlocutor
            cInterlocutor.addItem(e.getCod_empresa() + "   [(" + e.getDesc_empresa() + ")]");
            while (iter.hasNext()) {
                interl = iter.next();
                emp = BaseDatos.obtenerEmpresaPorIid(interl.getEmpresaHija().getIid());
                if (interl.getEmpresaHija() != null) {
                    cInterlocutor.addItem(emp.getCod_empresa() + "   [(" + emp.getDesc_empresa() + ")]");
                }
            }
        }
    }

    public String obtenerFormula(FamiliaVenta fv) {
        String formula = "";
        if (listaFormulas != null && !listaFormulas.isEmpty()) {
            Iterator<InterlocutorFamiliaVenta> iF = listaFormulas.iterator();
            InterlocutorFamiliaVenta ifv;
            while (iF.hasNext()) {
                ifv = iF.next();
                if (fv.getIid().equals(ifv.getFamiliaVenta().getIid())) {
                    formula = ifv.getFormula();
                    break;
                }
            }
        }
        return formula;
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bAcompra;
    private javax.swing.JButton bAventa;
    private javax.swing.JButton bConfig;
    private javax.swing.JButton bProv;
    private javax.swing.JButton bborrar;
    private javax.swing.JButton bcerrar;
    private javax.swing.JButton bcrear;
    private javax.swing.JButton bvisualizar;
    private javax.swing.JComboBox cInterlocutor;
    private javax.swing.ButtonGroup gBusqueda;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JRadioButton rCodigo;
    private javax.swing.JRadioButton rDes;
    private javax.swing.JRadioButton rFamilia;
    private javax.swing.JTable tarticulos1;
    private javax.swing.JTextField tbusqueda1;
    private javax.swing.JTable tcaracteristicas;
    // End of variables declaration//GEN-END:variables
}
