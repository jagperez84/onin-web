package gui;

import acceso.BaseDatos;
import bean.AgenteArticulo;
import bean.AgenteArticuloCodigo;
import bean.Agentes;
import bean.Almacen;
import bean.Articulo;
import bean.Precios;
import bean.ArticuloDescuento;
import bean.Escalado;
import bean.Interlocutor;
import bean.Caracteristica;
import bean.Colores;
import bean.DescuentoClienteArticulo;
import bean.DescuentoClienteFamiliaVenta;
import bean.Empresa;
import bean.Existencia;
import bean.FamiliaVenta;
import bean.FormulaArticuloProv;
import bean.FormulaFamiliaProv;
import bean.InterlocutorFamiliaVenta;
import bean.Iva;
import bean.Metadata;
import bean.Moneda;
import bean.MovimientoAlmacen;
import bean.TipoControl;
import bean.TipoMedida;
import bean.TipoMovimientoAlmacen;
import bean.TipoToldo;
import bean.UnidadMedida;
import bean.Usuario;
import bean.colorFamilia;
import bean.precioFamilia;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.io.File;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.KeyStroke;
import jxl.Sheet;
import jxl.Workbook;
import matematico.Matematico;
import modelo.Modelo;
import util.Constantes;
import util.Util;

public class NuevoArticulo extends javax.swing.JFrame {
    private boolean crear;
    private Empresa e;
    private Articulo ar;
    private Usuario u;
    private int numMedidas;
    private boolean hayCaracteristicas;
    private boolean actualizarMovExistencias;
    private String codigoAntiguo;
    private List<Caracteristica> listaCaracteristicas;
    private List<Escalado> listaEscalados;
    private List<MovimientoAlmacen> listaMovimientos;
    private List<MovimientoAlmacen> listaMovimientosBorrados;
    private List<MovimientoAlmacen> listaMovimientosCreados;
    private List<Existencia> listaExistencias;
    private List<ArticuloDescuento> lArticuloDescuentos;
    private List<AgenteArticulo> lAgenteArticulo;
    private List<AgenteArticuloCodigo> lAgenteArticuloCodigo;
    private FamiliaVenta fv;
    private TipoControl tc;
    private TipoMedida tm;
    private UnidadMedida um;
    private Interlocutor inter;
    private boolean modInter = false;
    private String formula;
    private List listaFormulas;
    private Precios precioAnt;
    private List listaPrecios = new ArrayList();
    private List listaPreciosIns = new ArrayList();
    private float pt = 0.0F;
    private Agentes prov = new Agentes();

    public NuevoArticulo(Empresa e, String titulo, Usuario u) {
        super(titulo);
        crear = true;
        this.e = e;
        this.u = u;

        precioAnt = null;
        numMedidas = 0;
        listaCaracteristicas = new ArrayList<Caracteristica>();
        listaEscalados = new ArrayList<Escalado>();
        listaMovimientos = new ArrayList<MovimientoAlmacen>();
        listaMovimientosBorrados = new ArrayList<MovimientoAlmacen>();
        listaMovimientosCreados = new ArrayList<MovimientoAlmacen>();
        listaExistencias = new ArrayList<Existencia>();
        lArticuloDescuentos = new ArrayList<ArticuloDescuento>();
        lAgenteArticulo = new ArrayList<AgenteArticulo>();
        lAgenteArticuloCodigo = new ArrayList<AgenteArticuloCodigo>();
        
        ar = new Articulo();
        ar.setPrecio_v(0.0F);
        ar.setPrecioIncremento(0.0F);
        ar.setPtc(0.0F);
        ar.setUpc(0.0F);
        
        initComponents();
        
        bcancelar.setToolTipText("Cancelar la creación del artículo");
        baceptar.setToolTipText("Realizar la modificación");
        bmodificar.setEnabled(false);
        ttipoControl.setEnabled(false);
        tExpliC.setEnabled(false);
        tFormulaC.setEnabled(false);
        cbEscaladoCaracteristica.setEnabled(false);
        bEscaladosCarFichero.setEnabled(false);
        bEscaladosFichero.setEnabled(false);
        cbEscaladoArticulo.setEnabled(true);
        tEscaladoArticulo.setEnabled(true);
        bCrearEscaladoArticulo.setEnabled(true);
        bBorrarEscaladoArticulo.setEnabled(true);
        hayCaracteristicas = false;
        actualizarMovExistencias = false;
        pExistencias.setVisible(false);
        tRestoMinimo.setEnabled(false);
        cbCorteLiso.setEnabled(false);
        bConfig.setEnabled(false);

        Metadata mdtIva = (Metadata) BaseDatos.obtenerMetadaPorNombre("ivaDocumento", e.getIid());
        Iva iva = BaseDatos.obtenerIvaPorPorcentaje(mdtIva.getValor());
        cIva.setSelectedItem(iva.getPorcentaje() + "%");
        //Inicializamos los precios

        crearIconosBotones();
        crearAcciones();
    }

    public NuevoArticulo(Empresa e, Articulo ar, String titulo, Usuario u, Interlocutor inter) {
        super(titulo);
        crear = false;
        this.ar = ar;
        this.e = e;
        this.u = u;

        fv = BaseDatos.obtenerFamiliaVentaPorIid(ar.getIid_fam_venta().getIid());
        tc = BaseDatos.obtenerTipoControlPorIid(fv.getIid_tipo_control().getIid());
        tm = BaseDatos.obtenerTipoMedidaByIid(tc.getIid_tipo_medida().getIid());
        um = BaseDatos.obtenerUnidadMedidaIid(tc.getUnidadResultado().getIid());

        if (inter != null) {
            modInter = true;
            this.inter = inter;
            listaFormulas = BaseDatos.obtenerInterFormulas(inter);
            formula = this.obtenerFormula(fv);
        }

        //Obtener precio activo para artículo sin car        
        precioAnt = BaseDatos.obtenerPrecioActivo(e, ar, 0);

        ScriptEngineManager manager = new ScriptEngineManager();
        ScriptEngine engine = manager.getEngineByName("js");

        numMedidas = numMedidas();
        listaCaracteristicas = BaseDatos.getListaCaracteristicas(e, ar);

        if (listaCaracteristicas != null && listaCaracteristicas.size() > 0) {
            //Calculamos la lista de precios
            Iterator<Caracteristica> ilc = listaCaracteristicas.iterator();
			Precios p;
			while (ilc.hasNext()) {
                p = BaseDatos.obtenerPrecioActivo(e, ar, ilc.next().getIid_color().getIid());
                listaPrecios.add(p);
            }
        }

        listaEscalados = BaseDatos.getListaEscalados(ar.getIid());
        listaExistencias = BaseDatos.getListaExistencias(ar);
        listaMovimientos = BaseDatos.getListaMovimientosAlmacenFiltrados(ar, e);
        listaMovimientosBorrados = new ArrayList<MovimientoAlmacen>();
        listaMovimientosCreados = new ArrayList<MovimientoAlmacen>();
        lArticuloDescuentos = BaseDatos.getListaArticuloDescuentoPorArticulo(ar.getIid());
        lAgenteArticulo = BaseDatos.getListaAgenteArticulo(e, ar);
        lAgenteArticuloCodigo = BaseDatos.getListaAgenteArticuloCodigo(ar.getIid());
        initComponents();

        tExpliC.setEnabled(false);
        tFormulaC.setEnabled(false);

        //Obtener precio activo
        //Cargamos modo interlocutor  con fórmula
        if (modInter) {
            //Desactivamos la edición de los campos de precio
            tprecio.setEnabled(false);
            tprecioIncremento.setEnabled(false);
            tupc.setEnabled(false);
            tptc.setEnabled(false);
            if (formula != null && !formula.equals("")) {
                tFormulaC.setText(formula);
            } else {
                tFormulaC.setText("Sin fórmula definida");
                modInter = false;
            }
        } else {
            tExpliC.setText("Empresa Madre");
            tFormulaC.setText("No aplica fórmula");
        }

        bAa.setEnabled(true);
        bAc.setEnabled(true);
        tcodigo.setText(ar.getCod_articulo());
        tdesctect.setText(ar.getDes_tecnica());
        tdescinf.setText(ar.getDes_inf());
        bactualizarstock.setSelected(ar.getAct_stock());
        bstockneg.setSelected(ar.getStock_neg());
        bstockmedida.setSelected(ar.getStock_med());
        bstockcolor.setSelected(ar.getStock_col());
        cbEscaladoArticulo.setSelected(ar.getEscalado());
        cbEscaladoCaracteristica.setSelected(ar.getEscaladoCaracteristica());

        if (ar.getMonocromo() != null && ar.getMonocromo()) {
            bMonocromo.setSelected(true);
        } else {
            bMonocromo.setSelected(false);
        }
        if (!modInter) {
            if (ar.getIva() != null) {
                Iva iva = BaseDatos.obtenerIvaPorIid(ar.getIva().getIid());
                cIva.setSelectedItem(iva.getPorcentaje() + "%");
            }
        } else {
            cIva.setSelectedItem(this.calcularIvaInterlocutor().toString() + "%");
        }

        if (!ar.getEscalado()) {
            bEscaladosFichero.setEnabled(false);
        } else {
            bEscaladosFichero.setEnabled(true);
        }

        if (!ar.getEscaladoCaracteristica()) {
            bEscaladosCarFichero.setEnabled(false);
        } else {
            bEscaladosCarFichero.setEnabled(true);
        }

        if (!modInter) {
            if (ar.getDescuento() != null) {
                tdescuento.setText(Util.convertirPuntoAComa(String.valueOf(ar.getDescuento())));
            }
        } else {
            Double desI = this.descuentoInterlocutor(ar);
            if (desI != null) {
                tdescuento.setText(Util.convertirPuntoAComa(String.valueOf(desI)));
            }
        }
        try {
            if (precioAnt != null && precioAnt.getPvp() != null) {
                if (!modInter) {
                    tprecio.setText(Util.convertirPuntoAComa(String.valueOf(precioAnt.getPvp())));
                } else {
                    String formulaP = formula.replace("pvp", precioAnt.getPvp().toString());
                    Float fPvp = (Float) Float.parseFloat(engine.eval(formulaP).toString());
                    fPvp = Matematico.redondear2decimales(fPvp);
                    tprecio.setText(Util.convertirPuntoAComa(String.valueOf(fPvp)));

                }
            }

            if (precioAnt != null && precioAnt.getPi() != null) {
                tprecioIncremento.setText(Util.convertirPuntoAComa(String.valueOf(precioAnt.getPi())));
                if (!modInter) {
                    tprecioIncremento.setText(Util.convertirPuntoAComa(String.valueOf(precioAnt.getPi())));
                } else {
                    String formulaP = formula.replace("pvp", precioAnt.getPi().toString());
                    Float fInc = (Float) Float.parseFloat(engine.eval(formulaP).toString());
                    tprecioIncremento.setText(Util.convertirPuntoAComa(String.valueOf(fInc)));
                }
            }

            //Obtener pmc
            Double pmc = BaseDatos.getPMP(ar.getIid(), 0, e.getIid()); //Sin caracteristica
            if (pmc != null) {
                tpmc.setText(Util.convertirPuntoAComa(String.valueOf(pmc)));
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        if (precioAnt != null && precioAnt.getUpc() != null) {
            if (!modInter) {
                tupc.setText(Util.convertirPuntoAComa(String.valueOf(precioAnt.getUpc())));
            } else {
                tupc.setText(Util.convertirPuntoAComa(String.valueOf(precioAnt.getPvp())));
            }
        }
        if (precioAnt != null && precioAnt.getPtc() != null) {
            if (!modInter) {
                tptc.setText(Util.convertirPuntoAComa(String.valueOf(precioAnt.getPtc())));
            } else {
                tptc.setText(Util.convertirPuntoAComa(String.valueOf(precioAnt.getPvp())));
            }
        }

        if (precioAnt != null && precioAnt.getFecha() != null) {
            Date fechaAnt = new Date(precioAnt.getFecha());
            SimpleDateFormat formatoFecha = new SimpleDateFormat("dd/MM/yyyy");
            tfc.setText(formatoFecha.format(fechaAnt));

        }
        tobservaciones.setText(ar.getObservaciones());
        if (ar.getProv_hab() != null) {
            cproveedorh.setSelectedItem(BaseDatos.obtenerAgenteByIid(ar.getProv_hab().getIid()).getNombre_comercial());
        }

        ttipoControl.setText((String) tc.getNombre());

        if (ar.getRestoMinimo() != null) {
            tRestoMinimo.setText(util.Util.convertirPuntoAComa(ar.getRestoMinimo().toString()));
        }

        if (ar.getCorteLiso() != null && ar.getCorteLiso()) {
            cbCorteLiso.setSelected(true);
        } else {
            cbCorteLiso.setSelected(false);
        }

        if (ar.getStockMinimo() != null) {
            tStockMinimo.setText(ar.getStockMinimo().toString());
        }

        ttipoControl.setEnabled(false);
        tcodigo.setEnabled(false);
        tdesctect.setEnabled(false);
        tdescinf.setEnabled(false);
        cfamiliav.setEnabled(false);
        cunidadm.setEnabled(false);
        tprecio.setEnabled(false);
        tprecioIncremento.setEnabled(false);
        tdescuento.setEnabled(false);
        cIva.setEnabled(false);
        cAlmacen.setEnabled(false);
        tobservaciones.setEnabled(false);
        bactualizarstock.setEnabled(false);
        bstockneg.setEnabled(false);
        bstockmedida.setEnabled(false);
        bstockcolor.setEnabled(false);
        cproveedorh.setEnabled(false);
        cmoneda.setEnabled(false);
        tptc.setEnabled(false);
        tupc.setEnabled(false);
        cbEscaladoArticulo.setEnabled(false);
        cbEscaladoCaracteristica.setEnabled(false);
        bEscaladosCarFichero.setEnabled(false);
        bEscaladosFichero.setEnabled(false);
        bcancelar.setToolTipText("Cancelar la creación");
        baceptar.setToolTipText("Realizar la modificación");
        bmodificar.setText("Modificar");
        bmodificar.setToolTipText("Modificar campos");
        bCrearInventario.setEnabled(false);
        tExistencias.setEnabled(false);
        bNuevaCaracteristica.setEnabled(false);
        bEliminarCaracteristica.setEnabled(false);
        tEscaladoArticulo.setEnabled(false);
        bCrearEscaladoArticulo.setEnabled(false);
        bBorrarEscaladoArticulo.setEnabled(false);
        bModificarCaracteristica.setEnabled(false);
        bBorrarMovimiento.setEnabled(false);
        tMovimientos.setEnabled(false);
        tagentearticulocodigo1.setEnabled(false);
        bNuevoAA.setEnabled(false);
        bEliminarAA.setEnabled(false);
        bModificarAA.setEnabled(false);
        tcaracteristicas.setEnabled(false);
        bNuevaCaracteristica.setEnabled(false);
        bEliminarCaracteristica.setEnabled(false);
        bModificarCaracteristica.setEnabled(false);
        tEscaladoCaracteristicas.setEnabled(false);
        bNuevoEscaladoCaracteristica.setEnabled(false);
        bEliminarEscaladoCaracteristica.setEnabled(false);
        List laux = BaseDatos.getListaCaracteristicas(e, ar);
        hayCaracteristicas = laux != null && laux.size() > 0;
        actualizarMovExistencias = false;
        bEscaladosCarFichero.setEnabled(false);
        bEscaladosFichero.setEnabled(false);
        tRestoMinimo.setEnabled(false);
        cbCorteLiso.setEnabled(false);
        tStockMinimo.setEnabled(false);
        bMonocromo.setEnabled(false);
        codigoAntiguo = ar.getCod_articulo();
        crearIconosBotones();
        crearAcciones();
    }

    List<AgenteArticuloCodigo> busquedaRapidaAgenteArticuloCodigoPorAgente(String proveedor) {
        List<AgenteArticuloCodigo> lres = new ArrayList<AgenteArticuloCodigo>();
        Iterator<AgenteArticuloCodigo> iter = lAgenteArticuloCodigo.iterator();
        AgenteArticuloCodigo temp;
        Agentes aTemp;
        while (iter.hasNext()) {
            temp = iter.next();
            aTemp = BaseDatos.obtenerAgenteByIid(temp.getIid_agente().getIid());
            if (aTemp.getNombre_comercial().toLowerCase().contains(proveedor.toLowerCase())) {
                lres.add(temp);
            }
        }
        return lres;
    }

    List<AgenteArticuloCodigo> busquedaRapidaAgenteArticuloCodigoPorCodigo(String codigo) {
        List<AgenteArticuloCodigo> lres = new ArrayList<AgenteArticuloCodigo>();
        Iterator<AgenteArticuloCodigo> iter = lAgenteArticuloCodigo.iterator();
        AgenteArticuloCodigo temp;
        while (iter.hasNext()) {
            temp = iter.next();
            if (temp.getCodigo().toLowerCase().contains(codigo.toLowerCase())) {
                lres.add(temp);
            }
        }
        return lres;
    }

    List<AgenteArticulo> busquedaRapidaAgenteArticuloPorAgente(String agente) {
        List<AgenteArticulo> lres = new ArrayList<AgenteArticulo>();
        Iterator<AgenteArticulo> iter = lAgenteArticulo.iterator();
        AgenteArticulo temp;
        Agentes aTemp;
        while (iter.hasNext()) {
            temp = iter.next();
            aTemp = BaseDatos.obtenerAgenteByIid(temp.getIid_agente().getIid());
            if (aTemp.getNombre_comercial().toLowerCase().contains(agente.toLowerCase())) {
                lres.add(temp);
            }
        }
        return lres;
    }

    List<AgenteArticulo> busquedaRapidaAgenteArticuloPorCaracteristica(String colorCaracteristica) {
        List<AgenteArticulo> lres = new ArrayList<AgenteArticulo>();
        Iterator<AgenteArticulo> iter = lAgenteArticulo.iterator();
        AgenteArticulo temp;
        Colores cTemp;
        while (iter.hasNext()) {
            temp = iter.next();
            cTemp = temp.getIid_caracteristica().getIid_color();
            if (cTemp.getDescripcion().toLowerCase().contains(colorCaracteristica.toLowerCase())) {
                lres.add(temp);
            }
        }
        return lres;
    }

    boolean eliminarAgenteArticuloCodigo(String proveedor) {
        boolean res = true, seguir = true;
        Iterator<AgenteArticuloCodigo> iter = lAgenteArticuloCodigo.iterator();
        Agentes aTemp;
        int pos = 0;
        while (iter.hasNext() && seguir) {
            aTemp = iter.next().getIid_agente();
            if (aTemp.getNombre_comercial().equalsIgnoreCase(proveedor)) {
                seguir = false;
            } else {
                pos++;
            }
        }

        if (seguir) {
            res = false;
        } else {
            lAgenteArticuloCodigo.remove(pos);
        }
        return res;
    }

    AgenteArticuloCodigo obtenerAgenteArticuloCodigo(String proveedor, Integer color) {
        AgenteArticuloCodigo temp, aac, res = null;
        Integer c;
        Boolean seguir = true;
        Iterator<AgenteArticuloCodigo> iter = lAgenteArticuloCodigo.iterator();
        int pos = 0;
        
        while (iter.hasNext() && seguir) {
            temp = iter.next();
            if ((temp.getIid_agente().getNombre_comercial().equalsIgnoreCase(proveedor)) && (temp.getIid_color().equals(color))) {
                seguir = false;
            } else {
                pos++;
            }
        }

        if (!seguir) {
            aac = lAgenteArticuloCodigo.get(pos);
            res = new AgenteArticuloCodigo();
            res.setCheckDto(aac.getCheckDto());
            res.setCodigo(aac.getCodigo());
            res.setDescripcion(aac.getDescripcion());
            res.setDescuento(aac.getDescuento());
            res.setIid(aac.getIid());
            res.setIid_agente(aac.getIid_agente());
            res.setIid_articulo(aac.getIid_articulo());
            res.setPrecio(aac.getPrecio());
            res.setTipoPrecio(aac.getTipoPrecio());
            res.setIid_color(aac.getIid_color());
        }
        return res;
    }

    private void borrarCaracteristica() {
        try {
            int indice = tcaracteristicas.getSelectedRow();
            if (indice >= 0) {
                int eliminar = 1;
                eliminar = JOptionPane.showConfirmDialog(null, "Está seguro de que desea eliminar el elemento seleccionado?", "¿Eliminar?", JOptionPane.YES_NO_OPTION);
                //hacerCambios = -1 ==> se ha pulsado la "x" de cancelar;
                //hacerCambios =  0 ==> se ha pulsado el "sí"
                //hacerCambios =  1 ==> se ha pulsado el "no"

                if (eliminar == 0) {
                    String color = (String) tcaracteristicas.getModel().getValueAt(indice, 0);
                    Colores c = BaseDatos.obtenerColor(color);
                    Caracteristica car = obtenerCaracteristica(c);
                    int indiceCaracteristica = obtenerIndiceCaracteristica(c);
                    listaCaracteristicas.remove(indiceCaracteristica);
                    actualizarCaracteristicas(listaPrecios);
                    borrarEscaladosCaracteristicas(car);
                    vaciarEscaladosCaracteristicas();
                    borrarMovimientosCaracteristicas(car);
                    borrarExistenciasCaracteristicas(car);
                    actualizarMovimientos(listaMovimientos);
                    actualizarExistencias(listaExistencias);
                    hayCaracteristicas = (listaCaracteristicas != null && listaCaracteristicas.size() > 0);
                    if (!hayCaracteristicas) {
                        listaEscalados = new ArrayList();
                        actualizarEscaladosArticulos();
                        cbEscaladoArticulo.setSelected(cbEscaladoCaracteristica.isSelected());
                        cbEscaladoArticulo.setEnabled(true);
                        cbEscaladoArticulo.setEnabled(true);
                        pEscaladoArticulo.setEnabled(cbEscaladoCaracteristica.isSelected());
                        bEscaladosFichero.setEnabled(true);
                        bEscaladosFichero.setEnabled(bEscaladosCarFichero.isVisible());
                        cbEscaladoCaracteristica.setSelected(false);
                        cbEscaladoCaracteristica.setEnabled(false);
                        cbEscaladoCaracteristica.setEnabled(false);
                        bEscaladosCarFichero.setEnabled(false);
                        bEscaladosCarFichero.setEnabled(false);
                        pEscaladoArticulo.setEnabled(false);
                    }
                }
            } else {
                JOptionPane.showMessageDialog(null, "No hay seleccionado ningún elemento", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Este elemento no se puede eliminar", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void borrarEscalado() {
        int indice = tEscaladoCaracteristicas.getSelectedRow();
        if (indice >= 0) {
            int eliminar = 1;
            eliminar = JOptionPane.showConfirmDialog(null, "Está seguro de que desea eliminar el elemento seleccionado?", "¿Eliminar?", JOptionPane.YES_NO_OPTION);
            //hacerCambios = -1 ==> se ha pulsado la "x" de cancelar;
            //hacerCambios =  0 ==> se ha pulsado el "sí"
            //hacerCambios =  1 ==> se ha pulsado el "no"

            if (eliminar == 0) {
                String color = (String) tEscaladoCaracteristicas.getModel().getValueAt(indice, 0);
                Colores c = BaseDatos.obtenerColor(color);
                Caracteristica car = obtenerCaracteristica(c);
                Integer dim1 = (Integer) tEscaladoCaracteristicas.getModel().getValueAt(indice, 1);
                Integer dim2 = (Integer) tEscaladoCaracteristicas.getModel().getValueAt(indice, 2);

                int posEscalado = this.obtenerPosicionEscaladoCaracteristica(dim1, dim2, car);
                if (posEscalado > -1) {
                    listaEscalados.remove(posEscalado);
                    actualizarEscaladosCaracteristicas(car);
                }
            }
        } else {
            JOptionPane.showMessageDialog(null, "No hay seleccionado ningún elemento", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void borrarEscaladoArticulo() {
        int indice = tEscaladoArticulo.getSelectedRow();
        if (indice >= 0) {

            int eliminar = 1;
            eliminar = JOptionPane.showConfirmDialog(null, "Está seguro de que desea eliminar el elemento seleccionado?", "¿Eliminar?", JOptionPane.YES_NO_OPTION);
            //hacerCambios = -1 ==> se ha pulsado la "x" de cancelar;
            //hacerCambios =  0 ==> se ha pulsado el "sí"
            //hacerCambios =  1 ==> se ha pulsado el "no"

            if (eliminar == 0) {
                Integer dim1 = (Integer) tEscaladoArticulo.getModel().getValueAt(indice, 0);
                Integer dim2 = (Integer) tEscaladoArticulo.getModel().getValueAt(indice, 1);

                int posEscalado = obtenerPosicionEscaladoArticulo(dim1, dim2);
                if (posEscalado > -1) {
                    listaEscalados.remove(posEscalado);
                    actualizarEscaladosArticulos();
                }
            }
        } else {
            JOptionPane.showMessageDialog(null, "No hay seleccionado ningún elemento", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void borrarMovimiento() {
        try {
            int indice = tMovimientos.getSelectedRow();
            if (indice >= 0) {

                int eliminar = 1;
                eliminar = JOptionPane.showConfirmDialog(null, "Está seguro de que desea eliminar el elemento seleccionado?", "¿Eliminar?", JOptionPane.YES_NO_OPTION);
                //hacerCambios = -1 ==> se ha pulsado la "x" de cancelar;
                //hacerCambios =  0 ==> se ha pulsado el "sí"
                //hacerCambios =  1 ==> se ha pulsado el "no"

                if (eliminar == 0) {
                    String concepto = (String) tMovimientos.getModel().getValueAt(indice, 0);
                    Almacen almacen = BaseDatos.obtenerAlmacen((String) tMovimientos.getModel().getValueAt(indice, 1));
                    String fechaStr = (String) tMovimientos.getModel().getValueAt(indice, 2);
                    String color = (String) tMovimientos.getModel().getValueAt(indice, 3);
                    Caracteristica car = null;
                    if (!color.equals("--")) {
                        car = obtenerCaracteristica(BaseDatos.obtenerColor(color));
                    }

                    TipoMovimientoAlmacen tma = BaseDatos.obtenerTipoMovimientoAlmacen((String) tMovimientos.getModel().getValueAt(indice, 4));

                    Float medida1 = null;
                    Float medida2 = null;
                    Float medida3 = null;
                    Float medida4 = null;
                    Float medida5 = null;

                    if (numMedidas() == 1) {
                        medida1 = new Float(Util.convertirComaAPunto((String) tMovimientos.getModel().getValueAt(indice, 6)));
                    } else if (numMedidas() == 2) {
                        medida1 = new Float(Util.convertirComaAPunto((String) tMovimientos.getModel().getValueAt(indice, 6)));
                        medida2 = new Float(Util.convertirComaAPunto((String) tMovimientos.getModel().getValueAt(indice, 7)));
                    } else if (numMedidas() == 3) {
                        medida1 = new Float(Util.convertirComaAPunto((String) tMovimientos.getModel().getValueAt(indice, 6)));
                        medida2 = new Float(Util.convertirComaAPunto((String) tMovimientos.getModel().getValueAt(indice, 7)));
                        medida3 = new Float(Util.convertirComaAPunto((String) tMovimientos.getModel().getValueAt(indice, 8)));
                    } else if (numMedidas() == 4) {
                        medida1 = new Float(Util.convertirComaAPunto((String) tMovimientos.getModel().getValueAt(indice, 6)));
                        medida2 = new Float(Util.convertirComaAPunto((String) tMovimientos.getModel().getValueAt(indice, 7)));
                        medida3 = new Float(Util.convertirComaAPunto((String) tMovimientos.getModel().getValueAt(indice, 8)));
                        medida4 = new Float(Util.convertirComaAPunto((String) tMovimientos.getModel().getValueAt(indice, 9)));
                    } else if (numMedidas() == 5) {
                        medida1 = new Float(Util.convertirComaAPunto((String) tMovimientos.getModel().getValueAt(indice, 6)));
                        medida2 = new Float(Util.convertirComaAPunto((String) tMovimientos.getModel().getValueAt(indice, 7)));
                        medida3 = new Float(Util.convertirComaAPunto((String) tMovimientos.getModel().getValueAt(indice, 8)));
                        medida4 = new Float(Util.convertirComaAPunto((String) tMovimientos.getModel().getValueAt(indice, 9)));
                        medida5 = new Float(Util.convertirComaAPunto((String) tMovimientos.getModel().getValueAt(indice, 10)));
                    }

                    MovimientoAlmacen mva = new MovimientoAlmacen();
                    SimpleDateFormat formatoFecha = new SimpleDateFormat("dd/MM/yyyy");
                    Long fecha = formatoFecha.parse(fechaStr).getTime();

                    mva.setAlmacen(almacen);
                    mva.setConcepto(concepto);
                    mva.setFecha(fecha);
                    mva.setCaracteristica(car);
                    mva.setTipoMovimiento(tma);
                    mva.setCantidad1(medida1);
                    mva.setCantidad2(medida2);
                    mva.setCantidad3(medida3);
                    mva.setCantidad4(medida4);
                    mva.setCantidad5(medida5);
                    mva.setArticulo(ar);

                    int indiceMovimiento = obtenerIndiceMovimiento(mva);
                    mva = listaMovimientos.get(indiceMovimiento);
                    int indiceExistencia = obtenerIndiceExistencia(mva);
                    Existencia ex = listaExistencias.get(indiceExistencia);
                    ex.setExistencia(ex.getExistencia() - mva.getCantidad());

                    if (ex.getExistencia() == 0) {
                        listaExistencias.remove(indiceExistencia);
                    }

                    listaMovimientos.remove(indiceMovimiento);
                    listaMovimientosBorrados.add(mva);

                    actualizarExistencias(listaExistencias);
                    actualizarMovimientos(listaMovimientos);
                }
            } else {
                JOptionPane.showMessageDialog(null, "No hay seleccionado ningún elemento", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Este elemento no se puede eliminar", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void crearAcciones() {
        KeyStroke escapeKeyStroke = KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false);
        Action escapeAction = new AbstractAction() {
            public void actionPerformed(ActionEvent e) {
                BaseDatos.desUsarArticulo(ar.getIid());
                cerrarArticulo();
            }
        };
        getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(escapeKeyStroke, "ESCAPE");
        getRootPane().getActionMap().put("ESCAPE", escapeAction);

        Dimension dim = Util.getDimensiones(this.getSize());
        if (dim != null) {
            setResizable(true);
            setSize(dim);
        }
    }

    public boolean eliminarAgenteArticulo(String color, String agente) {
        boolean res = true, seguir = true;
        Iterator<AgenteArticulo> iter = lAgenteArticulo.iterator();
        AgenteArticulo temp;
        int pos = 0;
        Caracteristica c;
		
        while (iter.hasNext() && seguir) {
            temp = iter.next();
            c = BaseDatos.obtenerCaracteristicaPorIid(temp.getIid_caracteristica().getIid());
            if (c.getIid_color().getDescripcion().equalsIgnoreCase(color) && temp.getIid_agente().getNombre_comercial().equalsIgnoreCase(agente)) {
                seguir = false;
            } else {
                pos++;
            }
        }

        if (seguir) {
            res = false;
        } else {
            lAgenteArticulo.remove(pos);
        }
        return res;
    }

    public boolean insertarAgenteArticulo(AgenteArticulo aa) {
        boolean res = true;
        Colores col = aa.getIid_caracteristica().getIid_color();
        Agentes a = aa.getIid_agente();
        Iterator<AgenteArticulo> iter = lAgenteArticulo.iterator();
        AgenteArticulo temp;

        while (iter.hasNext() && res) {
            temp = iter.next();
            if (temp.getIid_caracteristica().getIid_color().getCod_color().equalsIgnoreCase(col.getCod_color()) && temp.getIid_agente().getCod_agente().equalsIgnoreCase(a.getCod_agente())) {
                res = false;
            }
        }

        if (!res) {
            JOptionPane.showMessageDialog(null, "Ya hay un elemento con la característica y proveedor seleccionados", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            lAgenteArticulo.add(aa);
        }

        return res;
    }

    public boolean insertarAgenteArticuloCodigo(AgenteArticuloCodigo aac) {
        boolean res = true;
        Agentes a = aac.getIid_agente();
        Integer c = aac.getIid_color();
        Iterator<AgenteArticuloCodigo> iter = lAgenteArticuloCodigo.iterator();
        AgenteArticuloCodigo temp;

        while (iter.hasNext() && res) {
            temp = iter.next();
            if (temp.getIid_agente().getCod_agente().equalsIgnoreCase(a.getCod_agente()) && c == temp.getIid_color()) {
                res = false;
            }
        }

        if (!res) {
            JOptionPane.showMessageDialog(null, "Ya hay un elemento con el proveedor seleccionado", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            lAgenteArticuloCodigo.add(aac);
            this.actualizarAgenteArticuloCodigo1(lAgenteArticuloCodigo);
        }

        return res;
    }

    public AgenteArticulo obtenerAgenteArticulo(String color, String agente) {
        AgenteArticulo temp, aa, res = null;
        boolean seguir = true;
        Iterator<AgenteArticulo> iter = lAgenteArticulo.iterator();
        int pos = 0;

        while (iter.hasNext() && seguir) {
            temp = iter.next();
            if (temp.getIid_caracteristica().getIid_color().getDescripcion().equalsIgnoreCase(color) && temp.getIid_agente().getNombre_comercial().equalsIgnoreCase(agente)) {
                seguir = false;
            } else {
                pos++;
            }
        }

        if (!seguir) {
            aa = lAgenteArticulo.get(pos);
            res = new AgenteArticulo();
            res.setIid(aa.getIid());
            res.setIid_agente(aa.getIid_agente());
            res.setIid_articulo(aa.getIid_articulo());
            res.setIid_caracteristica(aa.getIid_caracteristica());
            res.setIid_empresa(aa.getIid_empresa());
            res.setPlazo_entrega(aa.getPlazo_entrega());
            res.setPrecio(aa.getPrecio());
            res.setReferencia(aa.getReferencia());
        }
        return res;
    }

    public boolean modificarAgenteArticulo(AgenteArticulo aa, String caracteristicaAntigua, String agenteAntiguo) {
        boolean res = true, cambiadoColorOAgente = true;
        int numCoincidenciasColorAgente = 0, pos = 0, primeraPos = -1;
        AgenteArticulo temp;
        Colores colTemp;
        Agentes aTemp;
        Iterator<AgenteArticulo> iter = lAgenteArticulo.iterator();
        Colores c = BaseDatos.obtenerColorPorIid(aa.getIid_caracteristica().getIid());
        Agentes a = BaseDatos.obtenerAgenteByIid(aa.getIid_agente().getIid());
		
        if (c.getDescripcion().equals(caracteristicaAntigua) && a.getNombre_comercial().equalsIgnoreCase(agenteAntiguo)) {
            cambiadoColorOAgente = false;
        }
        
        while (iter.hasNext()) {
            temp = iter.next();
            colTemp = BaseDatos.obtenerCaracteristicaPorIid(temp.getIid_caracteristica().getIid()).getIid_color();
            aTemp = temp.getIid_agente();

            if (colTemp.getDescripcion().equalsIgnoreCase(caracteristicaAntigua) && aTemp.getNombre_comercial().equalsIgnoreCase(agenteAntiguo)) {
                if (primeraPos < 0) {
                    primeraPos = pos;
                }
            }

            if (colTemp.getDescripcion().equalsIgnoreCase(c.getDescripcion()) && aTemp.getNombre_comercial().equalsIgnoreCase(a.getNombre_comercial())) {
                numCoincidenciasColorAgente++;
            }

            pos++;
        }

        if (numCoincidenciasColorAgente > 0 && cambiadoColorOAgente) {
            //Ya existe el elemento
            JOptionPane.showMessageDialog(null, "Ya hay un elemento con la característica y proveedor seleccionados", "Error", JOptionPane.ERROR_MESSAGE);
            res = false;
        } else {
            lAgenteArticulo.remove(primeraPos);
            lAgenteArticulo.add(primeraPos, aa);
            completarPantalla();
            // Si el proveedor es principal, recalculamos precios            
            prov = BaseDatos.obtenerProveedorNombreComercial((String) cproveedorh.getSelectedItem(), e);
            // Si se ha cambiado el proveedor, volvemos a calcular
            if (prov.getIid().equals(aa.getIid_agente().getIid())) {
                calPreciosProv();
            }
        }
        return res;
    }

    public boolean modificarAgenteArticuloCodigo(AgenteArticuloCodigo aac, String agenteAntiguo) {
        boolean res = true, cambiadoAgente = true;
        int primeraPos = -1, pos = 0, numCoincidenciasAgente = 0;
        Agentes aTemp;
        Iterator<AgenteArticuloCodigo> iter = lAgenteArticuloCodigo.iterator();
        Agentes a = BaseDatos.obtenerAgenteByIid(aac.getIid_agente().getIid());

        if (a.getNombre_comercial().equalsIgnoreCase(agenteAntiguo)) {
            cambiadoAgente = false;
        }

        while (iter.hasNext()) {
            aTemp = iter.next().getIid_agente();
            if (aTemp.getNombre_comercial().equalsIgnoreCase(agenteAntiguo)) {
                if (primeraPos < 0) {
                    primeraPos = pos;
                }
            }

            if (aTemp.getNombre_comercial().equalsIgnoreCase(a.getNombre_comercial())) {
                numCoincidenciasAgente++;
            }

            pos++;
        }

        if (numCoincidenciasAgente > 0 && cambiadoAgente) {
            JOptionPane.showMessageDialog(null, "Ya hay un elemento con el proveedor seleccionado", "Error", JOptionPane.ERROR_MESSAGE);
            res = false;
        } else {
            lAgenteArticuloCodigo.remove(primeraPos);
            lAgenteArticuloCodigo.add(primeraPos, aac);
            completarPantalla();
            // Si el proveedor es principal, recalculamos precios            
            prov = BaseDatos.obtenerProveedorNombreComercial((String) cproveedorh.getSelectedItem(), e);
            // Si se ha cambiado el proveedor, volvemos a calcular
            if (prov.getIid().equals(aac.getIid_agente().getIid())) {
                calPreciosProv();
            }
        }

        return res;
    }

    private void cerrarArticulo() {
        removeAll();
        dispose();
    }

    private void crearIconosBotones() {
        URL url = getClass().getResource("/iconos/cancelar.gif");
        ImageIcon icono = new ImageIcon(url);
        bcancelar.setIcon(icono);

        url = getClass().getResource("/iconos/guardarYvolver.png");
        icono = new ImageIcon(url);
        baceptar.setIcon(icono);

        url = getClass().getResource("/iconos/editar.png");
        icono = new ImageIcon(url);
        bmodificar.setIcon(icono);

        url = getClass().getResource("/iconos/gomaBorrar.gif");
        icono = new ImageIcon(url);
        bEliminarCaracteristica.setIcon(icono);
        bEliminarEscaladoCaracteristica.setIcon(icono);
        bBorrarEscaladoArticulo.setIcon(icono);
        bEliminarAA.setIcon(icono);

        url = getClass().getResource("/iconos/masAzul.png");
        icono = new ImageIcon(url);
        bNuevaCaracteristica.setIcon(icono);
        bNuevoEscaladoCaracteristica.setIcon(icono);
        bCrearEscaladoArticulo.setIcon(icono);
        bNuevoAA.setIcon(icono);

        url = getClass().getResource("/iconos/modificar_despiece.png");
        icono = new ImageIcon(url);
        bModificarCaracteristica.setIcon(icono);
        bModificarAA.setIcon(icono);

        url = getClass().getResource("/iconos/venta.png");
        icono = new ImageIcon(url);
        bAa.setIcon(icono);

        url = getClass().getResource("/iconos/compra.png");
        icono = new ImageIcon(url);
        bAc.setIcon(icono);

        url = getClass().getResource("/iconos/config.png");
        icono = new ImageIcon(url);
        bConfig.setIcon(icono);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        baceptar = new javax.swing.JButton();
        bcancelar = new javax.swing.JButton();
        bmodificar = new javax.swing.JButton();
        bAa = new javax.swing.JButton();
        bAc = new javax.swing.JButton();
        jScrollPane5 = new javax.swing.JScrollPane();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        bstockmedida = new javax.swing.JCheckBox();
        bactualizarstock = new javax.swing.JCheckBox();
        bstockneg = new javax.swing.JCheckBox();
        bstockcolor = new javax.swing.JCheckBox();
        jSeparator3 = new javax.swing.JSeparator();
        ldesctec = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tdesctect = new javax.swing.JTextArea();
        jScrollPane3 = new javax.swing.JScrollPane();
        tdescinf = new javax.swing.JTextArea();
        ldescinf = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        lfamiliav = new javax.swing.JLabel();
        lcodigo = new javax.swing.JLabel();
        tcodigo = new javax.swing.JTextField();
        cfamiliav = new javax.swing.JComboBox();
        lunidadmedida = new javax.swing.JLabel();
        cunidadm = new javax.swing.JComboBox();
        ltipocontrol = new javax.swing.JLabel();
        lproveedor = new javax.swing.JLabel();
        cproveedorh = new javax.swing.JComboBox();
        jSeparator2 = new javax.swing.JSeparator();
        jScrollPane1 = new javax.swing.JScrollPane();
        tobservaciones = new javax.swing.JTextArea();
        lobservaciones = new javax.swing.JLabel();
        ttipoControl = new javax.swing.JTextField();
        lRestoMinimo = new javax.swing.JLabel();
        tRestoMinimo = new javax.swing.JTextField();
        cbCorteLiso = new javax.swing.JCheckBox();
        lStockMinimo = new javax.swing.JLabel();
        tStockMinimo = new javax.swing.JTextField();
        bMonocromo = new javax.swing.JCheckBox();
        jScrollPane9 = new javax.swing.JScrollPane();
        Modelo modelo2 = new Modelo();
        tcaracteristicas = new javax.swing.JTable(modelo2);
        lCaracteristicas1 = new javax.swing.JLabel();
        cbEscaladoCaracteristica = new javax.swing.JCheckBox();
        bEscaladosCarFichero = new javax.swing.JButton();
        bNuevaCaracteristica = new javax.swing.JButton();
        bModificarCaracteristica = new javax.swing.JButton();
        bEliminarCaracteristica = new javax.swing.JButton();
        tdescuento = new javax.swing.JTextField();
        lDescuento = new javax.swing.JLabel();
        liva = new javax.swing.JLabel();
        cIva = new javax.swing.JComboBox();
        cmoneda = new javax.swing.JComboBox();
        lmoneda = new javax.swing.JLabel();
        cbEscaladoArticulo = new javax.swing.JCheckBox();
        bEscaladosFichero = new javax.swing.JButton();
        pEscaladoArticulo = new javax.swing.JPanel();
        bCrearEscaladoArticulo = new javax.swing.JButton();
        bBorrarEscaladoArticulo = new javax.swing.JButton();
        jScrollPane6 = new javax.swing.JScrollPane();
        Modelo modeloEscaladoArticulo = new Modelo();
        tEscaladoArticulo = new javax.swing.JTable(modeloEscaladoArticulo);
        lEscalado = new javax.swing.JLabel();
        pEscaladoCaracteristica = new javax.swing.JPanel();
        jScrollPane7 = new javax.swing.JScrollPane();
        Modelo modeloEscaladoCaracteristica = new Modelo();
        tEscaladoCaracteristicas = new javax.swing.JTable(modeloEscaladoCaracteristica);
        lEscaladoCaracteristicas = new javax.swing.JLabel();
        bNuevoEscaladoCaracteristica = new javax.swing.JButton();
        bEliminarEscaladoCaracteristica = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        tprecio = new javax.swing.JTextField();
        lprecio = new javax.swing.JLabel();
        lprecioIncremento = new javax.swing.JLabel();
        tprecioIncremento = new javax.swing.JTextField();
        lprecio1 = new javax.swing.JLabel();
        tupc = new javax.swing.JTextField();
        tptc = new javax.swing.JTextField();
        tFormulaC = new javax.swing.JTextField();
        tExpliC = new javax.swing.JLabel();
        lprecio2 = new javax.swing.JLabel();
        lprecio3 = new javax.swing.JLabel();
        tpmc = new javax.swing.JTextField();
        lprecio4 = new javax.swing.JLabel();
        tfc = new javax.swing.JTextField();
        bPrecios = new javax.swing.JButton();
        bConfig = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        pExistencias = new javax.swing.JPanel();
        bCrearInventario = new javax.swing.JButton();
        jScrollPane4 = new javax.swing.JScrollPane();
        Modelo modelo = new Modelo();
        tExistencias = new javax.swing.JTable(modelo);
        lAlmacen = new javax.swing.JLabel();
        cAlmacen = new javax.swing.JComboBox();
        jScrollPane8 = new javax.swing.JScrollPane();
        Modelo modelot = new Modelo();
        tMovimientos = new javax.swing.JTable(modelot);
        bBorrarMovimiento = new javax.swing.JButton();
        lMovimientos = new javax.swing.JLabel();
        lExistencias = new javax.swing.JLabel();
        pExistencias1 = new javax.swing.JPanel();
        jScrollPane10 = new javax.swing.JScrollPane();
        Modelo modelo1 = new Modelo();
        tagentearticulocodigo1 = new javax.swing.JTable(modelo1);
        lMovimientos1 = new javax.swing.JLabel();
        bNuevoAA = new javax.swing.JButton();
        bModificarAA = new javax.swing.JButton();
        bEliminarAA = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });

        baceptar.setText("Aceptar");
        baceptar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                baceptarActionPerformed(evt);
            }
        });

        bcancelar.setText("Cancelar");
        bcancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bcancelarActionPerformed(evt);
            }
        });

        bmodificar.setText("Modificar");
        bmodificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bmodificarActionPerformed(evt);
            }
        });

        bAa.setToolTipText("Crear albarán");
        bAa.setEnabled(false);
        bAa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bAaActionPerformed(evt);
            }
        });

        bAc.setToolTipText("Pedir");
        bAc.setEnabled(false);
        bAc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bAcActionPerformed(evt);
            }
        });

        bstockmedida.setText("Incluir medidas en stock");

        bactualizarstock.setText("Actualizar Stock");

        bstockneg.setText("Permitir stock negativo");

        bstockcolor.setText("Incluir stock en el color");

        ldesctec.setText("Descripcion Técnica");

        tdesctect.setColumns(20);
        tdesctect.setRows(5);
        tdesctect.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tdesctectKeyPressed(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tdesctectKeyReleased(evt);
            }
        });
        jScrollPane2.setViewportView(tdesctect);

        tdescinf.setColumns(20);
        tdescinf.setRows(5);
        tdescinf.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tdescinfKeyPressed(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tdescinfKeyReleased(evt);
            }
        });
        jScrollPane3.setViewportView(tdescinf);

        ldescinf.setText("Descripción Informativa");

        lfamiliav.setText("Familia Venta");

        lcodigo.setText("Código");

        tcodigo.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tcodigoKeyReleased(evt);
            }
        });

        cfamiliav.setModel(new javax.swing.DefaultComboBoxModel(new String[] {}));
        cfamiliav.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cfamiliavActionPerformed(evt);
            }
        });

        lunidadmedida.setText("Unidad Medida");

        cunidadm.setModel(new javax.swing.DefaultComboBoxModel(new String[] { }));

        ltipocontrol.setText("Tipo de Control");

        lproveedor.setText("Proveedor Habitual");

        cproveedorh.setModel(new javax.swing.DefaultComboBoxModel(new String[] {}));
        cproveedorh.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cproveedorhActionPerformed(evt);
            }
        });

        jSeparator2.setOrientation(javax.swing.SwingConstants.VERTICAL);

        tobservaciones.setColumns(20);
        tobservaciones.setRows(5);
        tobservaciones.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tobservacionesKeyPressed(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tobservacionesKeyReleased(evt);
            }
        });
        jScrollPane1.setViewportView(tobservaciones);

        lobservaciones.setText("Observaciones");

        lRestoMinimo.setText("Resto mínimo");

        tRestoMinimo.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tRestoMinimoKeyReleased(evt);
            }
        });

        cbCorteLiso.setText("Corte liso");

        lStockMinimo.setText("Stock mínimo");

        tStockMinimo.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tStockMinimoKeyReleased(evt);
            }
        });

        bMonocromo.setText("Monocromo");

        jScrollPane9.setPreferredSize(new java.awt.Dimension(452, 402));

        modelo2.addColumn("Color");
        modelo2.addColumn("UPC");
        modelo2.addColumn("PMC");
        modelo2.addColumn("Stock Mínimo");
        modelo2.addColumn("Cantidad Mínima");
        modelo2.addColumn("PVP");
        modelo2.addColumn("Precio Incremento");

        ScriptEngineManager manager = new ScriptEngineManager();
        ScriptEngine engine = manager.getEngineByName("js");
        if (listaCaracteristicas!=null && listaCaracteristicas.size()> 0) {
            if(!crear){

                //obtenemos la lista de todas las características
                //List lcaracteristicas = BaseDatos.getListaCaracteristicas(e, ar);
                List lcaracteristicas = listaCaracteristicas;
                if (listaCaracteristicas!=null){
                    Caracteristica c;
                    Object[] fila6;
                    for (Iterator iti = lcaracteristicas.iterator(); iti.hasNext();) {

                        fila6 = new Object[7];
                        c = (Caracteristica) iti.next();
                        if(c.getIid_color() != null){
                            fila6[0] = c.getIid_color().getCod_color();
                        }

                        Iterator i = listaPrecios.iterator();
                        Boolean seguir = true;
                        while (i.hasNext() && seguir) {

                            Precios p = (Precios) i.next();

                            if (p.getIid_car().equals(c.getIid_color().getIid())) {

                                if (p.getPtc() != null) {
                                    c.setPtc(p.getPtc());
                                }
                                if (p.getPvp() != null) {
                                    c.setPvp(p.getPvp());
                                }
                                if (p.getUpc() != null) {
                                    c.setUpc(p.getUpc());
                                }
                                if (p.getPi() != null) {
                                    c.setPrecioIncremento(p.getPi());
                                }

                                seguir = false;
                            }
                        }

                        if(c.getUpc() != null){
                            if (!modInter){
                                fila6[1] = Util.convertirPuntoAComa(c.getUpc().toString());
                            }else{

                                fila6[1] = Util.convertirPuntoAComa(c.getPvp().toString());
                            }

                        } else {
                            fila6[1] = "";
                        }
                        if(c.getPtc() != null){
                            if (!modInter){
                                fila6[2] = Util.convertirPuntoAComa(c.getPtc().toString());
                            }else{
                                fila6[2] = Util.convertirPuntoAComa(c.getPvp().toString());
                            }
                        } else {
                            fila6[2] = "";
                        }

                        if(c.getStock_min()){
                            fila6[3] = "Sí";
                            fila6[4] = c.getCantidad_stock_minimo();
                        }
                        else{
                            fila6[3] = "No";
                            fila6[4] = "";
                        }
                        try{
                            if(c.getPvp() != null){
                                if (!modInter){
                                    fila6[5] = Util.convertirPuntoAComa(c.getPvp().toString());
                                }else{
                                    String formulaP = formula.replace("pvp", c.getPvp().toString());
                                    fila6[5] = (Float) Float.parseFloat(engine.eval(formulaP).toString());
                                }

                            } else {
                                fila6[5] = "";
                            }

                            if(c.getPrecioIncremento() != null){
                                if(!modInter){
                                    fila6[6] = Util.convertirPuntoAComa(c.getPrecioIncremento().toString());
                                }else{
                                    String formulaP = formula.replace("pvp", c.getPrecioIncremento().toString());
                                    fila6[6] = (Float) Float.parseFloat(engine.eval(formulaP).toString());
                                }
                            } else {
                                fila6[6] = "";
                            }

                            modelo2.addRow(fila6);

                        }catch(Exception ex){
                            ex.printStackTrace();
                        }
                    }
                }
            }
        }
        tcaracteristicas.getColumnModel().getColumn(0).setPreferredWidth(100);
        tcaracteristicas.getColumnModel().getColumn(1).setPreferredWidth(100);
        tcaracteristicas.getColumnModel().getColumn(2).setPreferredWidth(100);
        tcaracteristicas.getColumnModel().getColumn(3).setPreferredWidth(80);
        tcaracteristicas.getColumnModel().getColumn(4).setPreferredWidth(110);
        tcaracteristicas.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tcaracteristicasMouseClicked(evt);
            }
        });
        tcaracteristicas.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tcaracteristicasKeyPressed(evt);
            }
        });
        jScrollPane9.setViewportView(tcaracteristicas);

        lCaracteristicas1.setFont(new java.awt.Font("Tahoma", 1, 11));
        lCaracteristicas1.setText("Colores:");

        cbEscaladoCaracteristica.setText("Escalado");
        cbEscaladoCaracteristica.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbEscaladoCaracteristicaActionPerformed(evt);
            }
        });

        bEscaladosCarFichero.setText("Obtener escalados desde fichero");
        bEscaladosCarFichero.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bEscaladosCarFicheroActionPerformed(evt);
            }
        });

        bNuevaCaracteristica.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bNuevaCaracteristicaActionPerformed(evt);
            }
        });

        bModificarCaracteristica.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bModificarCaracteristicaActionPerformed(evt);
            }
        });

        bEliminarCaracteristica.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bEliminarCaracteristicaActionPerformed(evt);
            }
        });

        tdescuento.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tdescuentoKeyReleased(evt);
            }
        });

        lDescuento.setText("Descuento");

        liva.setText("Iva");

        cIva.setModel(new javax.swing.DefaultComboBoxModel(new String[] {}));

        cmoneda.setModel(new javax.swing.DefaultComboBoxModel(new String[] {}));

        lmoneda.setText("Moneda");

        cbEscaladoArticulo.setText("Escalado");
        cbEscaladoArticulo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbEscaladoArticuloActionPerformed(evt);
            }
        });

        bEscaladosFichero.setText("Obtener escalados desde fichero");
        bEscaladosFichero.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bEscaladosFicheroActionPerformed(evt);
            }
        });

        bCrearEscaladoArticulo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bCrearEscaladoArticuloActionPerformed(evt);
            }
        });

        bBorrarEscaladoArticulo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bBorrarEscaladoArticuloActionPerformed(evt);
            }
        });

        modeloEscaladoArticulo.addColumn("Dimensión1");
        modeloEscaladoArticulo.addColumn("Dimensión2");
        modeloEscaladoArticulo.addColumn("Precio");

        //if(!crear){
            //List lescalados = BaseDatos.getListaEscalados(ar.getIid(),null);
            Escalado esc;
            List lescalados = listaEscalados;
            for (Iterator it3 = lescalados.iterator(); it3.hasNext();) {
                Object[] fila = new Object[3];
                esc = (Escalado) it3.next();
                fila[0] = esc.getDimension1();
                fila[1] = esc.getDimension2();
                fila[2] = Util.convertirPuntoAComa(esc.getPrecio().toString());
                modeloEscaladoArticulo.addRow(fila);
            }
            //}

        tEscaladoArticulo.getColumnModel().getColumn(0).setPreferredWidth(100);
        tEscaladoArticulo.getColumnModel().getColumn(1).setPreferredWidth(100);
        tEscaladoArticulo.getColumnModel().getColumn(2).setPreferredWidth(100);
        tEscaladoArticulo.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tEscaladoArticuloKeyPressed(evt);
            }
        });
        jScrollPane6.setViewportView(tEscaladoArticulo);

        lEscalado.setFont(new java.awt.Font("Tahoma", 1, 11));
        lEscalado.setText("Escalados");

        org.jdesktop.layout.GroupLayout pEscaladoArticuloLayout = new org.jdesktop.layout.GroupLayout(pEscaladoArticulo);
        pEscaladoArticulo.setLayout(pEscaladoArticuloLayout);
        pEscaladoArticuloLayout.setHorizontalGroup(
            pEscaladoArticuloLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(pEscaladoArticuloLayout.createSequentialGroup()
                .add(pEscaladoArticuloLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(pEscaladoArticuloLayout.createSequentialGroup()
                        .add(2, 2, 2)
                        .add(jScrollPane6, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 399, Short.MAX_VALUE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(pEscaladoArticuloLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                            .add(bCrearEscaladoArticulo, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .add(bBorrarEscaladoArticulo, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .add(lEscalado))
                .addContainerGap())
        );
        pEscaladoArticuloLayout.setVerticalGroup(
            pEscaladoArticuloLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(pEscaladoArticuloLayout.createSequentialGroup()
                .add(lEscalado)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(pEscaladoArticuloLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(pEscaladoArticuloLayout.createSequentialGroup()
                        .add(bCrearEscaladoArticulo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 24, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(bBorrarEscaladoArticulo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 24, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(44, Short.MAX_VALUE))
                    .add(jScrollPane6, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 98, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
        );

        modeloEscaladoCaracteristica.addColumn("Color");
        modeloEscaladoCaracteristica.addColumn("Dimensión1");
        modeloEscaladoCaracteristica.addColumn("Dimensión2");
        modeloEscaladoCaracteristica.addColumn("Precio");
        tEscaladoCaracteristicas.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tEscaladoCaracteristicasKeyPressed(evt);
            }
        });
        jScrollPane7.setViewportView(tEscaladoCaracteristicas);

        lEscaladoCaracteristicas.setFont(new java.awt.Font("Tahoma", 1, 11));
        lEscaladoCaracteristicas.setText("Escalados Color");

        bNuevoEscaladoCaracteristica.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bNuevoEscaladoCaracteristicaActionPerformed(evt);
            }
        });

        bEliminarEscaladoCaracteristica.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bEliminarEscaladoCaracteristicaActionPerformed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout pEscaladoCaracteristicaLayout = new org.jdesktop.layout.GroupLayout(pEscaladoCaracteristica);
        pEscaladoCaracteristica.setLayout(pEscaladoCaracteristicaLayout);
        pEscaladoCaracteristicaLayout.setHorizontalGroup(
            pEscaladoCaracteristicaLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(pEscaladoCaracteristicaLayout.createSequentialGroup()
                .add(pEscaladoCaracteristicaLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(lEscaladoCaracteristicas)
                    .add(pEscaladoCaracteristicaLayout.createSequentialGroup()
                        .add(jScrollPane7, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 406, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(pEscaladoCaracteristicaLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(bEliminarEscaladoCaracteristica, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 31, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(bNuevoEscaladoCaracteristica, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 31, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))))
                .add(0, 53, Short.MAX_VALUE))
        );
        pEscaladoCaracteristicaLayout.setVerticalGroup(
            pEscaladoCaracteristicaLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(pEscaladoCaracteristicaLayout.createSequentialGroup()
                .add(lEscaladoCaracteristicas)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(pEscaladoCaracteristicaLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(pEscaladoCaracteristicaLayout.createSequentialGroup()
                        .add(bNuevoEscaladoCaracteristica, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 23, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(bEliminarEscaladoCaracteristica, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 23, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                    .add(jScrollPane7, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)))
        );

        tprecio.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tprecioKeyReleased(evt);
            }
        });

        lprecio.setText("PVP");

        lprecioIncremento.setText("Añadido");

        tprecioIncremento.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tprecioIncrementoKeyReleased(evt);
            }
        });

        lprecio1.setText("UPC");

        tupc.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tupcKeyReleased(evt);
            }
        });

        tptc.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tptcKeyReleased(evt);
            }
        });

        tFormulaC.setEnabled(false);

        tExpliC.setText("PVP para Interlocutor, fórmula aplicada:");

        lprecio2.setText("PTC");

        lprecio3.setText("PMC");

        tpmc.setEnabled(false);
        tpmc.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tpmcKeyReleased(evt);
            }
        });

        lprecio4.setText("FP");

        tfc.setEnabled(false);
        tfc.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tfcKeyReleased(evt);
            }
        });

        bPrecios.setFont(new java.awt.Font("Pistilli", 1, 11));
        bPrecios.setText("R");
        bPrecios.setToolTipText("Registro de precios");
        bPrecios.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bPreciosActionPerformed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout jPanel2Layout = new org.jdesktop.layout.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jPanel2Layout.createSequentialGroup()
                        .add(tExpliC)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(tFormulaC, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 95, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                    .add(jPanel2Layout.createSequentialGroup()
                        .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING, false)
                            .add(jPanel2Layout.createSequentialGroup()
                                .add(lprecio)
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .add(tprecio, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 55, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                            .add(org.jdesktop.layout.GroupLayout.LEADING, jPanel2Layout.createSequentialGroup()
                                .add(lprecioIncremento)
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                .add(tprecioIncremento, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 55, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(org.jdesktop.layout.GroupLayout.TRAILING, lprecio1)
                            .add(lprecio3))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING, false)
                            .add(tpmc)
                            .add(tupc, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 56, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                        .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(jPanel2Layout.createSequentialGroup()
                                .add(lprecio2)
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                .add(tptc, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 52, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                .add(bPrecios, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .add(jPanel2Layout.createSequentialGroup()
                                .add(lprecio4)
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                                .add(tfc, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 98, Short.MAX_VALUE)))))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                        .add(lprecio)
                        .add(tprecio, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(tupc, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(lprecio1)
                        .add(tptc, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(lprecio2)
                        .add(bPrecios, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                    .add(jPanel2Layout.createSequentialGroup()
                        .add(26, 26, 26)
                        .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(lprecioIncremento)
                            .add(tprecioIncremento, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(tpmc, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(lprecio3)
                            .add(lprecio4)
                            .add(tfc, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))))
                .add(16, 16, 16)
                .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(tExpliC)
                    .add(tFormulaC, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        bConfig.setToolTipText("Configurar Producto");
        bConfig.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bConfigActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 12));
        jLabel1.setText("%");

        org.jdesktop.layout.GroupLayout jPanel1Layout = new org.jdesktop.layout.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jPanel1Layout.createSequentialGroup()
                        .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(lcodigo)
                            .add(lfamiliav)
                            .add(ltipocontrol)
                            .add(lunidadmedida)
                            .add(lproveedor))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                            .add(ttipoControl)
                            .add(tcodigo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 295, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(jPanel1Layout.createSequentialGroup()
                                .add(cfamiliav, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 132, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                .add(bConfig))
                            .add(cproveedorh, 0, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .add(cunidadm, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 134, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                    .add(jPanel1Layout.createSequentialGroup()
                        .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(cbCorteLiso)
                            .add(bstockneg)
                            .add(bstockcolor))
                        .add(10, 10, 10)
                        .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(jPanel1Layout.createSequentialGroup()
                                .add(lStockMinimo)
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                .add(tStockMinimo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 44, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                            .add(jPanel1Layout.createSequentialGroup()
                                .add(lRestoMinimo)
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                .add(tRestoMinimo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 41, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                            .add(bMonocromo)
                            .add(bactualizarstock)))
                    .add(bstockmedida)
                    .add(ldesctec)
                    .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING, false)
                        .add(org.jdesktop.layout.GroupLayout.LEADING, jScrollPane1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 389, Short.MAX_VALUE)
                        .add(org.jdesktop.layout.GroupLayout.LEADING, jScrollPane3)
                        .add(org.jdesktop.layout.GroupLayout.LEADING, jScrollPane2))
                    .add(ldescinf)
                    .add(lobservaciones)
                    .add(jSeparator1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 389, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(jSeparator3, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 421, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jSeparator2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jPanel1Layout.createSequentialGroup()
                        .add(14, 14, 14)
                        .add(jPanel2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(lDescuento)
                            .add(lmoneda)
                            .add(liva))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                            .add(jPanel1Layout.createSequentialGroup()
                                .add(tdescuento, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 57, Short.MAX_VALUE)
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                .add(jLabel1))
                            .add(cIva, 0, 75, Short.MAX_VALUE)
                            .add(cmoneda, 0, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .add(jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(pEscaladoArticulo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(jPanel1Layout.createSequentialGroup()
                                .add(cbEscaladoArticulo)
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                .add(bEscaladosFichero))))
                    .add(jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                            .add(org.jdesktop.layout.GroupLayout.LEADING, pEscaladoCaracteristica, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .add(org.jdesktop.layout.GroupLayout.LEADING, jPanel1Layout.createSequentialGroup()
                                .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                                    .add(org.jdesktop.layout.GroupLayout.LEADING, jPanel1Layout.createSequentialGroup()
                                        .add(jScrollPane9, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 399, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                        .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                                            .add(bEliminarCaracteristica, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 31, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                            .add(bModificarCaracteristica, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 31, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                            .add(bNuevaCaracteristica, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 31, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                                    .add(org.jdesktop.layout.GroupLayout.LEADING, lCaracteristicas1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 53, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                    .add(org.jdesktop.layout.GroupLayout.LEADING, jPanel1Layout.createSequentialGroup()
                                        .add(cbEscaladoCaracteristica)
                                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                        .add(bEscaladosCarFichero)))
                                .add(0, 60, Short.MAX_VALUE))))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel1Layout.createSequentialGroup()
                .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(lcodigo)
                    .add(tcodigo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                        .add(lfamiliav)
                        .add(cfamiliav, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                    .add(bConfig, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 25, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(ltipocontrol)
                    .add(ttipoControl, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(lunidadmedida)
                    .add(cunidadm, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(lproveedor)
                    .add(cproveedorh, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .add(18, 18, 18)
                .add(jSeparator1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(ldesctec)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jScrollPane2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(ldescinf)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jScrollPane3, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(lobservaciones)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jScrollPane1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 54, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jSeparator3, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .add(21, 21, 21)
                .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jPanel1Layout.createSequentialGroup()
                        .add(bstockmedida)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(bstockneg)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(bstockcolor)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(cbCorteLiso))
                    .add(jPanel1Layout.createSequentialGroup()
                        .add(bactualizarstock)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(bMonocromo)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(lRestoMinimo)
                            .add(tRestoMinimo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(lStockMinimo)
                            .add(tStockMinimo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))))
                .add(64, 64, 64))
            .add(jPanel1Layout.createSequentialGroup()
                .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jPanel1Layout.createSequentialGroup()
                        .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                            .add(jPanel1Layout.createSequentialGroup()
                                .add(jPanel2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 100, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                                    .add(cbEscaladoArticulo)
                                    .add(bEscaladosFichero)))
                            .add(jPanel1Layout.createSequentialGroup()
                                .add(8, 8, 8)
                                .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                                    .add(jPanel1Layout.createSequentialGroup()
                                        .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                                            .add(jLabel1)
                                            .add(tdescuento, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                        .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                                            .add(liva)
                                            .add(cIva, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                        .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                                            .add(lmoneda)
                                            .add(cmoneda, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                                    .add(lDescuento))))
                        .add(135, 135, 135)
                        .add(lCaracteristicas1)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                            .add(jPanel1Layout.createSequentialGroup()
                                .add(bNuevaCaracteristica, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 23, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                .add(bModificarCaracteristica, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 23, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                .add(bEliminarCaracteristica, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 23, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                            .add(jScrollPane9, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 85, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(bEscaladosCarFichero)
                            .add(cbEscaladoCaracteristica))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(pEscaladoCaracteristica, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .add(90, 90, 90))
                    .add(jPanel1Layout.createSequentialGroup()
                        .add(140, 140, 140)
                        .add(pEscaladoArticulo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
            .add(jPanel1Layout.createSequentialGroup()
                .add(jSeparator2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 533, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        cfamiliav.addItem(Constantes.VACIO);
        FamiliaVenta fv;
        List listaFamVCodigo = BaseDatos.getListaFamiliaVentas(e);
        for (Iterator it = listaFamVCodigo.iterator(); it.hasNext();) {
            fv = (FamiliaVenta) it.next();
            cfamiliav.addItem(fv.getNombre());
        }

        if(!crear && ar.getIid_fam_venta()!= null){
            fv = this.fv;
            cfamiliav.setSelectedItem(fv.getNombre());
        }
        else{
            cfamiliav.setSelectedIndex(0);
        }
        List listaNombreUnidadM = BaseDatos.getListaUnidadMedidas();
        UnidadMedida um;
        cunidadm.addItem(Constantes.VACIO);
        for (Iterator it = listaNombreUnidadM.iterator(); it.hasNext();) {
            um = (UnidadMedida) it.next();
            cunidadm.addItem(um.getNombre());
        }

        if(!crear && ar.getIid_unidad_medida() != null ){
            um = BaseDatos.obtenerUnidadMedidaIid(ar.getIid_unidad_medida().getIid());
            cunidadm.setSelectedItem(um.getNombre());
        }
        else{
            cunidadm.setSelectedIndex(0);
        }
        cproveedorh.addItem(Constantes.VACIO);
        List listanombreprov = BaseDatos.obtenerNombreComercialProveedor(e);
        for (Iterator it = listanombreprov.iterator(); it.hasNext();) {
            cproveedorh.addItem((String) it.next());
        }
        Agentes a = new Agentes();
        if (!crear && ar.getProv_hab() != null){
            a = BaseDatos.obtenerAgenteByIid(ar.getProv_hab().getIid());
        }
        if(!crear && a != null && a.getNombre_comercial() != null){
            cproveedorh.setSelectedItem(a.getNombre_comercial());
        }
        else{
            cproveedorh.setSelectedIndex(0);
        }
        List lIva = BaseDatos.getListaIva();
        Iva ivaTemp;
        for (Iterator it5 = lIva.iterator(); it5.hasNext();) {
            ivaTemp = (Iva) it5.next();
            cIva.addItem(ivaTemp.getPorcentaje()+"%");
        }
        List listaNombreMonedas = BaseDatos.obtenerNombreMoneda();
        cmoneda.addItem(Constantes.VACIO);
        for (Iterator it6 = listaNombreMonedas.iterator(); it6.hasNext();) {
            cmoneda.addItem((String) it6.next());
        }

        if(!crear){
            Moneda m = BaseDatos.obtenerMonedaByIid(ar.getIid_moneda().getIid());
            cmoneda.setSelectedItem(m.getNombre());
        }
        else{
            cmoneda.setSelectedItem("Euros");
        }

        jTabbedPane1.addTab("Modelo", jPanel1);

        bCrearInventario.setText("Crear Inventario");
        bCrearInventario.setActionCommand("jButton1");
        bCrearInventario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bCrearInventarioActionPerformed(evt);
            }
        });

        modelo.addColumn("Almacén");
        modelo.addColumn("Característica");

        if(this.numMedidas == 1){
            modelo.addColumn(ar.getIid_fam_venta().getIid_tipo_control().getIid_tipo_medida().getNombre_dim_1());
        }
        else if(numMedidas == 2){
            modelo.addColumn(ar.getIid_fam_venta().getIid_tipo_control().getIid_tipo_medida().getNombre_dim_1());
            modelo.addColumn(ar.getIid_fam_venta().getIid_tipo_control().getIid_tipo_medida().getNombre_dim_2());
        }
        else if(numMedidas == 3){
            modelo.addColumn(ar.getIid_fam_venta().getIid_tipo_control().getIid_tipo_medida().getNombre_dim_1());
            modelo.addColumn(ar.getIid_fam_venta().getIid_tipo_control().getIid_tipo_medida().getNombre_dim_2());
            modelo.addColumn(ar.getIid_fam_venta().getIid_tipo_control().getIid_tipo_medida().getNombre_dim_3());
        }
        else if(numMedidas == 4){
            modelo.addColumn(ar.getIid_fam_venta().getIid_tipo_control().getIid_tipo_medida().getNombre_dim_1());
            modelo.addColumn(ar.getIid_fam_venta().getIid_tipo_control().getIid_tipo_medida().getNombre_dim_2());
            modelo.addColumn(ar.getIid_fam_venta().getIid_tipo_control().getIid_tipo_medida().getNombre_dim_3());
            modelo.addColumn(ar.getIid_fam_venta().getIid_tipo_control().getIid_tipo_medida().getNombre_dim_4());
        }
        else if(numMedidas == 5){
            modelo.addColumn(ar.getIid_fam_venta().getIid_tipo_control().getIid_tipo_medida().getNombre_dim_1());
            modelo.addColumn(ar.getIid_fam_venta().getIid_tipo_control().getIid_tipo_medida().getNombre_dim_2());
            modelo.addColumn(ar.getIid_fam_venta().getIid_tipo_control().getIid_tipo_medida().getNombre_dim_3());
            modelo.addColumn(ar.getIid_fam_venta().getIid_tipo_control().getIid_tipo_medida().getNombre_dim_4());
            modelo.addColumn(ar.getIid_fam_venta().getIid_tipo_control().getIid_tipo_medida().getNombre_dim_5());
        }
        modelo.addColumn("Existencias");

        //List<Existencia> lE = BaseDatos.getListaExistencias(ar, null);
        List<Existencia> lE = listaExistencias;
        Iterator it = lE.iterator();
        Existencia ex;
        Object[] fila3;
        if(lE != null){
            while(it.hasNext()){
                fila3 = new Object[3 + numMedidas];
                ex = (Existencia)it.next();
                fila3[0] = ex.getAlmacen().getNombre();
                if(ex.getCaracteristica() != null){
                    fila3[1] = ex.getCaracteristica().getIid_color().getCod_color();
                }
                else{
                    fila3[1] = "--";
                }

                if(numMedidas == 1){
                    fila3[2] = ex.getCantidad1();
                }
                else if(numMedidas == 2){
                    fila3[2] = ex.getCantidad1();
                    fila3[3] = ex.getCantidad2();
                }
                else if(numMedidas == 3){
                    fila3[2] = ex.getCantidad1();
                    fila3[3] = ex.getCantidad2();
                    fila3[4] = ex.getCantidad3();
                }
                else if(numMedidas == 4){
                    fila3[2] = ex.getCantidad1();
                    fila3[3] = ex.getCantidad2();
                    fila3[4] = ex.getCantidad3();
                    fila3[5] = ex.getCantidad4();
                }
                else if(numMedidas == 5){
                    fila3[2] = ex.getCantidad1();
                    fila3[3] = ex.getCantidad2();
                    fila3[4] = ex.getCantidad3();
                    fila3[5] = ex.getCantidad4();
                    fila3[6] = ex.getCantidad5();
                }

                fila3[2 + numMedidas] = ex.getExistencia();
                modelo.addRow(fila3);
            }
        }
        jScrollPane4.setViewportView(tExistencias);

        lAlmacen.setText("Almacen");

        cAlmacen.setModel(new javax.swing.DefaultComboBoxModel(new String[] {}));
        cAlmacen.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cAlmacenActionPerformed(evt);
            }
        });

        modelot.addColumn("Concepto");
        modelot.addColumn("Almacén");
        modelot.addColumn("Fecha");
        modelot.addColumn("Característica");
        modelot.addColumn("Tipo");
        modelot.addColumn("Cantidad");

        SimpleDateFormat formatoTexto = new SimpleDateFormat("dd/mm/yyyy");
        Caracteristica car = new Caracteristica();
        if(numMedidas == 1){
            modelot.addColumn(tm.getNombre_dim_1());
        }
        else if(numMedidas == 2){
            modelot.addColumn(tm.getNombre_dim_1());
            modelot.addColumn(tm.getNombre_dim_2());
        }
        else if(numMedidas == 3){
            modelot.addColumn(tm.getNombre_dim_1());
            modelot.addColumn(tm.getNombre_dim_2());
            modelot.addColumn(tm.getNombre_dim_3());
        }
        else if(numMedidas == 4){
            modelot.addColumn(tm.getNombre_dim_1());
            modelot.addColumn(tm.getNombre_dim_2());
            modelot.addColumn(tm.getNombre_dim_3());
            modelot.addColumn(tm.getNombre_dim_4());
        }
        else if(numMedidas == 5){
            modelot.addColumn(tm.getNombre_dim_1());
            modelot.addColumn(tm.getNombre_dim_2());
            modelot.addColumn(tm.getNombre_dim_3());
            modelot.addColumn(tm.getNombre_dim_4());
            modelot.addColumn(tm.getNombre_dim_5());
        }

        // List<Existencia> lE = BaseDatos.getListaExistencias(ar, null);
        List<MovimientoAlmacen> lm = this.listaMovimientos;
        Iterator it0 = lm.iterator();
        MovimientoAlmacen mov;
        Object[] fila4;
        if(lm != null){
            while(it0.hasNext()){
                fila4 = new Object[6 + numMedidas()];
                mov = (MovimientoAlmacen)it0.next();
                fila4[0] = mov.getConcepto();
                fila4[1] = mov.getAlmacen().getNombre();
                fila4[2] = mov.getFecha();
                fila4[3] = (mov.getCaracteristica() != null)?mov.getCaracteristica().getIid_color().getCod_color():"--";
                fila4[4] = mov.getTipoMovimiento().getNombre();
                fila4[5] = mov.getCantidad();

                if(numMedidas() == 1){
                    fila4[6] = mov.getCantidad1();
                }
                else if(numMedidas() == 2){
                    fila4[6] = mov.getCantidad1();
                    fila4[7] = mov.getCantidad2();
                }
                else if(numMedidas() == 3){
                    fila4[6] = mov.getCantidad1();
                    fila4[7] = mov.getCantidad2();
                    fila4[8] = mov.getCantidad3();
                }
                else if(numMedidas() == 4){
                    fila4[6] = mov.getCantidad1();
                    fila4[7] = mov.getCantidad2();
                    fila4[8] = mov.getCantidad3();
                    fila4[9] = mov.getCantidad4();
                }
                else if(numMedidas() == 5){
                    fila4[6] = mov.getCantidad1();
                    fila4[7] = mov.getCantidad2();
                    fila4[8] = mov.getCantidad3();
                    fila4[9] = mov.getCantidad4();
                    fila4[10] = mov.getCantidad5();
                }
                modelot.addRow(fila4);
            }
        }
        tMovimientos.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tMovimientosKeyPressed(evt);
            }
        });
        jScrollPane8.setViewportView(tMovimientos);

        bBorrarMovimiento.setText("Borrar");
        bBorrarMovimiento.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bBorrarMovimientoActionPerformed(evt);
            }
        });

        lMovimientos.setFont(new java.awt.Font("Tahoma", 1, 11));
        lMovimientos.setText("Lista de Movimientos");

        lExistencias.setFont(new java.awt.Font("Tahoma", 1, 11));
        lExistencias.setText("Lista de Existencias");

        org.jdesktop.layout.GroupLayout pExistenciasLayout = new org.jdesktop.layout.GroupLayout(pExistencias);
        pExistencias.setLayout(pExistenciasLayout);
        pExistenciasLayout.setHorizontalGroup(
            pExistenciasLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(pExistenciasLayout.createSequentialGroup()
                .addContainerGap()
                .add(pExistenciasLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                    .add(org.jdesktop.layout.GroupLayout.LEADING, jScrollPane4, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 921, Short.MAX_VALUE)
                    .add(org.jdesktop.layout.GroupLayout.LEADING, jScrollPane8, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 921, Short.MAX_VALUE)
                    .add(org.jdesktop.layout.GroupLayout.LEADING, pExistenciasLayout.createSequentialGroup()
                        .add(lAlmacen)
                        .add(33, 33, 33)
                        .add(cAlmacen, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 178, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                    .add(org.jdesktop.layout.GroupLayout.LEADING, pExistenciasLayout.createSequentialGroup()
                        .add(lMovimientos, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 129, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED, 610, Short.MAX_VALUE)
                        .add(bCrearInventario)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(bBorrarMovimiento))
                    .add(org.jdesktop.layout.GroupLayout.LEADING, lExistencias))
                .addContainerGap())
        );
        pExistenciasLayout.setVerticalGroup(
            pExistenciasLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(pExistenciasLayout.createSequentialGroup()
                .addContainerGap()
                .add(pExistenciasLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(lAlmacen)
                    .add(cAlmacen, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(pExistenciasLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(lMovimientos)
                    .add(bBorrarMovimiento)
                    .add(bCrearInventario))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jScrollPane8, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 229, Short.MAX_VALUE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(lExistencias)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jScrollPane4, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 257, Short.MAX_VALUE))
        );

        cAlmacen.addItem(Constantes.VACIO);
        Almacen alm;
        List lAlm = BaseDatos.getListaAlmacenes();
        for (Iterator iti = lAlm.iterator(); iti.hasNext();) {
            alm = (Almacen) iti.next();
            cAlmacen.addItem(alm.getNombre());
        }

        cAlmacen.setSelectedIndex(0);

        jTabbedPane1.addTab("Existencias", pExistencias);

        modelo1.addColumn("Proveedor");
        modelo1.addColumn("Código");
        modelo1.addColumn("Tipo Precio");
        modelo1.addColumn("Precio");
        modelo1.addColumn("Descuento");
        modelo1.addColumn("Color");

        List laac1 = lAgenteArticuloCodigo;
        AgenteArticuloCodigo aac1;
        Iterator it1;
        Object[] fila1;
        if(laac1 != null){
            for (it1 = laac1.iterator(); it1.hasNext();) {
                fila1 = new Object[6];
                aac1 = (AgenteArticuloCodigo) it1.next();
                fila1[0] = aac1.getIid_agente().getNombre_comercial();
                fila1[1] = aac1.getCodigo();
                fila1[2] = aac1.getTipoPrecio();
                fila1[3] = Util.convertirPuntoAComa(aac1.getPrecio().toString());
                if(aac1.getDescuento() != null){
                    fila1[4] = Util.convertirPuntoAComa(aac1.getDescuento().toString());
                }
                if(aac1.getIid_color()!= null && aac1.getIid_color() != 0){
                    fila1[5] = BaseDatos.obtenerColorPorIid(aac1.getIid_color()).getCod_color();
                }
                modelo1.addRow(fila1);
            }
        }

        tagentearticulocodigo1.getColumnModel().getColumn(0).setPreferredWidth(150);
        tagentearticulocodigo1.getColumnModel().getColumn(1).setPreferredWidth(150);
        tagentearticulocodigo1.getColumnModel().getColumn(4).setPreferredWidth(50);
        tagentearticulocodigo1.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        tagentearticulocodigo1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tagentearticulocodigo1MouseClicked(evt);
            }
        });
        tagentearticulocodigo1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tagentearticulocodigo1KeyPressed(evt);
            }
        });
        jScrollPane10.setViewportView(tagentearticulocodigo1);

        lMovimientos1.setFont(new java.awt.Font("Tahoma", 1, 11));
        lMovimientos1.setText("Lista de Precios por Proveedor");

        bNuevoAA.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bNuevoAAActionPerformed(evt);
            }
        });

        bModificarAA.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bModificarAAActionPerformed(evt);
            }
        });

        bEliminarAA.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bEliminarAAActionPerformed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout pExistencias1Layout = new org.jdesktop.layout.GroupLayout(pExistencias1);
        pExistencias1.setLayout(pExistencias1Layout);
        pExistencias1Layout.setHorizontalGroup(
            pExistencias1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(pExistencias1Layout.createSequentialGroup()
                .addContainerGap()
                .add(pExistencias1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(pExistencias1Layout.createSequentialGroup()
                        .add(jScrollPane10, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 739, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(pExistencias1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(bEliminarAA, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 31, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(bModificarAA, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 31, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(bNuevoAA, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 31, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                    .add(lMovimientos1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 187, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(155, Short.MAX_VALUE))
        );
        pExistencias1Layout.setVerticalGroup(
            pExistencias1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(pExistencias1Layout.createSequentialGroup()
                .addContainerGap()
                .add(lMovimientos1)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(pExistencias1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jScrollPane10, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 246, Short.MAX_VALUE)
                    .add(pExistencias1Layout.createSequentialGroup()
                        .add(bNuevoAA, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 23, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(bModificarAA, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 23, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(bEliminarAA, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 23, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED, 165, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                .add(246, 246, 246))
        );

        jTabbedPane1.addTab("Precios por Proveedor", pExistencias1);

        jScrollPane5.setViewportView(jTabbedPane1);

        org.jdesktop.layout.GroupLayout layout = new org.jdesktop.layout.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(layout.createSequentialGroup()
                .addContainerGap()
                .add(bAa)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(bAc)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED, 604, Short.MAX_VALUE)
                .add(baceptar)
                .add(14, 14, 14)
                .add(bmodificar, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 103, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(bcancelar)
                .addContainerGap())
            .add(jScrollPane5, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 965, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, layout.createSequentialGroup()
                .add(jScrollPane5, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 604, Short.MAX_VALUE)
                .add(11, 11, 11)
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                    .add(bAa, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 21, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(bAc, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 21, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                        .add(bcancelar)
                        .add(bmodificar)
                        .add(baceptar)))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

private void bcancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bcancelarActionPerformed
    BaseDatos.desUsarArticulo(ar.getIid());
    cerrarArticulo();
}//GEN-LAST:event_bcancelarActionPerformed
    private int guardar() {
        int res = 0;
        try {
            String codigo = tcodigo.getText();
            String desc = tdesctect.getText();
            String familiaVentaString = (String) cfamiliav.getSelectedItem();
            String dtoString = Util.convertirComaAPunto(tdescuento.getText());
            String precioString = Util.convertirComaAPunto(tprecio.getText());
            String precioIncrementoString = Util.convertirComaAPunto(tprecioIncremento.getText());
            String precioUPC = Util.convertirComaAPunto(tupc.getText());
            String precioPTC = Util.convertirComaAPunto(tptc.getText());

            if (codigo != null && codigo.length() > 0 && desc != null && desc.length() > 0 && !familiaVentaString.equals(Constantes.VACIO)) {
                ar.setIid_empresa(e);
                ar.setCod_articulo(tcodigo.getText());
                ar.setDes_tecnica(tdesctect.getText());
                ar.setDes_inf(tdescinf.getText());
                ar.setAct_stock(bactualizarstock.isSelected());
                ar.setStock_neg(bstockneg.isSelected());
                ar.setStock_med(bstockmedida.isSelected());
                ar.setStock_col(bstockcolor.isSelected());
                ar.setIid_fam_venta(BaseDatos.obtenerFamiliaVentaPorNombre(e, (String) cfamiliav.getSelectedItem()));
                ar.setIid_unidad_medida(BaseDatos.obtenerUnidadMedidaNombre((String) cunidadm.getSelectedItem()));
                String siva = (String) cIva.getSelectedItem();
                String iva = siva.substring(0, siva.length() - 1);
                ar.setEscalado(cbEscaladoArticulo.isSelected());
                ar.setEscaladoCaracteristica(cbEscaladoCaracteristica.isSelected());
                ar.setEnUso("");

                Date fecha = new Date(); // fecha y hora locales
                Precios p = new Precios();

                String sPor = (String) cIva.getSelectedItem();
                String sPorcentaje = sPor.substring(0, sPor.length() - 1);
                ar.setIva(BaseDatos.obtenerIvaPorPorcentaje(sPorcentaje));

                if (dtoString.length() > 0) {
                    ar.setDescuento(Float.parseFloat(dtoString));
                }

                //Comprobamos si el precio ha cambiado
                if (crear || (precioAnt != null && (!precioAnt.getPvp().equals(Float.parseFloat(precioString))) || !precioAnt.getPi().equals(Float.parseFloat(precioIncrementoString)) || !precioAnt.getPtc().equals(Float.parseFloat(precioPTC)) || !precioAnt.getUpc().equals(Float.parseFloat(precioUPC)))) {
                    if (precioString.length() > 0) {
                        p.setPvp(Float.parseFloat(precioString));
                    } else {
                        p.setPvp(0F);
                    }

                    if (precioIncrementoString.length() > 0) {
                        p.setPi(Float.parseFloat(precioIncrementoString));
                    } else {
                        p.setPi(0F);
                    }

                    if (precioUPC.length() > 0) {
                        p.setUpc(Float.parseFloat(precioUPC));
                    } else {
                        p.setUpc(0F);
                    }

                    if (precioPTC.length() > 0) {
                        ar.setPtc(Float.parseFloat(precioPTC));
                    } else {
                        ar.setPtc(0F);
                    }

                    //Fecha de cambio
                    p.setFecha(fecha.getTime());
                    p.setIid_empresa(e);
                    p.setIid_art(ar);
                    p.setIid_car(0);
                    if (!crear) {
                        p.setIid(precioAnt.getIid());
                    }
                } else {
                    //No hay cambio de precio
                    p = null;
                }

                ar.setObservaciones(tobservaciones.getText());
                ar.setIid_moneda(BaseDatos.obtenerMonedaNombre((String) cmoneda.getSelectedItem()));
                ar.setProv_hab(BaseDatos.obtenerProveedorNombreComercial((String) cproveedorh.getSelectedItem(), e));

                if (tRestoMinimo.isVisible() && !tRestoMinimo.getText().equals("")) {
                    ar.setRestoMinimo(Float.parseFloat(Util.convertirComaAPunto(tRestoMinimo.getText())));
                } else {
                    ar.setRestoMinimo(null);
                }

                if (cbCorteLiso.isVisible() && cbCorteLiso.isSelected()) {
                    ar.setCorteLiso(true);
                } else {
                    ar.setCorteLiso(false);
                }

                if (tStockMinimo.getText() != null && !tStockMinimo.getText().equals("")) {
                    ar.setStockMinimo(Integer.valueOf(tStockMinimo.getText()));
                } else {
                    ar.setStockMinimo(null);
                }

                ar.setMonocromo(this.bMonocromo.isSelected());

                if (crear) {
                    //Creamos el articulo
                    if (BaseDatos.obtenerArticulo(codigo, e.getIid()) == null) {
                        if (!BaseDatos.insertarArticulo(ar, listaCaracteristicas, listaEscalados, listaMovimientos, listaExistencias, lArticuloDescuentos, lAgenteArticulo, lAgenteArticuloCodigo, listaPreciosIns, "Creación manual", u.getNombre())) {
                            JOptionPane.showMessageDialog(null, "No se puede ha podido insertar el elemento", "Error", JOptionPane.ERROR_MESSAGE);
                            res = 1;
                        }
                    } else {
                        JOptionPane.showMessageDialog(null, "Ya hay un articulo con el código " + codigo, "Error", JOptionPane.ERROR_MESSAGE);
                        res = 1;
                    }
                } else {
                    Articulo temp = null;
                    if (!codigo.equalsIgnoreCase(codigoAntiguo)) {
                        temp = BaseDatos.obtenerArticulo(codigo, e.getIid());
                    }

                    if (temp == null) {
                        if (BaseDatos.modificarArticulo(ar, listaCaracteristicas, listaEscalados, listaMovimientos, listaMovimientosBorrados, listaMovimientosCreados, actualizarMovExistencias, lArticuloDescuentos, lAgenteArticulo, lAgenteArticuloCodigo, listaPreciosIns, "Modificación manual", u.getNombre())) {
                        } else {
                            JOptionPane.showMessageDialog(null, "No se puede ha podido modificar el elemento", "Error", JOptionPane.ERROR_MESSAGE);
                            res = 1;
                        }
                    } else {
                        JOptionPane.showMessageDialog(null, "Ya hay un articulo con el código " + codigo, "Error", JOptionPane.ERROR_MESSAGE);
                        res = 1;
                    }
                }
            } else {
                //Error, hay que rellenar todos los campos
                JOptionPane.showMessageDialog(null, "Debe rellenar los campos \"Código\" , \"Familia de Ventas\" y \"Descripción Técnica\"", "Error", JOptionPane.ERROR_MESSAGE);
                res = 1;
            }
        } catch (NumberFormatException exc) {
            //Error, los campos numéricos no contienen números
            JOptionPane.showMessageDialog(null, "El campo \"Precio\", \"Descuento\" e \"Iva\" deben ser numérico", "Error", JOptionPane.ERROR_MESSAGE);
            res = 1;
        }
        return res;
    }
private void baceptarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_baceptarActionPerformed
    try {
        String codigo = tcodigo.getText();
        String desc = tdesctect.getText();
        String familiaVentaString = (String) cfamiliav.getSelectedItem();
        String dtoString = Util.convertirComaAPunto(tdescuento.getText());
        String precioString = Util.convertirComaAPunto(tprecio.getText());
        String precioIncrementoString = Util.convertirComaAPunto(tprecioIncremento.getText());
        String precioUPC = Util.convertirComaAPunto(tupc.getText());
        String precioPTC = Util.convertirComaAPunto(tptc.getText());
        Precios p = new Precios();

        if (codigo != null && codigo.length() > 0 && desc != null && desc.length() > 0 && !familiaVentaString.equals(Constantes.VACIO)) {
            ar.setIid_empresa(e);
            ar.setCod_articulo(tcodigo.getText());
            ar.setDes_tecnica(tdesctect.getText());
            ar.setDes_inf(tdescinf.getText());
            ar.setAct_stock(bactualizarstock.isSelected());
            ar.setStock_neg(bstockneg.isSelected());
            ar.setStock_med(bstockmedida.isSelected());
            ar.setStock_col(bstockcolor.isSelected());
            ar.setIid_fam_venta(BaseDatos.obtenerFamiliaVentaPorNombre(e, (String) cfamiliav.getSelectedItem()));
            ar.setIid_unidad_medida(BaseDatos.obtenerUnidadMedidaNombre((String) cunidadm.getSelectedItem()));
            String siva = (String) cIva.getSelectedItem();
            String iva = siva.substring(0, siva.length() - 1);
            ar.setEscalado(cbEscaladoArticulo.isSelected());
            ar.setEscaladoCaracteristica(cbEscaladoCaracteristica.isSelected());
            ar.setEnUso("");

            String sPor = (String) cIva.getSelectedItem();
            String sPorcentaje = sPor.substring(0, sPor.length() - 1);
            ar.setIva(BaseDatos.obtenerIvaPorPorcentaje(sPorcentaje));

            if (!dtoString.equals("")) {
                ar.setDescuento(Float.parseFloat(dtoString));
            }

            //Comprobamos si el precio ha cambiado
            Date fecha = new Date();
            boolean cambio = false;
            if (!crear && precioAnt != null) {
                if (!precioString.equals("")) {
                    if (precioAnt.getPvp() == null || !precioAnt.getPvp().equals(Float.parseFloat(precioString))) {
                        p.setPvp(Float.parseFloat(precioString));
                        cambio = true;
                    } else {
                        p.setPvp(precioAnt.getPvp());
                    }
                } else {
                    p.setPvp(0F);
                }

                if (!precioIncrementoString.equals("")) {
                    if (precioAnt.getPi() == null || !precioAnt.getPi().equals(Float.parseFloat(precioIncrementoString))) {
                        p.setPi(Float.parseFloat(precioIncrementoString));
                        cambio = true;
                    } else {
                        p.setPi(precioAnt.getPi());
                    }
                } else {
                    p.setPi(0F);
                }

                if (!precioUPC.equals("")) {
                    if (precioAnt.getUpc() == null || !precioAnt.getUpc().equals(Float.parseFloat(precioUPC))) {
                        p.setUpc(Float.parseFloat(precioUPC));
                        cambio = true;
                    } else {
                        p.setUpc(precioAnt.getUpc());
                    }
                } else {
                    p.setUpc(0F);
                }

                if (!precioPTC.equals("")) {
                    if (precioAnt.getPtc() == null || !precioAnt.getPtc().equals(Float.parseFloat(precioPTC))) {
                        p.setPtc(Float.parseFloat(precioPTC));
                        cambio = true;
                    } else {
                        p.setPtc(precioAnt.getPtc());
                    }
                } else {
                    p.setPtc(0F);
                }

                if (cambio) {
                    //Fecha de cambio
                    p.setFecha(fecha.getTime());
                    p.setIid_empresa(e);
                    p.setIid_art(ar);
                    p.setIid_car(0);
                    p.setIid(null);
                    listaPreciosIns.add(p);
                }
            } else {
                if (!precioString.equals("")) {
                    p.setPvp(Float.parseFloat(precioString));
                } else {
                    p.setPvp(0F);
                }

                if (!precioIncrementoString.equals("")) {
                    p.setPi(Float.parseFloat(precioIncrementoString));

                } else {
                    p.setPi(0F);
                }

                if (!precioUPC.equals("")) {
                    p.setUpc(Float.parseFloat(precioUPC));

                } else {
                    p.setUpc(0F);
                }

                if (!precioPTC.equals("")) {
                    p.setPtc(Float.parseFloat(precioPTC));
                } else {
                    p.setPtc(0F);
                }

                //Fecha de cambio
                p.setFecha(fecha.getTime());
                p.setIid_empresa(e);
                p.setIid_art(ar);
                p.setIid_car(0);
                p.setIid(null);
                //Añadimos el precio
                listaPreciosIns.add(p);
            }

            //También actualizamos los precios en el artículo, como respaldo
            ar.setPrecioIncremento(p.getPi());
            ar.setPrecio_v(p.getPvp());
            ar.setPtc(p.getPtc());
            ar.setUpc(p.getUpc());
            ar.setObservaciones(tobservaciones.getText());
            ar.setIid_moneda(BaseDatos.obtenerMonedaNombre((String) cmoneda.getSelectedItem()));
            ar.setProv_hab(BaseDatos.obtenerProveedorNombreComercial((String) cproveedorh.getSelectedItem(), e));
            if (tRestoMinimo.isVisible() && !tRestoMinimo.getText().equals("")) {
                ar.setRestoMinimo(Float.parseFloat(Util.convertirComaAPunto(tRestoMinimo.getText())));
            } else {
                ar.setRestoMinimo(null);
            }

            if (cbCorteLiso.isVisible() && cbCorteLiso.isSelected()) {
                ar.setCorteLiso(true);
            } else {
                ar.setCorteLiso(false);
            }

            if (tStockMinimo.getText() != null && !tStockMinimo.getText().equals("")) {
                ar.setStockMinimo(Integer.valueOf(tStockMinimo.getText()));
            } else {
                ar.setStockMinimo(null);
            }

            ar.setMonocromo(this.bMonocromo.isSelected());

            if (crear) {
                //Creamos el articulo
                if (BaseDatos.obtenerArticulo(codigo, e.getIid()) == null) {
                    if (!BaseDatos.insertarArticulo(ar, listaCaracteristicas, listaEscalados, listaMovimientos, listaExistencias, lArticuloDescuentos, lAgenteArticulo, lAgenteArticuloCodigo, listaPreciosIns, "Creación manual", u.getNombre())) {
                        JOptionPane.showMessageDialog(null, "No se puede ha podido insertar el elemento", "Error", JOptionPane.ERROR_MESSAGE);
                    } else {
                        cerrarArticulo();
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Ya hay un articulo con el código " + codigo, "Error", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                int hacerCambios = 1;
                hacerCambios = JOptionPane.showConfirmDialog(null, "Está seguro de que desea realizar los cambios?", "¿Realizar cambios?", JOptionPane.YES_NO_OPTION);
                //hacerCambios = -1 ==> se ha pulsado la "x" de cancelar;
                //hacerCambios =  0 ==> se ha pulsado el "sí"
                //hacerCambios =  1 ==> se ha pulsado el "no"
                if (hacerCambios == 0) {
                    Articulo temp = null;

                    if (!codigo.equalsIgnoreCase(codigoAntiguo)) {
                        temp = BaseDatos.obtenerArticulo(codigo, e.getIid());
                    }

                    if (temp == null) {
                        if (BaseDatos.modificarArticulo(ar, listaCaracteristicas, listaEscalados, listaMovimientos, listaMovimientosBorrados, listaMovimientosCreados, actualizarMovExistencias, lArticuloDescuentos, lAgenteArticulo, lAgenteArticuloCodigo, listaPreciosIns, "Modificación manual", u.getNombre())) {
                            cerrarArticulo();
                        } else {
                            JOptionPane.showMessageDialog(null, "No se puede ha podido modificar el elemento", "Error", JOptionPane.ERROR_MESSAGE);
                        }
                    } else {
                        JOptionPane.showMessageDialog(null, "Ya hay un articulo con el código " + codigo, "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
            }
        } else {
            //Error, hay que rellenar todos los campos
            JOptionPane.showMessageDialog(null, "Debe rellenar los campos \"Código\" , \"Familia de Ventas\" y \"Descripción Técnica\"", "Error", JOptionPane.ERROR_MESSAGE);
        }
    } catch (NumberFormatException exc) {
        //Error, los campos numéricos no contienen números
        JOptionPane.showMessageDialog(null, "El campo \"Precio\", \"Descuento\" e \"Iva\" deben ser numérico", "Error", JOptionPane.ERROR_MESSAGE);
    }
}//GEN-LAST:event_baceptarActionPerformed

    private void establecerEdiccion(boolean editable) {
        tcodigo.setEnabled(editable);
        tdesctect.setEnabled(editable);
        tdescinf.setEnabled(editable);
        cfamiliav.setEnabled(editable);
        cunidadm.setEnabled(editable);
        cIva.setEnabled(editable);
        tobservaciones.setEnabled(editable);
        bactualizarstock.setEnabled(editable);
        bstockneg.setEnabled(editable);
        bstockmedida.setEnabled(editable);
        bstockcolor.setEnabled(editable);
        cproveedorh.setEnabled(editable);
        cmoneda.setEnabled(editable);
        bCrearInventario.setEnabled(editable);
        tExistencias.setEnabled(editable);
        tcaracteristicas.setEnabled(editable);
        bNuevaCaracteristica.setEnabled(editable);
        bEliminarCaracteristica.setEnabled(editable);
        bModificarCaracteristica.setEnabled(editable);
        bEscaladosCarFichero.setEnabled(editable);
        bEscaladosFichero.setEnabled(editable);
        tEscaladoArticulo.setEnabled(editable);
        bCrearEscaladoArticulo.setEnabled(editable);
        bBorrarEscaladoArticulo.setEnabled(editable);
        cbEscaladoArticulo.setEnabled(editable);
        cbEscaladoCaracteristica.setEnabled(editable);
        tagentearticulocodigo1.setEnabled(editable);
        bNuevoAA.setEnabled(editable);
        bEliminarAA.setEnabled(editable);
        bModificarAA.setEnabled(editable);
        if (!modInter) {
            tprecio.setEnabled(editable);
            tprecioIncremento.setEnabled(editable);
            tdescuento.setEnabled(editable);
        }
        tEscaladoCaracteristicas.setEnabled(editable);
        bNuevoEscaladoCaracteristica.setEnabled(editable);
        bEliminarEscaladoCaracteristica.setEnabled(editable);
        bCrearInventario.setEnabled(editable);
        bBorrarMovimiento.setEnabled(editable);
        tMovimientos.setEnabled(editable);
        cAlmacen.setEnabled(editable);

        if (!modInter) {
            tptc.setEnabled(editable);
            tupc.setEnabled(editable);
        }
        tRestoMinimo.setEnabled(editable);
        tStockMinimo.setEnabled(editable);
        cbCorteLiso.setEnabled(editable);
        bMonocromo.setEnabled(editable);
    }
private void bmodificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bmodificarActionPerformed
    if (bmodificar.getText().equals("Modificar")) {
        //Si el botón tiene el texto Modificar
        establecerEdiccion(true);
        bmodificar.setText("Visualizar");
        bmodificar.setToolTipText("Visualizar campos");
        URL urlModificar = getClass().getResource("/iconos/buscar.gif");
        ImageIcon iconoModificar = new ImageIcon(urlModificar);
        bmodificar.setIcon(iconoModificar);
    } else {
        //si el botón tiene el texto Visualizar
        establecerEdiccion(false);
        bmodificar.setText("Modificar");
        bmodificar.setToolTipText("Modificar campos");
        URL urlModificar = getClass().getResource("/iconos/editar.png");
        ImageIcon iconoModificar = new ImageIcon(urlModificar);
        bmodificar.setIcon(iconoModificar);
    }
}//GEN-LAST:event_bmodificarActionPerformed

    public int obtenerIndiceCaracteristica(Colores c) {
        boolean seguir = true;
        int res = 0, tam = listaCaracteristicas.size();
        Caracteristica car;
        while (seguir && res < tam) {
            car = listaCaracteristicas.get(res);
            if (car.getIid_color().equals(c)) {
                seguir = false;
            } else {
                res++;
            }
        }
        return res;
    }

    public int obtenerIndiceArticuloDescuento(TipoToldo tt) {
        boolean seguir = true;
        int res = 0, tam = lArticuloDescuentos.size();
        ArticuloDescuento dd;
        TipoToldo aux;
        while (seguir && res < tam) {
            dd = lArticuloDescuentos.get(res);
            aux = BaseDatos.obtenerTipoToldoPorIid(dd.getTipoToldo().getIid());
            if (aux.equals(tt)) {
                seguir = false;
            } else {
                res++;
            }
        }
        return res;
    }

    private int obtenerIndiceMovimiento(MovimientoAlmacen m) {
        boolean seguir = true;
        int res = 0, tam = listaMovimientos.size();
        MovimientoAlmacen ma;
        while (seguir && res < tam) {
            ma = listaMovimientos.get(res);
            if (ma.equals(m)) {
                seguir = false;
            } else {
                res++;
            }
        }
        return res;
    }

    private int obtenerIndiceExistencia(MovimientoAlmacen m) {
        boolean seguir = true;
        int res = 0, tam = listaExistencias.size();
        Existencia ex;
        while (seguir && res < tam) {
            ex = listaExistencias.get(res);
            if (ex.equalsMovimiento(m)) {
                seguir = false;
            } else {
                res++;
            }
        }

        if (seguir) {
            res = -1;
        }
        return res;
    }

    private void visualizarCaracteristica() {
        int indice = tcaracteristicas.getSelectedRow();
		
        if (indice >= 0) {
            String color = (String) tcaracteristicas.getModel().getValueAt(indice, 0);
            Colores c = BaseDatos.obtenerColor(color);
            int indiceCaracteristica = obtenerIndiceCaracteristica(c);
            Caracteristica car = listaCaracteristicas.get(indiceCaracteristica);
            Caracteristica aux = car.clonar();
            NuevaCaracteristica nc = new NuevaCaracteristica(this, "Características - Modificación", aux, listaPrecios);
            nc.setDefaultCloseOperation(NuevaCaracteristica.DISPOSE_ON_CLOSE);
            nc.setLocationRelativeTo(null);
            nc.setVisible(true);
            nc = null;
        } else {
            JOptionPane.showMessageDialog(null, "No hay seleccionado ninguna característica", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private Caracteristica obtenerCaracteristica(Colores c) {
        Caracteristica res = null, aux = null;
        boolean seguir = true;
        Iterator<Caracteristica> it = listaCaracteristicas.iterator();
        while (seguir && it.hasNext()) {
            aux = it.next();
            if (aux.getIid_color().equals(c)) {
                seguir = false;
                res = aux;
            }
        }
        return res;
    }
private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
    if (!crear) {
        BaseDatos.desUsarArticulo(ar.getIid());
    }
}//GEN-LAST:event_formWindowClosing

    private void bBorrarMovimientoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bBorrarMovimientoActionPerformed
        borrarMovimiento();
    }//GEN-LAST:event_bBorrarMovimientoActionPerformed

    private void tMovimientosKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tMovimientosKeyPressed
        if (evt.getKeyChar() == KeyEvent.VK_DELETE) {
            borrarMovimiento();
        }
    }//GEN-LAST:event_tMovimientosKeyPressed

    private void cAlmacenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cAlmacenActionPerformed
        String sAlmacen = (String) cAlmacen.getSelectedItem();
        if (listaExistencias != null && listaExistencias.size() > 0) {
            List<Existencia> lExistencias;
            if (sAlmacen.equals(Constantes.VACIO)) {
                lExistencias = listaExistencias;
            } else {
                lExistencias = new ArrayList<Existencia>();
                Iterator it = listaExistencias.iterator();
                Existencia ex;

                while (it.hasNext()) {
                    ex = (Existencia) it.next();
                    if (ex.getAlmacen().getNombre().equals(sAlmacen)) {
                        lExistencias.add(ex);
                    }
                }
            }
            actualizarExistencias(lExistencias);
        }

        if (listaMovimientos != null && listaMovimientos.size() > 0) {
            List<MovimientoAlmacen> lMovimientosAux;
            if (sAlmacen.equals(Constantes.VACIO)) {
                lMovimientosAux = listaMovimientos;
            } else {
                lMovimientosAux = new ArrayList<MovimientoAlmacen>();
                MovimientoAlmacen movAl;
                Iterator it = listaMovimientos.iterator();
                while (it.hasNext()) {
                    movAl = (MovimientoAlmacen) it.next();
                    if (movAl.getAlmacen().getNombre().equals(sAlmacen)) {
                        lMovimientosAux.add(movAl);
                    }
                }
            }
            actualizarMovimientos(lMovimientosAux);
        }
    }//GEN-LAST:event_cAlmacenActionPerformed

    private void bCrearInventarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bCrearInventarioActionPerformed
        if (!cfamiliav.getSelectedItem().equals(Constantes.VACIO)) {
            NuevoMovimientoAlmacen laa = new NuevoMovimientoAlmacen(ar, e, this, listaCaracteristicas);
            laa.setDefaultCloseOperation(NuevoMovimientoAlmacen.DISPOSE_ON_CLOSE);
            laa.setLocationRelativeTo(null);
            laa.setVisible(true);
        } else {
            JOptionPane.showMessageDialog(null, "No hay seleccionado ninguna familia de venta", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_bCrearInventarioActionPerformed

    private void bAaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bAaActionPerformed
        Caracteristica car = new Caracteristica();
        if (hayCaracteristicas) {
            int indice = tcaracteristicas.getSelectedRow();
            if (indice >= 0) {
                String color = (String) tcaracteristicas.getModel().getValueAt(indice, 0);
                Colores c = BaseDatos.obtenerColor(color);
                car = obtenerCaracteristica(c);
            }
        } else {
            car = null;
        }

        NuevoPresupuesto np = new NuevoPresupuesto(e, BaseDatos.getClaseDocumentosByDescripcion(Constantes.ALBARAN), u, ar, car, inter);
        np.setDefaultCloseOperation(NuevoPresupuesto.DISPOSE_ON_CLOSE);
        np.setLocationRelativeTo(null);
        np.setEnabled(true);

        if (!crear && ar.getIid() != null) {
            BaseDatos.desUsarArticulo(ar.getIid());
        }
    }//GEN-LAST:event_bAaActionPerformed

    private void bAcActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bAcActionPerformed
        Caracteristica car;
		//DUDA: XK ESTA ESTA VBLE??
        if (hayCaracteristicas) {
            int indice = tcaracteristicas.getSelectedRow();
            if (indice >= 0) {
                String color = (String) tcaracteristicas.getModel().getValueAt(indice, 0);
                Colores c = BaseDatos.obtenerColor(color);
                car = obtenerCaracteristica(c);
            }
        } else {
            car = null;
        }

        NuevoCompras np = new NuevoCompras(e, BaseDatos.getClaseDocumentosByDescripcion(Constantes.PEDIDOC), u, ar, null);
        np.setDefaultCloseOperation(NuevoPresupuesto.DISPOSE_ON_CLOSE);
        np.setLocationRelativeTo(null);
        np.setVisible(true);
        BaseDatos.desUsarArticulo(ar.getIid());
    }//GEN-LAST:event_bAcActionPerformed

    private void tagentearticulocodigo1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tagentearticulocodigo1KeyPressed
        if (evt.getKeyChar() == KeyEvent.VK_ENTER) {
            visualizarAgenteArticuloCodigo();
        } else if (evt.getKeyChar() == KeyEvent.VK_DELETE) {
            borrarAgenteArticuloCodigo();
        }
    }//GEN-LAST:event_tagentearticulocodigo1KeyPressed

    private void tagentearticulocodigo1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tagentearticulocodigo1MouseClicked
        if (evt.getClickCount() == 2) {
            visualizarAgenteArticuloCodigo();
        }
    }//GEN-LAST:event_tagentearticulocodigo1MouseClicked

    private void bNuevoAAActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bNuevoAAActionPerformed
        NuevoAgenteArticuloCodigo naac = new NuevoAgenteArticuloCodigo(this, ar, "Código de Artículos por Proveedor - Creación", e, 0);
        naac.setDefaultCloseOperation(NuevoAgenteArticuloCodigo.DISPOSE_ON_CLOSE);
        naac.setLocationRelativeTo(null);
        naac.setVisible(true);
        naac = null;
    }//GEN-LAST:event_bNuevoAAActionPerformed

    private void bModificarAAActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bModificarAAActionPerformed
        visualizarAgenteArticuloCodigo();
    }//GEN-LAST:event_bModificarAAActionPerformed

    private void bEliminarAAActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bEliminarAAActionPerformed
        borrarAgenteArticuloCodigo();
    }//GEN-LAST:event_bEliminarAAActionPerformed

    private void bConfigActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bConfigActionPerformed
        //Comprobamos si existe el articulo
        int error = guardar();
        if (error == 0) {
            NuevoDAC nd = new NuevoDAC(e, "Creación de prodcuto", ar);
            nd.setDefaultCloseOperation(NuevoPresupuesto.DISPOSE_ON_CLOSE);
            nd.setLocationRelativeTo(null);
            nd.setVisible(true);
        }
    }//GEN-LAST:event_bConfigActionPerformed

    private void bPreciosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bPreciosActionPerformed
        listaPreciosArt la = new listaPreciosArt(e, this.ar, 0);
        la.setDefaultCloseOperation(NuevaCaracteristica.DISPOSE_ON_CLOSE);
        la.setLocationRelativeTo(null);
        la.setVisible(true);
    }//GEN-LAST:event_bPreciosActionPerformed

    private void tfcKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tfcKeyReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_tfcKeyReleased

    private void tpmcKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tpmcKeyReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_tpmcKeyReleased

    private void tptcKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tptcKeyReleased
        int tamaño = tptc.getText().length();
        if (tamaño > 0) {
            char c = tptc.getText().charAt(tamaño - 1);

            if (c == '.') {
                String contenidoAntiguo = tptc.getText().replace(".", ",");
                tptc.setText(contenidoAntiguo);
                c = ',';
            }

            if (!((c >= '0' && c <= '9') || c == ',')) {
                String str = tptc.getText().substring(0, tamaño - 1);
                tptc.setText(str);
            } else if (c == ',') {
                int indicePunto = tptc.getText().indexOf(',');
                if (indicePunto != (tamaño - 1)) {
                    String str = tptc.getText().substring(0, tamaño - 1);
                    tptc.setText(str);
                }
            }
        }
    }//GEN-LAST:event_tptcKeyReleased

    private void tupcKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tupcKeyReleased
        int tamaño = tupc.getText().length();
        if (tamaño > 0) {
            char c = tupc.getText().charAt(tamaño - 1);

            if (c == '.') {
                String contenidoAntiguo = tupc.getText().replace(".", ",");
                tupc.setText(contenidoAntiguo);
                c = ',';
            }

            if (!((c >= '0' && c <= '9') || c == ',')) {
                String str = tupc.getText().substring(0, tamaño - 1);
                tupc.setText(str);
            } else if (c == ',') {
                int indicePunto = tupc.getText().indexOf(',');
                if (indicePunto != (tamaño - 1)) {
                    String str = tupc.getText().substring(0, tamaño - 1);
                    tupc.setText(str);
                }
            }
        }
    }//GEN-LAST:event_tupcKeyReleased

    private void tprecioIncrementoKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tprecioIncrementoKeyReleased
        int tamaño = tprecioIncremento.getText().length();
        if (tamaño > 0) {
            char c = tprecioIncremento.getText().charAt(tamaño - 1);

            if (c == '.') {
                String contenidoAntiguo = tprecioIncremento.getText().replace(".", ",");
                tprecioIncremento.setText(contenidoAntiguo);
                c = ',';
            }

            if (!((c >= '0' && c <= '9') || c == ',')) {
                String str = tprecioIncremento.getText().substring(0, tamaño - 1);
                tprecioIncremento.setText(str);
            } else if (c == ',') {
                int indicePunto = tprecioIncremento.getText().indexOf(',');
                if (indicePunto != (tamaño - 1)) {
                    String str = tprecioIncremento.getText().substring(0, tamaño - 1);
                    tprecioIncremento.setText(str);
                }
            }
        }
    }//GEN-LAST:event_tprecioIncrementoKeyReleased

    private void tprecioKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tprecioKeyReleased
        int tamaño = tprecio.getText().length();
        if (tamaño > 0) {
            char c = tprecio.getText().charAt(tamaño - 1);

            if (c == '.') {
                String contenidoAntiguo = tprecio.getText().replace(".", ",");
                tprecio.setText(contenidoAntiguo);
                c = ',';
            }

            if (!((c >= '0' && c <= '9') || c == ',')) {
                String str = tprecio.getText().substring(0, tamaño - 1);
                tprecio.setText(str);
            } else if (c == ',') {
                int indicePunto = tprecio.getText().indexOf(',');
                if (indicePunto != (tamaño - 1)) {
                    String str = tprecio.getText().substring(0, tamaño - 1);
                    tprecio.setText(str);
                }
            }
        }
    }//GEN-LAST:event_tprecioKeyReleased

    private void bEliminarEscaladoCaracteristicaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bEliminarEscaladoCaracteristicaActionPerformed
        borrarEscalado();
    }//GEN-LAST:event_bEliminarEscaladoCaracteristicaActionPerformed

    private void bNuevoEscaladoCaracteristicaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bNuevoEscaladoCaracteristicaActionPerformed
        int indice = tcaracteristicas.getSelectedRow();

        if (indice >= 0) {
            String color = (String) tcaracteristicas.getModel().getValueAt(indice, 0);
            Colores c = BaseDatos.obtenerColor(color);
            Caracteristica car = obtenerCaracteristica(c);

            NuevoEscaladoArticulo nea = new NuevoEscaladoArticulo(this, "Escalado - Creación", car);
            nea.setDefaultCloseOperation(NuevoEscaladoArticulo.DISPOSE_ON_CLOSE);
            nea.setLocationRelativeTo(null);
            nea.setVisible(true);

        } else {
            JOptionPane.showMessageDialog(null, "No hay seleccionado ninguna caracterÃ­stica", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_bNuevoEscaladoCaracteristicaActionPerformed

    private void tEscaladoCaracteristicasKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tEscaladoCaracteristicasKeyPressed
        if (evt.getKeyChar() == KeyEvent.VK_DELETE) {
            borrarEscalado();
        }
    }//GEN-LAST:event_tEscaladoCaracteristicasKeyPressed

    private void tEscaladoArticuloKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tEscaladoArticuloKeyPressed
        if (evt.getKeyChar() == KeyEvent.VK_DELETE) {
            borrarEscaladoArticulo();
        }
    }//GEN-LAST:event_tEscaladoArticuloKeyPressed

    private void bBorrarEscaladoArticuloActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bBorrarEscaladoArticuloActionPerformed
        borrarEscaladoArticulo();
    }//GEN-LAST:event_bBorrarEscaladoArticuloActionPerformed

    private void bCrearEscaladoArticuloActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bCrearEscaladoArticuloActionPerformed
        NuevoEscaladoArticulo nea = new NuevoEscaladoArticulo(this, "Escalado - Creación", ar);
        nea.setDefaultCloseOperation(NuevoEscaladoArticulo.DISPOSE_ON_CLOSE);
        nea.setLocationRelativeTo(null);
        nea.setVisible(true);
        nea = null;
    }//GEN-LAST:event_bCrearEscaladoArticuloActionPerformed

    private void bEscaladosFicheroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bEscaladosFicheroActionPerformed
        try {
            int eliminar = 1;
            eliminar = JOptionPane.showConfirmDialog(null, "¿Está seguro de que desea modificar los escalados existentes?", "¿Modificar?", JOptionPane.YES_NO_OPTION);
            //hacerCambios = -1 ==> se ha pulsado la "x" de cancelar;
            //hacerCambios =  0 ==> se ha pulsado el "sí"
            //hacerCambios =  1 ==> se ha pulsado el "no"

            if (eliminar == 0) {
                JFileChooser chooser = new JFileChooser();
                chooser.setDialogTitle("Escalados");
                chooser.setMultiSelectionEnabled(false);
                chooser.setFileSelectionMode(JFileChooser.FILES_ONLY);

                int sel = chooser.showOpenDialog(this);
                if (sel == JFileChooser.APPROVE_OPTION) {
                    File selectedFile = chooser.getSelectedFile();
                    Workbook workbook = Workbook.getWorkbook(new File(selectedFile.getAbsolutePath()));
                    rellenarEscalados(workbook);
                    actualizarEscaladosArticulos();
                    JOptionPane.showMessageDialog(null, "Los escalados se han cargado correctamente", "Información", JOptionPane.INFORMATION_MESSAGE);
                }
            }
        } catch (Exception ex) {
        }
    }//GEN-LAST:event_bEscaladosFicheroActionPerformed

    private void cbEscaladoArticuloActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbEscaladoArticuloActionPerformed
        if (cbEscaladoArticulo.isSelected()) {
            //Hay que mostrar la tabla de escalado del artículo
            pEscaladoArticulo.setEnabled(true);
            bEscaladosFichero.setEnabled(true);
            bEscaladosFichero.setEnabled(true);
        } else {
            pEscaladoArticulo.setEnabled(false);
            bEscaladosFichero.setEnabled(false);
            //Hay que borrar el contenido de la tabla de escalado
            listaEscalados = new ArrayList<Escalado>();
            actualizarEscaladosArticulos();
        }
    }//GEN-LAST:event_cbEscaladoArticuloActionPerformed

    private void tdescuentoKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tdescuentoKeyReleased
        int tamaño = tdescuento.getText().length();
        if (tamaño > 0) {
            char c = tdescuento.getText().charAt(tamaño - 1);

            if (c == '.') {
                String contenidoAntiguo = tdescuento.getText().replace(".", ",");
                tdescuento.setText(contenidoAntiguo);
                c = ',';
            }

            if (!((c >= '0' && c <= '9') || c == ',')) {
                String str = tdescuento.getText().substring(0, tamaño - 1);
                tdescuento.setText(str);
            } else if (c == ',') {
                int indicePunto = tdescuento.getText().indexOf(',');
                if (indicePunto != (tamaño - 1)) {
                    String str = tdescuento.getText().substring(0, tamaño - 1);
                    tdescuento.setText(str);
                }
            }
        }
    }//GEN-LAST:event_tdescuentoKeyReleased

    private void bEliminarCaracteristicaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bEliminarCaracteristicaActionPerformed
        borrarCaracteristica();
    }//GEN-LAST:event_bEliminarCaracteristicaActionPerformed

    private void bModificarCaracteristicaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bModificarCaracteristicaActionPerformed
        visualizarCaracteristica();
    }//GEN-LAST:event_bModificarCaracteristicaActionPerformed

    private void bNuevaCaracteristicaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bNuevaCaracteristicaActionPerformed
        if (!cfamiliav.getSelectedItem().equals(Constantes.VACIO)) {
            int crearCaracteristica = 0;
            if (!hayCaracteristicas) {
                crearCaracteristica = 1;
                crearCaracteristica = JOptionPane.showConfirmDialog(null, "Si crea una caracterÃ­stica las existencias y escalados de este artÃ­culo se asociarÃ¡n a dicha caracterÃ­stica. Â¿EstÃ¡ seguro?", "InformaciÃ³n", JOptionPane.YES_NO_OPTION);
                //seguroCrear = -1 ==> se ha pulsado la "x" de cancelar;
                //seguroCrear =  0 ==> se ha pulsado el "sÃ­"
                //seguroCrear =  1 ==> se ha pulsado el "no"
            }

            if (crearCaracteristica == 0) {
                NuevaCaracteristica nc = new NuevaCaracteristica(this, "CaracterÃ­sticas - CreaciÃ³n", ar, e);
                nc.setDefaultCloseOperation(NuevaCaracteristica.DISPOSE_ON_CLOSE);
                nc.setLocationRelativeTo(null);
                nc.setVisible(true);
                nc = null;
            }
        } else {
            JOptionPane.showMessageDialog(null, "No hay seleccionado ninguna familia de venta", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_bNuevaCaracteristicaActionPerformed

    private void bEscaladosCarFicheroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bEscaladosCarFicheroActionPerformed
        try {
            int eliminar = 1;
            eliminar = JOptionPane.showConfirmDialog(null, "¿Está seguro de que desea modificar los escalados existentes?", "¿Modificar?", JOptionPane.YES_NO_OPTION);
            //hacerCambios = -1 ==> se ha pulsado la "x" de cancelar;
            //hacerCambios =  0 ==> se ha pulsado el "sí"
            //hacerCambios =  1 ==> se ha pulsado el "no"

            if (eliminar == 0) {
                JFileChooser chooser = new JFileChooser();
                chooser.setDialogTitle("Escalados");
                chooser.setMultiSelectionEnabled(false);
                chooser.setFileSelectionMode(JFileChooser.FILES_ONLY);

                int sel = chooser.showOpenDialog(this);
                if (sel == JFileChooser.APPROVE_OPTION) {
                    File selectedFile = chooser.getSelectedFile();

                    Workbook workbook = Workbook.getWorkbook(new File(selectedFile.getAbsolutePath()));
                    rellenarEscalados(workbook);
                    int indice = tcaracteristicas.getSelectedRow();
                    String color = (String) tEscaladoCaracteristicas.getModel().getValueAt(indice, 0);
                    Colores c = BaseDatos.obtenerColor(color);
                    Caracteristica car = obtenerCaracteristica(c);

                    actualizarEscaladosCaracteristicas(car);
                    JOptionPane.showMessageDialog(null, "Los escalados se han cargado correctamente", "Información", JOptionPane.INFORMATION_MESSAGE);
                }

            }
        } catch (Exception ex) {
        }
    }//GEN-LAST:event_bEscaladosCarFicheroActionPerformed

    private void cbEscaladoCaracteristicaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbEscaladoCaracteristicaActionPerformed
        if (cbEscaladoCaracteristica.isSelected()) {
            //Hay que mostrar la tabla de escalado del artículo
            pEscaladoCaracteristica.setEnabled(true);
            bEscaladosCarFichero.setEnabled(true);
            bEscaladosCarFichero.setEnabled(true);
        } else {
            pEscaladoCaracteristica.setEnabled(false);
            bEscaladosCarFichero.setEnabled(false);
            bEscaladosCarFichero.setEnabled(true);
            //Hay que borrar el contenido de la tabla de escalado
            listaEscalados = new ArrayList<Escalado>();
            int indice = tcaracteristicas.getSelectedRow();
            String color = (String) tEscaladoCaracteristicas.getModel().getValueAt(indice, 0);
            Colores c = BaseDatos.obtenerColor(color);
            Caracteristica car = obtenerCaracteristica(c);
            actualizarEscaladosCaracteristicas(car);
        }
    }//GEN-LAST:event_cbEscaladoCaracteristicaActionPerformed

    private void tcaracteristicasKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tcaracteristicasKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_tcaracteristicasKeyPressed

    private void tcaracteristicasMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tcaracteristicasMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_tcaracteristicasMouseClicked

    private void tStockMinimoKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tStockMinimoKeyReleased
        int tamaño = tStockMinimo.getText().length();
        if (tamaño > 0) {
            char c = tStockMinimo.getText().charAt(tamaño - 1);
            if (!(c >= '0' && c <= '9')) {
                String str = tStockMinimo.getText().substring(0, tamaño - 1);
                tStockMinimo.setText(str);
            }
        }
    }//GEN-LAST:event_tStockMinimoKeyReleased

    private void tRestoMinimoKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tRestoMinimoKeyReleased
        int tamaño = tRestoMinimo.getText().length();
        if (tamaño > 0) {
            char c = tRestoMinimo.getText().charAt(tamaño - 1);

            if (c == '.') {
                String contenidoAntiguo = tRestoMinimo.getText().replace(".", ",");
                tRestoMinimo.setText(contenidoAntiguo);
                c = ',';
            }

            if (!((c >= '0' && c <= '9') || c == ',')) {
                String str = tRestoMinimo.getText().substring(0, tamaño - 1);
                tRestoMinimo.setText(str);
            } else if (c == ',') {
                int indicePunto = tRestoMinimo.getText().indexOf(',');
                if (indicePunto != (tamaño - 1)) {
                    String str = tRestoMinimo.getText().substring(0, tamaño - 1);
                    tRestoMinimo.setText(str);
                }
            }
        }
    }//GEN-LAST:event_tRestoMinimoKeyReleased

    private void tobservacionesKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tobservacionesKeyReleased
        String obs = tobservaciones.getText();
        if (obs.length() > Constantes.TAM_OBSERVACIONES_ARTICULO) {
            JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_OBSERVACIONES_ARTICULO, "Error", JOptionPane.ERROR_MESSAGE);
            tobservaciones.setText(obs.substring(0, Constantes.TAM_OBSERVACIONES_ARTICULO));
        }
    }//GEN-LAST:event_tobservacionesKeyReleased

    private void tobservacionesKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tobservacionesKeyPressed
        if (evt.getKeyCode() == KeyEvent.VK_TAB) {
            cunidadm.requestFocus();
        }
    }//GEN-LAST:event_tobservacionesKeyPressed

    private void cfamiliavActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cfamiliavActionPerformed
        String familiaVenta = (String) cfamiliav.getSelectedItem();
        if (!familiaVenta.equals(Constantes.VACIO)) {
            this.fv = BaseDatos.obtenerFamiliaVentaPorNombre(e, familiaVenta);
            ar.setIid_fam_venta(fv);

            if (fv.getIid_tipo_control() != null) {
                TipoControl tp = BaseDatos.obtenerTipoControlPorIid(fv.getIid_tipo_control().getIid());
                this.tc = tp;
                this.um = BaseDatos.obtenerUnidadMedidaIid(tp.getUnidadResultado().getIid());
                ttipoControl.setText(tp.getNombre());
                this.tm = BaseDatos.obtenerTipoMedidaByIid(tp.getIid_tipo_medida().getIid());
                cunidadm.setSelectedItem(um.getNombre());
                numMedidas = numMedidas();
            } else {
                ttipoControl.setText(Constantes.VACIO);
            }

            if (fv.getConfeccionable()) {
                //Activamos el corte liso
                cbCorteLiso.setEnabled(true);
                tRestoMinimo.setEnabled(true);
            } else {
                cbCorteLiso.setEnabled(true);
                tRestoMinimo.setEnabled(true);
            }

            if (fv.getCod_familia().equals("PC")) {
                bConfig.setEnabled(true);
                //jTabbedPane1.setEnabledAt(jTabbedPane1.indexOfTab("Existencias"),false);
                bAc.setEnabled(false);
            } else {
                bConfig.setEnabled(false);
                //jTabbedPane1.setEnabledAt(jTabbedPane1.indexOfTab("Existencias"),true);
                bAc.setEnabled(true);
            }

            if (crear) {
                //En el caso que estemos creando, añadimos los colores de la familia
                List lColores = BaseDatos.getColoresPorFamilia(e.getIid(), fv.getIid());
                //Borramos las caracteristicas
                if (lColores != null) {
                    listaCaracteristicas.clear();
                    listaPrecios.clear();
                    Iterator itC = lColores.iterator();
                    Caracteristica ca = new Caracteristica();
                    Date fecha = new Date();
                    while (itC.hasNext()) {
                        colorFamilia cf = (colorFamilia) itC.next();
                        Colores c = BaseDatos.obtenerColorPorIid(cf.getIidColor());
                        ca = new Caracteristica();
                        ca.setIid_articulo(ar);
                        ca.setIid_color(c);
                        ca.setIid_empresa(e);
                        ca.setStock_max(false);
                        ca.setStock_min(false);
                        ca.setEscalado(false);
                        ca.setCond_pedir(false);

                        //Comprobar precio parametrizado
                        precioFamilia pF = BaseDatos.obtenerPrecioFamilia(e, fv, c.getRal().toString());
                        Float pvp = Matematico.redondear2decimales(pF.getPvp());
                        ca.setPvp(pvp);
                        
                        ca.setPtc(pF.getPtc());
                        ca.setUpc(pF.getUpc());

                        listaCaracteristicas.add(ca);

                        //Añadir lista precio
                        Precios p = new Precios();
                        p.setIid_empresa(e);
                        p.setIid_art(ar);
                        p.setIid_car(ca.getIid_color().getIid());
                        p.setPvp(pF.getPvp());
                        p.setPtc(pF.getPtc());
                        p.setUpc(pF.getUpc());
                        p.setPi(0F);
                        p.setFecha(fecha.getTime());

                        listaPrecios.add(p);
                        listaPreciosIns.add(p);
                    }
                    actualizarCaracteristicas(listaPrecios);
                }
            }

            actualizarMovimientos(listaMovimientos);
            if (fv.getConfeccionable() != null && fv.getConfeccionable()) {
                tRestoMinimo.setEnabled(true);
                lRestoMinimo.setEnabled(true);
                cbCorteLiso.setEnabled(true);
            } else {
                tRestoMinimo.setEnabled(false);
                lRestoMinimo.setEnabled(false);
                cbCorteLiso.setEnabled(false);
            }

        }
    }//GEN-LAST:event_cfamiliavActionPerformed

    private void tcodigoKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tcodigoKeyReleased
        String codigo = tcodigo.getText();
        if (codigo.length() > Constantes.TAM_CODIGO_ARTICULO) {
            JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_CODIGO_ARTICULO, "Error", JOptionPane.ERROR_MESSAGE);
            tcodigo.setText(codigo.substring(0, Constantes.TAM_CODIGO_ARTICULO));
        }
    }//GEN-LAST:event_tcodigoKeyReleased

    private void tdescinfKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tdescinfKeyReleased
        String desc = tdescinf.getText();
        if (desc.length() > Constantes.TAM_DESCRIPCION_INFORMATIVA_ARTICULO) {
            JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_DESCRIPCION_INFORMATIVA_ARTICULO, "Error", JOptionPane.ERROR_MESSAGE);
            tdescinf.setText(desc.substring(0, Constantes.TAM_DESCRIPCION_INFORMATIVA_ARTICULO));
        }
    }//GEN-LAST:event_tdescinfKeyReleased

    private void tdescinfKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tdescinfKeyPressed
        if (evt.getKeyCode() == KeyEvent.VK_TAB) {
            bactualizarstock.requestFocus();
        }
    }//GEN-LAST:event_tdescinfKeyPressed

    private void tdesctectKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tdesctectKeyReleased
        String desc = tdesctect.getText();
        if (desc.length() > Constantes.TAM_DESCRIPCION_TECNICA_ARTICULO) {
            JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_DESCRIPCION_TECNICA_ARTICULO, "Error", JOptionPane.ERROR_MESSAGE);
            tdesctect.setText(desc.substring(0, Constantes.TAM_DESCRIPCION_TECNICA_ARTICULO));
        }
    }//GEN-LAST:event_tdesctectKeyReleased

    private void tdesctectKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tdesctectKeyPressed
        if (evt.getKeyCode() == KeyEvent.VK_TAB) {
            tdescinf.requestFocus();
        }
    }//GEN-LAST:event_tdesctectKeyPressed

    private void cproveedorhActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cproveedorhActionPerformed
        prov = BaseDatos.obtenerProveedorNombreComercial((String) cproveedorh.getSelectedItem(), e);
        // Si se ha cambiado el proveedor, volvemos a calcular
         if (ar != null && prov != null && ((ar.getProv_hab() == null && prov != null ) || !prov.getIid().equals(ar.getProv_hab().getIid()))) {
            calPreciosProv();
        }

    }//GEN-LAST:event_cproveedorhActionPerformed

    protected boolean insertarArticuloDescuento(ArticuloDescuento ad) {
        boolean res = true;
        if (lArticuloDescuentos.contains(ad)) {
            //Si no se ha insertado mostramos un mensaje de error
            JOptionPane.showMessageDialog(null, "El tipo de toldo ya existe", "Error", JOptionPane.ERROR_MESSAGE);
            res = false;
        } else {
            lArticuloDescuentos.add(ad);
            actualizarArticuloDescuentos();
        }
        return res;
    }

    private void actualizarArticuloDescuentos() {

        /*Modelo modelo = (Modelo) tDescuentos.getModel();
         int i, j;


         //obtenemos el nº de filas;
         j = modelo.getRowCount();

         //eliminamos todas las filas
         for (i = 0; i < j; i++) {
         modelo.removeRow(0);
         }

         TipoToldo tt;
         List listaAuxDescuento = lArticuloDescuentos;
         ArticuloDescuento ad;
         Object[] fila;
         for (Iterator itD = listaAuxDescuento.iterator(); itD.hasNext();) {
         fila = new Object[6];
         ad = (ArticuloDescuento) itD.next();
         tt = BaseDatos.obtenerTipoToldoPorIid(ad.getTipoToldo().getIid());
         fila[0] = tt.getCodigo();
         fila[1] = ad.getLargoLona();
         fila[2] = ad.getAnchoLona();
         fila[3] = ad.getTuboEnrrollado();
         fila[4] = ad.getPerfilCarga();
         modelo.addRow(fila);
         }*/
    }

    protected boolean modificarArticuloDescuento(ArticuloDescuento ad) {
        boolean res = true;
        /*   int indice = tDescuentos.getSelectedRow();
         String tipoToldo = (String) tDescuentos.getModel().getValueAt(indice, 0);
         TipoToldo tt = BaseDatos.obtenerTipoToldoPorCodigo(tipoToldo);
         int indiceArticuloDescuentoAntiguo = obtenerIndiceArticuloDescuento(tt);
        
         if(this.lArticuloDescuentos.contains(ad) && !tt.getCodigo().equals(ad.getTipoToldo().getCodigo())){
         res = false;
         JOptionPane.showMessageDialog(null, "El tipo de toldo ya existe", "Error", JOptionPane.ERROR_MESSAGE);
         } else {
         lArticuloDescuentos.remove(indiceArticuloDescuentoAntiguo);
         lArticuloDescuentos.add(indiceArticuloDescuentoAntiguo, ad);
         actualizarArticuloDescuentos();
         }*/
        return res;
    }

    private void rellenarEscaladosCaracteristicas(int hoja, Workbook workbook) {

        Sheet sheet;
        String nombreHoja;
        int columna, numColumnas;
        int fila, numFilas;
        List<Integer> lColumnas;
        List<Integer> lFilas;
        Float cell;
        Escalado escalado;

        //Obtenemos la hoja a analizar
        sheet = workbook.getSheet(hoja);

        //Calculamos el nombre de la hoja excel
        nombreHoja = sheet.getName();

        //Obtemenos el color
        Colores c = BaseDatos.obtenerColorPorDescripcion(nombreHoja);

        //Obtemenos la característica
        Caracteristica caract = obtenerCaracteristica(c);

        //Calculamos el número de columnas
        numColumnas = sheet.getColumns();

        //Calculamos el numero de filas
        numFilas = sheet.getRows();

        //Rellenamos la lista con las columnas
        lColumnas = new ArrayList<Integer>();
        for (columna = 1; columna < numColumnas; columna++) {
            lColumnas.add(columna - 1, Integer.parseInt(sheet.getCell(columna, 0).getContents()));
        }

        //Rellenamos la lista con las filas
        lFilas = new ArrayList<Integer>();
        for (fila = 1; fila < numFilas; fila++) {
            lFilas.add(fila - 1, Integer.parseInt(sheet.getCell(0, fila).getContents()));
        }

        //Calculamos cada elemento [fila,columna]=Dato
        int posEscalado;
		for (fila = 1; fila < numFilas; fila++) {
            for (columna = 1; columna < numColumnas; columna++) {
                cell = Float.parseFloat(sheet.getCell(columna, fila).getContents());
                posEscalado = obtenerPosicionEscaladoCaracteristica(lFilas.get(fila - 1), lColumnas.get(columna - 1), caract);
                if (posEscalado != -1) {
                    escalado = listaEscalados.get(posEscalado);
                    escalado.setPrecio(cell);
                    listaEscalados.remove(posEscalado);
                    listaEscalados.add(posEscalado, escalado);
                } else {
                    escalado = new Escalado();
                    escalado.setArticulo(ar);
                    escalado.setCaracteristica(caract);
                    escalado.setDimension1(lFilas.get(fila - 1));
                    escalado.setDimension2(lColumnas.get(columna - 1));
                    escalado.setPrecio(cell);
                    listaEscalados.add(escalado);
                }
            }
        }
    }

    private void rellenarEscalados(Workbook workbook) {
        Sheet sheet;
        int columna, numColumnas;
        int fila, numFilas;
        List<Integer> lColumnas;
        List<Integer> lFilas;
        Float cell;
        Escalado escalado;

        //Obtenemos la hoja a analizar
        sheet = workbook.getSheet(0);

        //Calculamos el número de columnas
        numColumnas = sheet.getColumns();

        //Calculamos el numero de filas
        numFilas = sheet.getRows();

        //Rellenamos la lista con las columnas
        lColumnas = new ArrayList<Integer>();
        for (columna = 1; columna < numColumnas; columna++) {
            lColumnas.add(columna - 1, Integer.parseInt(sheet.getCell(columna, 0).getContents()));
        }

        //Rellenamos la lista con las filas
        lFilas = new ArrayList<Integer>();
        for (fila = 1; fila < numFilas; fila++) {
            lFilas.add(fila - 1, Integer.parseInt(sheet.getCell(0, fila).getContents()));
        }

        //Calculamos cada elemento [fila,columna]=Dato
        int posEscalado;
		for (fila = 1; fila < numFilas; fila++) {
            for (columna = 1; columna < numColumnas; columna++) {
                cell = Float.parseFloat(sheet.getCell(columna, fila).getContents());
                posEscalado = obtenerPosicionEscaladoArticulo(lFilas.get(fila - 1), lColumnas.get(columna - 1));
                if (posEscalado != -1) {
                    escalado = listaEscalados.get(posEscalado);
                    listaEscalados.remove(posEscalado);
                    escalado.setPrecio(cell);
                    listaEscalados.add(posEscalado, escalado);
                } else {
                    escalado = new Escalado();
                    escalado.setArticulo(ar);
                    escalado.setCaracteristica(null);
                    escalado.setDimension1(lFilas.get(fila - 1));
                    escalado.setDimension2(lColumnas.get(columna - 1));
                    escalado.setPrecio(cell);
                    listaEscalados.add(escalado);
                }
            }
        }
        actualizarEscaladosArticulos();
    }

    private int obtenerPosicionEscaladoCaracteristica(Integer dim1, Integer dim2, Caracteristica caract) {
        boolean seguir = true;
        int res = 0, tam = listaEscalados.size();
        Escalado esc;

        while (seguir && res < tam) {
            esc = listaEscalados.get(res);
            if (esc.getDimension1().equals(dim1) && esc.getDimension2().equals(dim2) && esc.getCaracteristica().getIid_color().equals(caract.getIid_color())) {
                seguir = false;
            } else {
                res++;
            }
        }

        if (seguir) {
            res = -1;
        }
        return res;
    }

    private int obtenerPosicionEscaladoArticulo(Integer dim1, Integer dim2) {
        boolean seguir = true;
        int res = 0, tam = listaEscalados.size();
        Escalado esc;

        while (seguir && res < tam) {
            esc = listaEscalados.get(res);
            if (esc.getDimension1().equals(dim1) && esc.getDimension2().equals(dim2)) {
                seguir = false;
            } else {
                res++;
            }
        }

        if (seguir) {
            res = -1;
        }

        return res;
    }

    protected void actualizarMovimientos(List<MovimientoAlmacen> lMovimientos) {
        Modelo modelot = (Modelo) tMovimientos.getModel();
        int i, j = modelot.getRowCount();

        //eliminamos todas las filas
        for (i = 0; i < j; i++) {
            modelot.removeRow(0);
        }

        modelot = new Modelo();
        tMovimientos.setModel(modelot);
        modelot.addColumn("Concepto");
        modelot.addColumn("Almacén");
        modelot.addColumn("Fecha");
        modelot.addColumn("Característica");
        modelot.addColumn("Tipo");
        modelot.addColumn("Cantidad");

        SimpleDateFormat formatoFecha = new SimpleDateFormat("dd/MM/yyyy");

        if (numMedidas() == 1) {
            modelot.addColumn(tm.getNombre_dim_1());
        } else if (numMedidas() == 2) {
            modelot.addColumn(tm.getNombre_dim_1());
            modelot.addColumn(tm.getNombre_dim_2());
        } else if (numMedidas() == 3) {
            modelot.addColumn(tm.getNombre_dim_1());
            modelot.addColumn(tm.getNombre_dim_2());
            modelot.addColumn(tm.getNombre_dim_3());
        } else if (numMedidas() == 4) {
            modelot.addColumn(tm.getNombre_dim_1());
            modelot.addColumn(tm.getNombre_dim_2());
            modelot.addColumn(tm.getNombre_dim_3());
            modelot.addColumn(tm.getNombre_dim_4());
        } else if (numMedidas() == 5) {
            modelot.addColumn(tm.getNombre_dim_1());
            modelot.addColumn(tm.getNombre_dim_2());
            modelot.addColumn(tm.getNombre_dim_3());
            modelot.addColumn(tm.getNombre_dim_4());
            modelot.addColumn(tm.getNombre_dim_5());
        }

        if (lMovimientos == null) {
            lMovimientos = new ArrayList<MovimientoAlmacen>();
        }

        Iterator<MovimientoAlmacen> it0 = lMovimientos.iterator();
        MovimientoAlmacen mov;
        Object[] fila4;
        while (it0.hasNext()) {
            fila4 = new Object[6 + numMedidas()];
            mov = it0.next();
            fila4[0] = mov.getConcepto();
            fila4[1] = mov.getAlmacen().getNombre();
            fila4[2] = formatoFecha.format(new Date(mov.getFecha()));
            fila4[3] =(mov.getCaracteristica() != null) ? mov.getCaracteristica().getIid_color().getCod_color() : "--";
            fila4[4] = mov.getTipoMovimiento().getNombre();
            fila4[5] = Util.convertirPuntoAComa(mov.getCantidad().toString());

            if (numMedidas() == 1) {
                fila4[6] = Util.convertirPuntoAComa(mov.getCantidad1().toString());
            } else if (numMedidas() == 2) {
                fila4[6] = Util.convertirPuntoAComa(mov.getCantidad1().toString());
                fila4[7] = Util.convertirPuntoAComa(mov.getCantidad2().toString());
            } else if (numMedidas() == 3) {
                fila4[6] = Util.convertirPuntoAComa(mov.getCantidad1().toString());
                fila4[7] = Util.convertirPuntoAComa(mov.getCantidad2().toString());
                fila4[8] = Util.convertirPuntoAComa(mov.getCantidad3().toString());
            } else if (numMedidas() == 4) {
                fila4[6] = Util.convertirPuntoAComa(mov.getCantidad1().toString());
                fila4[7] = Util.convertirPuntoAComa(mov.getCantidad2().toString());
                fila4[8] = Util.convertirPuntoAComa(mov.getCantidad3().toString());
                fila4[9] = Util.convertirPuntoAComa(mov.getCantidad4().toString());
            } else if (numMedidas() == 5) {
                fila4[6] = Util.convertirPuntoAComa(mov.getCantidad1().toString());
                fila4[7] = Util.convertirPuntoAComa(mov.getCantidad2().toString());
                fila4[8] = Util.convertirPuntoAComa(mov.getCantidad3().toString());
                fila4[9] = Util.convertirPuntoAComa(mov.getCantidad4().toString());
                fila4[10] = Util.convertirPuntoAComa(mov.getCantidad5().toString());
            }
            modelot.addRow(fila4);
        }
    }

    private void actualizarExistencias(List<Existencia> lExistencia) {
        Modelo model = (Modelo) this.tExistencias.getModel();
        int i, j = model.getRowCount();

        //eliminamos todas las filas
        for (i = 0; i < j; i++) {
            model.removeRow(0);
        }

        model = new Modelo();
        tExistencias.setModel(model);
        model.addColumn("Almacén");
        model.addColumn("Característica");

        if (this.numMedidas == 1) {
            model.addColumn(tm.getNombre_dim_1());
        } else if (numMedidas == 2) {
            model.addColumn(tm.getNombre_dim_1());
            model.addColumn(tm.getNombre_dim_2());
        } else if (numMedidas == 3) {
            model.addColumn(tm.getNombre_dim_1());
            model.addColumn(tm.getNombre_dim_2());
            model.addColumn(tm.getNombre_dim_3());
        } else if (numMedidas == 4) {
            model.addColumn(tm.getNombre_dim_1());
            model.addColumn(tm.getNombre_dim_2());
            model.addColumn(tm.getNombre_dim_3());
            model.addColumn(tm.getNombre_dim_4());
        } else if (numMedidas == 5) {
            model.addColumn(tm.getNombre_dim_1());
            model.addColumn(tm.getNombre_dim_2());
            model.addColumn(tm.getNombre_dim_3());
            model.addColumn(tm.getNombre_dim_4());
            model.addColumn(tm.getNombre_dim_5());
        }
        model.addColumn("Existencias");

        if (lExistencia == null) {
            lExistencia = new ArrayList<Existencia>();
        }

        Object[] fila;
        Existencia ex;
        Iterator<Existencia> it = lExistencia.iterator();

        while (it.hasNext()) {
            fila = new Object[3 + numMedidas()];
            ex = it.next();
            fila[0] = ex.getAlmacen().getNombre();
            fila[1] = (ex.getCaracteristica() != null) ? ex.getCaracteristica().getIid_color().getCod_color() : "--";
            
			if (numMedidas() == 1) {
                fila[2] = Util.convertirPuntoAComa(ex.getCantidad1().toString());
            } else if (numMedidas() == 2) {
                fila[2] = Util.convertirPuntoAComa(ex.getCantidad1().toString());
                fila[3] = Util.convertirPuntoAComa(ex.getCantidad2().toString());
            } else if (numMedidas() == 3) {
                fila[2] = Util.convertirPuntoAComa(ex.getCantidad1().toString());
                fila[3] = Util.convertirPuntoAComa(ex.getCantidad2().toString());
                fila[4] = Util.convertirPuntoAComa(ex.getCantidad3().toString());
            } else if (numMedidas() == 4) {
                fila[2] = Util.convertirPuntoAComa(ex.getCantidad1().toString());
                fila[3] = Util.convertirPuntoAComa(ex.getCantidad2().toString());
                fila[4] = Util.convertirPuntoAComa(ex.getCantidad3().toString());
                fila[5] = Util.convertirPuntoAComa(ex.getCantidad4().toString());
            } else if (numMedidas() == 5) {
                fila[2] = Util.convertirPuntoAComa(ex.getCantidad1().toString());
                fila[3] = Util.convertirPuntoAComa(ex.getCantidad2().toString());
                fila[4] = Util.convertirPuntoAComa(ex.getCantidad3().toString());
                fila[5] = Util.convertirPuntoAComa(ex.getCantidad4().toString());
                fila[6] = Util.convertirPuntoAComa(ex.getCantidad5().toString());
            }
            fila[2 + numMedidas()] = Util.convertirPuntoAComa(ex.getExistencia().toString());
            model.addRow(fila);
        }
    }

    private int numMedidas() {
        return tm.getNum_dimensiones();
    }

    public void insertarMovimientoExistencia(MovimientoAlmacen mva) {
        int insertar = 0;
        boolean existe = false;
        Float cantidadAntigua = 0F;

        if (listaMovimientos.contains(mva)) {
            insertar = JOptionPane.showConfirmDialog(null, "Este movimiento ya existe, ¿desea sobreescribirlo?", "¿Realizar cambios?", JOptionPane.YES_NO_OPTION);
            //insertar = -1 ==> se ha pulsado la "x" de cancelar;
            //insertar =  0 ==> se ha pulsado el "sí"
            //insertar =  1 ==> se ha pulsado el "no"
            existe = true;
        }

        if (insertar == 0) {
            if (existe) {
                int indice = this.obtenerIndiceMovimiento(mva);
                MovimientoAlmacen movAntiguo = listaMovimientos.get(indice);
                cantidadAntigua = movAntiguo.getCantidad();
                listaMovimientos.remove(indice);
                if (movAntiguo.getIid() != null) {
                    listaMovimientosBorrados.add(movAntiguo);
                }
                listaMovimientos.add(indice, mva);
            } else {
                listaMovimientos.add(mva);
            }
            listaMovimientosCreados.add(mva);

            int indiceExistencia = this.obtenerIndiceExistencia(mva);
            Existencia ex;
            ex = new Existencia();
            ex.setAlmacen(mva.getAlmacen());
            ex.setArticulo(mva.getArticulo());
            ex.setCantidad1(mva.getCantidad1());
            ex.setCantidad2(mva.getCantidad2());
            ex.setCantidad3(mva.getCantidad3());
            ex.setCantidad4(mva.getCantidad4());
            ex.setCantidad5(mva.getCantidad5());
            ex.setUnidadMedida1(mva.getUnidadMedida1());
            ex.setUnidadMedida2(mva.getUnidadMedida2());
            ex.setUnidadMedida3(mva.getUnidadMedida3());
            ex.setUnidadMedida4(mva.getUnidadMedida4());
            ex.setUnidadMedida5(mva.getUnidadMedida5());
            ex.setUnidadMedidaTotal(mva.getUnidadMedidaTotal());
            if (mva.getCaracteristica() != null) {
                ex.setCaracteristica(mva.getCaracteristica());
            }

            ex.setEmpresa(mva.getEmpresa());
            if (indiceExistencia == -1) {
                //Se crea la existencia
                ex.setExistencia(mva.getCantidad());
                listaExistencias.add(ex);
            } else {
                //Se actualiza la existencia
                Existencia exAntigua = listaExistencias.get(indiceExistencia);
                ex.setIid(exAntigua.getIid());
                listaExistencias.remove(indiceExistencia);
                ex.setExistencia(exAntigua.getExistencia() + mva.getCantidad() - cantidadAntigua);
                listaExistencias.add(indiceExistencia, ex);
            }
            actualizarExistencias(listaExistencias);
            actualizarMovimientos(listaMovimientos);
        }
    }

    public boolean insertarCaracteristica(Caracteristica c, Precios pc) {
        boolean res = true;
        if (!listaCaracteristicas.contains(c)) {
            listaCaracteristicas.add(c);
            if (!hayCaracteristicas) {
                Escalado esc;
                Iterator it = listaEscalados.iterator();
                while (it.hasNext()) {
                    esc = (Escalado) it.next();
                    esc.setCaracteristica(c);
                }

                it = listaMovimientos.iterator();
                MovimientoAlmacen mv;
                while (it.hasNext()) {
                    mv = (MovimientoAlmacen) it.next();
                    mv.setCaracteristica(c);
                }

                it = listaExistencias.iterator();
                Existencia ex;
                while (it.hasNext()) {
                    ex = (Existencia) it.next();
                    ex.setCaracteristica(c);
                }

                hayCaracteristicas = true;
                actualizarMovExistencias = true;
                if (cbEscaladoCaracteristica.isSelected()) {
                    cbEscaladoCaracteristica.setSelected(true);
                    bEscaladosCarFichero.setEnabled(true);
                    bNuevoEscaladoCaracteristica.setEnabled(true);
                    bEliminarEscaladoCaracteristica.setEnabled(true);
                } else {
                    //bEscaladosCarFichero.setEnabled(false);
                    bEscaladosCarFichero.setEnabled(false);
                    bNuevoEscaladoCaracteristica.setEnabled(false);
                    bEliminarEscaladoCaracteristica.setEnabled(false);
                }
                actualizarEscaladosCaracteristicas(c);
                actualizarMovimientos(listaMovimientos);
                actualizarExistencias(listaExistencias);
                bEscaladosCarFichero.setEnabled(true);
                bEscaladosFichero.setEnabled(false);
                bEscaladosFichero.setEnabled(false);
                cbEscaladoCaracteristica.setEnabled(true);
                pEscaladoArticulo.setEnabled(false);
                cbEscaladoArticulo.setEnabled(false);
                cbEscaladoArticulo.setSelected(false);
                cbEscaladoCaracteristica.setEnabled(true);
                pEscaladoArticulo.setEnabled(true);
            }

            if (pc != null) {
                listaPrecios.add(pc);
                this.listaPreciosIns.add(pc);
            }
			
            actualizarCaracteristicas(listaPrecios);
        } else {
            res = false;
            //Si no se ha insertado mostramos un mensaje de error
            JOptionPane.showMessageDialog(null, "La característica ya existe", "Error", JOptionPane.ERROR_MESSAGE);
        }
        return res;
    }

    public void insertarEscalado(Escalado escalado) {
        listaEscalados.add(escalado);
        if (escalado.getCaracteristica() == null) {
            actualizarEscaladosArticulos();
        } else {
            actualizarEscaladosCaracteristicas(escalado.getCaracteristica());
        }
    }

    public boolean modificarCaracteristica(Caracteristica c, Precios pc) {
        boolean res = true;
        int indice = tcaracteristicas.getSelectedRow();
        String sColor = (String) tcaracteristicas.getModel().getValueAt(indice, 0);
        Colores color = BaseDatos.obtenerColor(sColor);
        int indiceCaracteristicaAntigua = obtenerIndiceCaracteristica(color);

        if (listaCaracteristicas.contains(c) && !color.getCod_color().equals(c.getIid_color().getCod_color())) {
            res = false;
            JOptionPane.showMessageDialog(null, "La característica ya existe", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            listaCaracteristicas.remove(indiceCaracteristicaAntigua);
            listaCaracteristicas.add(indiceCaracteristicaAntigua, c);

        }

        //Actualizar lista de precio
        Caracteristica car = (Caracteristica) listaCaracteristicas.get(indiceCaracteristicaAntigua);
        Iterator<Precios> i = listaPrecios.iterator();
        int in = 0;
        boolean seguir = true;
        boolean encontrado = false;
        Precios pi =  null;
        while (i.hasNext() && seguir) {
            pi = i.next();
            //Comprobar el precio y el color
            if (ar.getIid().equals(pi.getIid_art().getIid()) && car.getIid_color().getIid().equals(pi.getIid_car())) {
                seguir = false;
                encontrado = true;
            }
            in++;
        }

        if (encontrado) {
            in--;
            listaPrecios.remove(in);
            listaPrecios.add(in, pc);
            if (!pc.getPvp().equals(pi.getPvp()) || !pc.getPtc().equals(pi.getPtc()) || !pc.getUpc().equals(pi.getUpc()) || !pc.getPi().equals(pi.getPi())) {
                //Cambio de precio
                pc.setIid(null);
                listaPreciosIns.add(pc);
            }
        }
        actualizarCaracteristicas(listaPrecios);
        return res;
    }

    public boolean existeEscalado(Integer medida1, Integer medida2, Caracteristica car) {
        Escalado esc = new Escalado();
        esc.setDimension1(medida1);
        esc.setDimension2(medida2);

        if (car == null) {
            return listaEscalados.contains(esc);
        } else {
            esc.setCaracteristica(car);
            return listaEscalados.contains(esc);
        }
    }

    public void actualizarEscaladosArticulos() {
        Modelo modelo = (Modelo) tEscaladoArticulo.getModel();
        int i, j = modelo.getRowCount();
		Escalado esc;
		
        //eliminamos todas las filas
        for (i = 0; i < j; i++) {
            modelo.removeRow(0);
        }

        for (Iterator<Escalado> it = listaEscalados.iterator(); it.hasNext();) {
            Object[] fila = new Object[3];
            esc = it.next();
            fila[0] = esc.getDimension1();
            fila[1] = esc.getDimension2();
            fila[2] = Util.convertirPuntoAComa(esc.getPrecio().toString());
            modelo.addRow(fila);
        }
    }

    public void actualizarEscaladosCaracteristicas(Caracteristica c) {
        Modelo modelo = (Modelo) tEscaladoCaracteristicas.getModel();
        int i, j = modelo.getRowCount();
		Escalado esc;
		
        //eliminamos todas las filas
        for (i = 0; i < j; i++) {
            modelo.removeRow(0);
        }

        List lescalados = obtenerListaEscaladosCaracteristicas(c);
        Object[] fila;
		for (Iterator<Escalado> it = lescalados.iterator(); it.hasNext();) {
            esc = it.next();
			fila = new Object[4];
            fila[0] = c.getIid_color().getCod_color();
            fila[1] = esc.getDimension1();
            fila[2] = esc.getDimension2();
            fila[3] = Util.convertirPuntoAComa(esc.getPrecio().toString());
            modelo.addRow(fila);
        }
    }

    private List<Escalado> obtenerListaEscaladosCaracteristicas(Caracteristica c) {
        List<Escalado> res = new ArrayList<Escalado>();
        Escalado esc;
        Iterator<Escalado> it = listaEscalados.iterator();
        while (it.hasNext()) {
            esc = it.next();
            if (esc.getCaracteristica().equals(c)) {
                res.add(esc);
            }
        }
        return res;
    }

    private void borrarEscaladosCaracteristicas(Caracteristica car) {
        List<Escalado> escaladosCarBorrar = obtenerListaEscaladosCaracteristicas(car);
        listaEscalados.removeAll(escaladosCarBorrar);
    }

    private List<MovimientoAlmacen> obtenerListaMovimientosCaracteristicas(Caracteristica car) {
        List<MovimientoAlmacen> lres = new ArrayList<MovimientoAlmacen>();
        Iterator it = listaMovimientos.iterator();
        MovimientoAlmacen mva;
        while (it.hasNext()) {
            mva = (MovimientoAlmacen) it.next();
            if (mva.getCaracteristica().equals(car)) {
                lres.add(mva);
            }
        }
        return lres;
    }

    private List<Existencia> obtenerListaExistenciaCaracteristicas(Caracteristica car) {
        List<Existencia> lres = new ArrayList<Existencia>();
        Iterator<Existencia> it = listaExistencias.iterator();
        Existencia ex;
        while (it.hasNext()) {
            ex = it.next();
            if (ex.getCaracteristica().equals(car)) {
                lres.add(ex);
            }
        }
        return lres;
    }

    private void borrarMovimientosCaracteristicas(Caracteristica car) {
        List<MovimientoAlmacen> lmov = obtenerListaMovimientosCaracteristicas(car);
        listaMovimientos.removeAll(lmov);
        listaMovimientosBorrados.addAll(lmov);
    }

    private void borrarExistenciasCaracteristicas(Caracteristica car) {
        List<Existencia> lex = obtenerListaExistenciaCaracteristicas(car);
        listaExistencias.removeAll(lex);
    }

    public void actualizarCaracteristicas(List lp) {
        Modelo modelo = (Modelo) tcaracteristicas.getModel();
        int i, j = modelo.getRowCount();

        //eliminamos todas las filas
        for (i = 0; i < j; i++) {
            modelo.removeRow(0);
        }

        Caracteristica c;
        Object[] fila;
		Iterator<Precios> itp;
		Boolean seguir;
		Precios p;
		for (Iterator it = listaCaracteristicas.iterator(); it.hasNext();) {
            fila = new Object[7];
            c = (Caracteristica) it.next();
            if (c.getIid_color() != null) {
                fila[0] = c.getIid_color().getCod_color();
            }

            itp = listaPrecios.iterator();
            seguir = true;
			
            while (itp.hasNext() && seguir) {
                p = itp.next();
                if (p.getIid_car().equals(c.getIid_color().getIid())) {
                    //El precio de la caracteristica  
                    if (p.getPtc() != null) {
                        c.setPtc(p.getPtc());
                    }
                    if (p.getPvp() != null) {
                        c.setPvp(p.getPvp());
                    }
                    if (p.getUpc() != null) {
                        c.setUpc(p.getUpc());
                    }
                    if (p.getPi() != null) {
                        c.setPrecioIncremento(p.getPi());
                    }
                    seguir = false;
                }
            }

			fila[1] = (c.getUpc() != null) ? fila[1] = Util.convertirPuntoAComa(c.getUpc().toString()) : "";
			fila[2] = (c.getPtc() != null) ? Util.convertirPuntoAComa(c.getPtc().toString()) : "";

            if (c.getStock_min()) {
                fila[3] = "Sí";
                fila[4] = c.getCantidad_stock_minimo();
            } else {
                fila[3] = "No";
                fila[4] = "";
            }

			fila[5] = (c.getPvp() != null) ? Util.convertirPuntoAComa(c.getPvp().toString()) : "";
			fila[6] = (c.getPrecioIncremento() != null) ? Util.convertirPuntoAComa(c.getPrecioIncremento().toString()) : "";
			
            modelo.addRow(fila);
        }

        hayCaracteristicas = true;
        cbEscaladoCaracteristica.setEnabled(true);
    }

    private void vaciarEscaladosCaracteristicas() {
        Modelo modelo = (Modelo) tEscaladoCaracteristicas.getModel();
        int i, j = modelo.getRowCount();
		
        //eliminamos todas las filas
        for (i = 0; i < j; i++) {
            modelo.removeRow(0);
        }
    }

    public List<AgenteArticulo> getListaAgenteArticulo() {
        return lAgenteArticulo;
    }

    public List<AgenteArticuloCodigo> getListaAgenteArticuloCodigo() {
        return lAgenteArticuloCodigo;
    }

    public String obtenerFormula(FamiliaVenta fv) {
        String formula = "";
        if (listaFormulas != null && !listaFormulas.isEmpty()) {
            Iterator<InterlocutorFamiliaVenta> iF = listaFormulas.iterator();
            InterlocutorFamiliaVenta ifv;
			while (iF.hasNext()) {
                ifv = iF.next();
                if (fv.getIid().equals(ifv.getFamiliaVenta().getIid())) {
                    formula = ifv.getFormula();
                    break;
                }
            }
        }
        return formula;
    }

    public Double descuentoInterlocutor(Articulo ar) {
        //Se ha de calcular el descuento segun la siguiente prioridad:
        //1.- Se usará el descuento que el cliente tenga para ese articulo
        //2.- Se usará el descuento que el cliente tenga para esa familia
        //3.- Se usará el descuento qeu el articulo tenga en si

        Double descuento = 0.0D;
        if (this.modInter) {
            Agentes interA = BaseDatos.obtenerAgenteByIid(inter.getIidCliente().getIid());
            String codigoAgente = interA.getCod_agente();
            if (codigoAgente != null && !codigoAgente.equals("")) {
                Agentes ag = BaseDatos.obtenerAgentePorEmpresaYCodigo(e.getIid(), codigoAgente);
                if (ag != null) {
                    DescuentoClienteArticulo dca = BaseDatos.obtenerDescuentoClienteArticulo(ag.getIid(), ar.getIid());
                    if (dca != null) {
                        //Se toma el descuento del cliente
                        descuento = dca.getDescuento();
                    } else {
                        DescuentoClienteFamiliaVenta dcfv = BaseDatos.obtenerDescuentoClienteFamiliaVenta(ag.getIid(), ar.getIid_fam_venta().getIid());
                        if (dcfv != null) {
                            //Se toma el descuento de la familia
                            descuento = dcfv.getDescuento();
                        } else {
                            //Se toma el descuento del articulo
                            if (ar.getDescuento() != null) {
                                descuento = Double.parseDouble(ar.getDescuento().toString());
                            }
                        }
                    }
                } else {
                    //Se toma el descuento del articulo
                    if (ar.getDescuento() != null) {
                        descuento = Double.parseDouble(ar.getDescuento().toString());
                    }
                }
            } else {
                //Se toma el descuento del articulo;
                if (ar.getDescuento() != null) {
                    descuento = Double.parseDouble(ar.getDescuento().toString());
                }
            }
        }
        return descuento;
    }

    public Float calcularIvaInterlocutor() {
        Iva ivaI = null;
        Float ivaIF = 0.0F;
        Agentes interA = BaseDatos.obtenerAgenteByIid(inter.getIidCliente().getIid());
        if (interA != null) {
            if (interA.getExento_iva() != null && interA.getExento_iva()) {
                //Exento
            } else {
                if (interA.getIva() != null) {
                    ivaI = interA.getIva();
                } else {
                    //Iva del documento
                    Metadata mdtIva = (Metadata) BaseDatos.obtenerMetadaPorNombre("ivaDocumento", e.getIid());
                    ivaI = BaseDatos.obtenerIvaPorPorcentaje(mdtIva.getValor());
                }
                ivaIF = ivaI.getPorcentaje();
            }
        }
        return ivaIF;
    }

    private void visualizarAgenteArticuloCodigo() {
        int indicePanel = jTabbedPane1.getSelectedIndex();
        int indiceFila = tagentearticulocodigo1.getSelectedRow();
        if (indiceFila >= 0) {

            String proveedor;
            proveedor = (String) tagentearticulocodigo1.getModel().getValueAt(indiceFila, 0);
            Integer color;

            if (tagentearticulocodigo1.getModel().getValueAt(indiceFila, 5) != null) {
                color = BaseDatos.obtenerColor(tagentearticulocodigo1.getModel().getValueAt(indiceFila, 5).toString()).getIid();
            } else {
                color = 0;
            }

            AgenteArticuloCodigo aac = this.obtenerAgenteArticuloCodigo(proveedor, color);
            int desde = 0;
            NuevoAgenteArticuloCodigo ntc;
            ntc = new NuevoAgenteArticuloCodigo(this, ar, "Código de Artículos por Proveedor - Modificación", aac, e, desde);
            ntc.setDefaultCloseOperation(NuevoAgenteArticuloCodigo.DISPOSE_ON_CLOSE);
            ntc.setLocationRelativeTo(null);
            ntc.setVisible(true);
        } else {
            JOptionPane.showMessageDialog(null, "No hay seleccionado ningún código de artículo por proveedor", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void borrarAgenteArticuloCodigo() {
        try {
            int indicePanel = jTabbedPane1.getSelectedIndex();
            int indiceFila = tagentearticulocodigo1.getSelectedRow();
            if (indiceFila >= 0) {

                int eliminar = 1;
                eliminar = JOptionPane.showConfirmDialog(null, "¿Está seguro de que desea eliminar el código de artículo por proveedor?", "¿Eliminar Código de Artículo por Proveedor?", JOptionPane.YES_NO_OPTION);
                //hacerCambios = -1 ==> se ha pulsado la "x" de cancelar;
                //hacerCambios =  0 ==> se ha pulsado el "sí"
                //hacerCambios =  1 ==> se ha pulsado el "no"

                if (eliminar == 0) {
                    String proveedor = (String) tagentearticulocodigo1.getModel().getValueAt(indiceFila, 0);
                    if (this.eliminarAgenteArticuloCodigo(proveedor)) {
                        lAgenteArticuloCodigo = this.getListaAgenteArticuloCodigo();
                        completarPantalla();
                    } else {
                        JOptionPane.showMessageDialog(null, "No se ha podido eliminar el ¿¿Agente Artículo??", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
            } else {
                JOptionPane.showMessageDialog(null, "No hay seleccionado ningún código de artículo por proveedor", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Este elemento no se puede eliminar", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void completarPantalla() {
        actualizarAgenteArticuloCodigo1(lAgenteArticuloCodigo);
    }

    public void actualizarAgenteArticuloCodigo1(List laac1) {
        Modelo modelo1 = (Modelo) tagentearticulocodigo1.getModel();
        int i, j = modelo1.getRowCount();

        //eliminamos todas las filas
        for (i = 0; i < j; i++) {
            modelo1.removeRow(0);
        }

        if (laac1 == null) {
            laac1 = new ArrayList();
        }

        AgenteArticuloCodigo aac1;
        Iterator<AgenteArticuloCodigo> it1;
        Object[] fila1;
        for (it1 = laac1.iterator(); it1.hasNext();) {
            fila1 = new Object[6];
            aac1 = it1.next();
            fila1[0] = aac1.getIid_agente().getNombre_comercial();
            fila1[1] = aac1.getCodigo();
            fila1[2] = aac1.getTipoPrecio();
            fila1[3] = Util.convertirPuntoAComa(aac1.getPrecio().toString());
            if (aac1.getDescuento() != null) {
                fila1[4] = Util.convertirPuntoAComa(aac1.getDescuento().toString());
            }
            if (aac1.getIid_color() != null && aac1.getIid_color() != 0) {
                fila1[5] = BaseDatos.obtenerColorPorIid(aac1.getIid_color()).getCod_color();
            }
            modelo1.addRow(fila1);
        }
        calPreciosProv();
    }

    private void calPreciosProv() {
        if (inter == null) {
            AgenteArticuloCodigo ap = null;
            Date fecha = new Date();
            List PreciosNuevo = new ArrayList();
            if (prov != null) {
                //Con caracteristica
                List CaracNueva = new ArrayList();
                if (listaCaracteristicas != null && !listaCaracteristicas.isEmpty()) {
                    Iterator ib = listaCaracteristicas.iterator();
                    Precios p;
                    Caracteristica car;
                    int exit;
                    Iterator<AgenteArticuloCodigo> ic;
                    while (ib.hasNext()) {
                        car = (Caracteristica) ib.next();
                        exit = 0;
                        ic = lAgenteArticuloCodigo.iterator();
                        while (ic.hasNext() && exit == 0) {
                            ap = ic.next();
                            if (ap.getIid_articulo().getIid().equals(ar.getIid()) && ap.getIid_agente().getIid().equals(prov.getIid()) && ap.getIid_color().equals(car.getIid_color().getIid())) {
                                exit = 1;
                            } else {
                                ap = null;
                            }
                        }
                        if (ap != null && ap.getPrecio() != 0) {
                            if (ap.getCheckDto()) {
                                //Tiene descuento
                                //Calculamos el precio de tarifa
                                pt = ap.getPrecio() - (ap.getPrecio() * (ap.getDescuento() / 100));
                                car.setPtc(pt);
                            } else {
                                // No tiene descuento
                                pt = ap.getPrecio();
                                car.setPtc(pt);
                            }

                            //Calculamos PVP si tiene formula definida
                            FormulaArticuloProv fap = BaseDatos.obtenerFormulaProvArticulo(prov.getIid(), ar.getIid());
                            String formula;
                            if (fap != null) {
                                formula = fap.getFormula();
                            } else {
                                //Buscar por familia
                                FormulaFamiliaProv ffp = BaseDatos.obtenerFormulaProvFamilia(prov.getIid(), ar.getIid_fam_venta().getIid());
                                if (ffp != null) {
                                    formula = ffp.getFormula();
                                } else {
                                    formula = null;
                                }
                            }

                            if (formula != null) {
                                ScriptEngineManager manager = new ScriptEngineManager();
                                ScriptEngine engine = manager.getEngineByName("js");
                                String sprecio = Float.toString(pt);
                                formula = formula.replace("pv", sprecio);
                                Float fprecio = 0.0F;
                                try {
                                    fprecio = (Float) Float.parseFloat(engine.eval(formula).toString());
                                } catch (ScriptException ex) {
                                    Logger.getLogger(NuevoArticulo.class.getName()).log(Level.SEVERE, null, ex);
                                }
                                fprecio = matematico.Matematico.redondear2decimales(fprecio);
                                car.setPvp(fprecio);
                            }
                            CaracNueva.add(car);

                            //Añadir lista precio
                            p = new Precios();
                            p.setIid_empresa(e);
                            p.setIid_art(ar);
                            p.setIid_car(car.getIid_color().getIid());
                            p.setPvp(car.getPvp());
                            p.setPtc(car.getPtc());
                            p.setUpc(car.getUpc());
                            p.setPi(0F);
                            p.setFecha(fecha.getTime());
                            p.setAccion("Precios por Proveedor Habitual");
                            PreciosNuevo.add(p);
                            listaPreciosIns.add(p);
                        } else {
                            //Añadimos la caracteristica sin modificar
                            CaracNueva.add(car);

                            //Añadir lista precio
                            p = new Precios();
                            p.setIid_empresa(e);
                            p.setIid_art(ar);
                            p.setIid_car(car.getIid_color().getIid());
                            p.setPvp(car.getPvp());
                            p.setPtc(car.getPtc());
                            p.setUpc(car.getUpc());
                            p.setPi(0F);
                            p.setFecha(fecha.getTime());
                            p.setAccion("Precios por Proveedor Habitual");
                            PreciosNuevo.add(p);
                        }
                    }

                    listaCaracteristicas.clear();
                    listaCaracteristicas.addAll(CaracNueva);
                    listaPrecios.clear();
                    listaPrecios.addAll(PreciosNuevo);
                    actualizarCaracteristicas(listaCaracteristicas);
                } else {
                    int exit = 0;
                    Iterator<AgenteArticuloCodigo> ic = lAgenteArticuloCodigo.iterator();
                    while (ic.hasNext() && exit == 0) {
                        ap = ic.next();
                        //ar, prov, car.getIid_color().getIid()
                        if (ap.getIid_articulo().getIid().equals(ar.getIid()) && ap.getIid_agente().getIid().equals(prov.getIid())) {
                            exit = 1;
                        } else {
                            ap = null;
                        }
                    }

                    if (ap != null && ap.getPrecio() != 0) {
                        if (ap.getCheckDto()) {
                            //Tiene descuento
                            //Calculamos el precio de tarifa
                            pt = ap.getPrecio() - (ap.getPrecio() * (ap.getDescuento() / 100));
                            tptc.setText(util.Util.convertirPuntoAComa(Float.toString(pt)));
                        } else {
                            // No tiene descuento
                            pt = ap.getPrecio();
                            tptc.setText(util.Util.convertirPuntoAComa(Float.toString(pt)));
                        }

                        //Calculamos PVP si tiene formula definida
                        FormulaArticuloProv fap = BaseDatos.obtenerFormulaProvArticulo(prov.getIid(), ar.getIid());
                        String formula;
                        Float fprecio = 0.0F;
                        if (fap != null) {
                            formula = fap.getFormula();
                        } else {
                            //Buscar por familia
                            FormulaFamiliaProv ffp = BaseDatos.obtenerFormulaProvFamilia(prov.getIid(), ar.getIid_fam_venta().getIid());
                            if (ffp != null) {
                                formula = ffp.getFormula();
                            } else {
                                formula = null;
                            }
                        }

                        if (formula != null) {
                            ScriptEngineManager manager = new ScriptEngineManager();
                            ScriptEngine engine = manager.getEngineByName("js");
                            String sprecio = Float.toString(pt);
                            formula = formula.replace("pv", sprecio);

                            try {
                                fprecio = (Float) Float.parseFloat(engine.eval(formula).toString());
                            } catch (ScriptException ex) {
                                Logger.getLogger(NuevoArticulo.class.getName()).log(Level.SEVERE, null, ex);
                            }
                            fprecio = matematico.Matematico.redondear2decimales(fprecio);
                            tprecio.setText(Util.convertirPuntoAComa(String.valueOf(fprecio)));
                        }

                        //Añadir lista precio
                        Precios p = new Precios();
                        p.setIid_empresa(e);
                        p.setIid_art(ar);
                        p.setPvp(fprecio);
                        p.setPtc(pt);
                        p.setUpc(ar.getUpc());
                        p.setPi(0F);
                        p.setFecha(fecha.getTime());
                        PreciosNuevo.add(p);
                        listaPreciosIns.add(p);
                    }
                }
            }
        }
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bAa;
    private javax.swing.JButton bAc;
    private javax.swing.JButton bBorrarEscaladoArticulo;
    private javax.swing.JButton bBorrarMovimiento;
    private javax.swing.JButton bConfig;
    private javax.swing.JButton bCrearEscaladoArticulo;
    private javax.swing.JButton bCrearInventario;
    private javax.swing.JButton bEliminarAA;
    private javax.swing.JButton bEliminarCaracteristica;
    private javax.swing.JButton bEliminarEscaladoCaracteristica;
    private javax.swing.JButton bEscaladosCarFichero;
    private javax.swing.JButton bEscaladosFichero;
    private javax.swing.JButton bModificarAA;
    private javax.swing.JButton bModificarCaracteristica;
    private javax.swing.JCheckBox bMonocromo;
    private javax.swing.JButton bNuevaCaracteristica;
    private javax.swing.JButton bNuevoAA;
    private javax.swing.JButton bNuevoEscaladoCaracteristica;
    private javax.swing.JButton bPrecios;
    private javax.swing.JButton baceptar;
    private javax.swing.JCheckBox bactualizarstock;
    private javax.swing.JButton bcancelar;
    private javax.swing.JButton bmodificar;
    private javax.swing.JCheckBox bstockcolor;
    private javax.swing.JCheckBox bstockmedida;
    private javax.swing.JCheckBox bstockneg;
    private javax.swing.JComboBox cAlmacen;
    private javax.swing.JComboBox cIva;
    private javax.swing.JCheckBox cbCorteLiso;
    private javax.swing.JCheckBox cbEscaladoArticulo;
    private javax.swing.JCheckBox cbEscaladoCaracteristica;
    private javax.swing.JComboBox cfamiliav;
    private javax.swing.JComboBox cmoneda;
    private javax.swing.JComboBox cproveedorh;
    private javax.swing.JComboBox cunidadm;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane10;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JScrollPane jScrollPane8;
    private javax.swing.JScrollPane jScrollPane9;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JLabel lAlmacen;
    private javax.swing.JLabel lCaracteristicas1;
    private javax.swing.JLabel lDescuento;
    private javax.swing.JLabel lEscalado;
    private javax.swing.JLabel lEscaladoCaracteristicas;
    private javax.swing.JLabel lExistencias;
    private javax.swing.JLabel lMovimientos;
    private javax.swing.JLabel lMovimientos1;
    private javax.swing.JLabel lRestoMinimo;
    private javax.swing.JLabel lStockMinimo;
    private javax.swing.JLabel lcodigo;
    private javax.swing.JLabel ldescinf;
    private javax.swing.JLabel ldesctec;
    private javax.swing.JLabel lfamiliav;
    private javax.swing.JLabel liva;
    private javax.swing.JLabel lmoneda;
    private javax.swing.JLabel lobservaciones;
    private javax.swing.JLabel lprecio;
    private javax.swing.JLabel lprecio1;
    private javax.swing.JLabel lprecio2;
    private javax.swing.JLabel lprecio3;
    private javax.swing.JLabel lprecio4;
    private javax.swing.JLabel lprecioIncremento;
    private javax.swing.JLabel lproveedor;
    private javax.swing.JLabel ltipocontrol;
    private javax.swing.JLabel lunidadmedida;
    private javax.swing.JPanel pEscaladoArticulo;
    private javax.swing.JPanel pEscaladoCaracteristica;
    private javax.swing.JPanel pExistencias;
    private javax.swing.JPanel pExistencias1;
    private javax.swing.JTable tEscaladoArticulo;
    private javax.swing.JTable tEscaladoCaracteristicas;
    private javax.swing.JTable tExistencias;
    private javax.swing.JLabel tExpliC;
    private javax.swing.JTextField tFormulaC;
    private javax.swing.JTable tMovimientos;
    private javax.swing.JTextField tRestoMinimo;
    private javax.swing.JTextField tStockMinimo;
    private javax.swing.JTable tagentearticulocodigo1;
    private javax.swing.JTable tcaracteristicas;
    private javax.swing.JTextField tcodigo;
    private javax.swing.JTextArea tdescinf;
    private javax.swing.JTextArea tdesctect;
    private javax.swing.JTextField tdescuento;
    private javax.swing.JTextField tfc;
    private javax.swing.JTextArea tobservaciones;
    private javax.swing.JTextField tpmc;
    private javax.swing.JTextField tprecio;
    private javax.swing.JTextField tprecioIncremento;
    private javax.swing.JTextField tptc;
    private javax.swing.JTextField ttipoControl;
    private javax.swing.JTextField tupc;
    // End of variables declaration//GEN-END:variables
}
