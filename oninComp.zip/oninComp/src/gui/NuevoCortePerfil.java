package gui;

import acceso.BaseDatos;
import auxiliar.CortePerfil;
import bean.DespiecePresupuesto;
import bean.LineaCortePerfil;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.net.URL;
import java.util.Iterator;
import java.util.List;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JOptionPane;
import javax.swing.KeyStroke;


public class NuevoCortePerfil extends javax.swing.JFrame {

    private List<CortePerfil> listaCortePerfil;
    private NuevoPresupuesto nuevoPresupuesto;
    private int perfilesMostrados;
    private List<Integer> listaIdentificadoresExistenciasRestosUsados;

    public NuevoCortePerfil(NuevoPresupuesto nuevoPresupuesto, List<CortePerfil> listaCortePerfil) {
        this.listaCortePerfil = listaCortePerfil;
        this.nuevoPresupuesto = nuevoPresupuesto;
        
        initComponents();

        bCancelar.setToolTipText("Cancelar");
        bFinalizar.setToolTipText("Finalizar");
        rellenarCortesPerfil();
        crearIconosBotones();
        crearAcciones();
    }

    private void rellenarCortesPerfil(){
        Iterator iter = listaCortePerfil.iterator();
        NuevaLineaCorteDePerfil nlcl;
        perfilesMostrados = 0;
        LineaCortePerfil lcl;
        CortePerfil cl;
        List listaTemporalCortesLona = BaseDatos.getListaLineaCortePerfil(nuevoPresupuesto.getPresupuesto().getIid());
        
        listaIdentificadoresExistenciasRestosUsados = BaseDatos.getListaRestosPerfilesUsados(nuevoPresupuesto.getPresupuesto().getIid());
        
        while(iter.hasNext()){
            cl = (CortePerfil) iter.next();
            lcl = getLineaCortePerfil(cl, listaTemporalCortesLona);
            if(lcl == null){
                nlcl = new NuevaLineaCorteDePerfil(this, nuevoPresupuesto, cl);
            } else {
                nlcl = new NuevaLineaCorteDePerfil(this, nuevoPresupuesto, cl, lcl);
            }
            panelCortePerfil.add(nlcl);
            panelCortePerfil.setVisible(true);
            panelCortePerfil.repaint();
            perfilesMostrados++;
        }
        
        for(int contadorPerfil = perfilesMostrados + 1; contadorPerfil < 10; contadorPerfil ++){
            NuevaLineaCorteDeLonaVacia nlclv = new NuevaLineaCorteDeLonaVacia();
            panelCortePerfil.add(nlclv);
        }
        
        panelCortePerfil.setSize(500, 500);
        panelCortePerfil.setLayout(new GridLayout(0, 1));
        
        panelCortePerfil.setVisible(true);
        panelCortePerfil.repaint();
    }
    
    
    private LineaCortePerfil getLineaCortePerfil(CortePerfil cl, List listaTemporalCortesLona) {
        LineaCortePerfil lcl = null;
        boolean seguir = true;
        Iterator iter = listaTemporalCortesLona.iterator();
        while(iter.hasNext() && seguir){
            lcl = (LineaCortePerfil)iter.next();
            if(!lcl.getEsDespiece() && cl.getIndiceElemento() == null && lcl.getLineaPresupuesto().getIid().equals(cl.getIddNuevaLineaPresupuesto())){
                seguir = false;
            } else if(lcl.getEsDespiece() && cl.getIndiceElemento() != null && lcl.getLineaPresupuesto().getIid().equals(cl.getIddNuevaLineaPresupuesto())){
                DespiecePresupuesto dp = lcl.getDespiece();
                dp = BaseDatos.obtenerDespiecePresupuestoByIid(dp.getIid());
                if(dp != null && dp.getOrden().equals(cl.getIndiceElemento())){
                     seguir = false;
                }
            }
        }
        
        if(seguir){
            lcl = null;
        }
        
        return lcl;
    }

    
    public void actualizarLineas() {
        panelCortePerfil.setVisible(true);
        panelCortePerfil.repaint();
        pack();
    }
    
    private void crearAcciones() {
        KeyStroke escapeKeyStroke = KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false);
        Action escapeAction = new AbstractAction() {
            public void actionPerformed(ActionEvent e) {
                nuevoPresupuesto.setFabricado(false);
                cerrarVentana();
            }
        }; 
        getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(escapeKeyStroke, "ESCAPE");
        getRootPane().getActionMap().put("ESCAPE", escapeAction);
    }
    
    public void salir(){
        nuevoPresupuesto.setFabricado(false);
        removeAll();
        dispose();
    }
    
    private void cerrarVentana(){
        //nuevoPresupuesto.setFabricado(false);
        removeAll();
        dispose();
    }

    private void crearIconosBotones() {
        URL urlCancelar = getClass().getResource("/iconos/cancelar.gif");
        ImageIcon iconoCancelar = new ImageIcon(urlCancelar);
        bCancelar.setIcon(iconoCancelar);
        
        URL urlFinalizar = getClass().getResource("/iconos/aceptar.png");
        ImageIcon iconoFinalizar = new ImageIcon(urlFinalizar);
        bFinalizar.setIcon(iconoFinalizar);
        
    }

    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        bCancelar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        panelCortePerfil = new javax.swing.JPanel();
        lTitulo = new javax.swing.JLabel();
        bFinalizar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        bCancelar.setText("Cancelar");
        bCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bCancelarActionPerformed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout panelCortePerfilLayout = new org.jdesktop.layout.GroupLayout(panelCortePerfil);
        panelCortePerfil.setLayout(panelCortePerfilLayout);
        panelCortePerfilLayout.setHorizontalGroup(
            panelCortePerfilLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(0, 608, Short.MAX_VALUE)
        );
        panelCortePerfilLayout.setVerticalGroup(
            panelCortePerfilLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(0, 327, Short.MAX_VALUE)
        );

        jScrollPane1.setViewportView(panelCortePerfil);

        lTitulo.setFont(new java.awt.Font("Tahoma", 1, 11));
        lTitulo.setText("     C.Linea      Cantidad                        Artículo                           Longitud                Tamaño");

        bFinalizar.setText("Finalizar");
        bFinalizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bFinalizarActionPerformed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout layout = new org.jdesktop.layout.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(layout.createSequentialGroup()
                .addContainerGap()
                .add(bFinalizar, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 103, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED, 412, Short.MAX_VALUE)
                .add(bCancelar)
                .addContainerGap())
            .add(layout.createSequentialGroup()
                .add(lTitulo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 511, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(99, Short.MAX_VALUE))
            .add(jScrollPane1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 610, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, layout.createSequentialGroup()
                .add(lTitulo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 21, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jScrollPane1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 329, Short.MAX_VALUE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(bCancelar)
                    .add(bFinalizar))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

private void bCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bCancelarActionPerformed
    cerrarVentana();
}//GEN-LAST:event_bCancelarActionPerformed

protected List getListaIdentificadoresExistenciasRestosUsados(){
    return this.listaIdentificadoresExistenciasRestosUsados;
}

private void bFinalizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bFinalizarActionPerformed
    boolean finalizarOperacion = true;
    NuevaLineaCorteDePerfil nlcl;
    for(int i = 0; (i < perfilesMostrados) && finalizarOperacion; i++){
        nlcl = (NuevaLineaCorteDePerfil)panelCortePerfil.getComponent(i);
        finalizarOperacion = nlcl.finalizable();
    }
    
    if(finalizarOperacion){
        if(BaseDatos.realizarCortePerfil(nuevoPresupuesto.getPresupuesto(), panelCortePerfil, perfilesMostrados)){
            JOptionPane.showMessageDialog(null, "Proceso de corte de perfiles realizado correctamente", "Información", JOptionPane.INFORMATION_MESSAGE);
            //nuevoPresupuesto.setFabricado(true);
            cerrarVentana();
        } else {
            nuevoPresupuesto.setFabricado(false);
            JOptionPane.showMessageDialog(null, "No se ha podido realizar el corte de perfil. Es posible que no haya perfiles suficiente", "Error", JOptionPane.ERROR_MESSAGE);
        }
    } else {
        JOptionPane.showMessageDialog(null, "Hay longitudes sin seleccionar", "Error", JOptionPane.ERROR_MESSAGE);
    }
}//GEN-LAST:event_bFinalizarActionPerformed
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bCancelar;
    private javax.swing.JButton bFinalizar;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lTitulo;
    private javax.swing.JPanel panelCortePerfil;
    // End of variables declaration//GEN-END:variables
}
