package gui;

import acceso.BaseDatos;
import bean.AgenteArticuloCodigo;
import bean.Agentes;
import bean.Articulo;
import bean.Empresa;
import bean.Colores;

import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.net.URL;
import java.util.Iterator;
import java.util.List;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JOptionPane;
import javax.swing.KeyStroke;
import util.Util;

public class NuevoAgenteArticuloCodigo extends javax.swing.JFrame {

    private NuevoArticulo laac;
    private Articulo ar;
    private AgenteArticuloCodigo aac;
    private boolean crear;
    private String codigoAntiguo;
    private String agenteAntiguo;
    private boolean precioTarifaAntiguo;
    private boolean precioAcordadoAntiguo;
    private boolean descuentoAntiguo;
    private String precioAntiguo;
    private String dtoAntiguo;
    private String descripcionAntigua;
    private Integer colorAntiguo;
    private Empresa e;
    private int desde;

    public NuevoAgenteArticuloCodigo(Empresa e) {
        this.e = e;
        initComponents();
        crearIconosBotones();
        crearAcciones();
    }

    public NuevoAgenteArticuloCodigo(NuevoArticulo laac, Articulo ar, String titulo, Empresa e, int desde) {
        super(titulo);
        this.ar = ar;
        this.laac = laac;
        this.e = e;
        this.desde = desde;
        aac = new AgenteArticuloCodigo();
        crear = true;
        initComponents();
        tarticulo.setText(ar.getDes_tecnica());
        tarticulo.setEnabled(false);
        bmodificar.setVisible(false);
        rbPrecioTarifa.setSelected(true);
        cbDescuento.setEnabled(true);
        cbDescuento.setSelected(false);
        tdto.setEnabled(false);
        ccolor.setEnabled(true);
        crearIconosBotones();
        crearAcciones();
    }

    public NuevoAgenteArticuloCodigo(NuevoArticulo laac, Articulo ar, String titulo, AgenteArticuloCodigo aac, Empresa e, int desde) {
        super(titulo);
        this.laac = laac;
        this.aac = aac;
        this.ar = ar;
        this.e = e;
        this.desde = desde;
        initComponents();
        tarticulo.setText(aac.getIid_articulo().getDes_tecnica());
        tcodigo.setText(aac.getCodigo());
        cagentes.setSelectedItem(aac.getIid_agente().getNombre_comercial());

        tprecio.setText(Util.convertirPuntoAComa(String.valueOf(aac.getPrecio())));
        cbDescuento.setSelected(aac.getCheckDto());
        tDescripcion.setText(aac.getDescripcion());

        //Coger color
        Colores co = BaseDatos.obtenerColorPorIid(aac.getIid_color());

        if (co != null) {
            ccolor.setSelectedItem(co.getCod_color());
        } else {
            ccolor.setSelectedItem("N/C");
        }

        if (cbDescuento.isSelected()) {
            this.tdto.setText(Util.convertirPuntoAComa(String.valueOf(aac.getDescuento())));
        }

        if (aac.getTipoPrecio().equals("Acordado")) {
            rbPrecioAcordado.setSelected(true);
        } else {
            rbPrecioTarifa.setSelected(true);
        }

        crear = false;
        tarticulo.setEnabled(false);
        tcodigo.setEnabled(false);
        cagentes.setEnabled(false);
        tdto.setEnabled(false);
        tprecio.setEnabled(false);
        rbPrecioAcordado.setEnabled(false);
        rbPrecioTarifa.setEnabled(false);
        cbDescuento.setEnabled(false);
        codigoAntiguo = aac.getCodigo();
        agenteAntiguo = aac.getIid_agente().getNombre_comercial();
        precioTarifaAntiguo = rbPrecioTarifa.isSelected();
        precioAcordadoAntiguo = rbPrecioAcordado.isSelected();
        descuentoAntiguo = cbDescuento.isSelected();
        precioAntiguo = tprecio.getText();
        dtoAntiguo = tdto.getText();
        descripcionAntigua = tDescripcion.getText();
        ccolor.setEnabled(false);
        colorAntiguo = aac.getIid_color();
        crearIconosBotones();
        crearAcciones();
    }

    private void crearAcciones() {
        KeyStroke escapeKeyStroke = KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false);
        Action escapeAction = new AbstractAction() {
            public void actionPerformed(ActionEvent e) {
                cerrarVentana();
            }
        };
        getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(escapeKeyStroke, "ESCAPE");
        getRootPane().getActionMap().put("ESCAPE", escapeAction);
    }

    private void cerrarVentana() {
        removeAll();
        dispose();
    }

    private void crearIconosBotones() {
        URL urlCancelar = getClass().getResource("/iconos/cancelar.gif");
        ImageIcon iconoCancelar = new ImageIcon(urlCancelar);
        bcancelar.setIcon(iconoCancelar);

        URL urlAceptar = getClass().getResource("/iconos/guardarYvolver.png");
        ImageIcon iconoAceptar = new ImageIcon(urlAceptar);
        baceptar.setIcon(iconoAceptar);

        URL urlModificar = getClass().getResource("/iconos/editar.png");
        ImageIcon iconoModificar = new ImageIcon(urlModificar);
        bmodificar.setIcon(iconoModificar);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jTextField1 = new javax.swing.JTextField();
        larticulo = new javax.swing.JLabel();
        lproveedor = new javax.swing.JLabel();
        tarticulo = new javax.swing.JTextField();
        tcodigo = new javax.swing.JTextField();
        baceptar = new javax.swing.JButton();
        bcancelar = new javax.swing.JButton();
        bmodificar = new javax.swing.JButton();
        lcodigo = new javax.swing.JLabel();
        cagentes = new javax.swing.JComboBox();
        rbPrecioTarifa = new javax.swing.JRadioButton();
        rbPrecioAcordado = new javax.swing.JRadioButton();
        tprecio = new javax.swing.JTextField();
        tdto = new javax.swing.JTextField();
        cbDescuento = new javax.swing.JCheckBox();
        lPrecio = new javax.swing.JLabel();
        lDto = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tDescripcion = new javax.swing.JTextArea();
        lDescripcion = new javax.swing.JLabel();
        lproveedor1 = new javax.swing.JLabel();
        ccolor = new javax.swing.JComboBox();

        jTextField1.setText("jTextField1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        larticulo.setText("Artículo");

        lproveedor.setText("Proveedor");

        baceptar.setText("Aceptar");
        baceptar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                baceptarActionPerformed(evt);
            }
        });

        bcancelar.setText("Cancelar");
        bcancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bcancelarActionPerformed(evt);
            }
        });

        bmodificar.setText("Modificar");
        bmodificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bmodificarActionPerformed(evt);
            }
        });

        lcodigo.setText("Código");

        cagentes.setModel(new javax.swing.DefaultComboBoxModel(new String[] {}));
        cagentes.addItem("-- Vacío --");
        List listanombreprov = BaseDatos.obtenerNombreComercialProveedor(e);
        for (Iterator it = listanombreprov.iterator(); it.hasNext();) {
            cagentes.addItem((String) it.next());
        }

        if(!crear && aac.getIid_agente() != null){
            cagentes.setSelectedItem(aac.getIid_agente().getNombre_comercial());
        }
        else{
            cagentes.setSelectedIndex(0);
        }

        buttonGroup1.add(rbPrecioTarifa);
        rbPrecioTarifa.setText("Precio Tarifa");
        rbPrecioTarifa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbPrecioTarifaActionPerformed(evt);
            }
        });

        buttonGroup1.add(rbPrecioAcordado);
        rbPrecioAcordado.setText("Precio Acordado");
        rbPrecioAcordado.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbPrecioAcordadoActionPerformed(evt);
            }
        });

        tprecio.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tprecioKeyReleased(evt);
            }
        });

        tdto.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tdtoKeyReleased(evt);
            }
        });

        cbDescuento.setText("Descuento");
        cbDescuento.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbDescuentoActionPerformed(evt);
            }
        });

        lPrecio.setText("Precio");

        lDto.setText("Descueto acordado");

        tDescripcion.setColumns(20);
        tDescripcion.setRows(5);
        jScrollPane1.setViewportView(tDescripcion);

        lDescripcion.setText("Descripcion:");

        lproveedor1.setText("Color");

        Colores c = new Colores();
        ccolor.setModel(new javax.swing.DefaultComboBoxModel(new String[] {}));
        ccolor.addItem("N/C");
        List listacolor = BaseDatos.getListaColoresArticulo(e, ar);
        for (Iterator it = listacolor.iterator(); it.hasNext();) {
            ccolor.addItem((String) it.next());
        }

        if(!crear && aac.getIid_color() != null && aac.getIid_color()!= 0){
            c = BaseDatos.obtenerColorPorIid(aac.getIid_color());
            ccolor.setSelectedItem(c.getCod_color());
        }
        else{
            ccolor.setSelectedIndex(0);
        }

        org.jdesktop.layout.GroupLayout layout = new org.jdesktop.layout.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(layout.createSequentialGroup()
                .addContainerGap()
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(rbPrecioAcordado)
                    .add(layout.createSequentialGroup()
                        .add(rbPrecioTarifa)
                        .add(43, 43, 43)
                        .add(cbDescuento))
                    .add(layout.createSequentialGroup()
                        .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(lPrecio)
                            .add(lDto))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(tprecio, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 113, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(tdto, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 113, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                    .add(lDescripcion)
                    .add(jScrollPane1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 285, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(layout.createSequentialGroup()
                        .add(24, 24, 24)
                        .add(baceptar)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(bmodificar, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 103, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(bcancelar))
                    .add(layout.createSequentialGroup()
                        .add(larticulo)
                        .add(18, 18, 18)
                        .add(tarticulo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 222, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                    .add(lproveedor1)
                    .add(layout.createSequentialGroup()
                        .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(lproveedor)
                            .add(lcodigo))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                                .add(tcodigo)
                                .add(cagentes, 0, 222, Short.MAX_VALUE))
                            .add(ccolor, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 74, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(38, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(layout.createSequentialGroup()
                .add(11, 11, 11)
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(larticulo)
                    .add(tarticulo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .add(8, 8, 8)
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(lproveedor)
                    .add(cagentes, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(lcodigo)
                    .add(tcodigo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(lproveedor1)
                    .add(ccolor, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED, 15, Short.MAX_VALUE)
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                    .add(cbDescuento)
                    .add(rbPrecioTarifa))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(rbPrecioAcordado)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(tprecio, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(lPrecio))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(lDto)
                    .add(tdto, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                .add(lDescripcion)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jScrollPane1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 118, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(bcancelar)
                    .add(bmodificar)
                    .add(baceptar))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

private void baceptarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_baceptarActionPerformed
    String codigo = tcodigo.getText();
    String agente = (String) cagentes.getSelectedItem();
    String precio = this.tprecio.getText();
    String color = (String) ccolor.getSelectedItem();

    if (codigo != null && codigo.length() > 0
            && agente != null && agente.length() > 0 && !agente.equals("-- Vacío -- ")
            && precio != null && precio.length() > 0) {

        aac.setCodigo(codigo);

        Agentes proveedor = BaseDatos.obtenerProveedorNombreComercial(agente, e);
        aac.setIid_agente(proveedor);

        aac.setPrecio(Float.valueOf(Util.convertirComaAPunto(precio)));

        if (this.rbPrecioAcordado.isSelected()) {
            aac.setTipoPrecio("Acordado");
        } else {
            aac.setTipoPrecio("Tarifa");
        }

        boolean checkDescuentoCorrecto = true;

        aac.setDescripcion(tDescripcion.getText());

        if (cbDescuento.isSelected()) {
            aac.setCheckDto(true);
            if (tdto.getText() != null && tdto.getText().length() > 0) {
                aac.setDescuento(Float.valueOf(Util.convertirComaAPunto(tdto.getText())));
            } else {
                checkDescuentoCorrecto = false;
            }
        } else {
            aac.setCheckDto(false);
        }

        if (color != null && color.length() > 0 && !color.equals("N/C")) {
            Colores c = BaseDatos.obtenerColor(color);
            aac.setIid_color(c.getIid());
            if (colorAntiguo == null) {
                colorAntiguo = 0;
            }
        }

        aac.setIid_articulo(ar);
        if (checkDescuentoCorrecto) {
            if (crear) {
                if (color.equals("N/C")) {
                    aac.setIid_color(0);
                }

                if (desde == 1) {
                    if (BaseDatos.insertarElemento(aac));
                    laac.insertarAgenteArticuloCodigo(aac);
                    cerrarVentana();
                } else {

                    if (laac.insertarAgenteArticuloCodigo(aac)) {
                        cerrarVentana();
                    }
                }
            } else {
                int hacerCambios = 1;

                if (hayCambios()) {
                    hacerCambios = JOptionPane.showConfirmDialog(null, "Está seguro de que desea realizar los cambios?", "¿Realizar cambios?", JOptionPane.YES_NO_OPTION);
                    //hacerCambios = -1 ==> se ha pulsado la "x" de cancelar;
                    //hacerCambios =  0 ==> se ha pulsado el "sí"
                    //hacerCambios =  1 ==> se ha pulsado el "no"
                    if (hacerCambios == 0) {
                        if (color.equals("N/C")) {
                            aac.setIid_color(0);
                        }
                        if (desde == 1) {
                            if (BaseDatos.modificarElemento(aac));
                            laac.modificarAgenteArticuloCodigo(aac, agenteAntiguo);
                            cerrarVentana();
                        } else {

                            if (laac.modificarAgenteArticuloCodigo(aac, agenteAntiguo)) {
                                cerrarVentana();
                            }
                        }


                    }
                } else {
                    //no hay cambios que realizar
                    JOptionPane.showMessageDialog(null, "No hay cambios que realizar", "Sin cambios", JOptionPane.ERROR_MESSAGE);
                }
            }
        } else {
            //Error, si ha seleccionado la casilla descuento debe de rellenarlo
            JOptionPane.showMessageDialog(null, "Si ha seleccionado Descuento debe rellenarlo", "Error", JOptionPane.ERROR_MESSAGE);
        }
    } else {
        //Error, hay que rellenar todos los campos
        JOptionPane.showMessageDialog(null, "Debe introducir el Código, el Proveedor y el Precio", "Error", JOptionPane.ERROR_MESSAGE);
    }



}//GEN-LAST:event_baceptarActionPerformed

private void bcancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bcancelarActionPerformed
    cerrarVentana();
}//GEN-LAST:event_bcancelarActionPerformed

private void bmodificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bmodificarActionPerformed
    if (bmodificar.getText().equals("Modificar")) {
        //Si el botón tiene el texto Modificar
        tcodigo.setEnabled(true);
        cagentes.setEnabled(true);
        rbPrecioAcordado.setEnabled(true);
        rbPrecioTarifa.setEnabled(true);
        tprecio.setEnabled(true);
        if (rbPrecioTarifa.isSelected()) {
            cbDescuento.setEnabled(true);
            if (cbDescuento.isSelected()) {
                tdto.setEnabled(true);
            }
        }
//      ccolor.setEnabled(true);
        bmodificar.setText("Visualizar");
        bmodificar.setToolTipText("Visualizar campos");
    } else {
        //si el botón tiene el texto Visualizar
        tcodigo.setEnabled(false);
        cagentes.setEnabled(false);
        tdto.setEnabled(false);
        tprecio.setEnabled(false);
        rbPrecioAcordado.setEnabled(false);
        rbPrecioTarifa.setEnabled(false);
        cbDescuento.setEnabled(false);
        bmodificar.setText("Modificar");
        bmodificar.setToolTipText("Modificar campos");
        ccolor.setEnabled(false);
    }
}//GEN-LAST:event_bmodificarActionPerformed

private void rbPrecioTarifaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbPrecioTarifaActionPerformed
    cbDescuento.setEnabled(true);
}//GEN-LAST:event_rbPrecioTarifaActionPerformed

private void rbPrecioAcordadoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbPrecioAcordadoActionPerformed
    cbDescuento.setEnabled(false);
    tdto.setText("");
    tdto.setEnabled(false);
    cbDescuento.setSelected(false);
}//GEN-LAST:event_rbPrecioAcordadoActionPerformed

private void cbDescuentoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbDescuentoActionPerformed
    if (cbDescuento.isSelected()) {
        tdto.setEnabled(true);
    } else {
        tdto.setEnabled(false);
        tdto.setText("");
    }
}//GEN-LAST:event_cbDescuentoActionPerformed

private void tprecioKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tprecioKeyReleased
    int tamaño = tprecio.getText().length();
    if (tamaño > 0) {
        char c = tprecio.getText().charAt(tamaño - 1);

        if (c == '.') {
            String contenidoAntiguo = tprecio.getText().replace(".", ",");
            tprecio.setText(contenidoAntiguo);
            c = ',';
        }

        if (!((c >= '0' && c <= '9') || c == ',')) {
            String str = tprecio.getText().substring(0, tamaño - 1);
            tprecio.setText(str);
        } else if (c == ',') {
            int indicePunto = tprecio.getText().indexOf(',');
            if (indicePunto != (tamaño - 1)) {
                String str = tprecio.getText().substring(0, tamaño - 1);
                tprecio.setText(str);
            }
        }
    }
}//GEN-LAST:event_tprecioKeyReleased

private void tdtoKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tdtoKeyReleased
    int tamaño = tdto.getText().length();
    if (tamaño > 0) {
        char c = tdto.getText().charAt(tamaño - 1);

        if (c == '.') {
            String contenidoAntiguo = tdto.getText().replace(".", ",");
            tdto.setText(contenidoAntiguo);
            c = ',';
        }

        if (!((c >= '0' && c <= '9') || c == ',')) {
            String str = tdto.getText().substring(0, tamaño - 1);
            tdto.setText(str);
        } else if (c == ',') {
            int indicePunto = tdto.getText().indexOf(',');
            if (indicePunto != (tamaño - 1)) {
                String str = tdto.getText().substring(0, tamaño - 1);
                tdto.setText(str);
            }
        }
    }
}//GEN-LAST:event_tdtoKeyReleased

    private boolean hayCambios() {

        //if (colorAntiguo != 0){

        return !((String) cagentes.getSelectedItem()).equals(agenteAntiguo)
                || !tcodigo.getText().equals(codigoAntiguo)
                || !precioTarifaAntiguo == rbPrecioTarifa.isSelected()
                || !precioAcordadoAntiguo == rbPrecioAcordado.isSelected()
                || !descuentoAntiguo == cbDescuento.isSelected()
                | !(dtoAntiguo.toString().equals(tdto.getText()))
                || !tprecio.getText().equals(precioAntiguo)
                || !tdto.getText().equals(dtoAntiguo)
                || !tDescripcion.getText().equals(descripcionAntigua)
                || !((String) (ccolor.getSelectedItem())).equals(BaseDatos.obtenerColorPorIid(colorAntiguo).getCod_color());
        /*}else if (!ccolor.getSelectedItem().equals("N/C")){
         return true;
         }
         return false;
         }*/

    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton baceptar;
    private javax.swing.JButton bcancelar;
    private javax.swing.JButton bmodificar;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JComboBox cagentes;
    private javax.swing.JCheckBox cbDescuento;
    private javax.swing.JComboBox ccolor;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JLabel lDescripcion;
    private javax.swing.JLabel lDto;
    private javax.swing.JLabel lPrecio;
    private javax.swing.JLabel larticulo;
    private javax.swing.JLabel lcodigo;
    private javax.swing.JLabel lproveedor;
    private javax.swing.JLabel lproveedor1;
    private javax.swing.JRadioButton rbPrecioAcordado;
    private javax.swing.JRadioButton rbPrecioTarifa;
    private javax.swing.JTextArea tDescripcion;
    private javax.swing.JTextField tarticulo;
    private javax.swing.JTextField tcodigo;
    private javax.swing.JTextField tdto;
    private javax.swing.JTextField tprecio;
    // End of variables declaration//GEN-END:variables
}
