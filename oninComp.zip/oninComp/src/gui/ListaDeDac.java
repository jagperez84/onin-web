package gui;

import acceso.BaseDatos;
import bean.Articulo;
import bean.Dac;
import bean.Empresa;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JOptionPane;
import javax.swing.KeyStroke;
import modelo.Modelo;

public class ListaDeDac extends javax.swing.JFrame {
    Empresa e;
    
    public ListaDeDac(Empresa e) {
        super("Artículos Compuestos - Mantenimiento");
        this.e = e;
        initComponents();
        crearIconosBotones();
        crearAcciones();
    }

    private void cerrarListaDeDac() {
        removeAll();
        dispose();
    }

    private void crearAcciones() {
        KeyStroke escapeKeyStroke = KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false);
        Action escapeAction = new AbstractAction() {
            public void actionPerformed(ActionEvent e) {
                cerrarListaDeDac();
            }
        }; 
        getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(escapeKeyStroke, "ESCAPE");
        getRootPane().getActionMap().put("ESCAPE", escapeAction);
        
        KeyStroke f1KeyStroke = KeyStroke.getKeyStroke (KeyEvent.VK_F1, 0, false);
        Action f1Action = new AbstractAction() {
            public void actionPerformed(ActionEvent ev) {
                crearDac();
            }
        }; 
        getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(f1KeyStroke, "F1");
        getRootPane().getActionMap().put("F1", f1Action);
    }

    private void crearDac() {
        NuevoDAC nd = new NuevoDAC(e, "Artículo Compuesto - Creación");
        nd.setDefaultCloseOperation(NuevoDAC.DISPOSE_ON_CLOSE);
        nd.setLocationRelativeTo(null);
        nd.setVisible(true);
        cerrarListaDeDac();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTabbedPane1 = new javax.swing.JTabbedPane();
        pcodigo = new javax.swing.JPanel();
        pnombre1 = new javax.swing.JPanel();
        lbusqueda1 = new javax.swing.JLabel();
        tbusqueda1 = new javax.swing.JTextField();
        bbusquedarapida1 = new javax.swing.JCheckBox();
        jScrollPane2 = new javax.swing.JScrollPane();
        Modelo modelo1 = new Modelo();
        tDac1 = new javax.swing.JTable(modelo1);
        bcerrar = new javax.swing.JButton();
        bvisualizar = new javax.swing.JButton();
        bborrar = new javax.swing.JButton();
        bcrear = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        lbusqueda1.setText("Búsqueda rápida");

        tbusqueda1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tbusqueda1KeyReleased(evt);
            }
        });

        bbusquedarapida1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bbusquedarapida1ActionPerformed(evt);
            }
        });

        modelo1.addColumn("Código");

        List ldac1 = BaseDatos.getListaDac(e.getIid());
        Iterator<Dac> it1;
        Object[] fila1;
        Articulo ar1;
        if(ldac1 != null){
            for (it1 = ldac1.iterator(); it1.hasNext();) {
                fila1 = new Object[1];
                ar1 = BaseDatos.obtenerArticuloPorIid(it1.next().getArticulo().getIid());
                fila1[0] = ar1.getCod_articulo();
                modelo1.addRow(fila1);
            }
        }
        tDac1.getColumnModel().getColumn(0).setPreferredWidth(230);
        tDac1.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        tDac1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tDac1MouseClicked(evt);
            }
        });
        tDac1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tDac1KeyPressed(evt);
            }
        });
        jScrollPane2.setViewportView(tDac1);

        org.jdesktop.layout.GroupLayout pnombre1Layout = new org.jdesktop.layout.GroupLayout(pnombre1);
        pnombre1.setLayout(pnombre1Layout);
        pnombre1Layout.setHorizontalGroup(
            pnombre1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, pnombre1Layout.createSequentialGroup()
                .add(10, 10, 10)
                .add(lbusqueda1)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(tbusqueda1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 326, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(bbusquedarapida1)
                .addContainerGap(320, Short.MAX_VALUE))
            .add(org.jdesktop.layout.GroupLayout.TRAILING, jScrollPane2, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 763, Short.MAX_VALUE)
        );
        pnombre1Layout.setVerticalGroup(
            pnombre1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(pnombre1Layout.createSequentialGroup()
                .addContainerGap()
                .add(pnombre1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(lbusqueda1)
                    .add(tbusqueda1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(bbusquedarapida1))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jScrollPane2, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 301, Short.MAX_VALUE))
        );

        org.jdesktop.layout.GroupLayout pcodigoLayout = new org.jdesktop.layout.GroupLayout(pcodigo);
        pcodigo.setLayout(pcodigoLayout);
        pcodigoLayout.setHorizontalGroup(
            pcodigoLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(0, 763, Short.MAX_VALUE)
            .add(pcodigoLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                .add(pcodigoLayout.createSequentialGroup()
                    .add(0, 0, 0)
                    .add(pnombre1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .add(0, 0, 0)))
        );
        pcodigoLayout.setVerticalGroup(
            pcodigoLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(0, 338, Short.MAX_VALUE)
            .add(pcodigoLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                .add(pcodigoLayout.createSequentialGroup()
                    .add(0, 0, 0)
                    .add(pnombre1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .add(0, 0, 0)))
        );

        jTabbedPane1.addTab("Código", pcodigo);

        bcerrar.setText("Cerrar");
        bcerrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bcerrarActionPerformed(evt);
            }
        });

        bvisualizar.setText("Visualizar");
        bvisualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bvisualizarActionPerformed(evt);
            }
        });

        bborrar.setText("Borrar");
        bborrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bborrarActionPerformed(evt);
            }
        });

        bcrear.setText("Crear");
        bcrear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bcrearActionPerformed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout layout = new org.jdesktop.layout.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jTabbedPane1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 768, Short.MAX_VALUE)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, layout.createSequentialGroup()
                .addContainerGap(356, Short.MAX_VALUE)
                .add(bcrear, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 93, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                .add(bborrar, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 90, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                .add(bvisualizar, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 101, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                .add(bcerrar, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 88, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, layout.createSequentialGroup()
                .add(jTabbedPane1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 366, Short.MAX_VALUE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(bcerrar)
                    .add(bvisualizar)
                    .add(bborrar)
                    .add(bcrear))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

private void bcrearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bcrearActionPerformed
    crearDac();
}//GEN-LAST:event_bcrearActionPerformed

private void bborrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bborrarActionPerformed
   borrarDac();
}//GEN-LAST:event_bborrarActionPerformed

private void bvisualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bvisualizarActionPerformed
    visualizarDac();
}//GEN-LAST:event_bvisualizarActionPerformed

private void bcerrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bcerrarActionPerformed
    cerrarListaDeDac();
}//GEN-LAST:event_bcerrarActionPerformed

private void tDac1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tDac1MouseClicked
if (evt.getClickCount() == 2) {
        visualizarDac();
    }
}//GEN-LAST:event_tDac1MouseClicked

private void tDac1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tDac1KeyPressed
    if (evt.getKeyChar() == KeyEvent.VK_ENTER) {
        visualizarDac();
    } else if(evt.getKeyChar() == KeyEvent.VK_DELETE){
        borrarDac();
    }
}//GEN-LAST:event_tDac1KeyPressed

private void bbusquedarapida1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bbusquedarapida1ActionPerformed
    if (bbusquedarapida1.isSelected()) {
        actualizarDac1(BaseDatos.busquedaRapidaDacPorCodigo(tbusqueda1.getText().toLowerCase()));
    } else {
        actualizarDac1(BaseDatos.getListaDac(e.getIid()));
    }
}//GEN-LAST:event_bbusquedarapida1ActionPerformed

private void tbusqueda1KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tbusqueda1KeyReleased
    if (bbusquedarapida1.isSelected()) {
        actualizarDac1(BaseDatos.busquedaRapidaDacPorCodigo(tbusqueda1.getText().toLowerCase()));
    }
}//GEN-LAST:event_tbusqueda1KeyReleased

    private void borrarDac(){
        try {
            int indicePanel = jTabbedPane1.getSelectedIndex();
            int indiceFila = -1;

            if (indicePanel == 0) {
                indiceFila = tDac1.getSelectedRow();
            }

            if (indiceFila >= 0) {

                int eliminar = JOptionPane.showConfirmDialog(null, "¿Está seguro de que desea eliminar el elemento seleccionado?", "¿Eliminar?", JOptionPane.YES_NO_OPTION);
                if (eliminar == 0) {

                    //obtenemos el codigo de la familia de venta
                    String codigo = "";
                    if (indicePanel == 0) {
                        codigo = (String) tDac1.getModel().getValueAt(indiceFila, 0);
                    }
                    
                    Dac dac = BaseDatos.obtenerDacPorCodigoArticulo(codigo, e.getIid());

                    if (BaseDatos.eliminarDac(dac.getIid())) {
                        completarPantalla();
                    } else {
                        JOptionPane.showMessageDialog(null, "No se ha podido eliminar el elemento", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
            } else {
                JOptionPane.showMessageDialog(null, "No hay seleccionado ningún elemento", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Este elemento no se puede eliminar", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void visualizarDac() {
        int indicePanel = this.jTabbedPane1.getSelectedIndex();
        int indiceFila = -1;

        if (indicePanel == 0) {
            indiceFila = this.tDac1.getSelectedRow();
        } 

        if (indiceFila >= 0) {

            String codigo = "";
            if (indicePanel == 0) {
                codigo = (String) tDac1.getModel().getValueAt(indiceFila, 0);
            }
            
            Dac dac = BaseDatos.obtenerDacPorCodigoArticulo(codigo, e.getIid());
            NuevoDAC nd = new NuevoDAC(e, dac, "Artículo Compuesto - Modificación");
            nd.setDefaultCloseOperation(NuevoAgente.DISPOSE_ON_CLOSE);
            nd.setLocationRelativeTo(null);
            nd.setVisible(true);
            cerrarListaDeDac();
        } else {
            JOptionPane.showMessageDialog(null, "No hay seleccionado ningún elemento", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void actualizarDac1(List listaDac) {
        Modelo modelo1 = (Modelo) this.tDac1.getModel();
        int i, j = modelo1.getRowCount();

        //eliminamos todas las filas
        for (i = 0; i < j; i++) {
            modelo1.removeRow(0);
        }

        if (listaDac == null) {
            listaDac = new ArrayList();
        }

        if (listaDac != null) {
            Iterator<Dac> it1;
            Object[] fila1;
			Articulo ar1;
            for (it1 = listaDac.iterator(); it1.hasNext();) {
               fila1 = new Object[1];
               ar1 = BaseDatos.obtenerArticuloPorIid(it1.next().getArticulo().getIid());
               fila1[0] = ar1.getCod_articulo();
               modelo1.addRow(fila1);
            }
        }
    }

    private void completarPantalla() {
        if (bbusquedarapida1.isSelected()) {
            actualizarDac1(BaseDatos.busquedaRapidaDacPorCodigo(tbusqueda1.getText().toLowerCase()));
        } else {
            actualizarDac1(BaseDatos.getListaDac(e.getIid()));
        }
    }
    
    private void crearIconosBotones(){
        URL url = getClass().getResource("/iconos/buscar.gif");
        ImageIcon icono = new ImageIcon(url);
        bvisualizar.setIcon(icono);
        
        url = getClass().getResource("/iconos/eliminar.png");
        icono = new ImageIcon(url);
        bborrar.setIcon(icono);
        
        url = getClass().getResource("/iconos/cancelar.gif");
        icono = new ImageIcon(url);
        bcerrar.setIcon(icono);
        
        url = getClass().getResource("/iconos/aceptar.png");
        icono = new ImageIcon(url);
        bcrear.setIcon(icono);
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bborrar;
    private javax.swing.JCheckBox bbusquedarapida1;
    private javax.swing.JButton bcerrar;
    private javax.swing.JButton bcrear;
    private javax.swing.JButton bvisualizar;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JLabel lbusqueda1;
    private javax.swing.JPanel pcodigo;
    private javax.swing.JPanel pnombre1;
    private javax.swing.JTable tDac1;
    private javax.swing.JTextField tbusqueda1;
    // End of variables declaration//GEN-END:variables
}
