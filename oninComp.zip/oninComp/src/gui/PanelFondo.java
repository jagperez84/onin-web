package gui;

import javax.swing.JPanel;
import java.awt.*;
import java.net.URL;

public  class PanelFondo extends JPanel
{
	private TexturePaint fondo;
	
	public PanelFondo(URL imgFondo)
	{
		fondo = images.carga(imgFondo, this);
	}
	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		Graphics2D g2d = (Graphics2D)g;
		Dimension d = getSize();
		g2d.setPaint(fondo);
		g2d.fill(new Rectangle(0,0,d.width,d.height));
	}
}

