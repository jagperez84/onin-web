package gui;

import acceso.BaseDatos;
import auxiliar.HebraFamiliaVentas;
import bean.Colores;
import gui.*;
import bean.Empresa;
import bean.FamiliaVenta;
import bean.MedidasFamiliaVenta;
import bean.TipoControl;
import bean.TipoProducto;
import bean.Usuario;
import bean.colorFamilia;
import bean.precioFamilia;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.KeyStroke;
import modelo.Modelo;
import util.Constantes;

public class NuevaFamiliaVenta extends javax.swing.JFrame {
    private FamiliaVenta fv;
    private Empresa e;
    private boolean crear;
    private String codigoAntiguo;
    private String nombreAntiguo;
    private String tipoMontajeAntiguo;
    private String tipocontrolAntiguo;
    private String tipoproductoAntiguo;
    private boolean cambioMedidas;
    private boolean cambioColores;
    private List lMedidas;
    private List lColores;
    private String tipoControlStrAnterior = "";
    private boolean mostrarMensaje = false;
    private boolean recortableAntiguo;
    private boolean confeccionadoAntiguo;
    private String restoMinimoAntiguo;
    private String ptcB;
    private String pvpB;
    private String upcB;
    private String ptcR;
    private String pvpR;
    private String upcR;
    private String ptcE;
    private String pvpE;
    private String upcE;
    private precioFamilia pFb;
    private precioFamilia pFr;
    private precioFamilia pFe;
    private precioFamilia pFs;
    private Usuario u;

    public NuevaFamiliaVenta(Empresa e, Usuario u, String titulo) {
        super(titulo);
        this.e = e;
        fv = new FamiliaVenta();
        crear = true;
        cambioMedidas = false;
        lMedidas = new ArrayList();
        tipoControlStrAnterior = "";
        this.u = u;
        initComponents();
        bmodificar.setVisible(false);
        bcancelar.setToolTipText("Cancelar la creación de la familia de ventas");
        baceptar.setToolTipText("Crear familia de ventas");
        crearIconosBotones();
        crearAcciones();
        cTipoMontaje.setSelectedItem(Constantes.FAMILIA_AMBOS);
        mostrarMensaje = true;
        lRestoMinimo.setVisible(false);
        tRestoMinimo.setVisible(false);
        bAplicar.setEnabled(false);
    }

    public NuevaFamiliaVenta(Empresa e, Usuario u, String titulo, FamiliaVenta fv) {
        super(titulo);
        this.fv = fv;
        this.e = e;
        this.u = u;
        crear = false;
        cambioMedidas = false;
        lMedidas = BaseDatos.getListaMedidasFamiliaVenta(fv.getIid());
        lColores = BaseDatos.getColoresPorFamilia(e.getIid(), fv.getIid());
        initComponents();
        tCodigo.setText(fv.getCod_familia());
        tNombre.setText(fv.getNombre());

        cbRecortable.setSelected(fv.getRecortable() != null && fv.getRecortable());
        cbConfeccionado.setSelected(fv.getConfeccionable() != null && fv.getConfeccionable());
        restoMinimoAntiguo = "";
        if (fv.getRestoMinimo() != null) {
            tRestoMinimo.setText(util.Util.convertirPuntoAComa(fv.getRestoMinimo().toString()));
            restoMinimoAntiguo = fv.getRestoMinimo().toString();
        }
        tCodigo.setEnabled(false);
        tNombre.setEnabled(false);
        ctcontrol.setEnabled(false);
        ctproducto.setEnabled(false);
        codigoAntiguo = fv.getCod_familia();
        nombreAntiguo = fv.getNombre();
        tipoMontajeAntiguo = fv.getTipoMontaje();
        tipoproductoAntiguo = (String) ctproducto.getSelectedItem();
        tipocontrolAntiguo = (String) ctcontrol.getSelectedItem();
        tipoControlStrAnterior = tipocontrolAntiguo;
        confeccionadoAntiguo = cbConfeccionado.isSelected();
        recortableAntiguo = cbRecortable.isSelected();

        //Informamos los precios por familia
        //Blanco / SC
        pFs = BaseDatos.obtenerPrecioFamilia(e, fv, "0");
        //Base
        pFb = BaseDatos.obtenerPrecioFamilia(e, fv, "1");
        //Ral
        pFr = BaseDatos.obtenerPrecioFamilia(e, fv, "2");
        //Especial
        pFe = BaseDatos.obtenerPrecioFamilia(e, fv, "3");

        
        if (pFs != null) {
            tPVPs.setText(util.Util.convertirPuntoAComa(pFs.getPvp().toString()));
            tPTCs.setText(util.Util.convertirPuntoAComa(pFs.getPtc().toString()));
            tUPCs.setText(util.Util.convertirPuntoAComa(pFs.getUpc().toString()));
        }
        
        if (pFb != null) {
            tPVPb.setText(util.Util.convertirPuntoAComa(pFb.getPvp().toString()));
            tPTCb.setText(util.Util.convertirPuntoAComa(pFb.getPtc().toString()));
            tUPCb.setText(util.Util.convertirPuntoAComa(pFb.getUpc().toString()));
        }

        if (pFr != null) {
            tPVPr.setText(util.Util.convertirPuntoAComa(pFr.getPvp().toString()));
            tPTCr.setText(util.Util.convertirPuntoAComa(pFr.getPtc().toString()));
            tUPCr.setText(util.Util.convertirPuntoAComa(pFr.getUpc().toString()));
        }

        if (pFe != null) {
            tPVPe.setText(util.Util.convertirPuntoAComa(pFe.getPvp().toString()));
            tPTCe.setText(util.Util.convertirPuntoAComa(pFe.getPtc().toString()));
            tUPCe.setText(util.Util.convertirPuntoAComa(pFe.getUpc().toString()));
        }

        bcancelar.setToolTipText("Cancelar la creación de la familia de venta");
        baceptar.setToolTipText("Realizar la modificación");
        bmodificar.setToolTipText("Modificar campos");
        bCrear.setEnabled(false);
        bVisualizar.setEnabled(false);
        bBorrar.setEnabled(false);
        tMedidas.setEnabled(false);
        cTipoMontaje.setEnabled(false);
        cbRecortable.setEnabled(false);
        cbConfeccionado.setEnabled(false);
        tRestoMinimo.setEnabled(false);
        crearIconosBotones();
        crearAcciones();
        mostrarMensaje = true;

        if (fv.getNombre().equalsIgnoreCase(Constantes.NOMBRE_FAM_PRECIO)) {
            this.bmodificar.setVisible(false);
        }

        if (tipoMontajeAntiguo == null || tipoMontajeAntiguo.equals("")) {
            cTipoMontaje.setSelectedItem(Constantes.FAMILIA_AMBOS);
        } else {
            cTipoMontaje.setSelectedItem(tipoMontajeAntiguo);
        }

        this.lRestoMinimo.setVisible(cbConfeccionado.isSelected());
        this.tRestoMinimo.setVisible(cbConfeccionado.isSelected());
    }

    public boolean modificarMedida(MedidasFamiliaVenta mfv, MedidasFamiliaVenta mfvAntigua) {
        Iterator<MedidasFamiliaVenta> iter = this.lMedidas.iterator();
        boolean existe = false;
        MedidasFamiliaVenta temp;
        int indiceAnterior = -1, contador = 0;

        while (iter.hasNext() && indiceAnterior == -1 && !existe) {
            temp = iter.next();
            if (iguales(mfvAntigua, temp)) {
                indiceAnterior = contador;
            }
            if (!existe && iguales(temp, mfv)) {
                existe = true;
            }
            contador++;
        }

        if (!existe) {
            lMedidas.remove(indiceAnterior);
            lMedidas.add(indiceAnterior, mfv);
            actualizarMedidas();
            cambioMedidas = true;
        } else {
            JOptionPane.showMessageDialog(null, "La medida ya existe", "Error", JOptionPane.ERROR_MESSAGE);
        }

        return !existe;
    }

    private void crearAcciones() {
        KeyStroke escapeKeyStroke = KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false);
        Action escapeAction = new AbstractAction() {
            public void actionPerformed(ActionEvent e) {
                cerrarVentana();
            }
        };
        getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(escapeKeyStroke, "ESCAPE");
        getRootPane().getActionMap().put("ESCAPE", escapeAction);
    }

    private void cerrarVentana() {
        removeAll();
        dispose();
    }

    private boolean iguales(MedidasFamiliaVenta mfv1, MedidasFamiliaVenta mfv2) {
        String medida1aStr = "";
        String medida2aStr = "";
        String medida3aStr = "";
        String medida4aStr = "";
        String medida5aStr = "";

        if (mfv1.getMedida1() != null) {
            medida1aStr = mfv1.getMedida1().toString();
        }
        if (mfv1.getMedida2() != null) {
            medida2aStr = mfv1.getMedida2().toString();
        }
        if (mfv1.getMedida3() != null) {
            medida3aStr = mfv1.getMedida3().toString();
        }
        if (mfv1.getMedida4() != null) {
            medida4aStr = mfv1.getMedida4().toString();
        }
        if (mfv1.getMedida5() != null) {
            medida5aStr = mfv1.getMedida5().toString();
        }

        String medida1bStr = "";
        String medida2bStr = "";
        String medida3bStr = "";
        String medida4bStr = "";
        String medida5bStr = "";

        if (mfv2.getMedida1() != null) {
            medida1bStr = mfv2.getMedida1().toString();
        }
        if (mfv2.getMedida2() != null) {
            medida2bStr = mfv2.getMedida2().toString();
        }
        if (mfv2.getMedida3() != null) {
            medida3bStr = mfv2.getMedida3().toString();
        }
        if (mfv2.getMedida4() != null) {
            medida4bStr = mfv2.getMedida4().toString();
        }
        if (mfv2.getMedida5() != null) {
            medida5bStr = mfv2.getMedida5().toString();
        }

        return medida1aStr.equals(medida1bStr) && medida2aStr.equals(medida2bStr) && medida3aStr.equals(medida3bStr) && medida4aStr.equals(medida4bStr) && medida5aStr.equals(medida5bStr);
    }

    private boolean igualesC(colorFamilia cf1, colorFamilia cf2) {
        if (cf1.getIidColor().equals(cf2.getIidColor()) && cf1.getIidFamilia().equals(cf2.getIidFamilia()) && cf1.getIidEmpresa().equals(cf2.getIidEmpresa())) {
            return true;
        } else {
            return false;
        }
    }

    public boolean insertarMedida(MedidasFamiliaVenta mfv) {
        Iterator<MedidasFamiliaVenta> iter = this.lMedidas.iterator();
        boolean seguir = true;

        while (iter.hasNext() && seguir) {
            seguir = !iguales(mfv, iter.next());
        }

        if (seguir) {
            lMedidas.add(mfv);
            actualizarMedidas();
            cambioMedidas = true;
        } else {
            JOptionPane.showMessageDialog(null, "La medida ya existe", "Error", JOptionPane.ERROR_MESSAGE);
        }

        return seguir;
    }

    public boolean insertarColor(colorFamilia cf) {
        Iterator<colorFamilia> iter = this.lColores.iterator();
        boolean seguir = true;

        while (iter.hasNext() && seguir) {
            seguir = !igualesC(cf, iter.next());
        }

        if (seguir) {
            lColores.add(cf);
            actualizarColores();
            cambioColores = true;
        } else {
            JOptionPane.showMessageDialog(null, "El color ya existe", "Error", JOptionPane.ERROR_MESSAGE);
        }

        return seguir;
    }

    private void actualizarMedidas() {
        Modelo modelo = (Modelo) this.tMedidas.getModel();
        int i, j = modelo.getRowCount();

        //eliminamos todas las filas
        for (i = 0; i < j; i++) {
            modelo.removeRow(0);
        }

        MedidasFamiliaVenta mfv;
        Object[] fila;
        for (Iterator it = lMedidas.iterator(); it.hasNext();) {
            fila = new Object[5];
            mfv = (MedidasFamiliaVenta) it.next();
            if (mfv.getMedida1() != null) {
                fila[0] = String.valueOf(mfv.getMedida1());
            }
            if (mfv.getMedida2() != null) {
                fila[1] = String.valueOf(mfv.getMedida2());
            }
            if (mfv.getMedida3() != null) {
                fila[2] = String.valueOf(mfv.getMedida3());
            }
            if (mfv.getMedida4() != null) {
                fila[3] = String.valueOf(mfv.getMedida4());
            }
            if (mfv.getMedida5() != null) {
                fila[4] = String.valueOf(mfv.getMedida5());
            }
            modelo.addRow(fila);
        }
    }

    private void actualizarColores() {
        Modelo modelo = (Modelo) this.tMedidasC.getModel();
        int i, j = modelo.getRowCount();

        //eliminamos todas las filas
        for (i = 0; i < j; i++) {
            modelo.removeRow(0);
        }

        colorFamilia cF;
        Colores c;
        Iterator<colorFamilia> itC;
        Object[] filaC;
        if (lColores != null) {
            for (itC = lColores.iterator(); itC.hasNext();) {
                filaC = new Object[3];
                c = BaseDatos.obtenerColorPorIid(itC.next().getIidColor());
                if (c != null) {
                    filaC[0] = c.getCod_color();
                    filaC[1] = c.getDescripcion();
                    filaC[2] = c.getRal();
                }
                modelo.addRow(filaC);
            }
        }
    }

    private void crearIconosBotones() {
        URL url = getClass().getResource("/iconos/cancelar.gif");
        ImageIcon icono = new ImageIcon(url);
        bcancelar.setIcon(icono);

        url = getClass().getResource("/iconos/guardarYvolver.png");
        icono = new ImageIcon(url);
        baceptar.setIcon(icono);

        url = getClass().getResource("/iconos/editar.png");
        icono = new ImageIcon(url);
        bmodificar.setIcon(icono);

        url = getClass().getResource("/iconos/masAzul.png");
        icono = new ImageIcon(url);
        bCrear.setIcon(icono);
        bCrearC.setIcon(icono);

        url = getClass().getResource("/iconos/gomaBorrar.gif");
        icono = new ImageIcon(url);
        bBorrar.setIcon(icono);
        bBorrarC.setIcon(icono);

        url = getClass().getResource("/iconos/modificar_despiece.png");
        icono = new ImageIcon(url);
        bVisualizar.setIcon(icono);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        baceptar = new javax.swing.JButton();
        bcancelar = new javax.swing.JButton();
        bmodificar = new javax.swing.JButton();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        pGeneral = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        ltproducto = new javax.swing.JLabel();
        ltcontrol = new javax.swing.JLabel();
        ctproducto = new javax.swing.JComboBox();
        ctcontrol = new javax.swing.JComboBox();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        tNombre = new javax.swing.JTextField();
        lnombre = new javax.swing.JLabel();
        tCodigo = new javax.swing.JTextField();
        lcodigo = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        cTipoMontaje = new javax.swing.JComboBox();
        cbConfeccionado = new javax.swing.JCheckBox();
        tRestoMinimo = new javax.swing.JTextField();
        lRestoMinimo = new javax.swing.JLabel();
        cbRecortable = new javax.swing.JCheckBox();
        pMedidas = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        Modelo modelo = new Modelo();
        tMedidas = new javax.swing.JTable(modelo);
        bVisualizar = new javax.swing.JButton();
        bBorrar = new javax.swing.JButton();
        bCrear = new javax.swing.JButton();
        pColores = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        Modelo modeloC = new Modelo();
        tMedidasC = new javax.swing.JTable(modeloC);
        bBorrarC = new javax.swing.JButton();
        bCrearC = new javax.swing.JButton();
        pColores1 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        bAplicar = new javax.swing.JButton();
        jLabel13 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        tPVPb = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        tPTCb = new javax.swing.JTextField();
        tUPCb = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        anadirB = new javax.swing.JCheckBox();
        jPanel3 = new javax.swing.JPanel();
        tPVPr = new javax.swing.JTextField();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        tPTCr = new javax.swing.JTextField();
        tUPCr = new javax.swing.JTextField();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        anadirR = new javax.swing.JCheckBox();
        jPanel4 = new javax.swing.JPanel();
        tPVPe = new javax.swing.JTextField();
        jLabel22 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        tPTCe = new javax.swing.JTextField();
        tUPCe = new javax.swing.JTextField();
        jLabel25 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        anadirE = new javax.swing.JCheckBox();
        jPanel5 = new javax.swing.JPanel();
        anadirS = new javax.swing.JCheckBox();
        jLabel12 = new javax.swing.JLabel();
        tPVPs = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        jLabel28 = new javax.swing.JLabel();
        tPTCs = new javax.swing.JTextField();
        jLabel29 = new javax.swing.JLabel();
        jLabel30 = new javax.swing.JLabel();
        tUPCs = new javax.swing.JTextField();
        jLabel31 = new javax.swing.JLabel();

        baceptar.setText("Aceptar");
        baceptar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                baceptarActionPerformed(evt);
            }
        });

        bcancelar.setText("Cancelar");
        bcancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bcancelarActionPerformed(evt);
            }
        });

        bmodificar.setText("Modificar");
        bmodificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bmodificarActionPerformed(evt);
            }
        });

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder("Tarifas por escalado"));

        ltproducto.setText("Tipo de producto");

        ltcontrol.setText("Tipo de control");

        ctproducto.setModel(new javax.swing.DefaultComboBoxModel(new String[] {}));

        ctcontrol.setModel(new javax.swing.DefaultComboBoxModel(new String[] {}));
        ctcontrol.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ctcontrolActionPerformed(evt);
            }
        });

        jLabel1.setText("Indique el tipo de producto y tipo de control que se utilizarán para identificar");

        jLabel2.setText("la configuración del orden de escalado a aplicar a las tarifas por escalado que");

        jLabel3.setText("se le definan a esta familia");

        org.jdesktop.layout.GroupLayout jPanel1Layout = new org.jdesktop.layout.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING, false)
                        .add(org.jdesktop.layout.GroupLayout.LEADING, jPanel1Layout.createSequentialGroup()
                            .add(ltproducto)
                            .add(10, 10, 10)
                            .add(ctproducto, 0, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .add(org.jdesktop.layout.GroupLayout.LEADING, jPanel1Layout.createSequentialGroup()
                            .add(ltcontrol)
                            .add(20, 20, 20)
                            .add(ctcontrol, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 262, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                    .add(jLabel1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 370, Short.MAX_VALUE)
                    .add(jLabel2, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .add(jLabel3))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel1Layout.createSequentialGroup()
                .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(ltcontrol)
                    .add(ctcontrol, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(ctproducto, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(ltproducto))
                .add(18, 18, 18)
                .add(jLabel1)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jLabel2)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jLabel3)
                .addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        List ltipoproducto = BaseDatos.getListaTipoProductos(e);
        TipoProducto tp;
        ctproducto.addItem(Constantes.VACIO);
        for (Iterator it = ltipoproducto.iterator(); it.hasNext();) {
            tp = (TipoProducto) it.next();
            ctproducto.addItem(tp.getDescripcion());
        }

        if(! crear && fv != null && fv.getIid_tipo_producto() != null){
            ctproducto.setSelectedItem(fv.getIid_tipo_producto().getDescripcion());
        }
        else{
            ctproducto.setSelectedIndex(0);
        }
        List ltipocontrol = BaseDatos.getListaTipoControl();
        TipoControl tc;
        ctcontrol.addItem(Constantes.VACIO);
        for (Iterator it = ltipocontrol.iterator(); it.hasNext();) {
            tc = (TipoControl)  it.next();
            ctcontrol.addItem(tc.getNombre());
        }

        if(!crear && fv != null && fv.getIid_tipo_control() != null){
            ctcontrol.setSelectedItem(fv.getIid_tipo_control().getNombre());
        }
        else{
            ctcontrol.setSelectedIndex(0);
        }

        tNombre.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tNombreKeyReleased(evt);
            }
        });

        lnombre.setText("Nombre");

        tCodigo.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tCodigoKeyReleased(evt);
            }
        });

        lcodigo.setText("Código");

        jLabel4.setText("Montaje");

        cTipoMontaje.setModel(new javax.swing.DefaultComboBoxModel(new String[] { Constantes.FAMILIA_CONFECCION, Constantes.FAMILIA_TALLER, Constantes.FAMILIA_AMBOS}));

        cbConfeccionado.setText("Confeccionable");
        cbConfeccionado.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbConfeccionadoActionPerformed(evt);
            }
        });

        tRestoMinimo.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tRestoMinimoKeyReleased(evt);
            }
        });

        lRestoMinimo.setText("Resto mínimo");

        cbRecortable.setText("Recortable");
        cbRecortable.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbRecortableActionPerformed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout pGeneralLayout = new org.jdesktop.layout.GroupLayout(pGeneral);
        pGeneral.setLayout(pGeneralLayout);
        pGeneralLayout.setHorizontalGroup(
            pGeneralLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(pGeneralLayout.createSequentialGroup()
                .addContainerGap()
                .add(pGeneralLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                    .add(pGeneralLayout.createSequentialGroup()
                        .add(pGeneralLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(lcodigo)
                            .add(lnombre))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(pGeneralLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(tNombre, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 327, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(tCodigo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 58, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                    .add(jPanel1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(pGeneralLayout.createSequentialGroup()
                        .add(jLabel4, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 48, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(cTipoMontaje, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 127, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                    .add(pGeneralLayout.createSequentialGroup()
                        .add(cbRecortable)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                        .add(cbConfeccionado)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                        .add(lRestoMinimo)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(tRestoMinimo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 37, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(19, Short.MAX_VALUE))
        );
        pGeneralLayout.setVerticalGroup(
            pGeneralLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(pGeneralLayout.createSequentialGroup()
                .addContainerGap()
                .add(pGeneralLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(lcodigo)
                    .add(tCodigo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(pGeneralLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(lnombre)
                    .add(tNombre, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                .add(jPanel1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .add(11, 11, 11)
                .add(pGeneralLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(jLabel4)
                    .add(cTipoMontaje, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(pGeneralLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(cbRecortable)
                    .add(cbConfeccionado)
                    .add(tRestoMinimo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(lRestoMinimo))
                .addContainerGap(92, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Datos Generales", pGeneral);

        modelo.addColumn("Medida 1");
        modelo.addColumn("Medida 2");
        modelo.addColumn("Medida 3");
        modelo.addColumn("Medida 4");
        modelo.addColumn("Medida 5");
        MedidasFamiliaVenta mfv;
        Iterator<MedidasFamiliaVenta> it;
        Object[] fila;
        if(lMedidas != null){
            for (it = lMedidas.iterator(); it.hasNext();) {
                fila = new Object[5];
                mfv = it.next();
                if(mfv.getMedida1() != null){
                    fila[0] = String.valueOf(mfv.getMedida1());
                }
                if(mfv.getMedida2() != null){
                    fila[1] = String.valueOf(mfv.getMedida2());
                }
                if(mfv.getMedida3() != null){
                    fila[2] = String.valueOf(mfv.getMedida3());
                }
                if(mfv.getMedida4() != null){
                    fila[3] = String.valueOf(mfv.getMedida4());
                }
                if(mfv.getMedida5() != null){
                    fila[4] = String.valueOf(mfv.getMedida5());
                }
                modelo.addRow(fila);
            }
        }

        tMedidas.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_ALL_COLUMNS);
        tMedidas.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tMedidasMouseClicked(evt);
            }
        });
        tMedidas.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tMedidasKeyPressed(evt);
            }
        });
        jScrollPane1.setViewportView(tMedidas);

        bVisualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bVisualizarActionPerformed(evt);
            }
        });

        bBorrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bBorrarActionPerformed(evt);
            }
        });

        bCrear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bCrearActionPerformed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout pMedidasLayout = new org.jdesktop.layout.GroupLayout(pMedidas);
        pMedidas.setLayout(pMedidasLayout);
        pMedidasLayout.setHorizontalGroup(
            pMedidasLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, pMedidasLayout.createSequentialGroup()
                .add(jScrollPane1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 384, Short.MAX_VALUE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(pMedidasLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(bCrear, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 31, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(bVisualizar, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 31, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(bBorrar, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 31, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );
        pMedidasLayout.setVerticalGroup(
            pMedidasLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jScrollPane1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 375, Short.MAX_VALUE)
            .add(pMedidasLayout.createSequentialGroup()
                .addContainerGap()
                .add(bCrear, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 23, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                .add(bVisualizar, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 23, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                .add(bBorrar, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 23, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(273, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Medidas", pMedidas);

        modeloC.addColumn("Código");
        modeloC.addColumn("Color");
        modeloC.addColumn("Tipo");

        Colores c;
        Iterator<colorFamilia> itC;
        Object[] filaC;
        if(lColores != null){
            for (itC = lColores.iterator(); itC.hasNext();) {
                filaC = new Object[3];
                c = BaseDatos.obtenerColorPorIid(itC.next().getIidColor());
                if (c!=null){
                    filaC[0] = c.getCod_color();
                    filaC[1] = c.getDescripcion();
                    filaC[2] = c.getRal();
                }
                modeloC.addRow(filaC);
            }
        }

        tMedidas.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_ALL_COLUMNS);
        jScrollPane2.setViewportView(tMedidasC);

        bBorrarC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bBorrarCActionPerformed(evt);
            }
        });

        bCrearC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bCrearCActionPerformed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout pColoresLayout = new org.jdesktop.layout.GroupLayout(pColores);
        pColores.setLayout(pColoresLayout);
        pColoresLayout.setHorizontalGroup(
            pColoresLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, pColoresLayout.createSequentialGroup()
                .add(jScrollPane2, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 384, Short.MAX_VALUE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(pColoresLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(bCrearC, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 31, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(bBorrarC, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 31, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );
        pColoresLayout.setVerticalGroup(
            pColoresLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jScrollPane2, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 375, Short.MAX_VALUE)
            .add(pColoresLayout.createSequentialGroup()
                .addContainerGap()
                .add(bCrearC, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 23, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                .add(bBorrarC, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 23, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(307, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Colores", pColores);

        jLabel5.setText("ATENCIÓN: Estos precios aplicaran a todas los artículos pertenecientes a esta familia,");

        jLabel6.setText("aseguresé antes de realizar cambios.");

        bAplicar.setText("Aplicar");
        bAplicar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bAplicarActionPerformed(evt);
            }
        });

        jLabel13.setText("Los precios sea ctualizarán al pulsar el botón Aplicar.");

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder("Lacado Base"));

        tPVPb.setText("0");

        jLabel8.setText("PVP:");

        jLabel7.setText("PTC:");

        jLabel10.setText("€");

        tPTCb.setText("0");

        tUPCb.setText("0");

        jLabel9.setText("UPC:");

        jLabel14.setText("€");

        jLabel15.setText("€");

        anadirB.setText("Incluir");

        org.jdesktop.layout.GroupLayout jPanel2Layout = new org.jdesktop.layout.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING, false)
                    .add(org.jdesktop.layout.GroupLayout.LEADING, jLabel7, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .add(org.jdesktop.layout.GroupLayout.LEADING, jLabel8, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .add(jLabel9, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 35, Short.MAX_VALUE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                    .add(tUPCb)
                    .add(tPTCb)
                    .add(tPVPb, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 44, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jLabel10)
                    .add(jLabel14)
                    .add(jLabel15))
                .addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .add(org.jdesktop.layout.GroupLayout.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(52, Short.MAX_VALUE)
                .add(anadirB)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel2Layout.createSequentialGroup()
                .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(jLabel8)
                    .add(tPVPb, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(jLabel10))
                .add(18, 18, 18)
                .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(jLabel7)
                    .add(tPTCb, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(jLabel14))
                .add(18, 18, 18)
                .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(jLabel9)
                    .add(tUPCb, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(jLabel15))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED, 10, Short.MAX_VALUE)
                .add(anadirB))
        );

        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder("Lacado Ral"));

        tPVPr.setText("0");

        jLabel16.setText("PVP:");

        jLabel17.setText("PTC:");

        jLabel18.setText("€");

        tPTCr.setText("0");

        tUPCr.setText("0");

        jLabel19.setText("UPC:");

        jLabel20.setText("€");

        jLabel21.setText("€");

        anadirR.setText("Incluir");

        org.jdesktop.layout.GroupLayout jPanel3Layout = new org.jdesktop.layout.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                    .add(anadirR)
                    .add(jPanel3Layout.createSequentialGroup()
                        .add(jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING, false)
                            .add(org.jdesktop.layout.GroupLayout.LEADING, jLabel17, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .add(org.jdesktop.layout.GroupLayout.LEADING, jLabel16, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .add(jLabel19, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 35, Short.MAX_VALUE))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                            .add(tUPCr)
                            .add(tPTCr)
                            .add(tPVPr, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 44, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(jLabel18)
                            .add(jLabel20)
                            .add(jLabel21))))
                .addContainerGap(16, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel3Layout.createSequentialGroup()
                .add(jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(jLabel16)
                    .add(tPVPr, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(jLabel18))
                .add(18, 18, 18)
                .add(jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(jLabel17)
                    .add(tPTCr, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(jLabel20))
                .add(18, 18, 18)
                .add(jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(jLabel19)
                    .add(tUPCr, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(jLabel21))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED, 10, Short.MAX_VALUE)
                .add(anadirR))
        );

        jPanel4.setBorder(javax.swing.BorderFactory.createTitledBorder("Lacado Especial"));

        tPVPe.setText("0");

        jLabel22.setText("PVP:");

        jLabel23.setText("PTC:");

        jLabel24.setText("€");

        tPTCe.setText("0");

        tUPCe.setText("0");

        jLabel25.setText("UPC:");

        jLabel26.setText("€");

        jLabel27.setText("€");

        anadirE.setText("Incluir");

        org.jdesktop.layout.GroupLayout jPanel4Layout = new org.jdesktop.layout.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel4Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                    .add(anadirE)
                    .add(jPanel4Layout.createSequentialGroup()
                        .add(jPanel4Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING, false)
                            .add(org.jdesktop.layout.GroupLayout.LEADING, jLabel23, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .add(org.jdesktop.layout.GroupLayout.LEADING, jLabel22, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .add(jLabel25, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 35, Short.MAX_VALUE))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jPanel4Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                            .add(tUPCe)
                            .add(tPTCe)
                            .add(tPVPe, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 44, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel4Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jLabel24)
                    .add(jLabel26)
                    .add(jLabel27))
                .addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel4Layout.createSequentialGroup()
                .add(jPanel4Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(jLabel22)
                    .add(tPVPe, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(jLabel24))
                .add(18, 18, 18)
                .add(jPanel4Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(jLabel23)
                    .add(tPTCe, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(jLabel26))
                .add(18, 18, 18)
                .add(jPanel4Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(jLabel25)
                    .add(tUPCe, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(jLabel27))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED, 10, Short.MAX_VALUE)
                .add(anadirE))
        );

        jPanel5.setBorder(javax.swing.BorderFactory.createTitledBorder("Blanco / Sin Color"));

        anadirS.setText("Incluir");

        jLabel12.setText("€");

        tPVPs.setText("0");

        jLabel11.setText("PVP:");

        jLabel28.setText("€");

        tPTCs.setText("0");

        jLabel29.setText("PTC:");

        jLabel30.setText("€");

        tUPCs.setText("0");

        jLabel31.setText("UPC:");

        org.jdesktop.layout.GroupLayout jPanel5Layout = new org.jdesktop.layout.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .add(jLabel11, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 42, Short.MAX_VALUE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(tPVPs, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 38, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                .add(jLabel12)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                .add(jLabel29, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 43, Short.MAX_VALUE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(tPTCs, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 34, Short.MAX_VALUE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jLabel28)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                .add(jLabel31, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 41, Short.MAX_VALUE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(tUPCs, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 36, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jLabel30)
                .add(16, 16, 16)
                .add(anadirS)
                .addContainerGap())
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel5Layout.createSequentialGroup()
                .addContainerGap(15, Short.MAX_VALUE)
                .add(jPanel5Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jPanel5Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                        .add(jLabel31)
                        .add(tUPCs, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(jLabel30)
                        .add(anadirS))
                    .add(jPanel5Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                        .add(jLabel29)
                        .add(tPTCs, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(jLabel28))
                    .add(jPanel5Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                        .add(jLabel11)
                        .add(tPVPs, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(jLabel12)))
                .addContainerGap())
        );

        org.jdesktop.layout.GroupLayout pColores1Layout = new org.jdesktop.layout.GroupLayout(pColores1);
        pColores1.setLayout(pColores1Layout);
        pColores1Layout.setHorizontalGroup(
            pColores1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(pColores1Layout.createSequentialGroup()
                .addContainerGap()
                .add(pColores1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jLabel6)
                    .add(jLabel5)
                    .add(jLabel13)
                    .add(jPanel5, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(pColores1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                        .add(bAplicar, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 83, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(pColores1Layout.createSequentialGroup()
                            .add(jPanel2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(18, 18, 18)
                            .add(jPanel3, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                            .add(jPanel4, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        pColores1Layout.setVerticalGroup(
            pColores1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, pColores1Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel5, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .add(18, 18, 18)
                .add(pColores1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                    .add(org.jdesktop.layout.GroupLayout.TRAILING, jPanel3, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .add(org.jdesktop.layout.GroupLayout.TRAILING, jPanel2, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .add(jPanel4, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                .add(bAplicar)
                .add(8, 8, 8)
                .add(jLabel13)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jLabel5, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 17, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jLabel6)
                .addContainerGap(17, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Precios/Color", pColores1);

        org.jdesktop.layout.GroupLayout layout = new org.jdesktop.layout.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, layout.createSequentialGroup()
                .addContainerGap(165, Short.MAX_VALUE)
                .add(baceptar)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(bmodificar, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 103, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(bcancelar)
                .addContainerGap())
            .add(jTabbedPane1)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, layout.createSequentialGroup()
                .add(jTabbedPane1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 403, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .add(18, 18, Short.MAX_VALUE)
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(bcancelar)
                    .add(bmodificar)
                    .add(baceptar))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

private void baceptarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_baceptarActionPerformed
    String codigo = tCodigo.getText();
    String nombre = tNombre.getText();
    String tipoControl = (String) ctcontrol.getSelectedItem();
    List<precioFamilia> lp = new ArrayList();
    
    precioFamilia pS = new precioFamilia();
    precioFamilia pB = new precioFamilia();
    precioFamilia pR = new precioFamilia();
    precioFamilia pE = new precioFamilia();

    if (codigo != null && codigo.length() > 0 && nombre != null && nombre.length() > 0 && tipoControl != null && !tipoControl.equals(Constantes.VACIO)) {

        TipoControl tc = BaseDatos.obtenerTipoControlPorNombre(tipoControl);
        TipoProducto tp = null;

        String tipoProducto = (String) ctproducto.getSelectedItem();
        if (!tipoProducto.equals(Constantes.VACIO)) {
            tp = BaseDatos.obtenerTipoProductoDesc(tipoProducto);
        }

        //creamos la familia de venta
        fv.setCod_familia(codigo);
        fv.setNombre(nombre);
        fv.setIid_empresa(e);
        fv.setTipoMontaje((String) cTipoMontaje.getSelectedItem());
        fv.setIid_tipo_control(tc);
        fv.setIid_tipo_producto(tp);
        fv.setRecortable(cbRecortable.isSelected());
        fv.setConfeccionable(cbConfeccionado.isSelected());
        if (fv.getConfeccionable() && !tRestoMinimo.getText().equals("")) {
            fv.setRestoMinimo(Float.parseFloat(util.Util.convertirComaAPunto(tRestoMinimo.getText())));
        } else {
            fv.setRestoMinimo(null);
        }
        
         //Creamos lista de precios
        //Base  
        if (pFb != null) {
            pB.setIid(pFb.getIid());
        }
        
        pB.setIidEmpresa(e.getIid());
        pB.setIidFamilia(fv.getIid());
        pB.setTipoRal("1");
        pB.setPvp(Float.parseFloat(util.Util.convertirComaAPunto(tPVPb.getText())));
        pB.setPtc(Float.parseFloat(util.Util.convertirComaAPunto(tPTCb.getText())));
        pB.setUpc(Float.parseFloat(util.Util.convertirComaAPunto(tUPCb.getText())));
        lp.add(pB);

        //Ral        
        if (pFr != null) {
            pR.setIid(pFr.getIid());
        }
        pR.setIidEmpresa(e.getIid());
        pR.setIidFamilia(fv.getIid());
        pR.setTipoRal("2");
        pR.setPvp(Float.parseFloat(util.Util.convertirComaAPunto(tPVPr.getText())));
        pR.setPtc(Float.parseFloat(util.Util.convertirComaAPunto(tPTCr.getText())));
        pR.setUpc(Float.parseFloat(util.Util.convertirComaAPunto(tUPCr.getText())));
        lp.add(pR);

        //Especial
        if (pFe != null) {
            pE.setIid(pFe.getIid());
        }
        pE.setIidEmpresa(e.getIid());
        pE.setIidFamilia(fv.getIid());
        pE.setTipoRal("3");
        pE.setPvp(Float.parseFloat(util.Util.convertirComaAPunto(tPVPe.getText())));
        pE.setPtc(Float.parseFloat(util.Util.convertirComaAPunto(tPTCe.getText())));
        pE.setUpc(Float.parseFloat(util.Util.convertirComaAPunto(tUPCe.getText())));
        lp.add(pE);
        
        //Blanco - S/C
        if (pFs != null) {
            pS.setIid(pFs.getIid());
        }
        pS.setIidEmpresa(e.getIid());
        pS.setIidFamilia(fv.getIid());
        pS.setTipoRal("0");
        pS.setPvp(Float.parseFloat(util.Util.convertirComaAPunto(tPVPs.getText())));
        pS.setPtc(Float.parseFloat(util.Util.convertirComaAPunto(tPTCs.getText())));
        pS.setUpc(Float.parseFloat(util.Util.convertirComaAPunto(tUPCs.getText())));
        lp.add(pS);

        if (crear) {
            if (BaseDatos.obtenerFamiliaVenta(codigo, e.getIid()) == null) {
                if (BaseDatos.insertarFamiliaVenta(fv, lMedidas, lColores, lp)) {
                    cerrarVentana();
                } else {
                    JOptionPane.showMessageDialog(null, "No se puede insertar el elemento", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(null, "Ya hay una familia de ventas con el código " + codigo, "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            int hacerCambios = 1;

            if (hayCambios()) {
                hacerCambios = JOptionPane.showConfirmDialog(null, "Está seguro de que desea realizar los cambios?", "¿Realizar cambios?", JOptionPane.YES_NO_OPTION);
                //hacerCambios = -1 ==> se ha pulsado la "x" de cancelar;
                //hacerCambios =  0 ==> se ha pulsado el "sí"
                //hacerCambios =  1 ==> se ha pulsado el "no"
                if (hacerCambios == 0) {
                    FamiliaVenta temp = null;
                    if (!codigoAntiguo.equalsIgnoreCase(codigo)) {
                        temp = BaseDatos.obtenerFamiliaVenta(codigo, e.getIid());
                    }
                    if (temp == null) {
                        if (BaseDatos.modificarFamiliaVenta(fv, lMedidas, lColores, e.getIid(), lp)) {
                            cerrarVentana();
                        } else {
                            JOptionPane.showMessageDialog(null, "No se puede ha podido modificar el elemento", "Error", JOptionPane.ERROR_MESSAGE);
                        }
                    } else {
                        JOptionPane.showMessageDialog(null, "Ya hay una familia de ventas con el código " + codigo, "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
            } else if (!cambioMedidas) {
                JOptionPane.showMessageDialog(null, "No hay cambios que realizar", "Sin cambios", JOptionPane.ERROR_MESSAGE);
            } else {
                cerrarVentana();
            }
        }
    } else {
        //Error, hay que rellenar todos los campos
        JOptionPane.showMessageDialog(null, "Debe rellenar los campos \"Código\", \"Nombre\" y \"Tipo de Control\"", "Error", JOptionPane.ERROR_MESSAGE);
    }
}//GEN-LAST:event_baceptarActionPerformed

private void bcancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bcancelarActionPerformed
    cerrarVentana();
}//GEN-LAST:event_bcancelarActionPerformed

private void bmodificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bmodificarActionPerformed
    if (bmodificar.getText().equals("Modificar")) {
        //Si el botón tiene el texto Modificar
        tCodigo.setEnabled(true);
        tNombre.setEnabled(true);
        ctcontrol.setEnabled(true);
        ctproducto.setEnabled(true);
        bmodificar.setText("Visualizar");
        bmodificar.setToolTipText("Visualizar campos");
        bCrear.setEnabled(true);
        bVisualizar.setEnabled(true);
        bBorrar.setEnabled(true);
        tMedidas.setEnabled(true);
        cTipoMontaje.setEnabled(true);
        cbRecortable.setEnabled(true);
        cbConfeccionado.setEnabled(true);
        tRestoMinimo.setEnabled(true);
        URL urlModificar = getClass().getResource("/iconos/buscar.gif");
        ImageIcon iconoModificar = new ImageIcon(urlModificar);
        bmodificar.setIcon(iconoModificar);
        tMedidasC.setEnabled(true);
        bCrearC.setEnabled(true);
        bBorrarC.setEnabled(true);
    } else {
        //si el botón tiene el texto Visualizar
        tCodigo.setEnabled(false);
        tNombre.setEnabled(false);
        ctcontrol.setEnabled(false);
        ctproducto.setEnabled(false);
        bmodificar.setText("Modificar");
        bmodificar.setToolTipText("Modificar campos");
        bCrear.setEnabled(false);
        bVisualizar.setEnabled(false);
        bBorrar.setEnabled(false);
        tMedidas.setEnabled(false);
        cTipoMontaje.setEnabled(false);
        cbRecortable.setEnabled(false);
        cbConfeccionado.setEnabled(false);
        tRestoMinimo.setEnabled(false);
        URL urlModificar = getClass().getResource("/iconos/editar.png");
        ImageIcon iconoModificar = new ImageIcon(urlModificar);
        bmodificar.setIcon(iconoModificar);
        tMedidasC.setEnabled(false);
        bCrearC.setEnabled(false);
        bBorrarC.setEnabled(false);
    }
}//GEN-LAST:event_bmodificarActionPerformed

private void bVisualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bVisualizarActionPerformed
    visualizarMedida();
}//GEN-LAST:event_bVisualizarActionPerformed

    private void visualizarMedida() {
        int indice = tMedidas.getSelectedRow();
        if (indice >= 0) {

            //obtenemos código del elemento seleccionado
            String medida1 = (String) tMedidas.getModel().getValueAt(indice, 0);
            String medida2 = (String) tMedidas.getModel().getValueAt(indice, 1);
            String medida3 = (String) tMedidas.getModel().getValueAt(indice, 2);
            String medida4 = (String) tMedidas.getModel().getValueAt(indice, 3);
            String medida5 = (String) tMedidas.getModel().getValueAt(indice, 4);

            MedidasFamiliaVenta mfv = new MedidasFamiliaVenta();
            if (medida1 != null && !medida1.equals("") && !medida1.equals("null")) {
                mfv.setMedida1(new Integer(medida1));
            }
            if (medida2 != null && !medida2.equals("") && !medida2.equals("null")) {
                mfv.setMedida2(new Integer(medida2));
            }
            if (medida3 != null && !medida3.equals("") && !medida3.equals("null")) {
                mfv.setMedida3(new Integer(medida3));
            }
            if (medida4 != null && !medida4.equals("") && !medida4.equals("null")) {
                mfv.setMedida4(new Integer(medida4));
            }
            if (medida5 != null && !medida5.equals("") && !medida5.equals("null")) {
                mfv.setMedida5(new Integer(medida5));
            }

            NuevaMedidaFamiliaVenta nmfv = new NuevaMedidaFamiliaVenta(this, "Medida - Modificacion", mfv, fv);
            nmfv.setDefaultCloseOperation(NuevaMedidaFamiliaVenta.DISPOSE_ON_CLOSE);
            nmfv.setLocationRelativeTo(null);
            nmfv.setVisible(true);
        } else {
            JOptionPane.showMessageDialog(null, "No hay seleccionado ningún elemento", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
private void bBorrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bBorrarActionPerformed
    borrarMedida();
}//GEN-LAST:event_bBorrarActionPerformed

    private void borrarMedida() {
        int indice = tMedidas.getSelectedRow();
        if (indice >= 0) {
            int eliminar = 1;
            eliminar = JOptionPane.showConfirmDialog(null, "Está seguro de que desea eliminar el elemento seleccionado?", "¿Eliminar?", JOptionPane.YES_NO_OPTION);
            //hacerCambios = -1 ==> se ha pulsado la "x" de cancelar;
            //hacerCambios =  0 ==> se ha pulsado el "sí"
            //hacerCambios =  1 ==> se ha pulsado el "no"

            if (eliminar == 0) {
                //obtenemos código del elemento seleccionado
                String medida1 = (String) tMedidas.getModel().getValueAt(indice, 0);
                String medida2 = (String) tMedidas.getModel().getValueAt(indice, 1);
                String medida3 = (String) tMedidas.getModel().getValueAt(indice, 2);
                String medida4 = (String) tMedidas.getModel().getValueAt(indice, 3);
                String medida5 = (String) tMedidas.getModel().getValueAt(indice, 4);

                MedidasFamiliaVenta mfv = new MedidasFamiliaVenta();
                if (medida1 != null && !medida1.equals("") && !medida1.equals("null")) {
                    mfv.setMedida1(new Integer(medida1));
                }
                if (medida2 != null && !medida2.equals("") && !medida2.equals("null")) {
                    mfv.setMedida2(new Integer(medida2));
                }
                if (medida3 != null && !medida3.equals("") && !medida3.equals("null")) {
                    mfv.setMedida3(new Integer(medida3));
                }
                if (medida4 != null && !medida4.equals("") && !medida4.equals("null")) {
                    mfv.setMedida4(new Integer(medida4));
                }
                if (medida5 != null && !medida5.equals("") && !medida5.equals("null")) {
                    mfv.setMedida5(new Integer(medida5));
                }

                Iterator<MedidasFamiliaVenta> iter = lMedidas.iterator();
                boolean encontrado = false;
                int contadorElemento = 0;

                while (iter.hasNext() && !encontrado) {
                      encontrado = iguales(iter.next(), mfv);
                    if (!encontrado) {
                        contadorElemento++;
                    }
                }

                if (encontrado) {
                    lMedidas.remove(contadorElemento);
                    actualizarMedidas();
                    cambioMedidas = true;
                }
            }
        } else {
            JOptionPane.showMessageDialog(null, "No hay seleccionado ningún elemento", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void borrarColor() {
        int indice = tMedidasC.getSelectedRow();
        if (indice >= 0) {

            int eliminar = 1;
            eliminar = JOptionPane.showConfirmDialog(null, "Está seguro de que desea eliminar el elemento seleccionado?", "¿Eliminar?", JOptionPane.YES_NO_OPTION);

            if (eliminar == 0) {
                //obtenemos código del elemento seleccionado
                String codColor = (String) tMedidasC.getModel().getValueAt(indice, 0);
                Colores c = BaseDatos.obtenerColor(codColor);

                colorFamilia cf = new colorFamilia();
                cf.setIidColor(c.getIid());
                cf.setIidFamilia(fv.getIid());
                cf.setIidEmpresa(e.getIid());

                Iterator<colorFamilia> iter = lColores.iterator();
                boolean encontrado = false;
                int contadorElemento = 0;

                while (iter.hasNext() && !encontrado) {
                    encontrado = igualesC(iter.next(), cf);
                    if (!encontrado) {
                        contadorElemento++;
                    }
                }

                if (encontrado) {
                    lColores.remove(contadorElemento);
                    actualizarColores();
                    cambioColores = true;
                }
            }
        } else {
            JOptionPane.showMessageDialog(null, "No hay seleccionado ningún elemento", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

private void bCrearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bCrearActionPerformed
    if (fv.getIid_tipo_control() != null) {
        NuevaMedidaFamiliaVenta nmfv = new NuevaMedidaFamiliaVenta(this, "Medida - Creación", fv);
        nmfv.setDefaultCloseOperation(NuevaMedidaFamiliaVenta.DISPOSE_ON_CLOSE);
        nmfv.setLocationRelativeTo(null);
        nmfv.setVisible(true);
    } else {
        JOptionPane.showMessageDialog(null, "No hay seleccionado ningún tipo de control", "Error", JOptionPane.ERROR_MESSAGE);
    }
}//GEN-LAST:event_bCrearActionPerformed

private void tCodigoKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tCodigoKeyReleased
    String codigo = tCodigo.getText();
    if (codigo.length() > Constantes.TAM_CODIGO_FAM_VENTA) {
        JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_CODIGO_FAM_VENTA, "Error", JOptionPane.ERROR_MESSAGE);
        tCodigo.setText(codigo.substring(0, Constantes.TAM_CODIGO_FAM_VENTA));
    }
}//GEN-LAST:event_tCodigoKeyReleased

private void tNombreKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tNombreKeyReleased
    String nombre = tCodigo.getText();
    if (nombre.length() > Constantes.TAM_NOMBRE_FAM_VENTA) {
        JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_NOMBRE_FAM_VENTA, "Error", JOptionPane.ERROR_MESSAGE);
        tCodigo.setText(nombre.substring(0, Constantes.TAM_NOMBRE_FAM_VENTA));
    }
}//GEN-LAST:event_tNombreKeyReleased

private void ctcontrolActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ctcontrolActionPerformed
    if (mostrarMensaje) {
        int hacerCambios = JOptionPane.showConfirmDialog(null, "Al cambiar el tipo de control se eliminarán todas las medidas.\n¿Está seguro de que desea realizar los cambios?", "¿Realizar cambios?", JOptionPane.YES_NO_OPTION);
        //hacerCambios = -1 ==> se ha pulsado la "x" de cancelar;
        //hacerCambios =  0 ==> se ha pulsado el "sí"
        //hacerCambios =  1 ==> se ha pulsado el "no"
        if (hacerCambios == 0) {
            String tipoControlStr = (String) this.ctcontrol.getSelectedItem();
            if (tipoControlStr.equals(Constantes.VACIO)) {
                tipoControlStrAnterior = "";
            } else {
                tipoControlStrAnterior = tipoControlStr;
            }
            fv.setIid_tipo_control(BaseDatos.obtenerTipoControlPorNombre(tipoControlStrAnterior));
            lMedidas = new ArrayList();
            actualizarMedidas();
        }
    }
}//GEN-LAST:event_ctcontrolActionPerformed

private void tMedidasKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tMedidasKeyPressed
    if (evt.getKeyChar() == KeyEvent.VK_ENTER) {
        visualizarMedida();
    } else if (evt.getKeyChar() == KeyEvent.VK_DELETE) {
        borrarMedida();
    }
}//GEN-LAST:event_tMedidasKeyPressed

private void tMedidasMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tMedidasMouseClicked
    if (evt.getClickCount() == 2) {
        visualizarMedida();
    }
}//GEN-LAST:event_tMedidasMouseClicked

private void cbConfeccionadoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbConfeccionadoActionPerformed
    lRestoMinimo.setVisible(cbConfeccionado.isSelected());
    tRestoMinimo.setVisible(cbConfeccionado.isSelected());
    cbRecortable.setSelected(!cbConfeccionado.isSelected());
}//GEN-LAST:event_cbConfeccionadoActionPerformed

private void tRestoMinimoKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tRestoMinimoKeyReleased
    int tamaño = tRestoMinimo.getText().length();
    if (tamaño > 0) {
        char c = tRestoMinimo.getText().charAt(tamaño - 1);

        if (c == '.') {
            String contenidoAntiguo = tRestoMinimo.getText().replace(".", ",");
            tRestoMinimo.setText(contenidoAntiguo);
            c = ',';
        }

        if (!((c >= '0' && c <= '9') || c == ',')) {
            String str = tRestoMinimo.getText().substring(0, tamaño - 1);
            tRestoMinimo.setText(str);
        } else if (c == ',') {
            int indicePunto = tRestoMinimo.getText().indexOf(',');
            if (indicePunto != (tamaño - 1)) {
                String str = tRestoMinimo.getText().substring(0, tamaño - 1);
                tRestoMinimo.setText(str);
            }
        }
    }
}//GEN-LAST:event_tRestoMinimoKeyReleased

private void cbRecortableActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbRecortableActionPerformed
    lRestoMinimo.setVisible(!cbRecortable.isSelected());
    tRestoMinimo.setVisible(!cbRecortable.isSelected());
    cbConfeccionado.setSelected(!cbRecortable.isSelected());
}//GEN-LAST:event_cbRecortableActionPerformed

    private void bBorrarCActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bBorrarCActionPerformed
        borrarColor();
    }//GEN-LAST:event_bBorrarCActionPerformed

    private void bCrearCActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bCrearCActionPerformed
        NuevoColorFamilia ncf = new NuevoColorFamilia(e, fv, this);
        ncf.setDefaultCloseOperation(NuevaMedidaFamiliaVenta.DISPOSE_ON_CLOSE);
        ncf.setLocationRelativeTo(null);
        ncf.setVisible(true);
    }//GEN-LAST:event_bCrearCActionPerformed

    private void bAplicarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bAplicarActionPerformed
        LogMasivoProgreso lmp = new LogMasivoProgreso();
        lmp.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        lmp.setLocationRelativeTo(null);
        lmp.setVisible(true);

        HebraFamiliaVentas hfv = new HebraFamiliaVentas(lmp, this);
        new Thread(hfv).start();
    }//GEN-LAST:event_bAplicarActionPerformed

    public boolean modificarMedidaFamiliaVenta(MedidasFamiliaVenta mfv) {
        boolean res = true;
        if (BaseDatos.modificarElemento(mfv)) {
            actualizarMedidas();
        } else {
            res = false;
            JOptionPane.showMessageDialog(null, "No se puede ha podido modificar el elemento", "Error", JOptionPane.ERROR_MESSAGE);
        }
        return res;
    }

    public boolean insertarMedidaFamiliaVenta(MedidasFamiliaVenta mfv) {
        boolean res = true;
        if (BaseDatos.insertarElemento(mfv)) {
            actualizarMedidas();
        } else {
            res = false;
            //Si no se ha insertado mostramos un mensaje de error
            JOptionPane.showMessageDialog(null, "No se puede ha podido insertar el elemento", "Error", JOptionPane.ERROR_MESSAGE);
        }
        return res;
    }

    private boolean hayCambios() {
        return !tCodigo.getText().equals(codigoAntiguo)
                || !tNombre.getText().equals(nombreAntiguo)
                || !((String) cTipoMontaje.getSelectedItem()).equals(tipoMontajeAntiguo)
                || !((String) ctcontrol.getSelectedItem()).equals(tipocontrolAntiguo)
                || !((String) ctproducto.getSelectedItem()).equals(tipoproductoAntiguo)
                || !cbConfeccionado.isSelected() == confeccionadoAntiguo
                || !cbRecortable.isSelected() == recortableAntiguo
                || !((String) tRestoMinimo.getText()).equals(restoMinimoAntiguo)
                || !tPVPb.getText().equals(pvpB)
                || !tPTCb.getText().equals(ptcB)
                || !tUPCb.getText().equals(upcB)
                || !tPVPr.getText().equals(pvpR)
                || !tPTCr.getText().equals(ptcR)
                || !tUPCr.getText().equals(upcR)
                || !tPVPe.getText().equals(pvpE)
                || !tPTCe.getText().equals(ptcE)
                || !tUPCe.getText().equals(upcE)
                || cambioMedidas
                || cambioColores;
    }
    
    public Empresa getEmpresa(){
        return this.e;
    }
    
    public FamiliaVenta getFamiliaVenta(){
        return this.fv;
    }
    
    public Usuario getUsuario(){
        return this.u;
    }
    
    public boolean getAnadirB(){
        return anadirB.isSelected();
    }
    
    public boolean getAnadirR(){
        return anadirR.isSelected();
    }
    
    public boolean getAnadirE(){
        return anadirE.isSelected();
    }
    
    public boolean getAnadirS(){
        return anadirS.isSelected();
    }
    
    public String getTPVPbTexto(){
        return this.tPVPb.getText();
    }
    public String getTPTCbTexto(){
        return this.tPTCb.getText();
    }
    public String getTUPCbTexto(){
        return this.tUPCb.getText();
    }
    
    public String getTPVPrTexto(){
        return this.tPVPr.getText();
    }
    public String getTPTCrTexto(){
        return this.tPTCr.getText();
    }
    public String getTUPCrTexto(){
        return this.tUPCr.getText();
    }
    
    public String getTPVPeTexto(){
        return this.tPVPe.getText();
    }
    public String getTPTCeTexto(){
        return this.tPTCe.getText();
    }
    public String getTUPCeTexto(){
        return this.tUPCe.getText();
    }
    
    public String getTPVPsTexto(){
        return tPVPs.getText();
    }
    public String getTPTCsTexto(){
        return tPTCs.getText();
    }
    public String getTUPCsTexto(){
        return tUPCs.getText();
    }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JCheckBox anadirB;
    private javax.swing.JCheckBox anadirE;
    private javax.swing.JCheckBox anadirR;
    private javax.swing.JCheckBox anadirS;
    private javax.swing.JButton bAplicar;
    private javax.swing.JButton bBorrar;
    private javax.swing.JButton bBorrarC;
    private javax.swing.JButton bCrear;
    private javax.swing.JButton bCrearC;
    private javax.swing.JButton bVisualizar;
    private javax.swing.JButton baceptar;
    private javax.swing.JButton bcancelar;
    private javax.swing.JButton bmodificar;
    private javax.swing.JComboBox cTipoMontaje;
    private javax.swing.JCheckBox cbConfeccionado;
    private javax.swing.JCheckBox cbRecortable;
    private javax.swing.JComboBox ctcontrol;
    private javax.swing.JComboBox ctproducto;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JLabel lRestoMinimo;
    private javax.swing.JLabel lcodigo;
    private javax.swing.JLabel lnombre;
    private javax.swing.JLabel ltcontrol;
    private javax.swing.JLabel ltproducto;
    private javax.swing.JPanel pColores;
    private javax.swing.JPanel pColores1;
    private javax.swing.JPanel pGeneral;
    private javax.swing.JPanel pMedidas;
    private javax.swing.JTextField tCodigo;
    private javax.swing.JTable tMedidas;
    private javax.swing.JTable tMedidasC;
    private javax.swing.JTextField tNombre;
    private javax.swing.JTextField tPTCb;
    private javax.swing.JTextField tPTCe;
    private javax.swing.JTextField tPTCr;
    private javax.swing.JTextField tPTCs;
    private javax.swing.JTextField tPVPb;
    private javax.swing.JTextField tPVPe;
    private javax.swing.JTextField tPVPr;
    private javax.swing.JTextField tPVPs;
    private javax.swing.JTextField tRestoMinimo;
    private javax.swing.JTextField tUPCb;
    private javax.swing.JTextField tUPCe;
    private javax.swing.JTextField tUPCr;
    private javax.swing.JTextField tUPCs;
    // End of variables declaration//GEN-END:variables
}
