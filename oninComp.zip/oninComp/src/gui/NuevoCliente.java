package gui;

import gui.*;
import bean.Agentes;
import acceso.*;
import bean.Articulo;
import bean.FormaPago;
import bean.Iva;
import bean.Presupuesto;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import javax.swing.JOptionPane;
import modelo.Modelo;
import util.Constantes;
import util.Util;
import bean.Contactos;
import bean.DescuentoClienteArticulo;
import bean.DescuentoClienteFamiliaVenta;
import bean.FormulaFamiliaProv;
import bean.FormulaArticuloProv;
import bean.DescuentoClienteFamiliaVenta;
import bean.Empresa;
import bean.FamiliaVenta;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.net.URL;
import java.text.SimpleDateFormat;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.KeyStroke;

public class NuevoCliente extends javax.swing.JFrame {

    private Agentes a;
    private boolean crear;
    private String codigoAntiguo;
    private String nombreComercialAntiguo;
    private String nombreFiscalAntiguo;
    private String cifAntiguo;
    private String paisAntiguo;
    private String provinciaAntigua;
    private String poblacionAntigua;
    private String direccionAntigua;
    private String cpAntiguo;
    private String provinciaFiscalAntigua;
    private String poblacionFiscalAntigua;
    private String direccionFiscalAntigua;
    private String cpFiscalAntiguo;
    private String tlfAntiguo;
    private String tlf2Antiguo;
    private String tlf3Antiguo;
    private String faxAntiguo;
    private String mailAntiguo;
    private String ivaAntiguo;
    private String contactoAntiguo;
    private boolean exentoIvaAntiguo;
    private boolean terceroAntiguo;
    private String formaPagoAntigua;
    private String nombreEntAntigua;
    private String direccionEntAntigua;
    private String poblacionEntAntigua;
    private String provinciaEntAntigua;
    private String cpEntAntigua;
    private String cuentaEntAntigua;
    private String observacionesAntigua;
    private String swiftAntiguo;
    private String diaCobro1Antiguo;
    private String diaCobro2Antiguo;
    private String diaCobro3Antiguo;
    private List<Contactos> listacontactos;
    private List<DescuentoClienteArticulo> listaDescuentoClienteArticulos;
    private List<DescuentoClienteFamiliaVenta> listaDescuentoClienteFamiliaVentas;
    private List<FormulaArticuloProv> listaFormulaArticulo;
    private List<FormulaFamiliaProv> listaFormulaFamilia;
    private int indiceFila;
    boolean cambios;
    private String tipo;
    private Empresa e;

    public NuevoCliente(String titulo, String tipo, Empresa e) {
        super(titulo);

        this.tipo = tipo;
        this.e = e;

        crear = true;
        a = new Agentes();
        if (tipo.equals("cli")) {
            a.setTipo_agente(BaseDatos.obtenerTipoAgente("Cliente"));
        } else if (tipo.equals("prov")) {
            a.setTipo_agente(BaseDatos.obtenerTipoAgente("Proveedor"));
        }

        initComponents();

        if (tipo.equals("prov")) {
            tcodigo.setText("400");

        } else if (tipo.equals("cli")) {
            //Si es un cliente se elimina la pestaña de fórmulas
            jTabbedPane1.remove(3);
        }

        iniciarDiasCobro();
        bcancelar.setToolTipText("Cancelar la creación");
        baceptar.setToolTipText("Realizar la modificación");
        bmodificar.setVisible(false);
        bAnadirNotaDocumento.setVisible(false);

        listacontactos = new ArrayList<Contactos>();
        listaDescuentoClienteArticulos = new ArrayList<DescuentoClienteArticulo>();
        listaDescuentoClienteFamiliaVentas = new ArrayList<DescuentoClienteFamiliaVenta>();

        listaFormulaArticulo = new ArrayList<FormulaArticuloProv>();
        listaFormulaFamilia = new ArrayList<FormulaFamiliaProv>();


        crearIconosBotones();
        crearAcciones();
        remove(pLista);
        repaint();
        pack();

    }

    public NuevoCliente(String titulo, Agentes a, String tipo, Empresa e) {
        super(titulo);

        this.e = e;
        this.a = a;
        this.tipo = tipo;

        crear = false;

        listaDescuentoClienteArticulos = BaseDatos.obtenerDescuentosClienteArticulos(a.getIid());
        listaDescuentoClienteFamiliaVentas = BaseDatos.obtenerDescuentosClienteFamiliaVenta(a.getIid());

        listaFormulaArticulo = BaseDatos.obtenerFormulaProvArticulo(a.getIid());
        listaFormulaFamilia = BaseDatos.obtenerFormulaProvFamilia(a.getIid());


        initComponents();
        iniciarDiasCobro();

        bcancelar.setToolTipText("Cancelar la creación");
        baceptar.setToolTipText("Realizar la modificación");
        bmodificar.setToolTipText("Modificar campos");
        bAnadirNotaDocumento.setEnabled(false);
        bAnadirPersona.setEnabled(false);
        cTerceros.setEnabled(false);
        bEliminarPersona.setEnabled(false);
        tSwift.setEnabled(false);
        bModificarPersona.setEnabled(false);
        tcodigo.setText(a.getCod_agente());
        tnombreFiscal.setText(a.getNombre_fiscal());
        tnombrecomercial.setText(a.getNombre_comercial());
        tCif.setText(a.getCif_nif());
        tpais.setText(a.getPais());
        tprovincia.setText(a.getProvincia());
        tpoblacion.setText(a.getPoblacion());
        tdireccion.setText(a.getDireccion());
        tcp.setText(String.valueOf(a.getCodigo_postal()));
        tprovinciaFiscal.setText(a.getProvincia_fiscal());
        tpoblacionFiscal.setText(a.getPoblacion_fiscal());
        tdireccionFiscal.setText(a.getDireccion_fiscal());
        tcpFiscal.setText(String.valueOf(a.getCodigo_postal_fiscal()));
        ttlf.setText(a.getTelefono());
        ttlf2.setText(a.getTelefono2());
        ttlf3.setText(a.getTelefono3());
        tmail.setText(a.getEmail());
        tfax.setText(a.getFax());
        tSwift.setText(a.getSwift());
        tEntidad.setText(a.getEntidad());
        tdirecent.setText(a.getDirec_ent());
        tcpent.setText(a.getCp_ent());
        tprovinciaent.setText(a.getProv_ent());
        tpoblacionent.setText(a.getPob_ent());
        tcuenta.setText(a.getCuenta());
        listacontactos = BaseDatos.getContactoAgente(a);
        if (a.getTerceros() != null) {
            cTerceros.setSelected(a.getTerceros());
        } else {
            cTerceros.setSelected(false);
        }

        if (a.getExento_iva() != null && a.getExento_iva() == true) {
            cbExentoIva.setSelected(true);
            cIva.setVisible(false);
            lIva.setVisible(false);
            ivaAntiguo = Constantes.VACIO;
        } else if (a.getIva() != null) {
            String sPorcentaje = a.getIva().getPorcentaje() + "%";
            cIva.setSelectedItem(sPorcentaje);
            ivaAntiguo = sPorcentaje;
        } else {
            ivaAntiguo = Constantes.VACIO;
        }

        if (a.getContactar() != null) {
            cContacto.setSelectedItem(a.getContactar());
            contactoAntiguo = a.getContactar();
        } else {
            contactoAntiguo = Constantes.OTROS;
        }

        if (a.getFormaPago() != null) {
            FormaPago fp = BaseDatos.obtenerFormaPagoPorIid(a.getFormaPago().getIid());
            formaPagoAntigua = fp.getCodigo();
            cFormaPago.setSelectedItem(formaPagoAntigua);
        } else {
            formaPagoAntigua = Constantes.VACIO;
        }


        if (a.getDiaCobro1() != null) {
            cDiaCobro1.setSelectedItem((String) a.getDiaCobro1().toString());
            diaCobro1Antiguo = (String) a.getDiaCobro1().toString();
        } else {
            diaCobro1Antiguo = "--";
        }

        if (a.getDiaCobro2() != null) {
            cDiaCobro2.setSelectedItem((String) a.getDiaCobro2().toString());
            diaCobro2Antiguo = (String) a.getDiaCobro2().toString();
        } else {
            diaCobro2Antiguo = "--";
        }

        if (a.getDiaCobro3() != null) {
            cDiaCobro3.setSelectedItem((String) a.getDiaCobro3().toString());
            diaCobro3Antiguo = (String) a.getDiaCobro3().toString();
        } else {
            diaCobro3Antiguo = "--";
        }

        cDiaCobro1.setEnabled(false);
        cDiaCobro2.setEnabled(false);
        cDiaCobro3.setEnabled(false);

        cContacto.setEnabled(false);
        cbExentoIva.setEnabled(false);
        tcodigo.setEnabled(false);
        tnombreFiscal.setEnabled(false);
        tnombrecomercial.setEnabled(false);
        tCif.setEnabled(false);
        tpais.setEnabled(false);
        tprovincia.setEnabled(false);
        tpoblacion.setEnabled(false);
        tdireccion.setEnabled(false);
        tprovinciaFiscal.setEnabled(false);
        tpoblacionFiscal.setEnabled(false);
        tdireccionFiscal.setEnabled(false);
        tcp.setEnabled(false);
        tcpFiscal.setEnabled(false);
        ttlf.setEnabled(false);
        ttlf2.setEnabled(false);
        ttlf3.setEnabled(false);
        tmail.setEnabled(false);
        tfax.setEnabled(false);
        cIva.setEnabled(false);
        cFormaPago.setEnabled(false);
        tEntidad.setEnabled(false);
        tdirecent.setEnabled(false);
        tcpent.setEnabled(false);
        tprovinciaent.setEnabled(false);
        tpoblacionent.setEnabled(false);
        tcuenta.setEnabled(false);
        bAnadirPersona.setEnabled(false);
        bEliminarPersona.setEnabled(false);
        bModificarPersona.setEnabled(false);
        tObservaciones.setEnabled(false);
        cFiscal.setEnabled(false);

        codigoAntiguo = a.getCod_agente();
        nombreComercialAntiguo = a.getNombre_comercial();
        nombreFiscalAntiguo = a.getNombre_fiscal();
        cifAntiguo = a.getCif_nif();
        paisAntiguo = a.getPais();
        provinciaAntigua = a.getProvincia();
        poblacionAntigua = a.getPoblacion();
        direccionAntigua = a.getDireccion();
        cpAntiguo = String.valueOf(a.getCodigo_postal());
        provinciaFiscalAntigua = a.getProvincia_fiscal();
        poblacionFiscalAntigua = a.getPoblacion_fiscal();
        swiftAntiguo = a.getSwift();
        direccionFiscalAntigua = a.getDireccion_fiscal();
        cpFiscalAntiguo = String.valueOf(a.getCodigo_postal_fiscal());
        tlfAntiguo = a.getTelefono();
        tlf2Antiguo = a.getTelefono2();
        tlf3Antiguo = a.getTelefono3();
        faxAntiguo = a.getFax();
        mailAntiguo = a.getEmail();

        if (a.getObservaciones() == null) {
            tObservaciones.setText("");
            observacionesAntigua = "";
        } else {
            tObservaciones.setText(a.getObservaciones());
            observacionesAntigua = a.getObservaciones();
        }

        if (a.getExento_iva() != null && a.getExento_iva()) {
            exentoIvaAntiguo = true;
        } else {
            exentoIvaAntiguo = false;
        }

        if (a.getTerceros() != null && a.getTerceros()) {
            terceroAntiguo = true;
        } else {
            terceroAntiguo = false;
        }


        nombreEntAntigua = a.getEntidad();
        direccionEntAntigua = a.getDirec_ent();
        poblacionEntAntigua = a.getPob_ent();
        provinciaEntAntigua = a.getProv_ent();
        cpEntAntigua = a.getCp_ent();
        cuentaEntAntigua = a.getCuenta();

        //Rellenamos las listas de descuentos
        Modelo modelo;

        modelo = (Modelo) tDtoArticulos.getModel();
        DescuentoClienteArticulo dca;
        Articulo artTemp;
        for (Iterator it = listaDescuentoClienteArticulos.iterator(); it.hasNext();) {
            Object[] filac = new Object[2];
            dca = (DescuentoClienteArticulo) it.next();
            artTemp = BaseDatos.obtenerArticuloPorIid(dca.getArticulo().getIid());
            filac[0] = artTemp.getCod_articulo();
            filac[1] = Util.convertirPuntoAComa(dca.getDescuento().toString());
            modelo.addRow(filac);
        }

        modelo = (Modelo) tDtoFamiliaVenta.getModel();
        DescuentoClienteFamiliaVenta dcfv;
        FamiliaVenta fvTemp;
        for (Iterator it = listaDescuentoClienteFamiliaVentas.iterator(); it.hasNext();) {
            Object[] filac = new Object[2];
            dcfv = (DescuentoClienteFamiliaVenta) it.next();
            fvTemp = BaseDatos.obtenerFamiliaVentaPorIid(dcfv.getFamiliaVenta().getIid());
            filac[0] = fvTemp.getCod_familia();
            filac[1] = Util.convertirPuntoAComa(dcfv.getDescuento().toString());
            modelo.addRow(filac);
        }


        //Rellenamos las listas de fomulas
        Modelo modelof;

        modelof = (Modelo) tForArticulos.getModel();
        FormulaArticuloProv fap;

        if (listaFormulaArticulo != null) {

            for (Iterator it = listaFormulaArticulo.iterator(); it.hasNext();) {
                Object[] filac = new Object[2];
                fap = (FormulaArticuloProv) it.next();
                artTemp = BaseDatos.obtenerArticuloPorIid(fap.getIidArticulo());
                filac[0] = artTemp.getCod_articulo();
                filac[1] = Util.convertirPuntoAComa(fap.getFormula());
                modelof.addRow(filac);
            }

        }

        modelof = (Modelo) tForFamiliaVenta.getModel();
        FormulaFamiliaProv ffp;

        if (listaFormulaFamilia != null) {

            for (Iterator it = listaFormulaFamilia.iterator(); it.hasNext();) {
                Object[] filac = new Object[2];
                ffp = (FormulaFamiliaProv) it.next();
                fvTemp = BaseDatos.obtenerFamiliaVentaPorIid(ffp.getIidFamilia());
                filac[0] = fvTemp.getCod_familia();
                filac[1] = Util.convertirPuntoAComa(ffp.getFormula());
                modelof.addRow(filac);
            }
        }

        this.bAnadirDtoArticulo.setEnabled(false);
        this.bAnadirDtoFamiliaVenta.setEnabled(false);
        this.bEliminarDtoArticulo.setEnabled(false);
        this.bEliminarDtoFamiliaVenta.setEnabled(false);
        this.bModificarDtoArticulo.setEnabled(false);
        this.bModificarDtoFamiliaVenta.setEnabled(false);
        this.bAnadirForArticulo.setEnabled(false);
        this.bAnadirForFamiliaVenta.setEnabled(false);
        this.bEliminarForArticulo.setEnabled(false);
        this.BorrarForFamiliaVenta.setEnabled(false);
        this.bModificarForArticulo.setEnabled(false);
        this.bModificarForFamiliaVenta.setEnabled(false);
        this.bModificarPersona.setEnabled(false);
        this.bAnadirPersona.setEnabled(false);
        this.bEliminarPersona.setEnabled(false);
        this.tcontactos.setEnabled(false);
        this.tPresupuestos.setEnabled(false);
        this.tDtoArticulos.setEnabled(false);
        this.tDtoFamiliaVenta.setEnabled(false);

        crearIconosBotones();
        crearAcciones();
    }

    private void crearIconosBotones() {

        URL urlCancelar = getClass().getResource("/iconos/cancelar.gif");
        ImageIcon iconoCancelar = new ImageIcon(urlCancelar);
        bcancelar.setIcon(iconoCancelar);

        URL urlAceptar = getClass().getResource("/iconos/guardarYvolver.png");
        ImageIcon iconoAceptar = new ImageIcon(urlAceptar);
        baceptar.setIcon(iconoAceptar);

        URL urlModificar = getClass().getResource("/iconos/editar.png");
        ImageIcon iconoModificar = new ImageIcon(urlModificar);
        bmodificar.setIcon(iconoModificar);
        bModificarPersona.setIcon(iconoModificar);
        bModificarForFamiliaVenta.setIcon(iconoModificar);
        bModificarDtoFamiliaVenta.setIcon(iconoModificar);
        bModificarDtoArticulo.setIcon(iconoModificar);
        bModificarForArticulo.setIcon(iconoModificar);

        URL urlAnadir = getClass().getResource("/iconos/anadir.png");
        ImageIcon iconoAnadir = new ImageIcon(urlAnadir);
        bAnadirDtoArticulo.setIcon(iconoAnadir);
        bAnadirForArticulo.setIcon(iconoAnadir);
        bAnadirDtoFamiliaVenta.setIcon(iconoAnadir);
        bAnadirForFamiliaVenta.setIcon(iconoAnadir);
        bAnadirPersona.setIcon(iconoAnadir);

        URL urlEliminar = getClass().getResource("/iconos/eliminar.png");
        ImageIcon iconoEliminar = new ImageIcon(urlEliminar);
        bEliminarDtoArticulo.setIcon(iconoEliminar);
        bEliminarForArticulo.setIcon(iconoEliminar);
        bEliminarDtoFamiliaVenta.setIcon(iconoEliminar);
        BorrarForFamiliaVenta.setIcon(iconoEliminar);
        bEliminarPersona.setIcon(iconoEliminar);





    }

    private void crearAcciones() {
        KeyStroke escapeKeyStroke = KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false);
        Action escapeAction = new AbstractAction() {
            public void actionPerformed(ActionEvent e) {
                cerrarCliente();
            }
        };
        getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(escapeKeyStroke, "ESCAPE");
        getRootPane().getActionMap().put("ESCAPE", escapeAction);


        Dimension dim = Util.getDimensiones(this.getSize());
        if (dim != null) {
            setResizable(true);
            setPreferredSize(dim);
            setSize(dim);
            setResizable(false);
        }
    }

    private void iniciarDiasCobro() {
        cDiaCobro1.addItem("--");
        cDiaCobro2.addItem("--");
        cDiaCobro3.addItem("--");
        for (Integer i = 1; i < 32; i++) {
            cDiaCobro1.addItem(i.toString());
            cDiaCobro2.addItem(i.toString());
            cDiaCobro3.addItem(i.toString());
        }
    }

    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        bcancelar = new javax.swing.JButton();
        baceptar = new javax.swing.JButton();
        bmodificar = new javax.swing.JButton();
        jScrollPane6 = new javax.swing.JScrollPane();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel3 = new javax.swing.JPanel();
        tpoblacion = new javax.swing.JTextField();
        lmail = new javax.swing.JLabel();
        tnombreFiscal = new javax.swing.JTextField();
        lnombrefiscal = new javax.swing.JLabel();
        lfax = new javax.swing.JLabel();
        ttlf2 = new javax.swing.JTextField();
        lcodigo = new javax.swing.JLabel();
        ttlf3 = new javax.swing.JTextField();
        lcp = new javax.swing.JLabel();
        lprovincia = new javax.swing.JLabel();
        lpais = new javax.swing.JLabel();
        tprovincia = new javax.swing.JTextField();
        lcif = new javax.swing.JLabel();
        tpais = new javax.swing.JTextField();
        tfax = new javax.swing.JTextField();
        tcp = new javax.swing.JTextField();
        jSeparator1 = new javax.swing.JSeparator();
        tdireccion = new javax.swing.JTextField();
        lnombrecomercial = new javax.swing.JLabel();
        tnombrecomercial = new javax.swing.JTextField();
        ttlf = new javax.swing.JTextField();
        ldireccion = new javax.swing.JLabel();
        cIva = new javax.swing.JComboBox();
        lIva = new javax.swing.JLabel();
        ltelefono = new javax.swing.JLabel();
        ltelefono3 = new javax.swing.JLabel();
        tcodigo = new javax.swing.JTextField();
        tCif = new javax.swing.JTextField();
        lpoblacion = new javax.swing.JLabel();
        ltelefono2 = new javax.swing.JLabel();
        tmail = new javax.swing.JTextField();
        pLista = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        Modelo modelo = new Modelo();
        tPresupuestos = new javax.swing.JTable(modelo);
        bAnadirNotaDocumento = new javax.swing.JButton();
        pLista1 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        Modelo modelo2 = new Modelo();
        tcontactos = new javax.swing.JTable(modelo2);
        bAnadirPersona = new javax.swing.JButton();
        bModificarPersona = new javax.swing.JButton();
        bEliminarPersona = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        ldireccion1 = new javax.swing.JLabel();
        tEntidad = new javax.swing.JTextField();
        lcp1 = new javax.swing.JLabel();
        tprovinciaent = new javax.swing.JTextField();
        lpoblacion2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        tcpent = new javax.swing.JTextField();
        lpoblacion1 = new javax.swing.JLabel();
        tpoblacionent = new javax.swing.JTextField();
        tcuenta = new javax.swing.JTextField();
        tdirecent = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        tSwift = new javax.swing.JTextField();
        lcp3 = new javax.swing.JLabel();
        cFormaPago = new javax.swing.JComboBox();
        lFormaPago = new javax.swing.JLabel();
        cContacto = new javax.swing.JComboBox();
        lContacto = new javax.swing.JLabel();
        cbExentoIva = new javax.swing.JCheckBox();
        cDiaCobro1 = new javax.swing.JComboBox();
        lDiaCobro = new javax.swing.JLabel();
        cDiaCobro2 = new javax.swing.JComboBox();
        cDiaCobro3 = new javax.swing.JComboBox();
        cFiscal = new javax.swing.JCheckBox();
        cTerceros = new javax.swing.JCheckBox();
        jPanel4 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        tObservaciones = new javax.swing.JTextArea();
        pDescuentoClienteArticulo = new javax.swing.JPanel();
        jScrollPane4 = new javax.swing.JScrollPane();
        Modelo modelo3 = new Modelo();
        tDtoArticulos = new javax.swing.JTable(modelo3);
        bAnadirDtoArticulo = new javax.swing.JButton();
        bModificarDtoArticulo = new javax.swing.JButton();
        bEliminarDtoArticulo = new javax.swing.JButton();
        pDescuentoClienteFamiliaVenta = new javax.swing.JPanel();
        jScrollPane5 = new javax.swing.JScrollPane();
        Modelo modelo4 = new Modelo();
        tDtoFamiliaVenta = new javax.swing.JTable(modelo4);
        bAnadirDtoFamiliaVenta = new javax.swing.JButton();
        bModificarDtoFamiliaVenta = new javax.swing.JButton();
        bEliminarDtoFamiliaVenta = new javax.swing.JButton();
        jPanel6 = new javax.swing.JPanel();
        tcpFiscal = new javax.swing.JTextField();
        tdireccionFiscal = new javax.swing.JTextField();
        tpoblacionFiscal = new javax.swing.JTextField();
        tprovinciaFiscal = new javax.swing.JTextField();
        lprovincia1 = new javax.swing.JLabel();
        lpoblacion3 = new javax.swing.JLabel();
        ldireccion2 = new javax.swing.JLabel();
        lcp2 = new javax.swing.JLabel();
        jPanel7 = new javax.swing.JPanel();
        pDescuentoClienteArticulo1 = new javax.swing.JPanel();
        jScrollPane8 = new javax.swing.JScrollPane();
        Modelo modelo5 = new Modelo();
        tForArticulos = new javax.swing.JTable(modelo5);
        bAnadirForArticulo = new javax.swing.JButton();
        bModificarForArticulo = new javax.swing.JButton();
        bEliminarForArticulo = new javax.swing.JButton();
        pDescuentoClienteFamiliaVenta1 = new javax.swing.JPanel();
        jScrollPane9 = new javax.swing.JScrollPane();
        Modelo modelo6 = new Modelo();
        tForFamiliaVenta = new javax.swing.JTable(modelo6);
        bAnadirForFamiliaVenta = new javax.swing.JButton();
        bModificarForFamiliaVenta = new javax.swing.JButton();
        BorrarForFamiliaVenta = new javax.swing.JButton();

        bcancelar.setText("Cancelar");
        bcancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bcancelarActionPerformed(evt);
            }
        });

        baceptar.setText("Aceptar");
        baceptar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                baceptarActionPerformed(evt);
            }
        });

        bmodificar.setText("Modificar");
        bmodificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bmodificarActionPerformed(evt);
            }
        });

        jTabbedPane1.setAutoscrolls(true);

        tpoblacion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tpoblacionActionPerformed(evt);
            }
        });
        tpoblacion.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tpoblacionKeyReleased(evt);
            }
        });

        lmail.setText("E-mail");

        tnombreFiscal.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tnombreFiscalKeyReleased(evt);
            }
        });

        lnombrefiscal.setText("Nombre Fiscal");

        lfax.setText("Fax");

        ttlf2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                ttlf2KeyReleased(evt);
            }
        });

        lcodigo.setText("Código");

        ttlf3.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                ttlf3KeyReleased(evt);
            }
        });

        lcp.setText("Código Postal");

        lprovincia.setText("Provincia");

        lpais.setText("Pais");

        lcif.setText("C.I.F.");

        tpais.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tpaisKeyReleased(evt);
            }
        });

        tfax.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tfaxKeyReleased(evt);
            }
        });

        tcp.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tcpKeyReleased(evt);
            }
        });

        tdireccion.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tdireccionKeyReleased(evt);
            }
        });

        lnombrecomercial.setText("Nombre Comercial");

        tnombrecomercial.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tnombrecomercialKeyReleased(evt);
            }
        });

        ttlf.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                ttlfKeyReleased(evt);
            }
        });

        ldireccion.setText("Dirección");

        cIva.setModel(new javax.swing.DefaultComboBoxModel(new String[] { }));

        lIva.setText("Iva");

        ltelefono.setText("Teléfono");

        ltelefono3.setText("Teléfono 3");

        tcodigo.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tcodigoKeyReleased(evt);
            }
        });

        tCif.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tCifKeyReleased(evt);
            }
        });

        lpoblacion.setText("Población");

        ltelefono2.setText("Telefono 2");

        tmail.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tmailKeyReleased(evt);
            }
        });

        pLista.setBorder(javax.swing.BorderFactory.createTitledBorder("Elementos Asociados"));

        modelo.addColumn("Documento");
        modelo.addColumn("Número");
        modelo.addColumn("Serie");
        modelo.addColumn("Fecha");
        modelo.addColumn("Imp. Total");
        modelo.addColumn("Estado");
        List lPresupuesto = BaseDatos.getListaPresupuestoByIdAgenteReducido(a.getCod_agente(), e.getIid());
        Iterator it;
        Object[] fila;
        SimpleDateFormat formatoFecha = new SimpleDateFormat("dd/MM/yyyy");

        if(lPresupuesto != null){
            for (it = lPresupuesto.iterator(); it.hasNext();) {
                fila = (Object[]) it.next();
                fila[3] = formatoFecha.format(fila[3]);
                modelo.addRow(fila);
            }
        }

        tPresupuestos.getColumnModel().getColumn(0).setPreferredWidth(95);
        tPresupuestos.getColumnModel().getColumn(1).setPreferredWidth(95);
        tPresupuestos.getColumnModel().getColumn(2).setPreferredWidth(125);
        tPresupuestos.getColumnModel().getColumn(3).setPreferredWidth(105);
        tPresupuestos.getColumnModel().getColumn(4).setPreferredWidth(95);
        tPresupuestos.getColumnModel().getColumn(5).setPreferredWidth(175);
        tPresupuestos.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        jScrollPane1.setViewportView(tPresupuestos);

        bAnadirNotaDocumento.setText("Añadir Nota");
        URL urlNota = getClass().getResource("/iconos/nota.gif");
        ImageIcon iconoNota = new ImageIcon(urlNota);
        bAnadirNotaDocumento.setIcon(iconoNota);
        bAnadirNotaDocumento.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bAnadirNotaDocumentoActionPerformed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout pListaLayout = new org.jdesktop.layout.GroupLayout(pLista);
        pLista.setLayout(pListaLayout);
        pListaLayout.setHorizontalGroup(
            pListaLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, pListaLayout.createSequentialGroup()
                .add(jScrollPane1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 413, Short.MAX_VALUE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(bAnadirNotaDocumento, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 100, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .add(23, 23, 23))
        );
        pListaLayout.setVerticalGroup(
            pListaLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(bAnadirNotaDocumento)
            .add(jScrollPane1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 80, Short.MAX_VALUE)
        );

        pLista1.setBorder(javax.swing.BorderFactory.createTitledBorder("Personas de Contacto"));

        modelo2.addColumn("Nombre");
        modelo2.addColumn("Teléfono");
        modelo2.addColumn("Móvil");
        modelo2.addColumn("Email");
        modelo2.addColumn("Cargo");
        modelo2.addColumn("Departamento");
        modelo2.addColumn("iid");
        List lcontacto = BaseDatos.getContactoAgente(a);
        Contactos c = new Contactos();
        Iterator itc;
        Object[] filac;
        if(lcontacto != null){
            for (itc = lcontacto.iterator(); itc.hasNext();) {
                filac = new Object[7];
                c = (Contactos) itc.next();
                filac[0] = c.getNombre()+ " " + c.getApellidos();
                filac[1] = c.getTelefono();
                filac[2] = c.getMovil();
                filac[3] = c.getEmail();
                filac[4] = c.getCargo();
                filac[5] = c.getDepartamento();
                filac[6] = c.getIid();
                modelo2.addRow(filac);
            }
        }
        tcontactos.getColumnModel().getColumn(0).setPreferredWidth(200);
        tcontactos.getColumnModel().getColumn(1).setPreferredWidth(80);
        tcontactos.getColumnModel().getColumn(2).setPreferredWidth(80);
        tcontactos.getColumnModel().getColumn(3).setPreferredWidth(140);
        tcontactos.getColumnModel().getColumn(4).setPreferredWidth(80);
        tcontactos.getColumnModel().getColumn(5).setPreferredWidth(80);
        tcontactos.getColumnModel().getColumn(6).setMaxWidth(0);
        tcontactos.getColumnModel().getColumn(6).setMinWidth(0);
        tcontactos.getTableHeader().getColumnModel().getColumn(6).setMaxWidth(0);
        tcontactos.getTableHeader().getColumnModel().getColumn(6).setMinWidth(0);
        tcontactos.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        tcontactos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tcontactosMouseClicked(evt);
            }
        });
        tcontactos.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tcontactosKeyPressed(evt);
            }
        });
        jScrollPane2.setViewportView(tcontactos);

        bAnadirPersona.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bAnadirPersonaActionPerformed(evt);
            }
        });

        bModificarPersona.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bModificarPersonaActionPerformed(evt);
            }
        });

        bEliminarPersona.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bEliminarPersonaActionPerformed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout pLista1Layout = new org.jdesktop.layout.GroupLayout(pLista1);
        pLista1.setLayout(pLista1Layout);
        pLista1Layout.setHorizontalGroup(
            pLista1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, pLista1Layout.createSequentialGroup()
                .add(jScrollPane2, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 489, Short.MAX_VALUE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                .add(pLista1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING, false)
                    .add(bEliminarPersona, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .add(bModificarPersona, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .add(bAnadirPersona, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        pLista1Layout.setVerticalGroup(
            pLista1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(pLista1Layout.createSequentialGroup()
                .add(pLista1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(pLista1Layout.createSequentialGroup()
                        .add(bAnadirPersona, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 18, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(bModificarPersona, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 18, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(bEliminarPersona, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 18, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                    .add(jScrollPane2, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 77, Short.MAX_VALUE))
                .addContainerGap())
        );

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Datos Bancarios", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, null, new java.awt.Color(0, 102, 204)));

        ldireccion1.setText("Dirección");

        tEntidad.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tEntidadKeyReleased(evt);
            }
        });

        lcp1.setText("Código Postal");

        tprovinciaent.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tprovinciaentKeyReleased(evt);
            }
        });

        lpoblacion2.setText("Provincia");

        jLabel1.setText("Nombre de la entidad");

        tcpent.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tcpentKeyReleased(evt);
            }
        });

        lpoblacion1.setText("Población");

        tpoblacionent.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tpoblacionentKeyReleased(evt);
            }
        });

        tcuenta.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tcuentaKeyReleased(evt);
            }
        });

        tdirecent.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tdirecentKeyReleased(evt);
            }
        });

        jLabel2.setText("Cuenta / IBAN");

        tSwift.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tSwiftKeyReleased(evt);
            }
        });

        lcp3.setText("SWIFT");

        org.jdesktop.layout.GroupLayout jPanel2Layout = new org.jdesktop.layout.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel2Layout.createSequentialGroup()
                .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(lpoblacion1)
                    .add(jPanel2Layout.createSequentialGroup()
                        .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(jLabel1)
                            .add(ldireccion1)
                            .add(jLabel2))
                        .add(10, 10, 10)
                        .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                            .add(tdirecent)
                            .add(tEntidad)
                            .add(jPanel2Layout.createSequentialGroup()
                                .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING, false)
                                    .add(org.jdesktop.layout.GroupLayout.LEADING, tcuenta)
                                    .add(org.jdesktop.layout.GroupLayout.LEADING, jPanel2Layout.createSequentialGroup()
                                        .add(tpoblacionent, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 130, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                                        .add(lpoblacion2)
                                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                        .add(tprovinciaent, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 92, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                                    .add(jPanel2Layout.createSequentialGroup()
                                        .add(lcp1)
                                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                        .add(tcpent, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 68, Short.MAX_VALUE))
                                    .add(jPanel2Layout.createSequentialGroup()
                                        .add(lcp3)
                                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                        .add(tSwift)))))))
                .addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel2Layout.createSequentialGroup()
                .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(jLabel1)
                    .add(tEntidad, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 19, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(ldireccion1)
                    .add(tdirecent, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 19, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .add(8, 8, 8)
                .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(lpoblacion1)
                    .add(tcpent, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 19, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(tpoblacionent, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(lpoblacion2)
                    .add(tprovinciaent, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 19, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(lcp1))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(jLabel2)
                    .add(tcuenta, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 18, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(tSwift, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 19, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(lcp3)))
        );

        cFormaPago.setModel(new javax.swing.DefaultComboBoxModel(new String[] {}));

        lFormaPago.setText("Forma de pago");

        cContacto.setModel(new javax.swing.DefaultComboBoxModel(new String[] {"Otros", "Otro Cliente", "Publicidad", "Toldos.org", "Via web" }));

        lContacto.setText("Forma de Contacto");

        cbExentoIva.setText("Exento Iva");
        cbExentoIva.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbExentoIvaActionPerformed(evt);
            }
        });

        cDiaCobro1.setModel(new javax.swing.DefaultComboBoxModel(new String[] {}));

        lDiaCobro.setText("Días de cobro");

        cDiaCobro2.setModel(new javax.swing.DefaultComboBoxModel(new String[] {}));

        cDiaCobro3.setModel(new javax.swing.DefaultComboBoxModel(new String[] {}));

        cFiscal.setSelected(true);
        cFiscal.setText("Fiscal");
        cFiscal.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                cFiscalStateChanged(evt);
            }
        });

        cTerceros.setText("A terceros");

        org.jdesktop.layout.GroupLayout jPanel3Layout = new org.jdesktop.layout.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                        .add(jPanel3Layout.createSequentialGroup()
                            .add(jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                                .add(lcodigo)
                                .add(jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING, false)
                                    .add(org.jdesktop.layout.GroupLayout.LEADING, lcif, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .add(org.jdesktop.layout.GroupLayout.LEADING, lnombrefiscal))
                                .add(lnombrecomercial))
                            .add(9, 9, 9)
                            .add(jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                                .add(tnombrecomercial)
                                .add(tcodigo)
                                .add(tnombreFiscal)
                                .add(org.jdesktop.layout.GroupLayout.TRAILING, tCif, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 213, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                            .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                            .add(jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                                .add(lContacto)
                                .add(lFormaPago)
                                .add(lDiaCobro)
                                .add(cbExentoIva, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 79, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                            .add(13, 13, 13)
                            .add(jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                                .add(org.jdesktop.layout.GroupLayout.LEADING, jPanel3Layout.createSequentialGroup()
                                    .add(cDiaCobro1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 41, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                    .add(cDiaCobro2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 41, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                    .add(cDiaCobro3, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 41, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                                .add(org.jdesktop.layout.GroupLayout.LEADING, cContacto, 0, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .add(jPanel3Layout.createSequentialGroup()
                                    .add(lIva)
                                    .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                    .add(cIva, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 91, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                                .add(org.jdesktop.layout.GroupLayout.LEADING, cFormaPago, 0, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                        .add(jPanel3Layout.createSequentialGroup()
                            .add(jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                                .add(lcp)
                                .add(jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                                    .add(ldireccion, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .add(lpais)
                                    .add(lpoblacion, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .add(lprovincia, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 52, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                            .add(31, 31, 31)
                            .add(jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                                .add(jPanel3Layout.createSequentialGroup()
                                    .add(tcp, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 57, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                                    .add(cFiscal)
                                    .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .add(cTerceros))
                                .add(tdireccion)
                                .add(tpoblacion)
                                .add(tprovincia)
                                .add(tpais, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 211, Short.MAX_VALUE))
                            .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                            .add(jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                                .add(jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                                    .add(ltelefono2)
                                    .add(ltelefono3)
                                    .add(org.jdesktop.layout.GroupLayout.LEADING, ltelefono))
                                .add(lmail)
                                .add(lfax))
                            .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                            .add(jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                                .add(jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                                    .add(tmail)
                                    .add(ttlf2)
                                    .add(ttlf3)
                                    .add(ttlf, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 99, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                                .add(tfax, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 99, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                        .add(jSeparator1))
                    .add(org.jdesktop.layout.GroupLayout.TRAILING, pLista, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .add(org.jdesktop.layout.GroupLayout.TRAILING, pLista1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .add(jPanel2, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                    .add(jPanel3Layout.createSequentialGroup()
                        .add(jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(lcodigo)
                            .add(tcodigo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(lnombrecomercial)
                            .add(tnombrecomercial, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(lnombrefiscal)
                            .add(tnombreFiscal, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(lcif)
                            .add(tCif, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(lDiaCobro)))
                    .add(jPanel3Layout.createSequentialGroup()
                        .add(jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(cbExentoIva)
                            .add(cIva, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 22, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(lIva))
                        .add(jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(jPanel3Layout.createSequentialGroup()
                                .add(52, 52, 52)
                                .add(jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                                    .add(cDiaCobro1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                    .add(cDiaCobro2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                    .add(cDiaCobro3, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                            .add(jPanel3Layout.createSequentialGroup()
                                .add(jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                                    .add(lContacto)
                                    .add(cContacto, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 22, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                .add(jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                                    .add(lFormaPago)
                                    .add(cFormaPago, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))))))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jSeparator1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 4, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .add(jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jPanel3Layout.createSequentialGroup()
                        .add(6, 6, 6)
                        .add(jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                            .add(lpais)
                            .add(tpais, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(lprovincia)
                            .add(tprovincia, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(lpoblacion)
                            .add(tpoblacion, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                    .add(jPanel3Layout.createSequentialGroup()
                        .add(11, 11, 11)
                        .add(jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(ltelefono)
                            .add(ttlf, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(ltelefono2)
                            .add(ttlf2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(ltelefono3)
                            .add(ttlf3, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(ldireccion)
                    .add(tdireccion, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(lfax)
                    .add(tfax, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                        .add(lcp)
                        .add(tcp, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(cFiscal)
                        .add(cTerceros))
                    .add(jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                        .add(lmail)
                        .add(tmail, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(pLista1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(pLista, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        List lIva = BaseDatos.getListaIva();
        Iva iva;
        cIva.addItem("-- Vacío --");
        for (Iterator it1 = lIva.iterator(); it1.hasNext();) {
            iva = (Iva) it1.next();
            cIva.addItem(iva.getPorcentaje()+"%");
        }
        //Creamos la lista de formas de pago
        cFormaPago.addItem(Constantes.VACIO);
        List lfp = BaseDatos.getListaFormaPago();
        FormaPago fpaux;
        for (Iterator it2 = lfp.iterator(); it2.hasNext();) {
            fpaux = (FormaPago) it2.next();
            cFormaPago.addItem(fpaux.getCodigo());
        }

        jTabbedPane1.addTab("Datos generales", jPanel3);

        jPanel5.setBorder(javax.swing.BorderFactory.createTitledBorder("Observaciones"));

        tObservaciones.setColumns(20);
        tObservaciones.setRows(5);
        jScrollPane3.setViewportView(tObservaciones);

        org.jdesktop.layout.GroupLayout jPanel5Layout = new org.jdesktop.layout.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, jPanel5Layout.createSequentialGroup()
                .add(jScrollPane3, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 552, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel5Layout.createSequentialGroup()
                .add(jScrollPane3, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 101, Short.MAX_VALUE)
                .add(1, 1, 1))
        );

        pDescuentoClienteArticulo.setBorder(javax.swing.BorderFactory.createTitledBorder("Descuento en artículos"));

        modelo3.addColumn("Artículo");
        modelo3.addColumn("Descuento");
        tDtoArticulos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tDtoArticulosMouseClicked(evt);
            }
        });
        tDtoArticulos.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tDtoArticulosKeyPressed(evt);
            }
        });
        jScrollPane4.setViewportView(tDtoArticulos);

        bAnadirDtoArticulo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bAnadirDtoArticuloActionPerformed(evt);
            }
        });

        bModificarDtoArticulo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bModificarDtoArticuloActionPerformed(evt);
            }
        });

        bEliminarDtoArticulo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bEliminarDtoArticuloActionPerformed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout pDescuentoClienteArticuloLayout = new org.jdesktop.layout.GroupLayout(pDescuentoClienteArticulo);
        pDescuentoClienteArticulo.setLayout(pDescuentoClienteArticuloLayout);
        pDescuentoClienteArticuloLayout.setHorizontalGroup(
            pDescuentoClienteArticuloLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, pDescuentoClienteArticuloLayout.createSequentialGroup()
                .add(jScrollPane4, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 515, Short.MAX_VALUE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(pDescuentoClienteArticuloLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                    .add(bAnadirDtoArticulo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 31, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(bModificarDtoArticulo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 31, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(bEliminarDtoArticulo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 31, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );
        pDescuentoClienteArticuloLayout.setVerticalGroup(
            pDescuentoClienteArticuloLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(pDescuentoClienteArticuloLayout.createSequentialGroup()
                .add(bAnadirDtoArticulo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 23, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                .add(bModificarDtoArticulo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 23, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                .add(bEliminarDtoArticulo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 23, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .add(73, 73, 73))
            .add(jScrollPane4, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 170, Short.MAX_VALUE)
        );

        pDescuentoClienteFamiliaVenta.setBorder(javax.swing.BorderFactory.createTitledBorder("Descuento en familia de ventas"));

        modelo4.addColumn("Familia Venta");
        modelo4.addColumn("Descuento");
        tDtoFamiliaVenta.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tDtoFamiliaVentaMouseClicked(evt);
            }
        });
        tDtoFamiliaVenta.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tDtoFamiliaVentaKeyPressed(evt);
            }
        });
        jScrollPane5.setViewportView(tDtoFamiliaVenta);

        bAnadirDtoFamiliaVenta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bAnadirDtoFamiliaVentaActionPerformed(evt);
            }
        });

        bModificarDtoFamiliaVenta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bModificarDtoFamiliaVentaActionPerformed(evt);
            }
        });

        bEliminarDtoFamiliaVenta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bEliminarDtoFamiliaVentaActionPerformed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout pDescuentoClienteFamiliaVentaLayout = new org.jdesktop.layout.GroupLayout(pDescuentoClienteFamiliaVenta);
        pDescuentoClienteFamiliaVenta.setLayout(pDescuentoClienteFamiliaVentaLayout);
        pDescuentoClienteFamiliaVentaLayout.setHorizontalGroup(
            pDescuentoClienteFamiliaVentaLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, pDescuentoClienteFamiliaVentaLayout.createSequentialGroup()
                .add(jScrollPane5, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 515, Short.MAX_VALUE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(pDescuentoClienteFamiliaVentaLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                    .add(bAnadirDtoFamiliaVenta, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 31, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(bModificarDtoFamiliaVenta, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 31, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(bEliminarDtoFamiliaVenta, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 31, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );
        pDescuentoClienteFamiliaVentaLayout.setVerticalGroup(
            pDescuentoClienteFamiliaVentaLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(pDescuentoClienteFamiliaVentaLayout.createSequentialGroup()
                .add(bAnadirDtoFamiliaVenta, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 23, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                .add(bModificarDtoFamiliaVenta, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 23, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                .add(bEliminarDtoFamiliaVenta, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 23, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .add(42, 42, 42))
            .add(jScrollPane5, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 140, Short.MAX_VALUE)
        );

        org.jdesktop.layout.GroupLayout jPanel4Layout = new org.jdesktop.layout.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel4Layout.createSequentialGroup()
                .add(jPanel4Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                    .add(org.jdesktop.layout.GroupLayout.LEADING, jPanel5, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .add(org.jdesktop.layout.GroupLayout.LEADING, pDescuentoClienteFamiliaVenta, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .add(org.jdesktop.layout.GroupLayout.LEADING, pDescuentoClienteArticulo, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .add(0, 0, 0))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .add(pDescuentoClienteArticulo, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                .add(pDescuentoClienteFamiliaVenta, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                .add(jPanel5, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .add(93, 93, 93))
        );

        jTabbedPane1.addTab("Descuentos y observaciones", jPanel4);

        tcpFiscal.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tcpFiscalKeyReleased(evt);
            }
        });

        tdireccionFiscal.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tdireccionFiscalKeyReleased(evt);
            }
        });

        tpoblacionFiscal.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tpoblacionFiscalKeyReleased(evt);
            }
        });

        tprovinciaFiscal.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tprovinciaFiscalKeyReleased(evt);
            }
        });

        lprovincia1.setText("Provincia");

        lpoblacion3.setText("Población");

        ldireccion2.setText("Dirección");

        lcp2.setText("Código Postal");

        org.jdesktop.layout.GroupLayout jPanel6Layout = new org.jdesktop.layout.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel6Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(lcp2)
                    .add(jPanel6Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                        .add(ldireccion2, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .add(lpoblacion3, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .add(lprovincia1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 52, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                .add(31, 31, 31)
                .add(jPanel6Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(tcpFiscal, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 57, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(tprovinciaFiscal, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 95, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(tpoblacionFiscal, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 161, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(tdireccionFiscal, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 260, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(208, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel6Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(lprovincia1)
                    .add(tprovinciaFiscal, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel6Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(lpoblacion3)
                    .add(tpoblacionFiscal, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel6Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(ldireccion2)
                    .add(tdireccionFiscal, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel6Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(lcp2)
                    .add(tcpFiscal, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(498, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Dirección Fiscal", jPanel6);

        pDescuentoClienteArticulo1.setBorder(javax.swing.BorderFactory.createTitledBorder("Fórmula por Artículo"));

        modelo5.addColumn("Artículo");
        modelo5.addColumn("Fórmula");
        tForArticulos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tForArticulosMouseClicked(evt);
            }
        });
        tForArticulos.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tForArticulosKeyPressed(evt);
            }
        });
        jScrollPane8.setViewportView(tForArticulos);

        bAnadirForArticulo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bAnadirForArticuloActionPerformed(evt);
            }
        });

        bModificarForArticulo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bModificarForArticuloActionPerformed(evt);
            }
        });

        bEliminarForArticulo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bEliminarForArticuloActionPerformed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout pDescuentoClienteArticulo1Layout = new org.jdesktop.layout.GroupLayout(pDescuentoClienteArticulo1);
        pDescuentoClienteArticulo1.setLayout(pDescuentoClienteArticulo1Layout);
        pDescuentoClienteArticulo1Layout.setHorizontalGroup(
            pDescuentoClienteArticulo1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, pDescuentoClienteArticulo1Layout.createSequentialGroup()
                .add(jScrollPane8, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 515, Short.MAX_VALUE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(pDescuentoClienteArticulo1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                    .add(bAnadirForArticulo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 31, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(bModificarForArticulo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 31, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(bEliminarForArticulo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 31, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );
        pDescuentoClienteArticulo1Layout.setVerticalGroup(
            pDescuentoClienteArticulo1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(pDescuentoClienteArticulo1Layout.createSequentialGroup()
                .add(bAnadirForArticulo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 23, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                .add(bModificarForArticulo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 23, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                .add(bEliminarForArticulo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 23, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .add(73, 73, 73))
            .add(jScrollPane8, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 170, Short.MAX_VALUE)
        );

        pDescuentoClienteFamiliaVenta1.setBorder(javax.swing.BorderFactory.createTitledBorder("Fórmula por Familia de Venta"));

        modelo6.addColumn("Familia Venta");
        modelo6.addColumn("Fórmula");
        tForFamiliaVenta.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tForFamiliaVentaMouseClicked(evt);
            }
        });
        tForFamiliaVenta.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tForFamiliaVentaKeyPressed(evt);
            }
        });
        jScrollPane9.setViewportView(tForFamiliaVenta);

        bAnadirForFamiliaVenta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bAnadirForFamiliaVentaActionPerformed(evt);
            }
        });

        bModificarForFamiliaVenta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bModificarForFamiliaVentaActionPerformed(evt);
            }
        });

        BorrarForFamiliaVenta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BorrarForFamiliaVentaActionPerformed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout pDescuentoClienteFamiliaVenta1Layout = new org.jdesktop.layout.GroupLayout(pDescuentoClienteFamiliaVenta1);
        pDescuentoClienteFamiliaVenta1.setLayout(pDescuentoClienteFamiliaVenta1Layout);
        pDescuentoClienteFamiliaVenta1Layout.setHorizontalGroup(
            pDescuentoClienteFamiliaVenta1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, pDescuentoClienteFamiliaVenta1Layout.createSequentialGroup()
                .add(jScrollPane9, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 515, Short.MAX_VALUE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(pDescuentoClienteFamiliaVenta1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                    .add(bAnadirForFamiliaVenta, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 31, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(bModificarForFamiliaVenta, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 31, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(BorrarForFamiliaVenta, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 31, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );
        pDescuentoClienteFamiliaVenta1Layout.setVerticalGroup(
            pDescuentoClienteFamiliaVenta1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(pDescuentoClienteFamiliaVenta1Layout.createSequentialGroup()
                .add(bAnadirForFamiliaVenta, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 23, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                .add(bModificarForFamiliaVenta, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 23, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                .add(BorrarForFamiliaVenta, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 23, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .add(42, 42, 42))
            .add(jScrollPane9, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 140, Short.MAX_VALUE)
        );

        org.jdesktop.layout.GroupLayout jPanel7Layout = new org.jdesktop.layout.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel7Layout.createSequentialGroup()
                .add(jPanel7Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                    .add(org.jdesktop.layout.GroupLayout.LEADING, pDescuentoClienteFamiliaVenta1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .add(org.jdesktop.layout.GroupLayout.LEADING, pDescuentoClienteArticulo1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .add(0, 0, 0))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel7Layout.createSequentialGroup()
                .add(72, 72, 72)
                .add(pDescuentoClienteArticulo1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .add(107, 107, 107)
                .add(pDescuentoClienteFamiliaVenta1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .add(72, 72, 72))
        );

        jTabbedPane1.addTab("Fórmula Precio", jPanel7);

        jScrollPane6.setViewportView(jTabbedPane1);

        org.jdesktop.layout.GroupLayout layout = new org.jdesktop.layout.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(layout.createSequentialGroup()
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                    .add(layout.createSequentialGroup()
                        .add(baceptar)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(bmodificar, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 103, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(bcancelar))
                    .add(jScrollPane6))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(layout.createSequentialGroup()
                .add(jScrollPane6, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 636, Short.MAX_VALUE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(bcancelar)
                    .add(bmodificar)
                    .add(baceptar))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

private void bmodificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bmodificarActionPerformed
    if (bmodificar.getText().equals("Modificar")) {
        //Si el botón tiene el texto Modificar
        cContacto.setEnabled(true);
        tcodigo.setEnabled(true);
        tnombreFiscal.setEnabled(true);
        tnombrecomercial.setEnabled(true);
        tCif.setEnabled(true);
        tpais.setEnabled(true);
        tprovincia.setEnabled(true);
        tpoblacion.setEnabled(true);
        tdireccion.setEnabled(true);
        tprovinciaFiscal.setEnabled(true);
        tpoblacionFiscal.setEnabled(true);
        tdireccionFiscal.setEnabled(true);
        tcpFiscal.setEnabled(true);
        tcp.setEnabled(true);
        ttlf.setEnabled(true);
        ttlf2.setEnabled(true);
        ttlf3.setEnabled(true);
        tmail.setEnabled(true);
        tfax.setEnabled(true);
        cIva.setEnabled(true);
        tEntidad.setEnabled(true);
        tdirecent.setEnabled(true);
        tcpent.setEnabled(true);
        tprovinciaent.setEnabled(true);
        tpoblacionent.setEnabled(true);
        tcuenta.setEnabled(true);
        bAnadirPersona.setEnabled(true);
        bEliminarPersona.setEnabled(true);
        bModificarPersona.setEnabled(true);
        bAnadirNotaDocumento.setEnabled(true);
        cbExentoIva.setEnabled(true);
        cFormaPago.setEnabled(true);
        tObservaciones.setEnabled(true);
        bAnadirDtoArticulo.setEnabled(true);
        bAnadirDtoFamiliaVenta.setEnabled(true);
        bEliminarDtoArticulo.setEnabled(true);
        bEliminarDtoFamiliaVenta.setEnabled(true);
        bModificarDtoArticulo.setEnabled(true);
        bModificarDtoFamiliaVenta.setEnabled(true);
        bAnadirForArticulo.setEnabled(true);
        bAnadirForFamiliaVenta.setEnabled(true);
        bEliminarForArticulo.setEnabled(true);
        BorrarForFamiliaVenta.setEnabled(true);
        bModificarForArticulo.setEnabled(true);
        bModificarForFamiliaVenta.setEnabled(true);
        bModificarPersona.setEnabled(true);
        bAnadirPersona.setEnabled(true);
        bEliminarPersona.setEnabled(true);
        tcontactos.setEnabled(true);
        tPresupuestos.setEnabled(true);
        tDtoArticulos.setEnabled(true);
        tDtoFamiliaVenta.setEnabled(true);
        cDiaCobro1.setEnabled(true);
        cDiaCobro2.setEnabled(true);
        cDiaCobro3.setEnabled(true);
        cFiscal.setEnabled(true);
        bmodificar.setText("Visualizar");
        bmodificar.setToolTipText("Visualizar campos");
        bmodificar.setToolTipText("Modificar campos");
        cTerceros.setEnabled(true);
        tSwift.setEnabled(true);

        URL urlModificar = getClass().getResource("/iconos/buscar.gif");
        ImageIcon iconoModificar = new ImageIcon(urlModificar);
        bmodificar.setIcon(iconoModificar);

    } else {
        //si el botón tiene el texto Visualizar
        cContacto.setEnabled(false);
        tcodigo.setEnabled(false);
        tnombreFiscal.setEnabled(false);
        tnombrecomercial.setEnabled(false);
        tCif.setEnabled(false);
        tpais.setEnabled(false);
        tprovincia.setEnabled(false);
        tpoblacion.setEnabled(false);
        tdireccion.setEnabled(false);
        tprovinciaFiscal.setEnabled(false);
        tpoblacionFiscal.setEnabled(false);
        tdireccionFiscal.setEnabled(false);
        tcpFiscal.setEnabled(false);
        tcp.setEnabled(false);
        ttlf.setEnabled(false);
        ttlf2.setEnabled(false);
        ttlf3.setEnabled(false);
        tmail.setEnabled(false);
        tfax.setEnabled(false);
        cIva.setEnabled(false);
        cFormaPago.setEnabled(false);
        cbExentoIva.setEnabled(false);
        tEntidad.setEnabled(false);
        tdirecent.setEnabled(false);
        tcpent.setEnabled(false);
        tprovinciaent.setEnabled(false);
        tpoblacionent.setEnabled(false);
        tcuenta.setEnabled(false);
        tObservaciones.setEnabled(false);
        bAnadirNotaDocumento.setEnabled(false);
        bAnadirDtoArticulo.setEnabled(false);
        bAnadirDtoFamiliaVenta.setEnabled(false);
        bEliminarDtoArticulo.setEnabled(false);
        bEliminarDtoFamiliaVenta.setEnabled(false);
        bModificarDtoArticulo.setEnabled(false);
        bModificarDtoFamiliaVenta.setEnabled(false);

        bAnadirForArticulo.setEnabled(false);
        bAnadirForFamiliaVenta.setEnabled(false);
        bEliminarForArticulo.setEnabled(false);
        BorrarForFamiliaVenta.setEnabled(false);
        bModificarForArticulo.setEnabled(false);
        bModificarForFamiliaVenta.setEnabled(false);

        bModificarPersona.setEnabled(false);
        bAnadirPersona.setEnabled(false);
        bEliminarPersona.setEnabled(false);
        tcontactos.setEnabled(false);
        tPresupuestos.setEnabled(false);
        tDtoArticulos.setEnabled(false);
        tDtoFamiliaVenta.setEnabled(false);
        cDiaCobro1.setEnabled(false);
        cDiaCobro2.setEnabled(false);
        cDiaCobro3.setEnabled(false);
        cFiscal.setEnabled(false);
        cTerceros.setEnabled(false);
        bmodificar.setText("Modificar");
        tSwift.setEnabled(true);

        URL urlModificar = getClass().getResource("/iconos/editar.png");
        ImageIcon iconoModificar = new ImageIcon(urlModificar);
        bmodificar.setIcon(iconoModificar);
    }
}//GEN-LAST:event_bmodificarActionPerformed

private void baceptarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_baceptarActionPerformed
    String nombreFiscal = tnombreFiscal.getText();
    String nombreComercial = tnombrecomercial.getText();
    String cif = tCif.getText();
    String codigo = tcodigo.getText();

    if (codigo != null && codigo.length() > 0
            && cif != null && cif.length() > 0
            && nombreFiscal != null && nombreFiscal.length() > 0
            && nombreComercial != null && nombreComercial.length() > 0) {

        try {
            FormaPago fp = BaseDatos.obtenerFormaPago((String) cFormaPago.getSelectedItem());
            if (Util.isNifNie(cif)) {
                //El IBAN o el Swift deben estar informados
                if (!tSwift.getText().equals("") || !tcuenta.getText().equals("")) {
                    a.setCod_agente(codigo);
                    a.setNombre_comercial(nombreComercial);
                    a.setNombre_fiscal(nombreFiscal);
                    a.setCif_nif(cif);
                    a.setPais(tpais.getText());
                    a.setProvincia(tprovincia.getText());
                    a.setPoblacion(tpoblacion.getText());
                    a.setDireccion(tdireccion.getText());
                    a.setCodigo_postal(Integer.parseInt(tcp.getText()));
                    a.setProvincia_fiscal(tprovinciaFiscal.getText());
                    a.setPoblacion_fiscal(tpoblacionFiscal.getText());
                    a.setDireccion_fiscal(tdireccionFiscal.getText());
                    a.setCodigo_postal_fiscal(Integer.parseInt(tcpFiscal.getText()));
                    a.setTelefono(ttlf.getText());
                    a.setTelefono2(ttlf2.getText());
                    a.setTelefono3(ttlf3.getText());
                    a.setEmail(tmail.getText());
                    a.setFax(tfax.getText());
                    a.setContactar((String) cContacto.getSelectedItem());
                    a.setEntidad(tEntidad.getText());
                    a.setDirec_ent(tdirecent.getText());
                    a.setCp_ent(tcpent.getText());
                    a.setProv_ent(tprovinciaent.getText());
                    a.setPob_ent(tpoblacionent.getText());
                    a.setCuenta(tcuenta.getText());
                    a.setFormaPago(fp);
                    a.setIid_empresa(e);
                    a.setObservaciones(tObservaciones.getText());
                    a.setTerceros(cTerceros.isSelected());
                    a.setSwift(tSwift.getText());

                    String sCobro = (String) cDiaCobro1.getSelectedItem();
                    if (!sCobro.equals("--")) {
                        a.setDiaCobro1(new Integer(sCobro));
                    } else {
                        a.setDiaCobro1(null);
                    }

                    sCobro = (String) cDiaCobro2.getSelectedItem();
                    if (!sCobro.equals("--")) {
                        a.setDiaCobro2(new Integer(sCobro));
                    } else {
                        a.setDiaCobro2(null);
                    }

                    sCobro = (String) cDiaCobro3.getSelectedItem();
                    if (!sCobro.equals("--")) {
                        a.setDiaCobro3(new Integer(sCobro));
                    } else {
                        a.setDiaCobro3(null);
                    }

                    if (cbExentoIva.isSelected()) {
                        a.setExento_iva(true);
                        a.setIva(null);
                    } else {
                        a.setExento_iva(false);
                        String sPorcentaje = (String) cIva.getSelectedItem();
                        if (!sPorcentaje.equals("-- Vacío --")) {
                            String sPor = sPorcentaje.substring(0, sPorcentaje.length() - 1);
                            a.setIva(BaseDatos.obtenerIvaPorPorcentaje(sPor));
                        }
                    }

                    if (crear) {
                        //Agentes temp = BaseDatos.obtenerAgentesPorCodigo(codigo, tipo, e);
                        Agentes temp = BaseDatos.obtenerAgentesPorCodigo(codigo, "", e);

                        if (temp == null) {
                            if (BaseDatos.insertarAgente(a, listacontactos, listaDescuentoClienteArticulos, listaDescuentoClienteFamiliaVentas, listaFormulaArticulo, listaFormulaFamilia)) {
                                cerrarCliente();
                            } else {
                                JOptionPane.showMessageDialog(null, "No se ha podido insertar el elemento", "Error", JOptionPane.ERROR_MESSAGE);
                            }
                        } else {
                            JOptionPane.showMessageDialog(null, "Ya hay un cliente con el codigo " + codigo, "Error", JOptionPane.ERROR_MESSAGE);
                        }
                    } else {
                        int hacerCambios = 1;

                        if (hayCambios()) {
                            hacerCambios = JOptionPane.showConfirmDialog(null, "Está seguro de que desea realizar los cambios?", "¿Realizar cambios?", JOptionPane.YES_NO_OPTION);
                            //hacerCambios = -1 ==> se ha pulsado la "x" de cancelar;
                            //hacerCambios =  0 ==> se ha pulsado el "sí"
                            //hacerCambios =  1 ==> se ha pulsado el "no"
                            if (hacerCambios == 0) {
                                Agentes temp = null;

                                if (!codigo.equalsIgnoreCase(codigoAntiguo)) {
                                    //temp = BaseDatos.obtenerAgentesPorCodigo(codigo, tipo, e);
                                    temp = BaseDatos.obtenerAgentesPorCodigo(codigo, "", e);
                                }

                                if (temp == null) {
                                    if (BaseDatos.modificarAgente(a, listacontactos, listaDescuentoClienteArticulos, listaDescuentoClienteFamiliaVentas, listaFormulaArticulo, listaFormulaFamilia)) {
                                        cerrarCliente();
                                    } else {
                                        JOptionPane.showMessageDialog(null, "No se ha podido modificar el elemento", "Error", JOptionPane.ERROR_MESSAGE);
                                    }
                                } else {
                                    JOptionPane.showMessageDialog(null, "Ya hay un cliente con el codigo " + codigo, "Error", JOptionPane.ERROR_MESSAGE);
                                }
                            }
                        } else {
                            JOptionPane.showMessageDialog(null, "No hay cambios que realizar", "Sin cambios", JOptionPane.ERROR_MESSAGE);
                        }
                    }

                } else {
                    JOptionPane.showMessageDialog(null, "El IBAN o el SWIFT deben estar informado", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(null, "El CIF introducido es incorrecto", "Error", JOptionPane.ERROR_MESSAGE);
            }

        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "El campo \"Código Postal\" debe ser numérico", "Error", JOptionPane.ERROR_MESSAGE);
        }
    } else {
        JOptionPane.showMessageDialog(null, "Debe rellenar el Código, Nombre Comercial, Nombre Fiscal y CIF", "Error", JOptionPane.ERROR_MESSAGE);
    }
}//GEN-LAST:event_baceptarActionPerformed

private void bcancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bcancelarActionPerformed
    cerrarCliente();
}//GEN-LAST:event_bcancelarActionPerformed

private void bEliminarDtoFamiliaVentaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bEliminarDtoFamiliaVentaActionPerformed
    borrarDtoFamilia();
}//GEN-LAST:event_bEliminarDtoFamiliaVentaActionPerformed

private void bModificarDtoFamiliaVentaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bModificarDtoFamiliaVentaActionPerformed
    visualizarDescuentoClienteFamiliaVenta();
}//GEN-LAST:event_bModificarDtoFamiliaVentaActionPerformed

private void bAnadirDtoFamiliaVentaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bAnadirDtoFamiliaVentaActionPerformed
    NuevoDtoFamiliaVenta ndfv = new NuevoDtoFamiliaVenta(this, "Descuento Familia Venta - Creación", e);
    ndfv.setDefaultCloseOperation(NuevoDtoFamiliaVenta.DISPOSE_ON_CLOSE);
    ndfv.setLocationRelativeTo(null);
    ndfv.setVisible(true);
}//GEN-LAST:event_bAnadirDtoFamiliaVentaActionPerformed

private void tDtoFamiliaVentaKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tDtoFamiliaVentaKeyPressed
    if (evt.getKeyChar() == KeyEvent.VK_ENTER) {
        visualizarDescuentoClienteFamiliaVenta();
    } else if (evt.getKeyChar() == KeyEvent.VK_DELETE) {
        borrarDtoFamilia();
    }
}//GEN-LAST:event_tDtoFamiliaVentaKeyPressed

private void tDtoFamiliaVentaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tDtoFamiliaVentaMouseClicked
    if (evt.getClickCount() == 2) {
        visualizarDescuentoClienteFamiliaVenta();
    }
}//GEN-LAST:event_tDtoFamiliaVentaMouseClicked

private void bEliminarDtoArticuloActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bEliminarDtoArticuloActionPerformed
    borrarDtoArticulo();
}//GEN-LAST:event_bEliminarDtoArticuloActionPerformed

private void bModificarDtoArticuloActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bModificarDtoArticuloActionPerformed
    visualizarDescuentoClienteArticulo();
}//GEN-LAST:event_bModificarDtoArticuloActionPerformed

private void bAnadirDtoArticuloActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bAnadirDtoArticuloActionPerformed
    NuevoDtoArticulo nda = new NuevoDtoArticulo(this, "Descuento Artículo - Creación", e);
    nda.setDefaultCloseOperation(NuevoDtoArticulo.DISPOSE_ON_CLOSE);
    nda.setLocationRelativeTo(null);
    nda.setVisible(true);
}//GEN-LAST:event_bAnadirDtoArticuloActionPerformed

private void tDtoArticulosKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tDtoArticulosKeyPressed
    if (evt.getKeyChar() == KeyEvent.VK_ENTER) {
        visualizarDescuentoClienteArticulo();
    } else if (evt.getKeyChar() == KeyEvent.VK_DELETE) {
        borrarDtoArticulo();
    }
}//GEN-LAST:event_tDtoArticulosKeyPressed

private void tDtoArticulosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tDtoArticulosMouseClicked
    if (evt.getClickCount() == 2) {
        visualizarDescuentoClienteArticulo();
    }
}//GEN-LAST:event_tDtoArticulosMouseClicked

private void bAnadirNotaDocumentoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bAnadirNotaDocumentoActionPerformed
    indiceFila = -1;
    indiceFila = tPresupuestos.getSelectedRow();

    if (indiceFila >= 0) {
        String numero = "";
        String claseDocumento = "";
        numero = (String) tPresupuestos.getModel().getValueAt(indiceFila, 1);
        claseDocumento = (String) tPresupuestos.getModel().getValueAt(indiceFila, 0);
        Presupuesto p = BaseDatos.obtenerPresupuestoPorNumeroPorClaseDocumento(numero, claseDocumento, e);

        NuevaNotaDocumento nnd = new NuevaNotaDocumento(this, p);
        nnd.setDefaultCloseOperation(NuevaNotaDocumento.DISPOSE_ON_CLOSE);
        nnd.setLocationRelativeTo(null);
        nnd.setVisible(true);
    } else {
        JOptionPane.showMessageDialog(null, "No hay seleccionado ningún documento", "Error", JOptionPane.ERROR_MESSAGE);
    }
}//GEN-LAST:event_bAnadirNotaDocumentoActionPerformed

private void bEliminarPersonaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bEliminarPersonaActionPerformed
    borrarContacto();
}//GEN-LAST:event_bEliminarPersonaActionPerformed

private void bModificarPersonaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bModificarPersonaActionPerformed
    visualizarContacto();
}//GEN-LAST:event_bModificarPersonaActionPerformed

private void bAnadirPersonaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bAnadirPersonaActionPerformed
    NuevoContacto nc = new NuevoContacto(a, this);
    nc.setDefaultCloseOperation(NuevaNotaDocumento.DISPOSE_ON_CLOSE);
    nc.setLocationRelativeTo(null);
    nc.setVisible(true);
}//GEN-LAST:event_bAnadirPersonaActionPerformed

private void tcontactosKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tcontactosKeyPressed
    if (evt.getKeyChar() == KeyEvent.VK_ENTER) {
        visualizarContacto();
    } else if (evt.getKeyChar() == KeyEvent.VK_DELETE) {
        borrarContacto();
    }
}//GEN-LAST:event_tcontactosKeyPressed

private void tcontactosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tcontactosMouseClicked
    if (evt.getClickCount() == 2) {
        visualizarContacto();
    }
}//GEN-LAST:event_tcontactosMouseClicked

private void tdirecentKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tdirecentKeyReleased
    String codigo = tdirecent.getText();
    if (codigo.length() > Constantes.TAM_DIRECCION_ENTIDAD_AGENTE) {
        JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_DIRECCION_ENTIDAD_AGENTE, "Error", JOptionPane.ERROR_MESSAGE);
        tdirecent.setText(codigo.substring(0, Constantes.TAM_DIRECCION_ENTIDAD_AGENTE));
    }
}//GEN-LAST:event_tdirecentKeyReleased

private void tcuentaKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tcuentaKeyReleased
    String codigo = tcuenta.getText();
    if (codigo.length() > Constantes.TAM_CUENTA_ENTIDAD_AGENTE) {
        JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_CUENTA_ENTIDAD_AGENTE, "Error", JOptionPane.ERROR_MESSAGE);
        tcuenta.setText(codigo.substring(0, Constantes.TAM_CUENTA_ENTIDAD_AGENTE));
    }
}//GEN-LAST:event_tcuentaKeyReleased

private void tpoblacionentKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tpoblacionentKeyReleased
    String codigo = tpoblacionent.getText();
    if (codigo.length() > Constantes.TAM_POBLACION_ENTIDAD_AGENTE) {
        JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_POBLACION_ENTIDAD_AGENTE, "Error", JOptionPane.ERROR_MESSAGE);
        tpoblacionent.setText(codigo.substring(0, Constantes.TAM_POBLACION_ENTIDAD_AGENTE));
    }
}//GEN-LAST:event_tpoblacionentKeyReleased

private void tcpentKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tcpentKeyReleased
    String cpent = tcpent.getText();
    if (cpent.length() > Constantes.TAM_CP) {
        JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_CP, "Error", JOptionPane.ERROR_MESSAGE);
        tcpent.setText(cpent.substring(0, Constantes.TAM_CP));
    }
}//GEN-LAST:event_tcpentKeyReleased

private void tprovinciaentKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tprovinciaentKeyReleased
    String codigo = tprovinciaent.getText();
    if (codigo.length() > Constantes.TAM_PROVINCIA_ENTIDAD_AGENTE) {
        JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_PROVINCIA_ENTIDAD_AGENTE, "Error", JOptionPane.ERROR_MESSAGE);
        tprovinciaent.setText(codigo.substring(0, Constantes.TAM_PROVINCIA_ENTIDAD_AGENTE));
    }
}//GEN-LAST:event_tprovinciaentKeyReleased

private void tEntidadKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tEntidadKeyReleased
    String codigo = tEntidad.getText();
    if (codigo.length() > Constantes.TAM_ENTIDAD_AGENTE) {
        JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_ENTIDAD_AGENTE, "Error", JOptionPane.ERROR_MESSAGE);
        tEntidad.setText(codigo.substring(0, Constantes.TAM_ENTIDAD_AGENTE));
    }
}//GEN-LAST:event_tEntidadKeyReleased

private void cbExentoIvaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbExentoIvaActionPerformed
    boolean visible = !cbExentoIva.isSelected();
    lIva.setVisible(visible);
    cIva.setVisible(visible);
    lIva.setEnabled(visible);
    cIva.setEnabled(visible);
}//GEN-LAST:event_cbExentoIvaActionPerformed

private void tcodigoKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tcodigoKeyReleased
    String codigo = tcodigo.getText();
    if (codigo.length() > Constantes.TAM_CODIGO_AGENTE) {
        JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_CODIGO_AGENTE, "Error", JOptionPane.ERROR_MESSAGE);
        tcodigo.setText(codigo.substring(0, Constantes.TAM_CODIGO_AGENTE));
    }
}//GEN-LAST:event_tcodigoKeyReleased

private void tCifKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tCifKeyReleased
    String codigo = tCif.getText();
    if (codigo.length() > Constantes.TAM_CIF_AGENTE) {
        JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_CIF_AGENTE, "Error", JOptionPane.ERROR_MESSAGE);
        tCif.setText(codigo.substring(0, Constantes.TAM_CIF_AGENTE));
    }
}//GEN-LAST:event_tCifKeyReleased

private void tmailKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tmailKeyReleased
    String codigo = tmail.getText();
    if (codigo.length() > Constantes.TAM_EMAIL_AGENTE) {
        JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_EMAIL_AGENTE, "Error", JOptionPane.ERROR_MESSAGE);
        tmail.setText(codigo.substring(0, Constantes.TAM_EMAIL_AGENTE));
    }
}//GEN-LAST:event_tmailKeyReleased

private void tpaisKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tpaisKeyReleased
    String codigo = tpais.getText();
    if (codigo.length() > Constantes.TAM_PAIS_AGENTE) {
        JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_PAIS_AGENTE, "Error", JOptionPane.ERROR_MESSAGE);
        tpais.setText(codigo.substring(0, Constantes.TAM_PAIS_AGENTE));
    }
}//GEN-LAST:event_tpaisKeyReleased

private void ttlf2KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_ttlf2KeyReleased
    int tamaño = ttlf2.getText().length();
    if (tamaño > 0) {
        char c = ttlf2.getText().charAt(tamaño - 1);
        if (!(c >= '0' && c <= '9')) {
            String str = ttlf2.getText().substring(0, tamaño - 1);
            ttlf2.setText(str);
        }
    }
}//GEN-LAST:event_ttlf2KeyReleased

private void ttlf3KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_ttlf3KeyReleased
    int tamaño = ttlf3.getText().length();
    if (tamaño > 0) {
        char c = ttlf3.getText().charAt(tamaño - 1);
        if (!(c >= '0' && c <= '9')) {
            String str = ttlf3.getText().substring(0, tamaño - 1);
            ttlf3.setText(str);
        }
    }
}//GEN-LAST:event_ttlf3KeyReleased

private void tfaxKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tfaxKeyReleased
    int tamaño = tfax.getText().length();
    if (tamaño > 0) {
        char c = tfax.getText().charAt(tamaño - 1);
        if (!(c >= '0' && c <= '9')) {
            String str = tfax.getText().substring(0, tamaño - 1);
            tfax.setText(str);
        }
    }
}//GEN-LAST:event_tfaxKeyReleased

private void tcpKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tcpKeyReleased
    String poblacion = tcp.getText();
    if (poblacion.length() > Constantes.TAM_CP) {
        JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_CP, "Error", JOptionPane.ERROR_MESSAGE);
        tcp.setText(poblacion.substring(0, Constantes.TAM_CP));
    }

    //Establecer misma dirección fiscal
    if (cFiscal.isSelected()) {
        tcpFiscal.setText(tcp.getText());
    }

}//GEN-LAST:event_tcpKeyReleased

private void tdireccionKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tdireccionKeyReleased
    String codigo = tdireccion.getText();
    if (codigo.length() > Constantes.TAM_DIRECCION_AGENTE) {
        JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_DIRECCION_AGENTE, "Error", JOptionPane.ERROR_MESSAGE);
        tdireccion.setText(codigo.substring(0, Constantes.TAM_DIRECCION_AGENTE));
    }

    //Establecer misma dirección fiscal
    if (cFiscal.isSelected()) {
        tdireccionFiscal.setText(tdireccion.getText());
    }

}//GEN-LAST:event_tdireccionKeyReleased

private void tnombrecomercialKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tnombrecomercialKeyReleased
    String codigo = tnombrecomercial.getText();
    if (codigo.length() > Constantes.TAM_NOMBRE_COMERCIAL_AGENTE) {
        JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_NOMBRE_COMERCIAL_AGENTE, "Error", JOptionPane.ERROR_MESSAGE);
        tnombrecomercial.setText(codigo.substring(0, Constantes.TAM_NOMBRE_COMERCIAL_AGENTE));
    }
}//GEN-LAST:event_tnombrecomercialKeyReleased

private void ttlfKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_ttlfKeyReleased
    int tamaño = ttlf.getText().length();
    if (tamaño > 0) {
        char c = ttlf.getText().charAt(tamaño - 1);
        if (!(c >= '0' && c <= '9')) {
            String str = ttlf.getText().substring(0, tamaño - 1);
            ttlf.setText(str);
        }
    }
}//GEN-LAST:event_ttlfKeyReleased

private void tnombreFiscalKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tnombreFiscalKeyReleased
    String codigo = tnombreFiscal.getText();
    if (codigo.length() > Constantes.TAM_NOMBRE_FISCAL_AGENTE) {
        JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_NOMBRE_FISCAL_AGENTE, "Error", JOptionPane.ERROR_MESSAGE);
        tnombreFiscal.setText(codigo.substring(0, Constantes.TAM_NOMBRE_FISCAL_AGENTE));
    }
}//GEN-LAST:event_tnombreFiscalKeyReleased

private void tpoblacionKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tpoblacionKeyReleased
    String codigo = tpoblacion.getText();
    if (codigo.length() > Constantes.TAM_POBLACION_AGENTE) {
        JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_POBLACION_AGENTE, "Error", JOptionPane.ERROR_MESSAGE);
        tpoblacion.setText(codigo.substring(0, Constantes.TAM_POBLACION_AGENTE));
    }

    //Establecer misma dirección fiscal
    if (cFiscal.isSelected()) {
        tpoblacionFiscal.setText(tpoblacion.getText());
    }

}//GEN-LAST:event_tpoblacionKeyReleased

private void cFiscalStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_cFiscalStateChanged
//  Establecer misma dirección fiscal
    if (cFiscal.isSelected()) {
        tprovinciaFiscal.setText(tprovincia.getText());
        tpoblacionFiscal.setText(tpoblacion.getText());
        tdireccionFiscal.setText(tdireccion.getText());
        tcpFiscal.setText(tcp.getText());
    }
}//GEN-LAST:event_cFiscalStateChanged

private void tpoblacionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tpoblacionActionPerformed
    String codigo = tpoblacion.getText();
    if (codigo.length() > Constantes.TAM_POBLACION_FISCAL_AGENTE) {
        JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_POBLACION_FISCAL_AGENTE, "Error", JOptionPane.ERROR_MESSAGE);
        tpoblacion.setText(codigo.substring(0, Constantes.TAM_POBLACION_FISCAL_AGENTE));
    }
}//GEN-LAST:event_tpoblacionActionPerformed

private void tprovinciaFiscalKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tprovinciaFiscalKeyReleased
    String codigo = tprovincia.getText();
    if (codigo.length() > Constantes.TAM_PROVINCIA_FISCAL_AGENTE) {
        JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_PROVINCIA_FISCAL_AGENTE, "Error", JOptionPane.ERROR_MESSAGE);
        tprovincia.setText(codigo.substring(0, Constantes.TAM_PROVINCIA_FISCAL_AGENTE));
    }
}//GEN-LAST:event_tprovinciaFiscalKeyReleased

private void tpoblacionFiscalKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tpoblacionFiscalKeyReleased
    String codigo = tpoblacion.getText();
    if (codigo.length() > Constantes.TAM_POBLACION_FISCAL_AGENTE) {
        JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_POBLACION_FISCAL_AGENTE, "Error", JOptionPane.ERROR_MESSAGE);
        tpoblacion.setText(codigo.substring(0, Constantes.TAM_POBLACION_FISCAL_AGENTE));
    }
}//GEN-LAST:event_tpoblacionFiscalKeyReleased

private void tdireccionFiscalKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tdireccionFiscalKeyReleased
    String codigo = tdireccionFiscal.getText();
    if (codigo.length() > Constantes.TAM_DIRECCION_FISCAL_AGENTE) {
        JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_DIRECCION_FISCAL_AGENTE, "Error", JOptionPane.ERROR_MESSAGE);
        tdireccionFiscal.setText(codigo.substring(0, Constantes.TAM_DIRECCION_FISCAL_AGENTE));
    }
}//GEN-LAST:event_tdireccionFiscalKeyReleased

private void tcpFiscalKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tcpFiscalKeyReleased
    String codigo = tcpFiscal.getText();
    if (codigo.length() > Constantes.TAM_CP_FISCAL_AGENTE) {
        JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_CP_FISCAL_AGENTE, "Error", JOptionPane.ERROR_MESSAGE);
        tcpFiscal.setText(codigo.substring(0, Constantes.TAM_CP_FISCAL_AGENTE));
    }
}//GEN-LAST:event_tcpFiscalKeyReleased

    private void tSwiftKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tSwiftKeyReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_tSwiftKeyReleased

    private void tForArticulosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tForArticulosMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_tForArticulosMouseClicked

    private void tForArticulosKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tForArticulosKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_tForArticulosKeyPressed

    private void bAnadirForArticuloActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bAnadirForArticuloActionPerformed
        NuevoForArticulo nda = new NuevoForArticulo(this, "Formula Artículo - Creación", e);
        nda.setDefaultCloseOperation(NuevoForArticulo.DISPOSE_ON_CLOSE);
        nda.setLocationRelativeTo(null);
        nda.setVisible(true);
    }//GEN-LAST:event_bAnadirForArticuloActionPerformed

    private void bModificarForArticuloActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bModificarForArticuloActionPerformed
            visualizarFormulaArticulo();
    }//GEN-LAST:event_bModificarForArticuloActionPerformed

    private void bEliminarForArticuloActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bEliminarForArticuloActionPerformed
        borrarForArticulo();
    }//GEN-LAST:event_bEliminarForArticuloActionPerformed

    private void tForFamiliaVentaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tForFamiliaVentaMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_tForFamiliaVentaMouseClicked

    private void tForFamiliaVentaKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tForFamiliaVentaKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_tForFamiliaVentaKeyPressed

    private void bAnadirForFamiliaVentaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bAnadirForFamiliaVentaActionPerformed
        NuevoForFamilia nda = new NuevoForFamilia(this, "Formula Familia - Creación", e);
        nda.setDefaultCloseOperation(NuevoForArticulo.DISPOSE_ON_CLOSE);
        nda.setLocationRelativeTo(null);
        nda.setVisible(true);
    }//GEN-LAST:event_bAnadirForFamiliaVentaActionPerformed

    private void bModificarForFamiliaVentaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bModificarForFamiliaVentaActionPerformed
        visualizarFormulaFamilia();
    }//GEN-LAST:event_bModificarForFamiliaVentaActionPerformed

    private void BorrarForFamiliaVentaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BorrarForFamiliaVentaActionPerformed
        borrarForFamilia();

    }//GEN-LAST:event_BorrarForFamiliaVentaActionPerformed

    private void cerrarCliente() {
        removeAll();
        dispose();
    }

    private void visualizarContacto() {
        indiceFila = tcontactos.getSelectedRow();
        if (indiceFila >= 0) {
            Contactos c;
            Integer iid = (Integer) tcontactos.getModel().getValueAt(indiceFila, 6);
            if (iid != null) {
                c = BaseDatos.getContactoIid(iid);
            } else {
                String nombreYApellidos = (String) tcontactos.getModel().getValueAt(indiceFila, 0);
                c = obtenerContactoPorNombreApellidos(nombreYApellidos);
            }

            NuevoContacto nc = new NuevoContacto(a, this, true, c, indiceFila);
            nc.setDefaultCloseOperation(NuevaNotaDocumento.DISPOSE_ON_CLOSE);
            nc.setLocationRelativeTo(null);
            nc.setVisible(true);
            nc = null;
        }
    }

    private Contactos obtenerContactoPorNombreApellidos(String nombreYApellidos) {
        Contactos res = null;

        boolean seguir = true;
        Iterator iter = this.listacontactos.iterator();
        Contactos c;
        while (seguir && iter.hasNext()) {
            c = (Contactos) iter.next();
            if ((c.getNombre() + " " + c.getApellidos()).equals(nombreYApellidos)) {
                seguir = false;
                res = c;
            }
        }

        return res;
    }

    private void borrarContacto() {
        indiceFila = tcontactos.getSelectedRow();
        if (indiceFila >= 0) {
            Integer eliminar = JOptionPane.showConfirmDialog(null, "Está seguro de que desea eliminar el contacto?", "¿Borrar contacto?", JOptionPane.YES_NO_OPTION);
            //hacerCambios = -1 ==> se ha pulsado la "x" de cancelar;
            //hacerCambios =  0 ==> se ha pulsado el "sí"
            //hacerCambios =  1 ==> se ha pulsado el "no"
            if (eliminar == 0) {
                listacontactos.remove(indiceFila);
                this.actualizarContactos();
            }
        }
    }

    private void borrarDtoArticulo() {
        int indiceFilaDto = this.tDtoArticulos.getSelectedRow();
        if (indiceFilaDto >= 0) {
            String codigoArticulo = (String) tDtoArticulos.getModel().getValueAt(indiceFilaDto, 0);
            DescuentoClienteArticulo dca = null;
            int indiceDca = buscarDescuentoClienteArticulo(codigoArticulo);
            this.listaDescuentoClienteArticulos.remove(indiceDca);
            this.actualizarListaDescuentoArticulos();
            cambios = true;
        } else {
            JOptionPane.showMessageDialog(null, "No hay ningún elemento seleccionado", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void borrarForArticulo() {
        int indiceFilaDto = this.tForArticulos.getSelectedRow();
        if (indiceFilaDto >= 0) {
            String codigoArticulo = (String) tForArticulos.getModel().getValueAt(indiceFilaDto, 0);

            int indiceFap = buscarFormulaArticulo(codigoArticulo);
            this.listaFormulaArticulo.remove(indiceFap);
            this.actualizarListaFormulaArticulos();
            cambios = true;
        } else {
            JOptionPane.showMessageDialog(null, "No hay ningún elemento seleccionado", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void borrarDtoFamilia() {
        int indiceFilaDto = this.tDtoFamiliaVenta.getSelectedRow();
        if (indiceFilaDto >= 0) {
            String codigoFamilia = (String) tDtoFamiliaVenta.getModel().getValueAt(indiceFilaDto, 0);
            DescuentoClienteFamiliaVenta dcfv = null;
            int indiceDcfv = buscarDescuentoClienteFamiliaVenta(codigoFamilia);
            this.listaFormulaFamilia.remove(indiceDcfv);
            this.actualizarListaDescuentoFamiliaVentas();
            cambios = true;
        } else {
            JOptionPane.showMessageDialog(null, "No hay ningún elemento seleccionado", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void borrarForFamilia() {
        int indiceFilaDto = this.tForFamiliaVenta.getSelectedRow();
        if (indiceFilaDto >= 0) {
            String codigoFamilia = (String) tForFamiliaVenta.getModel().getValueAt(indiceFilaDto, 0);

            int indiceDcfv = buscarFormulaFamiliaVenta(codigoFamilia);
            this.listaFormulaFamilia.remove(indiceDcfv);
            this.actualizarListaFormulaFamilia();
            cambios = true;
        } else {
            JOptionPane.showMessageDialog(null, "No hay ningún elemento seleccionado", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BorrarForFamiliaVenta;
    private javax.swing.JButton bAnadirDtoArticulo;
    private javax.swing.JButton bAnadirDtoFamiliaVenta;
    private javax.swing.JButton bAnadirForArticulo;
    private javax.swing.JButton bAnadirForFamiliaVenta;
    private javax.swing.JButton bAnadirNotaDocumento;
    private javax.swing.JButton bAnadirPersona;
    private javax.swing.JButton bEliminarDtoArticulo;
    private javax.swing.JButton bEliminarDtoFamiliaVenta;
    private javax.swing.JButton bEliminarForArticulo;
    private javax.swing.JButton bEliminarPersona;
    private javax.swing.JButton bModificarDtoArticulo;
    private javax.swing.JButton bModificarDtoFamiliaVenta;
    private javax.swing.JButton bModificarForArticulo;
    private javax.swing.JButton bModificarForFamiliaVenta;
    private javax.swing.JButton bModificarPersona;
    private javax.swing.JButton baceptar;
    private javax.swing.JButton bcancelar;
    private javax.swing.JButton bmodificar;
    private javax.swing.JComboBox cContacto;
    private javax.swing.JComboBox cDiaCobro1;
    private javax.swing.JComboBox cDiaCobro2;
    private javax.swing.JComboBox cDiaCobro3;
    private javax.swing.JCheckBox cFiscal;
    private javax.swing.JComboBox cFormaPago;
    private javax.swing.JComboBox cIva;
    private javax.swing.JCheckBox cTerceros;
    private javax.swing.JCheckBox cbExentoIva;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane8;
    private javax.swing.JScrollPane jScrollPane9;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JLabel lContacto;
    private javax.swing.JLabel lDiaCobro;
    private javax.swing.JLabel lFormaPago;
    private javax.swing.JLabel lIva;
    private javax.swing.JLabel lcif;
    private javax.swing.JLabel lcodigo;
    private javax.swing.JLabel lcp;
    private javax.swing.JLabel lcp1;
    private javax.swing.JLabel lcp2;
    private javax.swing.JLabel lcp3;
    private javax.swing.JLabel ldireccion;
    private javax.swing.JLabel ldireccion1;
    private javax.swing.JLabel ldireccion2;
    private javax.swing.JLabel lfax;
    private javax.swing.JLabel lmail;
    private javax.swing.JLabel lnombrecomercial;
    private javax.swing.JLabel lnombrefiscal;
    private javax.swing.JLabel lpais;
    private javax.swing.JLabel lpoblacion;
    private javax.swing.JLabel lpoblacion1;
    private javax.swing.JLabel lpoblacion2;
    private javax.swing.JLabel lpoblacion3;
    private javax.swing.JLabel lprovincia;
    private javax.swing.JLabel lprovincia1;
    private javax.swing.JLabel ltelefono;
    private javax.swing.JLabel ltelefono2;
    private javax.swing.JLabel ltelefono3;
    private javax.swing.JPanel pDescuentoClienteArticulo;
    private javax.swing.JPanel pDescuentoClienteArticulo1;
    private javax.swing.JPanel pDescuentoClienteFamiliaVenta;
    private javax.swing.JPanel pDescuentoClienteFamiliaVenta1;
    private javax.swing.JPanel pLista;
    private javax.swing.JPanel pLista1;
    private javax.swing.JTextField tCif;
    private javax.swing.JTable tDtoArticulos;
    private javax.swing.JTable tDtoFamiliaVenta;
    private javax.swing.JTextField tEntidad;
    private javax.swing.JTable tForArticulos;
    private javax.swing.JTable tForFamiliaVenta;
    private javax.swing.JTextArea tObservaciones;
    private javax.swing.JTable tPresupuestos;
    private javax.swing.JTextField tSwift;
    private javax.swing.JTextField tcodigo;
    private javax.swing.JTable tcontactos;
    private javax.swing.JTextField tcp;
    private javax.swing.JTextField tcpFiscal;
    private javax.swing.JTextField tcpent;
    private javax.swing.JTextField tcuenta;
    private javax.swing.JTextField tdireccion;
    private javax.swing.JTextField tdireccionFiscal;
    private javax.swing.JTextField tdirecent;
    private javax.swing.JTextField tfax;
    private javax.swing.JTextField tmail;
    private javax.swing.JTextField tnombreFiscal;
    private javax.swing.JTextField tnombrecomercial;
    private javax.swing.JTextField tpais;
    private javax.swing.JTextField tpoblacion;
    private javax.swing.JTextField tpoblacionFiscal;
    private javax.swing.JTextField tpoblacionent;
    private javax.swing.JTextField tprovincia;
    private javax.swing.JTextField tprovinciaFiscal;
    private javax.swing.JTextField tprovinciaent;
    private javax.swing.JTextField ttlf;
    private javax.swing.JTextField ttlf2;
    private javax.swing.JTextField ttlf3;
    // End of variables declaration//GEN-END:variables

    private boolean hayCambios() {
        return !tcodigo.getText().equals(codigoAntiguo)
                || !tnombrecomercial.getText().equals(nombreComercialAntiguo)
                || !tnombreFiscal.getText().equals(nombreFiscalAntiguo)
                || !tCif.getText().equals(cifAntiguo)
                || !tpais.getText().equals(paisAntiguo)
                || !tprovincia.getText().equals(provinciaAntigua)
                || !tpoblacion.getText().equals(poblacionAntigua)
                || !tdireccion.getText().equals(direccionAntigua)
                || !tcp.getText().equals(cpAntiguo)
                || !tprovinciaFiscal.getText().equals(provinciaFiscalAntigua)
                || !tpoblacionFiscal.getText().equals(poblacionFiscalAntigua)
                || !tdireccionFiscal.getText().equals(direccionFiscalAntigua)
                || !tcpFiscal.getText().equals(cpFiscalAntiguo)
                || !ttlf.getText().equals(tlfAntiguo)
                || !ttlf2.getText().equals(tlf2Antiguo)
                || !ttlf2.getText().equals(tlf3Antiguo)
                || !tfax.getText().equals(faxAntiguo)
                || !tmail.getText().equals(mailAntiguo)
                || !tObservaciones.getText().equals(observacionesAntigua)
                || !tEntidad.getText().equals(nombreEntAntigua)
                || !tdirecent.getText().equals(direccionEntAntigua)
                || !tpoblacionent.getText().equals(poblacionEntAntigua)
                || !tprovinciaent.getText().equals(provinciaEntAntigua)
                || !tcpent.getText().equals(cpEntAntigua)
                || !tcuenta.getText().equals(cuentaEntAntigua)
                || !tcuenta.getText().equals(cuentaEntAntigua)
                || !tSwift.getText().equals(swiftAntiguo)
                || !((String) cFormaPago.getSelectedItem()).equals(formaPagoAntigua)
                || !((String) cIva.getSelectedItem()).equals(ivaAntiguo)
                || !((String) cContacto.getSelectedItem()).equals(contactoAntiguo)
                || !exentoIvaAntiguo == cbExentoIva.isSelected()
                || !terceroAntiguo == cTerceros.isSelected()
                || !((String) cDiaCobro1.getSelectedItem()).equals(diaCobro1Antiguo)
                || !((String) cDiaCobro2.getSelectedItem()).equals(diaCobro2Antiguo)
                || !((String) cDiaCobro3.getSelectedItem()).equals(diaCobro3Antiguo)
                || cambios;
    }

    public boolean insertarContacto(Contactos c) {
        boolean res = true;
        if (!listacontactos.contains(c)) {
            listacontactos.add(c);
            actualizarContactos();
        } else {
            res = false;
            JOptionPane.showMessageDialog(null, "El contacto ya existe", "Error", JOptionPane.ERROR_MESSAGE);
        }
        return res;
    }

    private int buscarDescuentoClienteArticulo(String codigoArticulo) {
        int res = -1;
        int contador = 0;
        boolean seguir = true;

        if (this.listaDescuentoClienteArticulos == null) {
            this.listaDescuentoClienteArticulos = new ArrayList();
        }

        DescuentoClienteArticulo dca = null;
        Iterator iter = listaDescuentoClienteArticulos.iterator();
        Articulo artTemp;
        while (seguir && iter.hasNext()) {
            dca = (DescuentoClienteArticulo) iter.next();
            artTemp = BaseDatos.obtenerArticuloPorIid(dca.getArticulo().getIid());
            if (codigoArticulo.equals(artTemp.getCod_articulo())) {
                seguir = false;
                res = contador;
            } else {
                contador++;
            }
        }

        return res;
    }

    private int buscarFormulaArticulo(String codigoArticulo) {
        int res = -1;
        int contador = 0;
        boolean seguir = true;

        if (this.listaFormulaArticulo == null) {
            this.listaFormulaArticulo = new ArrayList();
        }

        FormulaArticuloProv dca = null;
        Iterator iter = listaFormulaArticulo.iterator();
        Articulo artTemp;
        while (seguir && iter.hasNext()) {
            dca = (FormulaArticuloProv) iter.next();
            artTemp = BaseDatos.obtenerArticuloPorIid(dca.getIidArticulo());
            if (codigoArticulo.equals(artTemp.getCod_articulo())) {
                seguir = false;
                res = contador;
            } else {
                contador++;
            }
        }

        return res;
    }

    private int buscarDescuentoClienteFamiliaVenta(String codigoFamilia) {
        int res = -1;
        int contador = 0;
        boolean seguir = true;

        if (this.listaDescuentoClienteFamiliaVentas == null) {
            this.listaDescuentoClienteFamiliaVentas = new ArrayList();
        }

        DescuentoClienteFamiliaVenta dcfv = null;
        Iterator iter = listaDescuentoClienteFamiliaVentas.iterator();
        FamiliaVenta fvTemp;
        while (seguir && iter.hasNext()) {
            dcfv = (DescuentoClienteFamiliaVenta) iter.next();
            fvTemp = BaseDatos.obtenerFamiliaVentaPorIid(dcfv.getFamiliaVenta().getIid());
            if (codigoFamilia.equals(fvTemp.getCod_familia())) {
                seguir = false;
                res = contador;
            } else {
                contador++;
            }
        }

        return res;
    }

    private int buscarFormulaFamiliaVenta(String codigoFamilia) {
        int res = -1;
        int contador = 0;
        boolean seguir = true;

        if (this.listaFormulaFamilia == null) {
            this.listaFormulaFamilia = new ArrayList();
        }

        FormulaFamiliaProv dcfv = null;
        Iterator iter = listaFormulaFamilia.iterator();
        FamiliaVenta fvTemp;
        while (seguir && iter.hasNext()) {
            dcfv = (FormulaFamiliaProv) iter.next();
            fvTemp = BaseDatos.obtenerFamiliaVentaPorIid(dcfv.getIidFamilia());
            if (codigoFamilia.equals(fvTemp.getCod_familia())) {
                seguir = false;
                res = contador;
            } else {
                contador++;
            }
        }

        return res;
    }

    public boolean modificarContacto(Contactos c, int indiceContactoAntiguo) {
        boolean res = true;
        listacontactos.remove(indiceContactoAntiguo);
        listacontactos.add(indiceContactoAntiguo, c);
        actualizarContactos();
        return res;
    }

    public void actualizarContactos() {
        Modelo modelo = (Modelo) tcontactos.getModel();
        int i, j;

        cambios = true;

        //obtenemos el nº de filas;
        j = modelo.getRowCount();

        //eliminamos todas las filas
        for (i = 0; i < j; i++) {
            modelo.removeRow(0);
        }

        Contactos c;
        for (Iterator it = listacontactos.iterator(); it.hasNext();) {
            Object[] filac = new Object[7];
            c = (Contactos) it.next();

            filac[0] = c.getNombre() + " " + c.getApellidos();
            filac[1] = c.getTelefono();
            filac[2] = c.getMovil();
            filac[3] = c.getEmail();
            filac[4] = c.getCargo();
            filac[5] = c.getDepartamento();
            filac[6] = c.getIid();

            modelo.addRow(filac);
        }

    }

    public boolean modificarDtoArticulo(NuevoDtoArticulo nda) {
        boolean res = true;

        int indiceModificar = 0;
        Iterator it = listaDescuentoClienteArticulos.iterator();
        boolean seguir = true;
        DescuentoClienteArticulo dca;
        Articulo artTemp;
        while (seguir && it.hasNext()) {
            dca = (DescuentoClienteArticulo) it.next();
            artTemp = dca.getArticulo();
            if (artTemp.getIid() != null) {
                dca.setArticulo(BaseDatos.obtenerArticuloPorIid(artTemp.getIid()));
            }
            if (dca.getArticulo().getCod_articulo().equals(nda.getCodigoArticuloAntiguo())) {
                seguir = false;
            } else {
                indiceModificar++;
            }
        }

        listaDescuentoClienteArticulos.remove(indiceModificar);
        dca = new DescuentoClienteArticulo();
        dca.setArticulo(nda.getArticulo());
        dca.setDescuento(new Double(nda.getDescuento()));
        listaDescuentoClienteArticulos.add(indiceModificar, dca);
        actualizarListaDescuentoArticulos();
        cambios = true;

        return res;
    }

    public boolean modificarForArticulo(NuevoForArticulo nda) {
        boolean res = true;

        int indiceModificar = 0;
        Iterator it = listaFormulaArticulo.iterator();
        boolean seguir = true;
        FormulaArticuloProv dca;
        Articulo artTemp;
        while (seguir && it.hasNext()) {
            dca = (FormulaArticuloProv) it.next();
            artTemp = BaseDatos.obtenerArticuloPorIid(dca.getIidArticulo());

            if (artTemp.getCod_articulo().equals(nda.getCodigoArticuloAntiguo())) {
                seguir = false;
            } else {
                indiceModificar++;
            }
        }

        listaFormulaArticulo.remove(indiceModificar);
        dca = new FormulaArticuloProv();
        dca.setIidArticulo(nda.getArticulo().getIid());
        dca.setFormula(nda.getFormula());
        dca.setIidEmpresa(e.getIid());

        listaFormulaArticulo.add(indiceModificar, dca);
        actualizarListaDescuentoArticulos();
        cambios = true;

        return res;
    }

    public boolean modificarForFamilia(NuevoForFamilia nfa) {
        boolean res = true;

        int indiceModificar = 0;
        Iterator it = listaFormulaFamilia.iterator();
        boolean seguir = true;
        FormulaFamiliaProv dca;
        FamiliaVenta fvTemp;
        while (seguir && it.hasNext()) {
            dca = (FormulaFamiliaProv) it.next();
            fvTemp = BaseDatos.obtenerFamiliaVentaPorIid(dca.getIidFamilia());

            if (fvTemp.getCod_familia().equals(nfa.getCodigoFamiliaAntiguo())) {
                seguir = false;
            } else {
                indiceModificar++;
            }
        }

        listaFormulaFamilia.remove(indiceModificar);
        dca = new FormulaFamiliaProv();
        dca.setIidFamilia(nfa.getFamilia().getIid());
        dca.setFormula(nfa.getFormula());
        dca.setIidEmpresa(e.getIid());

        listaFormulaFamilia.add(indiceModificar, dca);
        actualizarListaDescuentoArticulos();
        cambios = true;

        return res;
    }

    public boolean modificarDtoFamiliaVenta(NuevoDtoFamiliaVenta ndfv) {
        boolean res = true;

        int indiceModificar = 0;
        Iterator it = listaDescuentoClienteFamiliaVentas.iterator();
        boolean seguir = true;
        DescuentoClienteFamiliaVenta dcfv;
        FamiliaVenta fvTemp;
        while (seguir && it.hasNext()) {
            dcfv = (DescuentoClienteFamiliaVenta) it.next();
            fvTemp = dcfv.getFamiliaVenta();
            if (fvTemp.getIid() != null) {
                dcfv.setFamiliaVenta(BaseDatos.obtenerFamiliaVentaPorIid(fvTemp.getIid()));
            }
            if (dcfv.getFamiliaVenta().getCod_familia().equals(ndfv.getCodigoFamiliaVentaAntiguo())) {
                seguir = false;
            } else {
                indiceModificar++;
            }
        }

        listaDescuentoClienteFamiliaVentas.remove(indiceModificar);
        dcfv = new DescuentoClienteFamiliaVenta();
        dcfv.setFamiliaVenta(ndfv.getFamiliaVenta());
        dcfv.setDescuento(new Double(ndfv.getDescuento()));
        listaDescuentoClienteFamiliaVentas.add(indiceModificar, dcfv);
        actualizarListaDescuentoFamiliaVentas();
        cambios = true;

        return res;
    }

    public boolean insertarDtoArticulo(NuevoDtoArticulo nda) {
        boolean res = true;

        Iterator it = listaDescuentoClienteArticulos.iterator();
        boolean seguir = true;
        DescuentoClienteArticulo dca;
        Articulo artTemp;
        while (seguir && it.hasNext()) {
            dca = (DescuentoClienteArticulo) it.next();
            artTemp = dca.getArticulo();
            if (artTemp.getIid() != null) {
                dca.setArticulo(BaseDatos.obtenerArticuloPorIid(artTemp.getIid()));
            }
            if (dca.getArticulo().getCod_articulo().equals(nda.getArticulo().getCod_articulo())) {
                seguir = false;
            }
        }

        if (seguir) {
            dca = new DescuentoClienteArticulo();
            dca.setArticulo(nda.getArticulo());
            dca.setDescuento(new Double(nda.getDescuento()));
            listaDescuentoClienteArticulos.add(dca);
            actualizarListaDescuentoArticulos();
            cambios = true;
        } else {
            res = false;
        }

        return res;
    }

    public boolean insertarForArticulo(NuevoForArticulo nda) {
        boolean res = true;

        Iterator it = listaFormulaArticulo.iterator();
        boolean seguir = true;
        FormulaArticuloProv dca;
        Articulo artTemp;
        while (seguir && it.hasNext()) {
            dca = (FormulaArticuloProv) it.next();
            artTemp = BaseDatos.obtenerArticuloPorIid(dca.getIidArticulo());
            if (artTemp.getCod_articulo().equals(nda.getArticulo().getCod_articulo())) {
                seguir = false;
            }
        }

        if (seguir) {
            dca = new FormulaArticuloProv();
            dca.setIidArticulo(nda.getArticulo().getIid());
            dca.setFormula(nda.getFormula());
            dca.setIidEmpresa(e.getIid());
            listaFormulaArticulo.add(dca);
            actualizarListaFormulaArticulos();
            cambios = true;
        } else {
            res = false;
        }

        return res;
    }

    public boolean insertarForFamilia(NuevoForFamilia nfa) {
        boolean res = true;

        Iterator it = listaFormulaFamilia.iterator();
        boolean seguir = true;
        FormulaFamiliaProv dca;
        FamiliaVenta fvTemp;
        while (seguir && it.hasNext()) {
            dca = (FormulaFamiliaProv) it.next();
            fvTemp = BaseDatos.obtenerFamiliaVentaPorIid(dca.getIidFamilia());
            if (fvTemp.getNombre().equals(nfa.getFamilia().getNombre())) {
                seguir = false;
            }
        }

        if (seguir) {
            dca = new FormulaFamiliaProv();
            dca.setIidFamilia(nfa.getFamilia().getIid());
            dca.setFormula(nfa.getFormula());
            dca.setIidEmpresa(e.getIid());
            listaFormulaFamilia.add(dca);
            actualizarListaFormulaFamilia();
            cambios = true;
        } else {
            res = false;
        }

        return res;
    }

    public boolean insertarDtoFamiliaVenta(NuevoDtoFamiliaVenta ndfv) {
        boolean res = true;

        Iterator it = listaDescuentoClienteFamiliaVentas.iterator();
        boolean seguir = true;
        DescuentoClienteFamiliaVenta dcfv;
        FamiliaVenta fvTemp;
        while (seguir && it.hasNext()) {
            dcfv = (DescuentoClienteFamiliaVenta) it.next();
            fvTemp = dcfv.getFamiliaVenta();
            if (fvTemp.getIid() != null) {
                dcfv.setFamiliaVenta(BaseDatos.obtenerFamiliaVentaPorIid(fvTemp.getIid()));
            }
            if (dcfv.getFamiliaVenta().getCod_familia().equals(ndfv.getFamiliaVenta().getCod_familia())) {
                seguir = false;
            }
        }

        if (seguir) {
            dcfv = new DescuentoClienteFamiliaVenta();
            dcfv.setFamiliaVenta(ndfv.getFamiliaVenta());
            dcfv.setDescuento(new Double(ndfv.getDescuento()));
            listaDescuentoClienteFamiliaVentas.add(dcfv);
            actualizarListaFormulaFamilia();
            cambios = true;
        } else {
            res = false;
        }

        return res;
    }

    private void actualizarListaDescuentoFamiliaVentas() {
        Modelo modelo = (Modelo) this.tDtoFamiliaVenta.getModel();
        int i, j;

        //obtenemos el nº de filas;
        j = modelo.getRowCount();

        //eliminamos todas las filas
        for (i = 0; i < j; i++) {
            modelo.removeRow(0);
        }

        DescuentoClienteFamiliaVenta dcfv;
        FamiliaVenta fvTemp;
        for (Iterator it = this.listaDescuentoClienteFamiliaVentas.iterator(); it.hasNext();) {
            Object[] filac = new Object[2];
            dcfv = (DescuentoClienteFamiliaVenta) it.next();
            fvTemp = dcfv.getFamiliaVenta();
            if (fvTemp.getIid() != null) {
                fvTemp = BaseDatos.obtenerFamiliaVentaPorIid(fvTemp.getIid());
            }
            dcfv.setFamiliaVenta(fvTemp);
            filac[0] = dcfv.getFamiliaVenta().getCod_familia();
            filac[1] = Util.convertirPuntoAComa(dcfv.getDescuento().toString());
            modelo.addRow(filac);
        }
    }

    private void actualizarListaFormulaFamilia() {
        Modelo modelo = (Modelo) this.tForFamiliaVenta.getModel();
        int i, j;

        //obtenemos el nº de filas;
        j = modelo.getRowCount();

        //eliminamos todas las filas
        for (i = 0; i < j; i++) {
            modelo.removeRow(0);
        }

        FormulaFamiliaProv dcfv;
        FamiliaVenta fvTemp;
        for (Iterator it = this.listaFormulaFamilia.iterator(); it.hasNext();) {
            Object[] filac = new Object[2];
            dcfv = (FormulaFamiliaProv) it.next();

            if (dcfv.getIidFamilia() != null) {
                fvTemp = BaseDatos.obtenerFamiliaVentaPorIid(dcfv.getIidFamilia());
            } else {
                fvTemp = null;
            }

            filac[0] = fvTemp.getCod_familia();
            filac[1] = Util.convertirPuntoAComa(dcfv.getFormula());
            modelo.addRow(filac);
        }
    }

    private void actualizarListaDescuentoArticulos() {
        Modelo modelo = (Modelo) this.tDtoArticulos.getModel();
        int i, j;

        //obtenemos el nº de filas;
        j = modelo.getRowCount();

        //eliminamos todas las filas
        for (i = 0; i < j; i++) {
            modelo.removeRow(0);
        }

        DescuentoClienteArticulo dca;
        Articulo artTemp;
        for (Iterator it = this.listaDescuentoClienteArticulos.iterator(); it.hasNext();) {
            Object[] filac = new Object[2];
            dca = (DescuentoClienteArticulo) it.next();
            artTemp = dca.getArticulo();
            if (artTemp.getIid() != null) {
                artTemp = BaseDatos.obtenerArticuloPorIid(artTemp.getIid());
            }
            dca.setArticulo(artTemp);
            filac[0] = dca.getArticulo().getCod_articulo();
            filac[1] = Util.convertirPuntoAComa(dca.getDescuento().toString());
            modelo.addRow(filac);
        }
    }

    private void actualizarListaFormulaArticulos() {
        Modelo modelo = (Modelo) this.tForArticulos.getModel();
        int i, j;

        //obtenemos el nº de filas;
        j = modelo.getRowCount();

        //eliminamos todas las filas
        for (i = 0; i < j; i++) {
            modelo.removeRow(0);
        }

        FormulaArticuloProv dca;
        Articulo artTemp;
        for (Iterator it = this.listaFormulaArticulo.iterator(); it.hasNext();) {
            Object[] filac = new Object[2];
            dca = (FormulaArticuloProv) it.next();

            if (dca.getIidArticulo() != null) {
                artTemp = BaseDatos.obtenerArticuloPorIid(dca.getIidArticulo());
            } else {
                artTemp = null;
            }

            filac[0] = artTemp.getCod_articulo();
            filac[1] = Util.convertirPuntoAComa(dca.getFormula());
            modelo.addRow(filac);
        }
    }

    private void visualizarDescuentoClienteFamiliaVenta() {
        int indiceFilaDto = this.tDtoFamiliaVenta.getSelectedRow();

        if (indiceFilaDto >= 0) {
            String codigoFamilia = (String) tDtoFamiliaVenta.getModel().getValueAt(indiceFilaDto, 0);

            DescuentoClienteFamiliaVenta dcfv = null;
            int indiceDcfv = buscarDescuentoClienteFamiliaVenta(codigoFamilia);
            dcfv = this.listaDescuentoClienteFamiliaVentas.get(indiceDcfv);
            dcfv = dcfv.copiar();

            NuevoDtoFamiliaVenta ndfv = new NuevoDtoFamiliaVenta(this, "Descuento Familia Venta - Modificación", e, dcfv);
            ndfv.setDefaultCloseOperation(NuevoDtoFamiliaVenta.DISPOSE_ON_CLOSE);
            ndfv.setLocationRelativeTo(null);
            ndfv.setVisible(true);
        } else {
            JOptionPane.showMessageDialog(null, "No hay ningún elemento seleccionado", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void visualizarFormulaFamilia() {
        int indiceFilaDto = this.tForFamiliaVenta.getSelectedRow();

        if (indiceFilaDto >= 0) {
            String codigoFamilia = (String) tForFamiliaVenta.getModel().getValueAt(indiceFilaDto, 0);

            FormulaFamiliaProv dcfv = null;
            int indiceDcfv = buscarFormulaFamiliaVenta(codigoFamilia);
            dcfv = this.listaFormulaFamilia.get(indiceDcfv);
            //dcfv = dcfv.copiar();

            NuevoForFamilia ndfv = new NuevoForFamilia(this, "Fórmula Familia Venta - Modificación", e, dcfv);
            ndfv.setDefaultCloseOperation(NuevoDtoFamiliaVenta.DISPOSE_ON_CLOSE);
            ndfv.setLocationRelativeTo(null);
            ndfv.setVisible(true);
        } else {
            JOptionPane.showMessageDialog(null, "No hay ningún elemento seleccionado", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }


    private void visualizarDescuentoClienteArticulo() {
        int indiceFilaDto = this.tDtoArticulos.getSelectedRow();

        if (indiceFilaDto >= 0) {
            String codigoArticulo = (String) tDtoArticulos.getModel().getValueAt(indiceFilaDto, 0);

            DescuentoClienteArticulo dca = null;
            int indiceDca = buscarDescuentoClienteArticulo(codigoArticulo);
            dca = this.listaDescuentoClienteArticulos.get(indiceDca);
            dca = dca.copiar();

            NuevoDtoArticulo nda = new NuevoDtoArticulo(this, "Descuento Artículo - Modificación", e, dca);
            nda.setDefaultCloseOperation(NuevoDtoFamiliaVenta.DISPOSE_ON_CLOSE);
            nda.setLocationRelativeTo(null);
            nda.setVisible(true);
        } else {
            JOptionPane.showMessageDialog(null, "No hay ningún elemento seleccionado", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }


        private void visualizarFormulaArticulo() {
        int indiceFilaDto = this.tForArticulos.getSelectedRow();

        if (indiceFilaDto >= 0) {
            String codigoArticulo = (String) tForArticulos.getModel().getValueAt(indiceFilaDto, 0);

            FormulaArticuloProv dca = null;
            int indiceDca = buscarFormulaArticulo(codigoArticulo);
            dca = this.listaFormulaArticulo.get(indiceDca);
            

            NuevoForArticulo nda = new NuevoForArticulo(this, "Formula Artículo - Modificación", e, dca);
            nda.setDefaultCloseOperation(NuevoDtoFamiliaVenta.DISPOSE_ON_CLOSE);
            nda.setLocationRelativeTo(null);
            nda.setVisible(true);
        } else {
            JOptionPane.showMessageDialog(null, "No hay ningún elemento seleccionado", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }


}
