package gui;

import acceso.BaseDatos;
import bean.Agentes;
import bean.Comercial;
import bean.Presupuesto;
import bean.Empresa;
import bean.FormaPago;
import bean.Medicion;
import bean.Metadata;
import bean.Usuario;
import java.net.URL;
import java.util.Iterator;
import java.util.List;
import javax.swing.ImageIcon;
import util.Constantes;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.JComponent;
import javax.swing.JOptionPane;
import javax.swing.KeyStroke;
import org.hibernate.Session;
import util.HibernateUtil;

public class generarDocComercial extends javax.swing.JFrame {
    private List<Presupuesto> lp = new ArrayList<Presupuesto>();
    private Empresa e;
    private Usuario u;
    private Agentes a;
    private Comercial co;
    private Medicion m;
    private boolean crear = false;
    private Date fecha = new Date(); // fecha y hora locales
    private SimpleDateFormat formatoFecha = new SimpleDateFormat("dd/MM/yyyy");

    public generarDocComercial(Empresa e, Usuario u, Medicion me) throws ParseException {
        super("Modificar Documento de Medición");
        this.e = e;
        this.u = u;
        this.m = me;
        initComponents();
        tllamada.setDateFormatString("dd/MM/yyyy");
        tmedicion.setDateFormatString("dd/MM/yyyy");

        if (me.getIidCliente() != null) {
            a = BaseDatos.obtenerAgenteByIid(me.getIidCliente());
            tCodCliente.setText(a.getCod_agente());
        }

        tNombreCliente.setText(me.getNombre());
        tDireccionCliente.setText(me.getDireccion());
        tLocalidadCliente.setText(me.getLocalidad());
        tProvinciaCliente.setText(me.getProvincia());
        tEmailCliente.setText(me.getEmail());
        tTelefonoCliente.setText(me.getTelefono());
        tmovil.setText(me.getMovil());
        tcp.setText(me.getCodigoPostal());
        tDniCliente.setText(me.getDni());
        treferencia.setText(me.getReferencia());

        if (me.getObservaciones() != null) {
            taobservaciones.setText(me.getObservaciones());
        }

        if (me.getLlamada() != null) {
            tllamada.setDate(formatoFecha.parse(me.getLlamada()));
        }

        if (me.getMedicion() != null) {
            tmedicion.setDate(formatoFecha.parse(me.getMedicion()));
        }

        if (me.getHora() != null) {
            thora.setText(me.getHora());
        }

        if (me.getMedidor() != null) {
            lmedidor.setSelectedItem(me.getMedidor());
        }
        if (me.getEstado() != null) {
            lestado.setSelectedItem(me.getEstado());
        }
        if (me.getIidComercial() != null) {
            co = BaseDatos.obtenerComercialPorIid(me.getIidComercial());
            cComercial.setSelectedItem(co.getNombre());
        }
        if (me.getContactado() != null) {
            cContactado.setSelectedItem(me.getContactado());
        }
           
        tnumero.setText(me.getNumero());
        taobservaciones.setText(me.getObservaciones());
        crearAcciones();
    }

    public generarDocComercial(Empresa e, Usuario u) {
        super("Generar Documento de Medición");
        this.e = e;
        this.u = u;
        initComponents();
        crearIconosBotones();
        cComercial.setVisible(false);
        tRecomendadoPor.setVisible(false);
        tmedicion.setDateFormatString("dd/MM/yyyy");
        tllamada.setDateFormatString("dd/MM/yyyy");
        tllamada.setDate(fecha);
        crear = true;
        crearAcciones();
    }

    private Boolean comprobarDatos() {
        //Todos los datos del cliente están informados
        if (tNombreCliente.getText().isEmpty() || tDireccionCliente.getText().isEmpty() || tLocalidadCliente.getText().isEmpty() 
		|| tcp.getText().isEmpty() || tProvinciaCliente.getText().isEmpty() || tmovil.getText().isEmpty()
                || tNombreCliente.getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Los datos del cliente están incompletos", "Faltan datos", JOptionPane.ERROR_MESSAGE);
            return true;
        }
        //Forma de Contacto
        if (cContactado.getSelectedItem() == null) {
            JOptionPane.showMessageDialog(null, "Indique la forma de contacto", "Faltan datos", JOptionPane.ERROR_MESSAGE);
            return true;
        } else if (cContactado.getSelectedItem().equals(Constantes.COMERCIALES) && cComercial.getSelectedItem() == null) {
            JOptionPane.showMessageDialog(null, "Indique un comercial", "Faltan datos", JOptionPane.ERROR_MESSAGE);
            return true;
        } else if (cContactado.getSelectedItem().equals(Constantes.RECOMENDADO) && tRecomendadoPor.getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Indique la persona recomendadora", "Faltan datos", JOptionPane.ERROR_MESSAGE);
            return true;
        }
        //Fecha de Contacto
        if (tllamada.getDate() == null) {
            JOptionPane.showMessageDialog(null, "Indique la fecha de contacto", "Faltan datos", JOptionPane.ERROR_MESSAGE);
            return true;
        }
        if ((lestado.getSelectedItem().equals("Asignado") || lestado.getSelectedItem().equals("Recibido por Medidor")) && (lmedidor.getSelectedItem() == null)) {
            JOptionPane.showMessageDialog(null, "Indique el medidor asignado", "Faltan datos", JOptionPane.ERROR_MESSAGE);
            return true;
        }
        return false;
    }

    private void crearAcciones() {
        KeyStroke escapeKeyStroke = KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false);
        Action escapeAction = new AbstractAction() {
            public void actionPerformed(ActionEvent e) {
                cerrarListaDatosConversion();
            }
        };
        getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(escapeKeyStroke, "ESCAPE");
        getRootPane().getActionMap().put("ESCAPE", escapeAction);
    }

    private void cerrarListaDatosConversion() {
	removeAll();
        dispose();
    }

    private void crearIconosBotones() {
        URL url = getClass().getResource("/iconos/cancelar.gif");
        ImageIcon icono = new ImageIcon(url);
        bcancelar.setIcon(icono);

        url = getClass().getResource("/iconos/guardarYvolver.png");
        icono = new ImageIcon(url);
        baceptar.setIcon(icono);
    }
    
    public void guardarMedicion(Boolean presupuestar) {
        if (!comprobarDatos()) {
            if (m == null) {
                m = new Medicion();
            }

            m.setEmpresa(e);
            m.setNombre(tNombreCliente.getText());
            m.setDireccion(tDireccionCliente.getText());
            m.setProvincia(tProvinciaCliente.getText());
            m.setLocalidad(tLocalidadCliente.getText());
            m.setEmail(tEmailCliente.getText());
            m.setDni(tDniCliente.getText());
            m.setTelefono(tTelefonoCliente.getText());
            m.setMovil(tmovil.getText());
            m.setCodigoPostal(tcp.getText());
            m.setDni(tDniCliente.getText());
            m.setReferencia(treferencia.getText());
            m.setHora(thora.getText());
            m.setObservaciones(taobservaciones.getText());
            m.setContactado((String) cContactado.getSelectedItem());
            m.setEstado(!presupuestar ? (String) lestado.getSelectedItem() : "Presupuestado");
            m.setMedidor((String) lmedidor.getSelectedItem());

            Date fd = tmedicion.getDate();
            m.setMedicion((fd != null) ? formatoFecha.format(fd) : null);

            fd = tllamada.getDate();
            m.setLlamada((fd != null) ? formatoFecha.format(fd) : null);

            if (!tRecomendadoPor.getText().isEmpty()); //Por hacer ;

            if (cContactado.getSelectedItem().equals(Constantes.COMERCIALES)) {
                Comercial c = BaseDatos.obtenerComercialPorNombre((String) cComercial.getSelectedItem());
                m.setIidComercial(c.getIid());
            }

            if (!tCodCliente.getText().isEmpty()) {
                Agentes cod = BaseDatos.obtenerAgentesPorCodigo(tCodCliente.getText(), "cli", e);
                if (cod != null) {
                    m.setIidCliente(cod.getIid());
                }
            }

            if (crear) {
                //Generamos número de documento
                Metadata num = null;
                Metadata anio = null;

                Session session = HibernateUtil.getSessionFactory().getCurrentSession();
                session.beginTransaction();

                List listaMetadataNum = session.createQuery("from Metadata where nombre = 'numMedicion'").list();
                if (listaMetadataNum.size() >= 1) {
                    num = ((Metadata) listaMetadataNum.get(0));
                }

                List listaMetadataAnio = session.createQuery("from Metadata where nombre='anioMedicion'").list();
                if (listaMetadataAnio.size() >= 1) {
                    anio = ((Metadata) listaMetadataAnio.get(0));
                }

                String numDoc = num.getValor();
                int numDocI = Integer.valueOf(numDoc);

                num.setValor(String.valueOf(numDocI + 1));
                String numero = anio.getValor() + "/" + num.getValor();

                session.update(num);

                m.setNumero(numero);

                if (BaseDatos.insertarElemento(m)) {
                    JOptionPane.showMessageDialog(null, "Documento creado correctamente", "Creado", JOptionPane.INFORMATION_MESSAGE);
                    cerrarListaDatosConversion();
                } else {
                    JOptionPane.showMessageDialog(null, "Error al crear documento", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                if (BaseDatos.modificarElemento(m)) {
                    JOptionPane.showMessageDialog(null, "Documento modificado correctamente", "Modificado", JOptionPane.INFORMATION_MESSAGE);
                    cerrarListaDatosConversion();
                } else {
                    JOptionPane.showMessageDialog(null, "Error al modifcar documento", "Error", JOptionPane.ERROR_MESSAGE);

                }
            }
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPopupMenu1 = new javax.swing.JPopupMenu();
        tiposeleccion = new javax.swing.ButtonGroup();
        bcancelar = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        lCliente = new javax.swing.JLabel();
        tCodCliente = new javax.swing.JTextField();
        binsertarCliente = new javax.swing.JButton();
        bVerNotasCliente = new javax.swing.JButton();
        ldni = new javax.swing.JLabel();
        tDniCliente = new javax.swing.JTextField();
        tTelefonoCliente = new javax.swing.JTextField();
        ltelefono = new javax.swing.JLabel();
        tNombreCliente = new javax.swing.JTextField();
        lnombre = new javax.swing.JLabel();
        ldomicilio = new javax.swing.JLabel();
        tDireccionCliente = new javax.swing.JTextField();
        tLocalidadCliente = new javax.swing.JTextField();
        lLocalidad = new javax.swing.JLabel();
        tProvincia = new javax.swing.JLabel();
        tProvinciaCliente = new javax.swing.JTextField();
        lEmailCliente = new javax.swing.JLabel();
        tEmailCliente = new javax.swing.JTextField();
        lcontactado = new javax.swing.JLabel();
        cContactado = new javax.swing.JComboBox();
        cComercial = new javax.swing.JComboBox();
        tRecomendadoPor = new javax.swing.JTextField();
        ltelefono1 = new javax.swing.JLabel();
        tmovil = new javax.swing.JTextField();
        ltelefono2 = new javax.swing.JLabel();
        tcp = new javax.swing.JTextField();
        baceptar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        taobservaciones = new javax.swing.JTextArea();
        jLabel5 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        lnombre1 = new javax.swing.JLabel();
        lCliente1 = new javax.swing.JLabel();
        thora = new javax.swing.JTextField();
        tmedicion = new com.toedter.calendar.JDateChooser();
        lCliente2 = new javax.swing.JLabel();
        lestado = new javax.swing.JComboBox();
        lCliente3 = new javax.swing.JLabel();
        lmedidor = new javax.swing.JComboBox();
        lCliente4 = new javax.swing.JLabel();
        bPresupuesto = new javax.swing.JButton();
        lCliente5 = new javax.swing.JLabel();
        treferencia = new javax.swing.JTextField();
        tllamada = new com.toedter.calendar.JDateChooser();
        lCliente6 = new javax.swing.JLabel();
        tnumero = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        bcancelar.setText("Cerrar");
        bcancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bcancelarActionPerformed(evt);
            }
        });

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder("Información General"));

        lCliente.setFont(new java.awt.Font("Tahoma", 1, 11));
        lCliente.setText("Cliente");

        tCodCliente.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tCodClienteKeyReleased(evt);
            }
        });

        binsertarCliente.setText("...");
        binsertarCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                binsertarClienteActionPerformed(evt);
            }
        });

        bVerNotasCliente.setToolTipText("Ver notas");
        bVerNotasCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bVerNotasClienteActionPerformed(evt);
            }
        });

        ldni.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        ldni.setText("CIF/DNI");

        tTelefonoCliente.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tTelefonoClienteKeyReleased(evt);
            }
        });

        ltelefono.setFont(new java.awt.Font("Tahoma", 1, 11));
        ltelefono.setText("Teléfono");

        tNombreCliente.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tNombreClienteKeyReleased(evt);
            }
        });

        lnombre.setFont(new java.awt.Font("Tahoma", 1, 11));
        lnombre.setText("Nombre");

        ldomicilio.setFont(new java.awt.Font("Tahoma", 1, 11));
        ldomicilio.setText("Domicilio");

        tDireccionCliente.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tDireccionClienteKeyReleased(evt);
            }
        });

        tLocalidadCliente.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tLocalidadClienteKeyReleased(evt);
            }
        });

        lLocalidad.setFont(new java.awt.Font("Tahoma", 1, 11));
        lLocalidad.setText("Localidad");

        tProvincia.setFont(new java.awt.Font("Tahoma", 1, 11));
        tProvincia.setText("Provincia");

        tProvinciaCliente.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tProvinciaClienteKeyReleased(evt);
            }
        });

        lEmailCliente.setFont(new java.awt.Font("Tahoma", 1, 11));
        lEmailCliente.setText("Email");

        tEmailCliente.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tEmailClienteKeyReleased(evt);
            }
        });

        lcontactado.setFont(new java.awt.Font("Tahoma", 1, 11));
        lcontactado.setText("Contactado");

        cContactado.setModel(new javax.swing.DefaultComboBoxModel(new String[] {Constantes.VACIO, Constantes.RECOMENDADO, Constantes.TELEFONO, Constantes.VISITA_OFICINA, Constantes.EMAIL, Constantes.TARJETA, Constantes.COMERCIALES, Constantes.PRESUPUESTO_ONLINE, Constantes.OTROS}));
        cContactado.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cContactadoActionPerformed(evt);
            }
        });

        cComercial.setModel(new javax.swing.DefaultComboBoxModel(new String[] {}));
        cComercial.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cComercialActionPerformed(evt);
            }
        });

        tRecomendadoPor.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tRecomendadoPorKeyReleased(evt);
            }
        });

        ltelefono1.setFont(new java.awt.Font("Tahoma", 1, 11));
        ltelefono1.setText("Móvil");

        tmovil.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tmovilKeyReleased(evt);
            }
        });

        ltelefono2.setFont(new java.awt.Font("Tahoma", 1, 11));
        ltelefono2.setText("Código Postal");

        tcp.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tcpKeyReleased(evt);
            }
        });

        org.jdesktop.layout.GroupLayout jPanel1Layout = new org.jdesktop.layout.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel1Layout.createSequentialGroup()
                .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                    .add(jPanel1Layout.createSequentialGroup()
                        .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(jPanel1Layout.createSequentialGroup()
                                .add(347, 347, 347)
                                .add(ldni))
                            .add(jPanel1Layout.createSequentialGroup()
                                .add(346, 346, 346)
                                .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                                    .add(ltelefono1)
                                    .add(ltelefono, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 58, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))))
                        .add(17, 17, 17))
                    .add(jPanel1Layout.createSequentialGroup()
                        .add(ltelefono2)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)))
                .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(org.jdesktop.layout.GroupLayout.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(tmovil, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 127, Short.MAX_VALUE))
                    .add(org.jdesktop.layout.GroupLayout.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(tcp, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 127, Short.MAX_VALUE))
                    .add(org.jdesktop.layout.GroupLayout.TRAILING, tTelefonoCliente, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 127, Short.MAX_VALUE)
                    .add(tDniCliente, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 127, Short.MAX_VALUE))
                .addContainerGap())
            .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                .add(jPanel1Layout.createSequentialGroup()
                    .addContainerGap()
                    .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                        .add(jPanel1Layout.createSequentialGroup()
                            .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                                .add(ldomicilio)
                                .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                                    .add(lCliente)
                                    .add(lnombre, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 52, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                            .add(13, 13, 13))
                        .add(jPanel1Layout.createSequentialGroup()
                            .add(lLocalidad)
                            .add(14, 14, 14))
                        .add(jPanel1Layout.createSequentialGroup()
                            .add(lEmailCliente)
                            .add(35, 35, 35))
                        .add(lcontactado))
                    .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                    .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                        .add(jPanel1Layout.createSequentialGroup()
                            .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                                .add(org.jdesktop.layout.GroupLayout.LEADING, tEmailCliente)
                                .add(jPanel1Layout.createSequentialGroup()
                                    .add(tLocalidadCliente)
                                    .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                    .add(tProvincia)
                                    .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                    .add(tProvinciaCliente, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 99, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                                .add(org.jdesktop.layout.GroupLayout.LEADING, tNombreCliente)
                                .add(org.jdesktop.layout.GroupLayout.LEADING, jPanel1Layout.createSequentialGroup()
                                    .add(tCodCliente, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 186, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                    .add(binsertarCliente, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 19, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                    .add(bVerNotasCliente, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 28, Short.MAX_VALUE))
                                .add(org.jdesktop.layout.GroupLayout.LEADING, tDireccionCliente))
                            .add(222, 222, 222))
                        .add(jPanel1Layout.createSequentialGroup()
                            .add(cContactado, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 169, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                            .add(cComercial, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 148, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                            .add(tRecomendadoPor)))
                    .addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel1Layout.createSequentialGroup()
                .add(6, 6, 6)
                .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(ldni)
                    .add(tDniCliente, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(ltelefono)
                    .add(tTelefonoCliente, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(ltelefono1)
                    .add(tmovil, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(tcp, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(ltelefono2))
                .addContainerGap(68, Short.MAX_VALUE))
            .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                .add(jPanel1Layout.createSequentialGroup()
                    .add(3, 3, 3)
                    .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                        .add(lCliente)
                        .add(bVerNotasCliente, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 23, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(binsertarCliente)
                        .add(tCodCliente, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                    .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                    .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                        .add(tNombreCliente, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(lnombre))
                    .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                    .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                        .add(tDireccionCliente, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(ldomicilio))
                    .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                    .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                        .add(tProvincia)
                        .add(tProvinciaCliente, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(tLocalidadCliente, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(lLocalidad))
                    .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                    .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                        .add(tEmailCliente, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(lEmailCliente))
                    .add(11, 11, 11)
                    .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                        .add(cComercial, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(tRecomendadoPor, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 19, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(cContactado, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(lcontactado))
                    .addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );

        List lComerciales = BaseDatos.getListaComerciales();
        Comercial comercial;
        cComercial.addItem(Constantes.SELECCIONE_COMERCIAL);
        for (Iterator it = lComerciales.iterator(); it.hasNext();) {
            comercial = (Comercial) it.next();
            cComercial.addItem(comercial.getNombre());
        }

        baceptar.setText("Aceptar");
        baceptar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                baceptarActionPerformed(evt);
            }
        });

        taobservaciones.setColumns(20);
        taobservaciones.setRows(5);
        jScrollPane1.setViewportView(taobservaciones);

        jLabel5.setText("Observaciones:");

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder("Horario de la Medición"));

        lnombre1.setFont(new java.awt.Font("Tahoma", 1, 11));
        lnombre1.setText("Hora");

        lCliente1.setFont(new java.awt.Font("Tahoma", 1, 11));
        lCliente1.setText("Fecha");

        thora.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                thoraActionPerformed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout jPanel2Layout = new org.jdesktop.layout.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(lCliente1)
                    .add(lnombre1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 52, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .add(49, 49, 49)
                .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(tmedicion, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(thora, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 74, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel2Layout.createSequentialGroup()
                .addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                    .add(lCliente1)
                    .add(tmedicion, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(lnombre1)
                    .add(thora, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
        );

        lCliente2.setFont(new java.awt.Font("Tahoma", 1, 11));
        lCliente2.setText("Estado: ");

        lestado.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Planificado", "Asignado", "Recibido por Medidor", "Presupuestado" }));

        lCliente3.setFont(new java.awt.Font("Tahoma", 1, 11));
        lCliente3.setText("Medidor");

        lmedidor.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Sin montaje", "Medidas propias" }));
        List lmontador = BaseDatos.getListaUsuarios();
        Usuario us;

        for (Iterator it1 = lmontador.iterator(); it1.hasNext();) {
            us = (Usuario) it1.next();
            lmedidor.addItem(us.getNombre());
        }

        lCliente4.setFont(new java.awt.Font("Tahoma", 1, 11));
        lCliente4.setText("Fecha de Contacto");

        bPresupuesto.setText("Generar Presupuesto");
        bPresupuesto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bPresupuestoActionPerformed(evt);
            }
        });

        lCliente5.setFont(new java.awt.Font("Tahoma", 1, 11));
        lCliente5.setText("Referencia");

        lCliente6.setFont(new java.awt.Font("Tahoma", 1, 11));
        lCliente6.setText("Código");

        tnumero.setEnabled(false);
        tnumero.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tnumeroActionPerformed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout layout = new org.jdesktop.layout.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(layout.createSequentialGroup()
                .addContainerGap()
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(layout.createSequentialGroup()
                        .add(jPanel1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(bPresupuesto)
                            .add(jPanel2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(layout.createSequentialGroup()
                                .add(lCliente4)
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                .add(tllamada, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                            .add(layout.createSequentialGroup()
                                .add(lCliente3)
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                .add(lmedidor, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 145, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                            .add(layout.createSequentialGroup()
                                .add(lCliente2)
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                .add(lestado, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 145, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))))
                    .add(layout.createSequentialGroup()
                        .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(lCliente5)
                            .add(layout.createSequentialGroup()
                                .add(81, 81, 81)
                                .add(treferencia, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 493, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(lCliente6)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(tnumero, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 74, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                    .add(jLabel5)
                    .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                        .add(layout.createSequentialGroup()
                            .add(baceptar)
                            .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                            .add(bcancelar))
                        .add(jScrollPane1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 786, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(14, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(layout.createSequentialGroup()
                .addContainerGap()
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                        .add(lCliente5)
                        .add(treferencia, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                    .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                        .add(lCliente6)
                        .add(tnumero, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(org.jdesktop.layout.GroupLayout.TRAILING, layout.createSequentialGroup()
                        .add(jLabel5)
                        .add(3, 3, 3))
                    .add(jPanel1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(layout.createSequentialGroup()
                        .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                            .add(tllamada, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(lCliente4))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jPanel2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(lCliente2)
                            .add(lestado, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(lCliente3)
                            .add(lmedidor, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(bPresupuesto)))
                .add(jScrollPane1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 133, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(bcancelar)
                    .add(baceptar))
                .addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

private void bcancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bcancelarActionPerformed
    cerrarListaDatosConversion();
}//GEN-LAST:event_bcancelarActionPerformed

    private void baceptarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_baceptarActionPerformed
        guardarMedicion(false);
    }//GEN-LAST:event_baceptarActionPerformed
    private void tCodClienteKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tCodClienteKeyReleased
    }//GEN-LAST:event_tCodClienteKeyReleased

    private void binsertarClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_binsertarClienteActionPerformed
        ListaDeClientes ldc = new ListaDeClientes(this, e);
        ldc.setDefaultCloseOperation(ListaDeClientes.DISPOSE_ON_CLOSE);
        ldc.setLocationRelativeTo(null);
        ldc.setVisible(true);
    }//GEN-LAST:event_binsertarClienteActionPerformed

    private void bVerNotasClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bVerNotasClienteActionPerformed
        String codigo = tCodCliente.getText(), tipo = "", tipoCompleto = "";
        Agentes ag = BaseDatos.obtenerAgentesPorCodigo(codigo, tipo, e);
        if (ag == null) {
            JOptionPane.showMessageDialog(null, "El " + tipoCompleto + " no está almacenado en la base de datos", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            String obs = ag.getObservaciones();
            if (obs != null && obs.length() != 0) {
                VerNotaCliente vnc = new VerNotaCliente(obs);
                vnc.setDefaultCloseOperation(VerNotaCliente.DISPOSE_ON_CLOSE);
                vnc.setLocationRelativeTo(null);
                vnc.setVisible(true);
            } else {
                JOptionPane.showMessageDialog(null, "El " + tipoCompleto + " no tiene observaciones asociadas", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }//GEN-LAST:event_bVerNotasClienteActionPerformed

    private void tTelefonoClienteKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tTelefonoClienteKeyReleased
        String campo = tTelefonoCliente.getText();
        if (campo.length() > Constantes.TAM_TELEFONO_CLIENTE_PRESUPUESTO) {
            JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_TELEFONO_CLIENTE_PRESUPUESTO, "Error", JOptionPane.ERROR_MESSAGE);
            tTelefonoCliente.setText(campo.substring(0, Constantes.TAM_TELEFONO_CLIENTE_PRESUPUESTO));
        }
    }//GEN-LAST:event_tTelefonoClienteKeyReleased

    private void tNombreClienteKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tNombreClienteKeyReleased
        String campo = tNombreCliente.getText();
        if (campo.length() > Constantes.TAM_NOMBRE_CLIENTE_PRESUPUESTO) {
            JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_NOMBRE_CLIENTE_PRESUPUESTO, "Error", JOptionPane.ERROR_MESSAGE);
            tNombreCliente.setText(campo.substring(0, Constantes.TAM_NOMBRE_CLIENTE_PRESUPUESTO));
        }
    }//GEN-LAST:event_tNombreClienteKeyReleased

    private void tDireccionClienteKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tDireccionClienteKeyReleased
        String campo = tDireccionCliente.getText();
        if (campo.length() > Constantes.TAM_DIRECCION_CLIENTE_PRESUPUESTO) {
            JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_DIRECCION_CLIENTE_PRESUPUESTO, "Error", JOptionPane.ERROR_MESSAGE);
            tDireccionCliente.setText(campo.substring(0, Constantes.TAM_DIRECCION_CLIENTE_PRESUPUESTO));
        }
    }//GEN-LAST:event_tDireccionClienteKeyReleased

    private void tLocalidadClienteKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tLocalidadClienteKeyReleased
        String campo = tLocalidadCliente.getText();
        if (campo.length() > Constantes.TAM_LOCALIDAD_CLIENTE_PRESUPUESTO) {
            JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_LOCALIDAD_CLIENTE_PRESUPUESTO, "Error", JOptionPane.ERROR_MESSAGE);
            tLocalidadCliente.setText(campo.substring(0, Constantes.TAM_LOCALIDAD_CLIENTE_PRESUPUESTO));
        }
    }//GEN-LAST:event_tLocalidadClienteKeyReleased

    private void tProvinciaClienteKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tProvinciaClienteKeyReleased
        String campo = tProvinciaCliente.getText();
        if (campo.length() > Constantes.TAM_PROVINCIA_CLIENTE_PRESUPUESTO) {
            JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_PROVINCIA_CLIENTE_PRESUPUESTO, "Error", JOptionPane.ERROR_MESSAGE);
            tProvinciaCliente.setText(campo.substring(0, Constantes.TAM_PROVINCIA_CLIENTE_PRESUPUESTO));
        }
    }//GEN-LAST:event_tProvinciaClienteKeyReleased

    private void tEmailClienteKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tEmailClienteKeyReleased
        String campo = tEmailCliente.getText();
        if (campo.length() > Constantes.TAM_EMAIL_CLIENTE_PRESUPUESTO) {
            JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_EMAIL_CLIENTE_PRESUPUESTO, "Error", JOptionPane.ERROR_MESSAGE);
            tEmailCliente.setText(campo.substring(0, Constantes.TAM_EMAIL_CLIENTE_PRESUPUESTO));
        }
    }//GEN-LAST:event_tEmailClienteKeyReleased

    private void cContactadoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cContactadoActionPerformed
        String contactado = (String) cContactado.getSelectedItem();
        if (contactado != null && contactado.equals(Constantes.COMERCIALES)) {
            cComercial.setVisible(true);
            tRecomendadoPor.setVisible(false);
        } else if (contactado != null && contactado.equals(Constantes.RECOMENDADO)) {
            tRecomendadoPor.setVisible(true);
            tRecomendadoPor.setText("--Recomendado--");
            tRecomendadoPor.requestFocus();
            cComercial.setVisible(false);
            co = null;
        } else {
            cComercial.setVisible(false);
            co = null;
            tRecomendadoPor.setVisible(false);
        }
        this.validate();
        this.pack();
        this.repaint();
    }//GEN-LAST:event_cContactadoActionPerformed

    private void cComercialActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cComercialActionPerformed
        String nombreComercial = (String) cComercial.getSelectedItem();
        if (!nombreComercial.equals(Constantes.SELECCIONE_COMERCIAL)) {
            co = BaseDatos.obtenerComercialPorNombre(nombreComercial);
        } else {
            co = null;
        }
    }//GEN-LAST:event_cComercialActionPerformed

    protected void rellenarCliente(Agentes cliente) {
        tCodCliente.setText(cliente.getCod_agente());
        tDniCliente.setText(cliente.getCif_nif());
        tNombreCliente.setText(cliente.getNombre_comercial());
        tDireccionCliente.setText(cliente.getDireccion());
        tcp.setText(String.valueOf(cliente.getCodigo_postal()));
        tLocalidadCliente.setText(cliente.getPoblacion());
        tProvinciaCliente.setText(cliente.getProvincia());
        tTelefonoCliente.setText(cliente.getTelefono());
        tmovil.setText(cliente.getTelefono2());
        tEmailCliente.setText(cliente.getEmail());
        //calcularNuevoIva(cliente.getCif_nif());
        FormaPago ffpp = cliente.getFormaPago();

        /* if (ffpp != null && ffpp.getIid() != null) {
         ffpp = BaseDatos.obtenerFormaPagoPorIid(ffpp.getIid());
         cformapago.setSelectedItem(ffpp.getCodigo());
         }*/
    }

    private void tRecomendadoPorKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tRecomendadoPorKeyReleased
        String campo = tRecomendadoPor.getText();
        if (campo.length() > Constantes.TAM_RECOMENDADO_POR) {
            JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_RECOMENDADO_POR, "Error", JOptionPane.ERROR_MESSAGE);
            tRecomendadoPor.setText(campo.substring(0, Constantes.TAM_RECOMENDADO_POR));
        }
    }//GEN-LAST:event_tRecomendadoPorKeyReleased

    private void thoraActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_thoraActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_thoraActionPerformed

    private void tmovilKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tmovilKeyReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_tmovilKeyReleased

    private void tcpKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tcpKeyReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_tcpKeyReleased

    private void bPresupuestoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bPresupuestoActionPerformed
        //Generar Presupuesto a partir de la medición
        int result = JOptionPane.showConfirmDialog(this, "¿Desea generar el presupuesto?", "Generar Presupuesto", JOptionPane.YES_NO_CANCEL_OPTION);
        switch (result) {
            case JOptionPane.YES_OPTION:
                guardarMedicion(true);
                NuevoPresupuesto np = new NuevoPresupuesto(e, u, m);
                np.setDefaultCloseOperation(NuevoPresupuesto.DISPOSE_ON_CLOSE);
                np.setLocationRelativeTo(null);
                np.setVisible(true);
                return;
            case JOptionPane.NO_OPTION:
                return;
            case JOptionPane.CANCEL_OPTION:
                cancelSelection:
                return;
        }
    }//GEN-LAST:event_bPresupuestoActionPerformed

    private void tnumeroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tnumeroActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tnumeroActionPerformed
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bPresupuesto;
    private javax.swing.JButton bVerNotasCliente;
    private javax.swing.JButton baceptar;
    private javax.swing.JButton bcancelar;
    private javax.swing.JButton binsertarCliente;
    private javax.swing.JComboBox cComercial;
    private javax.swing.JComboBox cContactado;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPopupMenu jPopupMenu1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lCliente;
    private javax.swing.JLabel lCliente1;
    private javax.swing.JLabel lCliente2;
    private javax.swing.JLabel lCliente3;
    private javax.swing.JLabel lCliente4;
    private javax.swing.JLabel lCliente5;
    private javax.swing.JLabel lCliente6;
    private javax.swing.JLabel lEmailCliente;
    private javax.swing.JLabel lLocalidad;
    private javax.swing.JLabel lcontactado;
    private javax.swing.JLabel ldni;
    private javax.swing.JLabel ldomicilio;
    private javax.swing.JComboBox lestado;
    private javax.swing.JComboBox lmedidor;
    private javax.swing.JLabel lnombre;
    private javax.swing.JLabel lnombre1;
    private javax.swing.JLabel ltelefono;
    private javax.swing.JLabel ltelefono1;
    private javax.swing.JLabel ltelefono2;
    private javax.swing.JTextField tCodCliente;
    private javax.swing.JTextField tDireccionCliente;
    private javax.swing.JTextField tDniCliente;
    private javax.swing.JTextField tEmailCliente;
    private javax.swing.JTextField tLocalidadCliente;
    private javax.swing.JTextField tNombreCliente;
    private javax.swing.JLabel tProvincia;
    private javax.swing.JTextField tProvinciaCliente;
    private javax.swing.JTextField tRecomendadoPor;
    private javax.swing.JTextField tTelefonoCliente;
    private javax.swing.JTextArea taobservaciones;
    private javax.swing.JTextField tcp;
    private javax.swing.JTextField thora;
    private javax.swing.ButtonGroup tiposeleccion;
    private com.toedter.calendar.JDateChooser tllamada;
    private com.toedter.calendar.JDateChooser tmedicion;
    private javax.swing.JTextField tmovil;
    private javax.swing.JTextField tnumero;
    private javax.swing.JTextField treferencia;
    // End of variables declaration//GEN-END:variables
}
