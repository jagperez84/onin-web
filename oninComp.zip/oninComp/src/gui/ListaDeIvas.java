package gui;

import acceso.*;
import modelo.*;
import bean.Iva;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JOptionPane;
import javax.swing.KeyStroke;
import util.Util;

public class ListaDeIvas extends javax.swing.JFrame {

    public ListaDeIvas() {
        super("Iva - Mantenimiento");
        initComponents();
        crearIconosBotones();
        crearAcciones();
    }
    
    private void crearAcciones() {
        KeyStroke escapeKeyStroke = KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false);
        Action escapeAction = new AbstractAction() {
            public void actionPerformed(ActionEvent e) {
                cerrarListaDeIvas();
            }
        }; 
        getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(escapeKeyStroke, "ESCAPE");
        getRootPane().getActionMap().put("ESCAPE", escapeAction);
        
        KeyStroke f1KeyStroke = KeyStroke.getKeyStroke (KeyEvent.VK_F1, 0, false);
        Action f1Action = new AbstractAction() {
            public void actionPerformed(ActionEvent ev) {
                crearIva();
            }
        }; 
        getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(f1KeyStroke, "F1");
        getRootPane().getActionMap().put("F1", f1Action);
    }

    final void crearIva() {
        NuevoIva ni = new NuevoIva("Iva - Creación");
        ni.setDefaultCloseOperation(NuevoIva.DISPOSE_ON_CLOSE);
        ni.setLocationRelativeTo(null);
        ni.setVisible(true);
        cerrarListaDeIvas();
    }
    
    private void cerrarListaDeIvas(){
        removeAll();
        dispose();
    }

    private void crearIconosBotones() {
        URL urlVisualizar = getClass().getResource("/iconos/buscar.gif");
        ImageIcon iconoVisualizar = new ImageIcon(urlVisualizar);
        bmodificar.setIcon(iconoVisualizar);

        URL urlBorrar = getClass().getResource("/iconos/eliminar.png");
        ImageIcon iconoBorrar = new ImageIcon(urlBorrar);
        this.beliminar.setIcon(iconoBorrar);

        URL urlCerrar = getClass().getResource("/iconos/cancelar.gif");
        ImageIcon iconoCerrar = new ImageIcon(urlCerrar);
        bcerrar.setIcon(iconoCerrar);

        URL urlCrear = getClass().getResource("/iconos/aceptar.png");
        ImageIcon iconoCrear = new ImageIcon(urlCrear);
        bnuevo.setIcon(iconoCrear);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        Modelo modelo = new Modelo();
        tIva = new javax.swing.JTable(modelo);

        modelo.addColumn("Tipo");
        modelo.addColumn("Porcentaje");
        modelo.addColumn("Descripción");

        List lIva = BaseDatos.getListaIva();
        Iva iva;
        for (Iterator it = lIva.iterator(); it.hasNext();) {
            Object[] fila = new Object[3];
            iva = (Iva) it.next();
            fila[0] = iva.getTipo();
            fila[1] = Util.convertirPuntoAComa(iva.getPorcentaje().toString());
            fila[2] = iva.getDescripcion();
            modelo.addRow(fila);
        }
        ;
        bnuevo = new javax.swing.JButton();
        bmodificar = new javax.swing.JButton();
        beliminar = new javax.swing.JButton();
        bcerrar = new javax.swing.JButton();
        lbusqueda = new javax.swing.JLabel();
        tbusqueda = new javax.swing.JTextField();
        bbusquedarapida = new javax.swing.JCheckBox();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        tIva.getColumnModel().getColumn(0).setPreferredWidth(80);
        tIva.getColumnModel().getColumn(1).setPreferredWidth(80);
        tIva.getColumnModel().getColumn(2).setPreferredWidth(260);
        tIva.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        tIva.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tIvaMouseClicked(evt);
            }
        });
        tIva.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tIvaKeyPressed(evt);
            }
        });
        jScrollPane1.setViewportView(tIva);

        bnuevo.setText("Crear");
        bnuevo.setAutoscrolls(true);
        bnuevo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bnuevoActionPerformed(evt);
            }
        });

        bmodificar.setText("Visualizar");
        bmodificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bmodificarActionPerformed(evt);
            }
        });

        beliminar.setText("Borrar");
        beliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                beliminarActionPerformed(evt);
            }
        });

        bcerrar.setText("Cerrar");
        bcerrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bcerrarActionPerformed(evt);
            }
        });

        lbusqueda.setText("Búsqueda rápida");

        tbusqueda.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tbusquedaKeyReleased(evt);
            }
        });

        bbusquedarapida.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bbusquedarapidaActionPerformed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout layout = new org.jdesktop.layout.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(layout.createSequentialGroup()
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(layout.createSequentialGroup()
                        .addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .add(bnuevo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 93, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(18, 18, 18)
                        .add(beliminar, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 90, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(18, 18, 18)
                        .add(bmodificar, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 101, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(18, 18, 18)
                        .add(bcerrar, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 88, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                    .add(layout.createSequentialGroup()
                        .addContainerGap()
                        .add(lbusqueda, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 89, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(tbusqueda, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 310, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(bbusquedarapida, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 21, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
            .add(jScrollPane1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 446, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                    .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                        .add(lbusqueda)
                        .add(tbusqueda, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                    .add(bbusquedarapida))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                .add(jScrollPane1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 171, Short.MAX_VALUE)
                .add(18, 18, 18)
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(bcerrar)
                    .add(bmodificar)
                    .add(beliminar)
                    .add(bnuevo))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

private void bmodificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bmodificarActionPerformed
    visualizarIva();
}//GEN-LAST:event_bmodificarActionPerformed

private void visualizarIva(){
    int indice = tIva.getSelectedRow();
    if (indice >= 0) {
        Integer tipo = (Integer)tIva.getModel().getValueAt(indice, 0);
        Iva iva = BaseDatos.obtenerIvaPorTipo(tipo);
        NuevoIva ni = new NuevoIva("Iva - Modificación", iva);
        ni.setDefaultCloseOperation(NuevoIva.DISPOSE_ON_CLOSE);
        ni.setLocationRelativeTo(null);
        ni.setVisible(true);
        cerrarListaDeIvas();
    } else {
        JOptionPane.showMessageDialog(null, "No hay seleccionado ningún elemento", "Error", JOptionPane.ERROR_MESSAGE);
    }
}
private void beliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_beliminarActionPerformed
    borrarIva();
}//GEN-LAST:event_beliminarActionPerformed

private void borrarIva(){
    try{
        int indice = tIva.getSelectedRow();
        if (indice >= 0) {

            int eliminar = 1;
            eliminar = JOptionPane.showConfirmDialog(null, "Está seguro de que desea eliminar el elemento seleccionado?", "¿Eliminar?", JOptionPane.YES_NO_OPTION);
            //hacerCambios = -1 ==> se ha pulsado la "x" de cancelar;
            //hacerCambios =  0 ==> se ha pulsado el "sí"
            //hacerCambios =  1 ==> se ha pulsado el "no"
            if (eliminar == 0) {
                Integer tipo = (Integer) tIva.getModel().getValueAt(indice, 0);

                Iva iva = BaseDatos.obtenerIvaPorTipo(tipo);

                if (BaseDatos.eliminarElemento(iva.getClass(),iva.getIid())) {
                    completarPantalla();
                } else {
                    JOptionPane.showMessageDialog(null, "No se ha podido eliminar el elemento", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        } else {
            JOptionPane.showMessageDialog(null, "No hay seleccionado ningún elemento", "Error", JOptionPane.ERROR_MESSAGE);
        }
    } catch(Exception ex){
        JOptionPane.showMessageDialog(null, "Este elemento no se puede eliminar", "Error", JOptionPane.ERROR_MESSAGE);
    }
}

private void bnuevoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bnuevoActionPerformed
    crearIva();
}//GEN-LAST:event_bnuevoActionPerformed

private void bcerrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bcerrarActionPerformed
    setVisible(false);
}//GEN-LAST:event_bcerrarActionPerformed

private void bbusquedarapidaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bbusquedarapidaActionPerformed
    List lIva;
    if (bbusquedarapida.isSelected()) {
        String tipo = tbusqueda.getText().toLowerCase();
        lIva = BaseDatos.busquedaRapidaIva(tipo);
    } else{
        lIva = BaseDatos.getListaIva();
    }
    actualizarIva(lIva);
}//GEN-LAST:event_bbusquedarapidaActionPerformed

private void tbusquedaKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tbusquedaKeyReleased
    if (bbusquedarapida.isSelected()) {
        String tipo = tbusqueda.getText().toLowerCase();
        List lIva = BaseDatos.busquedaRapidaIva(tipo);
        actualizarIva(lIva);
    }
}//GEN-LAST:event_tbusquedaKeyReleased

private void tIvaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tIvaMouseClicked
    if(evt.getClickCount() == 2){
        visualizarIva();
    }
}//GEN-LAST:event_tIvaMouseClicked

private void tIvaKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tIvaKeyPressed
    if (evt.getKeyChar() == KeyEvent.VK_ENTER) {
        visualizarIva();
    } else if(evt.getKeyChar() == KeyEvent.VK_DELETE){
        borrarIva();
    }
}//GEN-LAST:event_tIvaKeyPressed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JCheckBox bbusquedarapida;
    private javax.swing.JButton bcerrar;
    private javax.swing.JButton beliminar;
    private javax.swing.JButton bmodificar;
    private javax.swing.JButton bnuevo;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lbusqueda;
    private javax.swing.JTable tIva;
    private javax.swing.JTextField tbusqueda;
    // End of variables declaration//GEN-END:variables
    
    private void completarPantalla(){
        List li;
        if (bbusquedarapida.isSelected()) {
            String tipo = tbusqueda.getText().toLowerCase();
            li = BaseDatos.busquedaRapidaIva(tipo);
        } else {
            li = BaseDatos.getListaIva();
        }
        actualizarIva(li);
    }

    public void actualizarIva(List lIva) {

        Modelo modelo = (Modelo) tIva.getModel();
        int i, j;
        Iva iva;
        Object[] fila = new Object[3];
        
        //obtenemos el nº de filas;
        j = modelo.getRowCount();

        //eliminamos todas las filas
        for (i = 0; i < j; i++) {
            modelo.removeRow(0);
        }

        if(lIva == null){
            lIva = new ArrayList();
        }
        
        for (Iterator it = lIva.iterator(); it.hasNext();) {
            iva = (Iva) it.next();
            fila[0] = iva.getTipo();
            fila[1] = iva.getPorcentaje();
            fila[2] = iva.getDescripcion();
            modelo.addRow(fila);
        }
    }
}
