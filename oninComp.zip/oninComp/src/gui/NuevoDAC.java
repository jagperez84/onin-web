package gui;

import acceso.BaseDatos;
import bean.Dac;
import bean.Empresa;
import bean.Articulo;
import bean.Caracteristica;
import bean.Colores;
import bean.Despiece;
import bean.FamiliaVenta;
import bean.Seleccion;
import bean.TipoControl;
import bean.TipoMedida;
import bean.UnidadMedida;
import bean.Variable;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import javax.swing.JOptionPane;
import modelo.Modelo;
import util.Constantes;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.KeyStroke;
import org.apache.log4j.Logger;
import util.Util;

public class NuevoDAC extends javax.swing.JFrame {

    private Empresa e;
    private List<Variable> listaVbles;
    private List<Seleccion> listaSeleccion;
    private List<Despiece> listaDespiece;
    private boolean crear;
    private Dac dac;
    private Articulo ar;
    private String codigoArticuloAntiguo;
    private boolean verTodos = false;
    private ScriptEngine engineGlobal;
    private static Logger log = Logger.getLogger(NuevoDAC.class);

    public NuevoDAC(Empresa e, String titulo) {
        super(titulo);

        ScriptEngineManager manager = new ScriptEngineManager();
        engineGlobal = manager.getEngineByName("js");

        this.e = e;
        this.dac = new Dac();
        ar = null;
        crear = true;
        listaVbles = new ArrayList<Variable>();
        listaSeleccion = new ArrayList<Seleccion>();
        listaDespiece = new ArrayList<Despiece>();
        initComponents();
        rellenarCombosColores();
        crearIconosBotones();
        crearAcciones();
        cbPlantilla.setSelectedIndex(1);
    }

    public NuevoDAC(Empresa e, String titulo, Articulo ar) {
        super(titulo);

        ScriptEngineManager manager = new ScriptEngineManager();
        engineGlobal = manager.getEngineByName("js");

        this.e = e;
        this.dac = new Dac();
        this.ar = ar;

        listaVbles = new ArrayList<Variable>();
        listaSeleccion = new ArrayList<Seleccion>();
        listaDespiece = new ArrayList<Despiece>();
        initComponents();

        tCodigo.setText(ar.getCod_articulo());
        tDescripcion.setText(ar.getDes_inf());

        Dac inDac = BaseDatos.obtenerDacPorCodigoArticulo(ar.getCod_articulo(), e.getIid());
        if (inDac == null) {
            crear = true;
        } else {
            this.dac = inDac;
            crear = false;
            tDescripcionDac.setText(inDac.getDescripcion());
            codigoArticuloAntiguo = ar.getCod_articulo();
            bCancelar.setToolTipText("Cancelar");
            bAceptar.setToolTipText("Aceptar");
            bModificar.setText("Modificar");
            bModificar.setToolTipText("Modificar campos");

            rellenarCombosColores();

            listaDespiece = BaseDatos.getListaDespiece(dac.getIid());

            Colores temp;
            if (dac.getClacado() != null) {
                temp = BaseDatos.obtenerColorPorIid(dac.getClacado().getIid());
                if (temp != null) {
                    cLacado.setSelectedItem(temp.getDescripcion());
                }
            }
            if (dac.getCaccesorios() != null) {
                temp = BaseDatos.obtenerColorPorIid(dac.getCaccesorios().getIid());
                if (temp != null) {
                    cAccesorios.setSelectedItem(temp.getDescripcion());
                }
            }

            tCantidad.setText(Util.convertirPuntoAComa(dac.getCantidad().toString()));
            engineGlobal.put("Cantidad", dac.getCantidad());

            FamiliaVenta fv = BaseDatos.obtenerFamiliaVentaPorIid(ar.getIid_fam_venta().getIid());
            TipoControl tc = BaseDatos.obtenerTipoControlPorIid(fv.getIid_tipo_control().getIid());
            if (tc != null) {
                UnidadMedida um;
                TipoMedida tm = BaseDatos.obtenerTipoMedidaByIid(tc.getIid_tipo_medida().getIid());

                if (tc.getUnidad1() != null) {
                    um = BaseDatos.obtenerUnidadMedidaIid(tc.getUnidad1().getIid());
                    if (um != null) {
                        lUnidad1.setText(tm.getNombre_dim_1());
                        lMagnitud1.setText(um.getCod_unidad_medida());
                        tMedida1.setText(Util.convertirPuntoAComa(dac.getMedida1().toString()));
                        engineGlobal.put("Dim1", dac.getMedida1());
                    }
                } else {
                    lUnidad1.setVisible(false);
                    lMagnitud1.setVisible(false);
                    tMedida1.setVisible(false);
                }
                if (tc.getUnidad2() != null) {
                    um = BaseDatos.obtenerUnidadMedidaIid(tc.getUnidad2().getIid());
                    if (um != null) {
                        lUnidad2.setText(tm.getNombre_dim_2());
                        lMagnitud2.setText(um.getCod_unidad_medida());
                        tMedida2.setText(Util.convertirPuntoAComa(dac.getMedida2().toString()));
                        engineGlobal.put("Dim2", dac.getMedida2());
                    }
                } else {
                    lUnidad2.setVisible(false);
                    lMagnitud2.setVisible(false);
                    tMedida2.setVisible(false);
                }
                if (tc.getUnidad3() != null) {
                    um = BaseDatos.obtenerUnidadMedidaIid(tc.getUnidad3().getIid());
                    if (um != null) {
                        lUnidad3.setText(tm.getNombre_dim_3());
                        lMagnitud3.setText(um.getCod_unidad_medida());
                        tMedida3.setText(Util.convertirPuntoAComa(dac.getMedida3().toString()));
                        engineGlobal.put("Dim3", dac.getMedida3());
                    }
                } else {
                    lUnidad3.setVisible(false);
                    lMagnitud3.setVisible(false);
                    tMedida3.setVisible(false);
                }
                if (tc.getUnidad4() != null) {
                    um = BaseDatos.obtenerUnidadMedidaIid(tc.getUnidad4().getIid());
                    if (um != null) {
                        lUnidad4.setText(tm.getNombre_dim_4());
                        lMagnitud4.setText(um.getCod_unidad_medida());
                        tMedida4.setText(Util.convertirPuntoAComa(dac.getMedida4().toString()));
                        engineGlobal.put("Dim4", dac.getMedida4());
                    }
                } else {
                    lUnidad4.setVisible(false);
                    lMagnitud4.setVisible(false);
                    tMedida4.setVisible(false);
                }
                if (tc.getUnidad5() != null) {
                    um = BaseDatos.obtenerUnidadMedidaIid(tc.getUnidad5().getIid());
                    if (um != null) {
                        lUnidad5.setText(tm.getNombre_dim_5());
                        lMagnitud5.setText(um.getCod_unidad_medida());
                        tMedida5.setText(Util.convertirPuntoAComa(dac.getMedida5().toString()));
                        engineGlobal.put("Dim5", dac.getMedida5());
                    }
                } else {
                    lUnidad5.setVisible(false);
                    lMagnitud5.setVisible(false);
                    tMedida5.setVisible(false);
                }
            }

            tCantidad.setEnabled(false);
            cLacado.setEnabled(false);
            cAccesorios.setEnabled(false);
            pMedidas.setEnabled(true);
            tMedida1.setEnabled(false);
            tMedida2.setEnabled(false);
            tMedida3.setEnabled(false);
            tMedida4.setEnabled(false);
            tMedida5.setEnabled(false);
            tDescripcionDac.setEnabled(false);
            bSeleccionarArticulo.setEnabled(false);
            bNuevaVble.setEnabled(false);
            bEliminarVble.setEnabled(false);
            bModificarVble.setEnabled(false);
            tVbles.setEnabled(false);
            tDespiece.setEnabled(false);
            bInsertar.setEnabled(false);
            bAñadir.setEnabled(false);
            bBajar.setEnabled(false);
            bBorrar.setEnabled(false);
            bSubir.setEnabled(false);
            bVerTodos.setEnabled(false);
            bModificarDespiece.setEnabled(false);

            cbPlantilla.setSelectedItem(dac.getTipoPlantilla());
            cbPlantilla.setEnabled(false);

            if (dac.getPerfilCofre() != null && dac.getPerfilCofre()) {
                cbPerfilCofre.setSelected(true);
            }

            if (dac.getLona() != null && dac.getLona()) {
                cbLona.setSelected(true);
            }
            cbLona.setEnabled(false);

            if (dac.getSoporte() != null && dac.getSoporte()) {
                cbSoporte.setSelected(true);
            }
            cbSoporte.setEnabled(false);

            if (dac.getCasquillo() != null && dac.getCasquillo()) {
                cbCasquillo.setSelected(true);
            }
            cbCasquillo.setEnabled(false);

            if (dac.getTapa() != null && dac.getTapa()) {
                cbTapa.setSelected(true);
            }
            cbTapa.setEnabled(false);

            if (dac.getMaquina() != null && dac.getMaquina()) {
                cbMaquina.setSelected(true);
            }
            cbMaquina.setEnabled(false);

            if (dac.getTerminal() != null && dac.getTerminal()) {
                this.cbTerminal.setSelected(true);
            }
            cbTerminal.setEnabled(false);

            if (dac.getPoleaIzquierda() != null && dac.getPoleaIzquierda()) {
                this.cbPoleaIzquierda.setSelected(true);
            }
            cbPoleaIzquierda.setEnabled(false);

            if (dac.getPoleaDerecha() != null && dac.getPoleaDerecha()) {
                this.cbPoleaDerecha.setSelected(true);
            }
            cbPoleaDerecha.setEnabled(false);

            if (dac.getLonaDoble() != null && dac.getLonaDoble()) {
                this.cbLonaDoble.setSelected(true);
            }
            cbLonaDoble.setEnabled(false);

            if (dac.getTuboEnrrolle() != null && dac.getTuboEnrrolle()) {
                cbTuboEnrrolle.setSelected(false);
            }
            cbTuboEnrrolle.setEnabled(false);

            if (dac.getAtacuerda() != null && dac.getAtacuerda()) {
                this.cbAtacuerda.setSelected(true);
            }
            cbAtacuerda.setEnabled(false);

            if (dac.getAtacuerdaPared() != null && dac.getAtacuerdaPared()) {
                this.cbAtacuerdaPared.setSelected(true);
            }
            cbAtacuerdaPared.setEnabled(false);

            if (dac.getManivela() != null && dac.getManivela()) {
                this.cbManivela.setSelected(true);
            }
            cbManivela.setEnabled(false);

            if (dac.getGancho() != null && dac.getGancho()) {
                this.cbGancho.setSelected(true);
            }
            cbGancho.setEnabled(false);

            if (dac.getBambolina() != null && dac.getBambolina()) {
                this.cbBambolina.setSelected(true);
            }
            cbBambolina.setEnabled(false);

            if (dac.getPerfil() != null && dac.getPerfil()) {
                this.cbPerfil.setSelected(true);
            }
            cbPerfil.setEnabled(false);

            if (dac.getBrazo() != null && dac.getBrazo()) {
                this.cbBrazo.setSelected(true);
            }
            cbBrazo.setEnabled(false);


            if (dac.getCofre() != null && dac.getCofre()) {
                this.cbCofre.setSelected(true);
            }
            cbCofre.setEnabled(false);

            if (dac.getMotor() != null && dac.getMotor()) {
                this.cbMotor.setSelected(true);
            }
            cbMotor.setEnabled(false);

            if (dac.getForma() != null && dac.getForma()) {
                this.cbForma.setSelected(true);
            }
            cbForma.setEnabled(false);


            if (dac.getCarruchaSimple() != null && dac.getCarruchaSimple()) {
                this.cbCarruchaSimple.setSelected(true);
            }
            cbCarruchaSimple.setEnabled(false);

            if (dac.getCarruchaDoble() != null && dac.getCarruchaDoble()) {
                this.cbCarruchaDoble.setSelected(true);
            }
            cbCarruchaDoble.setEnabled(false);

            if (dac.getPerfilCofre() != null && dac.getPerfilCofre()) {
                this.cbPerfilCofre.setSelected(true);
            }
            cbPerfilCofre.setEnabled(false);

            iniciarValoresVbles();
            actualizarListaVariables();
            actualizarListaDespiece();
        }

        rellenarCombosColores();
        crearIconosBotones();
        crearAcciones();

        cbPlantilla.setSelectedIndex(1);
    }

    public NuevoDAC(Empresa e, Dac dac, String titulo) {
        super(titulo);

        ScriptEngineManager manager = new ScriptEngineManager();
        engineGlobal = manager.getEngineByName("js");

        this.e = e;
        this.dac = dac;
        this.ar = BaseDatos.obtenerArticuloPorIid(dac.getArticulo().getIid());
        crear = false;
        listaVbles = BaseDatos.getListaVariables(dac.getIid());
        listaSeleccion = BaseDatos.getListaSeleccion(dac.getIid());

        listaDespiece = new ArrayList<Despiece>();

        initComponents();

        codigoArticuloAntiguo = ar.getCod_articulo();

        tCodigo.setText(codigoArticuloAntiguo);
        tDescripcion.setText(ar.getDes_inf());
        tDescripcionDac.setText(dac.getDescripcion());

        bCancelar.setToolTipText("Cancelar");
        bAceptar.setToolTipText("Aceptar");
        bModificar.setText("Modificar");
        bModificar.setToolTipText("Modificar campos");

        rellenarCombosColores();

        listaDespiece = BaseDatos.getListaDespiece(dac.getIid());

        Colores temp;
        if (dac.getClacado() != null) {
            temp = BaseDatos.obtenerColorPorIid(dac.getClacado().getIid());
            if (temp != null) {
                cLacado.setSelectedItem(temp.getDescripcion());
            }
        }
        if (dac.getCaccesorios() != null) {
            temp = BaseDatos.obtenerColorPorIid(dac.getCaccesorios().getIid());
            if (temp != null) {
                cAccesorios.setSelectedItem(temp.getDescripcion());
            }
        }

        tCantidad.setText(Util.convertirPuntoAComa(dac.getCantidad().toString()));
        engineGlobal.put("Cantidad", dac.getCantidad());

        FamiliaVenta fv = BaseDatos.obtenerFamiliaVentaPorIid(ar.getIid_fam_venta().getIid());
        TipoControl tc = BaseDatos.obtenerTipoControlPorIid(fv.getIid_tipo_control().getIid());

        if (tc != null) {
            UnidadMedida um;
            TipoMedida tm = BaseDatos.obtenerTipoMedidaByIid(tc.getIid_tipo_medida().getIid());

            if (tc.getUnidad1() != null) {
                um = BaseDatos.obtenerUnidadMedidaIid(tc.getUnidad1().getIid());
                if (um != null) {
                    lUnidad1.setText(tm.getNombre_dim_1());
                    lMagnitud1.setText(um.getCod_unidad_medida());
                    tMedida1.setText(Util.convertirPuntoAComa(dac.getMedida1().toString()));
                    engineGlobal.put("Dim1", dac.getMedida1());
                }
            } else {
                lUnidad1.setVisible(false);
                lMagnitud1.setVisible(false);
                tMedida1.setVisible(false);
            }
            if (tc.getUnidad2() != null) {
                um = BaseDatos.obtenerUnidadMedidaIid(tc.getUnidad2().getIid());
                if (um != null) {
                    lUnidad2.setText(tm.getNombre_dim_2());
                    lMagnitud2.setText(um.getCod_unidad_medida());
                    tMedida2.setText(Util.convertirPuntoAComa(dac.getMedida2().toString()));
                    engineGlobal.put("Dim2", dac.getMedida2());
                }
            } else {
                lUnidad2.setVisible(false);
                lMagnitud2.setVisible(false);
                tMedida2.setVisible(false);
            }
            if (tc.getUnidad3() != null) {
                um = BaseDatos.obtenerUnidadMedidaIid(tc.getUnidad3().getIid());
                if (um != null) {
                    lUnidad3.setText(tm.getNombre_dim_3());
                    lMagnitud3.setText(um.getCod_unidad_medida());
                    tMedida3.setText(Util.convertirPuntoAComa(dac.getMedida3().toString()));
                    engineGlobal.put("Dim3", dac.getMedida3());
                }
            } else {
                lUnidad3.setVisible(false);
                lMagnitud3.setVisible(false);
                tMedida3.setVisible(false);
            }
            if (tc.getUnidad4() != null) {
                um = BaseDatos.obtenerUnidadMedidaIid(tc.getUnidad4().getIid());
                if (um != null) {
                    lUnidad4.setText(tm.getNombre_dim_4());
                    lMagnitud4.setText(um.getCod_unidad_medida());
                    tMedida4.setText(Util.convertirPuntoAComa(dac.getMedida4().toString()));
                    engineGlobal.put("Dim4", dac.getMedida4());
                }
            } else {
                lUnidad4.setVisible(false);
                lMagnitud4.setVisible(false);
                tMedida4.setVisible(false);
            }
            if (tc.getUnidad5() != null) {
                um = BaseDatos.obtenerUnidadMedidaIid(tc.getUnidad5().getIid());
                if (um != null) {
                    lUnidad5.setText(tm.getNombre_dim_5());
                    lMagnitud5.setText(um.getCod_unidad_medida());
                    tMedida5.setText(Util.convertirPuntoAComa(dac.getMedida5().toString()));
                    engineGlobal.put("Dim5", dac.getMedida5());
                }
            } else {
                lUnidad5.setVisible(false);
                lMagnitud5.setVisible(false);
                tMedida5.setVisible(false);
            }
        }

        tCantidad.setEnabled(false);
        cLacado.setEnabled(false);
        cAccesorios.setEnabled(false);
        pMedidas.setEnabled(true);
        tMedida1.setEnabled(false);
        tMedida2.setEnabled(false);
        tMedida3.setEnabled(false);
        tMedida4.setEnabled(false);
        tMedida5.setEnabled(false);
        tDescripcionDac.setEnabled(false);
        bSeleccionarArticulo.setEnabled(false);
        bNuevaVble.setEnabled(false);
        bEliminarVble.setEnabled(false);
        bModificarVble.setEnabled(false);
        tVbles.setEnabled(false);
        tDespiece.setEnabled(false);
        bInsertar.setEnabled(false);
        bAñadir.setEnabled(false);
        bBajar.setEnabled(false);
        bBorrar.setEnabled(false);
        bSubir.setEnabled(false);
        bVerTodos.setEnabled(false);
        bModificarDespiece.setEnabled(false);

        cbPlantilla.setSelectedItem(dac.getTipoPlantilla());
        cbPlantilla.setEnabled(false);

        if (dac.getPerfilCofre() != null && dac.getPerfilCofre()) {
            cbPerfilCofre.setSelected(true);
        }

        if (dac.getLona() != null && dac.getLona()) {
            cbLona.setSelected(true);
        }
        cbLona.setEnabled(false);

        if (dac.getSoporte() != null && dac.getSoporte()) {
            cbSoporte.setSelected(true);
        }
        cbSoporte.setEnabled(false);

        if (dac.getCasquillo() != null && dac.getCasquillo()) {
            cbCasquillo.setSelected(true);
        }
        cbCasquillo.setEnabled(false);

        if (dac.getTapa() != null && dac.getTapa()) {
            cbTapa.setSelected(true);
        }
        cbTapa.setEnabled(false);

        if (dac.getMaquina() != null && dac.getMaquina()) {
            cbMaquina.setSelected(true);
        }
        cbMaquina.setEnabled(false);

        if (dac.getTerminal() != null && dac.getTerminal()) {
            this.cbTerminal.setSelected(true);
        }
        cbTerminal.setEnabled(false);

        if (dac.getPoleaIzquierda() != null && dac.getPoleaIzquierda()) {
            this.cbPoleaIzquierda.setSelected(true);
        }
        cbPoleaIzquierda.setEnabled(false);

        if (dac.getPoleaDerecha() != null && dac.getPoleaDerecha()) {
            this.cbPoleaDerecha.setSelected(true);
        }
        cbPoleaDerecha.setEnabled(false);

        if (dac.getLonaDoble() != null && dac.getLonaDoble()) {
            this.cbLonaDoble.setSelected(true);
        }
        cbLonaDoble.setEnabled(false);

        if (dac.getTuboEnrrolle() != null && dac.getTuboEnrrolle()) {
            cbTuboEnrrolle.setSelected(false);
        }
        cbTuboEnrrolle.setEnabled(false);

        if (dac.getAtacuerda() != null && dac.getAtacuerda()) {
            this.cbAtacuerda.setSelected(true);
        }
        cbAtacuerda.setEnabled(false);

        if (dac.getAtacuerdaPared() != null && dac.getAtacuerdaPared()) {
            this.cbAtacuerdaPared.setSelected(true);
        }
        cbAtacuerdaPared.setEnabled(false);

        if (dac.getManivela() != null && dac.getManivela()) {
            this.cbManivela.setSelected(true);
        }
        cbManivela.setEnabled(false);

        if (dac.getGancho() != null && dac.getGancho()) {
            this.cbGancho.setSelected(true);
        }
        cbGancho.setEnabled(false);

        if (dac.getBambolina() != null && dac.getBambolina()) {
            this.cbBambolina.setSelected(true);
        }
        cbBambolina.setEnabled(false);

        if (dac.getPerfil() != null && dac.getPerfil()) {
            this.cbPerfil.setSelected(true);
        }
        cbPerfil.setEnabled(false);

        if (dac.getBrazo() != null && dac.getBrazo()) {
            this.cbBrazo.setSelected(true);
        }
        cbBrazo.setEnabled(false);


        if (dac.getCofre() != null && dac.getCofre()) {
            this.cbCofre.setSelected(true);
        }
        cbCofre.setEnabled(false);

        if (dac.getMotor() != null && dac.getMotor()) {
            this.cbMotor.setSelected(true);
        }
        cbMotor.setEnabled(false);

        if (dac.getForma() != null && dac.getForma()) {
            this.cbForma.setSelected(true);
        }
        cbForma.setEnabled(false);


        if (dac.getCarruchaSimple() != null && dac.getCarruchaSimple()) {
            this.cbCarruchaSimple.setSelected(true);
        }
        cbCarruchaSimple.setEnabled(false);

        if (dac.getCarruchaDoble() != null && dac.getCarruchaDoble()) {
            this.cbCarruchaDoble.setSelected(true);
        }
        cbCarruchaDoble.setEnabled(false);

        if (dac.getPerfilCofre() != null && dac.getPerfilCofre()) {
            this.cbPerfilCofre.setSelected(true);
        }
        cbPerfilCofre.setEnabled(false);

        iniciarValoresVbles();
        actualizarListaVariables();
        actualizarListaDespiece();

        crearIconosBotones();
        crearAcciones();
    }

    private void crearAcciones() {
        KeyStroke escapeKeyStroke = KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false);
        Action escapeAction = new AbstractAction() {

            public void actionPerformed(ActionEvent e) {
                cerrarDac();
            }
        };
        getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(escapeKeyStroke, "ESCAPE");
        getRootPane().getActionMap().put("ESCAPE", escapeAction);

        Dimension dim = Util.getDimensiones(this.getSize());
        if (dim != null) {
            setResizable(true);
            setSize(dim);
        }
    }

    private void cerrarDac() {
        removeAll();
        dispose();
    }

    private void iniciarValoresVbles() {
        Variable var;
        String nombre;
        Double valor;

        for (Iterator<Variable> it = listaVbles.iterator(); it.hasNext();) {
            var = it.next();
            nombre = var.getNombre();
            valor = calcularValor(var);
            engineGlobal.put(nombre, valor);
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        bModificar = new javax.swing.JButton();
        bAceptar = new javax.swing.JButton();
        bCancelar = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        jPanel1 = new javax.swing.JPanel();
        pOpciones = new javax.swing.JPanel();
        cbLona = new javax.swing.JCheckBox();
        cbLonaDoble = new javax.swing.JCheckBox();
        cbSoporte = new javax.swing.JCheckBox();
        cbCasquillo = new javax.swing.JCheckBox();
        cbTapa = new javax.swing.JCheckBox();
        cbTerminal = new javax.swing.JCheckBox();
        cbMaquina = new javax.swing.JCheckBox();
        cbPoleaIzquierda = new javax.swing.JCheckBox();
        cbPoleaDerecha = new javax.swing.JCheckBox();
        cbCarruchaSimple = new javax.swing.JCheckBox();
        cbCarruchaDoble = new javax.swing.JCheckBox();
        cbAtacuerda = new javax.swing.JCheckBox();
        cbAtacuerdaPared = new javax.swing.JCheckBox();
        cbGancho = new javax.swing.JCheckBox();
        cbBambolina = new javax.swing.JCheckBox();
        cbPerfil = new javax.swing.JCheckBox();
        cbManivela = new javax.swing.JCheckBox();
        cbBrazo = new javax.swing.JCheckBox();
        cbMotor = new javax.swing.JCheckBox();
        cbCofre = new javax.swing.JCheckBox();
        cbForma = new javax.swing.JCheckBox();
        cbTuboEnrrolle = new javax.swing.JCheckBox();
        cbPerfilCofre = new javax.swing.JCheckBox();
        pMedidas = new javax.swing.JPanel();
        lUnidad1 = new javax.swing.JLabel();
        tMedida1 = new javax.swing.JTextField();
        lUnidad2 = new javax.swing.JLabel();
        tMedida2 = new javax.swing.JTextField();
        lMagnitud1 = new javax.swing.JLabel();
        lMagnitud2 = new javax.swing.JLabel();
        lUnidad3 = new javax.swing.JLabel();
        tMedida3 = new javax.swing.JTextField();
        lMagnitud3 = new javax.swing.JLabel();
        lUnidad4 = new javax.swing.JLabel();
        tMedida4 = new javax.swing.JTextField();
        lMagnitud4 = new javax.swing.JLabel();
        lUnidad5 = new javax.swing.JLabel();
        tMedida5 = new javax.swing.JTextField();
        lMagnitud5 = new javax.swing.JLabel();
        lCantidad = new javax.swing.JLabel();
        tCantidad = new javax.swing.JTextField();
        lMagnitudCantidad = new javax.swing.JLabel();
        pSeleccionArticulo2 = new javax.swing.JPanel();
        lLacado = new javax.swing.JLabel();
        cLacado = new javax.swing.JComboBox();
        lAccesorios = new javax.swing.JLabel();
        cAccesorios = new javax.swing.JComboBox();
        pSeleccionArticulo = new javax.swing.JPanel();
        bSeleccionarArticulo = new javax.swing.JButton();
        lCodigo = new javax.swing.JLabel();
        tCodigo = new javax.swing.JTextField();
        lDescripcion = new javax.swing.JLabel();
        tDescripcion = new javax.swing.JTextField();
        tDescripcionDac = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        cbPlantilla = new javax.swing.JComboBox();
        pDespiece = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        modelo.Modelo modeloD = new Modelo();
        tDespiece = new javax.swing.JTable();
        bSubir = new javax.swing.JButton();
        bBajar = new javax.swing.JButton();
        bAñadir = new javax.swing.JButton();
        bInsertar = new javax.swing.JButton();
        bModificarDespiece = new javax.swing.JButton();
        bBorrar = new javax.swing.JButton();
        bVerTodos = new javax.swing.JButton();
        pVbles = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        modelo.Modelo modelo = new Modelo();
        tVbles = new javax.swing.JTable();
        bNuevaVble = new javax.swing.JButton();
        bModificarVble = new javax.swing.JButton();
        bEliminarVble = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        bModificar.setText("Modificar");
        bModificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bModificarActionPerformed(evt);
            }
        });

        bAceptar.setText("Aceptar");
        bAceptar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bAceptarActionPerformed(evt);
            }
        });

        bCancelar.setText("Cancelar");
        bCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bCancelarActionPerformed(evt);
            }
        });

        pOpciones.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(102, 153, 255)), "Opciones", javax.swing.border.TitledBorder.LEFT, javax.swing.border.TitledBorder.DEFAULT_POSITION));

        cbLona.setText("Lona");

        cbLonaDoble.setText("Lona doble");

        cbSoporte.setText("Soporte");

        cbCasquillo.setText("Casquillo");

        cbTapa.setText("Tapa");

        cbTerminal.setText("Terminal");

        cbMaquina.setText("Maquina");

        cbPoleaIzquierda.setText("Polea izquierda");

        cbPoleaDerecha.setText("Polea derecha");

        cbCarruchaSimple.setText("Carrucha simple");

        cbCarruchaDoble.setText("Carrucha doble");

        cbAtacuerda.setText("Atacuerda");

        cbAtacuerdaPared.setText("Atacuerda pared");

        cbGancho.setText("Gancho");

        cbBambolina.setText("Bambolina");

        cbPerfil.setText("Perfil");

        cbManivela.setText("Manivela");

        cbBrazo.setText("Brazo");

        cbMotor.setText("Motor");

        cbCofre.setText("Cofre");

        cbForma.setText("Forma");

        cbTuboEnrrolle.setText("Tubo enrrolle");

        cbPerfilCofre.setText("Perfil cobre");

        org.jdesktop.layout.GroupLayout pOpcionesLayout = new org.jdesktop.layout.GroupLayout(pOpciones);
        pOpciones.setLayout(pOpcionesLayout);
        pOpcionesLayout.setHorizontalGroup(
            pOpcionesLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(pOpcionesLayout.createSequentialGroup()
                .add(pOpcionesLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(cbCarruchaSimple)
                    .add(cbCarruchaDoble)
                    .add(pOpcionesLayout.createSequentialGroup()
                        .add(pOpcionesLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(cbBambolina)
                            .add(cbAtacuerdaPared)
                            .add(cbBrazo)
                            .add(cbCasquillo)
                            .add(cbCofre)
                            .add(cbAtacuerda))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                        .add(pOpcionesLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(cbMaquina)
                            .add(cbMotor)
                            .add(cbForma)
                            .add(cbGancho)
                            .add(cbLona)
                            .add(cbLonaDoble)
                            .add(cbManivela)
                            .add(cbPerfil))))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(pOpcionesLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(cbTapa)
                    .add(cbSoporte)
                    .add(cbPoleaIzquierda)
                    .add(cbPoleaDerecha)
                    .add(cbTerminal)
                    .add(cbTuboEnrrolle)
                    .add(cbPerfilCofre)))
        );
        pOpcionesLayout.setVerticalGroup(
            pOpcionesLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(pOpcionesLayout.createSequentialGroup()
                .add(pOpcionesLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(cbAtacuerda)
                    .add(cbForma)
                    .add(cbPerfilCofre))
                .add(pOpcionesLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(pOpcionesLayout.createSequentialGroup()
                        .add(0, 0, 0)
                        .add(pOpcionesLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(cbAtacuerdaPared)
                            .add(cbGancho))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(pOpcionesLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(cbBambolina)
                            .add(cbLona))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(pOpcionesLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(cbBrazo)
                            .add(cbLonaDoble))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(pOpcionesLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(cbCarruchaSimple)
                            .add(cbManivela))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(pOpcionesLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(cbCarruchaDoble)
                            .add(cbMaquina))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(pOpcionesLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(cbCasquillo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 23, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(cbMotor))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(pOpcionesLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(cbCofre)
                            .add(cbPerfil)))
                    .add(pOpcionesLayout.createSequentialGroup()
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(pOpcionesLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(pOpcionesLayout.createSequentialGroup()
                                .add(92, 92, 92)
                                .add(cbTerminal))
                            .add(pOpcionesLayout.createSequentialGroup()
                                .add(cbPoleaIzquierda)
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                .add(cbPoleaDerecha)
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                .add(cbSoporte)
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                .add(cbTapa)))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(cbTuboEnrrolle))))
        );

        pMedidas.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.LineBorder(new java.awt.Color(153, 153, 255), 1, true), "Medidas"));

        lUnidad1.setText("Unidad1");

        tMedida1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tMedida1KeyReleased(evt);
            }
        });

        lUnidad2.setText("Unidad2");

        tMedida2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tMedida2KeyReleased(evt);
            }
        });

        lMagnitud1.setText("Magnitud1");

        lMagnitud2.setText("Magnitud2");

        lUnidad3.setText("Unidad3");

        tMedida3.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tMedida3KeyReleased(evt);
            }
        });

        lMagnitud3.setText("Magnitud3");

        lUnidad4.setText("Unidad4");

        tMedida4.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tMedida4KeyReleased(evt);
            }
        });

        lMagnitud4.setText("Magnitud4");

        lUnidad5.setText("Unidad5");

        tMedida5.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tMedida5KeyReleased(evt);
            }
        });

        lMagnitud5.setText("Magnitud5");

        lCantidad.setText("Cantidad");

        tCantidad.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tCantidadKeyReleased(evt);
            }
        });

        lMagnitudCantidad.setText("ud");

        org.jdesktop.layout.GroupLayout pMedidasLayout = new org.jdesktop.layout.GroupLayout(pMedidas);
        pMedidas.setLayout(pMedidasLayout);
        pMedidasLayout.setHorizontalGroup(
            pMedidasLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(pMedidasLayout.createSequentialGroup()
                .addContainerGap()
                .add(pMedidasLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(org.jdesktop.layout.GroupLayout.TRAILING, pMedidasLayout.createSequentialGroup()
                        .add(pMedidasLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING, false)
                            .add(org.jdesktop.layout.GroupLayout.LEADING, lUnidad5, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .add(org.jdesktop.layout.GroupLayout.LEADING, lUnidad4, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .add(org.jdesktop.layout.GroupLayout.LEADING, lUnidad3, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .add(org.jdesktop.layout.GroupLayout.LEADING, lUnidad2, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .add(org.jdesktop.layout.GroupLayout.LEADING, lUnidad1))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .add(pMedidasLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING, false)
                            .add(tMedida5)
                            .add(tMedida4)
                            .add(tMedida3)
                            .add(tMedida2)
                            .add(tMedida1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 68, Short.MAX_VALUE)))
                    .add(pMedidasLayout.createSequentialGroup()
                        .add(lCantidad)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(tCantidad, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 64, Short.MAX_VALUE)))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(pMedidasLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(lMagnitud5)
                    .add(lMagnitud4, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 59, Short.MAX_VALUE)
                    .add(lMagnitud3, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 59, Short.MAX_VALUE)
                    .add(lMagnitud2, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 59, Short.MAX_VALUE)
                    .add(lMagnitudCantidad)
                    .add(lMagnitud1))
                .addContainerGap())
        );
        pMedidasLayout.setVerticalGroup(
            pMedidasLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, pMedidasLayout.createSequentialGroup()
                .add(pMedidasLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(lCantidad)
                    .add(tCantidad, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(lMagnitudCantidad))
                .add(pMedidasLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(pMedidasLayout.createSequentialGroup()
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .add(pMedidasLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(lUnidad1)
                            .add(tMedida1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                    .add(pMedidasLayout.createSequentialGroup()
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(lMagnitud1)))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(pMedidasLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(lUnidad2)
                    .add(lMagnitud2)
                    .add(tMedida2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(pMedidasLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(lUnidad3)
                    .add(lMagnitud3)
                    .add(tMedida3, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(pMedidasLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(lUnidad4)
                    .add(lMagnitud4)
                    .add(tMedida4, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(pMedidasLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(lUnidad5)
                    .add(lMagnitud5)
                    .add(tMedida5, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
        );

        pSeleccionArticulo2.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.LineBorder(new java.awt.Color(153, 153, 255), 1, true), "Colores"));

        lLacado.setText("Lacado");

        cLacado.setModel(new javax.swing.DefaultComboBoxModel(new String[] { }));
        cLacado.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cLacadoActionPerformed(evt);
            }
        });

        lAccesorios.setText("Accesorios");

        cAccesorios.setModel(new javax.swing.DefaultComboBoxModel(new String[] { }));
        cAccesorios.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cAccesoriosActionPerformed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout pSeleccionArticulo2Layout = new org.jdesktop.layout.GroupLayout(pSeleccionArticulo2);
        pSeleccionArticulo2.setLayout(pSeleccionArticulo2Layout);
        pSeleccionArticulo2Layout.setHorizontalGroup(
            pSeleccionArticulo2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(pSeleccionArticulo2Layout.createSequentialGroup()
                .add(lLacado, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 48, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(cLacado, 0, 93, Short.MAX_VALUE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                .add(lAccesorios)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(cAccesorios, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 139, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        pSeleccionArticulo2Layout.setVerticalGroup(
            pSeleccionArticulo2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(pSeleccionArticulo2Layout.createSequentialGroup()
                .add(pSeleccionArticulo2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(lLacado)
                    .add(lAccesorios)
                    .add(cLacado, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(cAccesorios, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pSeleccionArticulo.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.LineBorder(new java.awt.Color(153, 153, 255), 1, true), "Artículo"));

        bSeleccionarArticulo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bSeleccionarArticuloActionPerformed(evt);
            }
        });

        lCodigo.setText("Codigo");

        tCodigo.setEditable(false);

        lDescripcion.setText("Descripción");

        tDescripcion.setEditable(false);

        tDescripcionDac.setEditable(false);
        tDescripcionDac.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tDescripcionDacKeyReleased(evt);
            }
        });

        jLabel1.setText("Plantilla");

        cbPlantilla.setModel(new javax.swing.DefaultComboBoxModel(new String[] { Constantes.PLANTILLA_TOLDO_ENRROLLADO, Constantes.PLANTILLA_TOLDO_GENERAL, Constantes.PLANTILLA_TOLDO_PLANO}));
        cbPlantilla.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbPlantillaActionPerformed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout pSeleccionArticuloLayout = new org.jdesktop.layout.GroupLayout(pSeleccionArticulo);
        pSeleccionArticulo.setLayout(pSeleccionArticuloLayout);
        pSeleccionArticuloLayout.setHorizontalGroup(
            pSeleccionArticuloLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(pSeleccionArticuloLayout.createSequentialGroup()
                .add(pSeleccionArticuloLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(pSeleccionArticuloLayout.createSequentialGroup()
                        .add(lCodigo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 64, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(tCodigo, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 242, Short.MAX_VALUE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(bSeleccionarArticulo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 33, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                    .add(org.jdesktop.layout.GroupLayout.TRAILING, pSeleccionArticuloLayout.createSequentialGroup()
                        .add(68, 68, 68)
                        .add(tDescripcion, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 281, Short.MAX_VALUE))
                    .add(pSeleccionArticuloLayout.createSequentialGroup()
                        .add(pSeleccionArticuloLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING, false)
                            .add(org.jdesktop.layout.GroupLayout.LEADING, jLabel1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .add(org.jdesktop.layout.GroupLayout.LEADING, lDescripcion, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 64, Short.MAX_VALUE))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(pSeleccionArticuloLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(cbPlantilla, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 168, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(tDescripcionDac, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 281, Short.MAX_VALUE))))
                .addContainerGap())
        );
        pSeleccionArticuloLayout.setVerticalGroup(
            pSeleccionArticuloLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(pSeleccionArticuloLayout.createSequentialGroup()
                .add(pSeleccionArticuloLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(pSeleccionArticuloLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                        .add(tCodigo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(lCodigo))
                    .add(bSeleccionarArticulo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(tDescripcion, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(pSeleccionArticuloLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(tDescripcionDac, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(lDescripcion))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                .add(pSeleccionArticuloLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(jLabel1)
                    .add(cbPlantilla, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pDespiece.setBorder(javax.swing.BorderFactory.createTitledBorder("Despiece"));

        tDespiece.setModel(modeloD);

        //Creamos las columnas
        modeloD.addColumn("Cantidad");
        modeloD.addColumn("Código");
        modeloD.addColumn("Descripción");
        modeloD.addColumn("Medidas");
        tDespiece.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tDespieceMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(tDespiece);

        bSubir.setText("Subir");
        bSubir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bSubirActionPerformed(evt);
            }
        });

        bBajar.setText("Bajar");
        bBajar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bBajarActionPerformed(evt);
            }
        });

        bAñadir.setText("Añadir");
        bAñadir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bAñadirActionPerformed(evt);
            }
        });

        bInsertar.setText("Insertar");
        bInsertar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bInsertarActionPerformed(evt);
            }
        });

        bModificarDespiece.setText("Modificar");
        bModificarDespiece.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bModificarDespieceActionPerformed(evt);
            }
        });

        bBorrar.setText("Borrar");
        bBorrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bBorrarActionPerformed(evt);
            }
        });

        bVerTodos.setText("Ver todos");
        bVerTodos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bVerTodosActionPerformed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout pDespieceLayout = new org.jdesktop.layout.GroupLayout(pDespiece);
        pDespiece.setLayout(pDespieceLayout);
        pDespieceLayout.setHorizontalGroup(
            pDespieceLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, pDespieceLayout.createSequentialGroup()
                .add(jScrollPane2, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 425, Short.MAX_VALUE)
                .add(18, 18, 18)
                .add(pDespieceLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING, false)
                    .add(bVerTodos, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .add(bBorrar, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .add(bModificarDespiece, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .add(bInsertar, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .add(bAñadir, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .add(bBajar, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .add(org.jdesktop.layout.GroupLayout.LEADING, bSubir, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 93, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );
        pDespieceLayout.setVerticalGroup(
            pDespieceLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(pDespieceLayout.createSequentialGroup()
                .add(bSubir)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(bBajar)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(bAñadir)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(bInsertar)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(bModificarDespiece)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(bBorrar)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(bVerTodos))
            .add(pDespieceLayout.createSequentialGroup()
                .add(jScrollPane2, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 217, Short.MAX_VALUE)
                .addContainerGap())
        );

        pVbles.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(102, 153, 255)), "Variables", javax.swing.border.TitledBorder.LEFT, javax.swing.border.TitledBorder.DEFAULT_POSITION));

        tVbles.setModel(modelo);

        // Creamos las columnas.
        modelo.addColumn("Nombre");
        modelo.addColumn("Valor");

        tVbles.getColumnModel().getColumn(0).setPreferredWidth(30);
        tVbles.getColumnModel().getColumn(1).setPreferredWidth(20);
        tVbles.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tVblesMouseClicked(evt);
            }
        });
        tVbles.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tVblesKeyPressed(evt);
            }
        });
        jScrollPane1.setViewportView(tVbles);

        bNuevaVble.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bNuevaVbleActionPerformed(evt);
            }
        });

        bModificarVble.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bModificarVbleActionPerformed(evt);
            }
        });

        bEliminarVble.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bEliminarVbleActionPerformed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout pVblesLayout = new org.jdesktop.layout.GroupLayout(pVbles);
        pVbles.setLayout(pVblesLayout);
        pVblesLayout.setHorizontalGroup(
            pVblesLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, pVblesLayout.createSequentialGroup()
                .add(jScrollPane1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 263, Short.MAX_VALUE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                .add(pVblesLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                    .add(bModificarVble, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 31, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(bEliminarVble, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 31, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(bNuevaVble, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 31, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
        );
        pVblesLayout.setVerticalGroup(
            pVblesLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(pVblesLayout.createSequentialGroup()
                .add(bNuevaVble, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 23, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(bModificarVble, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 23, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(bEliminarVble, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 23, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
            .add(jScrollPane1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 231, Short.MAX_VALUE)
        );

        org.jdesktop.layout.GroupLayout jPanel1Layout = new org.jdesktop.layout.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel1Layout.createSequentialGroup()
                .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(pSeleccionArticulo2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(pSeleccionArticulo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(pMedidas, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(pOpciones, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
            .add(jPanel1Layout.createSequentialGroup()
                .add(pVbles, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(pDespiece, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel1Layout.createSequentialGroup()
                .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jPanel1Layout.createSequentialGroup()
                        .add(pSeleccionArticulo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(pSeleccionArticulo2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                    .add(pMedidas, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(pOpciones, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(pDespiece, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .add(pVbles, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );

        jScrollPane3.setViewportView(jPanel1);

        org.jdesktop.layout.GroupLayout layout = new org.jdesktop.layout.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(layout.createSequentialGroup()
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(org.jdesktop.layout.GroupLayout.TRAILING, layout.createSequentialGroup()
                        .addContainerGap(637, Short.MAX_VALUE)
                        .add(bAceptar)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(bModificar, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 103, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(bCancelar))
                    .add(jScrollPane3, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 898, Short.MAX_VALUE))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(layout.createSequentialGroup()
                .add(jScrollPane3, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 491, Short.MAX_VALUE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(bCancelar)
                    .add(bModificar)
                    .add(bAceptar))
                .addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

private void bNuevaVbleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bNuevaVbleActionPerformed
    NuevaVariable nv = new NuevaVariable(this, "Variable - Creación");
    nv.setDefaultCloseOperation(NuevaVariable.DISPOSE_ON_CLOSE);
    nv.setVisible(true);
    nv.setLocationRelativeTo(null);
}//GEN-LAST:event_bNuevaVbleActionPerformed

private void bModificarVbleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bModificarVbleActionPerformed
    visualizarVariable();
}//GEN-LAST:event_bModificarVbleActionPerformed

    private void visualizarVariable() {
        int indice = tVbles.getSelectedRow();
        if (indice >= 0) {
            String nombre = (String) tVbles.getModel().getValueAt(indice, 0);
            int indiceVariable = obtenerIndiceVariable(nombre);
            Variable var = (Variable) listaVbles.get(indiceVariable);
            Variable aux = var.clonar();
            ArrayList<Seleccion> lSeleccion = this.obtenerSeleccionVbles(nombre);
            NuevaVariable nv = new NuevaVariable(this, "Variable - Modificación", aux, lSeleccion);
            nv.setDefaultCloseOperation(NuevaVariable.DISPOSE_ON_CLOSE);
            nv.setLocationRelativeTo(null);
            nv.setVisible(true);
        } else {
            JOptionPane.showMessageDialog(null, "No hay seleccionado ninguna variable", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void rellenarCombosColores() {
        List listaColores = BaseDatos.getListaColores();
        Iterator it = listaColores.iterator();
        Colores c;
        cLacado.addItem(Constantes.VACIO);
        cAccesorios.addItem(Constantes.VACIO);
        while (it.hasNext()) {
            c = (Colores) it.next();
            cLacado.addItem(c.getDescripcion());
            cAccesorios.addItem(c.getDescripcion());
        }
    }

    private ArrayList<Seleccion> obtenerSeleccionVbles(String nombre) {
        ArrayList<Seleccion> lres = new ArrayList<Seleccion>();
        Iterator iter = listaSeleccion.iterator();
        Seleccion sel;
        Variable var;
        while (iter.hasNext()) {
            sel = (Seleccion) iter.next();
            var = sel.getVariable();
            if (var.getNombre().equalsIgnoreCase(nombre)) {
                lres.add(sel);
            }
        }
        return lres;
    }

    public void eliminarSeleccion(String nombreVariable, String nombreSeleccion) {
        Iterator iter = listaSeleccion.iterator();
        Seleccion sel;
        Variable var;
        int indice = 0;
        int indiceBorrar = -1;
        while (iter.hasNext()) {
            sel = (Seleccion) iter.next();
            var = sel.getVariable();
            if (var.getNombre().equalsIgnoreCase(nombreVariable) && sel.getNombre().equalsIgnoreCase(nombreSeleccion)) {
                indiceBorrar = indice;
            }
            indice++;
        }
        if (indiceBorrar != -1) {
            listaSeleccion.remove(indiceBorrar);
        }
    }

private void bEliminarVbleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bEliminarVbleActionPerformed
    int indice = tVbles.getSelectedRow();
    if (indice >= 0) {
        int eliminar = 1;
        eliminar = JOptionPane.showConfirmDialog(null, "Está seguro de que desea eliminar el elemento seleccionado?", "¿Eliminar?", JOptionPane.YES_NO_OPTION);
        //hacerCambios = -1 ==> se ha pulsado la "x" de cancelar;
        //hacerCambios =  0 ==> se ha pulsado el "sí"
        //hacerCambios =  1 ==> se ha pulsado el "no"
        if (eliminar == 0) {
            String nombre = (String) tVbles.getModel().getValueAt(indice, 0);
            int indiceVariable = obtenerIndiceVariable(nombre);
            if (indiceVariable > -1) {
                listaVbles.remove(indiceVariable);
                actualizarListaVariables();
                actualizarListaDespiece();
            }
        }
    } else {
        JOptionPane.showMessageDialog(null, "No hay seleccionado ningún elemento", "Error", JOptionPane.ERROR_MESSAGE);
    }
}//GEN-LAST:event_bEliminarVbleActionPerformed

private void bCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bCancelarActionPerformed
    cerrarDac();
}//GEN-LAST:event_bCancelarActionPerformed

private void bAceptarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bAceptarActionPerformed
    try {
        String codigo = this.tCodigo.getText();
        String descripcion = this.tDescripcionDac.getText();

        if (codigo.length() > 0) {
            String colorLacadoStr = (String) cLacado.getSelectedItem();
            String colorAccesoriosStr = (String) cAccesorios.getSelectedItem();

            dac.setClacado(BaseDatos.obtenerColorPorDescripcion(colorLacadoStr));
            dac.setCaccesorios(BaseDatos.obtenerColorPorDescripcion(colorAccesoriosStr));
            dac.setArticulo(ar);
            dac.setDescripcion(descripcion);

            String medida1Str = this.tMedida1.getText();
            String medida2Str = this.tMedida2.getText();
            String medida3Str = this.tMedida3.getText();
            String medida4Str = this.tMedida4.getText();
            String medida5Str = this.tMedida5.getText();
            String cantidadStr = this.tCantidad.getText();

            if (medida1Str.length() == 0) {
                medida1Str = "0";
            }
            if (medida2Str.length() == 0) {
                medida2Str = "0";
            }
            if (medida3Str.length() == 0) {
                medida3Str = "0";
            }
            if (medida4Str.length() == 0) {
                medida4Str = "0";
            }
            if (medida5Str.length() == 0) {
                medida5Str = "0";
            }
            if (cantidadStr.length() == 0) {
                cantidadStr = "0";
            }

            dac.setMedida1(Double.valueOf(Util.convertirComaAPunto(medida1Str)));
            dac.setMedida2(Double.valueOf(Util.convertirComaAPunto(medida2Str)));
            dac.setMedida3(Double.valueOf(Util.convertirComaAPunto(medida3Str)));
            dac.setMedida4(Double.valueOf(Util.convertirComaAPunto(medida4Str)));
            dac.setMedida5(Double.valueOf(Util.convertirComaAPunto(medida5Str)));
            dac.setCantidad(Double.valueOf(Util.convertirComaAPunto(cantidadStr)));

            dac.setTipoPlantilla((String) cbPlantilla.getSelectedItem());
            dac.setLona(cbLona.isSelected());
            dac.setLonaDoble(cbLonaDoble.isSelected());
            dac.setPoleaDerecha(cbPoleaDerecha.isSelected());
            dac.setPoleaIzquierda(cbPoleaIzquierda.isSelected());
            dac.setMaquina(cbMaquina.isSelected());
            dac.setTerminal(cbTerminal.isSelected());
            dac.setSoporte(cbSoporte.isSelected());
            dac.setCasquillo(cbCasquillo.isSelected());
            dac.setTapa(cbTapa.isSelected());
            dac.setCarruchaSimple(cbCarruchaSimple.isSelected());
            dac.setCarruchaDoble(cbCarruchaDoble.isSelected());
            dac.setAtacuerda(cbAtacuerda.isSelected());
            dac.setAtacuerdaPared(cbAtacuerdaPared.isSelected());
            dac.setManivela(cbManivela.isSelected());
            dac.setGancho(cbGancho.isSelected());
            dac.setBambolina(cbBambolina.isSelected());
            dac.setPerfil(cbPerfil.isSelected());
            dac.setBrazo(cbBrazo.isSelected());
            dac.setMotor(cbMotor.isSelected());
            dac.setCofre(cbCofre.isSelected());
            dac.setForma(cbForma.isSelected());
            dac.setTuboEnrrolle(cbTuboEnrrolle.isSelected());
            dac.setPerfilCofre(cbPerfilCofre.isSelected());
            if (crear) {
                Dac temp = BaseDatos.obtenerDacPorCodigoArticulo(ar.getCod_articulo(), e.getIid());
                if (temp != null) {
                    JOptionPane.showMessageDialog(null, "El artículo seleccionado ya está relacionado con otro DAC", "Error", JOptionPane.ERROR_MESSAGE);
                } else if (BaseDatos.insertarDAC(dac, listaVbles, listaSeleccion, listaDespiece)) {
                    cerrarDac();
                } else {
                    JOptionPane.showMessageDialog(null, "No se ha podido insertar el DAC", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                Dac temp = null;

                if (!codigo.equalsIgnoreCase(codigoArticuloAntiguo)) {
                    temp = BaseDatos.obtenerDacPorCodigoArticulo(codigo, e.getIid());
                }

                if (temp != null) {
                    JOptionPane.showMessageDialog(null, "El artículo seleccionado ya está relacionado con otro DAC", "Error", JOptionPane.ERROR_MESSAGE);
                } else {
                    int hacerCambios = 1;

                    hacerCambios = JOptionPane.showConfirmDialog(null, "Está seguro de que desea realizar los cambios?", "¿Realizar cambios?", JOptionPane.YES_NO_OPTION);
                    //hacerCambios = -1 ==> se ha pulsado la "x" de cancelar;
                    //hacerCambios =  0 ==> se ha pulsado el "sí"
                    //hacerCambios =  1 ==> se ha pulsado el "no"
                    if (hacerCambios == 0) {
                        if (BaseDatos.modificarDAC(dac, listaVbles, listaSeleccion, listaDespiece)) {
                            cerrarDac();
                        } else {
                            JOptionPane.showMessageDialog(null, "No se ha podido modificar el DAC", "Error", JOptionPane.ERROR_MESSAGE);
                        }
                    }
                }
            }
        } else {
            //Error, debe rellenar los campos correspondientes
            JOptionPane.showMessageDialog(null, "Debe rellenar el campo Artículo", "Error", JOptionPane.ERROR_MESSAGE);
        }
    } catch (Exception ex) {
        log.error("Problemas extraños ", ex);
        JOptionPane.showMessageDialog(null, "Problemas extraños", "Error", JOptionPane.ERROR_MESSAGE);
    }
}//GEN-LAST:event_bAceptarActionPerformed

private void bModificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bModificarActionPerformed
    if (bModificar.getText().equals("Modificar")) {
        //Si el botón tiene el texto Modificar
        bSeleccionarArticulo.setEnabled(true);
        bNuevaVble.setEnabled(true);
        bEliminarVble.setEnabled(true);
        bModificarVble.setEnabled(true);
        tVbles.setEnabled(true);
        tDespiece.setEnabled(true);
        tMedida1.setEnabled(true);
        tMedida2.setEnabled(true);
        tMedida3.setEnabled(true);
        tMedida4.setEnabled(true);
        tMedida5.setEnabled(true);
        tCantidad.setEnabled(true);
        tDescripcionDac.setEnabled(true);
        cLacado.setEnabled(true);
        cAccesorios.setEnabled(true);
        bInsertar.setEnabled(true);
        bAñadir.setEnabled(true);
        bBajar.setEnabled(true);
        bBorrar.setEnabled(true);
        bSubir.setEnabled(true);
        bVerTodos.setEnabled(true);
        bModificarDespiece.setEnabled(true);
        bModificar.setText("Visualizar");
        bModificar.setToolTipText("Visualizar campos");
        cbPlantilla.setEnabled(true);
        cbPlantillaActionPerformed(null);
        URL urlModificar = getClass().getResource("/iconos/buscar.gif");
        ImageIcon iconoModificar = new ImageIcon(urlModificar);
        bModificar.setIcon(iconoModificar);

    } else {
        //si el botón tiene el texto Visualizar
        bSeleccionarArticulo.setEnabled(false);
        bNuevaVble.setEnabled(false);
        bEliminarVble.setEnabled(false);
        bModificarVble.setEnabled(false);
        tVbles.setEnabled(false);
        tDespiece.setEnabled(false);
        tMedida1.setEnabled(false);
        tMedida2.setEnabled(false);
        tMedida3.setEnabled(false);
        tMedida4.setEnabled(false);
        tMedida5.setEnabled(false);
        cLacado.setEnabled(false);
        tCantidad.setEnabled(false);
        tDescripcion.setEnabled(false);
        cAccesorios.setEnabled(false);
        bInsertar.setEnabled(false);
        bAñadir.setEnabled(false);
        bBajar.setEnabled(false);
        bBorrar.setEnabled(false);
        bSubir.setEnabled(false);
        bVerTodos.setEnabled(false);
        bModificarDespiece.setEnabled(false);
        cbPlantilla.setEnabled(false);
        cbLona.setEnabled(false);
        cbLonaDoble.setEnabled(false);
        cbPoleaIzquierda.setEnabled(false);
        cbPoleaDerecha.setEnabled(false);
        cbMaquina.setEnabled(false);
        cbSoporte.setEnabled(false);
        cbCasquillo.setEnabled(false);
        cbTerminal.setEnabled(false);
        cbTapa.setEnabled(false);
        cbCarruchaSimple.setEnabled(false);
        cbCarruchaDoble.setEnabled(false);
        cbAtacuerda.setEnabled(false);
        cbAtacuerdaPared.setEnabled(false);
        cbManivela.setEnabled(false);
        cbGancho.setEnabled(false);
        cbBambolina.setEnabled(false);
        cbPerfil.setEnabled(false);
        cbBrazo.setEnabled(false);
        cbMotor.setEnabled(false);
        cbCofre.setEnabled(false);
        cbForma.setEnabled(false);
        cbTuboEnrrolle.setEnabled(false);
        cbPerfilCofre.setEnabled(false);
        URL urlModificar = getClass().getResource("/iconos/editar.png");
        ImageIcon iconoModificar = new ImageIcon(urlModificar);
        bModificar.setIcon(iconoModificar);
        bModificar.setText("Modificar");
        bModificar.setToolTipText("Modificar campos");
    }
}//GEN-LAST:event_bModificarActionPerformed

private void tVblesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tVblesMouseClicked
    if (evt.getClickCount() == 2) {
        visualizarVariable();
    }
}//GEN-LAST:event_tVblesMouseClicked

private void tVblesKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tVblesKeyPressed
    if (evt.getKeyChar() == KeyEvent.VK_ENTER) {
        visualizarVariable();
    }
}//GEN-LAST:event_tVblesKeyPressed

private void bSeleccionarArticuloActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bSeleccionarArticuloActionPerformed
    SeleccionArticulosDac frame = new SeleccionArticulosDac(e, this, "SeleccionarArticulo");
    frame.setDefaultCloseOperation(SeleccionArticulosDac.DISPOSE_ON_CLOSE);
    frame.setLocationRelativeTo(null);
    frame.setVisible(true);
    frame = null;
}//GEN-LAST:event_bSeleccionarArticuloActionPerformed

    private void actualizarListaDespiece() {

        Modelo modeloTemp = (Modelo) this.tDespiece.getModel();
        int j = modeloTemp.getRowCount();
        for (int i = 0; i < j; i++) {
            modeloTemp.removeRow(0);
        }

        String sCantidad = getCantidad();
        Float cantidad;

        if (sCantidad.length() == 0) {
            cantidad = 0F;
        } else {
            cantidad = Float.valueOf(Util.convertirComaAPunto(sCantidad));
        }

        Despiece des;
        Object[] fila;
        Articulo articulo;
        Object oCantidad;
        FamiliaVenta fv;
        Iterator iter = listaDespiece.iterator();
        while (iter.hasNext()) {
            des = (Despiece) iter.next();
            articulo = BaseDatos.obtenerArticuloPorIid(des.getArticulo().getIid());
            fv = BaseDatos.obtenerFamiliaVentaPorIid(articulo.getIid_fam_venta().getIid());
            fila = new Object[4];
            if (fv.getNombre().equals(Constantes.NOMBRE_FAM_ESPECIFICACION)) {
                fila[0] = "1";
            } else {
                oCantidad = cantidad * evaluar(Util.convertirComaAPunto(des.getFormulaCantidad()), des.getRedondeo(), false);
                if (!oCantidad.toString().equals("0.0") || this.verTodos) {
                    fila[0] = Util.convertirPuntoAComa(String.valueOf(matematico.Matematico.redondear2decimales(Float.valueOf(String.valueOf(oCantidad.toString())))));
                    fila[3] = calcularMedida(des);
                }
            }
            fila[1] = articulo.getCod_articulo();
            fila[2] = articulo.getDes_inf();
            modeloTemp.addRow(fila);
        }
    }

    private String calcularMedida(Despiece des) {
        String res = "";
        int numMedidas = des.getNumeroDimensiones();

        if (numMedidas == 1) {
            res = "" + Util.convertirPuntoAComa(String.valueOf(evaluar(Util.convertirComaAPunto(des.getFormulaMedida1()), Constantes.DECIMALES2, false)));
        }

        if (numMedidas == 2) {
            res = Util.convertirPuntoAComa(String.valueOf(evaluar(Util.convertirComaAPunto(des.getFormulaMedida1()), Constantes.DECIMALES2, false))) + "x" + Util.convertirPuntoAComa(String.valueOf(evaluar(Util.convertirComaAPunto(des.getFormulaMedida2()), Constantes.DECIMALES2, false)));
        }

        if (numMedidas == 3) {
            res = Util.convertirPuntoAComa(String.valueOf(evaluar(Util.convertirComaAPunto(des.getFormulaMedida1()), Constantes.DECIMALES2, false))) + "x" + Util.convertirPuntoAComa(String.valueOf(evaluar(Util.convertirComaAPunto(des.getFormulaMedida2()), Constantes.DECIMALES2, false))) + "x" + Util.convertirPuntoAComa(String.valueOf(evaluar(Util.convertirComaAPunto(des.getFormulaMedida3()), Constantes.DECIMALES2, false)));
        }

        if (numMedidas == 4) {
            res = Util.convertirPuntoAComa(String.valueOf(evaluar(Util.convertirComaAPunto(des.getFormulaMedida1()), Constantes.DECIMALES2, false))) + "x" + Util.convertirPuntoAComa(String.valueOf(evaluar(Util.convertirComaAPunto(des.getFormulaMedida2()), Constantes.DECIMALES2, false))) + "x" + Util.convertirPuntoAComa(String.valueOf(evaluar(Util.convertirComaAPunto(des.getFormulaMedida3()), Constantes.DECIMALES2, false))) + "x" + Util.convertirPuntoAComa(String.valueOf(evaluar(Util.convertirComaAPunto(des.getFormulaMedida4()), Constantes.DECIMALES2, false)));
        }

        if (numMedidas == 5) {
            res = Util.convertirPuntoAComa(String.valueOf(evaluar(Util.convertirComaAPunto(des.getFormulaMedida1()), Constantes.DECIMALES2, false))) + "x" + Util.convertirPuntoAComa(String.valueOf(evaluar(Util.convertirComaAPunto(des.getFormulaMedida2()), Constantes.DECIMALES2, false))) + "x" + Util.convertirPuntoAComa(String.valueOf(evaluar(Util.convertirComaAPunto(des.getFormulaMedida3()), Constantes.DECIMALES2, false))) + "x" + Util.convertirPuntoAComa(String.valueOf(evaluar(Util.convertirComaAPunto(des.getFormulaMedida4()), Constantes.DECIMALES2, false))) + "x" + Util.convertirPuntoAComa(String.valueOf(evaluar(Util.convertirComaAPunto(des.getFormulaMedida5()), Constantes.DECIMALES2, false)));
        }

        return res;
    }

private void bSubirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bSubirActionPerformed
    int indice = this.tDespiece.getSelectedRow();
    if (indice > 0) {
        //Si hay alguno seleccionado se habrá de subir y cambiar su posicion en la lista de despiece
        Modelo modelo = (Modelo) tDespiece.getModel();
        modelo.moveRow(indice, indice, indice - 1);
        tDespiece.setRowSelectionInterval(indice - 1, indice - 1);

        Despiece despieceOrigen = new Despiece(this.listaDespiece.get(indice));
        despieceOrigen.setOrden(indice - 1);
        listaDespiece.remove(indice);
        listaDespiece.add(indice - 1, despieceOrigen);
        actualizarIndicesSecuencialesDespieces();
    }
}//GEN-LAST:event_bSubirActionPerformed

private void bBajarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bBajarActionPerformed
    int indice = this.tDespiece.getSelectedRow();
    Modelo modelo = (Modelo) tDespiece.getModel();

    if (indice > -1 && indice < modelo.getRowCount() - 1) {
        //Si hay alguno seleccionado se habrá de bajar y cambiar su posicion en la lista de despiece
        modelo.moveRow(indice, indice, indice + 1);
        tDespiece.setRowSelectionInterval(indice + 1, indice + 1);

        Despiece despieceOrigen = new Despiece(this.listaDespiece.get(indice));
        despieceOrigen.setOrden(indice + 1);
        listaDespiece.remove(indice);
        listaDespiece.add(indice + 1, despieceOrigen);
        actualizarIndicesSecuencialesDespieces();
    }
}//GEN-LAST:event_bBajarActionPerformed

private void bAñadirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bAñadirActionPerformed
    //Se inserta al final
    insertarDespiecePosicion(listaDespiece.size());
}//GEN-LAST:event_bAñadirActionPerformed

private void bInsertarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bInsertarActionPerformed
    //Se inserta despues del seleccionado
    if (listaDespiece.size() > 0) {
        int indice = this.tDespiece.getSelectedRow();
        if (indice != -1) {
            insertarDespiecePosicion(indice);
        } else {
            JOptionPane.showMessageDialog(null, "Debe seleccionar un elemento de la lista", "Error", JOptionPane.ERROR_MESSAGE);
        }
    } else {
        insertarDespiecePosicion(0);
    }
}//GEN-LAST:event_bInsertarActionPerformed

    private void insertarDespiecePosicion(int posicion) {
        Despiece despiece = new Despiece();
        despiece.setOrden(posicion);
        NuevoArticuloOpcion nao = new NuevoArticuloOpcion(e, dac, this, despiece);
        nao.setDefaultCloseOperation(NuevoArticuloOpcion.DISPOSE_ON_CLOSE);
        nao.setLocationRelativeTo(null);
        nao.setVisible(true);
    }

private void bModificarDespieceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bModificarDespieceActionPerformed
    modificarDespiece();
}//GEN-LAST:event_bModificarDespieceActionPerformed

    private void modificarDespiece() {
        Despiece despiece = null;
        int indice = this.tDespiece.getSelectedRow();

        if (indice < 0) {
            JOptionPane.showMessageDialog(null, "Debe seleccionar un elemento de la lista", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            despiece = listaDespiece.get(indice);
            despiece = new Despiece(despiece);

            Articulo art = BaseDatos.obtenerArticuloPorIid(despiece.getArticulo().getIid());
            NuevoArticuloOpcion nao = new NuevoArticuloOpcion(e, dac, art, despiece.getCaracteristica(), this, despiece);

            nao.setDefaultCloseOperation(NuevoArticuloOpcion.DISPOSE_ON_CLOSE);
            nao.setLocationRelativeTo(null);
            nao.setVisible(true);
        }
    }

private void bBorrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bBorrarActionPerformed
    int indice = this.tDespiece.getSelectedRow();
    if (indice > -1 && indice < tDespiece.getRowCount()) {
        Modelo modelo = (Modelo) tDespiece.getModel();
        modelo.removeRow(indice);
        Despiece d = listaDespiece.get(indice);
        listaDespiece.remove(indice);
        actualizarIndicesSecuencialesDespieces();

    }
}//GEN-LAST:event_bBorrarActionPerformed

    private void resetearTipoArticuloDespiece(String tipoArticuloDespiece, String tipoArticuloDespieceAntiguo) {
        if (this.listaDespiece == null) {
            listaDespiece = new ArrayList<Despiece>();
        }

        Iterator iter = listaDespiece.iterator();
        Despiece temporal;
        while (iter.hasNext()) {
            temporal = (Despiece) iter.next();
            if (temporal.getTipoArticulo().equals(tipoArticuloDespiece) || temporal.getTipoArticulo().equals(tipoArticuloDespieceAntiguo)) {
                temporal.setTipoArticulo("");
            }
        }
    }

    private void resetearTipoArticuloDespiece(String tipoArticuloDespiece) {
        if (this.listaDespiece == null) {
            listaDespiece = new ArrayList<Despiece>();
        }

        Iterator iter = listaDespiece.iterator();
        Despiece temporal;
        while (iter.hasNext()) {
            temporal = (Despiece) iter.next();
            if (temporal.getTipoArticulo().equals(tipoArticuloDespiece)) {
                temporal.setTipoArticulo("");
            }
        }
    }

    private void actualizarIndicesSecuencialesDespieces() {
        if (this.listaDespiece == null) {
            listaDespiece = new ArrayList<Despiece>();
        }

        Iterator iter = listaDespiece.iterator();
        Despiece temporal;
        int contador = 0;
        while (iter.hasNext()) {
            temporal = (Despiece) iter.next();
            temporal.setOrden(contador);
            contador++;
        }
    }

private void bVerTodosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bVerTodosActionPerformed
    this.verTodos = !this.verTodos;
    this.actualizarListaDespiece();
}//GEN-LAST:event_bVerTodosActionPerformed

private void tCantidadKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tCantidadKeyReleased
    int tamaño = tCantidad.getText().length();
    if (tamaño > 0) {
        char c = tCantidad.getText().charAt(tamaño - 1);

        if (c == '.') {
            String contenidoAntiguo = tCantidad.getText().replace(".", ",");
            tCantidad.setText(contenidoAntiguo);
            c = ',';
        }

        if (!((c >= '0' && c <= '9') || c == ',')) {
            String str = tCantidad.getText().substring(0, tamaño - 1);
            tCantidad.setText(str);
        } else if (c == ',') {
            int indicePunto = tCantidad.getText().indexOf(',');
            if (indicePunto != (tamaño - 1)) {
                String str = tCantidad.getText().substring(0, tamaño - 1);
                tCantidad.setText(str);
            }
        }
    }
    engineGlobal.put("Cantidad", Double.valueOf(tCantidad.getText()));
    actualizarListaVariables();
    actualizarListaDespiece();
}//GEN-LAST:event_tCantidadKeyReleased

private void tMedida1KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tMedida1KeyReleased
    int tamaño = tMedida1.getText().length();
    if (tamaño > 0) {
        char c = tMedida1.getText().charAt(tamaño - 1);

        if (c == '.') {
            String contenidoAntiguo = tMedida1.getText().replace(".", ",");
            tMedida1.setText(contenidoAntiguo);
            c = ',';
        }

        if (!((c >= '0' && c <= '9') || c == ',')) {
            String str = tMedida1.getText().substring(0, tamaño - 1);
            tMedida1.setText(str);
        } else if (c == ',') {
            int indicePunto = tMedida1.getText().indexOf(',');
            if (indicePunto != (tamaño - 1)) {
                String str = tMedida1.getText().substring(0, tamaño - 1);
                tMedida1.setText(str);
            }
        }
    }
    engineGlobal.put("Dim1", Double.valueOf(tMedida1.getText()));
    actualizarListaVariables();
    actualizarListaDespiece();
}//GEN-LAST:event_tMedida1KeyReleased

private void tMedida2KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tMedida2KeyReleased
    int tamaño = tMedida2.getText().length();
    if (tamaño > 0) {
        char c = tMedida2.getText().charAt(tamaño - 1);

        if (c == '.') {
            String contenidoAntiguo = tMedida2.getText().replace(".", ",");
            tMedida2.setText(contenidoAntiguo);
            c = ',';
        }

        if (!((c >= '0' && c <= '9') || c == ',')) {
            String str = tMedida2.getText().substring(0, tamaño - 1);
            tMedida2.setText(str);
        } else if (c == ',') {
            int indicePunto = tMedida2.getText().indexOf(',');
            if (indicePunto != (tamaño - 1)) {
                String str = tMedida2.getText().substring(0, tamaño - 1);
                tMedida2.setText(str);
            }
        }
    }
    engineGlobal.put("Dim2", Double.valueOf(tMedida2.getText()));
    actualizarListaVariables();
    actualizarListaDespiece();
}//GEN-LAST:event_tMedida2KeyReleased

private void tMedida3KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tMedida3KeyReleased
    int tamaño = tMedida3.getText().length();
    if (tamaño > 0) {
        char c = tMedida3.getText().charAt(tamaño - 1);

        if (c == '.') {
            String contenidoAntiguo = tMedida3.getText().replace(".", ",");
            tMedida3.setText(contenidoAntiguo);
            c = ',';
        }

        if (!((c >= '0' && c <= '9') || c == ',')) {
            String str = tMedida3.getText().substring(0, tamaño - 1);
            tMedida3.setText(str);
        } else if (c == ',') {
            int indicePunto = tMedida3.getText().indexOf(',');
            if (indicePunto != (tamaño - 1)) {
                String str = tMedida3.getText().substring(0, tamaño - 1);
                tMedida3.setText(str);
            }
        }
    }
    engineGlobal.put("Dim3", Double.valueOf(tMedida3.getText()));
    actualizarListaVariables();
    actualizarListaDespiece();
}//GEN-LAST:event_tMedida3KeyReleased

private void tMedida4KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tMedida4KeyReleased
    int tamaño = tMedida4.getText().length();
    if (tamaño > 0) {
        char c = tMedida4.getText().charAt(tamaño - 1);

        if (c == '.') {
            String contenidoAntiguo = tMedida4.getText().replace(".", ",");
            tMedida4.setText(contenidoAntiguo);
            c = ',';
        }

        if (!((c >= '0' && c <= '9') || c == ',')) {
            String str = tMedida4.getText().substring(0, tamaño - 1);
            tMedida4.setText(str);
        } else if (c == ',') {
            int indicePunto = tMedida4.getText().indexOf(',');
            if (indicePunto != (tamaño - 1)) {
                String str = tMedida4.getText().substring(0, tamaño - 1);
                tMedida4.setText(str);
            }
        }
    }
    engineGlobal.put("Dim4", Double.valueOf(tMedida4.getText()));
    actualizarListaVariables();
    actualizarListaDespiece();
}//GEN-LAST:event_tMedida4KeyReleased

private void tMedida5KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tMedida5KeyReleased
    int tamaño = tMedida5.getText().length();
    if (tamaño > 0) {
        char c = tMedida5.getText().charAt(tamaño - 1);

        if (c == '.') {
            String contenidoAntiguo = tMedida5.getText().replace(".", ",");
            tMedida5.setText(contenidoAntiguo);
            c = ',';
        }

        if (!((c >= '0' && c <= '9') || c == ',')) {
            String str = tMedida5.getText().substring(0, tamaño - 1);
            tMedida5.setText(str);
        } else if (c == ',') {
            int indicePunto = tMedida5.getText().indexOf(',');
            if (indicePunto != (tamaño - 1)) {
                String str = tMedida5.getText().substring(0, tamaño - 1);
                tMedida5.setText(str);
            }
        }
    }
    engineGlobal.put("Dim5", Double.valueOf(tMedida5.getText()));
    actualizarListaVariables();
    actualizarListaDespiece();
}//GEN-LAST:event_tMedida5KeyReleased

private void tDespieceMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tDespieceMouseClicked
    if (evt.getClickCount() == 2) {
        modificarDespiece();
    }
}//GEN-LAST:event_tDespieceMouseClicked

private void tDescripcionDacKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tDescripcionDacKeyReleased
    String descripcionDac = tDescripcionDac.getText();
    if (descripcionDac.length() > Constantes.TAM_DESCRIPCION_DAC) {
        JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_DESCRIPCION_DAC, "Error", JOptionPane.ERROR_MESSAGE);
        tDescripcionDac.setText(descripcionDac.substring(0, Constantes.TAM_DESCRIPCION_DAC));
    }
}//GEN-LAST:event_tDescripcionDacKeyReleased

private void cbPlantillaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbPlantillaActionPerformed
    String plantillaSeleccionada = (String) cbPlantilla.getSelectedItem();
    if (plantillaSeleccionada != null) {
        if (plantillaSeleccionada.equals(Constantes.PLANTILLA_TOLDO_ENRROLLADO)) {
            habilitarCheckToldoEnrrolado();
        } else if (plantillaSeleccionada.equals(Constantes.PLANTILLA_TOLDO_PLANO)) {
            habilitarCheckToldoPlano();
        } else if (plantillaSeleccionada.equals(Constantes.PLANTILLA_TOLDO_GENERAL)) {
            habilitarCheckToldoGeneral();
        }
    } else {
        cbPlantilla.setSelectedItem(Constantes.PLANTILLA_TOLDO_GENERAL);
    }
}//GEN-LAST:event_cbPlantillaActionPerformed

private void cLacadoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cLacadoActionPerformed
    if (listaDespiece != null && listaDespiece.size() > 0) {
        Colores colorLacado = BaseDatos.obtenerColorPorDescripcion((String) cLacado.getSelectedItem());
        Despiece temp;
        Iterator iter = listaDespiece.iterator();
        Articulo artTemp;
        Caracteristica carTemp, carAux;
        FamiliaVenta fv;
        StringBuffer buffer = new StringBuffer();

        while (iter.hasNext()) {
            temp = (Despiece) iter.next();
            artTemp = temp.getArticulo();
            artTemp = BaseDatos.obtenerArticuloPorIid(artTemp.getIid());
            carTemp = temp.getCaracteristica();

            if (carTemp != null) {
                carTemp = BaseDatos.obtenerCaracteristicaPorIid(carTemp.getIid());

                if (artTemp.getMonocromo() != null && artTemp.getMonocromo() && Constantes.DESC_COLOR_BLANCO.equalsIgnoreCase((String) cLacado.getSelectedItem())) {
                    colorLacado = BaseDatos.obtenerColorPorDescripcion(Constantes.DESC_COLOR_BLANCO);
                } else if (artTemp.getMonocromo() != null && artTemp.getMonocromo()) {
                    colorLacado = BaseDatos.obtenerColorPorDescripcion(Constantes.DESC_COLOR_NEGRO);
                }

                carAux = BaseDatos.obtenerCaracteristica(artTemp, e, colorLacado);
                fv = BaseDatos.obtenerFamiliaVentaPorIid(artTemp.getIid_fam_venta().getIid());
                
                if (fv.getRecortable() != null && fv.getRecortable() && carAux != null) {
                    temp.setCaracteristica(carAux);
                    temp.setColor(colorLacado);
                } else if (fv.getRecortable() != null && fv.getRecortable()) {
                    buffer.append("El artículo ");
                    buffer.append(artTemp.getCod_articulo());
                    buffer.append(" no posee la característica ");
                    buffer.append(colorLacado.getDescripcion());
                    buffer.append(".\n");
                }
            }
        }
        String mensajeMostrar = buffer.toString();
        if (mensajeMostrar.length() != 0) {
            JOptionPane.showMessageDialog(null, mensajeMostrar, "Información", JOptionPane.INFORMATION_MESSAGE);
        }
    }
}//GEN-LAST:event_cLacadoActionPerformed

private void cAccesoriosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cAccesoriosActionPerformed
    if (listaDespiece != null && listaDespiece.size() > 0) {

        Colores colorAccesorio = BaseDatos.obtenerColorPorDescripcion((String) cAccesorios.getSelectedItem());
        Despiece temp;
        Iterator iter = listaDespiece.iterator();
        Articulo artTemp;
        Caracteristica carTemp, carAux;
        FamiliaVenta fv;
        StringBuffer buffer = new StringBuffer();
        while (iter.hasNext()) {
            temp = (Despiece) iter.next();
            artTemp = temp.getArticulo();
            artTemp = BaseDatos.obtenerArticuloPorIid(artTemp.getIid());
            carTemp = temp.getCaracteristica();

            if (carTemp != null) {
                carTemp = BaseDatos.obtenerCaracteristicaPorIid(carTemp.getIid());

                if (artTemp.getMonocromo() != null && artTemp.getMonocromo() && Constantes.DESC_COLOR_BLANCO.equalsIgnoreCase((String) cAccesorios.getSelectedItem())) {
                    colorAccesorio = BaseDatos.obtenerColorPorDescripcion(Constantes.DESC_COLOR_BLANCO);
                } else if (artTemp.getMonocromo() != null && artTemp.getMonocromo()) {
                    colorAccesorio = BaseDatos.obtenerColorPorDescripcion(Constantes.DESC_COLOR_NEGRO);
                }

                carAux = BaseDatos.obtenerCaracteristica(artTemp, e, colorAccesorio);
                fv = artTemp.getIid_fam_venta();
                fv = BaseDatos.obtenerFamiliaVentaPorIid(fv.getIid());
                if ((fv.getRecortable() == null || !fv.getRecortable()) && carAux != null) {
                    temp.setCaracteristica(carAux);
                    temp.setColor(colorAccesorio);
                } else if (fv.getRecortable() == null || !fv.getRecortable()) {
                    buffer.append("El artículo ");
                    buffer.append(artTemp.getCod_articulo());
                    buffer.append(" no posee la característica ");
                    buffer.append(colorAccesorio.getDescripcion());
                    buffer.append(".\n");
                }
            }
        }

        String mensajeMostrar = buffer.toString();
        if (mensajeMostrar.length() != 0) {
            JOptionPane.showMessageDialog(null, mensajeMostrar, "Información", JOptionPane.INFORMATION_MESSAGE);
        }
    }
}//GEN-LAST:event_cAccesoriosActionPerformed
    private void habilitarCheckToldoGeneral() {
        cbLona.setEnabled(true);
        cbLonaDoble.setEnabled(true);
        cbPoleaIzquierda.setEnabled(true);
        cbPoleaDerecha.setEnabled(true);
        cbMaquina.setEnabled(true);
        cbSoporte.setEnabled(true);
        cbCasquillo.setEnabled(true);
        cbTerminal.setEnabled(true);
        cbTapa.setEnabled(true);
        cbCarruchaSimple.setEnabled(true);
        cbCarruchaDoble.setEnabled(true);
        cbAtacuerda.setEnabled(true);
        cbAtacuerdaPared.setEnabled(true);
        cbManivela.setEnabled(true);
        cbGancho.setEnabled(true);
        cbBambolina.setEnabled(true);
        cbPerfil.setEnabled(true);
        cbBrazo.setEnabled(true);
        cbMotor.setEnabled(true);
        cbCofre.setEnabled(true);
        cbForma.setEnabled(true);
        cbTuboEnrrolle.setEnabled(true);
        cbPerfilCofre.setEnabled(true);
    }

    private void habilitarCheckToldoEnrrolado() {
        cbLona.setEnabled(true);
        cbLonaDoble.setEnabled(false);
        cbLonaDoble.setSelected(false);
        cbPoleaIzquierda.setEnabled(false);
        cbPoleaIzquierda.setSelected(false);
        cbPoleaDerecha.setEnabled(false);
        cbPoleaDerecha.setSelected(false);
        cbMaquina.setEnabled(true);
        cbSoporte.setEnabled(true);
        cbCasquillo.setEnabled(true);
        cbTerminal.setEnabled(true);
        cbTapa.setEnabled(true);
        cbCarruchaSimple.setEnabled(false);
        cbCarruchaSimple.setSelected(false);
        cbCarruchaDoble.setEnabled(false);
        cbCarruchaDoble.setSelected(false);
        cbAtacuerda.setEnabled(false);
        cbAtacuerda.setSelected(false);
        cbAtacuerdaPared.setEnabled(false);
        cbAtacuerdaPared.setSelected(false);
        cbManivela.setEnabled(true);
        cbGancho.setEnabled(false);
        cbGancho.setSelected(false);
        cbBambolina.setEnabled(true);
        cbPerfil.setEnabled(true);
        cbBrazo.setEnabled(true);
        cbMotor.setEnabled(true);
        cbCofre.setEnabled(true);
        cbForma.setEnabled(true);
        cbTuboEnrrolle.setEnabled(true);
        cbPerfilCofre.setEnabled(true);
    }

    private void habilitarCheckToldoPlano() {
        cbLona.setEnabled(true);
        cbLonaDoble.setEnabled(true);
        cbPoleaIzquierda.setEnabled(true);
        cbPoleaDerecha.setEnabled(true);
        cbMaquina.setEnabled(false);
        cbMaquina.setSelected(false);
        cbSoporte.setEnabled(false);
        cbSoporte.setSelected(false);
        cbCasquillo.setEnabled(false);
        cbCasquillo.setSelected(false);
        cbTerminal.setEnabled(false);
        cbTerminal.setSelected(false);
        cbTapa.setEnabled(false);
        cbTapa.setSelected(false);
        cbCarruchaSimple.setEnabled(true);
        cbCarruchaDoble.setEnabled(true);
        cbAtacuerda.setEnabled(true);
        cbAtacuerdaPared.setEnabled(true);
        cbManivela.setEnabled(false);
        cbManivela.setSelected(false);
        cbGancho.setEnabled(true);
        cbBambolina.setEnabled(true);
        cbPerfil.setEnabled(true);
        cbBrazo.setEnabled(false);
        cbBrazo.setSelected(false);
        cbMotor.setEnabled(false);
        cbMotor.setSelected(false);
        cbCofre.setEnabled(false);
        cbCofre.setSelected(false);
        cbForma.setEnabled(true);
        cbTuboEnrrolle.setEnabled(false);
        cbPerfilCofre.setEnabled(false);
    }

    protected Integer obtenerIndiceDespiece(String tipoArticulo) {
        Integer res = null;
        Iterator iter = listaDespiece.iterator();
        boolean seguir = true;
        int indice = 0;
        Despiece temp = null;
        while (iter.hasNext() && seguir) {
            temp = (Despiece) iter.next();
            if (temp.getTipoArticulo().equals(tipoArticulo)) {
                seguir = false;
            } else {
                indice++;
            }
        }

        if (!seguir) {
            res = indice;
        }

        return res;
    }

    public void resetarTipoDespiece(String tipoArticulo) {
        Iterator iter = listaDespiece.iterator();
        boolean seguir = true;
        Despiece temp = null;
        while (iter.hasNext() && seguir) {
            temp = (Despiece) iter.next();
            if (temp.getTipoArticulo().equals(tipoArticulo)) {
                temp.setTipoArticulo("");
            }
        }
    }

    protected void modificarDespiece(Despiece despiece, boolean crear) {
        String tipo = despiece.getTipoArticulo();
        if (tipo.length() != 0) {
            resetearTipoArticuloDespiece(tipo);
        }
        listaDespiece.add(despiece.getOrden(), despiece);
        if (!crear) {
            listaDespiece.remove(despiece.getOrden() + 1);
        }
        actualizarIndicesSecuencialesDespieces();
        actualizarListaDespiece();
    }

    protected void modificarDespiece(Despiece despiece, boolean modificarDespiece, String tipoArticuloAntiguo) {

        String tipo = despiece.getTipoArticulo();
        if (despiece.getOrden() != null) {
            int orden = despiece.getOrden();
            listaDespiece.remove(orden);
            if (tipo.length() != 0) {
                resetearTipoArticuloDespiece(tipo, tipoArticuloAntiguo);
            }
            listaDespiece.add(despiece.getOrden(), despiece);
        } else {
            if (tipo.length() != 0) {
                resetearTipoArticuloDespiece(tipo, tipoArticuloAntiguo);
            }
            listaDespiece.add(despiece);
        }
        actualizarIndicesSecuencialesDespieces();
        actualizarListaDespiece();
    }

    protected boolean modificarVariable(Variable var) {
        boolean res = true;
        int indice = tVbles.getSelectedRow();
        String nombre = (String) tVbles.getModel().getValueAt(indice, 0);
        int indiceVariable = obtenerIndiceVariable(nombre);

        cambiarNombreSeleccion(nombre, var.getNombre());

        if (listaVbles.contains(var) && !nombre.equals(var.getNombre())) {
            res = false;
            JOptionPane.showMessageDialog(null, "La variable ya existe", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            listaVbles.remove(indiceVariable);
            listaVbles.add(indiceVariable, var);
            actualizarListaVariables();
            actualizarListaDespiece();
        }
        return res;
    }

    private void cambiarNombreSeleccion(String nombreAntiguo, String nombreNuevo) {
        Iterator iter = this.listaSeleccion.iterator();
        Seleccion temp;
        while (iter.hasNext()) {
            temp = (Seleccion) iter.next();
            if (temp.getVariable().getNombre().equals(nombreAntiguo)) {
                temp.getVariable().setNombre(nombreNuevo);
            }
        }
    }

    protected boolean insertarVariable(Variable var) {
        boolean res = true;
        if (listaVbles.contains(var)) {
            //Si no se ha insertado mostramos un mensaje de error
            JOptionPane.showMessageDialog(null, "Esta variable ya existe", "Error", JOptionPane.ERROR_MESSAGE);
            res = false;
        } else {
            listaVbles.add(var);
            actualizarListaVariables();
        }
        return res;
    }

    protected void insertarSeleccion(Seleccion sel) {
        listaSeleccion.add(sel);
    }

    private void actualizarListaVariables() {
        Modelo modelo = (Modelo) tVbles.getModel();
        Variable var;
        String nombre;
        Double valor;
        
        int i,  j = modelo.getRowCount();
        for (i = 0; i < j; i++) {
            modelo.removeRow(0);
        }
        
        for (Iterator it = listaVbles.iterator(); it.hasNext();) {
            Object[] fila = new Object[2];
            var = (Variable) it.next();
            nombre = var.getNombre();
            valor = calcularValor(var);
            engineGlobal.put(nombre, valor);
            try {
                fila[0] = var.getNombre();
                fila[1] = Util.convertirPuntoAComa(String.valueOf(valor));
                modelo.addRow(fila);
            } catch (Exception ex) {
                log.error("Error al actualizar la lista de variables ", ex);
                ex.printStackTrace();
            }
        }
    }

    public Double calcularValor(Variable var) {
        Double res = 0D;
        if (var.getTipo().equals(Constantes.NUMERICA)) {
            res = var.getValor();
        } else if (var.getTipo().equals(Constantes.CALCULADA)) {
            Double valorFormula = evaluar(var.getFormula(), Constantes.DECIMALES2, true);

            if (var.getActivarMaximo() && var.getValorMinimo() > valorFormula) {
                valorFormula = var.getValorMinimo();
            } else if (var.getActivarMaximo() && var.getValorMaximo() < valorFormula) {
                valorFormula = var.getValorMaximo();
            }

            res = valorFormula;

        } else {
            //Hay que buscar las seleccion de la variable y obtener la que esté a seleccionada
            Iterator iter = this.listaSeleccion.iterator();
            boolean seguir = true;
            Seleccion tempSel;
            Variable tempVar;
            while (seguir && iter.hasNext()) {
                tempSel = (Seleccion) iter.next();
                tempVar = tempSel.getVariable();

                if (tempVar.getNombre().equals(var.getNombre())) {
                    if (tempSel.getSeleccionada()) {
                        seguir = false;
                        res = tempSel.getValor();
                    }
                }
            }
        }
        return res;
    }

    private int obtenerIndiceVariable(String nombre) {
        boolean seguir = true;
        int res = 0;
        int tam = listaVbles.size();
        Variable aux;
        while (seguir && res < tam) {
            aux = (Variable) listaVbles.get(res);
            if (aux.getNombre().equalsIgnoreCase(nombre)) {
                seguir = false;
            } else {
                res++;
            }
        }

        if (seguir) {
            res = -1;
        }
        return res;
    }

    public void rellenarArticulo(Articulo ar) {
        this.ar = ar;
        tCodigo.setText(ar.getCod_articulo());
        tDescripcion.setText(ar.getDes_inf());

        FamiliaVenta fv = ar.getIid_fam_venta();
        fv = BaseDatos.obtenerFamiliaVentaPorIid(fv.getIid());
        if (!fv.getNombre().equalsIgnoreCase(Constantes.NOMBRE_FAM_ESPECIFICACION)) {
            //Actualizar las medidas
            TipoControl tc = fv.getIid_tipo_control();
            if (tc != null) {
                UnidadMedida um;
                TipoMedida tm = BaseDatos.obtenerTipoMedidaByIid(tc.getIid_tipo_medida().getIid());

                this.tCantidad.setText("0");

                if (tc.getUnidad1() != null) {
                    um = BaseDatos.obtenerUnidadMedidaIid(tc.getUnidad1().getIid());
                    if (um != null) {
                        lUnidad1.setText(tm.getNombre_dim_1());
                        lMagnitud1.setText(um.getCod_unidad_medida());
                        tMedida1.setText("100");
                        lUnidad1.setVisible(true);
                        lMagnitud1.setVisible(true);
                        tMedida1.setVisible(true);
                    }
                } else {
                    lUnidad1.setVisible(false);
                    lMagnitud1.setVisible(false);
                    tMedida1.setVisible(false);
                }
                if (tc.getUnidad2() != null) {
                    um = BaseDatos.obtenerUnidadMedidaIid(tc.getUnidad2().getIid());
                    if (um != null) {
                        lUnidad2.setText(tm.getNombre_dim_2());
                        lMagnitud2.setText(um.getCod_unidad_medida());
                        tMedida2.setText("100");
                        lUnidad2.setVisible(true);
                        lMagnitud2.setVisible(true);
                        tMedida2.setVisible(true);
                    }
                } else {
                    lUnidad2.setVisible(false);
                    lMagnitud2.setVisible(false);
                    tMedida2.setVisible(false);
                }
                if (tc.getUnidad3() != null) {
                    um = BaseDatos.obtenerUnidadMedidaIid(tc.getUnidad3().getIid());
                    if (um != null) {
                        lUnidad3.setText(tm.getNombre_dim_3());
                        lMagnitud3.setText(um.getCod_unidad_medida());
                        tMedida3.setText("100");
                        lUnidad3.setVisible(true);
                        lMagnitud3.setVisible(true);
                        tMedida3.setVisible(true);
                    }
                } else {
                    lUnidad3.setVisible(false);
                    lMagnitud3.setVisible(false);
                    tMedida3.setVisible(false);
                }
                if (tc.getUnidad4() != null) {
                    um = BaseDatos.obtenerUnidadMedidaIid(tc.getUnidad4().getIid());
                    if (um != null) {
                        lUnidad4.setText(tm.getNombre_dim_4());
                        lMagnitud4.setText(um.getCod_unidad_medida());
                        tMedida4.setText("100");
                        lUnidad4.setVisible(true);
                        lMagnitud4.setVisible(true);
                        tMedida4.setVisible(true);
                    }
                } else {
                    lUnidad4.setVisible(false);
                    lMagnitud4.setVisible(false);
                    tMedida4.setVisible(false);
                }
                if (tc.getUnidad5() != null) {
                    um = BaseDatos.obtenerUnidadMedidaIid(tc.getUnidad5().getIid());
                    if (um != null) {
                        lUnidad5.setText(tm.getNombre_dim_5());
                        lMagnitud5.setText(um.getCod_unidad_medida());
                        tMedida5.setText("100");
                        lUnidad5.setVisible(true);
                        lMagnitud5.setVisible(true);
                        tMedida5.setVisible(true);
                    }
                } else {
                    lUnidad5.setVisible(false);
                    lMagnitud5.setVisible(false);
                    tMedida5.setVisible(false);
                }
            }
        }
    }

    public int getNumeroDimensiones() {
        int numMedidas = 5;

        if (this.ar != null) {
            FamiliaVenta fv = BaseDatos.obtenerFamiliaVentaPorIid(this.ar.getIid_fam_venta().getIid());
            if (fv != null) {
                TipoControl tc = fv.getIid_tipo_control();
                tc = BaseDatos.obtenerTipoControl(tc.getCodigo());

                if (tc != null) {
                    TipoMedida tm = tc.getIid_tipo_medida();
                    tm = BaseDatos.obtenerTipoMedidaByIid(tm.getIid());
                    numMedidas = tm.getNum_dimensiones();
                }
            }
        }

        return numMedidas;
    }

    private String getCantidad() {
        if (this.tCantidad.getText() != null && this.tCantidad.getText().length() != 0) {
            return this.tCantidad.getText();
        } else {
            return "0";
        }
    }

    private String getDim1() {
        if (this.tMedida1.isVisible()) {
            if (this.tMedida1.getText() != null && this.tMedida1.getText().length() != 0) {
                return this.tMedida1.getText();
            } else {
                return "0";
            }
        } else {
            return "0";
        }
    }

    private String getDim2() {
        if (this.tMedida2.isVisible()) {
            if (this.tMedida2.getText() != null && this.tMedida2.getText().length() != 0) {
                return this.tMedida2.getText();
            } else {
                return "0";
            }
        } else {
            return "0";
        }
    }

    private String getDim3() {
        if (this.tMedida3.isVisible()) {
            if (this.tMedida3.getText() != null && this.tMedida3.getText().length() != 0) {
                return this.tMedida3.getText();
            } else {
                return "0";
            }
        } else {
            return "0";
        }
    }

    private String getDim4() {
        if (this.tMedida4.isVisible()) {
            if (this.tMedida4.getText() != null && this.tMedida4.getText().length() != 0) {
                return this.tMedida4.getText();
            } else {
                return "0";
            }
        } else {
            return "0";
        }
    }

    private String getDim5() {
        if (this.tMedida5.isVisible()) {
            if (this.tMedida5.getText() != null && this.tMedida5.getText().length() != 0) {
                return this.tMedida5.getText();
            } else {
                return "0";
            }
        } else {
            return "0";
        }
    }

    public List<Variable> getListaVbles() {
        return listaVbles;
    }

    public boolean comprobarCondicion(String condicion) {
        boolean res = true;

        ScriptEngineManager manager = new ScriptEngineManager();
        ScriptEngine engine = manager.getEngineByName("js");

        int numMedidasArticuloDac = getNumeroDimensiones();

        if (numMedidasArticuloDac == 0 && (condicion.contains("Dim1") || condicion.contains("Dim2") || condicion.contains("Dim3") || condicion.contains("Dim4") || condicion.contains("Dim5"))) {
            res = false;
        } else if (numMedidasArticuloDac == 1 && (condicion.contains("Dim2") || condicion.contains("Dim3") || condicion.contains("Dim4") || condicion.contains("Dim5"))) {
            res = false;
        } else if (numMedidasArticuloDac == 2 && (condicion.contains("Dim3") || condicion.contains("Dim4") || condicion.contains("Dim5"))) {
            res = false;
        } else if (numMedidasArticuloDac == 3 && (condicion.contains("Dim4") || condicion.contains("Dim5"))) {
            res = false;
        } else if (numMedidasArticuloDac == 4 && (condicion.contains("Dim5"))) {
            res = false;
        }

        if (res) {
            //No hay dimensiones que se pasen
            engine.put("Dim1", Double.valueOf(Util.convertirComaAPunto(getDim1())));
            engine.put("Dim2", Double.valueOf(Util.convertirComaAPunto(getDim2())));
            engine.put("Dim3", Double.valueOf(Util.convertirComaAPunto(getDim3())));
            engine.put("Dim4", Double.valueOf(Util.convertirComaAPunto(getDim4())));
            engine.put("Dim5", Double.valueOf(Util.convertirComaAPunto(getDim5())));
            engine.put("Cantidad", Double.valueOf(Util.convertirComaAPunto(getCantidad())));

            Iterator iter = this.listaVbles.iterator();
            Variable var;
            while (iter.hasNext()) {
                var = (Variable) iter.next();
                engine.put(var.getNombre(), var.getValor());
            }

            try {
                boolean condicionRes = (Boolean) engine.eval(Util.convertirComaAPunto(condicion));
                boolean condicionRes2 = (Boolean) engineGlobal.eval(Util.convertirComaAPunto(condicion));
                System.out.println("2.- " + condicionRes + "  -  " + condicionRes2);
                res = condicionRes2;
            } catch (Exception se) {
                res = false;
            }
        }

        return res;
    }
    
    public Double evaluar(String formula, String tipoRedondeo, boolean mostrarError) {
        Double resultado = null;
        boolean res = true;

        if (formula.length() == 0) {
            formula = "0.0";
        }
        
        int numMedidasArticuloDac = getNumeroDimensiones();

        if (numMedidasArticuloDac == 0 && (formula.contains("Dim1") || formula.contains("Dim2") || formula.contains("Dim3") || formula.contains("Dim4") || formula.contains("Dim5"))) {
            res = false;
        } else if (numMedidasArticuloDac == 1 && (formula.contains("Dim2") || formula.contains("Dim3") || formula.contains("Dim4") || formula.contains("Dim5"))) {
            res = false;
        } else if (numMedidasArticuloDac == 2 && (formula.contains("Dim3") || formula.contains("Dim4") || formula.contains("Dim5"))) {
            res = false;
        } else if (numMedidasArticuloDac == 3 && (formula.contains("Dim4") || formula.contains("Dim5"))) {
            res = false;
        } else if (numMedidasArticuloDac == 4 && (formula.contains("Dim5"))) {
            res = false;
        }

        if (res) {
            try {
                resultado = (Double) engineGlobal.eval(Util.convertirComaAPunto(formula));
                if (tipoRedondeo.equals(Constantes.TRUNCAR)) {
                    resultado = matematico.Matematico.truncar(resultado);
                } else if (tipoRedondeo.equals(Constantes.EXCESO)) {
                    resultado = matematico.Matematico.exceso(resultado);
                } else {
                    resultado = matematico.Matematico.redondear2decimales(resultado);
                }
            } catch (Exception se) {
                if (mostrarError) {
                    JOptionPane.showMessageDialog(null, "Hay un error al evaluar la fórmula", "Error", JOptionPane.INFORMATION_MESSAGE);
                }
            }
        } else {
            JOptionPane.showMessageDialog(null, "Error, en la fórmula aparecen más medidas de las que tiene el artículo", "Error", JOptionPane.INFORMATION_MESSAGE);
        }

        return resultado;
    }

    private void crearIconosBotones() {

        URL url = getClass().getResource("/iconos/cancelar.gif");
        ImageIcon icono = new ImageIcon(url);
        bCancelar.setIcon(icono);

        url = getClass().getResource("/iconos/guardarYvolver.png");
        icono = new ImageIcon(url);
        bAceptar.setIcon(icono);

        url = getClass().getResource("/iconos/editar.png");
        icono = new ImageIcon(url);
        bModificar.setIcon(icono);

        url = getClass().getResource("/iconos/masAzul.png");
        icono = new ImageIcon(url);
        bSeleccionarArticulo.setIcon(icono);

        url = getClass().getResource("/iconos/gomaBorrar.gif");
        icono = new ImageIcon(url);
        bBorrar.setIcon(icono);
        bEliminarVble.setIcon(icono);

        url = getClass().getResource("/iconos/ojo.png");
        icono = new ImageIcon(url);
        bVerTodos.setIcon(icono);

        url = getClass().getResource("/iconos/arriba.png");
        icono = new ImageIcon(url);
        bSubir.setIcon(icono);

        url = getClass().getResource("/iconos/abajo.png");
        icono = new ImageIcon(url);
        bBajar.setIcon(icono);

        url = getClass().getResource("/iconos/añadir.png");
        icono = new ImageIcon(url);
        bAñadir.setIcon(icono);

        url = getClass().getResource("/iconos/insertar.png");
        icono = new ImageIcon(url);
        bInsertar.setIcon(icono);
        bNuevaVble.setIcon(icono);

        url = getClass().getResource("/iconos/modificar_despiece.png");
        icono = new ImageIcon(url);
        bModificarVble.setIcon(icono);
        bModificarDespiece.setIcon(icono);
    }

    protected String getStringColorLacado() {
        return (String) cLacado.getSelectedItem();
    }

    protected String getStringColorAccesorios() {
        return (String) cAccesorios.getSelectedItem();
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bAceptar;
    private javax.swing.JButton bAñadir;
    private javax.swing.JButton bBajar;
    private javax.swing.JButton bBorrar;
    private javax.swing.JButton bCancelar;
    private javax.swing.JButton bEliminarVble;
    private javax.swing.JButton bInsertar;
    private javax.swing.JButton bModificar;
    private javax.swing.JButton bModificarDespiece;
    private javax.swing.JButton bModificarVble;
    private javax.swing.JButton bNuevaVble;
    private javax.swing.JButton bSeleccionarArticulo;
    private javax.swing.JButton bSubir;
    private javax.swing.JButton bVerTodos;
    private javax.swing.JComboBox cAccesorios;
    private javax.swing.JComboBox cLacado;
    private javax.swing.JCheckBox cbAtacuerda;
    private javax.swing.JCheckBox cbAtacuerdaPared;
    private javax.swing.JCheckBox cbBambolina;
    private javax.swing.JCheckBox cbBrazo;
    private javax.swing.JCheckBox cbCarruchaDoble;
    private javax.swing.JCheckBox cbCarruchaSimple;
    private javax.swing.JCheckBox cbCasquillo;
    private javax.swing.JCheckBox cbCofre;
    private javax.swing.JCheckBox cbForma;
    private javax.swing.JCheckBox cbGancho;
    private javax.swing.JCheckBox cbLona;
    private javax.swing.JCheckBox cbLonaDoble;
    private javax.swing.JCheckBox cbManivela;
    private javax.swing.JCheckBox cbMaquina;
    private javax.swing.JCheckBox cbMotor;
    private javax.swing.JCheckBox cbPerfil;
    private javax.swing.JCheckBox cbPerfilCofre;
    private javax.swing.JComboBox cbPlantilla;
    private javax.swing.JCheckBox cbPoleaDerecha;
    private javax.swing.JCheckBox cbPoleaIzquierda;
    private javax.swing.JCheckBox cbSoporte;
    private javax.swing.JCheckBox cbTapa;
    private javax.swing.JCheckBox cbTerminal;
    private javax.swing.JCheckBox cbTuboEnrrolle;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JLabel lAccesorios;
    private javax.swing.JLabel lCantidad;
    private javax.swing.JLabel lCodigo;
    private javax.swing.JLabel lDescripcion;
    private javax.swing.JLabel lLacado;
    private javax.swing.JLabel lMagnitud1;
    private javax.swing.JLabel lMagnitud2;
    private javax.swing.JLabel lMagnitud3;
    private javax.swing.JLabel lMagnitud4;
    private javax.swing.JLabel lMagnitud5;
    private javax.swing.JLabel lMagnitudCantidad;
    private javax.swing.JLabel lUnidad1;
    private javax.swing.JLabel lUnidad2;
    private javax.swing.JLabel lUnidad3;
    private javax.swing.JLabel lUnidad4;
    private javax.swing.JLabel lUnidad5;
    private javax.swing.JPanel pDespiece;
    private javax.swing.JPanel pMedidas;
    private javax.swing.JPanel pOpciones;
    private javax.swing.JPanel pSeleccionArticulo;
    private javax.swing.JPanel pSeleccionArticulo2;
    private javax.swing.JPanel pVbles;
    private javax.swing.JTextField tCantidad;
    private javax.swing.JTextField tCodigo;
    private javax.swing.JTextField tDescripcion;
    private javax.swing.JTextField tDescripcionDac;
    private javax.swing.JTable tDespiece;
    private javax.swing.JTextField tMedida1;
    private javax.swing.JTextField tMedida2;
    private javax.swing.JTextField tMedida3;
    private javax.swing.JTextField tMedida4;
    private javax.swing.JTextField tMedida5;
    private javax.swing.JTable tVbles;
    // End of variables declaration//GEN-END:variables
}
