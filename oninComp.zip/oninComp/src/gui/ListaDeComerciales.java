package gui;

import acceso.BaseDatos;
import bean.Comercial;
import bean.Empresa;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JOptionPane;
import javax.swing.KeyStroke;
import modelo.Modelo;
import util.Util;

public class ListaDeComerciales extends javax.swing.JFrame {
    private Empresa e;
    private List listaInicial;

    public ListaDeComerciales(Empresa e) {
        super("Comerciales - Mantenimiento");
        this.e = e;
        this.listaInicial = BaseDatos.getListaComerciales();
        
        initComponents();
        
        tComercial1.requestFocus();
        if (tComercial1.getRowCount() > 0){
            tComercial1.setRowSelectionInterval(0,0);
        }

        crearIconosBotones();
        crearAcciones();
    }

private void borrarComercial() {
    try {
        int indiceFila = this.tComercial1.getSelectedRow();
        if (indiceFila >= 0) {
            if (JOptionPane.showConfirmDialog(null, "¿Está seguro de que desea eliminar el elemento seleccionado?", "¿Eliminar?", JOptionPane.YES_NO_OPTION) == 0) {
                Comercial c = BaseDatos.obtenerComercialPorCodigo((String) tComercial1.getModel().getValueAt(indiceFila, 0));
                if (BaseDatos.eliminarElemento(Comercial.class, c.getIid())) {
                    realizarBusqueda();
                } else {
                    JOptionPane.showMessageDialog(null, "No se ha podido eliminar el elemento seleccionado", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        } else {
            JOptionPane.showMessageDialog(null, "No hay seleccionado ningún elemento", "Error", JOptionPane.ERROR_MESSAGE);
        }
    } catch (Exception ex) {
        JOptionPane.showMessageDialog(null, "Este elemento no se puede eliminar", "Error", JOptionPane.ERROR_MESSAGE);
    }
}

    private void crearAcciones() {
        KeyStroke escapeKeyStroke = KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false);
        Action escapeAction = new AbstractAction() {
            public void actionPerformed(ActionEvent e) {
                cerrarListaDeComerciales();
            }
        }; 
        getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(escapeKeyStroke, "ESCAPE");
        getRootPane().getActionMap().put("ESCAPE", escapeAction);
        
        KeyStroke f1KeyStroke = KeyStroke.getKeyStroke (KeyEvent.VK_F1, 0, false);
        Action f1Action = new AbstractAction() {
            public void actionPerformed(ActionEvent ev) {
                crearComercial();
            }
        }; 
        getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(f1KeyStroke, "F1");
        getRootPane().getActionMap().put("F1", f1Action);
    }
    
    private void cerrarListaDeComerciales(){
        removeAll();
        dispose();      
    }
    
    private void crearComercial(){
        NuevoComercial nc = new NuevoComercial("Comercial - Creación",e);
        nc.setDefaultCloseOperation(NuevoComercial.DISPOSE_ON_CLOSE);
        nc.setLocationRelativeTo(null);
        nc.setVisible(true);
        nc = null;
        cerrarListaDeComerciales();
    }
    
    private void crearIconosBotones() {
        URL url = getClass().getResource("/iconos/buscar.gif");
        ImageIcon icono = new ImageIcon(url);
        bVisualizar.setIcon(icono);

        url = getClass().getResource("/iconos/eliminar.png");
        icono = new ImageIcon(url);
        bBorrar.setIcon(icono);

        URL urlCerrar = getClass().getResource("/iconos/cancelar.gif");
        icono = new ImageIcon(url);
        bCerrar.setIcon(icono);

        URL urlCrear = getClass().getResource("/iconos/aceptar.png");
        icono = new ImageIcon(url);
        bCrear.setIcon(icono);
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        bVisualizar = new javax.swing.JButton();
        bCerrar = new javax.swing.JButton();
        bBorrar = new javax.swing.JButton();
        bCrear = new javax.swing.JButton();
        lbusqueda2 = new javax.swing.JLabel();
        tbusqueda1 = new javax.swing.JTextField();
        rbCodigo = new javax.swing.JRadioButton();
        rbNombre = new javax.swing.JRadioButton();
        rbTelefono = new javax.swing.JRadioButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        Modelo modelo1 = new Modelo();
        tComercial1 = new javax.swing.JTable(modelo1);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        bVisualizar.setText("Visualizar");
        bVisualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bVisualizarActionPerformed(evt);
            }
        });

        bCerrar.setText("Cerrar");
        bCerrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bCerrarActionPerformed(evt);
            }
        });

        bBorrar.setText("Borrar");
        bBorrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bBorrarActionPerformed(evt);
            }
        });

        bCrear.setText("Crear");
        bCrear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bCrearActionPerformed(evt);
            }
        });

        lbusqueda2.setText("Búsqueda rápida");

        tbusqueda1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tbusqueda1KeyReleased(evt);
            }
        });

        buttonGroup1.add(rbCodigo);
        rbCodigo.setText("Código");
        rbCodigo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbCodigoActionPerformed(evt);
            }
        });

        buttonGroup1.add(rbNombre);
        rbNombre.setText("Nombre");
        rbNombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbNombreActionPerformed(evt);
            }
        });

        buttonGroup1.add(rbTelefono);
        rbTelefono.setText("Teléfono");
        rbTelefono.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbTelefonoActionPerformed(evt);
            }
        });

        modelo1.addColumn("Código");
        modelo1.addColumn("Nombre");
        modelo1.addColumn("Teléfono");
        modelo1.addColumn("Teléfono 2");
        modelo1.addColumn("Nif");
        modelo1.addColumn("%");

        Comercial c1;
        Iterator<Comercial> it1;
        Object[] fila1;
        if(listaInicial != null){
            for (it1 = listaInicial.iterator(); it1.hasNext();) {
                fila1 = new Object[6];
                c1 = it1.next();
                fila1[0] = c1.getCodigo();
                fila1[1] = c1.getNombre();
                fila1[2] = c1.getTelefono();
                fila1[3] = c1.getTelefono2();
                fila1[4] = c1.getNif();
                fila1[5] = Util.convertirPuntoAComa(String.valueOf(c1.getPorcentaje()));
                modelo1.addRow(fila1);
            }
        }
        tComercial1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tComercial1MouseClicked(evt);
            }
        });
        tComercial1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tComercial1KeyPressed(evt);
            }
        });
        jScrollPane2.setViewportView(tComercial1);

        org.jdesktop.layout.GroupLayout layout = new org.jdesktop.layout.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(layout.createSequentialGroup()
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(layout.createSequentialGroup()
                        .addContainerGap()
                        .add(lbusqueda2)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(tbusqueda1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 326, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                        .add(rbCodigo)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(rbNombre)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(rbTelefono))
                    .add(layout.createSequentialGroup()
                        .add(258, 258, 258)
                        .add(bCrear, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 93, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(bBorrar, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 90, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(bVisualizar, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 101, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(bCerrar, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 88, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .add(org.jdesktop.layout.GroupLayout.TRAILING, jScrollPane2, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 658, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(layout.createSequentialGroup()
                .addContainerGap()
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(lbusqueda2)
                    .add(tbusqueda1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(rbCodigo)
                    .add(rbNombre)
                    .add(rbTelefono))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jScrollPane2, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 269, Short.MAX_VALUE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(bCerrar)
                    .add(bVisualizar)
                    .add(bBorrar)
                    .add(bCrear))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

private void bVisualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bVisualizarActionPerformed
    visualizar();
}//GEN-LAST:event_bVisualizarActionPerformed

private void visualizar(){
    int indiceFila = tComercial1.getSelectedRow();
    if (indiceFila >= 0) {
        Comercial c = BaseDatos.obtenerComercialPorCodigo((String) tComercial1.getModel().getValueAt(indiceFila, 0));
        NuevoComercial nc = new NuevoComercial("Comercial - Modificación",c,e);
        nc.setDefaultCloseOperation(NuevoColor.DISPOSE_ON_CLOSE);
        nc.setLocationRelativeTo(null);
        nc.setVisible(true);
        cerrarListaDeComerciales();
    } else {
        JOptionPane.showMessageDialog(null, "No hay seleccionado ningún elemento", "Error", JOptionPane.ERROR_MESSAGE);
    }
}

private void bCerrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bCerrarActionPerformed
    cerrarListaDeComerciales();
}//GEN-LAST:event_bCerrarActionPerformed

private void tbusqueda1KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tbusqueda1KeyReleased
    realizarBusqueda();
}//GEN-LAST:event_tbusqueda1KeyReleased

private void bBorrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bBorrarActionPerformed
    borrarComercial();
}//GEN-LAST:event_bBorrarActionPerformed

private void bCrearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bCrearActionPerformed
    crearComercial();
}//GEN-LAST:event_bCrearActionPerformed

private void tComercial1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tComercial1MouseClicked
    if(evt.getClickCount()==2){
        visualizar();
    }
}//GEN-LAST:event_tComercial1MouseClicked

private void tComercial1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tComercial1KeyPressed
    if(evt.getKeyChar() == KeyEvent.VK_ENTER){
        visualizar();
    } else if(evt.getKeyChar() == KeyEvent.VK_DELETE){
        borrarComercial();
    }
}//GEN-LAST:event_tComercial1KeyPressed

private void rbCodigoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbCodigoActionPerformed
    realizarBusqueda();
}//GEN-LAST:event_rbCodigoActionPerformed

private void rbNombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbNombreActionPerformed
    realizarBusqueda();
}//GEN-LAST:event_rbNombreActionPerformed

private void rbTelefonoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbTelefonoActionPerformed
    realizarBusqueda();
}//GEN-LAST:event_rbTelefonoActionPerformed

protected void realizarBusqueda(){
    if (rbCodigo.isSelected()) {
        actualizarComerciales(BaseDatos.busquedaRapidaComercialPorCodigo(tbusqueda1.getText().toLowerCase()));
    }else if (rbNombre.isSelected()) {
        actualizarComerciales(BaseDatos.busquedaRapidaComercialPorNombre(tbusqueda1.getText().toLowerCase()));
    }else if (rbTelefono.isSelected()) {
        actualizarComerciales(BaseDatos.busquedaRapidaComercialPorTelefono(tbusqueda1.getText().toLowerCase()));
    }else {
        actualizarComerciales(BaseDatos.getListaComerciales());
    }
}

    private void actualizarComerciales(List lComerciales1) {
        Modelo modelo1 = (Modelo) tComercial1.getModel();
        int i, j = modelo1.getRowCount();

        //eliminamos todas las filas
        for (i = 0; i < j; i++) {
            modelo1.removeRow(0);
        }

        if (lComerciales1 == null) {
            lComerciales1 = new ArrayList();
        }
        if (lComerciales1 != null) {
			Comercial c1;
			Iterator<Comercial> it1;
			Object[] fila1;
            for (it1 = lComerciales1.iterator(); it1.hasNext();) {
               fila1 = new Object[6];
               c1 = it1.next();
               fila1[0] = c1.getCodigo();
               fila1[1] = c1.getNombre();
               fila1[2] = c1.getTelefono();
               fila1[3] = c1.getTelefono2();
               fila1[4] = c1.getNif(); 
               fila1[5] = Util.convertirPuntoAComa(String.valueOf(c1.getPorcentaje()));
               modelo1.addRow(fila1);
            }
        }
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bBorrar;
    private javax.swing.JButton bCerrar;
    private javax.swing.JButton bCrear;
    private javax.swing.JButton bVisualizar;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel lbusqueda2;
    private javax.swing.JRadioButton rbCodigo;
    private javax.swing.JRadioButton rbNombre;
    private javax.swing.JRadioButton rbTelefono;
    private javax.swing.JTable tComercial1;
    private javax.swing.JTextField tbusqueda1;
    // End of variables declaration//GEN-END:variables
}
