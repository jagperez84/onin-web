package gui;

import acceso.BaseDatos;
import bean.Articulo;
import bean.ClaseDocumento;
import bean.Empresa;
import bean.LineaPresupuesto;
import bean.Montaje;
import bean.Presupuesto;
import bean.Usuario;
import bean.EstadoDocumento;
import bean.Interlocutor;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.KeyStroke;
import matematico.Matematico;
import modelo.ColorRenderer;
import modelo.Modelo;
import util.Constantes;
import util.Util;

public class ListaDePresupuestos extends javax.swing.JFrame {

    private Empresa e;
    private ClaseDocumento cd;
    private Usuario u;
    private List listaInicial;
    private List<Presupuesto> listaP;
    private Montaje m;
    private HashMap<Integer, String> listaEst = new HashMap<Integer, String>();
    private HashMap<Integer, String> listaInt = new HashMap<Integer, String>();

    public ListaDePresupuestos(Empresa e, Usuario u, ClaseDocumento cd) {
        super(cd.getDescripcion() + " - Mantenimiento");
        setExtendedState(MAXIMIZED_BOTH);
        this.e = e;
        this.cd = cd;
        this.u = u;
        Date hoy = new Date();
        String descripcion = cd.getDescripcion();

        if (descripcion.equals(Constantes.FACTURA)) {
            listaInicial = BaseDatos.getListaFacturas(e.getIid());
        } else {
            listaInicial = BaseDatos.getListaPresupuesto(e.getIid(), cd.getIid());
        }

        if (descripcion.equalsIgnoreCase(Constantes.PEDIDO)) {
            listaP = BaseDatos.getListaPendientes(u, e.getIid(), cd.getIid());
        }
        initComponents();

        if (descripcion.equals(Constantes.FACTURA)) {
            rNC.setText("N.Fiscal");
            jLabel11.setText("Nombre Fiscal:");
        }

        fInicio.setDateFormatString("dd/MM/yyyy");
        fInicio.setDate(hoy);
        fFin.setDateFormatString("dd/MM/yyyy");
        fFin.setDate(hoy);
        tbusqueda1.requestFocus();
        
        //El panel de montaje por defecto invisible
        pMontaje.setVisible(false);

        if (listaInicial == null) {
            listaInicial = new ArrayList();
        }

        List<Integer> listaPagados = new ArrayList<Integer>();
        List<Integer> listaImpagados = new ArrayList<Integer>();
        int contador = 0;
        Presupuesto pTemp;
        Iterator<Presupuesto> it = listaInicial.iterator();
        while (it.hasNext()) {
            pTemp = it.next();
            if (pTemp.getPagado() != null && pTemp.getPagado()) {
                listaPagados.add(contador);
            } else if (pTemp.getImpagado() != null && pTemp.getImpagado()) {
                listaImpagados.add(contador);
            }
            contador++;
        }

        tpresupuesto1.setDefaultRenderer(Object.class, new ColorRenderer(listaPagados, Color.GREEN, listaImpagados, Color.RED));
        crearIconosBotones();
        crearAcciones();

        if (descripcion.equals(Constantes.PEDIDO)) {
            List<Integer> listaCaducados = new ArrayList<Integer>();
            it = listaP.iterator();
            contador = 0;
            while (it.hasNext()) {
                pTemp = it.next();
                if ((pTemp.getFechaEntrega() != null && (pTemp.getFechaEntrega()) < hoy.getTime()) && !pTemp.getInstalado()) {
                    listaCaducados.add(contador);
                }
                contador++;
            }
            tpresupuesto8.setDefaultRenderer(Object.class, new ColorRenderer(listaPagados, Color.GREEN, listaCaducados, Color.ORANGE));
        } else {
            pPendientes.setVisible(false);
            pDireccion.remove(pDireccion.indexOfTab("Pendientes"));
        }
        
        int indicePanel = this.pDireccion.getSelectedIndex();
        if (indicePanel == 0) {
            if (this.tpresupuesto1.getSelectedRow() >= 0) {
                Presupuesto pre = this.obtenerDocSel();
                if (pre != null) {
                    rellenarLineas(pre);
                }
            }
        }
    }

    //Para listado desde medición
    public ListaDePresupuestos(Empresa e, Usuario u, ClaseDocumento cd, List<Presupuesto> lp) {
        super(cd.getDescripcion() + " - Mantenimiento");
        setExtendedState(MAXIMIZED_BOTH);
        this.e = e;
        this.cd = cd;
        this.u = u;
        listaInicial = lp;
        String descripcion = cd.getDescripcion();
        if (cd.getDescripcion().equalsIgnoreCase(Constantes.PEDIDO)) {
            listaP = BaseDatos.getListaPendientes(u, e.getIid(), cd.getIid());
        }
        initComponents();

        if (descripcion.equals(Constantes.FACTURA)) {
            this.rNC.setText("N.Fiscal");
            jLabel11.setText("Nombre Fiscal:");
        }

        tpresupuesto1.setRowSelectionInterval(0, 0);
        tbusqueda1.requestFocus();

        //El panel de montaje por defecto invisible
        pMontaje.setVisible(false);

        if (listaInicial == null) {
            listaInicial = new ArrayList();
        }

        List<Integer> listaPagados = new ArrayList<Integer>();
        List<Integer> listaImpagados = new ArrayList<Integer>();
        int contador = 0;
        Presupuesto pTemp;
        Iterator<Presupuesto> it = listaInicial.iterator();
        while (it.hasNext()) {
            pTemp = it.next();
            if (pTemp.getPagado() != null && pTemp.getPagado()) {
                listaPagados.add(contador);
            } else if (pTemp.getImpagado() != null && pTemp.getImpagado()) {
                listaImpagados.add(contador);
            }
            contador++;
        }

        tpresupuesto1.setDefaultRenderer(Object.class, new ColorRenderer(listaPagados, Color.GREEN, listaImpagados, Color.RED));

        crearIconosBotones();
        crearAcciones();

        if (descripcion.equals(Constantes.PEDIDO)) {
            List<Integer> listaCaducados = new ArrayList<Integer>();
            it = listaP.iterator();
            contador = 0;
            Date hoy = new Date();
            while (it.hasNext()) {
                pTemp = it.next();
                if ((pTemp.getFechaEntrega() != null && (pTemp.getFechaEntrega() < hoy.getTime())) && !pTemp.getInstalado()) {
                    listaCaducados.add(contador);
                }
                contador++;
            }
            tpresupuesto8.setDefaultRenderer(Object.class, new ColorRenderer(listaPagados, Color.GREEN, listaCaducados, Color.ORANGE));
        } else {
            pPendientes.setVisible(false);
            pDireccion.remove(pDireccion.indexOfTab("Pendientes"));
        }
        int indicePanel = this.pDireccion.getSelectedIndex();
        if (indicePanel == 0) {
            if (this.tpresupuesto1.getSelectedRow() >= 0) {
                Presupuesto pre = this.obtenerDocSel();
                if (pre != null) {
                    rellenarLineas(pre);
                }
            }
        }
    }

    private void crearAcciones() {
        KeyStroke escapeKeyStroke = KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false);
        Action escapeAction = new AbstractAction() {
            public void actionPerformed(ActionEvent e) {
                cerrarListaPresupuestos();
            }
        };
        getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(escapeKeyStroke, "ESCAPE");
        getRootPane().getActionMap().put("ESCAPE", escapeAction);

        KeyStroke f1KeyStroke = KeyStroke.getKeyStroke(KeyEvent.VK_F1, 0, false);
        Action f1Action = new AbstractAction() {
            public void actionPerformed(ActionEvent ev) {
                crearPresupuesto();
            }
        };
        getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(f1KeyStroke, "F1");
        getRootPane().getActionMap().put("F1", f1Action);

        KeyStroke f8KeyStroke = KeyStroke.getKeyStroke(KeyEvent.VK_F8, 0, false);
        Action f8Action = new AbstractAction() {

            public void actionPerformed(ActionEvent ev) {
                Presupuesto pS = obtenerDocSel();
                if (pS != null) {
                    configurar(new DatosConversion(pS, "directo", e, u));
                } else {
                    JOptionPane.showMessageDialog(null, "No hay seleccionado ningún elemento", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        };
        getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(f8KeyStroke, "F8");
        getRootPane().getActionMap().put("F8", f8Action);

        KeyStroke f9KeyStroke = KeyStroke.getKeyStroke(KeyEvent.VK_F9, 0, false);
        Action f9Action = new AbstractAction() {
            public void actionPerformed(ActionEvent ev) {
                Presupuesto pS = obtenerDocSel();
                if (pS != null) {
                    configurar(new flujoDatos(pS, e, u));
                }
            }
        };
        getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(f9KeyStroke, "F9");
        getRootPane().getActionMap().put("F9", f9Action);

        Dimension dim = Util.getDimensiones(this.getSize());
        if (dim != null) {
            setResizable(true);
            setSize(dim);
        }
    }

    private void cerrarListaPresupuestos() {
        removeAll();
        dispose();
    }

    private void configurar(JFrame frame) {
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    private void crearPresupuesto() {
        configurar(new NuevoPresupuesto(e, cd, u, this));
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        gBusqueda = new javax.swing.ButtonGroup();
        bcancelar = new javax.swing.JButton();
        bcrear = new javax.swing.JButton();
        bBorrar = new javax.swing.JButton();
        bvisualizar = new javax.swing.JButton();
        jScrollPane4 = new javax.swing.JScrollPane();
        pDireccion = new javax.swing.JTabbedPane();
        pnombrecomercial = new javax.swing.JPanel();
        tbusqueda1 = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        Modelo modelo1 = new Modelo();
        tpresupuesto1 = new javax.swing.JTable(modelo1);
        jScrollPane3 = new javax.swing.JScrollPane();
        Modelo modelo = new Modelo();
        tLineas = new javax.swing.JTable(modelo);
        bProv = new javax.swing.JButton();
        rNC = new javax.swing.JRadioButton();
        rNum = new javax.swing.JRadioButton();
        rEstado = new javax.swing.JRadioButton();
        rRef = new javax.swing.JRadioButton();
        rDirec = new javax.swing.JRadioButton();
        bProv1 = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        tNombreComercial = new javax.swing.JTextField();
        tNumero = new javax.swing.JTextField();
        tReferencia = new javax.swing.JTextField();
        tDireccion = new javax.swing.JTextField();
        bBuscar = new javax.swing.JButton();
        fInicio = new com.toedter.calendar.JDateChooser();
        fFin = new com.toedter.calendar.JDateChooser();
        jLabel15 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        cInterlocutor = new javax.swing.JComboBox();
        lInterlocutor = new javax.swing.JLabel();
        pPendientes = new javax.swing.JPanel();
        jScrollPane9 = new javax.swing.JScrollPane();
        Modelo modelo8 = new Modelo();
        tpresupuesto8 = new javax.swing.JTable(modelo8);
        pMontaje = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tobservaciones = new javax.swing.JTextArea();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        ttipo = new javax.swing.JTextField();
        tmontador = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        thora = new javax.swing.JTextField();
        beliminar = new javax.swing.JButton();
        bcomunicar = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        tfecha = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        thorafin = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        tduracion = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        tduracionreal = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        bcancelar.setToolTipText("Salir (Esc)");
        bcancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bcancelarActionPerformed(evt);
            }
        });

        bcrear.setToolTipText("Crear (F1)");
        bcrear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bcrearActionPerformed(evt);
            }
        });

        bBorrar.setToolTipText("Borrar (F2)");
        bBorrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bBorrarActionPerformed(evt);
            }
        });

        bvisualizar.setToolTipText("Visualizar (F3)");
        bvisualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bvisualizarActionPerformed(evt);
            }
        });

        tbusqueda1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tbusqueda1KeyReleased(evt);
            }
        });

        modelo1.addColumn("Interlocutor");
        if(cd.getDescripcion().equals(Constantes.FACTURA)){
            modelo1.addColumn("N. Fiscal");
        } else {
            modelo1.addColumn("N. comercial");
        }
        modelo1.addColumn("Número");
        modelo1.addColumn("Referencia");
        modelo1.addColumn("Fecha");
        modelo1.addColumn("Imp. Total");
        modelo1.addColumn("Estado");
        modelo1.addColumn("Dirección");
        modelo1.addColumn("Localidad");
        if(cd.getDescripcion().equals(Constantes.PEDIDO)){
            modelo1.addColumn("F. Entrega");
        }
        modelo1.addColumn("iid");

        Presupuesto p1;
        Iterator it1;
        Object[] fila1;
        SimpleDateFormat formatoFecha = new SimpleDateFormat("dd/MM/yyyy");
        EstadoDocumento es;
        Empresa emI;
        Integer estId;
        Integer intId;

        if(listaInicial  != null){
            for (it1 = listaInicial .iterator(); it1.hasNext();) {
                fila1 = new Object[11];
                p1 = (Presupuesto) it1.next();

                intId = p1.getInterlocutor();
                if(!listaInt.containsKey(intId)){
                    emI = BaseDatos.obtenerEmpresaPorIid(intId);
                    listaInt.put(intId, emI.getDesc_empresa());
                }

                fila1[0] = listaInt.get(intId);
                fila1[1] = p1.getNombreCliente();
                fila1[2] = p1.getNumero();
                fila1[3] = p1.getReferencia();
                fila1[4] = formatoFecha.format(new Date(p1.getFecha()));
                fila1[5] = Util.convertirPuntoAComa(String.valueOf(Matematico.redondear2decimales( p1.getImporte_total())))+" €";
                fila1[7] = p1.getDomicilioCliente();
                fila1[8] = p1.getProvinciaCliente();

                if(cd.getDescripcion().equals(Constantes.PEDIDO)){
                    fila1[9] = formatoFecha.format(new Date(p1.getFechaEntrega()));
                    fila1[10] = p1.getIid();
                } else {
                    fila1[9] = p1.getIid();
                }

                estId = p1.getEstado().getIid();
                if(!listaEst.containsKey(estId)){
                    es = BaseDatos.obtenerEstadoPorIid(estId);
                    listaEst.put(estId, es.getDescripcion());
                }
                fila1[6] = listaEst.get(estId);

                modelo1.addRow(fila1);
            }
        }
        tpresupuesto1.getColumnModel().getColumn(0).setPreferredWidth(120);
        tpresupuesto1.getColumnModel().getColumn(1).setPreferredWidth(160);
        tpresupuesto1.getColumnModel().getColumn(2).setPreferredWidth(60);
        tpresupuesto1.getColumnModel().getColumn(3).setPreferredWidth(130);
        tpresupuesto1.getColumnModel().getColumn(4).setPreferredWidth(70);
        tpresupuesto1.getColumnModel().getColumn(5).setPreferredWidth(63);
        tpresupuesto1.getColumnModel().getColumn(6).setPreferredWidth(180);
        tpresupuesto1.getColumnModel().getColumn(7).setPreferredWidth(100);
        tpresupuesto1.getColumnModel().getColumn(8).setPreferredWidth(70);

        int indiceColumnaIid = 9;
        if(cd.getDescripcion().equals(Constantes.PEDIDO)){
            tpresupuesto1.getColumnModel().getColumn(9).setPreferredWidth(70);
            indiceColumnaIid = 10;
        }
        tpresupuesto1.getColumnModel().getColumn(indiceColumnaIid).setWidth(0);
        tpresupuesto1.getColumnModel().getColumn(indiceColumnaIid).setMaxWidth(0);
        tpresupuesto1.getColumnModel().getColumn(indiceColumnaIid).setMinWidth(0);
        tpresupuesto1.getColumnModel().getColumn(indiceColumnaIid).setPreferredWidth(0);
        tpresupuesto1.getColumnModel().getColumn(indiceColumnaIid).setResizable(false);
        tpresupuesto1.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        tpresupuesto1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tpresupuesto1MouseClicked(evt);
            }
        });
        tpresupuesto1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tpresupuesto1KeyPressed(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tpresupuesto1KeyReleased(evt);
            }
        });
        jScrollPane1.setViewportView(tpresupuesto1);

        // Creamos las columnas.
        modelo.addColumn("Línea");
        modelo.addColumn("Tipo");
        modelo.addColumn("Cantidad");
        modelo.addColumn("Descripción");
        modelo.addColumn("Precio");
        modelo.addColumn("Importe");
        tLineas.getColumnModel().getColumn(0).setPreferredWidth(15);
        tLineas.getColumnModel().getColumn(1).setPreferredWidth(25);
        tLineas.getColumnModel().getColumn(2).setPreferredWidth(30);
        tLineas.getColumnModel().getColumn(3).setPreferredWidth(160);
        tLineas.getColumnModel().getColumn(4).setPreferredWidth(15);
        tLineas.getColumnModel().getColumn(5).setPreferredWidth(25);
        jScrollPane3.setViewportView(tLineas);

        bProv.setToolTipText("Procesar Documento (F8)");
        bProv.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bProvActionPerformed(evt);
            }
        });

        gBusqueda.add(rNC);
        rNC.setSelected(true);
        rNC.setLabel("N. Comercial");
        rNC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rNCActionPerformed(evt);
            }
        });

        gBusqueda.add(rNum);
        rNum.setLabel("Número");
        rNum.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rNumActionPerformed(evt);
            }
        });

        gBusqueda.add(rEstado);
        rEstado.setLabel("Estado");
        rEstado.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rEstadoActionPerformed(evt);
            }
        });

        gBusqueda.add(rRef);
        rRef.setLabel("Referencia");
        rRef.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rRefActionPerformed(evt);
            }
        });

        gBusqueda.add(rDirec);
        rDirec.setLabel("Dirección");
        rDirec.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rDirecActionPerformed(evt);
            }
        });

        bProv1.setToolTipText("Flujo de Documentos (F9)");
        bProv1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bProv1ActionPerformed(evt);
            }
        });

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder("Búsqueda Avanzada"));

        jLabel11.setFont(new java.awt.Font("Tahoma", 1, 14));
        jLabel11.setText("Nombre Comercial:");

        jLabel13.setFont(new java.awt.Font("Tahoma", 1, 14));
        jLabel13.setText("Número:");

        jLabel14.setFont(new java.awt.Font("Tahoma", 1, 14));
        jLabel14.setText("Desde:");

        jLabel16.setFont(new java.awt.Font("Tahoma", 1, 14));
        jLabel16.setText("Referencia:");

        jLabel17.setFont(new java.awt.Font("Tahoma", 1, 14));
        jLabel17.setText("Dirección:");

        tNombreComercial.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tNombreComercialKeyPressed(evt);
            }
        });

        tNumero.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tNumeroKeyPressed(evt);
            }
        });

        tReferencia.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tReferenciaKeyPressed(evt);
            }
        });

        tDireccion.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tDireccionKeyPressed(evt);
            }
        });

        bBuscar.setToolTipText("Buscar");
        bBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bBuscarActionPerformed(evt);
            }
        });

        fInicio.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                fInicioKeyPressed(evt);
            }
        });

        fFin.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                fFinKeyPressed(evt);
            }
        });

        jLabel15.setFont(new java.awt.Font("Tahoma", 1, 14));
        jLabel15.setText("Hasta:");

        jLabel18.setFont(new java.awt.Font("Tahoma", 1, 14));
        jLabel18.setText("Interlocutor:");

        org.jdesktop.layout.GroupLayout jPanel1Layout = new org.jdesktop.layout.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, jPanel1Layout.createSequentialGroup()
                .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jLabel11)
                    .add(jLabel16)
                    .add(jLabel14)
                    .add(jLabel13)
                    .add(jLabel17)
                    .add(jLabel18))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jPanel1Layout.createSequentialGroup()
                        .add(fInicio, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jLabel15)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(fFin, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                    .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING, false)
                        .add(org.jdesktop.layout.GroupLayout.LEADING, jPanel1Layout.createSequentialGroup()
                            .add(cInterlocutor, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 217, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .add(bBuscar))
                        .add(org.jdesktop.layout.GroupLayout.LEADING, tDireccion)
                        .add(org.jdesktop.layout.GroupLayout.LEADING, tReferencia)
                        .add(org.jdesktop.layout.GroupLayout.LEADING, tNumero)
                        .add(org.jdesktop.layout.GroupLayout.LEADING, tNombreComercial, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 249, Short.MAX_VALUE)))
                .addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel1Layout.createSequentialGroup()
                .addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jPanel1Layout.createSequentialGroup()
                        .add(jLabel11)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jLabel13)
                        .add(10, 10, 10)
                        .add(jLabel14)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jLabel16)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jLabel17)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jLabel18))
                    .add(jPanel1Layout.createSequentialGroup()
                        .add(tNombreComercial, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 17, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(tNumero, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 17, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                            .add(fInicio, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(fFin, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(jLabel15))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(tReferencia, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 17, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(tDireccion, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 17, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                            .add(cInterlocutor, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(bBuscar, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 24, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))))
        );

        List li = BaseDatos.getListaInterlocutores(e);
        Empresa ei;
        cInterlocutor.addItem(Constantes.TODOS);
        //Añadimos la empresa actual(madre) como primer interlocutor
        cInterlocutor.addItem(e.getDesc_empresa());
        for (Iterator<Interlocutor> it = li.iterator(); it.hasNext();) {
            ei = BaseDatos.obtenerEmpresaPorIid(it.next().getEmpresaHija().getIid());
            cInterlocutor.addItem(ei.getDesc_empresa());
        }

        lInterlocutor.setFont(new java.awt.Font("Tahoma", 1, 24));

        org.jdesktop.layout.GroupLayout pnombrecomercialLayout = new org.jdesktop.layout.GroupLayout(pnombrecomercial);
        pnombrecomercial.setLayout(pnombrecomercialLayout);
        pnombrecomercialLayout.setHorizontalGroup(
            pnombrecomercialLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(pnombrecomercialLayout.createSequentialGroup()
                .addContainerGap()
                .add(pnombrecomercialLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                    .add(tbusqueda1)
                    .add(jScrollPane1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 620, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(pnombrecomercialLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(pnombrecomercialLayout.createSequentialGroup()
                        .add(bProv, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 53, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(bProv1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 54, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                    .add(pnombrecomercialLayout.createSequentialGroup()
                        .add(rNC)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(rNum)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(rEstado)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(rRef)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(rDirec))
                    .add(lInterlocutor, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 458, Short.MAX_VALUE)
                    .add(jScrollPane3, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 458, Short.MAX_VALUE)
                    .add(jPanel1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );
        pnombrecomercialLayout.setVerticalGroup(
            pnombrecomercialLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(pnombrecomercialLayout.createSequentialGroup()
                .addContainerGap(23, Short.MAX_VALUE)
                .add(pnombrecomercialLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(tbusqueda1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(rNC)
                    .add(rNum)
                    .add(rEstado)
                    .add(rRef)
                    .add(rDirec))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(pnombrecomercialLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                    .add(pnombrecomercialLayout.createSequentialGroup()
                        .add(jScrollPane3, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 268, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(lInterlocutor, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 45, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jPanel1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(pnombrecomercialLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                            .add(bProv1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .add(bProv, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 42, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                    .add(jScrollPane1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 590, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
        );

        pDireccion.addTab("Búsqueda:", pnombrecomercial);

        pPendientes.setFont(new java.awt.Font("Tahoma", 0, 14));

        modelo8.addColumn("Entrega");
        modelo8.addColumn("Mont.");
        modelo8.addColumn("Interlocutor");
        modelo8.addColumn("Referencia");
        modelo8.addColumn("Número");
        modelo8.addColumn("Fecha");
        modelo8.addColumn("Dirección");
        modelo8.addColumn("Población");
        modelo8.addColumn("");

        Presupuesto p8;
        Iterator<Presupuesto> it8;
        Object[] fila8;

        if(listaP  != null){
            for (it8 = listaP.iterator(); it8.hasNext();) {
                fila8 = new Object[9];
                p8 = it8.next();

                intId = p8.getInterlocutor();
                if(!listaInt.containsKey(intId)){
                    emI = BaseDatos.obtenerEmpresaPorIid(intId);
                    listaInt.put(intId, emI.getCod_empresa());
                }

                fila8[0] = formatoFecha.format(new Date(p8.getFechaEntrega()));
                fila8[1] = (BaseDatos.obtenerMontaje(p8) == null)?"No":"Sí";
                fila8[2] = listaInt.get(intId);
                fila8[3] = p8.getReferencia();
                fila8[4] = p8.getNumero();
                fila8[5] = formatoFecha.format(new Date(p8.getFecha()));
                fila8[6] = p8.getProvinciaCliente();
                fila8[7] = p8.getDomicilioCliente();
                fila8[8] = p8.getIid();
                modelo8.addRow(fila8);
            }
        }

        tpresupuesto8.getColumnModel().getColumn(0).setPreferredWidth(60);
        tpresupuesto8.getColumnModel().getColumn(1).setPreferredWidth(40);
        tpresupuesto8.getColumnModel().getColumn(2).setPreferredWidth(120);
        tpresupuesto8.getColumnModel().getColumn(3).setPreferredWidth(250);
        tpresupuesto8.getColumnModel().getColumn(4).setPreferredWidth(60);
        tpresupuesto8.getColumnModel().getColumn(5).setPreferredWidth(180);
        tpresupuesto8.getColumnModel().getColumn(6).setPreferredWidth(120);
        tpresupuesto8.getColumnModel().getColumn(7).setPreferredWidth(120);
        tpresupuesto8.getColumnModel().getColumn(8).setWidth(0);
        tpresupuesto8.getColumnModel().getColumn(8).setMaxWidth(0);
        tpresupuesto8.getColumnModel().getColumn(8).setMinWidth(0);
        tpresupuesto8.getColumnModel().getColumn(8).setPreferredWidth(0);
        tpresupuesto8.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        tpresupuesto8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tpresupuesto8MouseClicked(evt);
            }
        });
        tpresupuesto8.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tpresupuesto8KeyPressed(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tpresupuesto8KeyReleased(evt);
            }
        });
        jScrollPane9.setViewportView(tpresupuesto8);

        pMontaje.setBorder(javax.swing.BorderFactory.createTitledBorder("Orden de Montaje"));

        jLabel1.setText("Montadores:");

        tobservaciones.setColumns(20);
        tobservaciones.setEditable(false);
        tobservaciones.setRows(5);
        jScrollPane2.setViewportView(tobservaciones);

        jLabel2.setText("Observaciones:");

        jLabel3.setText("Tipo de Montaje:");

        ttipo.setEditable(false);

        tmontador.setEditable(false);

        jLabel4.setText("Hora Inicio");

        thora.setEditable(false);

        beliminar.setText("Eliminar");
        beliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                beliminarActionPerformed(evt);
            }
        });

        bcomunicar.setText("Comunicar");

        jLabel5.setText("Fecha");

        tfecha.setEditable(false);

        jLabel6.setText("Hora Fin");

        thorafin.setEditable(false);

        jLabel7.setText("Duración Estimada:");

        tduracion.setEditable(false);

        jLabel8.setText("Duración Real:");

        tduracionreal.setEditable(false);

        jLabel9.setText("horas");

        jLabel10.setText("horas");

        org.jdesktop.layout.GroupLayout pMontajeLayout = new org.jdesktop.layout.GroupLayout(pMontaje);
        pMontaje.setLayout(pMontajeLayout);
        pMontajeLayout.setHorizontalGroup(
            pMontajeLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(pMontajeLayout.createSequentialGroup()
                .addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .add(pMontajeLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(pMontajeLayout.createSequentialGroup()
                        .add(pMontajeLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(pMontajeLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                                .add(pMontajeLayout.createSequentialGroup()
                                    .add(jLabel1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 89, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                    .add(tmontador))
                                .add(pMontajeLayout.createSequentialGroup()
                                    .add(jLabel3, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 89, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                    .add(ttipo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 145, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                            .add(pMontajeLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING, false)
                                .add(org.jdesktop.layout.GroupLayout.LEADING, beliminar, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .add(org.jdesktop.layout.GroupLayout.LEADING, bcomunicar)))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(pMontajeLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(pMontajeLayout.createSequentialGroup()
                                .add(pMontajeLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                                    .add(jLabel4)
                                    .add(jLabel6))
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                .add(pMontajeLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                                    .add(thorafin)
                                    .add(thora)
                                    .add(tfecha, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 77, Short.MAX_VALUE)))
                            .add(jLabel5)
                            .add(pMontajeLayout.createSequentialGroup()
                                .add(pMontajeLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                                    .add(jLabel7)
                                    .add(jLabel8))
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                .add(pMontajeLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING, false)
                                    .add(tduracionreal)
                                    .add(tduracion, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 24, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                                .add(pMontajeLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                                    .add(pMontajeLayout.createSequentialGroup()
                                        .add(12, 12, 12)
                                        .add(jLabel9))
                                    .add(org.jdesktop.layout.GroupLayout.TRAILING, pMontajeLayout.createSequentialGroup()
                                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                        .add(jLabel10))))))
                    .add(jLabel2)
                    .add(jScrollPane2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 347, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
        );
        pMontajeLayout.setVerticalGroup(
            pMontajeLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(pMontajeLayout.createSequentialGroup()
                .addContainerGap()
                .add(pMontajeLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(pMontajeLayout.createSequentialGroup()
                        .add(26, 26, 26)
                        .add(pMontajeLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(jLabel1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 24, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(tmontador, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(jLabel4, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 24, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(thora, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                    .add(pMontajeLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                        .add(ttipo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(jLabel5, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 24, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(jLabel3, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 24, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(tfecha, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                .add(pMontajeLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(pMontajeLayout.createSequentialGroup()
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(pMontajeLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(jLabel6, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 24, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(thorafin, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(pMontajeLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(tduracion, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(jLabel9, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 24, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(jLabel7, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 24, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(pMontajeLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(tduracionreal, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(jLabel10, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 24, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(jLabel8, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 24, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                    .add(pMontajeLayout.createSequentialGroup()
                        .add(15, 15, 15)
                        .add(bcomunicar)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(beliminar)))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                .add(jLabel2)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jScrollPane2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 140, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
        );

        org.jdesktop.layout.GroupLayout pPendientesLayout = new org.jdesktop.layout.GroupLayout(pPendientes);
        pPendientes.setLayout(pPendientesLayout);
        pPendientesLayout.setHorizontalGroup(
            pPendientesLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(pPendientesLayout.createSequentialGroup()
                .add(jScrollPane9, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 623, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(pMontaje, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        pPendientesLayout.setVerticalGroup(
            pPendientesLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(pMontaje, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
            .add(jScrollPane9, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 634, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
        );

        pDireccion.addTab("Pendientes", pPendientes);

        jScrollPane4.setViewportView(pDireccion);

        org.jdesktop.layout.GroupLayout layout = new org.jdesktop.layout.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(layout.createSequentialGroup()
                .addContainerGap(897, Short.MAX_VALUE)
                .add(bcrear, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 49, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(bBorrar, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 41, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(bvisualizar, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 46, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .add(8, 8, 8)
                .add(bcancelar, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 48, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
            .add(jScrollPane4, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 1111, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, layout.createSequentialGroup()
                .add(jScrollPane4, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 670, Short.MAX_VALUE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                    .add(bcancelar, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 37, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(bvisualizar, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 37, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(bBorrar, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 37, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(bcrear, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 37, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

private void bcancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bcancelarActionPerformed
    cerrarListaPresupuestos();
}//GEN-LAST:event_bcancelarActionPerformed

private void bcrearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bcrearActionPerformed
    crearPresupuesto();
}//GEN-LAST:event_bcrearActionPerformed

private void bBorrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bBorrarActionPerformed
    borrarPresupuesto();

    if (cd.getDescripcion().equals(Constantes.FACTURA)) {
        actualizarPresupuestos(BaseDatos.getListaFacturas(e.getIid()));
    } else {
        actualizarPresupuestos(BaseDatos.getListaPresupuesto(e.getIid(), cd.getIid()));
    }

    if (cd.getDescripcion().equalsIgnoreCase(Constantes.PEDIDO)) {
        actualizarPendientes(BaseDatos.getListaPendientes(u, e.getIid(), cd.getIid()));
    }
    
    this.obtenerResultado();
}//GEN-LAST:event_bBorrarActionPerformed

private void bvisualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bvisualizarActionPerformed
    visualizarPresupuesto();
}//GEN-LAST:event_bvisualizarActionPerformed

    private void tpresupuesto8MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tpresupuesto8MouseClicked
        Presupuesto pre = obtenerDocSelPendiente();
        seleccionadoDocumentoPendiente(pre);
        if (evt.getClickCount() == 2) {
            configurar(new NuevoPresupuesto(e, pre, u, this));
        }
    }//GEN-LAST:event_tpresupuesto8MouseClicked

    private void tpresupuesto8KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tpresupuesto8KeyPressed
        if (evt.getKeyChar() == KeyEvent.VK_ENTER) {
            Presupuesto pre = obtenerDocSelPendiente();
            if (pre != null) {
                seleccionadoDocumentoPendiente(pre);
                configurar(new NuevoPresupuesto(e, pre, u, this));
            }
        } else if (evt.getKeyChar() == KeyEvent.VK_DELETE) {
            bBorrarActionPerformed(null);
        }
        
    }//GEN-LAST:event_tpresupuesto8KeyPressed

    private void tpresupuesto1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tpresupuesto1KeyPressed
        if (evt.getKeyChar() == KeyEvent.VK_ENTER) {
            visualizarPresupuesto();
        } else if (evt.getKeyChar() == KeyEvent.VK_DELETE) {
            bBorrarActionPerformed(null);
        }
    }//GEN-LAST:event_tpresupuesto1KeyPressed

    private void tpresupuesto1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tpresupuesto1MouseClicked
        int indiceFila = tpresupuesto1.getSelectedRow();
        if (indiceFila >= 0) {
            Presupuesto pre = this.obtenerDocSel();
            if (pre != null) {
                rellenarLineas(pre);
            }
        }
        if (evt.getClickCount() == 2) {
            visualizarPresupuesto();
        }
    }//GEN-LAST:event_tpresupuesto1MouseClicked

    private void tbusqueda1KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tbusqueda1KeyReleased
        List lp = null;
        if (rNC.isSelected()) {
            lp = BaseDatos.busquedaRapidaDocumentoPorNombreComercial(tbusqueda1.getText().toLowerCase(), cd.getIid(), e.getIid());
        } else if (rNum.isSelected()) {
            lp = BaseDatos.busquedaRapidaDocumentoPorNumero(tbusqueda1.getText().toLowerCase(), cd.getIid(), e.getIid());
        } else if (rEstado.isSelected()) {
            lp = BaseDatos.busquedaRapidaDocumentoPorEstado(tbusqueda1.getText().toLowerCase(), cd.getIid(), e.getIid());
        } else if (rRef.isSelected()) {
            lp = BaseDatos.busquedaRapidaDocumentoPorReferencia(tbusqueda1.getText().toLowerCase(), cd.getIid(), e.getIid());
        } else if (rDirec.isSelected()) {
            lp = BaseDatos.busquedaRapidaDocumentosPorDireccion(tbusqueda1.getText().toLowerCase(), e.getIid(), cd.getIid());
        }
        actualizarPresupuestos(lp);
    }//GEN-LAST:event_tbusqueda1KeyReleased

    private void bProvActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bProvActionPerformed
        //PROCESAR DOCUMENTOS
        Presupuesto pS = obtenerDocSel();
        if (pS != null) {
            configurar(new DatosConversion(pS, "directo", this.e, this.u));
        }
    }//GEN-LAST:event_bProvActionPerformed

    private void rNCActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rNCActionPerformed
        if (rNC.isSelected()) {
            actualizarPresupuestos(BaseDatos.busquedaRapidaDocumentoPorNombreComercial(tbusqueda1.getText().toLowerCase(), cd.getIid(), e.getIid()));
        }
    }//GEN-LAST:event_rNCActionPerformed

    private void rNumActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rNumActionPerformed
        if (rNum.isSelected()) {
            actualizarPresupuestos(BaseDatos.busquedaRapidaDocumentoPorNumero(tbusqueda1.getText().toLowerCase(), cd.getIid(), e.getIid()));
        }
    }//GEN-LAST:event_rNumActionPerformed

    private void rEstadoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rEstadoActionPerformed
        if (rEstado.isSelected()) {
            actualizarPresupuestos(BaseDatos.busquedaRapidaDocumentoPorEstado(tbusqueda1.getText().toLowerCase(), cd.getIid(), e.getIid()));
        }
    }//GEN-LAST:event_rEstadoActionPerformed

    private void rRefActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rRefActionPerformed
        if (rRef.isSelected()) {
            actualizarPresupuestos(BaseDatos.busquedaRapidaDocumentoPorReferencia(tbusqueda1.getText().toLowerCase(), cd.getIid(), e.getIid()));
        }
    }//GEN-LAST:event_rRefActionPerformed

    private void rDirecActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rDirecActionPerformed
        if (rDirec.isSelected()) {
            actualizarPresupuestos(BaseDatos.busquedaRapidaDocumentosPorDireccion(tbusqueda1.getText().toLowerCase(), e.getIid(), cd.getIid()));
        }
    }//GEN-LAST:event_rDirecActionPerformed

    protected void obtenerResultado() {
        List lp = null;
        if (rDirec.isSelected()) {
            lp = BaseDatos.busquedaRapidaDocumentosPorDireccion(tbusqueda1.getText().toLowerCase(), e.getIid(), cd.getIid());
        } else if (rRef.isSelected()) {
            lp = BaseDatos.busquedaRapidaDocumentoPorReferencia(tbusqueda1.getText().toLowerCase(), cd.getIid(), e.getIid());
        } else if (rEstado.isSelected()) {
            lp = BaseDatos.busquedaRapidaDocumentoPorEstado(tbusqueda1.getText().toLowerCase(), cd.getIid(), e.getIid());
        } else if (rNum.isSelected()) {
            lp = BaseDatos.busquedaRapidaDocumentoPorNumero(tbusqueda1.getText().toLowerCase(), cd.getIid(), e.getIid());
        } else if (rNC.isSelected()) {
            lp = BaseDatos.busquedaRapidaDocumentoPorNombreComercial(tbusqueda1.getText().toLowerCase(), cd.getIid(), e.getIid());
        }
        actualizarPresupuestos(lp);

        //Actualizamos la lista de pendientes
        if(this.cd.getDescripcion().equalsIgnoreCase(Constantes.PEDIDO)){
            actualizarPendientes(BaseDatos.getListaPendientes(u, e.getIid(), cd.getIid()));
        }
    }

    private void bProv1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bProv1ActionPerformed
        Presupuesto pS = obtenerDocSel();
        if (pS != null) {
            configurar(new flujoDatos(pS, e, u));
        }
    }//GEN-LAST:event_bProv1ActionPerformed

    private void beliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_beliminarActionPerformed
        BaseDatos.eliminarMontaje(m);
        pMontaje.setVisible(false);
    }//GEN-LAST:event_beliminarActionPerformed

    private int obtenerInterlocutor() {
        int interlocutor = 0;
        if (!cInterlocutor.getSelectedItem().equals(Constantes.TODOS)) {
            Empresa em = BaseDatos.obtenerEmpresaDesc((String) cInterlocutor.getSelectedItem());
            if (em != null) {
                interlocutor = em.getIid();
                lInterlocutor.setText(em.getDesc_empresa());
            } else {
                interlocutor = 0;
            }
        } else {
            lInterlocutor.setText("");
        }
        return interlocutor;
    }

    private void bBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bBuscarActionPerformed
        actualizarPresupuestos(BaseDatos.busquedaCompuestaPresupuesto(e, tNombreComercial.getText(), tNumero.getText(), tReferencia.getText(), tDireccion.getText(), cd.getIid(), fInicio.getDate().getTime(), fFin.getDate().getTime(), this.obtenerInterlocutor()));
    }//GEN-LAST:event_bBuscarActionPerformed

    private void tNombreComercialKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tNombreComercialKeyPressed
        if (evt.getKeyChar() == KeyEvent.VK_ENTER) {
            actualizarPresupuestos(BaseDatos.busquedaCompuestaPresupuesto(e, tNombreComercial.getText(), tNumero.getText(), tReferencia.getText(), tDireccion.getText(), cd.getIid(), fInicio.getDate().getTime(), fFin.getDate().getTime(), this.obtenerInterlocutor()));
        }
    }//GEN-LAST:event_tNombreComercialKeyPressed

    private void tNumeroKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tNumeroKeyPressed
        if (evt.getKeyChar() == KeyEvent.VK_ENTER) {
            actualizarPresupuestos(BaseDatos.busquedaCompuestaPresupuesto(e, tNombreComercial.getText(), tNumero.getText(), tReferencia.getText(), tDireccion.getText(), cd.getIid(), fInicio.getDate().getTime(), fFin.getDate().getTime(), this.obtenerInterlocutor()));
        }
    }//GEN-LAST:event_tNumeroKeyPressed

    private void fInicioKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_fInicioKeyPressed
        if (evt.getKeyChar() == KeyEvent.VK_ENTER) {
            actualizarPresupuestos(BaseDatos.busquedaCompuestaPresupuesto(e, tNombreComercial.getText(), tNumero.getText(), tReferencia.getText(), tDireccion.getText(), cd.getIid(), fInicio.getDate().getTime(), fFin.getDate().getTime(), this.obtenerInterlocutor()));
        }
    }//GEN-LAST:event_fInicioKeyPressed

    private void fFinKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_fFinKeyPressed
        if (evt.getKeyChar() == KeyEvent.VK_ENTER) {
            actualizarPresupuestos(BaseDatos.busquedaCompuestaPresupuesto(e, tNombreComercial.getText(), tNumero.getText(), tReferencia.getText(), tDireccion.getText(), cd.getIid(), fInicio.getDate().getTime(), fFin.getDate().getTime(), this.obtenerInterlocutor()));
        }
    }//GEN-LAST:event_fFinKeyPressed

    private void tReferenciaKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tReferenciaKeyPressed
        if (evt.getKeyChar() == KeyEvent.VK_ENTER) {
            actualizarPresupuestos(BaseDatos.busquedaCompuestaPresupuesto(e, tNombreComercial.getText(), tNumero.getText(), tReferencia.getText(), tDireccion.getText(), cd.getIid(), fInicio.getDate().getTime(), fFin.getDate().getTime(), this.obtenerInterlocutor()));
        }
    }//GEN-LAST:event_tReferenciaKeyPressed

    private void tDireccionKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tDireccionKeyPressed
        if (evt.getKeyChar() == KeyEvent.VK_ENTER) {
            actualizarPresupuestos(BaseDatos.busquedaCompuestaPresupuesto(e, tNombreComercial.getText(), tNumero.getText(), tReferencia.getText(), tDireccion.getText(), cd.getIid(), fInicio.getDate().getTime(), fFin.getDate().getTime(), this.obtenerInterlocutor()));
        }
    }//GEN-LAST:event_tDireccionKeyPressed

private void tpresupuesto1KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tpresupuesto1KeyReleased
    if (evt.getKeyCode() == KeyEvent.VK_UP || evt.getKeyCode() == KeyEvent.VK_DOWN) {
        int indiceFila = tpresupuesto1.getSelectedRow();
        if (indiceFila >= 0) {
            Presupuesto pre = this.obtenerDocSel();
            if (pre != null) {
                rellenarLineas(pre);
            }
        }
    }
}//GEN-LAST:event_tpresupuesto1KeyReleased

private void tpresupuesto8KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tpresupuesto8KeyReleased
    if (evt.getKeyCode() == KeyEvent.VK_UP || evt.getKeyCode() == KeyEvent.VK_DOWN) {
        seleccionadoDocumentoPendiente(null);
    }
}//GEN-LAST:event_tpresupuesto8KeyReleased

    private void visualizarPresupuesto() {
        Presupuesto pre;
        if (this.pDireccion.getSelectedIndex() == 0) {
            pre = this.obtenerDocSel();
        } else {
            pre = this.obtenerDocSelPendiente();
        }

        if (pre != null) {
            configurar(new NuevoPresupuesto(e, pre, u, this));
        }
    }

    private void rellenarLineas(Presupuesto p) {
        Modelo modelo = (Modelo) tLineas.getModel();
        int i, j = modelo.getRowCount();
        //eliminamos todas las filas
        for (i = 0; i < j; i++) {
            modelo.removeRow(0);
        }

        List lineas = BaseDatos.getListaLineaPresupuesto(p.getIid());
        LineaPresupuesto lp;
        int contador;
        Articulo a;
        Object[] fila;
        Iterator<LineaPresupuesto> it;
        if (lineas != null) {
            contador = 1;
            for (it = lineas.iterator(); it.hasNext(); contador++) {
                lp = it.next();
                if (lp.getArticulo_iid() != null) {
                    fila = new Object[6];
                    a = BaseDatos.obtenerArticuloPorIid(lp.getArticulo_iid().getIid());
                    fila[0] = contador;
                    fila[1] = "Artículo";
                    fila[2] = Util.convertirPuntoAComa(lp.getCantidad().toString());
                    fila[3] = lp.getDescripcion();
                    fila[4] = Util.convertirPuntoAComa(lp.getPrecio().toString());
                    fila[5] = Util.convertirPuntoAComa(lp.getImporte().toString());
                    modelo.addRow(fila);
                }
            }
        }
    }

    private void actualizarPresupuestos(List lpresupuesto1) {
        Modelo modelo1 = (Modelo) tpresupuesto1.getModel();
        int i, j = modelo1.getRowCount();

        List<Integer> listaPagados = new ArrayList<Integer>();
        List<Integer> listaImpagados = new ArrayList<Integer>();
        int contador = 0;
        Presupuesto pTemp;
        Iterator<Presupuesto> it = lpresupuesto1.iterator();
        while (it.hasNext()) {
            pTemp = it.next();
            if (pTemp.getPagado() != null && pTemp.getPagado()) {
                listaPagados.add(contador);
            } else if (pTemp.getImpagado() != null && pTemp.getImpagado()) {
                listaImpagados.add(contador);
            }
            contador++;
        }

        tpresupuesto1.setDefaultRenderer(Object.class, new ColorRenderer(listaPagados, Color.GREEN, listaImpagados, Color.RED));

        //eliminamos todas las filas
        for (i = 0; i < j; i++) {
            modelo1.removeRow(0);
        }

        if (lpresupuesto1 == null) {
            lpresupuesto1 = new ArrayList();
        }

        Presupuesto p1;
        Iterator<Presupuesto> it1;
        Object[] fila1;
        SimpleDateFormat formatoFecha = new SimpleDateFormat("dd/MM/yyyy");
        EstadoDocumento es;
        Empresa emI;
        Integer estId;
        Integer intId;

        if (lpresupuesto1 != null) {
            for (it1 = lpresupuesto1.iterator(); it1.hasNext();) {
                fila1 = new Object[11];
                p1 = it1.next();

                intId = p1.getInterlocutor();
                if (!listaInt.containsKey(intId)) {
                    emI = BaseDatos.obtenerEmpresaPorIid(intId);
                    listaInt.put(intId, emI.getDesc_empresa());
                }

                estId = p1.getEstado().getIid();
                if (!listaEst.containsKey(estId)) {
                    es = BaseDatos.obtenerEstadoPorIid(estId);
                    listaEst.put(estId, es.getDescripcion());
                }

                fila1[0] = listaInt.get(intId);
                fila1[1] = p1.getNombreCliente();
                fila1[2] = p1.getNumero();
                fila1[3] = p1.getReferencia();
                fila1[4] = formatoFecha.format(new Date(p1.getFecha()));
                fila1[5] = Util.convertirPuntoAComa(String.valueOf(Matematico.redondear2decimales(p1.getImporte_total()))) + " €";
                fila1[6] = listaEst.get(estId);
                fila1[7] = p1.getDomicilioCliente();
                fila1[8] = p1.getProvinciaCliente();
                if (cd.getDescripcion().equals(Constantes.PEDIDO)) {
                    fila1[9] = formatoFecha.format(new Date(p1.getFechaEntrega()));
                    fila1[10] = p1.getIid();
                } else {
                    fila1[9] = p1.getIid();
                }
                modelo1.addRow(fila1);
            }
        }
    }

    private void actualizarPendientes(List lpresupuesto) {
        Modelo modelo1 = (Modelo) tpresupuesto8.getModel();
        int i, j = modelo1.getRowCount();
        Date hoy = new Date();
        List listaPagados = new ArrayList();
        Presupuesto p1;
        Iterator<Presupuesto> it1;
        Object[] fila1;
        Integer intId;
        Empresa emI;
        SimpleDateFormat formatoFecha = new SimpleDateFormat("dd/MM/yyyy");
        List<Integer> listaCaducados = new ArrayList<Integer>();
        Integer contador = 0;

        //eliminamos todas las filas
        for (i = 0; i < j; i++) {
            modelo1.removeRow(0);
        }

        if (lpresupuesto == null) {
            lpresupuesto = new ArrayList();
        }

        if (lpresupuesto != null) {
            for (it1 = lpresupuesto.iterator(); it1.hasNext();) {
                fila1 = new Object[9];
                p1 = it1.next();
                
                if (p1.getPagado() != null && p1.getPagado()) {
                    listaPagados.add(contador);
                }
                if ((p1.getFechaEntrega() != null && (p1.getFechaEntrega()) < hoy.getTime()) && !p1.getInstalado()) {
                    listaCaducados.add(contador);
                }
                contador++;

                intId = p1.getInterlocutor();
                if (!listaInt.containsKey(intId)) {
                    emI = BaseDatos.obtenerEmpresaPorIid(intId);
                    listaInt.put(intId, emI.getDesc_empresa());
                }

                fila1[0] = formatoFecha.format(new Date(p1.getFechaEntrega()));
                fila1[1] = (BaseDatos.obtenerMontaje(p1) != null) ? "Sí" : "No";
                fila1[2] = listaInt.get(intId);
                fila1[3] = p1.getReferencia();
                fila1[4] = p1.getNumero();
                fila1[5] = formatoFecha.format(new Date(p1.getFecha()));
                fila1[6] = p1.getProvinciaCliente();
                fila1[7] = p1.getDomicilioCliente();
                fila1[8] = p1.getIid();
                modelo1.addRow(fila1);
            }
            tpresupuesto8.setDefaultRenderer(Object.class, new ColorRenderer(listaPagados, Color.GREEN, listaCaducados, Color.ORANGE));
        }
    }

    private void crearIconosBotones() {
        URL url = getClass().getResource("/iconos/detalle.png");
        ImageIcon icono = new ImageIcon(url);
        bvisualizar.setIcon(icono);

        url = getClass().getResource("/iconos/borrar32.png");
        icono = new ImageIcon(url);
        bBorrar.setIcon(icono);

        url = getClass().getResource("/iconos/eliminar.png");
        icono = new ImageIcon(url);
        bcancelar.setIcon(icono);

        url = getClass().getResource("/iconos/aceptar.png");
        ImageIcon iconoCrear = new ImageIcon(url);
        bcrear.setIcon(iconoCrear);

        url = getClass().getResource("/iconos/buscar.gif");
        icono = new ImageIcon(url);
        bBuscar.setIcon(icono);

        url = getClass().getResource("/iconos/flujo32.png");
        icono = new ImageIcon(url);
        bProv1.setIcon(icono);

        url = getClass().getResource("/iconos/convertir32.png");
        icono = new ImageIcon(url);
        bProv.setIcon(icono);
    }

    private void borrarPresupuesto() {
        try {
            int indicePanel = this.pDireccion.getSelectedIndex();
            int indiceFila = -1;
            Integer iid = null;

            if (indicePanel == 0) {
                indiceFila = this.tpresupuesto1.getSelectedRow();
                if (indiceFila >= 0) {
                    if (cd.getDescripcion().equals(Constantes.PEDIDO)) {
                        iid = (Integer) tpresupuesto1.getModel().getValueAt(indiceFila, 10);
                    } else {
                        iid = (Integer) tpresupuesto1.getModel().getValueAt(indiceFila, 9);
                    }
                }
            } else {
                indiceFila = this.tpresupuesto8.getSelectedRow();
                if (indiceFila >= 0) {
                    iid = (Integer) tpresupuesto8.getModel().getValueAt(indiceFila, 8);
                }
            }

            if (indiceFila >= 0) {
                int eliminar = 1;
                eliminar = JOptionPane.showConfirmDialog(null, "¿Está seguro de que desea eliminar el elemento seleccionado?", "¿Eliminar?", JOptionPane.YES_NO_OPTION);
                //hacerCambios = -1 ==> se ha pulsado la "x" de cancelar;
                //hacerCambios =  0 ==> se ha pulsado el "sí"
                //hacerCambios =  1 ==> se ha pulsado el "no"

                if (eliminar == 0) {
                    if (BaseDatos.eliminarPresupuesto(iid)) {
                        JOptionPane.showMessageDialog(null, "Documento eliminado satisfactoriamente", "Información", JOptionPane.INFORMATION_MESSAGE);
                        obtenerResultado();
                    } else {
                        JOptionPane.showMessageDialog(null, "No se ha podido eliminar el elemento seleccionado", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
            } else {
                JOptionPane.showMessageDialog(null, "No hay seleccionado ningún elemento", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Este elemento no se puede eliminar", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private Presupuesto obtenerDocSelPendiente() {
        Integer indiceFila = tpresupuesto8.getSelectedRow();
        if (indiceFila != -1) {
            return BaseDatos.obtenerPresupuesto((Integer) tpresupuesto8.getModel().getValueAt(indiceFila, 8));
        } else {
            JOptionPane.showMessageDialog(null, "No hay seleccionado ningún elemento", "Error", JOptionPane.ERROR_MESSAGE);
            return null;
        }
    }

    private void seleccionadoDocumentoPendiente(Presupuesto pre) {
        if (pre == null) {
            pre = obtenerDocSelPendiente();
        }
        m = BaseDatos.obtenerMontaje(pre);
        //Si existe montaje y el usuario es oficina o administrador mostramos el detalle de montaje
        if ((m != null) && (u.getTipo().equals(Constantes.USUARIO_OFICINA) || u.getTipo().equals(Constantes.USUARIO_ADMINISTRADOR))) {
            //Obtener fecha de entrega
            SimpleDateFormat formatoDelTexto = new SimpleDateFormat("dd/MM/yyyy");
            pMontaje.setVisible(true);
            ttipo.setText(m.getIidTipo().getDescripcion());
            thora.setText(m.getHora());
            tmontador.setText(m.getMontador());
            tobservaciones.setText(m.getObservaciones());
            tduracion.setText(m.getDuracionEst());
            tduracionreal.setText(m.getDuracionFin());
            thorafin.setText(m.getHoraFin());
            tfecha.setText(formatoDelTexto.format(pre.getFechaEntrega()));
        } else {
            pMontaje.setVisible(false);
        }
    }

    private Presupuesto obtenerDocSel() {
        Integer indiceFila = tpresupuesto1.getSelectedRow();
        if (indiceFila != -1) {
            Integer iid = null;
            if (cd.getDescripcion().equals(Constantes.PEDIDO)) {
                iid = (Integer) tpresupuesto1.getModel().getValueAt(indiceFila, 10);
            } else {
                iid = (Integer) tpresupuesto1.getModel().getValueAt(indiceFila, 9);
            }
            return BaseDatos.obtenerPresupuesto(iid);
        } else {
            JOptionPane.showMessageDialog(null, "No hay seleccionado ningún elemento", "Error", JOptionPane.ERROR_MESSAGE);
            return null;
        }
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bBorrar;
    private javax.swing.JButton bBuscar;
    private javax.swing.JButton bProv;
    private javax.swing.JButton bProv1;
    private javax.swing.JButton bcancelar;
    private javax.swing.JButton bcomunicar;
    private javax.swing.JButton bcrear;
    private javax.swing.JButton beliminar;
    private javax.swing.JButton bvisualizar;
    private javax.swing.JComboBox cInterlocutor;
    private com.toedter.calendar.JDateChooser fFin;
    private com.toedter.calendar.JDateChooser fInicio;
    private javax.swing.ButtonGroup gBusqueda;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane9;
    private javax.swing.JLabel lInterlocutor;
    private javax.swing.JTabbedPane pDireccion;
    private javax.swing.JPanel pMontaje;
    private javax.swing.JPanel pPendientes;
    private javax.swing.JPanel pnombrecomercial;
    private javax.swing.JRadioButton rDirec;
    private javax.swing.JRadioButton rEstado;
    private javax.swing.JRadioButton rNC;
    private javax.swing.JRadioButton rNum;
    private javax.swing.JRadioButton rRef;
    private javax.swing.JTextField tDireccion;
    private javax.swing.JTable tLineas;
    private javax.swing.JTextField tNombreComercial;
    private javax.swing.JTextField tNumero;
    private javax.swing.JTextField tReferencia;
    private javax.swing.JTextField tbusqueda1;
    private javax.swing.JTextField tduracion;
    private javax.swing.JTextField tduracionreal;
    private javax.swing.JTextField tfecha;
    private javax.swing.JTextField thora;
    private javax.swing.JTextField thorafin;
    private javax.swing.JTextField tmontador;
    private javax.swing.JTextArea tobservaciones;
    private javax.swing.JTable tpresupuesto1;
    private javax.swing.JTable tpresupuesto8;
    private javax.swing.JTextField ttipo;
    // End of variables declaration//GEN-END:variables
}
