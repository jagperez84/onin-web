package gui;

import acceso.BaseDatos;
import bean.Almacen;
import bean.Articulo;
import bean.Colores;

import bean.TipoMovimientoAlmacen;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import bean.Caracteristica;
import bean.Empresa;
import bean.FamiliaVenta;
import bean.MovimientoAlmacen;
import bean.TipoControl;
import bean.TipoMedida;
import bean.UnidadMedida;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.net.URL;
import java.text.ParseException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JOptionPane;
import javax.swing.KeyStroke;
import util.Constantes;
import util.Util;

public class NuevoMovimientoAlmacen extends javax.swing.JFrame {

    private Caracteristica car;
    private Articulo ar;
    private Empresa e;
    private int numMedidas;
    private MovimientoAlmacen mva;
    private NuevoArticulo nar;
    private boolean crear;
    private ListaDeMovimientos lm;
    private MovimientoAlmacen mvaAntiguo;
    private List<Caracteristica> listaCaracteristicas;

    public NuevoMovimientoAlmacen(Articulo ar, Empresa e, NuevoArticulo nar, List<Caracteristica> listaCaracteristicas) {
        super("Movimiento de Almacén - Creación");
        this.ar = ar;
        this.e = e;
        this.nar = nar;
        mva = new MovimientoAlmacen();
        this.listaCaracteristicas = listaCaracteristicas;
        numMedidas = ar.getIid_fam_venta().getIid_tipo_control().getIid_tipo_medida().getNum_dimensiones();
        crear = true;
        initComponents();
        if(ar != null && ar.getPrecio_v() != null){
            tPrecio.setText(Util.convertirPuntoAComa(String.valueOf(ar.getPrecio_v())));
        }
        mostrarCantidades(numMedidas);
        bModificar.setVisible(false);
        
        crearIconosBotones();
        crearAcciones();
    }

    public NuevoMovimientoAlmacen(ListaDeMovimientos lm, MovimientoAlmacen mva) {
        super("Movimiento de Almacén - Modificación");
        this.lm = lm;
        this.mva = mva;
        this.ar = mva.getArticulo();
        this.e = mva.getEmpresa();

        mvaAntiguo = mva.copiar();
        numMedidas = ar.getIid_fam_venta().getIid_tipo_control().getIid_tipo_medida().getNum_dimensiones();
        crear = false;
        listaCaracteristicas = BaseDatos.getListaCaracteristicas(e, ar);
        initComponents();
        mostrarCantidades(numMedidas);

        String codArticulo = ar.getCod_articulo();
        SimpleDateFormat formatoFecha = new SimpleDateFormat("dd/MM/yyyy");
        
        tFecha.setText(formatoFecha.format(new Date(mva.getFecha())));
        tConcepto.setText(mva.getConcepto());
        cTipoMovimiento.setSelectedItem((String) mva.getTipoMovimiento().getNombre());

        if (mva.getCaracteristica() != null) {
            cCaracteristica.setSelectedItem(mva.getCaracteristica().getIid_color().getDescripcion());
            codArticulo += "/" + cCaracteristica.getSelectedItem();
        }

        tArtCar.setText(codArticulo);
        cAlmacen.setSelectedItem(mva.getAlmacen().getNombre());
        
        if(mva.isIniciarMedidas() != null){
            cbInicializar.setSelected(mva.isIniciarMedidas());
        }
        cValoracionPrecio.setSelectedItem(mva.getValoracionPrecio());
        
        String precioS = "0";
        if(mva.getPrecio() != null){
            precioS = String.valueOf(mva.getPrecio());
        }
        
        String cantidadS = "0";
        if(mva.getCantidad() != null){
            cantidadS = String.valueOf(mva.getCantidad());
        }
        
        tPrecio.setText(Util.convertirPuntoAComa(precioS));
        tCantidad.setText(Util.convertirPuntoAComa(cantidadS));
        
        if (mva.getCantidad1() != null) {
            tMedida1.setText(Util.convertirPuntoAComa(String.valueOf(mva.getCantidad1())));
        }
        if (mva.getCantidad2() != null) {
            tMedida2.setText(Util.convertirPuntoAComa(String.valueOf(mva.getCantidad2())));
        }
        if (mva.getCantidad3() != null) {
            tMedida3.setText(Util.convertirPuntoAComa(String.valueOf(mva.getCantidad3())));
        }
        if (mva.getCantidad4() != null) {
            tMedida4.setText(Util.convertirPuntoAComa(String.valueOf(mva.getCantidad4())));
        }
        if (mva.getCantidad5() != null) {
            tMedida5.setText(Util.convertirPuntoAComa(String.valueOf(mva.getCantidad5())));
        }
        
        calcularImporte();

        cTipoMovimiento.setEnabled(false);
        cCaracteristica.setEnabled(false);
        cValoracionPrecio.setEnabled(false);
        tConcepto.setEnabled(false);
        tCantidad.setEnabled(false);
        tMedida1.setEnabled(false);
        tMedida2.setEnabled(false);
        tMedida3.setEnabled(false);
        tMedida4.setEnabled(false);
        tMedida5.setEnabled(false);
        cAlmacen.setEnabled(false);
        cbInicializar.setEnabled(false);
        tPrecio.setEnabled(false);
        
        crearIconosBotones();
        crearAcciones();
    }

    private void cerrarMovimiento() {
        dispose();
    }

    private void crearIconosBotones() {
        URL urlCancelar = getClass().getResource("/iconos/cancelar.gif");
        ImageIcon iconoCancelar = new ImageIcon(urlCancelar);
        bCancelar.setIcon(iconoCancelar);
        
        URL urlAceptar = getClass().getResource("/iconos/guardarYvolver.png");
        ImageIcon iconoAceptar = new ImageIcon(urlAceptar);
        bAceptar.setIcon(iconoAceptar);
        
        URL urlModificar = getClass().getResource("/iconos/editar.png");
        ImageIcon iconoModificar = new ImageIcon(urlModificar);
        bModificar.setIcon(iconoModificar);
    }

    private void crearAcciones() {
        KeyStroke escapeKeyStroke = KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false);
        Action escapeAction = new AbstractAction() {
            public void actionPerformed(ActionEvent e) {
                cerrarMovimiento();
            }
        }; 
        getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(escapeKeyStroke, "ESCAPE");
        getRootPane().getActionMap().put("ESCAPE", escapeAction);
    }
    
    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lfecha = new javax.swing.JLabel();
        tFecha = new javax.swing.JTextField();
        lnumero = new javax.swing.JLabel();
        tnumero = new javax.swing.JTextField();
        bCancelar = new javax.swing.JButton();
        bAceptar = new javax.swing.JButton();
        pCantidadesMedidas = new javax.swing.JPanel();
        lCantidad = new javax.swing.JLabel();
        tCantidad = new javax.swing.JTextField();
        lMedidaTotal = new javax.swing.JLabel();
        tMedidaTotal = new javax.swing.JTextField();
        lMed3 = new javax.swing.JLabel();
        lMedida1 = new javax.swing.JLabel();
        tMedida1 = new javax.swing.JTextField();
        lMed1 = new javax.swing.JLabel();
        lMedida2 = new javax.swing.JLabel();
        tMedida2 = new javax.swing.JTextField();
        lMed2 = new javax.swing.JLabel();
        lMedida3 = new javax.swing.JLabel();
        tMedida3 = new javax.swing.JTextField();
        lMed5 = new javax.swing.JLabel();
        lMedida4 = new javax.swing.JLabel();
        tMedida4 = new javax.swing.JTextField();
        lMed4 = new javax.swing.JLabel();
        tMedida5 = new javax.swing.JTextField();
        lMedida5 = new javax.swing.JLabel();
        lMed = new javax.swing.JLabel();
        lMovimiento = new javax.swing.JLabel();
        cTipoMovimiento = new javax.swing.JComboBox();
        lConcepto = new javax.swing.JLabel();
        tConcepto = new javax.swing.JTextField();
        lArticuloCaracteristica = new javax.swing.JLabel();
        cCaracteristica = new javax.swing.JComboBox();
        tArtCar = new javax.swing.JTextField();
        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        cAlmacen = new javax.swing.JComboBox();
        cbInicializar = new javax.swing.JCheckBox();
        pPrecio = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        tPrecio = new javax.swing.JTextField();
        tImporte = new javax.swing.JTextField();
        lImporte = new javax.swing.JLabel();
        lValoracion = new javax.swing.JLabel();
        cValoracionPrecio = new javax.swing.JComboBox();
        bModificar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        lfecha.setText("Fecha");

        tFecha.setEditable(false);

        lnumero.setText("Número");

        tnumero.setEditable(false);

        bCancelar.setText("Cancelar");
        bCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bCancelarActionPerformed(evt);
            }
        });

        bAceptar.setText("Aceptar");
        bAceptar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bAceptarActionPerformed(evt);
            }
        });

        pCantidadesMedidas.setBorder(javax.swing.BorderFactory.createTitledBorder("Cantidades y medidas"));

        lCantidad.setText("Cantidad");

        tCantidad.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tCantidadKeyReleased(evt);
            }
        });

        lMedidaTotal.setText("Medida Total");

        tMedidaTotal.setEditable(false);

        lMed3.setText("umt");

        lMedida1.setText("Cantidad");

        tMedida1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tMedida1KeyReleased(evt);
            }
        });

        lMed1.setText("umt");

        lMedida2.setText("Cantidad");

        tMedida2.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tMedida2KeyReleased(evt);
            }
        });

        lMed2.setText("umt");

        lMedida3.setText("Cantidad");

        tMedida3.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tMedida3KeyReleased(evt);
            }
        });

        lMed5.setText("umt");

        lMedida4.setText("Cantidad");

        tMedida4.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tMedida4KeyReleased(evt);
            }
        });

        lMed4.setText("umt");

        tMedida5.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tMedida5KeyReleased(evt);
            }
        });

        lMedida5.setText("Cantidad");

        lMed.setText("umt");

        org.jdesktop.layout.GroupLayout pCantidadesMedidasLayout = new org.jdesktop.layout.GroupLayout(pCantidadesMedidas);
        pCantidadesMedidas.setLayout(pCantidadesMedidasLayout);
        pCantidadesMedidasLayout.setHorizontalGroup(
            pCantidadesMedidasLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(pCantidadesMedidasLayout.createSequentialGroup()
                .addContainerGap()
                .add(pCantidadesMedidasLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(pCantidadesMedidasLayout.createSequentialGroup()
                        .add(lCantidad)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(tCantidad, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 95, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(28, 28, 28)
                        .add(lMedidaTotal)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(tMedidaTotal, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 120, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(lMed, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 90, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                    .add(pCantidadesMedidasLayout.createSequentialGroup()
                        .add(pCantidadesMedidasLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(lMedida1)
                            .add(pCantidadesMedidasLayout.createSequentialGroup()
                                .add(tMedida1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 75, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                .add(lMed1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 84, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                        .add(28, 28, 28)
                        .add(pCantidadesMedidasLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(pCantidadesMedidasLayout.createSequentialGroup()
                                .add(tMedida2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 75, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                .add(lMed2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 84, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                            .add(lMedida2))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(pCantidadesMedidasLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(lMedida3)
                            .add(pCantidadesMedidasLayout.createSequentialGroup()
                                .add(tMedida3, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 75, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                .add(lMed3, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 90, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))))
                    .add(pCantidadesMedidasLayout.createSequentialGroup()
                        .add(pCantidadesMedidasLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(lMedida4)
                            .add(pCantidadesMedidasLayout.createSequentialGroup()
                                .add(tMedida4, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 75, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                .add(lMed4, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 84, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                        .add(28, 28, 28)
                        .add(pCantidadesMedidasLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(pCantidadesMedidasLayout.createSequentialGroup()
                                .add(tMedida5, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 75, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                .add(lMed5, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 84, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                            .add(lMedida5))))
                .addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        pCantidadesMedidasLayout.setVerticalGroup(
            pCantidadesMedidasLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(pCantidadesMedidasLayout.createSequentialGroup()
                .addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .add(pCantidadesMedidasLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(lCantidad)
                    .add(tCantidad, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(lMedidaTotal)
                    .add(tMedidaTotal, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(lMed))
                .add(18, 18, 18)
                .add(pCantidadesMedidasLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(pCantidadesMedidasLayout.createSequentialGroup()
                        .add(lMedida1)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(pCantidadesMedidasLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(tMedida1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(lMed1)))
                    .add(pCantidadesMedidasLayout.createSequentialGroup()
                        .add(lMedida2)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(pCantidadesMedidasLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(tMedida2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(lMed2)))
                    .add(pCantidadesMedidasLayout.createSequentialGroup()
                        .add(lMedida3)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(pCantidadesMedidasLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(tMedida3, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(lMed3))))
                .add(18, 18, 18)
                .add(pCantidadesMedidasLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(pCantidadesMedidasLayout.createSequentialGroup()
                        .add(lMedida4)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(pCantidadesMedidasLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(tMedida4, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(lMed4)))
                    .add(pCantidadesMedidasLayout.createSequentialGroup()
                        .add(lMedida5)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(pCantidadesMedidasLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(tMedida5, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(lMed5)))))
        );

        tArtCar.setEditable(false);
        tArtCar.setEditable(false);
        tArtCar.setEditable(false);
        tArtCar.setEditable(false);
        tArtCar.setEditable(false);
        tArtCar.setEditable(false);
        tArtCar.setEditable(false);

        lMovimiento.setText("Tipo de Movimiento");

        cTipoMovimiento.setModel(new javax.swing.DefaultComboBoxModel(new String[] {}));

        lConcepto.setText("Concepto");

        tConcepto.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tConceptoKeyReleased(evt);
            }
        });

        lArticuloCaracteristica.setText("Artículo/Caracteristica");

        cCaracteristica.setModel(new javax.swing.DefaultComboBoxModel(new String[] {}));
        cCaracteristica.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cCaracteristicaActionPerformed(evt);
            }
        });

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder("Almacén"));

        jLabel2.setText("Almacén");

        cAlmacen.setModel(new javax.swing.DefaultComboBoxModel(new String[] { }));

        cbInicializar.setText("Inicializar todas las medidas");

        org.jdesktop.layout.GroupLayout jPanel2Layout = new org.jdesktop.layout.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(cbInicializar, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 200, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(jPanel2Layout.createSequentialGroup()
                        .add(jLabel2)
                        .add(18, 18, 18)
                        .add(cAlmacen, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 249, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel2Layout.createSequentialGroup()
                .addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(jLabel2)
                    .add(cAlmacen, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                .add(cbInicializar, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 16, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        List la = BaseDatos.getListaAlmacenes();
        Almacen am;
        for (Iterator it = la.iterator(); it.hasNext();) {
            am = (Almacen) it.next();
            cAlmacen.addItem(am.getNombre());
        }

        pPrecio.setBorder(javax.swing.BorderFactory.createTitledBorder("Precio"));

        jLabel1.setText("Precio");

        tPrecio.setText("0");
        tPrecio.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tPrecioKeyReleased(evt);
            }
        });

        tImporte.setText("0");

        lImporte.setText("Importe");

        lValoracion.setText("Valoración del precio");

        cValoracionPrecio.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Manual", "P.M.C.", "Último Precio Coste" }));

        org.jdesktop.layout.GroupLayout pPrecioLayout = new org.jdesktop.layout.GroupLayout(pPrecio);
        pPrecio.setLayout(pPrecioLayout);
        pPrecioLayout.setHorizontalGroup(
            pPrecioLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(pPrecioLayout.createSequentialGroup()
                .add(pPrecioLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(tPrecio, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 109, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(jLabel1))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(pPrecioLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(pPrecioLayout.createSequentialGroup()
                        .add(lImporte)
                        .add(87, 87, 87)
                        .add(lValoracion))
                    .add(pPrecioLayout.createSequentialGroup()
                        .add(tImporte, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 109, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(18, 18, 18)
                        .add(cValoracionPrecio, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 230, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        pPrecioLayout.setVerticalGroup(
            pPrecioLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(pPrecioLayout.createSequentialGroup()
                .addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .add(pPrecioLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(jLabel1)
                    .add(lImporte)
                    .add(lValoracion))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(pPrecioLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(tPrecio, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(tImporte, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(cValoracionPrecio, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
        );

        tImporte.setEnabled(false);

        bModificar.setText("Modificar");
        bModificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bModificarActionPerformed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout layout = new org.jdesktop.layout.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(layout.createSequentialGroup()
                .addContainerGap()
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                        .add(layout.createSequentialGroup()
                            .add(lnumero)
                            .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                            .add(tnumero, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 100, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                            .add(lfecha)
                            .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                            .add(tFecha, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 71, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(19, 19, 19)
                            .add(lMovimiento)
                            .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                            .add(cTipoMovimiento, 0, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .add(layout.createSequentialGroup()
                            .add(lArticuloCaracteristica)
                            .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                            .add(tArtCar, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 227, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                            .add(cCaracteristica, 0, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .add(layout.createSequentialGroup()
                            .add(lConcepto)
                            .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                            .add(tConcepto))
                        .add(pCantidadesMedidas, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 536, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                    .add(jPanel2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(pPrecio, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .add(org.jdesktop.layout.GroupLayout.TRAILING, layout.createSequentialGroup()
                .addContainerGap(281, Short.MAX_VALUE)
                .add(bAceptar)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(bModificar, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 103, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                .add(bCancelar)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(lnumero)
                    .add(tnumero, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(lfecha)
                    .add(tFecha, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(lMovimiento)
                    .add(cTipoMovimiento, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(lArticuloCaracteristica)
                    .add(cCaracteristica, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(tArtCar, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(lConcepto)
                    .add(tConcepto, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(pCantidadesMedidas, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 81, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(pPrecio, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(bCancelar)
                    .add(bAceptar)
                    .add(bModificar))
                .addContainerGap())
        );

        Date fecha = new Date(); // fecha y hora locales
        SimpleDateFormat formatoFecha = new SimpleDateFormat("dd/MM/yyyy");
        tFecha.setText(formatoFecha.format(fecha));
        List ltm = BaseDatos.getListaTipoMovimientoAlmacen();
        TipoMovimientoAlmacen tm;
        for (Iterator it = ltm.iterator(); it.hasNext();) {
            tm = (TipoMovimientoAlmacen) it.next();
            cTipoMovimiento.addItem(tm.getNombre());
        }
        //List lc = BaseDatos.getListaCaracteristicas(e, ar);
        Caracteristica c;
        for (Iterator it = listaCaracteristicas.iterator(); it.hasNext();) {
            c = (Caracteristica) it.next();
            cCaracteristica.addItem(c.getIid_color().getDescripcion());
        }

        if(listaCaracteristicas.size() < 1){
            cCaracteristica.addItem("-- Vacío --");
        }
        tArtCar.setEditable(false);

        pack();
    }// </editor-fold>//GEN-END:initComponents

private void bCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bCancelarActionPerformed
    cerrarMovimiento();
}//GEN-LAST:event_bCancelarActionPerformed

private void bAceptarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bAceptarActionPerformed
    boolean ok;
    SimpleDateFormat formatoFecha = new SimpleDateFormat("dd/MM/yyyy");
    Date fecha = null;
        try {
            fecha = formatoFecha.parse(tFecha.getText());
        } catch (ParseException ex) {
            Logger.getLogger(NuevoMovimientoAlmacen.class.getName()).log(Level.SEVERE, null, ex);
        }
    
    mva.setAlmacen(BaseDatos.obtenerAlmacen((String) cAlmacen.getSelectedItem()));
    mva.setArticulo(ar);
    almacenarCantidades(mva);
    if (car!=null){
        mva.setCaracteristica(car);
    }
    mva.setConcepto(tConcepto.getText());
    mva.setEmpresa(e);
    mva.setFecha(fecha.getTime());
    mva.setIniciarMedidas(cbInicializar.isSelected());
    mva.setTipoMovimiento(BaseDatos.obtenerTipoMovimientoAlmacen((String) cTipoMovimiento.getSelectedItem()));
    mva.setValoracionPrecio((String) cValoracionPrecio.getSelectedItem());
    
    String precioS = "0";
    if(tPrecio != null && !tPrecio.getText().equalsIgnoreCase("")){
        precioS = tPrecio.getText();
    }
    precioS = Util.convertirComaAPunto(precioS);
    
    String cantidadS = "0";
    if(tCantidad != null && !tCantidad.getText().equalsIgnoreCase("")){
        String claseM = (String)cTipoMovimiento.getSelectedItem();
        TipoMovimientoAlmacen tp = BaseDatos.obtenerTipoMovimientoAlmacen(claseM);
        //Si es una salida establecemos cantidad negativa
        if(tp.getClaseInventario().getIid()!=4){
            cantidadS = tCantidad.getText();
        }else{
             cantidadS = "-"+ tCantidad.getText();
        }
    }
    cantidadS = Util.convertirComaAPunto(cantidadS);
            
    mva.setPrecio(Float.parseFloat(precioS));
    mva.setCantidad(Float.parseFloat(cantidadS));
    
    mva.setModificable(true);

    boolean todoRelleno = true;
    if (mva.getAlmacen() == null) {
        todoRelleno = false;
    }
    if (mva.getTipoMovimiento() == null) {
        todoRelleno = false;
    }
    if (mva.getArticulo() == null) {
        todoRelleno = false;
    }
    if (mva.getCantidad() == null || mva.getCantidad() == 0F) {
        todoRelleno = false;
    }
    if (mva.getConcepto() == null || mva.getConcepto().equals("")) {
        todoRelleno = false;
    }

    if (todoRelleno) {
        if (crear) {
            //Estamos en la creación
            nar.insertarMovimientoExistencia(mva);
            cerrarMovimiento();
        } else {
            //Estamos en una modificación
            ok = BaseDatos.modificarMovimientoExistencia(mva, mvaAntiguo);
            if (ok) {
                //Movimiento actualizado correctamente
                JOptionPane.showMessageDialog(null, "Movimiento Modificado Correctamente", "OK", JOptionPane.INFORMATION_MESSAGE);
                lm.actualizarMovimientos();
                cerrarMovimiento();
            } else {
                //Error al actualizar el movimiento
                JOptionPane.showMessageDialog(null, "Error al modificar el movimiento", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    } else {
        JOptionPane.showMessageDialog(null, "Debe rellenar los campos: \"Tipo de Movimiento\", \"Artículo\",\"Concepto\",\"Cantidad\" y \"Almacén\"", "Error", JOptionPane.ERROR_MESSAGE);
    }

}//GEN-LAST:event_bAceptarActionPerformed

private void cCaracteristicaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cCaracteristicaActionPerformed
    String sCar = (String) this.cCaracteristica.getSelectedItem();
    String sArtCar = ar.getCod_articulo();
    if (!sCar.equals("-- Vacío --")) {
        sArtCar += "/" + sCar;
        Colores color = BaseDatos.obtenerColorPorDescripcion(sCar);
        car = BaseDatos.obtenerCaracteristica(ar, e, color);
    }
    tArtCar.setText(sArtCar);
}//GEN-LAST:event_cCaracteristicaActionPerformed

private void tMedida1KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tMedida1KeyReleased
    int tamaño = tMedida1.getText().length();
    if (tamaño > 0) {
        char c = tMedida1.getText().charAt(tamaño - 1);
        
        if(c == '.'){
            String contenidoAntiguo = tMedida1.getText().replace(".", ",");
            tMedida1.setText(contenidoAntiguo);
            c = ',';
        }
        
        if (!((c >= '0' && c <= '9') || c == ',')) {
            String str = tMedida1.getText().substring(0, tamaño - 1);
            tMedida1.setText(str);
        } else if (c == ',') {
            int indicePunto = tMedida1.getText().indexOf(',');
            if (indicePunto != (tamaño - 1)) {
                String str = tMedida1.getText().substring(0, tamaño - 1);
                tMedida1.setText(str);
            }
        }
        calcularImporte();
    }
}//GEN-LAST:event_tMedida1KeyReleased

private void tMedida2KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tMedida2KeyReleased
    int tamaño = tMedida2.getText().length();
    if (tamaño > 0) {
        char c = tMedida2.getText().charAt(tamaño - 1);
        
        if(c == '.'){
            String contenidoAntiguo = tMedida2.getText().replace(".", ",");
            tMedida2.setText(contenidoAntiguo);
            c = ',';
        }
        
        if (!((c >= '0' && c <= '9') || c == ',')) {
            String str = tMedida2.getText().substring(0, tamaño - 1);
            tMedida2.setText(str);
        } else if (c == ',') {
            int indicePunto = tMedida2.getText().indexOf(',');
            if (indicePunto != (tamaño - 1)) {
                String str = tMedida2.getText().substring(0, tamaño - 1);
                tMedida2.setText(str);
            }
        }
        calcularImporte();
    }
}//GEN-LAST:event_tMedida2KeyReleased

private void tMedida3KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tMedida3KeyReleased
    int tamaño = tMedida3.getText().length();
    if (tamaño > 0) {
        char c = tMedida3.getText().charAt(tamaño - 1);
        
        if(c == '.'){
            String contenidoAntiguo = tMedida3.getText().replace(".", ",");
            tMedida3.setText(contenidoAntiguo);
            c = ',';
        }
        
        if (!((c >= '0' && c <= '9') || c == ',')) {
            String str = tMedida3.getText().substring(0, tamaño - 1);
            tMedida3.setText(str);
        } else if (c == ',') {
            int indicePunto = tMedida3.getText().indexOf(',');
            if (indicePunto != (tamaño - 1)) {
                String str = tMedida3.getText().substring(0, tamaño - 1);
                tMedida3.setText(str);
            }
        }
        calcularImporte();
    }
}//GEN-LAST:event_tMedida3KeyReleased

private void tMedida4KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tMedida4KeyReleased
    int tamaño = tMedida4.getText().length();
    if (tamaño > 0) {
        char c = tMedida4.getText().charAt(tamaño - 1);
        
        if(c == '.'){
            String contenidoAntiguo = tMedida4.getText().replace(".", ",");
            tMedida4.setText(contenidoAntiguo);
            c = ',';
        }
        
        if (!((c >= '0' && c <= '9') || c == ',')) {
            String str = tMedida4.getText().substring(0, tamaño - 1);
            tMedida4.setText(str);
        } else if (c == ',') {
            int indicePunto = tMedida4.getText().indexOf(',');
            if (indicePunto != (tamaño - 1)) {
                String str = tMedida4.getText().substring(0, tamaño - 1);
                tMedida4.setText(str);
            }
        }
        calcularImporte();
    }
}//GEN-LAST:event_tMedida4KeyReleased

private void tMedida5KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tMedida5KeyReleased
    int tamaño = tMedida5.getText().length();
    if (tamaño > 0) {
        char c = tMedida5.getText().charAt(tamaño - 1);
        
        if(c == '.'){
            String contenidoAntiguo = tMedida5.getText().replace(".", ",");
            tMedida5.setText(contenidoAntiguo);
            c = ',';
        }
        
        if (!((c >= '0' && c <= '9') || c == ',')) {
            String str = tMedida5.getText().substring(0, tamaño - 1);
            tMedida5.setText(str);
        } else if (c == ',') {
            int indicePunto = tMedida5.getText().indexOf(',');
            if (indicePunto != (tamaño - 1)) {
                String str = tMedida5.getText().substring(0, tamaño - 1);
                tMedida5.setText(str);
            }
        }
        calcularImporte();
    }
}//GEN-LAST:event_tMedida5KeyReleased

private void tPrecioKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tPrecioKeyReleased
    int tamaño = tPrecio.getText().length();
    if (tamaño > 0) {
        char c = tPrecio.getText().charAt(tamaño - 1);
        
        if(c == '.'){
            String contenidoAntiguo = tPrecio.getText().replace(".", ",");
            tPrecio.setText(contenidoAntiguo);
            c = ',';
        }
        
        if (!((c >= '0' && c <= '9') || c == ',')) {
            String str = tPrecio.getText().substring(0, tamaño - 1);
            tPrecio.setText(str);
        } else if (c == ',') {
            int indicePunto = tPrecio.getText().indexOf(',');
            if (indicePunto != (tamaño - 1)) {
                String str = tPrecio.getText().substring(0, tamaño - 1);
                tPrecio.setText(str);
            }
        }
        calcularImporte();
    }
}//GEN-LAST:event_tPrecioKeyReleased

private void tCantidadKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tCantidadKeyReleased
    int tamaño = tCantidad.getText().length();
    if (tamaño > 0) {
        char c = tCantidad.getText().charAt(tamaño - 1);
        
        if(c == '.'){
            String contenidoAntiguo = tCantidad.getText().replace(".", ",");
            tCantidad.setText(contenidoAntiguo);
            c = ',';
        }
        
        if (!((c >= '0' && c <= '9') || c == ',')) {
            String str = tCantidad.getText().substring(0, tamaño - 1);
            tCantidad.setText(str);
        } else if (c == ',') {
            int indicePunto = tCantidad.getText().indexOf(',');
            if (indicePunto != (tamaño - 1)) {
                String str = tCantidad.getText().substring(0, tamaño - 1);
                tCantidad.setText(str);
            }
        }
        calcularImporte();
    }
}//GEN-LAST:event_tCantidadKeyReleased

private void bModificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bModificarActionPerformed
    if (bModificar.getText().equals("Modificar")) {
        //Si el botón tiene el texto Modificar
        cTipoMovimiento.setEnabled(true);
        cCaracteristica.setEnabled(true);
        cValoracionPrecio.setEnabled(true);
        tConcepto.setEnabled(true);
        tCantidad.setEnabled(true);
        tMedida1.setEnabled(true);
        tMedida2.setEnabled(true);
        tMedida3.setEnabled(true);
        tMedida4.setEnabled(true);
        tMedida5.setEnabled(true);
        cAlmacen.setEnabled(true);
        cbInicializar.setEnabled(true);
        tPrecio.setEnabled(true);
        bModificar.setText("Visualizar");
        bModificar.setToolTipText("Visualizar campos");
    } else {
        //si el botón tiene el texto Visualizar
        cTipoMovimiento.setEnabled(false);
        cCaracteristica.setEnabled(false);
        cValoracionPrecio.setEnabled(false);
        tConcepto.setEnabled(false);
        tCantidad.setEnabled(false);
        tMedida1.setEnabled(false);
        tMedida2.setEnabled(false);
        tMedida3.setEnabled(false);
        tMedida4.setEnabled(false);
        tMedida5.setEnabled(false);
        cAlmacen.setEnabled(false);
        cbInicializar.setEnabled(false);
        tPrecio.setEnabled(false);
        bModificar.setText("Modificar");
        bModificar.setToolTipText("Modificar campos");
    }
}//GEN-LAST:event_bModificarActionPerformed

private void tConceptoKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tConceptoKeyReleased
    String concepto = tConcepto.getText();
    if(concepto.length() > Constantes.TAM_CONCEPTO_MOVIMIENTO_ALMACEN){
        JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_CONCEPTO_MOVIMIENTO_ALMACEN, "Error", JOptionPane.ERROR_MESSAGE);
        tConcepto.setText(concepto.substring(0, Constantes.TAM_CONCEPTO_MOVIMIENTO_ALMACEN));
    }
}//GEN-LAST:event_tConceptoKeyReleased

    private void calcularImporte() {
        try {
            ScriptEngineManager manager = new ScriptEngineManager();
            ScriptEngine engine = manager.getEngineByName("js");
            Float medidaTotal = 0.0F;

            engine.put("Dim1", Util.convertirComaAPunto(tMedida1.getText()));
            engine.put("Dim2", Util.convertirComaAPunto(tMedida2.getText()));
            engine.put("Dim3", Util.convertirComaAPunto(tMedida3.getText()));
            engine.put("Dim4", Util.convertirComaAPunto(tMedida4.getText()));
            engine.put("Dim5", Util.convertirComaAPunto(tMedida5.getText()));

            TipoMedida tm = ar.getIid_fam_venta().getIid_tipo_control().getIid_tipo_medida();
            TipoControl tc = BaseDatos.obtenerTipoControlPorIid(ar.getIid_fam_venta().getIid_tipo_control().getIid()); 
            UnidadMedida umM = BaseDatos.obtenerUnidadMedidaIid(ar.getIid_unidad_medida().getIid());
            
            String tipoCalculo = tm.getTipo_calculo();

            if (tipoCalculo.equals("Fórmula")) {
                Double medidaTotalDouble = (Double) engine.eval(tm.getFormula());
                medidaTotal = Float.parseFloat(String.valueOf(medidaTotalDouble)) * Float.valueOf(Util.convertirComaAPunto(tCantidad.getText()));
            } else {
                
                
            if (tm.getCodigo().equals("U") || tm.getCodigo().equals("u")) {
                   /*medidaTotal = tCantidad.getText();
                   totalCar = existen.getExistencia();
                   totalArt = totalArt + totalCar;*/
               } else if (tm.getCodigo().equals("L") || tm.getCodigo().equals("l")) {
                   UnidadMedida umM1 = BaseDatos.obtenerUnidadMedidaIid(tc.getUnidad1().getIid());
                   medidaTotal = (Float.valueOf(Util.convertirComaAPunto(tMedida1.getText())) * (umM1.getEquivalencia_unidad_base() / umM.getEquivalencia_unidad_base())) * Float.valueOf(Util.convertirComaAPunto(tCantidad.getText()));
                   
               } else if (tm.getCodigo().equals("S") || tm.getCodigo().equals("s")) {
                   UnidadMedida umM1 = BaseDatos.obtenerUnidadMedidaIid(tc.getUnidad1().getIid());
                   UnidadMedida umM2 = BaseDatos.obtenerUnidadMedidaIid(tc.getUnidad2().getIid());
                   
                   medidaTotal = (((Float.valueOf(Util.convertirComaAPunto(tMedida1.getText())) * (umM.getEquivalencia_unidad_base() / umM1.getEquivalencia_unidad_base())) * 
                                 ( Float.valueOf(Util.convertirComaAPunto(tMedida2.getText())) * (umM.getEquivalencia_unidad_base() / umM2.getEquivalencia_unidad_base()))) ) * Float.valueOf(Util.convertirComaAPunto(tCantidad.getText()));
                   
               }
                
            }
            
            tMedidaTotal.setText(Util.convertirPuntoAComa(String.valueOf(matematico.Matematico.redondear2decimales(medidaTotal))));
            Float importe = (Float) medidaTotal * Float.valueOf(Util.convertirComaAPunto(tPrecio.getText()));
            tImporte.setText(Util.convertirPuntoAComa(String.valueOf(matematico.Matematico.redondear2decimales(importe))));
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Error al calcular el importe", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bAceptar;
    private javax.swing.JButton bCancelar;
    private javax.swing.JButton bModificar;
    private javax.swing.JComboBox cAlmacen;
    private javax.swing.JComboBox cCaracteristica;
    private javax.swing.JComboBox cTipoMovimiento;
    private javax.swing.JComboBox cValoracionPrecio;
    private javax.swing.JCheckBox cbInicializar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JLabel lArticuloCaracteristica;
    private javax.swing.JLabel lCantidad;
    private javax.swing.JLabel lConcepto;
    private javax.swing.JLabel lImporte;
    private javax.swing.JLabel lMed;
    private javax.swing.JLabel lMed1;
    private javax.swing.JLabel lMed2;
    private javax.swing.JLabel lMed3;
    private javax.swing.JLabel lMed4;
    private javax.swing.JLabel lMed5;
    private javax.swing.JLabel lMedida1;
    private javax.swing.JLabel lMedida2;
    private javax.swing.JLabel lMedida3;
    private javax.swing.JLabel lMedida4;
    private javax.swing.JLabel lMedida5;
    private javax.swing.JLabel lMedidaTotal;
    private javax.swing.JLabel lMovimiento;
    private javax.swing.JLabel lValoracion;
    private javax.swing.JLabel lfecha;
    private javax.swing.JLabel lnumero;
    private javax.swing.JPanel pCantidadesMedidas;
    private javax.swing.JPanel pPrecio;
    private javax.swing.JTextField tArtCar;
    private javax.swing.JTextField tCantidad;
    private javax.swing.JTextField tConcepto;
    private javax.swing.JTextField tFecha;
    private javax.swing.JTextField tImporte;
    private javax.swing.JTextField tMedida1;
    private javax.swing.JTextField tMedida2;
    private javax.swing.JTextField tMedida3;
    private javax.swing.JTextField tMedida4;
    private javax.swing.JTextField tMedida5;
    private javax.swing.JTextField tMedidaTotal;
    private javax.swing.JTextField tPrecio;
    private javax.swing.JTextField tnumero;
    // End of variables declaration//GEN-END:variables

    private void mostrarCantidades(int numMedidas) {
        tMedida1.setVisible(false);
        tMedida2.setVisible(false);
        tMedida3.setVisible(false);
        tMedida4.setVisible(false);
        tMedida5.setVisible(false);

        lMedida1.setVisible(false);
        lMedida2.setVisible(false);
        lMedida3.setVisible(false);
        lMedida4.setVisible(false);
        lMedida5.setVisible(false);

        lMed1.setVisible(false);
        lMed2.setVisible(false);
        lMed3.setVisible(false);
        lMed4.setVisible(false);
        lMed5.setVisible(false);

        tMedida1.setText("1");
        tMedida2.setText("1");
        tMedida3.setText("1");
        tMedida4.setText("1");
        tMedida5.setText("1");
        
        FamiliaVenta fv = BaseDatos.obtenerFamiliaVentaPorIid(ar.getIid_fam_venta().getIid());
        TipoControl tc = BaseDatos.obtenerTipoControlPorIid(fv.getIid_tipo_control().getIid());
        UnidadMedida um = BaseDatos.obtenerUnidadMedidaIid(tc.getUnidadResultado().getIid());

        lMed.setText(um.getAbreviacion());

        if (numMedidas == 1) {
            lMedida1.setText(ar.getIid_fam_venta().getIid_tipo_control().getUnidad1().getNombre());
            lMed1.setText(ar.getIid_fam_venta().getIid_tipo_control().getUnidad1().getCod_unidad_medida());
            tMedida1.setVisible(true);
            lMedida1.setVisible(true);
            lMed1.setVisible(true);
            tMedida1.setText("0");
        } else if (numMedidas == 2) {
            lMedida1.setText(ar.getIid_fam_venta().getIid_tipo_control().getUnidad1().getNombre());
            lMed1.setText(ar.getIid_fam_venta().getIid_tipo_control().getUnidad1().getCod_unidad_medida());
            tMedida1.setVisible(true);
            lMedida1.setVisible(true);
            lMed1.setVisible(true);
            tMedida1.setText("0");

            lMedida2.setText(ar.getIid_fam_venta().getIid_tipo_control().getUnidad1().getNombre());
            lMed2.setText(ar.getIid_fam_venta().getIid_tipo_control().getUnidad2().getNombre());
            tMedida2.setVisible(true);
            lMedida2.setVisible(true);
            lMed2.setVisible(true);
            tMedida2.setText("0");
        } else if (numMedidas == 3) {
            lMedida1.setText(ar.getIid_fam_venta().getIid_tipo_control().getUnidad1().getNombre());
            lMed1.setText(ar.getIid_fam_venta().getIid_tipo_control().getUnidad1().getCod_unidad_medida());
            tMedida1.setVisible(true);
            lMedida1.setVisible(true);
            lMed1.setVisible(true);
            tMedida1.setText("0");

            lMedida2.setText(ar.getIid_fam_venta().getIid_tipo_control().getUnidad2().getNombre());
            lMed2.setText(ar.getIid_fam_venta().getIid_tipo_control().getUnidad2().getCod_unidad_medida());
            tMedida2.setVisible(true);
            lMedida2.setVisible(true);
            lMed2.setVisible(true);
            tMedida2.setText("0");

            lMedida3.setText(ar.getIid_fam_venta().getIid_tipo_control().getUnidad3().getNombre());
            lMed3.setText(ar.getIid_fam_venta().getIid_tipo_control().getUnidad3().getCod_unidad_medida());
            tMedida3.setVisible(true);
            lMedida3.setVisible(true);
            lMed3.setVisible(true);
            tMedida3.setText("0");

        } else if (numMedidas == 4) {
            lMedida1.setText(ar.getIid_fam_venta().getIid_tipo_control().getUnidad1().getNombre());
            lMed1.setText(ar.getIid_fam_venta().getIid_tipo_control().getUnidad1().getCod_unidad_medida());
            tMedida1.setVisible(true);
            lMedida1.setVisible(true);
            lMed1.setVisible(true);
            tMedida1.setText("0");

            lMedida2.setText(ar.getIid_fam_venta().getIid_tipo_control().getUnidad2().getNombre());
            lMed2.setText(ar.getIid_fam_venta().getIid_tipo_control().getUnidad2().getCod_unidad_medida());
            tMedida2.setVisible(true);
            lMedida2.setVisible(true);
            lMed2.setVisible(true);
            tMedida2.setText("0");

            lMedida3.setText(ar.getIid_fam_venta().getIid_tipo_control().getUnidad3().getNombre());
            lMed3.setText(ar.getIid_fam_venta().getIid_tipo_control().getUnidad3().getCod_unidad_medida());
            tMedida3.setVisible(true);
            lMedida3.setVisible(true);
            lMed3.setVisible(true);
            tMedida3.setText("0");

            lMedida4.setText(ar.getIid_fam_venta().getIid_tipo_control().getUnidad4().getNombre());
            lMed4.setText(ar.getIid_fam_venta().getIid_tipo_control().getUnidad4().getCod_unidad_medida());
            tMedida4.setVisible(true);
            lMedida4.setVisible(true);
            lMed4.setVisible(true);
            tMedida4.setText("0");
        } else if (numMedidas == 5) {
            lMedida1.setText(ar.getIid_fam_venta().getIid_tipo_control().getUnidad1().getNombre());
            lMed1.setText(ar.getIid_fam_venta().getIid_tipo_control().getUnidad1().getCod_unidad_medida());
            tMedida1.setVisible(true);
            lMedida1.setVisible(true);
            lMed1.setVisible(true);
            tMedida1.setText("0");

            lMedida2.setText(ar.getIid_fam_venta().getIid_tipo_control().getUnidad2().getNombre());
            lMed2.setText(ar.getIid_fam_venta().getIid_tipo_control().getUnidad2().getCod_unidad_medida());
            tMedida2.setVisible(true);
            lMedida2.setVisible(true);
            lMed2.setVisible(true);
            tMedida2.setText("0");

            lMedida3.setText(ar.getIid_fam_venta().getIid_tipo_control().getUnidad3().getNombre());
            lMed3.setText(ar.getIid_fam_venta().getIid_tipo_control().getUnidad3().getCod_unidad_medida());
            tMedida3.setVisible(true);
            lMedida3.setVisible(true);
            lMed3.setVisible(true);
            tMedida3.setText("0");

            lMedida4.setText(ar.getIid_fam_venta().getIid_tipo_control().getUnidad4().getNombre());
            lMed4.setText(ar.getIid_fam_venta().getIid_tipo_control().getUnidad4().getCod_unidad_medida());
            tMedida4.setVisible(true);
            lMedida4.setVisible(true);
            lMed4.setVisible(true);
            tMedida4.setText("0");

            lMedida5.setText(ar.getIid_fam_venta().getIid_tipo_control().getUnidad5().getNombre());
            lMed5.setText(ar.getIid_fam_venta().getIid_tipo_control().getUnidad5().getCod_unidad_medida());
            tMedida5.setVisible(true);
            lMedida5.setVisible(true);
            lMed5.setVisible(true);
            tMedida5.setText("0");
        }
        
        
    }

    private void almacenarCantidades(MovimientoAlmacen mva) {
        //Familia de venta para conocer las medidas y unidades
        FamiliaVenta fv = BaseDatos.obtenerFamiliaVentaPorIid(ar.getIid_fam_venta().getIid());
        TipoControl  tc = fv.getIid_tipo_control();
        mva.setCantidad1(0F);
        mva.setCantidad2(0F);
        mva.setCantidad3(0F);
        mva.setCantidad4(0F);
        mva.setCantidad5(0F);
        
        if (numMedidas == 1) {
            mva.setCantidad1(Float.parseFloat(Util.convertirComaAPunto(tMedida1.getText())));
            //Unidad de medida 1
            mva.setUnidadMedida1(tc.getUnidad1());
            
        } else if (numMedidas == 2) {
            mva.setCantidad1(Float.parseFloat(Util.convertirComaAPunto(tMedida1.getText())));
            //Unidad de medida 1
            mva.setUnidadMedida1(tc.getUnidad1());
            mva.setCantidad2(Float.parseFloat(Util.convertirComaAPunto(tMedida2.getText())));
            //Unidad de medida 2
            mva.setUnidadMedida2(tc.getUnidad2().getIid());
        } else if (numMedidas == 3) {
            mva.setCantidad1(Float.parseFloat(Util.convertirComaAPunto(tMedida1.getText())));
            //Unidad de medida 1
            mva.setUnidadMedida1(tc.getUnidad1());
            mva.setCantidad2(Float.parseFloat(Util.convertirComaAPunto(tMedida2.getText())));
            //Unidad de medida 2
            mva.setUnidadMedida2(tc.getUnidad2().getIid());
            //Unidad de medida 3
            mva.setUnidadMedida3(tc.getUnidad2().getIid());
            mva.setCantidad3(Float.parseFloat(Util.convertirComaAPunto(tMedida3.getText())));
        } else if (numMedidas == 4) {
            //Unidad de medida 1
            mva.setUnidadMedida1(tc.getUnidad1());
            mva.setCantidad1(Float.parseFloat(Util.convertirComaAPunto(tMedida1.getText())));
            //Unidad de medida 2
            mva.setUnidadMedida2(tc.getUnidad2().getIid());
            mva.setCantidad2(Float.parseFloat(Util.convertirComaAPunto(tMedida2.getText())));
            //Unidad de medida 3
            mva.setUnidadMedida3(tc.getUnidad3().getIid());
            mva.setCantidad3(Float.parseFloat(Util.convertirComaAPunto(tMedida3.getText())));
            //Unidad de medida 4
            mva.setUnidadMedida4(tc.getUnidad4().getIid());            
            mva.setCantidad4(Float.parseFloat(Util.convertirComaAPunto(tMedida4.getText())));
        } else if (numMedidas == 5) {
            //Unidad de medida 1
            mva.setUnidadMedida1(tc.getUnidad1());
            mva.setCantidad1(Float.parseFloat(Util.convertirComaAPunto(tMedida1.getText())));
            //Unidad de medida 2
            mva.setUnidadMedida2(tc.getUnidad2().getIid());
            mva.setCantidad2(Float.parseFloat(Util.convertirComaAPunto(tMedida2.getText())));
            //Unidad de medida 3
            mva.setUnidadMedida3(tc.getUnidad3().getIid());
            mva.setCantidad3(Float.parseFloat(Util.convertirComaAPunto(tMedida3.getText())));
            //Unidad de medida 4
            mva.setUnidadMedida4(tc.getUnidad4().getIid());            
            mva.setCantidad4(Float.parseFloat(Util.convertirComaAPunto(tMedida4.getText())));
           //Unidad de medida 5
            mva.setUnidadMedida5(tc.getUnidad5().getIid());            
            mva.setCantidad5(Float.parseFloat(Util.convertirComaAPunto(tMedida5.getText())));
        }
        //Unidad Medida total, sacado del artículo
        mva.setUnidadMedidaTotal(ar.getIid_unidad_medida());
    }
    
           
}