package gui;

import acceso.BaseDatos;
import auxiliar.CorteLona;
import bean.Articulo;
import bean.Caracteristica;
import bean.Existencia;
import bean.LineaCorteLona;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Shape;
import java.awt.geom.Line2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import javax.imageio.ImageIO;
import modelo.Modelo;
import util.Util;
import util.Constantes;

public class NuevaLineaCorteDeLona extends javax.swing.JPanel {

    NuevoPresupuesto p;
    CorteLona corteLona;
    int numPañosEnteros;
    Float alto;
    Float ancho;
    Float anchoSeleccionado;
    Float restoIzquierdo;
    NuevoCorteLona ncl;
    NuevoCorteLonaSimulado ncls;
    boolean hayRestos;
    List<Existencia> listaRestosUsados;
    List<Integer> listaRestosIniciales;
    boolean crear;
    boolean inicializar;
    Integer iid;
    boolean automaticoAntiguo;
    String tCorteLonaAntiguo;
    String dobladilloAntiguo;
    String solapeAntiguo;
    String anchoAntiguo;
    boolean hayCambios;

    public NuevaLineaCorteDeLona(NuevoCorteLona ncl, NuevoPresupuesto p, CorteLona corteLona) {
        this.ncl = ncl;
        this.p = p;
        this.corteLona = corteLona;
        this.crear = false;
        this.listaRestosIniciales = new ArrayList<Integer>();
        this.inicializar = false;
        this.iid = null;
        initComponents();

        tCantidad.setEnabled(false);
        tLinea.setEnabled(false);
        tSalida.setEnabled(false);
        tCodigoLinea.setEnabled(false);
        tCodigo.setEnabled(false);

        iniciarAncho();

        tCantidad.setText(corteLona.getCantidad());
        tLinea.setText(corteLona.getMedida2());
        tSalida.setText(corteLona.getMedida1());
        tCodigo.setText(corteLona.getCodigoArticuloCaracterisitica());
        tCodigoLinea.setText(corteLona.getCodigoLinea());
        pIzquierdo.setVisible(false);
        hayCambios = false;

    }

    public NuevaLineaCorteDeLona(NuevoCorteLonaSimulado ncls, NuevoPresupuesto p, CorteLona corteLona) {
        this.ncls = ncls;
        this.p = p;
        this.corteLona = corteLona;
        this.crear = false;
        this.listaRestosIniciales = new ArrayList<Integer>();
        this.inicializar = false;
        this.iid = null;
        initComponents();

        tCantidad.setEnabled(false);
        tLinea.setEnabled(false);
        tSalida.setEnabled(false);
        tCodigoLinea.setEnabled(false);
        tCodigo.setEnabled(false);

        iniciarAncho();

        tCantidad.setText(corteLona.getCantidad());
        tLinea.setText(corteLona.getMedida2());
        tSalida.setText(corteLona.getMedida1());
        tCodigo.setText(corteLona.getCodigoArticuloCaracterisitica());
        tCodigoLinea.setText(corteLona.getCodigoLinea());
        pIzquierdo.setVisible(false);
        hayCambios = false;

    }

    public NuevaLineaCorteDeLona(NuevoCorteLona ncl, NuevoPresupuesto nuevoPresupuesto, CorteLona cl, LineaCorteLona lcl) {
        this.ncl = ncl;
        this.p = nuevoPresupuesto;
        this.corteLona = cl;
        this.crear = false;
        this.listaRestosIniciales = new ArrayList<Integer>();
        this.inicializar = true;
        this.iid = lcl.getIid();
        initComponents();

        tCantidad.setEnabled(false);
        tLinea.setEnabled(false);
        tSalida.setEnabled(false);
        tCodigoLinea.setEnabled(false);
        tCodigo.setEnabled(false);

        iniciarAncho();
        
        cAncho.setSelectedItem(Util.convertirPuntoAComa(new Float(lcl.getAnchoSeleccionado().toString()).toString()));
        anchoAntiguo = Util.convertirPuntoAComa(new Float(lcl.getAnchoSeleccionado().toString()).toString());
        
        cbAutomatico.setSelected(lcl.getAutomatico());
        automaticoAntiguo = lcl.getAutomatico();
        
        tCodigoLinea.setText(cl.getCodigoLinea().toString());
        tCantidad.setText(Util.convertirPuntoAComa(lcl.getCantidad().toString()));
                
        tSolape.setText(Util.convertirPuntoAComa(lcl.getSolape().toString()));
        solapeAntiguo = Util.convertirPuntoAComa(lcl.getSolape().toString());
        
        tDobladillo.setText(Util.convertirPuntoAComa(lcl.getDobladillo().toString()));
        dobladilloAntiguo = Util.convertirPuntoAComa(lcl.getDobladillo().toString());
        
        
        tLinea.setText(Util.convertirPuntoAComa(lcl.getLinea().toString()));
        tSalida.setText(Util.convertirPuntoAComa(lcl.getSalida().toString()));
        
        cCorteLona.setSelectedItem(lcl.getTipoCorteLona());
        tCorteLonaAntiguo = lcl.getTipoCorteLona();
        
        tCodigo.setText(corteLona.getCodigoArticuloCaracterisitica());
        pIzquierdo.setVisible(false);
        
        if(cbAutomatico.isSelected()){
            rellenarPanelIzquierdo();
            pIzquierdo.setVisible(true);
        } else {
            pIzquierdo.setVisible(false);
        }
        repaint();
        ncl.actualizarLineas();
        this.inicializar = false;
        hayCambios = false;
    }
    
    public NuevaLineaCorteDeLona(NuevoCorteLonaSimulado ncls, NuevoPresupuesto nuevoPresupuesto, CorteLona cl, LineaCorteLona lcl) {
        this.ncls = ncls;
        this.p = nuevoPresupuesto;
        this.corteLona = cl;
        this.crear = false;
        this.listaRestosIniciales = new ArrayList<Integer>();
        this.inicializar = true;
        this.iid = lcl.getIid();
        initComponents();

        tCantidad.setEnabled(false);
        tLinea.setEnabled(false);
        tSalida.setEnabled(false);
        tCodigoLinea.setEnabled(false);
        tCodigo.setEnabled(false);

        iniciarAncho();
        
        cAncho.setSelectedItem(Util.convertirPuntoAComa(new Float(lcl.getAnchoSeleccionado().toString()).toString()));
        anchoAntiguo = Util.convertirPuntoAComa(new Float(lcl.getAnchoSeleccionado().toString()).toString());
        
        cbAutomatico.setSelected(lcl.getAutomatico());
        automaticoAntiguo = lcl.getAutomatico();
        
        tCodigoLinea.setText(cl.getCodigoLinea().toString());
        tCantidad.setText(Util.convertirPuntoAComa(lcl.getCantidad().toString()));
                
        tSolape.setText(Util.convertirPuntoAComa(lcl.getSolape().toString()));
        solapeAntiguo = Util.convertirPuntoAComa(lcl.getSolape().toString());
        
        tDobladillo.setText(Util.convertirPuntoAComa(lcl.getDobladillo().toString()));
        dobladilloAntiguo = Util.convertirPuntoAComa(lcl.getDobladillo().toString());
        
        
        tLinea.setText(Util.convertirPuntoAComa(lcl.getLinea().toString()));
        tSalida.setText(Util.convertirPuntoAComa(lcl.getSalida().toString()));
        
        cCorteLona.setSelectedItem(lcl.getTipoCorteLona());
        tCorteLonaAntiguo = lcl.getTipoCorteLona();
        
        tCodigo.setText(corteLona.getCodigoArticuloCaracterisitica());
        pIzquierdo.setVisible(false);
        
        if(cbAutomatico.isSelected()){
            rellenarPanelIzquierdo();
            pIzquierdo.setVisible(true);
        } else {
            pIzquierdo.setVisible(false);
        }
        repaint();
        ncl.actualizarLineas();
        this.inicializar = false;
        hayCambios = false;
    }

    public Integer getCodigoLinea() {
        return new Integer(tCodigoLinea.getText());
    }

    public Float getDobladillo() {
        return new Float(Util.convertirComaAPunto(tDobladillo.getText()));
    }

    public Float getLinea() {
        return new Float(Util.convertirComaAPunto(tLinea.getText()));
    }

    public Float getSalida() {
        return new Float(Util.convertirComaAPunto(tSalida.getText()));
    }

    public Float getSolape() {
        return new Float(Util.convertirComaAPunto(tSolape.getText()));
    }

    boolean finalizable() {
        boolean res = true;
        if(cbAutomatico.isSelected()){
            res =  !((String)cAncho.getSelectedItem()).equals(Constantes.SIN_EXISTENCIAS) &&
                    tIzquierdo.getSelectedRowCount() > 0;
        } else {
            res = !((String)cAncho.getSelectedItem()).equals(Constantes.SIN_EXISTENCIAS);
        }
        
        if(res){
            realizarOperacion();
            hayCambios = hayCambios();
        }
        return res;

    }
    
    public boolean getEsDespiece(){
        return corteLona.getEsDespiece();
    }
    
    public String getTipoCorteLona(){
        return (String)cCorteLona.getSelectedItem();
    }
    
    public List<Existencia> getListaRestosUsados(){
        return this.listaRestosUsados;
    }
    
    public void mostrarRestosIzquierdo(){
        if(this.cbAutomatico.isSelected()){
            rellenarPanelIzquierdo();
            pIzquierdo.setVisible(true);
       } else {
           pIzquierdo.setVisible(false);
       }
    }
    
    public void ocultarRestosIzquierdo(){
        pIzquierdo.setVisible(false);
    }
    
    public CorteLona getCorteLona(){
        return corteLona;
    }

    private void iniciarAncho() {
        cAncho.addItem(Constantes.SIN_EXISTENCIAS);

        List listaExistencias;
        Caracteristica carac = corteLona.getCaracteristica();
        if (carac == null) {
            listaExistencias = BaseDatos.getListaExistencias(corteLona.getArticulo(), p.getAlmacen());
        } else {
            listaExistencias = BaseDatos.getListaExistencias(corteLona.getArticulo(), carac.getIid(), p.getAlmacen());
        }

        if (listaExistencias != null && listaExistencias.size() > 0) {
            Iterator iter = listaExistencias.iterator();
            Existencia ex;
            while (iter.hasNext()) {
                ex = (Existencia) iter.next();
                cAncho.removeItem(Util.convertirPuntoAComa(ex.getCantidad2().toString()));
                cAncho.addItem(Util.convertirPuntoAComa(ex.getCantidad2().toString()));
            }
            cAncho.setSelectedIndex(1);
        }
    }

    public void realizarOperacion() {
        String corteLonaS = (String) cCorteLona.getSelectedItem();
        Float fLinea = new Float(Util.convertirComaAPunto(tLinea.getText()));
        Float lineaAcumulada = 0F;
        Float dobladillo = Float.valueOf(Util.convertirComaAPunto(tDobladillo.getText()));
        Float solape = Float.valueOf(Util.convertirComaAPunto(tSolape.getText()));
        numPañosEnteros = 0;
        hayRestos = false;

        if(cbAutomatico.isSelected()){
            this.listaRestosUsados = new ArrayList<Existencia>();

            int indices[] = tIzquierdo.getSelectedRows();
            int contadorIndiceRestos;
            Float restosSeleccionados = 0F;
            for(contadorIndiceRestos = 0; contadorIndiceRestos < indices.length; contadorIndiceRestos++){
                restosSeleccionados += new Float(Util.convertirComaAPunto((String)tIzquierdo.getValueAt(indices[contadorIndiceRestos], 0)));
                listaRestosUsados.add(BaseDatos.getExistenciaByIid((Integer)tIzquierdo.getValueAt(indices[contadorIndiceRestos], 2)));
            }
        }
        
        if (corteLonaS.equals(Constantes.TIPO_CORTE_ASIMETRICO)) {

            hayRestos = true;
            restoIzquierdo = 0F;
            anchoSeleccionado = new Float(Util.convertirComaAPunto((String) cAncho.getSelectedItem()));
            while (lineaAcumulada < fLinea) {
                lineaAcumulada += anchoSeleccionado;
                numPañosEnteros++;
            }

            if (lineaAcumulada > fLinea) {
                numPañosEnteros--;
                restoIzquierdo = (fLinea - numPañosEnteros * anchoSeleccionado);
                restoIzquierdo += (2 * dobladillo) + (numPañosEnteros * solape);
                hayRestos = true;

                if (anchoSeleccionado.equals(restoIzquierdo)) {
                    numPañosEnteros++;
                    restoIzquierdo = 0F;
                    hayRestos = false;
                }
            } else if (lineaAcumulada.equals(fLinea)) {
                restoIzquierdo = (2 * dobladillo) + (numPañosEnteros * solape);
                hayRestos = true;
            }

        } else if (corteLonaS.equals(Constantes.TIPO_CORTE_RETAL_MAXI)) {
            Float restoRepartir = 0F;
            hayRestos = true;
            restoIzquierdo = 0F;
            anchoSeleccionado = new Float(Util.convertirComaAPunto((String) cAncho.getSelectedItem()));
            while (lineaAcumulada < fLinea) {
                lineaAcumulada += anchoSeleccionado;
                numPañosEnteros++;
            }

            if (lineaAcumulada > fLinea) {
                numPañosEnteros = numPañosEnteros - 2;
                restoRepartir = (fLinea - numPañosEnteros * anchoSeleccionado);
                restoRepartir += (2 * dobladillo) + ((numPañosEnteros + 1) * solape);
                restoIzquierdo = restoRepartir / 2;
                hayRestos = true;

                if (anchoSeleccionado.equals(restoRepartir)) {
                    numPañosEnteros++;
                    restoIzquierdo = 0F;
                    hayRestos = false;

                }
            } else if (lineaAcumulada.equals(fLinea)) {
                numPañosEnteros--;
                restoIzquierdo = (anchoSeleccionado + (2 * dobladillo) + ((numPañosEnteros + 1) * solape)) / 2;
                hayRestos = true;
            }

        } else if (corteLonaS.equals(Constantes.TIPO_CORTE_RETAL_MINI)) {
            Float restoRepartir = 0F;
            hayRestos = true;
            restoIzquierdo = 0F;
            anchoSeleccionado = new Float(Util.convertirComaAPunto((String) cAncho.getSelectedItem()));
            while (lineaAcumulada < fLinea) {
                lineaAcumulada += anchoSeleccionado;
                numPañosEnteros++;
            }

            if (lineaAcumulada > fLinea) {
                numPañosEnteros--;
                restoRepartir = (fLinea - numPañosEnteros * anchoSeleccionado);
                restoRepartir += (2 * dobladillo) + ((numPañosEnteros + 1) * solape);
                restoIzquierdo = restoRepartir / 2;
                hayRestos = true;

                if (anchoSeleccionado.equals(restoRepartir)) {
                    numPañosEnteros++;
                    restoIzquierdo = 0F;
                    hayRestos = false;

                }
            } else if (lineaAcumulada.equals(fLinea)) {
                restoIzquierdo = ((2 * dobladillo) + ((numPañosEnteros + 1) * solape)) / 2;
                hayRestos = true;
            }

        } else if (corteLonaS.equals(Constantes.TIPO_CORTE_DEGRADEE)) {
            hayRestos = false;
            restoIzquierdo = 0F;
            anchoSeleccionado = new Float(Util.convertirComaAPunto((String) cAncho.getSelectedItem()));
            numPañosEnteros = 1;
                    
        } else if(corteLonaS.equals(Constantes.TIPO_CORTE_SCREEN)){
            
        }
    }

    public Float calcularRestoUsado(){
        String corteLonaS = (String) cCorteLona.getSelectedItem();
        Float fLinea = new Float(Util.convertirComaAPunto(tLinea.getText()));
        Float lineaAcumulada = 0F;
        Float dobladillo = Float.valueOf(Util.convertirComaAPunto(tDobladillo.getText()));
        Float solape = Float.valueOf(Util.convertirComaAPunto(tSolape.getText()));
        numPañosEnteros = 0;
        hayRestos = false;

        
        if (corteLonaS.equals(Constantes.TIPO_CORTE_ASIMETRICO)) {

            hayRestos = true;
            restoIzquierdo = 0F;
            anchoSeleccionado = new Float(Util.convertirComaAPunto((String) cAncho.getSelectedItem()));
            while (lineaAcumulada < fLinea) {
                lineaAcumulada += anchoSeleccionado;
                numPañosEnteros++;
            }

            if (lineaAcumulada > fLinea) {
                numPañosEnteros--;
                restoIzquierdo = (fLinea - numPañosEnteros * anchoSeleccionado);
                restoIzquierdo += (2 * dobladillo) + (numPañosEnteros * solape);
                hayRestos = true;

                if (anchoSeleccionado.equals(restoIzquierdo)) {
                    numPañosEnteros++;
                    restoIzquierdo = 0F;
                    hayRestos = false;
                }
            } else if (lineaAcumulada.equals(fLinea)) {
                restoIzquierdo = (2 * dobladillo) + (numPañosEnteros * solape);
                hayRestos = true;
            }
        } else if (corteLonaS.equals(Constantes.TIPO_CORTE_RETAL_MAXI)) {
            Float restoRepartir = 0F;
            hayRestos = true;
            restoIzquierdo = 0F;
            anchoSeleccionado = new Float(Util.convertirComaAPunto((String) cAncho.getSelectedItem()));
            while (lineaAcumulada < fLinea) {
                lineaAcumulada += anchoSeleccionado;
                numPañosEnteros++;
            }
            if (lineaAcumulada > fLinea) {
                numPañosEnteros = numPañosEnteros - 2;
                restoRepartir = (fLinea - numPañosEnteros * anchoSeleccionado);
                restoRepartir += (2 * dobladillo) + ((numPañosEnteros + 1) * solape);
                restoIzquierdo = restoRepartir / 2;
                hayRestos = true;

                if (anchoSeleccionado.equals(restoRepartir)) {
                    numPañosEnteros++;
                    restoIzquierdo = 0F;
                    hayRestos = false;

                }
            } else if (lineaAcumulada.equals(fLinea)) {
                numPañosEnteros--;
                restoIzquierdo = (anchoSeleccionado + (2 * dobladillo) + ((numPañosEnteros + 1) * solape)) / 2;
                hayRestos = true;
            }
        } else if (corteLonaS.equals(Constantes.TIPO_CORTE_RETAL_MINI)) {
            Float restoRepartir = 0F;
            hayRestos = true;
            restoIzquierdo = 0F;
            anchoSeleccionado = new Float(Util.convertirComaAPunto((String) cAncho.getSelectedItem()));
            while (lineaAcumulada < fLinea) {
                lineaAcumulada += anchoSeleccionado;
                numPañosEnteros++;
            }

            if (lineaAcumulada > fLinea) {
                numPañosEnteros--;
                restoRepartir = (fLinea - numPañosEnteros * anchoSeleccionado);
                restoRepartir += (2 * dobladillo) + ((numPañosEnteros + 1) * solape);
                restoIzquierdo = restoRepartir / 2;
                hayRestos = true;

                if (anchoSeleccionado.equals(restoRepartir)) {
                    numPañosEnteros++;
                    restoIzquierdo = 0F;
                    hayRestos = false;

                }
            } else if (lineaAcumulada.equals(fLinea)) {
                restoIzquierdo = ((2 * dobladillo) + ((numPañosEnteros + 1) * solape)) / 2;
                hayRestos = true;
            }

        } else if (corteLonaS.equals(Constantes.TIPO_CORTE_DEGRADEE)) {
        
        }
        return restoIzquierdo;
    }
    
    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        tCodigo = new javax.swing.JTextField();
        tLinea = new javax.swing.JTextField();
        tSalida = new javax.swing.JTextField();
        cCorteLona = new javax.swing.JComboBox();
        tDobladillo = new javax.swing.JTextField();
        tSolape = new javax.swing.JTextField();
        cAncho = new javax.swing.JComboBox();
        tCantidad = new javax.swing.JTextField();
        tCodigoLinea = new javax.swing.JTextField();
        pIzquierdo = new javax.swing.JPanel();
        sCrollIzquierdo = new javax.swing.JScrollPane();
        Modelo modeloIzquierdo = new Modelo();
        tIzquierdo = new javax.swing.JTable(modeloIzquierdo);
        cbAutomatico = new javax.swing.JCheckBox();

        setBackground(new java.awt.Color(204, 204, 204));
        setAutoscrolls(true);

        tLinea.setFont(new java.awt.Font("Tahoma", 1, 11));

        tSalida.setFont(new java.awt.Font("Tahoma", 1, 11));

        cCorteLona.setModel(new javax.swing.DefaultComboBoxModel(new String[] { Constantes.TIPO_CORTE_ASIMETRICO, Constantes.TIPO_CORTE_RETAL_MAXI, Constantes.TIPO_CORTE_RETAL_MINI, Constantes.TIPO_CORTE_DEGRADEE, Constantes.TIPO_CORTE_SCREEN}));
        cCorteLona.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cCorteLonaActionPerformed(evt);
            }
        });

        tDobladillo.setFont(new java.awt.Font("Tahoma", 1, 11));
        tDobladillo.setText("3");
        tDobladillo.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tDobladilloKeyReleased(evt);
            }
        });

        tSolape.setFont(new java.awt.Font("Tahoma", 1, 11));
        tSolape.setText("2,7");
        tSolape.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tSolapeKeyReleased(evt);
            }
        });

        cAncho.setModel(new javax.swing.DefaultComboBoxModel(new String[] {}));
        cAncho.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cAnchoActionPerformed(evt);
            }
        });

        tCantidad.setFont(new java.awt.Font("Tahoma", 1, 11));

        tCodigoLinea.setFont(new java.awt.Font("Tahoma", 1, 11));

        modeloIzquierdo.addColumn("Ancho");
        modeloIzquierdo.addColumn("Largo");
        modeloIzquierdo.addColumn("Iid");

        tIzquierdo.getColumnModel().getColumn(2).setMaxWidth(0);
        tIzquierdo.getColumnModel().getColumn(2).setMinWidth(0);
        tIzquierdo.getTableHeader().getColumnModel().getColumn(2).setMaxWidth(0);
        tIzquierdo.getTableHeader().getColumnModel().getColumn(2).setMinWidth(0);
        sCrollIzquierdo.setViewportView(tIzquierdo);

        org.jdesktop.layout.GroupLayout pIzquierdoLayout = new org.jdesktop.layout.GroupLayout(pIzquierdo);
        pIzquierdo.setLayout(pIzquierdoLayout);
        pIzquierdoLayout.setHorizontalGroup(
            pIzquierdoLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(sCrollIzquierdo, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 224, Short.MAX_VALUE)
        );
        pIzquierdoLayout.setVerticalGroup(
            pIzquierdoLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(sCrollIzquierdo, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 72, Short.MAX_VALUE)
        );

        cbAutomatico.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbAutomaticoActionPerformed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout layout = new org.jdesktop.layout.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(layout.createSequentialGroup()
                .addContainerGap()
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(layout.createSequentialGroup()
                        .add(tCodigoLinea, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 51, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(tCantidad, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 51, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(tCodigo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 181, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(tSalida, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 50, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(tLinea, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 51, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(8, 8, 8)
                        .add(cCorteLona, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 77, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(19, 19, 19)
                        .add(cbAutomatico)
                        .add(18, 18, 18)
                        .add(tDobladillo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 38, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(tSolape, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 40, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(cAncho, 0, 97, Short.MAX_VALUE))
                    .add(pIzquierdo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(layout.createSequentialGroup()
                .addContainerGap()
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(org.jdesktop.layout.GroupLayout.TRAILING, layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                        .add(cCorteLona, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(tDobladillo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(tSolape, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(cAncho, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                    .add(org.jdesktop.layout.GroupLayout.TRAILING, layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                        .add(tCodigo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(tCantidad, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(tCodigoLinea, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(tLinea, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(tSalida, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .add(pIzquierdo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
            .add(layout.createSequentialGroup()
                .add(16, 16, 16)
                .add(cbAutomatico, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 13, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void vaciarPanelIzquierdo(){
        Modelo modelo = (Modelo) tIzquierdo.getModel();

        int i, j;

        //obtenemos el nº de filas;
        j = modelo.getRowCount();

        //eliminamos todas las filas
        for (i = 0; i < j; i++) {
            modelo.removeRow(0);
        }
    }
    
    private void rellenarPanelIzquierdo() {
        Modelo modelo = (Modelo) tIzquierdo.getModel();

        int i, j;
        int contador = 0;
        //obtenemos el nº de filas;
        j = modelo.getRowCount();

        //eliminamos todas las filas
        for (i = 0; i < j; i++) {
            modelo.removeRow(0);
        }
        
        Float restoUsado = calcularRestoUsado();
        List<Existencia> lista;
        
        Caracteristica carac = corteLona.getCaracteristica();
        Float largo = new Float(Util.convertirComaAPunto(tSalida.getText()));
        if(carac != null){
            lista = BaseDatos.getListaMovimientosRestos(this.p.getPresupuesto().getIid(), getArticulo().getIid(), getCaracteristica().getIid(), p.getAlmacen().getIid(), largo);
        } else {
            lista = BaseDatos.getListaMovimientosRestos(this.p.getPresupuesto().getIid(), getArticulo().getIid(), null, p.getAlmacen().getIid(), largo);
        }

        if (lista == null) {
            lista = new ArrayList<Existencia>();
        }

        Existencia ex;
        Iterator it;
        Object[] fila;
        for (it = lista.iterator(); it.hasNext();) {
            fila = new Object[3];
            ex = (Existencia) it.next();
            if(ex.getCantidad2() >= restoUsado){
                fila[0] = Util.convertirPuntoAComa(ex.getCantidad2().toString());
                fila[1] = Util.convertirPuntoAComa(ex.getCantidad1().toString());
            
                fila[2] = ex.getIid();
                modelo.addRow(fila);
                if(this.inicializar && ncl.getListaIdentificadoresExistenciasRestosUsados().contains(ex.getIid())){
                    if(!listaRestosIniciales.contains(ex.getIid())){
                        listaRestosIniciales.add(ex.getIid());
                    }
                    tIzquierdo.addRowSelectionInterval(contador, contador);
                }
                contador++;
            }
        }
    }

private void tDobladilloKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tDobladilloKeyReleased
    int tamaño = tDobladillo.getText().length();
    if (tamaño > 0) {
        char c = tDobladillo.getText().charAt(tamaño - 1);

        if (c == '.') {
            String contenidoAntiguo = tDobladillo.getText().replace(".", ",");
            tDobladillo.setText(contenidoAntiguo);
            c = ',';
        }

        if (!((c >= '0' && c <= '9') || c == ',')) {
            String str = tDobladillo.getText().substring(0, tamaño - 1);
            tDobladillo.setText(str);
        } else if (c == ',') {
            int indicePunto = tDobladillo.getText().indexOf(',');
            if (indicePunto != (tamaño - 1)) {
                String str = tDobladillo.getText().substring(0, tamaño - 1);
                tDobladillo.setText(str);
            }
        }
    } else {
        tDobladillo.setText("0");
    }
}//GEN-LAST:event_tDobladilloKeyReleased

private void tSolapeKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tSolapeKeyReleased
    int tamaño = tSolape.getText().length();
    if (tamaño > 0) {
        char c = tSolape.getText().charAt(tamaño - 1);

        if (c == '.') {
            String contenidoAntiguo = tSolape.getText().replace(".", ",");
            tSolape.setText(contenidoAntiguo);
            c = ',';
        }

        if (!((c >= '0' && c <= '9') || c == ',')) {
            String str = tSolape.getText().substring(0, tamaño - 1);
            tSolape.setText(str);
        } else if (c == ',') {
            int indicePunto = tSolape.getText().indexOf(',');
            if (indicePunto != (tamaño - 1)) {
                String str = tSolape.getText().substring(0, tamaño - 1);
                tSolape.setText(str);
            }
        }
    } else {
        tSolape.setText("0");
    }
}//GEN-LAST:event_tSolapeKeyReleased

private void cbAutomaticoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbAutomaticoActionPerformed
    if(cbAutomatico.isSelected()){
        rellenarPanelIzquierdo();
        pIzquierdo.setVisible(true);
    } else {
        pIzquierdo.setVisible(false);
    }
    repaint();
    if(ncl == null){
        ncls.actualizarLineas();
    } else {
        ncl.actualizarLineas();
    }
    
}//GEN-LAST:event_cbAutomaticoActionPerformed

private void cAnchoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cAnchoActionPerformed
    if(cAncho.getSelectedIndex() == 0){
        cbAutomatico.setSelected(false);
        cbAutomatico.setEnabled(false);
        pIzquierdo.setVisible(false);
        vaciarPanelIzquierdo();
    } else {
        cbAutomatico.setEnabled(true);
        pIzquierdo.setVisible(false);
    }
    
    if(cbAutomatico.isSelected()){
        rellenarPanelIzquierdo();
        pIzquierdo.setVisible(true);
    } else {
        pIzquierdo.setVisible(false);
    }
    repaint();
    
    if(ncl == null){
        ncls.actualizarLineas();
    } else {
        ncl.actualizarLineas();
    }
}//GEN-LAST:event_cAnchoActionPerformed

private void cCorteLonaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cCorteLonaActionPerformed
    String corteLonaSel = (String) cCorteLona.getSelectedItem();
    if(corteLonaSel.equals(Constantes.TIPO_CORTE_DEGRADEE)){
        cbAutomatico.setSelected(false);
        cbAutomatico.setEnabled(false);
        pIzquierdo.setVisible(false);
    } else {
        if(cbAutomatico.isSelected()){
            rellenarPanelIzquierdo();
            pIzquierdo.setVisible(true);
        } else {
            pIzquierdo.setVisible(false);
        }
        
        if(cAncho.getSelectedIndex() > 0){
            cbAutomatico.setEnabled(true);
        }
    }
    
    repaint();
    ncl.actualizarLineas();
}//GEN-LAST:event_cCorteLonaActionPerformed

    public boolean medidaRellena() {
        return !((String) cAncho.getSelectedItem()).equals(Constantes.SIN_EXISTENCIAS);
    }
    
    public Float getCantidad(){
        return new Float(Util.convertirComaAPunto(tCantidad.getText()));
    }
    
    public Float getAlto() {
        return new Float(Util.convertirComaAPunto(tSalida.getText()));
    }

    public Float getAncho() {
        return ancho;
    }

    public Float getAnchoSeleccionado() {
        return anchoSeleccionado;
    }

    public boolean isHayRestos() {
        return hayRestos;
    }

    public int getNumPañosEnteros() {
        return numPañosEnteros;
    }

    public Float getRestoIzquierdo() {
        return restoIzquierdo;
    }
    
    public Articulo getArticulo(){
        return corteLona.getArticulo();
    }
    
    public Caracteristica getCaracteristica(){
        return corteLona.getCaracteristica();
    }
    
    public boolean getAutmomatico(){
        return cbAutomatico.isSelected();
    }

    public void pintarLona(){
        String corteLonaS;
        int anchoTotal = 0;
        BufferedImage bi = null;
        int altoN = 50;
        int anchoN = 100;
        float []dash={1.5f,1.5f,1.5f};
        Font fuente = new Font("Serif", Font.PLAIN, 11);
        Shape linea;
        BasicStroke bs;
        Graphics2D g;
        int i;
        int numLineas;

        if(!cbAutomatico.isSelected()){
            corteLonaS = (String) this.cCorteLona.getSelectedItem();
            
            if(corteLonaS.equals(Constantes.TIPO_CORTE_ASIMETRICO)){
                
                numLineas = 0;
                
                anchoTotal = numPañosEnteros * anchoN;
                numLineas = numPañosEnteros - 1;
                
                if(hayRestos){
                    anchoTotal += anchoN;
                    numLineas++;
                }
                
                bi = new BufferedImage(anchoTotal + 1, altoN + 1, BufferedImage.TYPE_INT_RGB);
                g = bi.createGraphics();
                
                g.setColor(Color.WHITE);
                g.fillRect(0, 0, anchoTotal + 1, altoN + 1);
                
                g.setColor(Color.BLACK);
                g.drawRect(0, 0, anchoTotal, altoN);
                
                for(i = 1;  i <= numLineas; i++){
                    linea = new Line2D.Double(anchoN * i, 0, anchoN * i, altoN);
                    bs = new BasicStroke(1.0f,BasicStroke.CAP_BUTT,BasicStroke.JOIN_MITER,1.0f,dash,0.0f);
                    g.setStroke(bs);
                    g.draw(linea);
                }
                
                for(i = 1;  i <= numLineas + 1; i++){
                    g.setFont(fuente);
                    
                    if((i == numLineas + 1) && hayRestos){
                        g.drawString("TC", i * anchoN - (anchoN / 2) - 20, (altoN / 2) - 8 );
                        g.drawString(tSalida.getText() + "x" + Util.convertirPuntoAComa(restoIzquierdo.toString()), i * anchoN - (anchoN / 2) - 43 , (altoN / 2) + 8 );
                    } else {
                        g.drawString("TE", i * anchoN - (anchoN / 2) - 20, (altoN / 2) - 8 );
                        g.drawString(tSalida.getText() + "x" + Util.convertirPuntoAComa(anchoSeleccionado.toString()), i * anchoN - (anchoN / 2) - 43 , (altoN / 2) + 8 );
                    }
                }
            } else if(corteLonaS.equals(Constantes.TIPO_CORTE_RETAL_MAXI) || corteLonaS.equals(Constantes.TIPO_CORTE_RETAL_MINI)){
                numLineas = 0;
                
                anchoTotal = numPañosEnteros * anchoN;
                numLineas = numPañosEnteros - 1;
                
                if(hayRestos){
                    anchoTotal += anchoN * 2;
                    numLineas += 2;
                }

                bi = new BufferedImage(anchoTotal + 1, altoN + 1, BufferedImage.TYPE_INT_RGB);
                g = bi.createGraphics();
                
                g.setColor(Color.WHITE);
                g.fillRect(0, 0, anchoTotal + 1, altoN + 1);
                
                g.setColor(Color.BLACK);
                g.drawRect(0, 0, anchoTotal, altoN);
                
                for(i = 1;  i <= numLineas; i++){
                    linea = new Line2D.Double(anchoN * i, 0, anchoN * i, altoN);
                    bs = new BasicStroke(1.0f,BasicStroke.CAP_BUTT,BasicStroke.JOIN_MITER,1.0f,dash,0.0f);
                    g.setStroke(bs);
                    g.draw(linea);
                }
                
                for(i = 1;  i <= numLineas + 1; i++){
                    g.setFont(fuente);
                    
                    if((i == 1 || i == numLineas + 1) && hayRestos){
                        g.drawString("TC", i * anchoN - (anchoN / 2) - 20, (altoN / 2) - 8 );
                        g.drawString(tSalida.getText() + "x" + Util.convertirPuntoAComa(restoIzquierdo.toString()), i * anchoN - (anchoN / 2) - 43 , (altoN / 2) + 8 );
                    } else {
                        g.drawString("TE", i * anchoN - (anchoN / 2) - 20, (altoN / 2) - 8 );
                        g.drawString(tSalida.getText() + "x" + Util.convertirPuntoAComa(anchoSeleccionado.toString()), i * anchoN - (anchoN / 2) - 43 , (altoN / 2) + 8 );
                    }
                }
            }
        }
  
        try{
            File outputfile = new File("C:\\Users\\Antonio\\Desktop\\Imagenes\\paco.png");
            ImageIO.write(bi, "png", outputfile);
        } catch(Exception ex){
            ex.printStackTrace();
        }
    }
    
    public boolean hayCambios(){
        
        boolean automaticoNuevo = cbAutomatico.isSelected();
        String tCorteLonaNuevo = (String) cCorteLona.getSelectedItem();
        String dobladilloNuevo = Util.convertirPuntoAComa(new Double(Util.convertirComaAPunto(tDobladillo.getText())).toString());
        String solapeNuevo = Util.convertirPuntoAComa(new Double(Util.convertirComaAPunto(tSolape.getText())).toString());
        String anchoNuevo = (String)cAncho.getSelectedItem();

        List<Integer> listaRestosFinales = new ArrayList<Integer>();
        if(this.cbAutomatico.isSelected()){

            int indices[] = tIzquierdo.getSelectedRows();
            int contadorIndiceRestos;
            Float restosSeleccionados = 0F;
            Existencia ex;
            for(contadorIndiceRestos = 0; contadorIndiceRestos < indices.length; contadorIndiceRestos++){
                ex = BaseDatos.getExistenciaByIid((Integer)tIzquierdo.getValueAt(indices[contadorIndiceRestos], 2));
                listaRestosFinales.add(ex.getIid());
            }
        }
        
        boolean cambiosRestos = !(listaRestosFinales.containsAll(listaRestosIniciales) && listaRestosIniciales.size() == listaRestosFinales.size());

        return automaticoNuevo != automaticoAntiguo 
                || !tCorteLonaNuevo.equals(tCorteLonaAntiguo)
                || !dobladilloNuevo.equals(dobladilloAntiguo)
                || !solapeNuevo.equals(solapeAntiguo)
                || !anchoNuevo.equals(anchoAntiguo)
                || (automaticoNuevo && automaticoAntiguo && cambiosRestos);
    }
    
    public Integer getIid(){
        return this.iid;
    }
    
    public boolean getHayCambios(){
        return hayCambios;
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox cAncho;
    private javax.swing.JComboBox cCorteLona;
    private javax.swing.JCheckBox cbAutomatico;
    private javax.swing.JPanel pIzquierdo;
    private javax.swing.JScrollPane sCrollIzquierdo;
    private javax.swing.JTextField tCantidad;
    private javax.swing.JTextField tCodigo;
    private javax.swing.JTextField tCodigoLinea;
    private javax.swing.JTextField tDobladillo;
    private javax.swing.JTable tIzquierdo;
    private javax.swing.JTextField tLinea;
    private javax.swing.JTextField tSalida;
    private javax.swing.JTextField tSolape;
    // End of variables declaration//GEN-END:variables
}
