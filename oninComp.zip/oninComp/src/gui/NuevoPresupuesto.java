package gui;

import acceso.BaseDatos;
import auxiliar.CorteLona;
import auxiliar.CortePerfil;
import auxiliar.DesUnidades;
import auxiliar.Objeto2Elementos;
import auxiliar.PdfFilter;
import informes.Informe;
import bean.Agentes;
import bean.Almacen;
import bean.Articulo;
import bean.Caracteristica;
import bean.ClaseDocumento;
import bean.Colores;
import bean.Comercial;
import bean.Dac;
import bean.DacPresupuesto;
import bean.DescuentoClienteArticulo;
import bean.DescuentoClienteFamiliaVenta;
import bean.Despiece;
import bean.Empresa;
import bean.EstadoDocumento;
import bean.LineaCorteLona;
import bean.FamiliaVenta;
import bean.FormaPago;
import bean.DespiecePresupuesto;
import bean.FormaPago2;
import bean.Interlocutor;
import bean.InterlocutorFamiliaVenta;
import bean.Iva;
import bean.LineaPresupuesto;
import bean.Medicion;
import bean.Metadata;
import bean.Presupuesto;
import bean.SeleccionPresupuesto;
import bean.TipoAgente;
import bean.TipoControl;
import bean.TipoMedida;
import bean.Usuario;
import bean.VariablePresupuesto;
import informes.recibos.Recibo;
import informes.recibos.VencimientoImpreso;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.KeyStroke;
import javax.swing.ScrollPaneLayout;
import informes.confeccionLonasTotal.ConfeccionLonasTotal;
import informes.confeccionLonasTotal.LineaConfeccionTotal;
import informes.hojaTrabajoTotal.HojaTrabajoTotal;
import informes.hojaTrabajoTotal.LineaHojaTrabajoTotal;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.text.ParseException;
import java.util.logging.Level;
import java.util.logging.Logger;
import modelo.Modelo;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import util.Constantes;
import util.Util;

public class NuevoPresupuesto extends javax.swing.JFrame {
    private int num_articulos;
    protected List listaArticulos;
    private Empresa e;
    protected FormaPago fp;
    protected FormaPago2 fp2;
    protected FormaPago2 fp2_aux;
    private double importe_total = 0;
    private double importe_total_dto = 0;
    private double dto = 0;
    private double precio_dto = 0;
    private double precio_iva;
    private double precio_final;
    private boolean crear;
    private Presupuesto p;
    protected Integer cod_fp2;
    private boolean creacion;
    private ClaseDocumento cd;
    private Usuario u;
    private boolean pagado;
    private boolean impagado;
    private Comercial comercial;
    private int lineaActiva;
    protected HashMap rellenarDacMap;
    private int lineasVacias = 0;
    private Articulo a;
    private HashMap<Integer, Integer> mapaNuevoClaves;
    private boolean preparadoAntiguo;
    private boolean fabricadoAntiguo;
    private boolean confeccionadoAntiguo;
    private boolean finalizadoAntiguo;
    private boolean calcularPre = false;
    private Interlocutor i;
    private List formulas;
    private Agentes interCli;
    private ListaDePresupuestos ldp;
    public Date fechaD;

    public NuevoPresupuesto(Empresa e, ClaseDocumento cd, Usuario u, ListaDePresupuestos ldp) {
        super("Onin : " + cd.getDescripcion());
        creacion = true;
        fp = null;
        fp2 = null;
        fp2_aux = null;
        num_articulos = 1;
        this.e = e;
        this.u = u;
        this.cd = cd;
        this.ldp = ldp;
        this.fechaD = new Date();
        p = new Presupuesto();
        p.setClase_documento(this.cd);
        crear = true;
        listaArticulos = new ArrayList();
        initComponents();
        String descripcion = cd.getDescripcion();
        cod_fp2 = -1;
        creacion = false;
        lconvertido.setText(" ");
        pagado = false;
        impagado = false;
        cComercial.setVisible(false);
        comercial = null;
        tRecomendadoPor.setVisible(false);
        
        anadirLineaPresupuesto();

        if (descripcion.equals(Constantes.ALBARANC) || descripcion.equals(Constantes.FACTURAC)) {
            jMenuAlbaran.setEnabled(false);
        }

        if (descripcion.equals(Constantes.PEDIDOC) || descripcion.equals(Constantes.ALBARANC) || descripcion.equals(Constantes.FACTURAC)) {
            lCliente.setText("Proveedor");
        }
        
        Metadata mdtIva = (Metadata) BaseDatos.obtenerMetadaPorNombre("ivaDocumento", e.getIid());
        if (mdtIva != null) {
            tIva.setText(Util.convertirPuntoAComa(mdtIva.getValor()));
        }
        
        if (descripcion.equals(Constantes.PRESUPUESTO)) {
            jMenuAlbaran.setText("Convertir a Albarán");
        } else if (cd.getDescripcion().equals("Albarán")) {
            jMenuAlbaran.setText("Convertir a Factura");
        } else {
            jMenuAlbaran.setText("Convertir");
            jMenuAlbaran.setEnabled(false);
        }
        
        SimpleDateFormat formatoFecha = new SimpleDateFormat("dd/MM/yyyy");
        tfecha.setText(formatoFecha.format(this.fechaD));

        if (this.cd.getDescripcion().equals(Constantes.PEDIDO)) {
            cFechaEntrega.setDateFormatString("dd/MM/yyyy");
            cFechaEntrega.setDate(this.fechaD);
            this.cestado.setVisible(false);
            this.lestado.setVisible(false);
            cbPreparado.getModel().setSelected(false);
            cbFabricado.getModel().setSelected(false);
            cbInstalado.getModel().setSelected(false);
            cbConfeccionado.getModel().setSelected(false);
        } else {
            lFechaEntrega.setVisible(false);
            cFechaEntrega.setVisible(false);
            bVerEntregas.setVisible(false);
            this.cbConfeccionado.setVisible(false);
            this.cbFabricado.setVisible(false);
            this.cbPreparado.setVisible(false);
            this.cbInstalado.setVisible(false);
            jMenuItemCorteLona.setVisible(false);
            jMenuItemVerCorteLona.setVisible(false);
            jMenuItemCortePerfil.setVisible(false);
            jMenuItemDescuentoUnidades.setVisible(false);
            jSeparator1.setVisible(false);
            jMenuItemMontaje.setVisible(false);
        }

        lineaActiva = 0;
        crearIconosBotones();
        rellenarDacMap = new HashMap();

        if (descripcion.equals(Constantes.PEDIDOC) || descripcion.equals(Constantes.ALBARANC) || descripcion.equals(Constantes.FACTURAC)) {
            lcontactado.setVisible(false);
            cContactado.setVisible(false);
            cComercial.setVisible(false);
            tRecomendadoPor.setVisible(false);
            bGuardarCliente.setText("Guardar Proveedor");
        }

        jMenuPagado.setEnabled(false);
        jMenuImpagado.setEnabled(false);
        crearAcciones();

        if (!this.getTitle().contains(Constantes.FACTURA)) {
            jMenuImprimirRecibos.setEnabled(false);
        }

        calcularPre = true;
    }

    public NuevoPresupuesto(Empresa e, Usuario u, Medicion me) {
        super("Onin : " + Constantes.PRESUPUESTO);
        creacion = true;
        fp = null;
        fp2 = null;
        fp2_aux = null;
        num_articulos = 1;
        this.e = e;
        this.u = u;
        this.cd = BaseDatos.getClaseDocumentosByDescripcion(Constantes.PRESUPUESTO);
        p = new Presupuesto();
        p.setClase_documento(this.cd);
        p.setMedicion(me.getIid());
        crear = true;
        listaArticulos = new ArrayList();
        lconvertido.setText(" ");
        tIva.setEnabled(false);
        cod_fp2 = -1;
        creacion = false;
        initComponents();
        String descripcion = cd.getDescripcion();

        if (descripcion.equals(Constantes.ALBARANC) || descripcion.equals(Constantes.FACTURAC)) {
            jMenuAlbaran.setEnabled(false);
        }

        anadirLineaPresupuesto();

        Metadata mdtIva = (Metadata) BaseDatos.obtenerMetadaPorNombre("ivaDocumento", e.getIid());
        if (mdtIva != null) {
            tIva.setText(Util.convertirPuntoAComa(mdtIva.getValor()));
        }
        
        if (descripcion.equals(Constantes.PRESUPUESTO)) {
            jMenuAlbaran.setText("Convertir a Albarán");
        } else if (cd.getDescripcion().equals("Albarán")) {
            jMenuAlbaran.setText("Convertir a Factura");
        } else {
            jMenuAlbaran.setText("Convertir");
            jMenuAlbaran.setEnabled(false);
        }
        pagado = false;
        impagado = false;
        cComercial.setVisible(false);
        comercial = null;
        tRecomendadoPor.setVisible(false);

        this.fechaD = new Date();
        SimpleDateFormat formatoFecha = new SimpleDateFormat("dd/MM/yyyy");
        tfecha.setText(formatoFecha.format(this.fechaD));

        if (descripcion.equals(Constantes.PEDIDO)) {
            cFechaEntrega.setDateFormatString("dd/MM/yyyy");
            cFechaEntrega.setDate(fechaD);
            this.cestado.setVisible(false);
            this.lestado.setVisible(false);
            cbPreparado.getModel().setSelected(false);
            cbFabricado.getModel().setSelected(false);
            cbInstalado.getModel().setSelected(false);
            cbConfeccionado.getModel().setSelected(false);
        } else {
            lFechaEntrega.setVisible(false);
            cFechaEntrega.setVisible(false);
            bVerEntregas.setVisible(false);
            this.cbConfeccionado.setVisible(false);
            this.cbFabricado.setVisible(false);
            this.cbPreparado.setVisible(false);
            this.cbInstalado.setVisible(false);
            jMenuItemCorteLona.setVisible(false);
            jMenuItemVerCorteLona.setVisible(false);
            jMenuItemCortePerfil.setVisible(false);
            jMenuItemDescuentoUnidades.setVisible(false);
            jSeparator1.setVisible(false);
            jMenuItemMontaje.setVisible(false);
        }

        lineaActiva = 0;
        crearIconosBotones();
        rellenarDacMap = new HashMap();

        if (descripcion.equals(Constantes.PEDIDOC) || descripcion.equals(Constantes.ALBARANC) || descripcion.equals(Constantes.FACTURAC)) {
            lcontactado.setVisible(false);
            cContactado.setVisible(false);
            cComercial.setVisible(false);
            tRecomendadoPor.setVisible(false);
            bGuardarCliente.setText("Guardar Proveedor");
            lCliente.setText("Proveedor");
        }

        jMenuPagado.setEnabled(false);
        jMenuImpagado.setEnabled(false);
        crearAcciones();

        if (!this.getTitle().contains(Constantes.FACTURA)) {
            jMenuImprimirRecibos.setEnabled(false);
        }

        //Informar con datos de la medición
        if (me.getIidCliente() != null) {
            tCodCliente.setText(BaseDatos.obtenerAgenteByIid(me.getIidCliente()).getCod_agente());
        }

        tNombreCliente.setText(me.getNombre());
        tDireccionCliente.setText(me.getDireccion());
        tTelefonoCliente.setText(me.getTelefono());
        tEmailCliente.setText(me.getEmail());
        tLocalidadCliente.setText(me.getLocalidad());
        tProvinciaCliente.setText(me.getProvincia());
        tDniCliente.setText(me.getDni());
        tCpCliente.setText(me.getCodigoPostal());
        cContactado.setSelectedItem(me.getContactado());
        tReferencia.setText(me.getReferencia());
        if (me.getIidComercial() != null) {
            cComercial.setSelectedItem(BaseDatos.obtenerComercialPorIid(me.getIidComercial()).getNombre());
        }
        calcularPre = true;
    }

    public NuevoPresupuesto(Empresa e, ClaseDocumento cd, Usuario u, Articulo a, Caracteristica c, Interlocutor inter) {
        super("Onin : " + cd.getDescripcion());
        creacion = true;
        fp = null;
        fp2 = null;
        fp2_aux = null;
        num_articulos = 1;
        this.e = e;
        this.u = u;
        this.cd = cd;
        this.a = a;
        rellenarDacMap = new HashMap();
        p = new Presupuesto();
        p.setClase_documento(this.cd);
        crear = true;
        lconvertido.setText(" ");
        listaArticulos = new ArrayList();
        initComponents();
        String descripcion = cd.getDescripcion();

        if (inter != null) {
            this.i = inter;
            Empresa eH = BaseDatos.obtenerEmpresaPorIid(inter.getEmpresaHija().getIid());
            cInterlocutor.setSelectedItem(eH.getCod_empresa());
            this.obtenerInterlocutorFormulas();
        }

        if (descripcion.equals(Constantes.ALBARANC) || descripcion.equals(Constantes.FACTURAC)) {
            jMenuAlbaran.setEnabled(false);
        }
        
        LineaPresupuesto lp = new LineaPresupuesto();
        lp.setArticulo_iid(a);
        lp.setCantidad(1.0);
        FamiliaVenta fv = BaseDatos.obtenerFamiliaVentaPorIid(a.getIid_fam_venta().getIid());
        TipoControl tp = BaseDatos.obtenerTipoControlPorIid(fv.getIid_tipo_control().getIid());
        TipoMedida tm = BaseDatos.obtenerTipoMedidaByIid(tp.getIid_tipo_medida().getIid());
        lp.setNummedidas(tm.getNum_dimensiones());
        lp.setPrecio(0.0);

        if (c == null) {
            List<Caracteristica> lc = BaseDatos.getListaCaracteristicas(e, a);
            if (lc.size() > 0) {
                c = (Caracteristica) lc.get(0);
            }
        }
        lp.setCaracteristica(c);
        mapaNuevoClaves = new HashMap<Integer, Integer>();
        RellenarDac rd = anadirLineaPresupuestoAlbaran(lp, a, c);

        Metadata mdtIva = (Metadata) BaseDatos.obtenerMetadaPorNombre("ivaDocumento", e.getIid());
        if (mdtIva != null) {
            tIva.setText(Util.convertirPuntoAComa(mdtIva.getValor()));
        }
        cod_fp2 = -1;
        creacion = false;

        if (cd.getDescripcion().equals("Presupuesto")) {
            jMenuAlbaran.setText("Convertir a Albarán");
        } else if (cd.getDescripcion().equals("Albarán")) {
            jMenuAlbaran.setText("Convertir a Factura");
        } else {
            jMenuAlbaran.setText("Convertir");
            jMenuAlbaran.setEnabled(false);
        }
        pagado = false;
        impagado = false;
        cComercial.setVisible(false);
        comercial = null;
        tRecomendadoPor.setVisible(false);

        this.fechaD = new Date();
        SimpleDateFormat formatoFecha = new SimpleDateFormat("dd/MM/yyyy");
        tfecha.setText(formatoFecha.format(this.fechaD));

        if (descripcion.equals(Constantes.PEDIDO)) {
            cFechaEntrega.setDateFormatString("dd/MM/yyyy");
            cFechaEntrega.setDate(this.fechaD);
            this.cestado.setVisible(false);
            this.lestado.setVisible(false);
        } else {
            lFechaEntrega.setVisible(false);
            cFechaEntrega.setVisible(false);
            bVerEntregas.setVisible(false);
            this.cbConfeccionado.setVisible(false);
            this.cbFabricado.setVisible(false);
            this.cbPreparado.setVisible(false);
            this.cbInstalado.setVisible(false);
        }

        lineaActiva = 0;
        crearIconosBotones();

        if (descripcion.equals(Constantes.PEDIDOC) || descripcion.equals(Constantes.ALBARANC) || descripcion.equals(Constantes.FACTURAC)) {
            lcontactado.setVisible(false);
            cContactado.setVisible(false);
            cComercial.setVisible(false);
            tRecomendadoPor.setVisible(false);
            bGuardarCliente.setText("Guardar Proveedor");
            lCliente.setText("Proveedor");
        }

        jMenuPagado.setEnabled(false);
        jMenuImpagado.setEnabled(false);
        crearAcciones();

        if (!this.getTitle().contains(Constantes.FACTURA)) {
            jMenuImprimirRecibos.setEnabled(false);
        }

        setVisible(true);
        if (rd != null) {
            rd.accionAceptar();
        }
        calcularPre = true;
    }

    public NuevoPresupuesto(Empresa e, Presupuesto p, Usuario u, ListaDePresupuestos ldp) {
        creacion = true;
        crear = false;
        this.p = p;
        this.e = e;
        this.u = u;
        this.ldp = ldp;
        this.cd = BaseDatos.getClaseDocumentosByIid(p.getClase_documento().getIid());
        this.setTitle("Onin : " + cd.getDescripcion());
        num_articulos = 1;
        String descripcion = cd.getDescripcion();
        initComponents();
        cSeries.setSelectedItem(p.getSerie());
        listaArticulos = new ArrayList();
        tdto.setText(Util.convertirPuntoAComa(String.valueOf(p.getDto())));
        tnumero.setText(p.getNumero());
        fp2 = BaseDatos.obtenerFormaPago2(p.getFp().getIid());
        fp2_aux = new FormaPago2();
        fp2_aux.modificar(fp2);
        fp2_aux.setIid(fp2.getIid());
        
        if (descripcion.equals(Constantes.ALBARANC) || descripcion.equals(Constantes.FACTURAC)) {
            jMenuAlbaran.setEnabled(false);
        }

        if (p.getIvaDocumento() != null) {
            tIva.setText(Util.convertirPuntoAComa(p.getIvaDocumento().toString()));
            tIva.setEnabled(false);
        }

        if (fp2 != null) {
            cod_fp2 = fp2.getIid();
            fp = BaseDatos.obtenerFormaPago(String.valueOf(fp2.getCodigo()));
            cformapago.setSelectedItem(fp.getCodigo());
        }

        if (((String) cformapago.getSelectedItem()).equals(Constantes.VACIO)) {
            bcrearplazo.setEnabled(false);
            beliminarplazo.setEnabled(false);
            bmodificarplazo.setEnabled(false);
        }

        if (p.getEstado() != null) {
            cestado.setSelectedItem(BaseDatos.obtenerEstadoPorIid(p.getEstado().getIid()).getDescripcion());
        } else {
            cestado.setSelectedIndex(0);
        }

        tObservaciones.setText(p.getObservaciones());
        tCodCliente.setText(p.getCodigoCliente());
        tDniCliente.setText(p.getCifCliente());
        tNombreCliente.setText(p.getNombreCliente());
        tDireccionCliente.setText(p.getDomicilioCliente());
        tLocalidadCliente.setText(p.getLocalidadCliente());
        tProvinciaCliente.setText(p.getProvinciaCliente());
        tCpCliente.setText(p.getCpCliente());
        tPaisCliente.setText(p.getPaisCliente());
        tTelefonoCliente.setText(p.getTelefonoCliente());
        tEmailCliente.setText(p.getEmailCliente());
        tRecomendadoPor.setText(p.getRecomendadoPor());
        tReferencia.setText(p.getReferencia());

        Object[] cliente = BaseDatos.obtenerAgentePorEmpresaYCodigoPresupuestoReducido(e.getIid(), p.getCodigoCliente());
        Agentes newCliente = new Agentes();
        if (cliente != null && cliente[0] != null) {
            newCliente.setObservaciones((String) cliente[0]);
        }
        if (cliente != null && cliente[1] != null) {
            newCliente.setIva((Iva) cliente[1]);
        }
        if (cliente != null && cliente[2] != null) {
            newCliente.setExento_iva((Boolean) cliente[2]);
        }

        creacion = false;

        if (this.p.getConvertido()) {
            lconvertido.setText("Este " + cd.getDescripcion() + " ya ha sido convertido");
        } else {
            lconvertido.setText(" ");
        }

        if (descripcion.equals(Constantes.PEDIDOC) || descripcion.equals(Constantes.ALBARANC) || descripcion.equals(Constantes.FACTURAC)) {
            lcontactado.setVisible(false);
            cContactado.setVisible(false);
            cComercial.setVisible(false);
            tRecomendadoPor.setVisible(false);
            bGuardarCliente.setText("Guardar Proveedor");
            lCliente.setText("Proveedor");
        }

        cargarLineasPresupuesto();
        calcularPre = false;
        calcularPrecio(false);

        boolean hayNotasDocumento = false;
        hayNotasDocumento = p.getNota_documento() != null && p.getNota_documento().length() > 0;

        boolean tieneObservacionesCliente = false;
        if (cliente != null) {
            tieneObservacionesCliente = newCliente.getObservaciones() != null && newCliente.getObservaciones().length() > 0;
        }

        if (hayNotasDocumento && tieneObservacionesCliente) {
            JOptionPane.showMessageDialog(null, "Este documento tiene notas asociadas\nEste cliente tiene observaciones asociadas", "Información", JOptionPane.INFORMATION_MESSAGE);
            bVerNotas.setEnabled(true);
        } else if (hayNotasDocumento) {
            JOptionPane.showMessageDialog(null, "Este documento tiene notas asociadas", "Información", JOptionPane.INFORMATION_MESSAGE);
            bVerNotas.setEnabled(true);
        } else if (tieneObservacionesCliente) {
            JOptionPane.showMessageDialog(null, "Este cliente tiene observaciones asociadas", "Información", JOptionPane.INFORMATION_MESSAGE);
            bVerNotas.setEnabled(true);
        }

        if (hayNotasDocumento) {
            URL urlExclamacion = getClass().getResource("/iconos/exclamacion.PNG");
            ImageIcon iconoExclamacion = new ImageIcon(urlExclamacion);
            bHayNotas.setIcon(iconoExclamacion);
            bHayNotas.setToolTipText("Hay notas");
            bHayNotas.setVisible(true);
        } else {
            bHayNotas.setVisible(false);
        }

        if (descripcion.equals(Constantes.ALBARAN) || descripcion.equals(Constantes.ALBARANB)) {
            jMenuPagado.setEnabled(true);
            jMenuImpagado.setEnabled(true);
        } else {
            jMenuPagado.setEnabled(false);
            jMenuImpagado.setEnabled(false);
        }

        pagado = p.getPagado();
        impagado = p.getImpagado();

        cContactado.setSelectedItem(p.getContactado());
        comercial = p.getComercial();
        if (comercial != null) {
            comercial = (Comercial) BaseDatos.obtenerComercialPorIid(comercial.getIid());
            cComercial.setSelectedItem(comercial.getNombre());
            cComercial.setVisible(true);
            tRecomendadoPor.setVisible(false);
        } else {
            cComercial.setVisible(false);
        }

        if (cContactado.equals(Constantes.RECOMENDADO)) {
            tRecomendadoPor.setVisible(true);
        }

        SimpleDateFormat formatoFecha = new SimpleDateFormat("dd/MM/yyyy");
        Date fechaC = new Date(p.getFecha());
        tfecha.setText(formatoFecha.format(fechaC));
        fechaD = new Date(p.getFecha());

        if (descripcion.equals(Constantes.PEDIDO)) {
            cFechaEntrega.setDateFormatString("dd/MM/yyyy");
            try {
                Date fechaP = new Date(p.getFechaEntrega());
                tfecha.setText(formatoFecha.format(fechaC));
                cFechaEntrega.setDate(fechaP);
            } catch (Exception ex) {
                cFechaEntrega.setDate(new Date());
            }
            cestado.setVisible(false);
            lestado.setVisible(false);
            bMovimientoAlmacen.setEnabled(true);

            if (BaseDatos.obtenerMontaje(p) != null) {
                URL urlExclamacion = getClass().getResource("/iconos/construccion.PNG");
                ImageIcon iconoExclamacion = new ImageIcon(urlExclamacion);
                bHayMontaje.setIcon(iconoExclamacion);
                bHayMontaje.setToolTipText("Tiene montaje");
                bHayMontaje.setVisible(true);
            }
        } else {
            lFechaEntrega.setVisible(false);
            cFechaEntrega.setVisible(false);
            bVerEntregas.setVisible(false);
            cbConfeccionado.setVisible(false);
            cbFabricado.setVisible(false);
            cbPreparado.setVisible(false);
            cbInstalado.setVisible(false);
        }

        cbFabricado.setSelected((p.getFabricado() != null) ? p.getFabricado() : false);
        cbConfeccionado.setSelected((p.getConfeccionado() != null) ? p.getConfeccionado() : false);
        cbPreparado.setSelected((p.getPreparado() != null) ? p.getPreparado() : false);
        cbInstalado.setSelected((p.getInstalado() != null) ? p.getInstalado() : false);
        cAlmacen.setSelectedItem(BaseDatos.obtenerAlmacenById(p.getAlmacen().getIid()).getNombre());
        
        limpiarPlazosAdelantados();
        rellenarPlazosAdelantados();
        limpiarVencimientos();
        rellenarVencimientos();

        crearIconosBotones();
        habilitarControles(false);
        rellenarMapaDac();
        crearAcciones();

        //Interlocutor
        Empresa in = BaseDatos.obtenerEmpresaPorIid(p.getInterlocutor());
        cInterlocutor.setSelectedItem(in.getCod_empresa());
        //No se puede modificar el interlocutor!!!!
        cInterlocutor.setEnabled(false);

        if (!this.getTitle().contains(Constantes.FACTURA)) {
            jMenuImprimirRecibos.setEnabled(false);
        }

        calcularPre = true;
        calcularPrecio(false);
    }

    private void rellenarMapaDac() {
        rellenarDacMap = new HashMap();
        RellenarDac rd;
        Dac dacBase;
        DacPresupuesto dp;
        LineaPresupuesto lpt;
        NuevaLineaPresupuesto lip;
        List listaDacPresupuesto = BaseDatos.getlistaDacPresupuesto(p.getIid());
        Iterator<DacPresupuesto> iter = listaDacPresupuesto.iterator();

        while (iter.hasNext()) {
            dp = iter.next();
            dacBase = BaseDatos.obtenerDacById(dp.getDac().getIid());
            dp.setDac(dacBase);
            lpt = BaseDatos.obtenerLineaPresupuestoByPresupuestoCodigo(p.getIid(), dp.getCodigo());
            if (lpt != null) {
                lip = (NuevaLineaPresupuesto) panel.getComponent(mapaNuevoClaves.get(lpt.getCodigo()) - 1);
                rd = new RellenarDac(dp, lip, "Título", dacBase);
                rellenarDacMap.put(mapaNuevoClaves.get(lpt.getCodigo()), rd);
            }
        }
    }

    private void calcularNuevoIva(Agentes cliente) {
        if (cliente != null) {
            String serie = (String) cSeries.getSelectedItem();
            if (serie.equals(Constantes.SERIE_STD)) {
                if (cliente.getExento_iva() != null && cliente.getExento_iva()) {
                    tIva.setText("0,0");
                    lIva.setText("Exento Iva");
                } else {
                    Iva iva;
                    if (cliente.getIva() != null) {
                        iva = cliente.getIva();
                    } else {
                        Metadata mdtIva = (Metadata) BaseDatos.obtenerMetadaPorNombre("ivaDocumento", e.getIid());
                        iva = BaseDatos.obtenerIvaPorPorcentaje(mdtIva.getValor());
                    }
                    tIva.setText(Util.convertirPuntoAComa(String.valueOf(iva.getPorcentaje())));
                    lIva.setText("% IVA");
                }
            } else if (serie.equals(Constantes.SERIE_SEC)) {
                tIva.setText("0,0");
            }
            if (calcularPre) {
                calcularPrecio(false);
            }
        }
    }

    public Float calcularIvaInterlocutor() {
        Iva ivaI = null;
        Float ivaIF = 0.0F;

        if (interCli != null) {
            String serie = (String) cSeries.getSelectedItem();
            if (serie.equals(Constantes.SERIE_STD)) {
                if (!(interCli.getExento_iva() != null && interCli.getExento_iva())) {
                    if (interCli.getIva() != null) {
                        ivaI = interCli.getIva();
                    } else {
                        //Iva del documento
                        Metadata mdtIva = (Metadata) BaseDatos.obtenerMetadaPorNombre("ivaDocumento", e.getIid());
                        ivaI = BaseDatos.obtenerIvaPorPorcentaje(mdtIva.getValor());
                    }
                    ivaIF = ivaI.getPorcentaje() / 100;
                }
            }
        }
        return ivaIF;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane14 = new javax.swing.JScrollPane();
        jPanel1 = new javax.swing.JPanel();
        tIva = new javax.swing.JTextField();
        lPrecioTotalBruto = new javax.swing.JLabel();
        limporte_iva = new javax.swing.JLabel();
        lObservaciones = new javax.swing.JLabel();
        ldto = new javax.swing.JLabel();
        lTotal = new javax.swing.JLabel();
        lprecio = new javax.swing.JLabel();
        lSubTotal = new javax.swing.JLabel();
        tdto = new javax.swing.JTextField();
        limporte_dto = new javax.swing.JLabel();
        lprecio_final = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        tObservaciones = new javax.swing.JTextArea();
        lIva = new javax.swing.JLabel();
        ltotalbruto = new javax.swing.JLabel();
        lfecha = new javax.swing.JLabel();
        lnumero = new javax.swing.JLabel();
        tfecha = new javax.swing.JTextField();
        tnumero = new javax.swing.JTextField();
        bAnadirNotas = new javax.swing.JButton();
        bVerNotas = new javax.swing.JButton();
        cSeries = new javax.swing.JComboBox();
        lReferencia = new javax.swing.JLabel();
        tReferencia = new javax.swing.JTextField();
        lestado = new javax.swing.JLabel();
        cestado = new javax.swing.JComboBox();
        lnombre = new javax.swing.JLabel();
        ldomicilio = new javax.swing.JLabel();
        tLocalidadCliente = new javax.swing.JTextField();
        tProvinciaCliente = new javax.swing.JTextField();
        tNombreCliente = new javax.swing.JTextField();
        ltelefono = new javax.swing.JLabel();
        tCodCliente = new javax.swing.JTextField();
        binsertarCliente = new javax.swing.JButton();
        ldni = new javax.swing.JLabel();
        tDireccionCliente = new javax.swing.JTextField();
        lcontactado = new javax.swing.JLabel();
        cContactado = new javax.swing.JComboBox();
        bImprimir = new javax.swing.JButton();
        bCrearPdf = new javax.swing.JButton();
        bMandarMail = new javax.swing.JButton();
        lconvertido = new javax.swing.JLabel();
        tPaisCliente = new javax.swing.JTextField();
        tDniCliente = new javax.swing.JTextField();
        tTelefonoCliente = new javax.swing.JTextField();
        cComercial = new javax.swing.JComboBox();
        lFechaEntrega = new javax.swing.JLabel();
        lPais = new javax.swing.JLabel();
        lLocalidad = new javax.swing.JLabel();
        tProvincia = new javax.swing.JLabel();
        lCliente = new javax.swing.JLabel();
        lCpCliente = new javax.swing.JLabel();
        tCpCliente = new javax.swing.JTextField();
        lEmailCliente = new javax.swing.JLabel();
        tEmailCliente = new javax.swing.JTextField();
        tRecomendadoPor = new javax.swing.JTextField();
        bGuardarCliente = new javax.swing.JButton();
        cbPreparado = new javax.swing.JCheckBox();
        cbFabricado = new javax.swing.JCheckBox();
        cbConfeccionado = new javax.swing.JCheckBox();
        cFechaEntrega = new com.toedter.calendar.JDateChooser();
        lAlmacen = new javax.swing.JLabel();
        cAlmacen = new javax.swing.JComboBox();
        bVerNotasCliente = new javax.swing.JButton();
        cbInstalado = new javax.swing.JCheckBox();
        bVerEntregas = new javax.swing.JButton();
        cInterlocutor = new javax.swing.JComboBox();
        lFechaEntrega1 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        lfecha1 = new javax.swing.JLabel();
        lInterlocutor = new javax.swing.JLabel();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel2 = new javax.swing.JPanel();
        ttitulo2 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        panel = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        lformapago = new javax.swing.JLabel();
        cformapago = new javax.swing.JComboBox();
        tformapago = new javax.swing.JTextField();
        lformapago1 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        Modelo modeloplazosadelantados = new Modelo();
        tplazosadelantados = new javax.swing.JTable(modeloplazosadelantados);
        bcrearplazo = new javax.swing.JButton();
        bmodificarplazo = new javax.swing.JButton();
        beliminarplazo = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        Modelo modelovencimientos = new Modelo();
        tvencimientos = new javax.swing.JTable(modelovencimientos);
        bCrearVencimiento = new javax.swing.JButton();
        bmodificarvencimiento = new javax.swing.JButton();
        beliminarvencimiento = new javax.swing.JButton();
        lformapago2 = new javax.swing.JLabel();
        bHayNotas = new javax.swing.JButton();
        bInsertarArticuloAntes = new javax.swing.JButton();
        bInsertarArticuloDespues = new javax.swing.JButton();
        bInsertarArticuloPrincipio = new javax.swing.JButton();
        bInsertarNotaDespues = new javax.swing.JButton();
        bInsertarNotaAntes = new javax.swing.JButton();
        bInsertarArticuloFinal = new javax.swing.JButton();
        bInsertarNotaPrincipio = new javax.swing.JButton();
        bInsertarNotaFinal = new javax.swing.JButton();
        bMovimientoAlmacen = new javax.swing.JButton();
        bHayMontaje = new javax.swing.JButton();
        lbTercero = new javax.swing.JLabel();
        lbTercero.setVisible(false);
        baceptar = new javax.swing.JButton();
        bguardar = new javax.swing.JButton();
        bmodificar = new javax.swing.JButton();
        bcancelar = new javax.swing.JButton();
        jMenuBar70 = new javax.swing.JMenuBar();
        jMenuOpciones69 = new javax.swing.JMenu();
        jMenuAlbaran = new javax.swing.JMenuItem();
        jMenuPDF = new javax.swing.JMenuItem();
        jMenuPagado = new javax.swing.JMenuItem();
        jMenuImpagado = new javax.swing.JMenuItem();
        jMenuImprimirRecibos = new javax.swing.JMenuItem();
        jSeparator3 = new javax.swing.JSeparator();
        jMenuItemHojaMontaje = new javax.swing.JMenuItem();
        jMenuItemCorteLona = new javax.swing.JMenuItem();
        jMenuItemVerCorteLona = new javax.swing.JMenuItem();
        jMenuItemCortePerfil = new javax.swing.JMenuItem();
        jMenuItemMontaje = new javax.swing.JMenuItem();
        jMenuItemDescuentoUnidades = new javax.swing.JMenuItem();
        jSeparator1 = new javax.swing.JSeparator();
        jMenuItemNotaPrincipio = new javax.swing.JMenuItem();
        jMenuItemNotaFinal = new javax.swing.JMenuItem();
        jMenuItemNotaAntes = new javax.swing.JMenuItem();
        jMenuItemNotaDespues = new javax.swing.JMenuItem();
        jSeparator2 = new javax.swing.JSeparator();
        jMenuItemLineaPrincipio = new javax.swing.JMenuItem();
        jMenuItemLineaFinal = new javax.swing.JMenuItem();
        jMenuItemLineaAntes = new javax.swing.JMenuItem();
        jMenuItemLineaDespues = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        jPanel1.setAutoscrolls(true);

        tIva.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        tIva.setText("0.0");
        tIva.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tIvaKeyReleased(evt);
            }
        });

        lPrecioTotalBruto.setFont(new java.awt.Font("Tahoma", 1, 11));
        lPrecioTotalBruto.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        lPrecioTotalBruto.setText("0");

        limporte_iva.setFont(new java.awt.Font("Tahoma", 1, 11));
        limporte_iva.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        limporte_iva.setText("0");

        lObservaciones.setFont(new java.awt.Font("Tahoma", 1, 11));
        lObservaciones.setText("Observaciones");

        ldto.setFont(new java.awt.Font("Tahoma", 1, 11));
        ldto.setText("% dto S /");

        lTotal.setFont(new java.awt.Font("Tahoma", 1, 12));
        lTotal.setForeground(new java.awt.Color(0, 0, 204));
        lTotal.setText("Total");

        lprecio.setFont(new java.awt.Font("Tahoma", 1, 12));
        lprecio.setForeground(new java.awt.Color(0, 0, 204));
        lprecio.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        lprecio.setText("0");

        lSubTotal.setFont(new java.awt.Font("Tahoma", 1, 12));
        lSubTotal.setForeground(new java.awt.Color(0, 0, 204));
        lSubTotal.setText("SubTotal");

        tdto.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        tdto.setText("0.0");
        tdto.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tdtoKeyReleased(evt);
            }
        });

        limporte_dto.setFont(new java.awt.Font("Tahoma", 1, 11));
        limporte_dto.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        limporte_dto.setText("0");

        lprecio_final.setFont(new java.awt.Font("Tahoma", 1, 12));
        lprecio_final.setForeground(new java.awt.Color(0, 0, 204));
        lprecio_final.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lprecio_final.setText("0");

        tObservaciones.setColumns(20);
        tObservaciones.setRows(5);
        tObservaciones.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tObservacionesKeyReleased(evt);
            }
        });
        jScrollPane4.setViewportView(tObservaciones);

        lIva.setFont(new java.awt.Font("Tahoma", 1, 11));
        lIva.setText("% IVA");

        ltotalbruto.setFont(new java.awt.Font("Tahoma", 1, 11));
        ltotalbruto.setText("Total bruto");

        lfecha.setFont(new java.awt.Font("Tahoma", 1, 11));
        lfecha.setText("Fecha");

        lnumero.setFont(new java.awt.Font("Tahoma", 1, 11));
        lnumero.setText("Número");

        tfecha.setEditable(false);

        tnumero.setEditable(false);

        bAnadirNotas.setText("Añadir Notas");
        bAnadirNotas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bAnadirNotasActionPerformed(evt);
            }
        });

        bVerNotas.setText("Ver Notas");
        bVerNotas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bVerNotasActionPerformed(evt);
            }
        });

        cSeries.setModel(new javax.swing.DefaultComboBoxModel(new String[] { Constantes.SERIE_STD , Constantes.SERIE_SEC }));
        cSeries.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cSeriesActionPerformed(evt);
            }
        });

        lReferencia.setFont(new java.awt.Font("Tahoma", 1, 11));
        lReferencia.setText("Referencia");

        tReferencia.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tReferenciaKeyReleased(evt);
            }
        });

        lestado.setFont(new java.awt.Font("Tahoma", 1, 11));
        lestado.setText("Estado");

        cestado.setModel(new javax.swing.DefaultComboBoxModel(new String[] {}));

        lnombre.setFont(new java.awt.Font("Tahoma", 1, 11));
        lnombre.setText("Nombre");

        ldomicilio.setFont(new java.awt.Font("Tahoma", 1, 11));
        ldomicilio.setText("Domicilio");

        tLocalidadCliente.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tLocalidadClienteKeyReleased(evt);
            }
        });

        tProvinciaCliente.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tProvinciaClienteKeyReleased(evt);
            }
        });

        tNombreCliente.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tNombreClienteKeyReleased(evt);
            }
        });

        ltelefono.setFont(new java.awt.Font("Tahoma", 1, 11));
        ltelefono.setText("Teléfono");

        tCodCliente.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tCodClienteKeyPressed(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tCodClienteKeyReleased(evt);
            }
        });

        binsertarCliente.setText("...");
        binsertarCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                binsertarClienteActionPerformed(evt);
            }
        });

        ldni.setFont(new java.awt.Font("Tahoma", 1, 11));
        ldni.setText("CIF/DNI");

        tDireccionCliente.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tDireccionClienteKeyReleased(evt);
            }
        });

        lcontactado.setFont(new java.awt.Font("Tahoma", 1, 11));
        lcontactado.setText("Contactado");

        cContactado.setModel(new javax.swing.DefaultComboBoxModel(new String[] {Constantes.VACIO, Constantes.RECOMENDADO, Constantes.TELEFONO, Constantes.VISITA_OFICINA, Constantes.EMAIL, Constantes.TARJETA, Constantes.COMERCIALES, Constantes.PRESUPUESTO_ONLINE, Constantes.OTROS}));
        cContactado.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cContactadoActionPerformed(evt);
            }
        });

        bImprimir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bImprimirActionPerformed(evt);
            }
        });

        bCrearPdf.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bCrearPdfActionPerformed(evt);
            }
        });

        bMandarMail.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bMandarMailActionPerformed(evt);
            }
        });

        lconvertido.setFont(new java.awt.Font("Lucida Sans Unicode", 1, 14));
        lconvertido.setForeground(new java.awt.Color(0, 0, 153));
        lconvertido.setText(" ");

        tPaisCliente.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tPaisClienteKeyReleased(evt);
            }
        });

        tTelefonoCliente.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tTelefonoClienteKeyReleased(evt);
            }
        });

        cComercial.setModel(new javax.swing.DefaultComboBoxModel(new String[] {}));
        cComercial.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cComercialActionPerformed(evt);
            }
        });

        lFechaEntrega.setFont(new java.awt.Font("Tahoma", 1, 11));
        lFechaEntrega.setText("Fecha entrega");

        lPais.setFont(new java.awt.Font("Tahoma", 1, 11));
        lPais.setText("Pais");

        lLocalidad.setFont(new java.awt.Font("Tahoma", 1, 11));
        lLocalidad.setText("Localidad");

        tProvincia.setFont(new java.awt.Font("Tahoma", 1, 11));
        tProvincia.setText("Provincia");

        lCliente.setFont(new java.awt.Font("Tahoma", 1, 11));
        lCliente.setText("Cliente");

        lCpCliente.setFont(new java.awt.Font("Tahoma", 1, 11));
        lCpCliente.setText("CP");

        tCpCliente.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tCpClienteKeyReleased(evt);
            }
        });

        lEmailCliente.setFont(new java.awt.Font("Tahoma", 1, 11));
        lEmailCliente.setText("Email");

        tEmailCliente.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tEmailClienteKeyReleased(evt);
            }
        });

        tRecomendadoPor.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tRecomendadoPorKeyReleased(evt);
            }
        });

        bGuardarCliente.setText("Guardar Cliente");
        bGuardarCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bGuardarClienteActionPerformed(evt);
            }
        });

        cbPreparado.setText("Preparado");

        cbFabricado.setText("Fabricado");
        cbFabricado.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbFabricadoActionPerformed(evt);
            }
        });

        cbConfeccionado.setText("Confeccionado");
        cbConfeccionado.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbConfeccionadoActionPerformed(evt);
            }
        });

        lAlmacen.setFont(new java.awt.Font("Tahoma", 1, 11));
        lAlmacen.setText("Alm.");

        cAlmacen.setModel(new javax.swing.DefaultComboBoxModel(new String[] {}));

        bVerNotasCliente.setToolTipText("Ver notas");
        bVerNotasCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bVerNotasClienteActionPerformed(evt);
            }
        });

        cbInstalado.setText("Finalizado");

        bVerEntregas.setToolTipText("Entregas programadas");
        bVerEntregas.setActionCommand("Ver Entregas");
        bVerEntregas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bVerEntregasActionPerformed(evt);
            }
        });

        cInterlocutor.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cInterlocutorItemStateChanged(evt);
            }
        });

        lFechaEntrega1.setFont(new java.awt.Font("Tahoma", 1, 11));
        lFechaEntrega1.setText("Inter.");

        lfecha1.setFont(new java.awt.Font("Tahoma", 1, 11));
        lfecha1.setText("Interlocutor");

        lInterlocutor.setFont(new java.awt.Font("Tahoma", 1, 14));
        lInterlocutor.setText("Empresa");

        ttitulo2.setBackground(new java.awt.Color(204, 204, 255));
        ttitulo2.setFont(new java.awt.Font("Lucida Sans Unicode", 1, 14));
        ttitulo2.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        ttitulo2.setText("  Cantidad          Artículo(datos externos)                                                               Medidas                     Precio           Importe");
        ttitulo2.setOpaque(true);

        jScrollPane1.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);

        panel.setBackground(new java.awt.Color(255, 255, 255));
        panel.setAutoscrolls(true);

        org.jdesktop.layout.GroupLayout panelLayout = new org.jdesktop.layout.GroupLayout(panel);
        panel.setLayout(panelLayout);
        panelLayout.setHorizontalGroup(
            panelLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(0, 992, Short.MAX_VALUE)
        );
        panelLayout.setVerticalGroup(
            panelLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(0, 308, Short.MAX_VALUE)
        );

        jScrollPane1.setViewportView(panel);
        panel.setLayout(new GridLayout(0,1));

        org.jdesktop.layout.GroupLayout jPanel2Layout = new org.jdesktop.layout.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, jPanel2Layout.createSequentialGroup()
                .add(jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                    .add(org.jdesktop.layout.GroupLayout.LEADING, jScrollPane1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 1002, Short.MAX_VALUE)
                    .add(ttitulo2, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 1002, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel2Layout.createSequentialGroup()
                .add(ttitulo2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 18, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jScrollPane1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 281, Short.MAX_VALUE))
        );

        jScrollPane1.setLayout(new ScrollPaneLayout());

        jScrollPane1.setPreferredSize(new Dimension (100,100));
        jScrollPane1.getAccessibleContext().setAccessibleParent(jScrollPane1);

        jTabbedPane1.addTab("Líneas", jPanel2);

        lformapago.setFont(new java.awt.Font("Tahoma", 1, 11));
        lformapago.setText("Forma de pago");

        cformapago.setModel(new javax.swing.DefaultComboBoxModel(new String[] {}));
        //Creamos la lista de formas de pago
        cformapago.addItem("-- Vacío --");
        List lfp = BaseDatos.getListaFormaPago();
        FormaPago fpaux;
        for (Iterator it = lfp.iterator(); it.hasNext();) {
            fpaux = (FormaPago) it.next();
            cformapago.addItem(fpaux.getCodigo());
        }
        cformapago.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cformapagoActionPerformed(evt);
            }
        });

        tformapago.setEnabled(false);

        lformapago1.setFont(new java.awt.Font("Tahoma", 1, 11));
        lformapago1.setText("Plazos adelantados");

        modeloplazosadelantados.addColumn("Plazo");
        modeloplazosadelantados.addColumn("%");
        modeloplazosadelantados.addColumn("Importe");
        modeloplazosadelantados.addColumn("Tipo Recibo");
        modeloplazosadelantados.addColumn("Cobrado");

        tplazosadelantados.getColumnModel().getColumn(0).setPreferredWidth(50);
        tplazosadelantados.getColumnModel().getColumn(1).setPreferredWidth(50);
        tplazosadelantados.getColumnModel().getColumn(2).setPreferredWidth(80);
        tplazosadelantados.getColumnModel().getColumn(3).setPreferredWidth(200);
        tplazosadelantados.getColumnModel().getColumn(4).setPreferredWidth(80);
        tplazosadelantados.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        tplazosadelantados.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tplazosadelantadosMouseClicked(evt);
            }
        });
        tplazosadelantados.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tplazosadelantadosKeyPressed(evt);
            }
        });
        jScrollPane2.setViewportView(tplazosadelantados);

        bcrearplazo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bcrearplazoActionPerformed(evt);
            }
        });

        bmodificarplazo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bmodificarplazoActionPerformed(evt);
            }
        });

        beliminarplazo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                beliminarplazoActionPerformed(evt);
            }
        });

        modelovencimientos.addColumn("Días");
        modelovencimientos.addColumn("%");
        modelovencimientos.addColumn("Importe");
        modelovencimientos.addColumn("Tipo Recibo");
        modelovencimientos.addColumn("Fecha");

        tvencimientos.getColumnModel().getColumn(0).setPreferredWidth(50);
        tvencimientos.getColumnModel().getColumn(1).setPreferredWidth(50);
        tvencimientos.getColumnModel().getColumn(2).setPreferredWidth(80);
        tvencimientos.getColumnModel().getColumn(3).setPreferredWidth(200);
        tvencimientos.getColumnModel().getColumn(4).setPreferredWidth(50);
        tvencimientos.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        tvencimientos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tvencimientosMouseClicked(evt);
            }
        });
        tvencimientos.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tvencimientosKeyPressed(evt);
            }
        });
        jScrollPane3.setViewportView(tvencimientos);

        bCrearVencimiento.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bCrearVencimientoActionPerformed(evt);
            }
        });

        bmodificarvencimiento.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bmodificarvencimientoActionPerformed(evt);
            }
        });

        beliminarvencimiento.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                beliminarvencimientoActionPerformed(evt);
            }
        });

        lformapago2.setFont(new java.awt.Font("Tahoma", 1, 11));
        lformapago2.setText("Plazos con Vencimiento");

        org.jdesktop.layout.GroupLayout jPanel3Layout = new org.jdesktop.layout.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jPanel3Layout.createSequentialGroup()
                        .add(lformapago)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(cformapago, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 122, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(tformapago, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 180, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                    .add(jPanel3Layout.createSequentialGroup()
                        .add(jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(jPanel3Layout.createSequentialGroup()
                                .add(bcrearplazo)
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                .add(bmodificarplazo)
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                .add(beliminarplazo))
                            .add(jScrollPane2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 473, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(lformapago1))
                        .add(10, 10, 10)
                        .add(jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(jPanel3Layout.createSequentialGroup()
                                .add(bCrearVencimiento)
                                .add(11, 11, 11)
                                .add(bmodificarvencimiento)
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                .add(beliminarvencimiento))
                            .add(lformapago2)
                            .add(jScrollPane3, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 509, Short.MAX_VALUE))))
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(lformapago)
                    .add(cformapago, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(tformapago, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .add(18, 18, 18)
                .add(jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jPanel3Layout.createSequentialGroup()
                        .add(lformapago2)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jScrollPane3, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 115, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                    .add(jPanel3Layout.createSequentialGroup()
                        .add(lformapago1)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jScrollPane2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 115, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                .add(6, 6, 6)
                .add(jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING, false)
                        .add(org.jdesktop.layout.GroupLayout.LEADING, beliminarplazo, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .add(org.jdesktop.layout.GroupLayout.LEADING, bmodificarplazo, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .add(org.jdesktop.layout.GroupLayout.LEADING, bcrearplazo, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 29, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                    .add(jPanel3Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                        .add(org.jdesktop.layout.GroupLayout.TRAILING, beliminarvencimiento, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 29, Short.MAX_VALUE)
                        .add(org.jdesktop.layout.GroupLayout.TRAILING, bmodificarvencimiento, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 29, Short.MAX_VALUE)
                        .add(bCrearVencimiento, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap(86, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Formas de pago", jPanel3);

        bHayNotas.setVisible(false);
        bHayNotas.setToolTipText("Hay notas");

        bInsertarArticuloAntes.setText("AA");
        bInsertarArticuloAntes.setToolTipText("Insertar árticulo antes");
        bInsertarArticuloAntes.setMargin(new java.awt.Insets(2, 5, 2, 2));
        bInsertarArticuloAntes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bInsertarArticuloAntesActionPerformed(evt);
            }
        });

        bInsertarArticuloDespues.setText("AD");
        bInsertarArticuloDespues.setToolTipText("Insertar artículo después");
        bInsertarArticuloDespues.setMargin(new java.awt.Insets(2, 5, 2, 2));
        bInsertarArticuloDespues.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bInsertarArticuloDespuesActionPerformed(evt);
            }
        });

        bInsertarArticuloPrincipio.setText("AP");
        bInsertarArticuloPrincipio.setToolTipText("Insertar artículo al principio");
        bInsertarArticuloPrincipio.setMargin(new java.awt.Insets(2, 5, 2, 2));
        bInsertarArticuloPrincipio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bInsertarArticuloPrincipioActionPerformed(evt);
            }
        });

        bInsertarNotaDespues.setText("ND");
        bInsertarNotaDespues.setToolTipText("Insertar nota despues");
        bInsertarNotaDespues.setMargin(new java.awt.Insets(2, 5, 2, 2));
        bInsertarNotaDespues.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bInsertarNotaDespuesActionPerformed(evt);
            }
        });

        bInsertarNotaAntes.setText("NA");
        bInsertarNotaAntes.setToolTipText("Insertar nota antes");
        bInsertarNotaAntes.setMargin(new java.awt.Insets(2, 5, 2, 2));
        bInsertarNotaAntes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bInsertarNotaAntesActionPerformed(evt);
            }
        });

        bInsertarArticuloFinal.setText("AF");
        bInsertarArticuloFinal.setToolTipText("Insertar artículo al final");
        bInsertarArticuloFinal.setMargin(new java.awt.Insets(2, 5, 2, 2));
        bInsertarArticuloFinal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bInsertarArticuloFinalActionPerformed(evt);
            }
        });

        bInsertarNotaPrincipio.setText("NP");
        bInsertarNotaPrincipio.setToolTipText("Insertar nota al principio");
        bInsertarNotaPrincipio.setMargin(new java.awt.Insets(2, 5, 2, 2));
        bInsertarNotaPrincipio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bInsertarNotaPrincipioActionPerformed(evt);
            }
        });

        bInsertarNotaFinal.setText("NF");
        bInsertarNotaFinal.setToolTipText("Insertar nota al final");
        bInsertarNotaFinal.setMargin(new java.awt.Insets(2, 5, 2, 2));
        bInsertarNotaFinal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bInsertarNotaFinalActionPerformed(evt);
            }
        });

        bMovimientoAlmacen.setText("MA");
        bMovimientoAlmacen.setToolTipText("Ver Movimientos Generados");
        bMovimientoAlmacen.setEnabled(false);
        bMovimientoAlmacen.setMargin(new java.awt.Insets(2, 5, 2, 2));
        bMovimientoAlmacen.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bMovimientoAlmacenActionPerformed(evt);
            }
        });

        bHayMontaje.setVisible(false);
        bHayMontaje.setToolTipText("Montaje");
        bHayMontaje.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bHayMontajeActionPerformed(evt);
            }
        });

        lbTercero.setFont(new java.awt.Font("Tahoma", 1, 12));
        lbTercero.setText("Nombre de cliente (Código)");

        org.jdesktop.layout.GroupLayout jPanel1Layout = new org.jdesktop.layout.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jScrollPane4, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 982, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                        .add(jPanel1Layout.createSequentialGroup()
                            .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                                .add(lconvertido, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 415, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                .add(jPanel1Layout.createSequentialGroup()
                                    .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                                        .add(jPanel1Layout.createSequentialGroup()
                                            .add(lfecha1)
                                            .add(6, 6, 6))
                                        .add(jPanel1Layout.createSequentialGroup()
                                            .add(cbPreparado)
                                            .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)))
                                    .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                                        .add(jPanel1Layout.createSequentialGroup()
                                            .add(cbConfeccionado)
                                            .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                            .add(cbFabricado)
                                            .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                            .add(cbInstalado))
                                        .add(lInterlocutor, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 372, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                                .add(jPanel1Layout.createSequentialGroup()
                                    .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING, false)
                                        .add(org.jdesktop.layout.GroupLayout.LEADING, jPanel1Layout.createSequentialGroup()
                                            .add(lReferencia)
                                            .add(10, 10, 10)
                                            .add(tReferencia))
                                        .add(org.jdesktop.layout.GroupLayout.LEADING, jPanel1Layout.createSequentialGroup()
                                            .add(lestado)
                                            .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                            .add(cestado, 0, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                        .add(org.jdesktop.layout.GroupLayout.LEADING, jPanel1Layout.createSequentialGroup()
                                            .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                                                .add(jPanel1Layout.createSequentialGroup()
                                                    .add(lnumero)
                                                    .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED))
                                                .add(jPanel1Layout.createSequentialGroup()
                                                    .add(lfecha)
                                                    .add(15, 15, 15)))
                                            .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                                                .add(tnumero)
                                                .add(tfecha, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 71, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                                            .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                            .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                                                .add(bAnadirNotas, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .add(cSeries, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 111, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))))
                                    .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                                        .add(jPanel1Layout.createSequentialGroup()
                                            .add(bVerNotas)
                                            .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                            .add(bHayNotas, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 22, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                            .add(4, 4, 4)
                                            .add(bHayMontaje, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 22, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                                        .add(jPanel1Layout.createSequentialGroup()
                                            .add(10, 10, 10)
                                            .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                                                .add(jPanel1Layout.createSequentialGroup()
                                                    .add(lFechaEntrega)
                                                    .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                                    .add(cFechaEntrega, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                                    .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                                    .add(bVerEntregas, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 23, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                                                .add(jPanel1Layout.createSequentialGroup()
                                                    .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                                                        .add(lAlmacen)
                                                        .add(lFechaEntrega1))
                                                    .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                                    .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                                                        .add(cInterlocutor, 0, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                        .add(cAlmacen, 0, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))))))
                            .add(18, 18, 18)
                            .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                                .add(jPanel1Layout.createSequentialGroup()
                                    .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                                        .add(ldomicilio)
                                        .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                                            .add(lCliente)
                                            .add(lnombre, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 52, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                                    .add(13, 13, 13))
                                .add(jPanel1Layout.createSequentialGroup()
                                    .add(lLocalidad)
                                    .add(14, 14, 14))
                                .add(jPanel1Layout.createSequentialGroup()
                                    .add(lEmailCliente)
                                    .add(35, 35, 35))
                                .add(lcontactado))
                            .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                            .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING, false)
                                .add(bGuardarCliente)
                                .add(jPanel1Layout.createSequentialGroup()
                                    .add(cContactado, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 169, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                    .add(cComercial, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 148, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                    .add(tRecomendadoPor))
                                .add(jPanel1Layout.createSequentialGroup()
                                    .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING)
                                        .add(org.jdesktop.layout.GroupLayout.LEADING, tEmailCliente)
                                        .add(jPanel1Layout.createSequentialGroup()
                                            .add(tLocalidadCliente)
                                            .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                            .add(tProvincia)
                                            .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                            .add(tProvinciaCliente, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 99, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                                        .add(org.jdesktop.layout.GroupLayout.LEADING, tNombreCliente)
                                        .add(org.jdesktop.layout.GroupLayout.LEADING, jPanel1Layout.createSequentialGroup()
                                            .add(tCodCliente, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 186, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                            .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                            .add(binsertarCliente, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 19, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                            .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                            .add(bVerNotasCliente, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 28, Short.MAX_VALUE))
                                        .add(org.jdesktop.layout.GroupLayout.LEADING, tDireccionCliente)
                                        .add(lbTercero, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                    .add(29, 29, 29)
                                    .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                                        .add(lCpCliente)
                                        .add(ltelefono, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 58, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                        .add(lPais)
                                        .add(ldni))
                                    .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                    .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                                        .add(tDniCliente)
                                        .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.TRAILING, false)
                                            .add(tTelefonoCliente)
                                            .add(org.jdesktop.layout.GroupLayout.LEADING, tPaisCliente)
                                            .add(tCpCliente, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 135, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))))))
                        .add(jLabel1)
                        .add(jPanel1Layout.createSequentialGroup()
                            .add(ltotalbruto)
                            .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                            .add(lPrecioTotalBruto, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 71, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                            .add(tdto, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 34, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                            .add(ldto)
                            .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                            .add(limporte_dto, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 60, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                            .add(lSubTotal, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 60, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                            .add(lprecio, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 87, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                            .add(tIva, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 37, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                            .add(lIva)
                            .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                            .add(limporte_iva, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 73, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(68, 68, 68)
                            .add(lTotal)
                            .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                            .add(lprecio_final, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 89, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                        .add(lObservaciones)
                        .add(jTabbedPane1))
                    .add(jPanel1Layout.createSequentialGroup()
                        .add(bImprimir, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 29, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(bCrearPdf, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 33, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(bMandarMail, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 29, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(bInsertarArticuloAntes)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(bInsertarArticuloDespues)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(bInsertarArticuloPrincipio)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(bInsertarArticuloFinal)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(bInsertarNotaAntes)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(bInsertarNotaDespues)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(bInsertarNotaPrincipio)
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(bInsertarNotaFinal)
                        .add(33, 33, 33)
                        .add(bMovimientoAlmacen)))
                .addContainerGap(26, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(jPanel1Layout.createSequentialGroup()
                .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                        .add(bInsertarArticuloDespues, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 23, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(bInsertarArticuloAntes))
                    .add(bInsertarArticuloPrincipio)
                    .add(bInsertarArticuloFinal)
                    .add(bInsertarNotaAntes)
                    .add(bInsertarNotaDespues)
                    .add(bInsertarNotaPrincipio)
                    .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                        .add(bInsertarNotaFinal)
                        .add(bMovimientoAlmacen))
                    .add(bImprimir, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 23, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(bCrearPdf, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 23, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(bMandarMail, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 23, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(lbTercero)
                .add(7, 7, 7)
                .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jPanel1Layout.createSequentialGroup()
                        .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(bVerEntregas, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(jPanel1Layout.createSequentialGroup()
                                .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                                    .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                                        .add(lfecha)
                                        .add(tfecha, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                        .add(cSeries, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                        .add(lFechaEntrega))
                                    .add(cFechaEntrega, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                                .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                                    .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                                        .add(lnumero)
                                        .add(tnumero, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                        .add(bAnadirNotas)
                                        .add(bVerNotas))
                                    .add(bHayNotas, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                    .add(bHayMontaje, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(lestado)
                            .add(cestado, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(lAlmacen)
                            .add(cAlmacen, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                        .add(7, 7, 7)
                        .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                            .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                                .add(lReferencia)
                                .add(tReferencia, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                                .add(lFechaEntrega1))
                            .add(jPanel1Layout.createSequentialGroup()
                                .add(3, 3, 3)
                                .add(cInterlocutor, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 20, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(lfecha1)
                            .add(lInterlocutor, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 18, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(cbPreparado, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 23, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(cbConfeccionado)
                            .add(cbFabricado)
                            .add(cbInstalado))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(lconvertido))
                    .add(jPanel1Layout.createSequentialGroup()
                        .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(ldni)
                            .add(lCliente)
                            .add(bVerNotasCliente, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 23, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(binsertarCliente)
                            .add(tCodCliente, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(tDniCliente, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(tNombreCliente, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(ltelefono)
                            .add(lnombre)
                            .add(tTelefonoCliente, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(lCpCliente)
                            .add(tDireccionCliente, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(ldomicilio)
                            .add(tCpCliente, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(tProvincia)
                            .add(tProvinciaCliente, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(lPais)
                            .add(tLocalidadCliente, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(lLocalidad)
                            .add(tPaisCliente, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 19, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(tEmailCliente, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(lEmailCliente))
                        .add(11, 11, 11)
                        .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                            .add(cComercial, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(cContactado, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                            .add(lcontactado)
                            .add(tRecomendadoPor, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 19, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                        .add(bGuardarCliente)))
                .add(17, 17, 17)
                .add(jTabbedPane1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 333, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
                    .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                        .add(ltotalbruto)
                        .add(lPrecioTotalBruto))
                    .add(jPanel1Layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                        .add(ldto)
                        .add(limporte_dto)
                        .add(lSubTotal)
                        .add(tdto, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(lprecio)
                        .add(tIva, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                        .add(lIva)
                        .add(limporte_iva)
                        .add(lTotal)
                        .add(lprecio_final))
                    .add(jLabel1))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                .add(lObservaciones)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jScrollPane4, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 22, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        //if(this.p.getClase_documento().getDescripcion().equals("Presupuesto"))
        if(this.cd.getDescripcion().equals("Presupuesto")){
            List lestadod = BaseDatos.getListaEstadoDocumento("PS");
            EstadoDocumento ed;
            for (Iterator it = lestadod.iterator(); it.hasNext();) {
                ed = (EstadoDocumento) it.next();
                cestado.addItem(ed.getDescripcion());
            }
        } else if(this.cd.getDescripcion().equals("Factura")){
            List lestadod = BaseDatos.getListaEstadoDocumento("FC");
            EstadoDocumento ed;
            for (Iterator it = lestadod.iterator(); it.hasNext();) {
                ed = (EstadoDocumento) it.next();
                cestado.addItem(ed.getDescripcion());
            }
        } else if (this.cd.getDescripcion().equals("Pedido")){
            List lestadod = BaseDatos.getListaEstadoDocumento("PD");
            EstadoDocumento ed;
            for (Iterator it = lestadod.iterator(); it.hasNext();) {
                ed = (EstadoDocumento) it.next();
                cestado.addItem(ed.getDescripcion());
            }
        } else if (this.cd.getDescripcion().equals("Albarán")){

            List lestadod = BaseDatos.getListaEstadoDocumento("AL");
            EstadoDocumento ed;
            for (Iterator it = lestadod.iterator(); it.hasNext();) {
                ed = (EstadoDocumento) it.next();
                cestado.addItem(ed.getDescripcion());
            }
        } else if ((cd.getDescripcion().equals(Constantes.PEDIDOC)) ||
            (cd.getDescripcion().equals(Constantes.ALBARANC)) ||
            (cd.getDescripcion().equals(Constantes.FACTURAC))){

            List lestadod = BaseDatos.getListaEstadoDocumento("PC");
            EstadoDocumento ed;
            for (Iterator it = lestadod.iterator(); it.hasNext();) {
                ed = (EstadoDocumento) it.next();
                cestado.addItem(ed.getDescripcion());
            }
        }
        List lComerciales = BaseDatos.getListaComerciales();
        Comercial comercial;
        cComercial.addItem(Constantes.SELECCIONE_COMERCIAL);
        for (Iterator it = lComerciales.iterator(); it.hasNext();) {
            comercial = (Comercial) it.next();
            cComercial.addItem(comercial.getNombre());
        }
        List la = BaseDatos.getListaAlmacenes();
        Almacen am;
        for (Iterator it = la.iterator(); it.hasNext();) {
            am = (Almacen) it.next();
            cAlmacen.addItem(am.getNombre());
        }
        bVerEntregas.getAccessibleContext().setAccessibleName("Ver Entregas");
        List li = BaseDatos.getListaInterlocutores(e);
        Interlocutor in;
        Empresa ei;
        //Añadimos la empresa actual(madre) como primer interlocutor
        cInterlocutor.addItem(e.getCod_empresa());
        for (Iterator it = li.iterator(); it.hasNext();) {
            in = (Interlocutor) it.next();
            ei = BaseDatos.obtenerEmpresaPorIid(in.getEmpresaHija().getIid());
            cInterlocutor.addItem(ei.getCod_empresa());
        }

        jScrollPane14.setViewportView(jPanel1);

        baceptar.setText("Aceptar");
        baceptar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                baceptarActionPerformed(evt);
            }
        });

        bguardar.setText("Guardar");
        bguardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bguardarActionPerformed(evt);
            }
        });

        bmodificar.setText("Modificar");
        bmodificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bmodificarActionPerformed(evt);
            }
        });

        bcancelar.setText("Cancelar");
        bcancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bcancelarActionPerformed(evt);
            }
        });

        jMenuOpciones69.setText("Opciones");

        jMenuAlbaran.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F8, 0));
        jMenuAlbaran.setText("Convertir");
        jMenuAlbaran.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuAlbaranActionPerformed(evt);
            }
        });
        jMenuOpciones69.add(jMenuAlbaran);

        jMenuPDF.setText("Crear PDF");
        jMenuPDF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuPDFActionPerformed(evt);
            }
        });
        jMenuOpciones69.add(jMenuPDF);

        jMenuPagado.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F9, 0));
        jMenuPagado.setText("Establecer Pagado");
        jMenuPagado.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuPagadoActionPerformed(evt);
            }
        });
        jMenuOpciones69.add(jMenuPagado);

        jMenuImpagado.setText("Establecer como impagado");
        jMenuImpagado.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuImpagadoActionPerformed(evt);
            }
        });
        jMenuOpciones69.add(jMenuImpagado);

        jMenuImprimirRecibos.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F7, 0));
        jMenuImprimirRecibos.setText("Imprimir recibos");
        jMenuImprimirRecibos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuImprimirRecibosActionPerformed(evt);
            }
        });
        jMenuOpciones69.add(jMenuImprimirRecibos);
        jMenuOpciones69.add(jSeparator3);

        jMenuItemHojaMontaje.setText("Hoja Montaje");
        jMenuItemHojaMontaje.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItemHojaMontajeActionPerformed(evt);
            }
        });
        jMenuOpciones69.add(jMenuItemHojaMontaje);

        jMenuItemCorteLona.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F1, 0));
        jMenuItemCorteLona.setText("Corte de lona");
        jMenuItemCorteLona.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItemCorteLonaActionPerformed(evt);
            }
        });
        jMenuOpciones69.add(jMenuItemCorteLona);

        jMenuItemVerCorteLona.setText("Ver corte de lona");
        jMenuItemVerCorteLona.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItemVerCorteLonaActionPerformed(evt);
            }
        });
        jMenuOpciones69.add(jMenuItemVerCorteLona);

        jMenuItemCortePerfil.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F2, 0));
        jMenuItemCortePerfil.setText("Corte de perfil");
        jMenuItemCortePerfil.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItemCortePerfilActionPerformed(evt);
            }
        });
        jMenuOpciones69.add(jMenuItemCortePerfil);

        jMenuItemMontaje.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_M, java.awt.event.InputEvent.CTRL_MASK));
        jMenuItemMontaje.setText("Generar Orden de Montaje");
        jMenuItemMontaje.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItemMontajeActionPerformed(evt);
            }
        });
        jMenuOpciones69.add(jMenuItemMontaje);

        jMenuItemDescuentoUnidades.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F3, 0));
        jMenuItemDescuentoUnidades.setText("Descuento de unidades");
        jMenuItemDescuentoUnidades.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItemDescuentoUnidadesActionPerformed(evt);
            }
        });
        jMenuOpciones69.add(jMenuItemDescuentoUnidades);
        jMenuOpciones69.add(jSeparator1);

        jMenuItemNotaPrincipio.setText("Añadir nota informativa al principio");
        jMenuItemNotaPrincipio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItemNotaPrincipioActionPerformed(evt);
            }
        });
        jMenuOpciones69.add(jMenuItemNotaPrincipio);

        jMenuItemNotaFinal.setText("Añadir nota informativa al final");
        jMenuItemNotaFinal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItemNotaFinalActionPerformed(evt);
            }
        });
        jMenuOpciones69.add(jMenuItemNotaFinal);

        jMenuItemNotaAntes.setText("Añadir nota informativa antes de");
        jMenuItemNotaAntes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItemNotaAntesActionPerformed(evt);
            }
        });
        jMenuOpciones69.add(jMenuItemNotaAntes);

        jMenuItemNotaDespues.setText("Añadir nota informativa despues de");
        jMenuItemNotaDespues.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItemNotaDespuesActionPerformed(evt);
            }
        });
        jMenuOpciones69.add(jMenuItemNotaDespues);
        jMenuOpciones69.add(jSeparator2);

        jMenuItemLineaPrincipio.setText("Añadir línea al principio");
        jMenuItemLineaPrincipio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItemLineaPrincipioActionPerformed(evt);
            }
        });
        jMenuOpciones69.add(jMenuItemLineaPrincipio);

        jMenuItemLineaFinal.setText("Añadir línea al final");
        jMenuItemLineaFinal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItemLineaFinalActionPerformed(evt);
            }
        });
        jMenuOpciones69.add(jMenuItemLineaFinal);

        jMenuItemLineaAntes.setText("Añadir línea antes de");
        jMenuItemLineaAntes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItemLineaAntesActionPerformed(evt);
            }
        });
        jMenuOpciones69.add(jMenuItemLineaAntes);

        jMenuItemLineaDespues.setText("Añadir línea despues de");
        jMenuItemLineaDespues.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItemLineaDespuesActionPerformed(evt);
            }
        });
        jMenuOpciones69.add(jMenuItemLineaDespues);

        jMenuBar70.add(jMenuOpciones69);

        setJMenuBar(jMenuBar70);

        org.jdesktop.layout.GroupLayout layout = new org.jdesktop.layout.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(layout.createSequentialGroup()
                .addContainerGap()
                .add(baceptar)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(bguardar)
                .add(10, 10, 10)
                .add(bmodificar, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 103, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(bcancelar))
            .add(jScrollPane14, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 1053, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, layout.createSequentialGroup()
                .add(jScrollPane14, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 689, Short.MAX_VALUE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(bcancelar)
                    .add(bmodificar)
                    .add(bguardar)
                    .add(baceptar))
                .add(22, 22, 22))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void visualizarPlazoAdelantado() {
        int indice = tplazosadelantados.getSelectedRow();
        if (indice >= 0) {
            String cobrado = (String) tplazosadelantados.getValueAt(indice, 4);
            String porcentaje = String.valueOf(tplazosadelantados.getValueAt(indice, 1));
            String tipoRecibo = (String) tplazosadelantados.getValueAt(indice, 3);
            String nombre = (String) tplazosadelantados.getValueAt(indice, 0);
            String simporte = String.valueOf(tplazosadelantados.getValueAt(indice, 2));
            double importe = Double.parseDouble(Util.convertirComaAPunto(simporte));
            String emitido;
            String recibo;
            String imputado;
            Long fecha;

            if (indice == 0) {
                emitido = fp2.getEmitido1();
                recibo = fp2.getRecibo1();
                imputado = fp2.getImputado1();
                fecha = fp2.getFechaPlazo1();
            } else if (indice == 1) {
                emitido = fp2.getEmitido2();
                recibo = fp2.getRecibo2();
                imputado = fp2.getImputado2();
                fecha = fp2.getFechaPlazo2();
            } else if (indice == 2) {
                emitido = fp2.getEmitido3();
                recibo = fp2.getRecibo3();
                imputado = fp2.getImputado3();
                fecha = fp2.getFechaPlazo3();
            } else if (indice == 3) {
                emitido = fp2.getEmitido4();
                recibo = fp2.getRecibo4();
                imputado = fp2.getImputado4();
                fecha = fp2.getFechaPlazo4();
            } else if (indice == 4) {
                emitido = fp2.getEmitido5();
                recibo = fp2.getRecibo5();
                imputado = fp2.getImputado5();
                fecha = fp2.getFechaPlazo5();
            } else if (indice == 5) {
                emitido = fp2.getEmitido6();
                recibo = fp2.getRecibo6();
                imputado = fp2.getImputado6();
                fecha = fp2.getFechaPlazo6();
            } else if (indice == 6) {
                emitido = fp2.getEmitido7();
                recibo = fp2.getRecibo7();
                imputado = fp2.getImputado7();
                fecha = fp2.getFechaPlazo7();
            } else if (indice == 7) {
                emitido = fp2.getEmitido8();
                recibo = fp2.getRecibo8();
                imputado = fp2.getImputado8();
                fecha = fp2.getFechaPlazo8();
            } else if (indice == 8) {
                emitido = fp2.getEmitido9();
                recibo = fp2.getRecibo9();
                imputado = fp2.getImputado9();
                fecha = fp2.getFechaPlazo9();
            } else {
                emitido = fp2.getEmitido10();
                recibo = fp2.getRecibo10();
                imputado = fp2.getImputado10();
                fecha = fp2.getFechaPlazo10();
            }

            if (fecha == null) {
                fecha = getFechaLong();
            }

            Plazo pl = new Plazo(indice, porcentaje, cobrado, tipoRecibo, nombre, importe_total, importe, fp2, imputado, recibo, emitido, this, fecha);
            pl.setDefaultCloseOperation(Plazo.DISPOSE_ON_CLOSE);
            pl.setLocationRelativeTo(null);
            pl.setVisible(true);
        }
    }

    private void habilitarControles(boolean enabled) {
        this.bcrearplazo.setEnabled(enabled);
        this.beliminarplazo.setEnabled(enabled);
        this.beliminarvencimiento.setEnabled(enabled);
        this.bmodificarplazo.setEnabled(enabled);
        this.bmodificarvencimiento.setEnabled(enabled);
        this.cformapago.setEnabled(enabled);
        this.tObservaciones.setEnabled(enabled);
        this.tplazosadelantados.setEnabled(enabled);
        this.tvencimientos.setEnabled(enabled);
        this.tdto.setEnabled(enabled);
        this.tIva.setEnabled(enabled);
        this.cFechaEntrega.setEnabled(enabled);
        this.tReferencia.setEnabled(enabled);
        this.cestado.setEnabled(enabled);
        this.cSeries.setEnabled(enabled);
        this.tCodCliente.setEnabled(enabled);
        this.binsertarCliente.setEnabled(enabled);
        this.tNombreCliente.setEnabled(enabled);
        this.tDireccionCliente.setEnabled(enabled);
        this.tLocalidadCliente.setEnabled(enabled);
        this.tProvinciaCliente.setEnabled(enabled);
        this.tEmailCliente.setEnabled(enabled);
        this.cContactado.setEnabled(enabled);
        this.cComercial.setEnabled(enabled);
        this.tRecomendadoPor.setEnabled(enabled);
        this.tDniCliente.setEnabled(enabled);
        this.tTelefonoCliente.setEnabled(enabled);
        this.tCpCliente.setEnabled(enabled);
        this.tPaisCliente.setEnabled(enabled);
        this.binsertarCliente.setEnabled(enabled);
        this.bGuardarCliente.setEnabled(enabled);
        this.panel.setEnabled(enabled);
        this.bCrearVencimiento.setEnabled(enabled);
        this.beliminarvencimiento.setEnabled(enabled);
        this.bmodificarvencimiento.setEnabled(enabled);
        this.cInterlocutor.setEnabled(enabled);

        Component[] lista = panel.getComponents();
        NuevaLineaPresupuesto np;
        Component temp;
        int indice = 0;
        int maxIndice = lista.length;
        while (indice < maxIndice) {
            temp = (Component) lista[indice];
            if (temp instanceof NuevaLineaPresupuesto) {
                np = (NuevaLineaPresupuesto) temp;
                np.habilitarElementos(enabled);
            }
            indice++;
        }
    }

    private void teclaF9() {
        boolean enabled = true;
        if (bmodificar.getText().equals("Modificar")) {
            //Si el botón tiene el texto Modificar
            URL urlModificar = getClass().getResource("/iconos/buscar.gif");
            ImageIcon iconoModificar = new ImageIcon(urlModificar);
            bmodificar.setIcon(iconoModificar);
            bmodificar.setText("Visualizar");
            bmodificar.setToolTipText("Visualizar campos");
            enabled = true;
        } else {
            enabled = false;
            URL urlModificar = getClass().getResource("/iconos/editar.png");
            ImageIcon iconoModificar = new ImageIcon(urlModificar);
            bmodificar.setIcon(iconoModificar);
            //si el botón tiene el texto Visualizar
            bmodificar.setText("Modificar");
            bmodificar.setToolTipText("Modificar campos");
        }

        habilitarControles(enabled);
    }

    private void cerrarPresupuesto() {
        if (this.ldp != null) {
            ldp.obtenerResultado();
        }
        removeAll();
        dispose();
    }

    private void audi(Presupuesto p, String accion, Empresa e, Usuario u) {
        /* Auditoria au = new Auditoria();
        Calendar calendario = Calendar.getInstance();
        int hora, minutos;
        hora = calendario.get(Calendar.HOUR_OF_DAY);
        minutos = calendario.get(Calendar.MINUTE);
        
        au.setfecha(p.getFecha());
        au.sethora(hora + ":" + minutos);
        au.setcodigo_objeto(p.getNumero());
        au.setaccion(accion);
        au.setusuario(u.getNombre());
        au.setempresa(e.getDesc_empresa());
        BaseDatos.insertarElemento(au);*/
    }

    private boolean actualizarPresupuesto() {
        //Almacenamos los checks marcados para mandar los mensajes internos
        if (p.getPreparado() != null) {
            preparadoAntiguo = p.getPreparado();
        } else {
            preparadoAntiguo = false;
        }
        if (p.getFabricado() != null) {
            fabricadoAntiguo = p.getFabricado();
        } else {
            fabricadoAntiguo = false;
        }
        if (p.getConfeccionado() != null) {
            confeccionadoAntiguo = p.getConfeccionado();
        } else {
            confeccionadoAntiguo = false;
        }
        if (p.getInstalado() != null) {
            finalizadoAntiguo = p.getInstalado();
        } else {
            finalizadoAntiguo = false;
        }

        boolean hayLineasErroneas = false;
        Iterator<NuevaLineaPresupuesto> iter = this.listaArticulos.iterator();
        boolean seguir = true;
        while (iter.hasNext() && seguir) {
            seguir = iter.next().esLineaCorrecta();
        }

        if (!seguir) {
            hayLineasErroneas = true;
        }

        EstadoDocumento ed = BaseDatos.obtenerEstadoDocumentoPorDesc((String) cestado.getSelectedItem());
        String serie = (String) cSeries.getSelectedItem();
        String ivaDto = this.tIva.getText();
        String dto1 = tdto.getText();
        String observaciones = tObservaciones.getText();
        String contacto = (String) cContactado.getSelectedItem();
        String com = (String) cComercial.getSelectedItem();
        
        if (observaciones != null) {
            if (observaciones.length() >= Constantes.TAM_OBSERVACIONES_PRESUPUESTO) {
                observaciones = observaciones.substring(0, Constantes.TAM_OBSERVACIONES_PRESUPUESTO);
            }
        }
        
        boolean mensajeError = false;
        boolean mensajeFechaEntrega = false;
        boolean mensajeComercial = false;
        boolean mensajeAlmacen = false;

        if (hayLineasErroneas) {
            mensajeError = true;
        }

        if (this.getTipoDocumento().equals(Constantes.PEDIDO) && this.cFechaEntrega.getDate() == null) {
            mensajeError = true;
            mensajeFechaEntrega = true;
        }

        if (fp2 == null) {
            mensajeError = true;
        }

        if (cAlmacen.getItemCount() <= 0) {
            mensajeError = true;
            mensajeAlmacen = true;
        }

        if (contacto.equals(Constantes.COMERCIALES) && com.equals(Constantes.SELECCIONE_COMERCIAL)) {
            mensajeError = true;
            mensajeComercial = true;
        }

        if (mensajeError) {
            String mensajeErr = "";
            if (mensajeComercial && mensajeFechaEntrega) {
                mensajeErr = "Debe seleccionar la fecha de entrega, la forma de pago y el comercial.";
            } else if (mensajeComercial) {
                mensajeErr = "Debe seleccionar la forma de pago y el comercial.";
            } else if (mensajeFechaEntrega) {
                mensajeErr = "Debe seleccionar la fecha de entrega y la forma de pago.";
            } else {
                mensajeErr = "Debe seleccionar la forma de pago.";
            }

            if (mensajeAlmacen) {
                mensajeErr += " No hay seleccionado ningún almacén.";
            }

            if (hayLineasErroneas) {
                mensajeErr += " Hay Líneas Erroneas en el documento.";
            }

            JOptionPane.showMessageDialog(null, mensajeErr, "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            p.setClase_documento(cd);
            p.setFecha(this.fechaD.getTime());
            p.setEstado(ed);
            p.setSerie(serie);
            p.setDto(Double.valueOf(Util.convertirComaAPunto(dto1)));
            p.setImporte_total(precio_final);
            p.setEmpresa(e);
            
            p.setConvertido(false);
            //p.setIva(iva);
            p.setIvaDocumento(ivaDto.length() == 0 ? 0F : Float.parseFloat(Util.convertirComaAPunto(ivaDto)));
            p.setReferencia(tReferencia.getText());
            p.setCifCliente(tDniCliente.getText());
            p.setCodigoCliente(tCodCliente.getText());
            p.setDomicilioCliente(tDireccionCliente.getText());
            p.setLocalidadCliente(tLocalidadCliente.getText());
            p.setNombreCliente(tNombreCliente.getText());
            p.setPaisCliente(tPaisCliente.getText());
            p.setProvinciaCliente(tProvinciaCliente.getText());
            p.setTelefonoCliente(tTelefonoCliente.getText());
            p.setCpCliente(tCpCliente.getText());
            p.setPagado(pagado);
            p.setImpagado(impagado);
            p.setContactado((String) cContactado.getSelectedItem());
            p.setComercial(comercial);
            p.setObservaciones(observaciones);
            p.setFabricado(cbFabricado.isSelected());
            p.setConfeccionado(cbConfeccionado.isSelected());
            p.setPreparado(cbPreparado.isSelected());
            p.setInstalado(cbInstalado.isSelected());
            p.setEmailCliente(tEmailCliente.getText());
            p.setRecomendadoPor(tRecomendadoPor.getText());
            p.setAlmacen(BaseDatos.obtenerAlmacen((String) cAlmacen.getSelectedItem()));
            p.setInterlocutor(BaseDatos.obtenerEmpresa((String) cInterlocutor.getSelectedItem()).getIid());
            p.setPorcentajeComercial((comercial != null) ? comercial.getPorcentaje() : 0F);
            
            Date fd = cFechaEntrega.getDate();
            if (fd != null) {
                p.setFechaEntrega(fd.getTime());
            }
        }

        return !mensajeError;
    }

    private void borrarPlazoAdelantado() {
        int plazo = tplazosadelantados.getSelectedRow() + 1;
        Double porcentajeNegativo = null;
        if (plazo > 0) {
            if (plazo == 1) {
                porcentajeNegativo = fp2.getPorcentajepago1() * -1;
                //REORGANIZACION
                fp2.setNombreplazo1(fp2.getNombreplazo2());
                fp2.setPorcentajepago1(fp2.getPorcentajepago2());
                fp2.setIid_tr_p1(fp2.getIid_tr_p2());
                fp2.setCobrado1(fp2.getCobrado2());
                fp2.setImportep1(fp2.getImportep2());
                fp2.setFechap1(fp2.getFechap2());
                fp2.setEmitido1(fp2.getEmitido2());
                fp2.setRecibo1(fp2.getRecibo2());

                fp2.setNombreplazo2(fp2.getNombreplazo3());
                fp2.setPorcentajepago2(fp2.getPorcentajepago3());
                fp2.setIid_tr_p2(fp2.getIid_tr_p3());
                fp2.setCobrado2(fp2.getCobrado3());
                fp2.setImportep2(fp2.getImportep3());
                fp2.setFechap2(fp2.getFechap3());
                fp2.setEmitido2(fp2.getEmitido3());
                fp2.setRecibo2(fp2.getRecibo3());

                fp2.setNombreplazo3(fp2.getNombreplazo3());
                fp2.setPorcentajepago3(fp2.getPorcentajepago3());
                fp2.setIid_tr_p3(fp2.getIid_tr_p3());
                fp2.setCobrado3(fp2.getCobrado3());
                fp2.setImportep3(fp2.getImportep3());
                fp2.setFechap3(fp2.getFechap3());
                fp2.setEmitido3(fp2.getEmitido3());
                fp2.setRecibo3(fp2.getRecibo3());

                fp2.setNombreplazo4(fp2.getNombreplazo5());
                fp2.setPorcentajepago4(fp2.getPorcentajepago5());
                fp2.setIid_tr_p4(fp2.getIid_tr_p5());
                fp2.setCobrado4(fp2.getCobrado5());
                fp2.setImportep4(fp2.getImportep5());
                fp2.setFechap4(fp2.getFechap5());
                fp2.setEmitido4(fp2.getEmitido5());
                fp2.setRecibo4(fp2.getRecibo5());

                fp2.setNombreplazo5(fp2.getNombreplazo6());
                fp2.setPorcentajepago5(fp2.getPorcentajepago6());
                fp2.setIid_tr_p5(fp2.getIid_tr_p6());
                fp2.setCobrado5(fp2.getCobrado6());
                fp2.setImportep5(fp2.getImportep6());
                fp2.setFechap5(fp2.getFechap6());
                fp2.setEmitido5(fp2.getEmitido6());
                fp2.setRecibo5(fp2.getRecibo6());

                fp2.setNombreplazo6(fp2.getNombreplazo7());
                fp2.setPorcentajepago6(fp2.getPorcentajepago7());
                fp2.setIid_tr_p6(fp2.getIid_tr_p7());
                fp2.setCobrado6(fp2.getCobrado7());
                fp2.setImportep6(fp2.getImportep7());
                fp2.setFechap6(fp2.getFechap7());
                fp2.setEmitido6(fp2.getEmitido7());
                fp2.setRecibo6(fp2.getRecibo7());

                fp2.setNombreplazo7(fp2.getNombreplazo8());
                fp2.setPorcentajepago7(fp2.getPorcentajepago8());
                fp2.setIid_tr_p7(fp2.getIid_tr_p8());
                fp2.setCobrado7(fp2.getCobrado8());
                fp2.setImportep7(fp2.getImportep8());
                fp2.setFechap7(fp2.getFechap8());
                fp2.setEmitido7(fp2.getEmitido8());
                fp2.setRecibo7(fp2.getRecibo8());

                fp2.setNombreplazo8(fp2.getNombreplazo9());
                fp2.setPorcentajepago8(fp2.getPorcentajepago9());
                fp2.setIid_tr_p8(fp2.getIid_tr_p9());
                fp2.setCobrado8(fp2.getCobrado9());
                fp2.setImportep8(fp2.getImportep9());
                fp2.setFechap8(fp2.getFechap9());
                fp2.setEmitido8(fp2.getEmitido9());
                fp2.setRecibo8(fp2.getRecibo9());
            } else if (plazo == 2) {
                porcentajeNegativo = fp2.getPorcentajepago2() * -1;
                //REORGANIZACION
                fp2.setNombreplazo2(fp2.getNombreplazo3());
                fp2.setPorcentajepago2(fp2.getPorcentajepago3());
                fp2.setIid_tr_p2(fp2.getIid_tr_p3());
                fp2.setCobrado2(fp2.getCobrado3());
                fp2.setImportep2(fp2.getImportep3());
                fp2.setFechap2(fp2.getFechap3());
                fp2.setEmitido2(fp2.getEmitido3());
                fp2.setRecibo2(fp2.getRecibo3());

                fp2.setNombreplazo3(fp2.getNombreplazo3());
                fp2.setPorcentajepago3(fp2.getPorcentajepago3());
                fp2.setIid_tr_p3(fp2.getIid_tr_p3());
                fp2.setCobrado3(fp2.getCobrado3());
                fp2.setImportep3(fp2.getImportep3());
                fp2.setFechap3(fp2.getFechap3());
                fp2.setEmitido3(fp2.getEmitido3());
                fp2.setRecibo3(fp2.getRecibo3());

                fp2.setNombreplazo4(fp2.getNombreplazo5());
                fp2.setPorcentajepago4(fp2.getPorcentajepago5());
                fp2.setIid_tr_p4(fp2.getIid_tr_p5());
                fp2.setCobrado4(fp2.getCobrado5());
                fp2.setImportep4(fp2.getImportep5());
                fp2.setFechap4(fp2.getFechap5());
                fp2.setEmitido4(fp2.getEmitido5());
                fp2.setRecibo4(fp2.getRecibo5());

                fp2.setNombreplazo5(fp2.getNombreplazo6());
                fp2.setPorcentajepago5(fp2.getPorcentajepago6());
                fp2.setIid_tr_p5(fp2.getIid_tr_p6());
                fp2.setCobrado5(fp2.getCobrado6());
                fp2.setImportep5(fp2.getImportep6());
                fp2.setFechap5(fp2.getFechap6());
                fp2.setEmitido5(fp2.getEmitido6());
                fp2.setRecibo5(fp2.getRecibo6());

                fp2.setNombreplazo6(fp2.getNombreplazo7());
                fp2.setPorcentajepago6(fp2.getPorcentajepago7());
                fp2.setIid_tr_p6(fp2.getIid_tr_p7());
                fp2.setCobrado6(fp2.getCobrado7());
                fp2.setImportep6(fp2.getImportep7());
                fp2.setFechap6(fp2.getFechap7());
                fp2.setEmitido6(fp2.getEmitido7());
                fp2.setRecibo6(fp2.getRecibo7());

                fp2.setNombreplazo7(fp2.getNombreplazo8());
                fp2.setPorcentajepago7(fp2.getPorcentajepago8());
                fp2.setIid_tr_p7(fp2.getIid_tr_p8());
                fp2.setCobrado7(fp2.getCobrado8());
                fp2.setImportep7(fp2.getImportep8());
                fp2.setFechap7(fp2.getFechap8());
                fp2.setEmitido7(fp2.getEmitido8());
                fp2.setRecibo7(fp2.getRecibo8());

                fp2.setNombreplazo8(fp2.getNombreplazo9());
                fp2.setPorcentajepago8(fp2.getPorcentajepago9());
                fp2.setIid_tr_p8(fp2.getIid_tr_p9());
                fp2.setCobrado8(fp2.getCobrado9());
                fp2.setImportep8(fp2.getImportep9());
                fp2.setFechap8(fp2.getFechap9());
                fp2.setEmitido8(fp2.getEmitido9());
                fp2.setRecibo8(fp2.getRecibo9());
            } else if (plazo == 3) {
                porcentajeNegativo = fp2.getPorcentajepago3() * -1;
                //REORGANIZACION
                fp2.setNombreplazo3(fp2.getNombreplazo4());
                fp2.setPorcentajepago3(fp2.getPorcentajepago4());
                fp2.setIid_tr_p3(fp2.getIid_tr_p4());
                fp2.setCobrado3(fp2.getCobrado4());
                fp2.setImportep3(fp2.getImportep4());
                fp2.setFechap3(fp2.getFechap4());
                fp2.setEmitido3(fp2.getEmitido4());
                fp2.setRecibo3(fp2.getRecibo4());

                fp2.setNombreplazo4(fp2.getNombreplazo5());
                fp2.setPorcentajepago4(fp2.getPorcentajepago5());
                fp2.setIid_tr_p4(fp2.getIid_tr_p5());
                fp2.setCobrado4(fp2.getCobrado5());
                fp2.setImportep4(fp2.getImportep5());
                fp2.setFechap4(fp2.getFechap5());
                fp2.setEmitido4(fp2.getEmitido5());
                fp2.setRecibo4(fp2.getRecibo5());

                fp2.setNombreplazo5(fp2.getNombreplazo6());
                fp2.setPorcentajepago5(fp2.getPorcentajepago6());
                fp2.setIid_tr_p5(fp2.getIid_tr_p6());
                fp2.setCobrado5(fp2.getCobrado6());
                fp2.setImportep5(fp2.getImportep6());
                fp2.setFechap5(fp2.getFechap6());
                fp2.setEmitido5(fp2.getEmitido6());
                fp2.setRecibo5(fp2.getRecibo6());

                fp2.setNombreplazo6(fp2.getNombreplazo7());
                fp2.setPorcentajepago6(fp2.getPorcentajepago7());
                fp2.setIid_tr_p6(fp2.getIid_tr_p7());
                fp2.setCobrado6(fp2.getCobrado7());
                fp2.setImportep6(fp2.getImportep7());
                fp2.setFechap6(fp2.getFechap7());
                fp2.setEmitido6(fp2.getEmitido7());
                fp2.setRecibo6(fp2.getRecibo7());

                fp2.setNombreplazo7(fp2.getNombreplazo8());
                fp2.setPorcentajepago7(fp2.getPorcentajepago8());
                fp2.setIid_tr_p7(fp2.getIid_tr_p8());
                fp2.setCobrado7(fp2.getCobrado8());
                fp2.setImportep7(fp2.getImportep8());
                fp2.setFechap7(fp2.getFechap8());
                fp2.setEmitido7(fp2.getEmitido8());
                fp2.setRecibo7(fp2.getRecibo8());

                fp2.setNombreplazo8(fp2.getNombreplazo9());
                fp2.setPorcentajepago8(fp2.getPorcentajepago9());
                fp2.setIid_tr_p8(fp2.getIid_tr_p9());
                fp2.setCobrado8(fp2.getCobrado9());
                fp2.setImportep8(fp2.getImportep9());
                fp2.setFechap8(fp2.getFechap9());
                fp2.setEmitido8(fp2.getEmitido9());
                fp2.setRecibo8(fp2.getRecibo9());
            } else if (plazo == 4) {
                porcentajeNegativo = fp2.getPorcentajepago4() * -1;
                //REORGANIZACION
                fp2.setNombreplazo4(fp2.getNombreplazo5());
                fp2.setPorcentajepago4(fp2.getPorcentajepago5());
                fp2.setIid_tr_p4(fp2.getIid_tr_p5());
                fp2.setCobrado4(fp2.getCobrado5());
                fp2.setImportep4(fp2.getImportep5());
                fp2.setFechap4(fp2.getFechap5());
                fp2.setEmitido4(fp2.getEmitido5());
                fp2.setRecibo4(fp2.getRecibo5());

                fp2.setNombreplazo5(fp2.getNombreplazo6());
                fp2.setPorcentajepago5(fp2.getPorcentajepago6());
                fp2.setIid_tr_p5(fp2.getIid_tr_p6());
                fp2.setCobrado5(fp2.getCobrado6());
                fp2.setImportep5(fp2.getImportep6());
                fp2.setFechap5(fp2.getFechap6());
                fp2.setEmitido5(fp2.getEmitido6());
                fp2.setRecibo5(fp2.getRecibo6());

                fp2.setNombreplazo6(fp2.getNombreplazo7());
                fp2.setPorcentajepago6(fp2.getPorcentajepago7());
                fp2.setIid_tr_p6(fp2.getIid_tr_p7());
                fp2.setCobrado6(fp2.getCobrado7());
                fp2.setImportep6(fp2.getImportep7());
                fp2.setFechap6(fp2.getFechap7());
                fp2.setEmitido6(fp2.getEmitido7());
                fp2.setRecibo6(fp2.getRecibo7());

                fp2.setNombreplazo7(fp2.getNombreplazo8());
                fp2.setPorcentajepago7(fp2.getPorcentajepago8());
                fp2.setIid_tr_p7(fp2.getIid_tr_p8());
                fp2.setCobrado7(fp2.getCobrado8());
                fp2.setImportep7(fp2.getImportep8());
                fp2.setFechap7(fp2.getFechap8());
                fp2.setEmitido7(fp2.getEmitido8());
                fp2.setRecibo7(fp2.getRecibo8());

                fp2.setNombreplazo8(fp2.getNombreplazo9());
                fp2.setPorcentajepago8(fp2.getPorcentajepago9());
                fp2.setIid_tr_p8(fp2.getIid_tr_p9());
                fp2.setCobrado8(fp2.getCobrado9());
                fp2.setImportep8(fp2.getImportep9());
                fp2.setFechap8(fp2.getFechap9());
                fp2.setEmitido8(fp2.getEmitido9());
                fp2.setRecibo8(fp2.getRecibo9());
            } else if (plazo == 5) {
                porcentajeNegativo = fp2.getPorcentajepago5() * -1;
                //REORGANIZACION
                fp2.setNombreplazo5(fp2.getNombreplazo6());
                fp2.setPorcentajepago5(fp2.getPorcentajepago6());
                fp2.setIid_tr_p5(fp2.getIid_tr_p6());
                fp2.setCobrado5(fp2.getCobrado6());
                fp2.setImportep5(fp2.getImportep6());
                fp2.setFechap5(fp2.getFechap6());
                fp2.setEmitido5(fp2.getEmitido6());
                fp2.setRecibo5(fp2.getRecibo6());

                fp2.setNombreplazo6(fp2.getNombreplazo7());
                fp2.setPorcentajepago6(fp2.getPorcentajepago7());
                fp2.setIid_tr_p6(fp2.getIid_tr_p7());
                fp2.setCobrado6(fp2.getCobrado7());
                fp2.setImportep6(fp2.getImportep7());
                fp2.setFechap6(fp2.getFechap7());
                fp2.setEmitido6(fp2.getEmitido7());
                fp2.setRecibo6(fp2.getRecibo7());

                fp2.setNombreplazo7(fp2.getNombreplazo8());
                fp2.setPorcentajepago7(fp2.getPorcentajepago8());
                fp2.setIid_tr_p7(fp2.getIid_tr_p8());
                fp2.setCobrado7(fp2.getCobrado8());
                fp2.setImportep7(fp2.getImportep8());
                fp2.setFechap7(fp2.getFechap8());
                fp2.setEmitido7(fp2.getEmitido8());
                fp2.setRecibo7(fp2.getRecibo8());

                fp2.setNombreplazo8(fp2.getNombreplazo9());
                fp2.setPorcentajepago8(fp2.getPorcentajepago9());
                fp2.setIid_tr_p8(fp2.getIid_tr_p9());
                fp2.setCobrado8(fp2.getCobrado9());
                fp2.setImportep8(fp2.getImportep9());
                fp2.setFechap8(fp2.getFechap9());
                fp2.setEmitido8(fp2.getEmitido9());
                fp2.setRecibo8(fp2.getRecibo9());
            } else if (plazo == 6) {
                porcentajeNegativo = fp2.getPorcentajepago6() * -1;
                //REORGANIZACION
                fp2.setNombreplazo6(fp2.getNombreplazo7());
                fp2.setPorcentajepago6(fp2.getPorcentajepago7());
                fp2.setIid_tr_p6(fp2.getIid_tr_p7());
                fp2.setCobrado6(fp2.getCobrado7());
                fp2.setImportep6(fp2.getImportep7());
                fp2.setFechap6(fp2.getFechap7());
                fp2.setEmitido6(fp2.getEmitido7());
                fp2.setRecibo6(fp2.getRecibo7());

                fp2.setNombreplazo7(fp2.getNombreplazo8());
                fp2.setPorcentajepago7(fp2.getPorcentajepago8());
                fp2.setIid_tr_p7(fp2.getIid_tr_p8());
                fp2.setCobrado7(fp2.getCobrado8());
                fp2.setImportep7(fp2.getImportep8());
                fp2.setFechap7(fp2.getFechap8());
                fp2.setEmitido7(fp2.getEmitido8());
                fp2.setRecibo7(fp2.getRecibo8());

                fp2.setNombreplazo8(fp2.getNombreplazo9());
                fp2.setPorcentajepago8(fp2.getPorcentajepago9());
                fp2.setIid_tr_p8(fp2.getIid_tr_p9());
                fp2.setCobrado8(fp2.getCobrado9());
                fp2.setImportep8(fp2.getImportep9());
                fp2.setFechap8(fp2.getFechap9());
                fp2.setEmitido8(fp2.getEmitido9());
                fp2.setRecibo8(fp2.getRecibo9());
            } else if (plazo == 7) {
                porcentajeNegativo = fp2.getPorcentajepago7() * -1;
                //REORGANIZACION
                fp2.setNombreplazo7(fp2.getNombreplazo8());
                fp2.setPorcentajepago7(fp2.getPorcentajepago8());
                fp2.setIid_tr_p7(fp2.getIid_tr_p8());
                fp2.setCobrado7(fp2.getCobrado8());
                fp2.setImportep7(fp2.getImportep8());
                fp2.setFechap7(fp2.getFechap8());
                fp2.setEmitido7(fp2.getEmitido8());
                fp2.setRecibo7(fp2.getRecibo8());

                fp2.setNombreplazo8(fp2.getNombreplazo9());
                fp2.setPorcentajepago8(fp2.getPorcentajepago9());
                fp2.setIid_tr_p8(fp2.getIid_tr_p9());
                fp2.setCobrado8(fp2.getCobrado9());
                fp2.setImportep8(fp2.getImportep9());
                fp2.setFechap8(fp2.getFechap9());
                fp2.setEmitido8(fp2.getEmitido9());
                fp2.setRecibo8(fp2.getRecibo9());
            } else if (plazo == 8) {
                porcentajeNegativo = fp2.getPorcentajepago8() * -1;
                //REORGANIZACION
                fp2.setNombreplazo8(fp2.getNombreplazo9());
                fp2.setPorcentajepago8(fp2.getPorcentajepago9());
                fp2.setIid_tr_p8(fp2.getIid_tr_p9());
                fp2.setCobrado8(fp2.getCobrado9());
                fp2.setImportep8(fp2.getImportep9());
                fp2.setFechap8(fp2.getFechap9());
                fp2.setEmitido8(fp2.getEmitido9());
                fp2.setRecibo8(fp2.getRecibo9());
            } else if (plazo == 9) {
                porcentajeNegativo = fp2.getPorcentajepago9() * -1;
                fp2.setNombreplazo9(null);
                fp2.setPorcentajepago9(null);
                fp2.setIid_tr_p9(null);
                fp2.setCobrado9(null);
                fp2.setImportep9(null);
                fp2.setFechap9(null);
                fp2.setEmitido9(null);
                fp2.setRecibo9(null);

            }

            fp2.setNombreplazo9(null);
            fp2.setPorcentajepago9(null);
            fp2.setIid_tr_p9(null);
            fp2.setCobrado9(null);
            fp2.setImportep9(null);
            fp2.setFechap9(null);
            fp2.setEmitido9(null);
            fp2.setRecibo9(null);
            fp2.setNumplazosadelantados(fp2.getNumplazosadelantados() - 1);
            disminuirVencimientos(porcentajeNegativo);

            limpiarPlazosAdelantados();
            limpiarVencimientos();
            rellenarPlazosAdelantados();
            rellenarVencimientos();

            if (tplazosadelantados.getSelectedRowCount() == 0) {
                beliminarplazo.setEnabled(false);
            }
            if (tplazosadelantados.getSelectedRowCount() == 0) {
                bmodificarplazo.setEnabled(false);
            }
        }
    }

private void jMenuAlbaranActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuAlbaranActionPerformed
    if (cd.getDescripcion().equals(Constantes.PRESUPUESTO)) {
        //Hay que convertir el presupuesto a albarán
        convertirDocumento("Presupuesto");
    } else if (cd.getDescripcion().equals(Constantes.ALBARAN)) {
        //Hay que convertir el el albarán a presupuesto
        convertirAlbaran();
    } else if (cd.getDescripcion().equals(Constantes.PEDIDO)) {
        //Hay que convertir el el albarán a presupuesto
        convertirDocumento("Pedido");
    } else if (cd.getDescripcion().equals(Constantes.PEDIDOC) || cd.getDescripcion().equals(Constantes.ALBARANC) || cd.getDescripcion().equals(Constantes.FACTURAC)) {
        //Hay que convertir el el albarán a presupuesto
        convertirDocumento(Constantes.PEDIDOC);
    }
}//GEN-LAST:event_jMenuAlbaranActionPerformed

private void jMenuPDFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuPDFActionPerformed
    Agentes cli = BaseDatos.obtenerAgentesPorCodigo(p.getCodigoCliente(), "cli", e);
    HashMap parameters = new HashMap();

    if (i == null) {
        parameters.put("e.cod_empresa", e.getCod_empresa());
        parameters.put("e.desc_empresa", e.getDesc_empresa());
        parameters.put("e.dire_empresa", e.getDire_empresa());
        parameters.put("e.pobla_empresa", e.getPobla_empresa());
        parameters.put("e.cp_empresa", e.getCp_empresa());
        parameters.put("e.cif", e.getCif());
        parameters.put("e.telefono", e.getTelefono());
        parameters.put("e.fax", e.getFax());
        parameters.put("e.email", e.getEmail());
        parameters.put("e.web", e.getUrlWeb());
        parameters.put("tipoDocumento", cd.getDescripcion());

        if (!cli.getTerceros()) {
            parameters.put("c.codigo", this.tCodCliente.getText());
            parameters.put("c.dni", this.tDniCliente.getText());
            parameters.put("c.nombreComercial", this.tNombreCliente.getText());
            parameters.put("c.direccion", this.tDireccionCliente.getText());
            parameters.put("c.cp", this.tCpCliente.getText());
            parameters.put("c.poblacion", this.tLocalidadCliente.getText());
            parameters.put("c.provincia", this.tProvinciaCliente.getText());
            parameters.put("c.telefono", this.tTelefonoCliente.getText());
        } else {
            parameters.put("c.codigo", this.tCodCliente.getText());
            parameters.put("c.dni", this.tDniCliente.getText());
            parameters.put("c.nombreComercial", cli.getNombre_comercial());
            parameters.put("c.direccion", cli.getDireccion());
            parameters.put("c.cp", cli.getCodigo_postal().toString());
            parameters.put("c.poblacion", cli.getPoblacion());
            parameters.put("c.provincia", cli.getProvincia());
            parameters.put("c.telefono", cli.getTelefono());
        }

        parameters.put("logo", new ByteArrayInputStream(e.getImagen()));
        parameters.put("referencia", tReferencia.getText());
        parameters.put("numero", tnumero.getText());
        parameters.put("fecha", tfecha.getText());
    } else {
        //En el caso que tenga interlocutor, mostramos los datos de este para el cliente
        Empresa eI = BaseDatos.obtenerEmpresaPorIid(i.getEmpresaHija().getIid());
        parameters.put("e.cod_empresa", eI.getCod_empresa());
        parameters.put("e.desc_empresa", eI.getDesc_empresa());
        parameters.put("e.dire_empresa", eI.getDire_empresa());
        parameters.put("e.pobla_empresa", eI.getPobla_empresa());
        parameters.put("e.cp_empresa", eI.getCp_empresa());
        parameters.put("e.cif", e.getCif());
        parameters.put("e.telefono", e.getTelefono());
        parameters.put("e.fax", e.getFax());
        parameters.put("e.email", e.getEmail());
        parameters.put("e.web", e.getUrlWeb());
        parameters.put("tipoDocumento", cd.getDescripcion());

        if (!cli.getTerceros()) {
            parameters.put("c.codigo", this.tCodCliente.getText());
            parameters.put("c.dni", this.tDniCliente.getText());
            parameters.put("c.nombreComercial", this.tNombreCliente.getText());
            parameters.put("c.direccion", this.tDireccionCliente.getText());
            parameters.put("c.cp", this.tCpCliente.getText());
            parameters.put("c.poblacion", this.tLocalidadCliente.getText());
            parameters.put("c.provincia", this.tProvinciaCliente.getText());
            parameters.put("c.telefono", this.tTelefonoCliente.getText());
        } else {
            parameters.put("c.codigo", this.tCodCliente.getText());
            parameters.put("c.dni", this.tDniCliente.getText());
            parameters.put("c.nombreComercial", cli.getNombre_comercial());
            parameters.put("c.direccion", cli.getDireccion());
            parameters.put("c.cp", cli.getCodigo_postal().toString());
            parameters.put("c.poblacion", cli.getPoblacion());
            parameters.put("c.provincia", cli.getProvincia());
            parameters.put("c.telefono", cli.getTelefono());
        }

        parameters.put("logo", new ByteArrayInputStream(eI.getImagen()));
        parameters.put("referencia", tReferencia.getText());
        parameters.put("numero", tnumero.getText());
        parameters.put("fecha", tfecha.getText());
    }

    HashMap hashPrecio = new HashMap();
    hashPrecio.put("precio_bruto", lprecio.getText());
    hashPrecio.put("precio_final", lprecio_final.getText());
    hashPrecio.put("precio_iva", limporte_iva.getText());
    hashPrecio.put("iva", tIva.getText());

    parameters.put("hashPrecio", hashPrecio);
    parameters.put("precio_bruto", lprecio.getText());
    parameters.put("precio_final", lprecio_final.getText());
    parameters.put("precio_iva", limporte_iva.getText());

    List<LineaPresupuesto> listaProducto = new ArrayList<LineaPresupuesto>();
    NuevaLineaPresupuesto nlip;
    Articulo arti;
    Iterator<NuevaLineaPresupuesto> it = listaArticulos.iterator();
    LineaPresupuesto lip;
    FamiliaVenta fve;
    TipoControl tco;
    TipoMedida tme;
    double precio;

    while (it.hasNext()) {
        nlip = it.next();
        arti = nlip.getArticulo();
        if (arti != null) {
            lip = new LineaPresupuesto();
            lip.setArticulo_iid(arti);
            fve = BaseDatos.obtenerFamiliaVentaPorIid(nlip.getArticulo().getIid_fam_venta().getIid());
            tco = BaseDatos.obtenerTipoControlPorIid(fve.getIid_tipo_control().getIid());
            tme = BaseDatos.obtenerTipoMedidaByIid(tco.getIid_tipo_medida().getIid());
            lip.setNummedidas(tme.getNum_dimensiones());
            lip.setCodigo(nlip.getCodigo());
            lip.setPrecio(nlip.getPrecio());
            lip.setManual(nlip.getManual() ? "S" : "N");
            lip.setPresupuesto_iid(p);
            lip.setDescuento(nlip.getDescuento());
            lip.setCantidad(nlip.getCantidad());
            lip.setMedida1(nlip.getMedida1());
            lip.setMedida2(nlip.getMedida2());
            lip.setMedida3(nlip.getMedida3());
            lip.setMedida4(nlip.getMedida4());
            lip.setMedida5(nlip.getMedida5());
            lip.setMedidares(nlip.getMedidares());
            lip.setDescripcion(nlip.getDescripcion());
            lip.setCantidadStr(Util.convertirPuntoAComa(String.valueOf(nlip.getCantidad())));
            lip.setImporteStr(Util.convertirPuntoAComa(String.valueOf(nlip.getImporte())));
            precio = ((100 - lip.getDescuento()) * nlip.getPrecio()) / 100;
            lip.setPrecioStr(Util.convertirPuntoAComa(String.valueOf(matematico.Matematico.redondear2decimales(precio))));
            listaProducto.add(lip);
        } else if (!nlip.isLineaArticulo() && nlip.getDescripcion() != null && !nlip.getDescripcion().equals("")) {
            lip = new LineaPresupuesto();
            lip.setDescripcion(nlip.getDescripcion());
            listaProducto.add(lip);
        }
    }
    parameters.put("lineaPresupuesto", new JRBeanCollectionDataSource(listaProducto));

    List<Objeto2Elementos> lista = fp2.getPlazos();
    parameters.put("formaPago", new JRBeanCollectionDataSource(lista));
    parameters.put("formaPagoStr", fp2.getCodigo());

    Informe.imprimirPresupuesto(parameters);
}//GEN-LAST:event_jMenuPDFActionPerformed

private void jMenuPagadoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuPagadoActionPerformed
    if (pagado) {
        JOptionPane.showMessageDialog(null, "Este documento ya ha sido dado por pagado", "Error", JOptionPane.ERROR_MESSAGE);
    } else {
        int pagar = 1;
        pagar = JOptionPane.showConfirmDialog(null, "¿Está seguro de que desea dar por pagado el documento?", "¿Dar por pagado?", JOptionPane.YES_NO_OPTION);
        //hacerCambios = -1 ==> se ha pulsado la "x" de cancelar;
        //hacerCambios =  0 ==> se ha pulsado el "sí"
        //hacerCambios =  1 ==> se ha pulsado el "no"
        if (pagar == 0) {
            pagado = true;
            if (p.getClase_documento().getDescripcion().equals(Constantes.FACTURA)) {
                cestado.setSelectedItem("Pagado");
            }
        }
    }
}//GEN-LAST:event_jMenuPagadoActionPerformed

    private void eliminarVencimiento() {
        int numVencimientos = tvencimientos.getRowCount();
        if (numVencimientos == 1) {
            JOptionPane.showMessageDialog(null, "No se puede eliminar el único vencimiento existente", "Error", JOptionPane.ERROR_MESSAGE);
        } else if (numVencimientos > 1) {
            int indice = tvencimientos.getSelectedRow();
            if (indice >= 0) {
                String porcentaje = (String) tvencimientos.getValueAt(indice, 1);
                String importe = (String) tvencimientos.getValueAt(indice, 2);
                disminuirVencimientosModificacion((-1) * Double.valueOf(Util.convertirComaAPunto(porcentaje)), (-1) * Double.valueOf(Util.convertirComaAPunto(importe)));
                fp2.setNumplazosvencimiento(fp2.getNumplazosvencimiento() - 1);
                reorganizarVencimientos(indice);
                limpiarVencimientos();
                rellenarVencimientos();
            }
        }
    }

    private void reorganizarVencimientos(int indiceBorrado) {
        if (indiceBorrado == 0) {
            fp2.setCobradoVencimiento1(fp2.getCobradoVencimiento2());
            fp2.setEmitidoVencimiento1(fp2.getEmitidoVencimiento2());
            fp2.setReciboVencimiento1(fp2.getReciboVencimiento2());
            fp2.setImputadoVencimiento1(fp2.getImputadoVencimiento2());
            fp2.setIid_tr_v1(fp2.getIid_tr_v2());
            fp2.setImportev1(fp2.getImportev2());
            fp2.setPlazovm1(fp2.getPlazovm2());
            fp2.setPlazopm1(fp2.getPlazopm2());

            fp2.setCobradoVencimiento2(fp2.getCobradoVencimiento3());
            fp2.setEmitidoVencimiento2(fp2.getEmitidoVencimiento3());
            fp2.setReciboVencimiento2(fp2.getReciboVencimiento3());
            fp2.setImputadoVencimiento2(fp2.getImputadoVencimiento3());
            fp2.setIid_tr_v2(fp2.getIid_tr_v3());
            fp2.setImportev2(fp2.getImportev3());
            fp2.setPlazovm2(fp2.getPlazovm3());
            fp2.setPlazopm2(fp2.getPlazopm3());

            fp2.setCobradoVencimiento3(fp2.getCobradoVencimiento4());
            fp2.setEmitidoVencimiento3(fp2.getEmitidoVencimiento4());
            fp2.setReciboVencimiento3(fp2.getReciboVencimiento4());
            fp2.setImputadoVencimiento3(fp2.getImputadoVencimiento4());
            fp2.setIid_tr_v3(fp2.getIid_tr_v4());
            fp2.setImportev3(fp2.getImportev4());
            fp2.setPlazovm3(fp2.getPlazovm4());
            fp2.setPlazopm3(fp2.getPlazopm4());

            fp2.setCobradoVencimiento4(fp2.getCobradoVencimiento5());
            fp2.setEmitidoVencimiento4(fp2.getEmitidoVencimiento5());
            fp2.setReciboVencimiento4(fp2.getReciboVencimiento5());
            fp2.setImputadoVencimiento4(fp2.getImputadoVencimiento5());
            fp2.setIid_tr_v4(fp2.getIid_tr_v5());
            fp2.setImportev4(fp2.getImportev5());
            fp2.setPlazovm4(fp2.getPlazovm5());
            fp2.setPlazopm4(fp2.getPlazopm5());

            fp2.setCobradoVencimiento5(fp2.getCobradoVencimiento6());
            fp2.setEmitidoVencimiento5(fp2.getEmitidoVencimiento6());
            fp2.setReciboVencimiento5(fp2.getReciboVencimiento6());
            fp2.setImputadoVencimiento5(fp2.getImputadoVencimiento6());
            fp2.setIid_tr_v5(fp2.getIid_tr_v6());
            fp2.setImportev5(fp2.getImportev6());
            fp2.setPlazovm5(fp2.getPlazovm6());
            fp2.setPlazopm5(fp2.getPlazopm6());

            fp2.setCobradoVencimiento6(fp2.getCobradoVencimiento7());
            fp2.setEmitidoVencimiento6(fp2.getEmitidoVencimiento7());
            fp2.setReciboVencimiento6(fp2.getReciboVencimiento7());
            fp2.setImputadoVencimiento6(fp2.getImputadoVencimiento7());
            fp2.setIid_tr_v6(fp2.getIid_tr_v7());
            fp2.setImportev6(fp2.getImportev7());
            fp2.setPlazovm6(fp2.getPlazovm7());
            fp2.setPlazopm6(fp2.getPlazopm7());

            fp2.setCobradoVencimiento7(fp2.getCobradoVencimiento8());
            fp2.setEmitidoVencimiento7(fp2.getEmitidoVencimiento8());
            fp2.setReciboVencimiento7(fp2.getReciboVencimiento8());
            fp2.setImputadoVencimiento7(fp2.getImputadoVencimiento8());
            fp2.setIid_tr_v7(fp2.getIid_tr_v8());
            fp2.setImportev7(fp2.getImportev8());
            fp2.setPlazovm7(fp2.getPlazovm8());
            fp2.setPlazopm7(fp2.getPlazopm8());

            fp2.setCobradoVencimiento8(fp2.getCobradoVencimiento9());
            fp2.setEmitidoVencimiento8(fp2.getEmitidoVencimiento9());
            fp2.setReciboVencimiento8(fp2.getReciboVencimiento9());
            fp2.setImputadoVencimiento8(fp2.getImputadoVencimiento9());
            fp2.setIid_tr_v8(fp2.getIid_tr_v9());
            fp2.setImportev8(fp2.getImportev9());
            fp2.setPlazovm8(fp2.getPlazovm9());
            fp2.setPlazopm8(fp2.getPlazopm9());

            fp2.setCobradoVencimiento9(fp2.getCobradoVencimiento10());
            fp2.setEmitidoVencimiento9(fp2.getEmitidoVencimiento10());
            fp2.setReciboVencimiento9(fp2.getReciboVencimiento10());
            fp2.setImputadoVencimiento9(fp2.getImputadoVencimiento10());
            fp2.setIid_tr_v9(fp2.getIid_tr_v10());
            fp2.setImportev9(fp2.getImportev10());
            fp2.setPlazovm9(fp2.getPlazovm10());
            fp2.setPlazopm9(fp2.getPlazopm10());
        } else if (indiceBorrado == 1) {
            fp2.setCobradoVencimiento2(fp2.getCobradoVencimiento3());
            fp2.setEmitidoVencimiento2(fp2.getEmitidoVencimiento3());
            fp2.setReciboVencimiento2(fp2.getReciboVencimiento3());
            fp2.setImputadoVencimiento2(fp2.getImputadoVencimiento3());
            fp2.setIid_tr_v2(fp2.getIid_tr_v3());
            fp2.setImportev2(fp2.getImportev3());
            fp2.setPlazovm2(fp2.getPlazovm3());
            fp2.setPlazopm2(fp2.getPlazopm3());

            fp2.setCobradoVencimiento3(fp2.getCobradoVencimiento4());
            fp2.setEmitidoVencimiento3(fp2.getEmitidoVencimiento4());
            fp2.setReciboVencimiento3(fp2.getReciboVencimiento4());
            fp2.setImputadoVencimiento3(fp2.getImputadoVencimiento4());
            fp2.setIid_tr_v3(fp2.getIid_tr_v4());
            fp2.setImportev3(fp2.getImportev4());
            fp2.setPlazovm3(fp2.getPlazovm4());
            fp2.setPlazopm3(fp2.getPlazopm4());

            fp2.setCobradoVencimiento4(fp2.getCobradoVencimiento5());
            fp2.setEmitidoVencimiento4(fp2.getEmitidoVencimiento5());
            fp2.setReciboVencimiento4(fp2.getReciboVencimiento5());
            fp2.setImputadoVencimiento4(fp2.getImputadoVencimiento5());
            fp2.setIid_tr_v4(fp2.getIid_tr_v5());
            fp2.setImportev4(fp2.getImportev5());
            fp2.setPlazovm4(fp2.getPlazovm5());
            fp2.setPlazopm4(fp2.getPlazopm5());

            fp2.setCobradoVencimiento5(fp2.getCobradoVencimiento6());
            fp2.setEmitidoVencimiento5(fp2.getEmitidoVencimiento6());
            fp2.setReciboVencimiento5(fp2.getReciboVencimiento6());
            fp2.setImputadoVencimiento5(fp2.getImputadoVencimiento6());
            fp2.setIid_tr_v5(fp2.getIid_tr_v6());
            fp2.setImportev5(fp2.getImportev6());
            fp2.setPlazovm5(fp2.getPlazovm6());
            fp2.setPlazopm5(fp2.getPlazopm6());

            fp2.setCobradoVencimiento6(fp2.getCobradoVencimiento7());
            fp2.setEmitidoVencimiento6(fp2.getEmitidoVencimiento7());
            fp2.setReciboVencimiento6(fp2.getReciboVencimiento7());
            fp2.setImputadoVencimiento6(fp2.getImputadoVencimiento7());
            fp2.setIid_tr_v6(fp2.getIid_tr_v7());
            fp2.setImportev6(fp2.getImportev7());
            fp2.setPlazovm6(fp2.getPlazovm7());
            fp2.setPlazopm6(fp2.getPlazopm7());

            fp2.setCobradoVencimiento7(fp2.getCobradoVencimiento8());
            fp2.setEmitidoVencimiento7(fp2.getEmitidoVencimiento8());
            fp2.setReciboVencimiento7(fp2.getReciboVencimiento8());
            fp2.setImputadoVencimiento7(fp2.getImputadoVencimiento8());
            fp2.setIid_tr_v7(fp2.getIid_tr_v8());
            fp2.setImportev7(fp2.getImportev8());
            fp2.setPlazovm7(fp2.getPlazovm8());
            fp2.setPlazopm7(fp2.getPlazopm8());

            fp2.setCobradoVencimiento8(fp2.getCobradoVencimiento9());
            fp2.setEmitidoVencimiento8(fp2.getEmitidoVencimiento9());
            fp2.setReciboVencimiento8(fp2.getReciboVencimiento9());
            fp2.setImputadoVencimiento8(fp2.getImputadoVencimiento9());
            fp2.setIid_tr_v8(fp2.getIid_tr_v9());
            fp2.setImportev8(fp2.getImportev9());
            fp2.setPlazovm8(fp2.getPlazovm9());
            fp2.setPlazopm8(fp2.getPlazopm9());

            fp2.setCobradoVencimiento9(fp2.getCobradoVencimiento10());
            fp2.setEmitidoVencimiento9(fp2.getEmitidoVencimiento10());
            fp2.setReciboVencimiento9(fp2.getReciboVencimiento10());
            fp2.setImputadoVencimiento9(fp2.getImputadoVencimiento10());
            fp2.setIid_tr_v9(fp2.getIid_tr_v10());
            fp2.setImportev9(fp2.getImportev10());
            fp2.setPlazovm9(fp2.getPlazovm10());
            fp2.setPlazopm9(fp2.getPlazopm10());
        } else if (indiceBorrado == 2) {
            fp2.setCobradoVencimiento3(fp2.getCobradoVencimiento4());
            fp2.setEmitidoVencimiento3(fp2.getEmitidoVencimiento4());
            fp2.setReciboVencimiento3(fp2.getReciboVencimiento4());
            fp2.setImputadoVencimiento3(fp2.getImputadoVencimiento4());
            fp2.setIid_tr_v3(fp2.getIid_tr_v4());
            fp2.setImportev3(fp2.getImportev4());
            fp2.setPlazovm3(fp2.getPlazovm4());
            fp2.setPlazopm3(fp2.getPlazopm4());

            fp2.setCobradoVencimiento4(fp2.getCobradoVencimiento5());
            fp2.setEmitidoVencimiento4(fp2.getEmitidoVencimiento5());
            fp2.setReciboVencimiento4(fp2.getReciboVencimiento5());
            fp2.setImputadoVencimiento4(fp2.getImputadoVencimiento5());
            fp2.setIid_tr_v4(fp2.getIid_tr_v5());
            fp2.setImportev4(fp2.getImportev5());
            fp2.setPlazovm4(fp2.getPlazovm5());
            fp2.setPlazopm4(fp2.getPlazopm5());

            fp2.setCobradoVencimiento5(fp2.getCobradoVencimiento6());
            fp2.setEmitidoVencimiento5(fp2.getEmitidoVencimiento6());
            fp2.setReciboVencimiento5(fp2.getReciboVencimiento6());
            fp2.setImputadoVencimiento5(fp2.getImputadoVencimiento6());
            fp2.setIid_tr_v5(fp2.getIid_tr_v6());
            fp2.setImportev5(fp2.getImportev6());
            fp2.setPlazovm5(fp2.getPlazovm6());
            fp2.setPlazopm5(fp2.getPlazopm6());

            fp2.setCobradoVencimiento6(fp2.getCobradoVencimiento7());
            fp2.setEmitidoVencimiento6(fp2.getEmitidoVencimiento7());
            fp2.setReciboVencimiento6(fp2.getReciboVencimiento7());
            fp2.setImputadoVencimiento6(fp2.getImputadoVencimiento7());
            fp2.setIid_tr_v6(fp2.getIid_tr_v7());
            fp2.setImportev6(fp2.getImportev7());
            fp2.setPlazovm6(fp2.getPlazovm7());
            fp2.setPlazopm6(fp2.getPlazopm7());

            fp2.setCobradoVencimiento7(fp2.getCobradoVencimiento8());
            fp2.setEmitidoVencimiento7(fp2.getEmitidoVencimiento8());
            fp2.setReciboVencimiento7(fp2.getReciboVencimiento8());
            fp2.setImputadoVencimiento7(fp2.getImputadoVencimiento8());
            fp2.setIid_tr_v7(fp2.getIid_tr_v8());
            fp2.setImportev7(fp2.getImportev8());
            fp2.setPlazovm7(fp2.getPlazovm8());
            fp2.setPlazopm7(fp2.getPlazopm8());

            fp2.setCobradoVencimiento8(fp2.getCobradoVencimiento9());
            fp2.setEmitidoVencimiento8(fp2.getEmitidoVencimiento9());
            fp2.setReciboVencimiento8(fp2.getReciboVencimiento9());
            fp2.setImputadoVencimiento8(fp2.getImputadoVencimiento9());
            fp2.setIid_tr_v8(fp2.getIid_tr_v9());
            fp2.setImportev8(fp2.getImportev9());
            fp2.setPlazovm8(fp2.getPlazovm9());
            fp2.setPlazopm8(fp2.getPlazopm9());

            fp2.setCobradoVencimiento9(fp2.getCobradoVencimiento10());
            fp2.setEmitidoVencimiento9(fp2.getEmitidoVencimiento10());
            fp2.setReciboVencimiento9(fp2.getReciboVencimiento10());
            fp2.setImputadoVencimiento9(fp2.getImputadoVencimiento10());
            fp2.setIid_tr_v9(fp2.getIid_tr_v10());
            fp2.setImportev9(fp2.getImportev10());
            fp2.setPlazovm9(fp2.getPlazovm10());
            fp2.setPlazopm9(fp2.getPlazopm10());
        } else if (indiceBorrado == 3) {
            fp2.setCobradoVencimiento4(fp2.getCobradoVencimiento5());
            fp2.setEmitidoVencimiento4(fp2.getEmitidoVencimiento5());
            fp2.setReciboVencimiento4(fp2.getReciboVencimiento5());
            fp2.setImputadoVencimiento4(fp2.getImputadoVencimiento5());
            fp2.setIid_tr_v4(fp2.getIid_tr_v5());
            fp2.setImportev4(fp2.getImportev5());
            fp2.setPlazovm4(fp2.getPlazovm5());
            fp2.setPlazopm4(fp2.getPlazopm5());

            fp2.setCobradoVencimiento5(fp2.getCobradoVencimiento6());
            fp2.setEmitidoVencimiento5(fp2.getEmitidoVencimiento6());
            fp2.setReciboVencimiento5(fp2.getReciboVencimiento6());
            fp2.setImputadoVencimiento5(fp2.getImputadoVencimiento6());
            fp2.setIid_tr_v5(fp2.getIid_tr_v6());
            fp2.setImportev5(fp2.getImportev6());
            fp2.setPlazovm5(fp2.getPlazovm6());
            fp2.setPlazopm5(fp2.getPlazopm6());

            fp2.setCobradoVencimiento6(fp2.getCobradoVencimiento7());
            fp2.setEmitidoVencimiento6(fp2.getEmitidoVencimiento7());
            fp2.setReciboVencimiento6(fp2.getReciboVencimiento7());
            fp2.setImputadoVencimiento6(fp2.getImputadoVencimiento7());
            fp2.setIid_tr_v6(fp2.getIid_tr_v7());
            fp2.setImportev6(fp2.getImportev7());
            fp2.setPlazovm6(fp2.getPlazovm7());
            fp2.setPlazopm6(fp2.getPlazopm7());

            fp2.setCobradoVencimiento7(fp2.getCobradoVencimiento8());
            fp2.setEmitidoVencimiento7(fp2.getEmitidoVencimiento8());
            fp2.setReciboVencimiento7(fp2.getReciboVencimiento8());
            fp2.setImputadoVencimiento7(fp2.getImputadoVencimiento8());
            fp2.setIid_tr_v7(fp2.getIid_tr_v8());
            fp2.setImportev7(fp2.getImportev8());
            fp2.setPlazovm7(fp2.getPlazovm8());
            fp2.setPlazopm7(fp2.getPlazopm8());

            fp2.setCobradoVencimiento8(fp2.getCobradoVencimiento9());
            fp2.setEmitidoVencimiento8(fp2.getEmitidoVencimiento9());
            fp2.setReciboVencimiento8(fp2.getReciboVencimiento9());
            fp2.setImputadoVencimiento8(fp2.getImputadoVencimiento9());
            fp2.setIid_tr_v8(fp2.getIid_tr_v9());
            fp2.setImportev8(fp2.getImportev9());
            fp2.setPlazovm8(fp2.getPlazovm9());
            fp2.setPlazopm8(fp2.getPlazopm9());

            fp2.setCobradoVencimiento9(fp2.getCobradoVencimiento10());
            fp2.setEmitidoVencimiento9(fp2.getEmitidoVencimiento10());
            fp2.setReciboVencimiento9(fp2.getReciboVencimiento10());
            fp2.setImputadoVencimiento9(fp2.getImputadoVencimiento10());
            fp2.setIid_tr_v9(fp2.getIid_tr_v10());
            fp2.setImportev9(fp2.getImportev10());
            fp2.setPlazovm9(fp2.getPlazovm10());
            fp2.setPlazopm9(fp2.getPlazopm10());
        } else if (indiceBorrado == 4) {
            fp2.setCobradoVencimiento5(fp2.getCobradoVencimiento6());
            fp2.setEmitidoVencimiento5(fp2.getEmitidoVencimiento6());
            fp2.setReciboVencimiento5(fp2.getReciboVencimiento6());
            fp2.setImputadoVencimiento5(fp2.getImputadoVencimiento6());
            fp2.setIid_tr_v5(fp2.getIid_tr_v6());
            fp2.setImportev5(fp2.getImportev6());
            fp2.setPlazovm5(fp2.getPlazovm6());
            fp2.setPlazopm5(fp2.getPlazopm6());

            fp2.setCobradoVencimiento6(fp2.getCobradoVencimiento7());
            fp2.setEmitidoVencimiento6(fp2.getEmitidoVencimiento7());
            fp2.setReciboVencimiento6(fp2.getReciboVencimiento7());
            fp2.setImputadoVencimiento6(fp2.getImputadoVencimiento7());
            fp2.setIid_tr_v6(fp2.getIid_tr_v7());
            fp2.setImportev6(fp2.getImportev7());
            fp2.setPlazovm6(fp2.getPlazovm7());
            fp2.setPlazopm6(fp2.getPlazopm7());

            fp2.setCobradoVencimiento7(fp2.getCobradoVencimiento8());
            fp2.setEmitidoVencimiento7(fp2.getEmitidoVencimiento8());
            fp2.setReciboVencimiento7(fp2.getReciboVencimiento8());
            fp2.setImputadoVencimiento7(fp2.getImputadoVencimiento8());
            fp2.setIid_tr_v7(fp2.getIid_tr_v8());
            fp2.setImportev7(fp2.getImportev8());
            fp2.setPlazovm7(fp2.getPlazovm8());
            fp2.setPlazopm7(fp2.getPlazopm8());

            fp2.setCobradoVencimiento8(fp2.getCobradoVencimiento9());
            fp2.setEmitidoVencimiento8(fp2.getEmitidoVencimiento9());
            fp2.setReciboVencimiento8(fp2.getReciboVencimiento9());
            fp2.setImputadoVencimiento8(fp2.getImputadoVencimiento9());
            fp2.setIid_tr_v8(fp2.getIid_tr_v9());
            fp2.setImportev8(fp2.getImportev9());
            fp2.setPlazovm8(fp2.getPlazovm9());
            fp2.setPlazopm8(fp2.getPlazopm9());

            fp2.setCobradoVencimiento9(fp2.getCobradoVencimiento10());
            fp2.setEmitidoVencimiento9(fp2.getEmitidoVencimiento10());
            fp2.setReciboVencimiento9(fp2.getReciboVencimiento10());
            fp2.setImputadoVencimiento9(fp2.getImputadoVencimiento10());
            fp2.setIid_tr_v9(fp2.getIid_tr_v10());
            fp2.setImportev9(fp2.getImportev10());
            fp2.setPlazovm9(fp2.getPlazovm10());
            fp2.setPlazopm9(fp2.getPlazopm10());
        } else if (indiceBorrado == 5) {
            fp2.setCobradoVencimiento6(fp2.getCobradoVencimiento7());
            fp2.setEmitidoVencimiento6(fp2.getEmitidoVencimiento7());
            fp2.setReciboVencimiento6(fp2.getReciboVencimiento7());
            fp2.setImputadoVencimiento6(fp2.getImputadoVencimiento7());
            fp2.setIid_tr_v6(fp2.getIid_tr_v7());
            fp2.setImportev6(fp2.getImportev7());
            fp2.setPlazovm6(fp2.getPlazovm7());
            fp2.setPlazopm6(fp2.getPlazopm7());

            fp2.setCobradoVencimiento7(fp2.getCobradoVencimiento8());
            fp2.setEmitidoVencimiento7(fp2.getEmitidoVencimiento8());
            fp2.setReciboVencimiento7(fp2.getReciboVencimiento8());
            fp2.setImputadoVencimiento7(fp2.getImputadoVencimiento8());
            fp2.setIid_tr_v7(fp2.getIid_tr_v8());
            fp2.setImportev7(fp2.getImportev8());
            fp2.setPlazovm7(fp2.getPlazovm8());
            fp2.setPlazopm7(fp2.getPlazopm8());

            fp2.setCobradoVencimiento8(fp2.getCobradoVencimiento9());
            fp2.setEmitidoVencimiento8(fp2.getEmitidoVencimiento9());
            fp2.setReciboVencimiento8(fp2.getReciboVencimiento9());
            fp2.setImputadoVencimiento8(fp2.getImputadoVencimiento9());
            fp2.setIid_tr_v8(fp2.getIid_tr_v9());
            fp2.setImportev8(fp2.getImportev9());
            fp2.setPlazovm8(fp2.getPlazovm9());
            fp2.setPlazopm8(fp2.getPlazopm9());

            fp2.setCobradoVencimiento9(fp2.getCobradoVencimiento10());
            fp2.setEmitidoVencimiento9(fp2.getEmitidoVencimiento10());
            fp2.setReciboVencimiento9(fp2.getReciboVencimiento10());
            fp2.setImputadoVencimiento9(fp2.getImputadoVencimiento10());
            fp2.setIid_tr_v9(fp2.getIid_tr_v10());
            fp2.setImportev9(fp2.getImportev10());
            fp2.setPlazovm9(fp2.getPlazovm10());
            fp2.setPlazopm9(fp2.getPlazopm10());
        } else if (indiceBorrado == 6) {
            fp2.setCobradoVencimiento7(fp2.getCobradoVencimiento8());
            fp2.setEmitidoVencimiento7(fp2.getEmitidoVencimiento8());
            fp2.setReciboVencimiento7(fp2.getReciboVencimiento8());
            fp2.setImputadoVencimiento7(fp2.getImputadoVencimiento8());
            fp2.setIid_tr_v7(fp2.getIid_tr_v8());
            fp2.setImportev7(fp2.getImportev8());
            fp2.setPlazovm7(fp2.getPlazovm8());
            fp2.setPlazopm7(fp2.getPlazopm8());

            fp2.setCobradoVencimiento8(fp2.getCobradoVencimiento9());
            fp2.setEmitidoVencimiento8(fp2.getEmitidoVencimiento9());
            fp2.setReciboVencimiento8(fp2.getReciboVencimiento9());
            fp2.setImputadoVencimiento8(fp2.getImputadoVencimiento9());
            fp2.setIid_tr_v8(fp2.getIid_tr_v9());
            fp2.setImportev8(fp2.getImportev9());
            fp2.setPlazovm8(fp2.getPlazovm9());
            fp2.setPlazopm8(fp2.getPlazopm9());

            fp2.setCobradoVencimiento9(fp2.getCobradoVencimiento10());
            fp2.setEmitidoVencimiento9(fp2.getEmitidoVencimiento10());
            fp2.setReciboVencimiento9(fp2.getReciboVencimiento10());
            fp2.setImputadoVencimiento9(fp2.getImputadoVencimiento10());
            fp2.setIid_tr_v9(fp2.getIid_tr_v10());
            fp2.setImportev9(fp2.getImportev10());
            fp2.setPlazovm9(fp2.getPlazovm10());
            fp2.setPlazopm9(fp2.getPlazopm10());
        } else if (indiceBorrado == 7) {
            fp2.setCobradoVencimiento8(fp2.getCobradoVencimiento9());
            fp2.setEmitidoVencimiento8(fp2.getEmitidoVencimiento9());
            fp2.setReciboVencimiento8(fp2.getReciboVencimiento9());
            fp2.setImputadoVencimiento8(fp2.getImputadoVencimiento9());
            fp2.setIid_tr_v8(fp2.getIid_tr_v9());
            fp2.setImportev8(fp2.getImportev9());
            fp2.setPlazovm8(fp2.getPlazovm9());
            fp2.setPlazopm8(fp2.getPlazopm9());

            fp2.setCobradoVencimiento9(fp2.getCobradoVencimiento10());
            fp2.setEmitidoVencimiento9(fp2.getEmitidoVencimiento10());
            fp2.setReciboVencimiento9(fp2.getReciboVencimiento10());
            fp2.setImputadoVencimiento9(fp2.getImputadoVencimiento10());
            fp2.setIid_tr_v9(fp2.getIid_tr_v10());
            fp2.setImportev9(fp2.getImportev10());
            fp2.setPlazovm9(fp2.getPlazovm10());
            fp2.setPlazopm9(fp2.getPlazopm10());
        } else if (indiceBorrado == 8) {
            fp2.setCobradoVencimiento9(fp2.getCobradoVencimiento10());
            fp2.setEmitidoVencimiento9(fp2.getEmitidoVencimiento10());
            fp2.setReciboVencimiento9(fp2.getReciboVencimiento10());
            fp2.setImputadoVencimiento9(fp2.getImputadoVencimiento10());
            fp2.setIid_tr_v9(fp2.getIid_tr_v10());
            fp2.setImportev9(fp2.getImportev10());
            fp2.setPlazovm9(fp2.getPlazovm10());
            fp2.setPlazopm9(fp2.getPlazopm10());
        }
    }
private void jMenuItemLineaDespuesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItemLineaDespuesActionPerformed
    lineaDespues();
}//GEN-LAST:event_jMenuItemLineaDespuesActionPerformed

private void jMenuItemNotaFinalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItemNotaFinalActionPerformed
    notaFinal();
}//GEN-LAST:event_jMenuItemNotaFinalActionPerformed

private void jMenuItemNotaAntesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItemNotaAntesActionPerformed
    notaAntes();
}//GEN-LAST:event_jMenuItemNotaAntesActionPerformed

private void jMenuItemNotaDespuesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItemNotaDespuesActionPerformed
    notaDespues();
}//GEN-LAST:event_jMenuItemNotaDespuesActionPerformed

private void jMenuItemLineaPrincipioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItemLineaPrincipioActionPerformed
    lineaPrincipio();
}//GEN-LAST:event_jMenuItemLineaPrincipioActionPerformed

private void jMenuItemLineaFinalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItemLineaFinalActionPerformed
    lineaFinal();
}//GEN-LAST:event_jMenuItemLineaFinalActionPerformed

private void jMenuItemLineaAntesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItemLineaAntesActionPerformed
    lineaAntes();
}//GEN-LAST:event_jMenuItemLineaAntesActionPerformed

private void jMenuItemNotaPrincipioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItemNotaPrincipioActionPerformed
    notaPrincipio();
}//GEN-LAST:event_jMenuItemNotaPrincipioActionPerformed

    private void lineaDespues() {
        insertarLineaNueva(lineaActiva, true);
    }

    private void notaFinal() {
        insertarLineaNueva(this.listaArticulos.size(), false);
    }

    private void notaAntes() {
        insertarLineaNueva(lineaActiva - 1, false);
        lineaActiva++;
    }

    private void notaDespues() {
        insertarLineaNueva(lineaActiva, false);
    }

    private void lineaPrincipio() {
        insertarLineaNueva(0, true);
    }

    private void lineaFinal() {
        insertarLineaNueva(listaArticulos.size(), true);
    }

    private void lineaAntes() {
        insertarLineaNueva(lineaActiva - 1, true);
        lineaActiva++;
    }

    private void notaPrincipio() {
        insertarLineaNueva(0, false);
    }

private void jMenuImpagadoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuImpagadoActionPerformed
    if (impagado) {
        JOptionPane.showMessageDialog(null, "Este documento ya ha sido dado por impagado", "Error", JOptionPane.ERROR_MESSAGE);
    } else {
        int impagar = 1;
        impagar = JOptionPane.showConfirmDialog(null, "¿Está seguro de que desea dar por impagado el documento?", "¿Dar por impagado?", JOptionPane.YES_NO_OPTION);
        //hacerCambios = -1 ==> se ha pulsado la "x" de cancelar;
        //hacerCambios =  0 ==> se ha pulsado el "sí"
        //hacerCambios =  1 ==> se ha pulsado el "no"
        if (impagar == 0) {
            impagado = true;
            if (p.getClase_documento().getDescripcion().equals(Constantes.FACTURA)) {
                cestado.setSelectedItem("Impagado");
            }
        }
    }
}//GEN-LAST:event_jMenuImpagadoActionPerformed

private void jMenuImprimirRecibosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuImprimirRecibosActionPerformed
    if (this.tvencimientos.getRowCount() < 1) {
        JOptionPane.showMessageDialog(null, "No hay ningún vencimiento", "Error", JOptionPane.ERROR_MESSAGE);
    } else {
        HashMap parameters = new HashMap();
        List<VencimientoImpreso> listaVencimientos = new ArrayList<VencimientoImpreso>();
        VencimientoImpreso vi;

        int indice;
        int hasta = tvencimientos.getRowCount();
        String simporte;
        String fechaStr;
        String cuenta = "";
        String entidad = "";
        String codPostalLocalidad = "";

        if (!tCpCliente.getText().equals("") && !tLocalidadCliente.getText().equals("")) {
            codPostalLocalidad = tCpCliente.getText() + " - " + tLocalidadCliente.getText();
        } else if (tCpCliente.getText().equals("")) {
            codPostalLocalidad = tLocalidadCliente.getText();
        } else {
            codPostalLocalidad = tCpCliente.getText();
        }

        Agentes age = BaseDatos.obtenerAgentesPorCodigo(tCodCliente.getText(), "cli", e);
        if (age != null) {
            cuenta = age.getCuenta();
            entidad = age.getEntidad();
        }

        Double dimporte;
        String cadenaEuros = "";
        String cadenaEurosEntera = "";
        String cadenaEurosDecimal = "";
        String tipoRecibo = "";

        for (indice = 1; indice <= hasta; indice++) {
            simporte = (String) tvencimientos.getValueAt(indice - 1, 2);
            fechaStr = (String) tvencimientos.getValueAt(indice - 1, 4);
            tipoRecibo = (String) tvencimientos.getValueAt(indice - 1, 3);

            if (tipoRecibo.equals("Domiciliado")) {
                dimporte = new Double(Util.convertirComaAPunto(simporte));

                cadenaEurosEntera = util.NumLetrasJ.convierte(String.valueOf(dimporte.intValue())).toUpperCase();
                cadenaEurosDecimal = util.NumLetrasJ.convierte(String.valueOf(matematico.Matematico.redondear2decimales(dimporte - dimporte.intValue())).substring(2)).toUpperCase();
                cadenaEuros = cadenaEurosEntera + " CON " + cadenaEurosDecimal;

                vi = new VencimientoImpreso("Ejemplar para la empresa", tnumero.getText() + "-" + indice, tfecha.getText(), fechaStr, "# " + simporte + " #", cadenaEuros, entidad, cuenta, tNombreCliente.getText(), tDireccionCliente.getText(), codPostalLocalidad, tProvinciaCliente.getText(), tTelefonoCliente.getText(), tDniCliente.getText(), e.getDesc_empresa(), e.getCif());
                listaVencimientos.add(vi);
                vi = new VencimientoImpreso("Ejemplar para la empresa", tnumero.getText() + "-" + indice, tfecha.getText(), fechaStr, "# " + simporte + " #", cadenaEuros, entidad, cuenta, tNombreCliente.getText(), tDireccionCliente.getText(), codPostalLocalidad, tProvinciaCliente.getText(), tTelefonoCliente.getText(), tDniCliente.getText(), e.getDesc_empresa(), e.getCif());
                listaVencimientos.add(vi);
                vi = new VencimientoImpreso("Ejemplar para el cliente", tnumero.getText() + "-" + indice, tfecha.getText(), fechaStr, "# " + simporte + " #", cadenaEuros, entidad, cuenta, tNombreCliente.getText(), tDireccionCliente.getText(), codPostalLocalidad, tProvinciaCliente.getText(), tTelefonoCliente.getText(), tDniCliente.getText(), e.getDesc_empresa(), e.getCif());
                listaVencimientos.add(vi);
            }
        }

        if (listaVencimientos != null && listaVencimientos.size() > 0) {
            parameters.put("vencimiento", new JRBeanCollectionDataSource(listaVencimientos));
            Recibo.imprimirRecibo(parameters);
        } else {
            JOptionPane.showMessageDialog(null, "No hay ningún vencimiento domiciliado", "Error", JOptionPane.INFORMATION_MESSAGE);
        }
    }
}//GEN-LAST:event_jMenuImprimirRecibosActionPerformed

private void jMenuItemCorteLonaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItemCorteLonaActionPerformed
    cortarLona();
}//GEN-LAST:event_jMenuItemCorteLonaActionPerformed

    private int cortarLona() {
        int guardar = 1;
        guardar = JOptionPane.showConfirmDialog(null, "Debe guardar el documento ¿Desea guardarlo?", "¿Guardar Documento?", JOptionPane.YES_NO_OPTION);
        //hacerCambios = -1 ==> se ha pulsado la "x" de cancelar;
        //hacerCambios =  0 ==> se ha pulsado el "sí"
        //hacerCambios =  1 ==> se ha pulsado el "no"
        if (guardar == 0) {

            if (actualizarPresupuesto()) {
                if (BaseDatos.guardarDocumento(p, fp2, cod_fp2, fp2_aux, listaArticulos, crear, cd, rellenarDacMap)) {
                    JOptionPane.showMessageDialog(null, "Documento guardado", "Guardado", JOptionPane.INFORMATION_MESSAGE);
                    crear = false;
                    tnumero.setText(p.getNumero());
                    mensajesInternos();
                    //Se han de tomar todos los articulos (ya sea en en DAC o no) cuya FV = Lona

                    List listaNueva = BaseDatos.getListaLineaPresupuesto(p.getIid());
                    Iterator<LineaPresupuesto> iter = listaNueva.iterator();
                    LineaPresupuesto lp;
                    int codigoLinea;
                    Articulo arti;
                    Caracteristica caract;
                    RellenarDac rd;
                    List<CorteLona> listaLona = new ArrayList<CorteLona>();
                    FamiliaVenta fv;
                    String medida1S,medida2S , cantidadS;

                    while (iter.hasNext()) {
                        lp = iter.next();
                        if (lp.getArticulo_iid() != null) {
                            codigoLinea = lp.getCodigo();
                            rd = (RellenarDac) rellenarDacMap.get(codigoLinea);

                            if (rd == null) {
                                arti = lp.getArticulo_iid();
                                caract = lp.getCaracteristica();
                                if (arti != null) {
                                    arti = BaseDatos.obtenerArticuloPorIid(arti.getIid());
                                    fv = arti.getIid_fam_venta();
                                    fv = BaseDatos.obtenerFamiliaVentaPorIid(fv.getIid());
                                    if (fv.getConfeccionable() != null && fv.getConfeccionable()) {
                                        listaLona.add(new CorteLona(codigoLinea, lp));
                                    }
                                }
                            } else {
                                medida1S = Util.convertirPuntoAComa(String.valueOf(lp.getMedida1()));
                                medida2S = Util.convertirPuntoAComa(String.valueOf(lp.getMedida2()));
                                cantidadS = Util.convertirPuntoAComa(String.valueOf(lp.getCantidad()));
                                listaLona.addAll(rd.getArticulosLona(medida1S, medida2S, cantidadS, codigoLinea, lp));
                            }
                        }
                    }

                    if (listaLona != null && listaLona.size() > 0) {
                        final NuevoCorteLona ncl = new NuevoCorteLona(this, listaLona);
                        ncl.setDefaultCloseOperation(NuevoCorteLona.DO_NOTHING_ON_CLOSE);
                        ncl.setLocationRelativeTo(null);
                        ncl.setVisible(true);
                        ncl.addWindowListener(new WindowAdapter() {
                            @Override
                            public void windowClosing(WindowEvent e) {
                                ncl.salir();
                            }
                        });
                    } else {
                        JOptionPane.showMessageDialog(null, "No hay ninguna lona", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                } else {
                    String mensaje = "No se puede ha podido modificar el elemento";
                    if (crear) {
                        mensaje = "No se puede ha podido insertar el elemento";
                    }
                    JOptionPane.showMessageDialog(null, mensaje, "Error", JOptionPane.ERROR_MESSAGE);
                }
                crearDocInt();
            }
        }
        return guardar;
    }

private void jMenuItemCortePerfilActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItemCortePerfilActionPerformed
    cortarPerfil();
}//GEN-LAST:event_jMenuItemCortePerfilActionPerformed

    private int cortarPerfil() {
        int guardar = 1;
        guardar = JOptionPane.showConfirmDialog(null, "Debe guardar el documento ¿Desea guardarlo?", "¿Guardar Documento?", JOptionPane.YES_NO_OPTION);
        //hacerCambios = -1 ==> se ha pulsado la "x" de cancelar;
        //hacerCambios =  0 ==> se ha pulsado el "sí"
        //hacerCambios =  1 ==> se ha pulsado el "no"
        if (guardar == 0) {
            if (actualizarPresupuesto()) {
                if (BaseDatos.guardarDocumento(p, fp2, cod_fp2, fp2_aux, listaArticulos, crear, cd, rellenarDacMap)) {
                    JOptionPane.showMessageDialog(null, "Documento guardado", "Guardado", JOptionPane.INFORMATION_MESSAGE);
                    mensajesInternos();
                    crear = false;
                    tnumero.setText(p.getNumero());
                    //Se han de tomar todos los articulos (ya sea en en DAC o no) cuya FV = Perfil

                    List listaNueva = BaseDatos.getListaLineaPresupuesto(p.getIid());
                    Iterator<LineaPresupuesto> iter = listaNueva.iterator();
                    LineaPresupuesto lp;
                    int codigoLinea;
                    Articulo arti;
                    Caracteristica caract;
                    RellenarDac rd;
                    List<CortePerfil> listaPerfil = new ArrayList<CortePerfil>();
                    FamiliaVenta fv;
                    String medida1S, cantidadS;

                    while (iter.hasNext()) {
                        lp = iter.next();
                        if (lp.getArticulo_iid() != null) {
                            codigoLinea = lp.getCodigo();
                            rd = (RellenarDac) rellenarDacMap.get(codigoLinea);

                            if (rd == null) {
                                arti = lp.getArticulo_iid();
                                caract = lp.getCaracteristica();
                                if (arti != null) {
                                    arti = BaseDatos.obtenerArticuloPorIid(arti.getIid());
                                    fv = arti.getIid_fam_venta();
                                    fv = BaseDatos.obtenerFamiliaVentaPorIid(fv.getIid());
                                    if (fv.getRecortable() != null && fv.getRecortable()) {
                                        listaPerfil.add(new CortePerfil(codigoLinea, lp));
                                    }
                                }
                            } else {
                                medida1S = Util.convertirPuntoAComa(String.valueOf(lp.getMedida1()));
                                cantidadS = Util.convertirPuntoAComa(String.valueOf(lp.getCantidad()));
                                listaPerfil.addAll(rd.getArticulosPerfil(medida1S, cantidadS, codigoLinea, lp));
                            }
                        }
                    }

                    if (listaPerfil != null && listaPerfil.size() > 0) {
                        final NuevoCortePerfil ncl = new NuevoCortePerfil(this, listaPerfil);
                        ncl.setDefaultCloseOperation(NuevoCortePerfil.DO_NOTHING_ON_CLOSE);
                        ncl.setLocationRelativeTo(null);
                        ncl.setVisible(true);
                        ncl.addWindowListener(new WindowAdapter() {
                            @Override
                            public void windowClosing(WindowEvent e) {
                                ncl.salir();
                            }
                        });
                    } else {
                        JOptionPane.showMessageDialog(null, "No hay ninguna lona", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                    crearDocInt();
                } else {
                    String mensaje = "No se puede ha podido modificar el elemento";
                    if (crear) {
                        mensaje = "No se puede ha podido insertar el elemento";
                    }
                    JOptionPane.showMessageDialog(null, mensaje, "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        }
        return guardar;
    }

private void jMenuItemDescuentoUnidadesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItemDescuentoUnidadesActionPerformed
    int guardar = 1;
    guardar = JOptionPane.showConfirmDialog(null, "Debe guardar el documento ¿Desea guardarlo?", "¿Guardar Presupuesto?", JOptionPane.YES_NO_OPTION);
    //hacerCambios = -1 ==> se ha pulsado la "x" de cancelar;
    //hacerCambios =  0 ==> se ha pulsado el "sÃ­"
    //hacerCambios =  1 ==> se ha pulsado el "no"
    if (guardar == 0) {
        if (actualizarPresupuesto()) {
            if (BaseDatos.guardarDocumento(p, fp2, cod_fp2, fp2_aux, listaArticulos, crear, cd, rellenarDacMap)) {
                JOptionPane.showMessageDialog(null, "Documento guardado", "Guardado", JOptionPane.INFORMATION_MESSAGE);
                crear = false;
                tnumero.setText(p.getNumero());

                //Se han de tomar todos los articulos (ya sea en en DAC o no) cuya FV = Unidades
                List listaNueva = BaseDatos.getListaLineaPresupuesto(p.getIid());
                Iterator<LineaPresupuesto> iter = listaNueva.iterator();
                LineaPresupuesto lp;
                int codigoLinea;
                Articulo arti;
                Caracteristica caract;
                RellenarDac rd;
                List<DesUnidades> listaArticulo = new ArrayList<DesUnidades>();
                DesUnidades unidades;
                FamiliaVenta fv;
                String cantidadS;

                while (iter.hasNext()) {
                    lp = iter.next();
                    if (lp.getArticulo_iid() != null) {
                        codigoLinea = lp.getCodigo();
                        rd = (RellenarDac) rellenarDacMap.get(codigoLinea);
                        if (rd == null) {
                            arti = lp.getArticulo_iid();
                            caract = lp.getCaracteristica();
                            if (arti != null) {
                                arti = BaseDatos.obtenerArticuloPorIid(arti.getIid());
                                fv = arti.getIid_fam_venta();
                                fv = BaseDatos.obtenerFamiliaVentaPorIid(fv.getIid());
                                if (caract != null) {
                                    caract = BaseDatos.obtenerCaracteristicaPorIid(caract.getIid());
                                }
                                //Si el tipo de control es cantidad, lo descontamos
                                if (fv.getIid_tipo_control().getIid_tipo_medida().getNombre().equals("Cantidad")) {
                                    unidades = new DesUnidades();
                                    unidades.setAr(arti);
                                    unidades.setCar(caract);
                                    unidades.setCantidad(lp.getCantidad());
                                    unidades.setIidLineaPresupuesto(lp.getIid());
                                    listaArticulo.add(unidades);
                                }
                            }
                        } else {
                            cantidadS = Util.convertirPuntoAComa(String.valueOf(lp.getCantidad()));
                            listaArticulo.addAll(rd.getArticulosCantidad(cantidadS, codigoLinea, lp));
                        }
                    }
                }

                if (listaArticulo != null && listaArticulo.size() > 0) {
                    if (BaseDatos.realizarDescuentoUnidades(p, listaArticulo)) {
                        JOptionPane.showMessageDialog(null, "Proceso de descuentos de unidades realizado correctamente", "Información", JOptionPane.INFORMATION_MESSAGE);
                        Float ex = 0.0F;
                        Iterator<DesUnidades> iterNuevo = listaArticulo.iterator();
                        //String mensajeStock = "";
                        StringBuffer bufferStock = new StringBuffer();
                        List<String> listaArticulosIncluidos = new ArrayList<String>();

                        while (iterNuevo.hasNext()) {
                            unidades = iterNuevo.next();
                            arti = unidades.getAr();
                            caract = unidades.getCar();
                            if (caract != null) {
                                if (caract.getStock_min() != null && caract.getStock_min()) {
                                    ex = BaseDatos.getExistenciaCaracteristica(arti, caract.getIid());
                                    //La cantidad restante es menor que el stock mÃ­nimo
                                    if (caract.getCantidad_stock_minimo() > ex && !listaArticulosIncluidos.contains(arti.getCod_articulo() + "--" + caract.getIid())) {
                                        String co = caract.getIid_color().getDescripcion();
                                        listaArticulosIncluidos.add(arti.getCod_articulo() + "--" + caract.getIid());
                                        bufferStock.append("El stock minimo del artículo ");
                                        bufferStock.append(arti.getDes_tecnica());
                                        bufferStock.append(" de color ");
                                        bufferStock.append(co);
                                        bufferStock.append(" ha sido sobrepasado (");
                                        bufferStock.append(ex);
                                        bufferStock.append(").\n");
                                    }
                                }
                            } else if (arti.getStockMinimo() != 0) {
                                ex = BaseDatos.getExistenciaCaracteristica(arti, null);
                                if (arti.getStockMinimo() > ex && !listaArticulosIncluidos.contains(arti.getCod_articulo())) {
                                    bufferStock.append("El stock minimo del artículo ");
                                    bufferStock.append(arti.getDes_tecnica());
                                    bufferStock.append(" ha sido sobrepasado (");
                                    bufferStock.append(ex);
                                    bufferStock.append(").\n");
                                    listaArticulosIncluidos.add(arti.getCod_articulo());
                                }
                            }
                        }

                        if (bufferStock.length() > 0) {
                            JOptionPane.showMessageDialog(null, bufferStock.toString(), "Stock Mínimo", JOptionPane.INFORMATION_MESSAGE);
                        }
                        crearDocInt();
                    } else {
                        JOptionPane.showMessageDialog(null, "No se ha podido realizar el descuento de unidades. Es posible que no haya unidades suficiente", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                /*
                //Crear movimientos negativos de almacÃ©n
                //Eliminar sÃ³lo los de unidades (implementar mÃ©todo)
                BaseDatos.elimnarMovimientoAlmacenDocumento(p);
                
                MovimientoAlmacen ma = new MovimientoAlmacen();
                Iterator i = listaArticulo.iterator();
                DesUnidades mlp = new DesUnidades();
                Date fecha = new Date(); // fecha y hora locales
                Caracteristica nCar = null;
                
                while (i.hasNext()) {
                // Creamos movimientos de almacen
                mlp = (DesUnidades) i.next();
                ma.setAlmacen(p.getAlmacen());
                ma.setArticulo(mlp.getAr());
                //Estamos descontando del almacen
                mlp.setCantidad(mlp.getCantidad());
                ma.setCantidad(Float.parseFloat(mlp.getCantidad().toString()));
                if (mlp.getCar() != null) {
                nCar = BaseDatos.obtenerCaracteristicaPorIid(mlp.getCar().getIid());
                ma.setCaracteristica(nCar);
                }
                
                ma.setConcepto("Pedido de fabricaciÃ³n: " + p.getNumero());
                ma.setEmpresa(e);
                
                SimpleDateFormat formatoFecha = new SimpleDateFormat("dd/MM/yyyy");
                ma.setFecha(fecha.getTime());
                
                ma.setModificable(false);
                
                TipoMovimientoAlmacen tma = BaseDatos.obtenerTipoMovimientoAlmacen(Constantes.SALIDA_FABRICACION);
                
                ma.setTipoMovimiento(tma);
                ma.setPresupuesto(p);
                
                BaseDatos.insertarMovimientoExistencia(ma);
                //Comprobamos el stock mÃ­nimo
                Float ex = 0.0F;
                
                if (nCar != null) {
                if (nCar.getStock_min() != null && nCar.getStock_min()) {
                ex = BaseDatos.getExistenciaCaracteristica(mlp.getAr(), nCar.getIid());
                //La cantidad restante es menor que el stock mÃ­nimo
                if (nCar.getCantidad_stock_minimo() > ex) {
                String co = nCar.getIid_color().getDescripcion();
                
                JOptionPane.showMessageDialog(null, "El stock mÃ­nimo del artÃ­culo " + mlp.getAr().getDes_tecnica() + " de color " + co + " ha sido sobrepasado (" + ex + ")", "Stock MÃ­nimo", JOptionPane.INFORMATION_MESSAGE);
                }
                }
                } else {
                if (mlp.getAr().getStockMinimo() != 0) {
                ex = BaseDatos.getExistenciaCaracteristica(mlp.getAr(), null);
                if (mlp.getAr().getStockMinimo() > ex) {
                
                JOptionPane.showMessageDialog(null, "El stock mÃ­nimo del artÃ­culo " + mlp.getAr().getDes_tecnica() + " ha sido sobrepasado (" + ex + ")", "Stock MÃ­nimo", JOptionPane.INFORMATION_MESSAGE);
                }
                
                }
                }
                
                }
                 */
                } else {
                    JOptionPane.showMessageDialog(null, "No hay ningun artículo cantidad", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                String mensaje = "No se puede ha podido modificar el elemento";
                if (crear) {
                    mensaje = "No se puede ha podido insertar el elemento";
                }
                JOptionPane.showMessageDialog(null, mensaje, "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
}//GEN-LAST:event_jMenuItemDescuentoUnidadesActionPerformed

    private void jMenuItemMontajeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItemMontajeActionPerformed
        generarMontaje gM = new generarMontaje(e, u, p);
        gM.setDefaultCloseOperation(NuevoPresupuesto.DISPOSE_ON_CLOSE);
        gM.setLocationRelativeTo(null);
        gM.setVisible(true);
    }//GEN-LAST:event_jMenuItemMontajeActionPerformed

private void jMenuItemVerCorteLonaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItemVerCorteLonaActionPerformed
    int numCorteLona = 0;
    if (this.p.getIid() != null) {
        List<LineaCorteLona> listaLineacorteLonaBBDD = BaseDatos.getListaLineaCorteLona(this.p.getIid());
        if (listaLineacorteLonaBBDD != null) {
            numCorteLona = listaLineacorteLonaBBDD.size();
        }

        if (numCorteLona > 0) {
            Integer clave;
            RellenarDac rd;
            Dac dac;
            NuevaLineaPresupuesto nlp;
            LineaConfeccionTotal lct;
            Iterator iter = null;
            LineaCorteLona lcl;
            DespiecePresupuesto dp;
            Despiece d;
            Articulo articuloBase;
            List<LineaConfeccionTotal> llct = new ArrayList<LineaConfeccionTotal>();
            Float cantidad1;
            HashMap parameters = new HashMap();
            String cantidadTemporal;
            String contadorLineaStr;

            parameters.put("numero", getNumero());
            parameters.put("referencia", getReferencia());
            parameters.put("cliente", getNombreCliente());
            parameters.put("fecha", tfecha.getText());

            for (Iterator it = rellenarDacMap.keySet().iterator(); it.hasNext();) {
                clave = (Integer) it.next();
                rd = (RellenarDac) rellenarDacMap.get(clave);
                rd = getRellenarDac(clave);
                dac = rd.getDacBase();
                nlp = (NuevaLineaPresupuesto) listaArticulos.get(clave - 1);
                cantidad1 = Float.parseFloat(Util.convertirComaAPunto(nlp.getTcantidad()));
                if (nlp.getTcantidad() != null && nlp.getTcantidad().length() > 0) {
                    dac.setCantidad(Double.parseDouble(Util.convertirComaAPunto(nlp.getTcantidad())));
                } else {
                    dac.setCantidad(0D);
                }

                if (nlp.getTMedida1() != null && nlp.getTMedida1().length() > 0) {
                    dac.setMedida1(Double.parseDouble(Util.convertirComaAPunto(nlp.getTMedida1())));
                } else {
                    dac.setMedida1(0D);
                }

                if (nlp.getTMedida2() != null && nlp.getTMedida2().length() > 0) {
                    dac.setMedida2(Double.parseDouble(Util.convertirComaAPunto(nlp.getTMedida2())));
                } else {
                    dac.setMedida2(0D);
                }

                if (nlp.getTMedida3() != null && nlp.getTMedida3().length() > 0) {
                    dac.setMedida3(Double.parseDouble(Util.convertirComaAPunto(nlp.getTMedida3())));
                } else {
                    dac.setMedida3(0D);
                }

                if (nlp.getTMedida5() != null && nlp.getTMedida5().length() > 0) {
                    dac.setMedida4(Double.parseDouble(Util.convertirComaAPunto(nlp.getTMedida5())));
                } else {
                    dac.setMedida4(0D);
                }

                if (nlp.getTMedida5() != null && nlp.getTMedida5().length() > 0) {
                    dac.setMedida5(Double.parseDouble(Util.convertirComaAPunto(nlp.getTMedida5())));
                } else {
                    dac.setMedida5(0D);
                }

                rd.setDacBase(dac);
                rd = new RellenarDac(rd, this, "Titulo");

                lct = new LineaConfeccionTotal();
                lct.setDato("dac");
                lct.setCodigoToldo(nlp.getTCodigo());
                lct.setDescripcionDAC(nlp.getArticulo().getDes_tecnica());
                lct.setCantidad(nlp.getTcantidad());
                lct.setMedidaDac(nlp.getTMedida1() + " x " + nlp.getTMedida2());
                lct.setImagenConfeccion(null);
                llct.add(lct);

                String articulos = "";

                /*if(!rd.getLona().equals("")){
                articulos += "Lona: " + rd.getLona() + "\n";
                }
                
                if(!rd.getFaldon().equals("")){
                articulos += "Faldón: " + rd.getFaldon() + "\n";
                }
                
                if(!rd.getTipoFaldon().equals("")){
                articulos += "Tipo faldón: " + rd.getTipoFaldon() + "\n";
                }
                
                if(!rd.getRibete().equals("")){
                articulos += "Ribete: " + rd.getRibete() + "\n";
                }
                
                if(!rd.getManivela().equals("")){
                articulos += "Manivela: " + rd.getManivela() + "\n";
                }
                
                if(!rd.getBrazos().equals("")){
                articulos += "Brazos: " + rd.getBrazos() + "\n";
                }
                
                if(!rd.getMotor().equals("")){
                articulos += "Motor: " + rd.getMotor() + "\n";
                }
                
                if(!rd.getTuboEnrrolle().equals("")){
                articulos += "T. enrrolle: " + rd.getTuboEnrrolle() + "\n";
                }
                
                if(!rd.getTuboCarga().equals("")){
                articulos += "T. carga: " + rd.getTuboCarga() + "\n";
                }*/

                List<LineaCorteLona> llcl = BaseDatos.getListaLineaCorteLonaByLineaPresupuesto(nlp.getIid());

                if (llcl != null && llcl.size() > 0) {
                    iter = llcl.iterator();
                    while (iter.hasNext()) {
                        contadorLineaStr = "L" + clave;
                        lcl = (LineaCorteLona) iter.next();
                        lct = new LineaConfeccionTotal();
                        lct.setDato("articulo");
                        lct.setContadorLinea(contadorLineaStr);
                        lct.setNumeroDoc(getNumero());
                        lct.setCorte("Corte de tipo " + lcl.getTipoCorteLona());

                        if (lcl.getEsDespiece()) {
                            dp = BaseDatos.obtenerDespiecePresupuestoByIid(lcl.getDespiece().getIid());
                            d = dp.clonar();
                            articuloBase = BaseDatos.obtenerArticuloPorIid(dp.getArticulo().getIid());
                            lct.setCodigo(articuloBase.getCod_articulo());
                            cantidadTemporal = Util.convertirPuntoAComa(String.valueOf(rd.evaluar(cantidad1 + "*(" + dp.getFormulaCantidad() + ")", dp.getRedondeo(), false)));
                            lct.setCant(cantidadTemporal);
                            lct.setMedidaArticulo(Util.convertirPuntoAComa(String.valueOf(rd.evaluar(dp.getFormulaMedida1(), dp.getRedondeo(), false))) + " x " + Util.convertirPuntoAComa(String.valueOf(rd.evaluar(dp.getFormulaMedida2(), dp.getRedondeo(), false))));
                            lct.setDescripcionArticulo(articuloBase.getDes_tecnica());
                        } else {
                            lct.setCodigo(nlp.getTCodigo());
                            lct.setMedidaArticulo(nlp.getTMedida1() + " x" + nlp.getTMedida2());
                            lct.setCant(nlp.getTcantidad());
                            lct.setDescripcionArticulo(nlp.getArticulo().getDes_tecnica());
                        }
                        lct.setArticulos(articulos);
                        lct.setImagenConfeccion(Util.pintarLona(lcl.getTipoCorteLona(), lcl.getLinea().toString(), lcl.getSalida().toString(), lcl.getDobladillo().toString(), lcl.getSolape().toString(), lcl.getAnchoSeleccionado().floatValue()));
                        llct.add(lct);
                    }
                }
            }
            parameters.put("LineaLonaTotal", new JRBeanCollectionDataSource(llct));
            ConfeccionLonasTotal.imprimirConfeccionLonasTotal(parameters);
        } else {
            NuevoCorteLonaSimulado ncs = new NuevoCorteLonaSimulado(this);
            ncs.setDefaultCloseOperation(NuevoArticulo.DISPOSE_ON_CLOSE);
            ncs.setLocationRelativeTo(null);
            ncs.setVisible(true);
        }
    } else {
        JOptionPane.showMessageDialog(null, "El documento aún no ha sido guardado", "Error", JOptionPane.INFORMATION_MESSAGE);
    }
}//GEN-LAST:event_jMenuItemVerCorteLonaActionPerformed

    private void bVerEntregasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bVerEntregasActionPerformed
        ListaEntregasFecha ef = new ListaEntregasFecha(e, cFechaEntrega.getDate());
        ef.setDefaultCloseOperation(NuevoPresupuesto.DISPOSE_ON_CLOSE);
        ef.setLocationRelativeTo(null);
        ef.setVisible(true);
    }//GEN-LAST:event_bVerEntregasActionPerformed

    private void bVerNotasClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bVerNotasClienteActionPerformed
        String codigo = tCodCliente.getText();
        String tipo = "cli";
        String tipoCompleto = "cliente";

        if (cd.getDescripcion().equals(Constantes.PEDIDOC) || cd.getDescripcion().equals(Constantes.ALBARANC) || cd.getDescripcion().equals(Constantes.FACTURAC)) {
            tipo = "prov";
            tipoCompleto = "proveedor";
        }

        Agentes ag = BaseDatos.obtenerAgentesPorCodigo(codigo, tipo, e);
        if (ag == null) {
            JOptionPane.showMessageDialog(null, "El " + tipoCompleto + " no está almacenado en la base de datos", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            String obs = ag.getObservaciones();
            if (obs != null && obs.length() > 0) {
                VerNotaCliente vnc = new VerNotaCliente(obs);
                vnc.setDefaultCloseOperation(VerNotaCliente.DISPOSE_ON_CLOSE);
                vnc.setLocationRelativeTo(null);
                vnc.setVisible(true);
            } else {
                JOptionPane.showMessageDialog(null, "El " + tipoCompleto + " no tiene observaciones asociadas", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }//GEN-LAST:event_bVerNotasClienteActionPerformed

    private void bCrearVencimientoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bCrearVencimientoActionPerformed
        double importeParaVencimiento = Double.valueOf(Util.convertirComaAPunto(this.lprecio_final.getText()));
        int numFilasVencimiento = tvencimientos.getRowCount();
        if (numFilasVencimiento > 0 && numFilasVencimiento < 10) {
            Vencimiento pl = new Vencimiento(numFilasVencimiento, importeParaVencimiento, fp2, this);
            pl.setDefaultCloseOperation(Plazo.DISPOSE_ON_CLOSE);
            pl.setLocationRelativeTo(null);
            pl.setVisible(true);
        } else if (numFilasVencimiento == 0) {
            JOptionPane.showMessageDialog(null, "Debe haber al menos algún vencimiento", "Error", JOptionPane.ERROR_MESSAGE);
        } else if (numFilasVencimiento > 9) {
            JOptionPane.showMessageDialog(null, "Ya tiene creados 10 vencimientos", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_bCrearVencimientoActionPerformed

    private void bGuardarClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bGuardarClienteActionPerformed
        boolean isCPnumerico = true;
        Integer cpNumerico = -1;
        String nombreCliente = this.tNombreCliente.getText();
        String codigoCliente = this.tCodCliente.getText();

        if (nombreCliente != null && nombreCliente.length() > 0 && codigoCliente != null && codigoCliente.length() > 0) {
            try {
                if (tCpCliente.getText().length() > 0) {
                    cpNumerico = new Integer(this.tCpCliente.getText());
                }
            } catch (Exception ex) {
                isCPnumerico = false;
            }

            if (isCPnumerico) {
                //Comprobamos si existe el código de cliente
                Agentes cliente = BaseDatos.obtenerAgentesPorCodigo(tCodCliente.getText(), "cli", e);
                if (cliente == null) {
                    TipoAgente tipo = BaseDatos.obtenerTipoAgente("Cliente");
                    Agentes nuevoCliente = new Agentes();
                    nuevoCliente.setCod_agente(this.tCodCliente.getText());
                    nuevoCliente.setCif_nif(this.tDniCliente.getText());
                    nuevoCliente.setNombre_comercial(this.tNombreCliente.getText());
                    nuevoCliente.setNombre_fiscal(this.tNombreCliente.getText());
                    nuevoCliente.setTelefono(this.tTelefonoCliente.getText());
                    nuevoCliente.setDireccion(this.tDireccionCliente.getText());
                    nuevoCliente.setDireccion_fiscal(this.tDireccionCliente.getText());
                    nuevoCliente.setCodigo_postal(new Integer(this.tCpCliente.getText()));
                    nuevoCliente.setCodigo_postal_fiscal(new Integer(this.tCpCliente.getText()));
                    nuevoCliente.setProvincia(this.tProvinciaCliente.getText());
                    nuevoCliente.setProvincia_fiscal(this.tProvinciaCliente.getText());
                    nuevoCliente.setPoblacion(this.tLocalidadCliente.getText());
                    nuevoCliente.setPoblacion_fiscal(this.tLocalidadCliente.getText());
                    nuevoCliente.setPais(this.tPaisCliente.getText());
                    nuevoCliente.setEmail(this.tEmailCliente.getText());
                    nuevoCliente.setTipo_agente(tipo);
                    nuevoCliente.setIid_empresa(e);

                    if (BaseDatos.insertarElemento(nuevoCliente)) {
                        JOptionPane.showMessageDialog(null, "Cliente almacenado correctamente", "Información", JOptionPane.INFORMATION_MESSAGE);
                    } else {
                        JOptionPane.showMessageDialog(null, "Se ha producido un error al almacenar el cliente", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                } else {
                    TipoAgente tipo = BaseDatos.obtenerTipoAgente("Cliente");
                    cliente.setCod_agente(this.tCodCliente.getText());
                    cliente.setCif_nif(this.tDniCliente.getText());
                    cliente.setNombre_comercial(this.tNombreCliente.getText());
                    cliente.setNombre_fiscal(this.tNombreCliente.getText());
                    cliente.setTelefono(this.tTelefonoCliente.getText());
                    cliente.setDireccion(this.tDireccionCliente.getText());
                    cliente.setDireccion_fiscal(this.tDireccionCliente.getText());
                    cliente.setCodigo_postal(new Integer(this.tCpCliente.getText()));
                    cliente.setCodigo_postal_fiscal(new Integer(this.tCpCliente.getText()));
                    cliente.setProvincia(this.tProvinciaCliente.getText());
                    cliente.setProvincia_fiscal(this.tProvinciaCliente.getText());
                    cliente.setPoblacion(this.tLocalidadCliente.getText());
                    cliente.setPoblacion_fiscal(this.tLocalidadCliente.getText());
                    cliente.setPais(this.tPaisCliente.getText());
                    cliente.setEmail(this.tEmailCliente.getText());
                    cliente.setTipo_agente(tipo);
                    cliente.setIid_empresa(e);
                    if (BaseDatos.modificarElemento(cliente)) {
                        JOptionPane.showMessageDialog(null, "Cliente modificado correctamente", "Información", JOptionPane.INFORMATION_MESSAGE);
                    } else {
                        JOptionPane.showMessageDialog(null, "Se ha producido un error al modificar el cliente", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
            } else {
                JOptionPane.showMessageDialog(null, "El Código postal del cliente debe ser numérico", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(null, "Debe introducir el nombre y el código", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_bGuardarClienteActionPerformed
    private void tRecomendadoPorKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tRecomendadoPorKeyReleased
        String campo = tRecomendadoPor.getText();
        if (campo.length() > Constantes.TAM_RECOMENDADO_POR) {
            JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_RECOMENDADO_POR, "Error", JOptionPane.ERROR_MESSAGE);
            tRecomendadoPor.setText(campo.substring(0, Constantes.TAM_RECOMENDADO_POR));
        }
    }//GEN-LAST:event_tRecomendadoPorKeyReleased

    private void tEmailClienteKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tEmailClienteKeyReleased
        String campo = tEmailCliente.getText();
        if (campo.length() > Constantes.TAM_EMAIL_CLIENTE_PRESUPUESTO) {
            JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_EMAIL_CLIENTE_PRESUPUESTO, "Error", JOptionPane.ERROR_MESSAGE);
            tEmailCliente.setText(campo.substring(0, Constantes.TAM_EMAIL_CLIENTE_PRESUPUESTO));
        }
}//GEN-LAST:event_tEmailClienteKeyReleased

    private void tCpClienteKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tCpClienteKeyReleased
        String campo = tCpCliente.getText();
        if (campo.length() > Constantes.TAM_CP_CLIENTE_PRESUPUESTO) {
            JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_CP_CLIENTE_PRESUPUESTO, "Error", JOptionPane.ERROR_MESSAGE);
            tCpCliente.setText(campo.substring(0, Constantes.TAM_CP_CLIENTE_PRESUPUESTO));
        }
    }//GEN-LAST:event_tCpClienteKeyReleased

    private void cComercialActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cComercialActionPerformed
        String nombreComercial = (String) cComercial.getSelectedItem();
        if (!nombreComercial.equals(Constantes.SELECCIONE_COMERCIAL)) {
            comercial = BaseDatos.obtenerComercialPorNombre(nombreComercial);
        } else {
            comercial = null;
        }
    }//GEN-LAST:event_cComercialActionPerformed

    private void tTelefonoClienteKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tTelefonoClienteKeyReleased
        String campo = tTelefonoCliente.getText();
        if (campo.length() > Constantes.TAM_TELEFONO_CLIENTE_PRESUPUESTO) {
            JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_TELEFONO_CLIENTE_PRESUPUESTO, "Error", JOptionPane.ERROR_MESSAGE);
            tTelefonoCliente.setText(campo.substring(0, Constantes.TAM_TELEFONO_CLIENTE_PRESUPUESTO));
        }
    }//GEN-LAST:event_tTelefonoClienteKeyReleased

    private void tPaisClienteKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tPaisClienteKeyReleased
        String campo = tPaisCliente.getText();
        if (campo.length() > Constantes.TAM_PAIS_CLIENTE_PRESUPUESTO) {
            JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_PAIS_CLIENTE_PRESUPUESTO, "Error", JOptionPane.ERROR_MESSAGE);
            tPaisCliente.setText(campo.substring(0, Constantes.TAM_PAIS_CLIENTE_PRESUPUESTO));
        }
    }//GEN-LAST:event_tPaisClienteKeyReleased

    private void bMandarMailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bMandarMailActionPerformed
        if (tEmailCliente.getText() != null && !tEmailCliente.getText().equals("")) {
            int guardar = 1;
            guardar = JOptionPane.showConfirmDialog(null, "Para mandar el mail primero debe guardar el presupuesto ¿Desea guardarlo?", "¿Guardar Presupuesto?", JOptionPane.YES_NO_OPTION);
            //hacerCambios = -1 ==> se ha pulsado la "x" de cancelar;
            //hacerCambios =  0 ==> se ha pulsado el "sí"
            //hacerCambios =  1 ==> se ha pulsado el "no"
            if (guardar == 0) {
                if (actualizarPresupuesto()) {
                    boolean correcto = true;
                    if (BaseDatos.guardarDocumento(p, fp2, cod_fp2, fp2_aux, listaArticulos, crear, cd, rellenarDacMap)) {
                        String accion = "Presupuesto Modificado";
                        if (crear) {
                            accion = "Nuevo Presupuesto";
                        }
                        audi(p, accion, this.e, this.u);
                        crearDocInt();
                    } else {
                        String mensaje = "No se puede ha podido modificar el elemento";
                        if (crear) {
                            mensaje = "No se puede ha podido insertar el elemento";
                        }
                        JOptionPane.showMessageDialog(null, mensaje, "Error", JOptionPane.ERROR_MESSAGE);
                        correcto = false;
                    }

                    if (correcto) {
                        crear = false;
                        HashMap parametros = crearHashMapParametros();
                        String rutaPresupuesto = Informe.crearPresupuestoEmail(parametros);
                        EnviarMail nnd = new EnviarMail("Presupuesto Toldos Víctor Manuel", this.tEmailCliente.getText(), rutaPresupuesto, p, u.getPie(), e.getUrlWeb());
                        nnd.setDefaultCloseOperation(NuevaNotaDocumento.DISPOSE_ON_CLOSE);
                        nnd.setLocationRelativeTo(null);
                        nnd.setVisible(true);
                    }
                }
            }
        } else {
            JOptionPane.showMessageDialog(null, "No hay seleccionado ningúna dirección de correo", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_bMandarMailActionPerformed

    private void bCrearPdfActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bCrearPdfActionPerformed
        if (fp2 == null) {
            JOptionPane.showMessageDialog(null, "Debe seleccionar la forma de pago", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            JFileChooser example = new JFileChooser() {

                @Override
                public void approveSelection() {
                    File f = getSelectedFile();
                    if (f.exists() && getDialogType() == SAVE_DIALOG) {
                        int result = JOptionPane.showConfirmDialog(this, "El archivo ya existe, ¿Desea sobreescribirlo?", "El archivo ya existe", JOptionPane.YES_NO_CANCEL_OPTION);
                        switch (result) {
                            case JOptionPane.YES_OPTION:
                                super.approveSelection();
                                return;
                            case JOptionPane.NO_OPTION:
                                return;
                            case JOptionPane.CANCEL_OPTION:
                                cancelSelection:
                                return;
                        }
                    }
                    super.approveSelection();
                }
            };
            example.setDialogTitle("Guardar");
            example.setMultiSelectionEnabled(false);
            example.setAcceptAllFileFilterUsed(false);
            example.setFileSelectionMode(JFileChooser.FILES_ONLY);
            PdfFilter pf = new PdfFilter();
            example.setFileFilter(pf);
            int sel = example.showSaveDialog(this);
            if (sel == JFileChooser.APPROVE_OPTION) {
                File selectedFile = example.getSelectedFile();
                HashMap parametros = crearHashMapParametros();
                String ruta = selectedFile.getAbsolutePath();
                if (!ruta.endsWith(".pdf")) {
                    ruta += ".pdf";
                }
                Informe.guardarPresupuesto(parametros, ruta);
            }
        }
    }//GEN-LAST:event_bCrearPdfActionPerformed

    private void bImprimirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bImprimirActionPerformed
        jMenuPDFActionPerformed(null);
    }//GEN-LAST:event_bImprimirActionPerformed

    private void cContactadoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cContactadoActionPerformed
        String contactado = (String) cContactado.getSelectedItem();
        if (contactado != null && contactado.equals(Constantes.COMERCIALES)) {
            cComercial.setVisible(true);
            tRecomendadoPor.setVisible(false);
        } else if (contactado != null && contactado.equals(Constantes.RECOMENDADO)) {
            tRecomendadoPor.setVisible(true);
            tRecomendadoPor.setText("--Recomendado--");
            tRecomendadoPor.requestFocus();
            cComercial.setVisible(false);
            comercial = null;
        } else {
            cComercial.setVisible(false);
            comercial = null;
            tRecomendadoPor.setVisible(false);
        }
        this.validate();
        this.pack();
        this.repaint();
        Dimension dim = Util.getDimensiones(this.getSize());
        if (dim != null) {
            setResizable(true);
            setSize(dim);
            setResizable(false);
        }
    }//GEN-LAST:event_cContactadoActionPerformed

    private void tDireccionClienteKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tDireccionClienteKeyReleased
        String campo = tDireccionCliente.getText();
        if (campo.length() > Constantes.TAM_DIRECCION_CLIENTE_PRESUPUESTO) {
            JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_DIRECCION_CLIENTE_PRESUPUESTO, "Error", JOptionPane.ERROR_MESSAGE);
            tDireccionCliente.setText(campo.substring(0, Constantes.TAM_DIRECCION_CLIENTE_PRESUPUESTO));
        }
    }//GEN-LAST:event_tDireccionClienteKeyReleased

    private void binsertarClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_binsertarClienteActionPerformed
        ListaDeClientes ldc = new ListaDeClientes(this, e);
        ldc.setDefaultCloseOperation(ListaDeClientes.DISPOSE_ON_CLOSE);
        ldc.setLocationRelativeTo(null);
        ldc.setVisible(true);
    }//GEN-LAST:event_binsertarClienteActionPerformed

    private void tCodClienteKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tCodClienteKeyReleased
        String campo = tCodCliente.getText();
        if (campo.length() > Constantes.TAM_CODIGO_CLIENTE_PRESUPUESTO) {
            JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_CODIGO_CLIENTE_PRESUPUESTO, "Error", JOptionPane.ERROR_MESSAGE);
            tCodCliente.setText(campo.substring(0, Constantes.TAM_CODIGO_CLIENTE_PRESUPUESTO));
        }
    }//GEN-LAST:event_tCodClienteKeyReleased

    private void tNombreClienteKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tNombreClienteKeyReleased
        String campo = tNombreCliente.getText();
        if (campo.length() > Constantes.TAM_NOMBRE_CLIENTE_PRESUPUESTO) {
            JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_NOMBRE_CLIENTE_PRESUPUESTO, "Error", JOptionPane.ERROR_MESSAGE);
            tNombreCliente.setText(campo.substring(0, Constantes.TAM_NOMBRE_CLIENTE_PRESUPUESTO));
        }
    }//GEN-LAST:event_tNombreClienteKeyReleased

    private void tProvinciaClienteKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tProvinciaClienteKeyReleased
        String campo = tProvinciaCliente.getText();
        if (campo.length() > Constantes.TAM_PROVINCIA_CLIENTE_PRESUPUESTO) {
            JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_PROVINCIA_CLIENTE_PRESUPUESTO, "Error", JOptionPane.ERROR_MESSAGE);
            tProvinciaCliente.setText(campo.substring(0, Constantes.TAM_PROVINCIA_CLIENTE_PRESUPUESTO));
        }
    }//GEN-LAST:event_tProvinciaClienteKeyReleased

    private void tLocalidadClienteKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tLocalidadClienteKeyReleased
        String campo = tLocalidadCliente.getText();
        if (campo.length() > Constantes.TAM_LOCALIDAD_CLIENTE_PRESUPUESTO) {
            JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_LOCALIDAD_CLIENTE_PRESUPUESTO, "Error", JOptionPane.ERROR_MESSAGE);
            tLocalidadCliente.setText(campo.substring(0, Constantes.TAM_LOCALIDAD_CLIENTE_PRESUPUESTO));
        }
    }//GEN-LAST:event_tLocalidadClienteKeyReleased

    private void tReferenciaKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tReferenciaKeyReleased
        String campo = tReferencia.getText();
        if (campo.length() > Constantes.TAM_REFERENCIA_PRESUPUESTO) {
            JOptionPane.showMessageDialog(null, "El tamaño máximo del campo es " + Constantes.TAM_REFERENCIA_PRESUPUESTO, "Error", JOptionPane.ERROR_MESSAGE);
            tReferencia.setText(campo.substring(0, Constantes.TAM_REFERENCIA_PRESUPUESTO));
        }
    }//GEN-LAST:event_tReferenciaKeyReleased

    private void cSeriesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cSeriesActionPerformed
        String cifCliente = tDniCliente.getText();
        if (cifCliente != null && !cifCliente.equals("")) {
            Object[] cliente = BaseDatos.obtenerAgentePorEmpresaYCodigoPresupuestoReducido(e.getIid(), tCodCliente.getText());
            Agentes newCliente = new Agentes();
            if (cliente[0] != null) {
                newCliente.setObservaciones((String) cliente[0]);
            }
            if (cliente[1] != null) {
                newCliente.setIva((Iva) cliente[1]);
            }
            if (cliente[2] != null) {
                newCliente.setExento_iva((Boolean) cliente[2]);
            }
            calcularNuevoIva(newCliente);
        }
    }//GEN-LAST:event_cSeriesActionPerformed

    private void bVerNotasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bVerNotasActionPerformed
        NuevaNotaDocumento nnd = new NuevaNotaDocumento(p, "vis");
        nnd.setDefaultCloseOperation(NuevaNotaDocumento.DISPOSE_ON_CLOSE);
        nnd.setLocationRelativeTo(null);
        nnd.setVisible(true);
    }//GEN-LAST:event_bVerNotasActionPerformed

    private void bAnadirNotasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bAnadirNotasActionPerformed
        NuevaNotaDocumento nnd = new NuevaNotaDocumento(p, this);
        nnd.setDefaultCloseOperation(NuevaNotaDocumento.DISPOSE_ON_CLOSE);
        nnd.setLocationRelativeTo(null);
        nnd.setVisible(true);
    }//GEN-LAST:event_bAnadirNotasActionPerformed

    private void bmodificarplazoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bmodificarplazoActionPerformed
        visualizarPlazoAdelantado();
    }//GEN-LAST:event_bmodificarplazoActionPerformed

    private void tObservacionesKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tObservacionesKeyReleased
        String observaciones = tObservaciones.getText();
        if (observaciones.length() >= Constantes.TAM_OBSERVACIONES_PRESUPUESTO) {
            JOptionPane.showMessageDialog(null, "El tamaño de las observaciones no puede pasar de " + Constantes.TAM_OBSERVACIONES_PRESUPUESTO + " caracteres", "Error", JOptionPane.ERROR_MESSAGE);
            observaciones = observaciones.substring(0, Constantes.TAM_OBSERVACIONES_PRESUPUESTO);
            tObservaciones.setText(observaciones);
        }
    }//GEN-LAST:event_tObservacionesKeyReleased

    private void bcancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bcancelarActionPerformed
        cerrarPresupuesto();
    }//GEN-LAST:event_bcancelarActionPerformed

    private void beliminarvencimientoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_beliminarvencimientoActionPerformed
        eliminarVencimiento();
    }//GEN-LAST:event_beliminarvencimientoActionPerformed

    private void baceptarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_baceptarActionPerformed
        if (actualizarPresupuesto()) {
            if (BaseDatos.guardarDocumento(p, fp2, cod_fp2, fp2_aux, listaArticulos, crear, cd, rellenarDacMap)) {
                //obtener documento
                String accion = p.getClase_documento().getDescripcion() + " Modificado";
                if (crear) {
                    //obtener documento
                    accion = "Nuevo " + p.getClase_documento().getDescripcion();
                }
                audi(p, accion, this.e, this.u);
                JOptionPane.showMessageDialog(null, "Documento guardado", "Guardado", JOptionPane.INFORMATION_MESSAGE);
                crearDocInt();
                mensajesInternos();
                cerrarPresupuesto();
            } else {
                String mensaje = "Error al modificar el documento";
                if (crear) {
                    mensaje = "Error al intentar crear el documento";
                }
                JOptionPane.showMessageDialog(null, mensaje, "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }//GEN-LAST:event_baceptarActionPerformed

    private void cformapagoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cformapagoActionPerformed
        String sfp = (String) cformapago.getSelectedItem();

        if (!creacion) {
            limpiarPlazosAdelantados();
            limpiarVencimientos();
            if (!sfp.equals(Constantes.VACIO)) {
                fp = BaseDatos.obtenerFormaPago(sfp);
                fp2 = new FormaPago2(fp);
                tformapago.setText(fp2.getDescripcioncliente());
                rellenarPlazosAdelantados();
                rellenarVencimientos();
            } else {
                bcrearplazo.setEnabled(false);
                beliminarplazo.setEnabled(false);
                bmodificarplazo.setEnabled(false);
                bCrearVencimiento.setEnabled(false);
                beliminarvencimiento.setEnabled(false);
                bmodificarvencimiento.setEnabled(false);
                fp = null;
                fp2 = null;
            }
        }

        if (!sfp.equals(Constantes.VACIO)) {
            bcrearplazo.setEnabled(true);
            beliminarplazo.setEnabled(true);
            bmodificarplazo.setEnabled(true);
            bCrearVencimiento.setEnabled(true);
            beliminarvencimiento.setEnabled(true);
            bmodificarvencimiento.setEnabled(true);
        }
    }//GEN-LAST:event_cformapagoActionPerformed

    private void beliminarplazoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_beliminarplazoActionPerformed
        borrarPlazoAdelantado();
    }//GEN-LAST:event_beliminarplazoActionPerformed

    private void bguardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bguardarActionPerformed
        if (actualizarPresupuesto()) {
            if (BaseDatos.guardarDocumento(p, fp2, cod_fp2, fp2_aux, listaArticulos, crear, cd, rellenarDacMap)) {
                tnumero.setText(p.getNumero());
                String accion = "Presupuesto Modificado";
                if (crear) {
                    accion = "Nuevo Presupuesto";
                }
                audi(p, accion, this.e, this.u);
                JOptionPane.showMessageDialog(null, "Documento guardado", "Guardado", JOptionPane.INFORMATION_MESSAGE);
                //Envíamos los mensajes internos pertinentes
                mensajesInternos();
                crearDocInt();
                crear = false;
            } else {
                String mensaje = "No se puede ha podido modificar el elemento";
                if (crear) {
                    mensaje = "No se puede ha podido insertar el elemento";
                }
                JOptionPane.showMessageDialog(null, mensaje, "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }//GEN-LAST:event_bguardarActionPerformed

    private void tdtoKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tdtoKeyReleased
        int codigo = evt.getKeyCode();
        if (codigo != KeyEvent.VK_BACK_SPACE && codigo != KeyEvent.VK_ENTER && codigo != KeyEvent.VK_DELETE && codigo != KeyEvent.VK_LEFT && codigo != KeyEvent.VK_RIGHT) {
            char c = evt.getKeyChar();
            int carePosition = tIva.getCaretPosition();
            String contenidoAntiguo = tIva.getText().replace(".", ",");
            int indiceComaPuntoUltimo = contenidoAntiguo.lastIndexOf(",");
            int indiceComaPuntoPrimero = contenidoAntiguo.indexOf(',');

            if (!(c >= '0' && c <= '9') && c != '.' && c != ',') {
                contenidoAntiguo = contenidoAntiguo.replace(String.valueOf(c), "");
                carePosition--;
            }

            if (indiceComaPuntoUltimo != indiceComaPuntoPrimero) {
                contenidoAntiguo = contenidoAntiguo.replaceFirst(",", "");
                if (indiceComaPuntoUltimo <= carePosition) {
                    carePosition--;
                }
            }

            if (carePosition > contenidoAntiguo.length()) {
                carePosition = contenidoAntiguo.length();
            }

            tIva.setText(contenidoAntiguo);
            tIva.setCaretPosition(carePosition);
            calcularPrecio(true);
        } else if (codigo == KeyEvent.VK_BACK_SPACE || codigo == KeyEvent.VK_DELETE) {
            calcularPrecio(true);
        }
    }//GEN-LAST:event_tdtoKeyReleased

    private void tvencimientosKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tvencimientosKeyPressed
        if (evt.getKeyChar() == KeyEvent.VK_ENTER) {
            visualizarVencimiento();
        } else if (evt.getKeyChar() == KeyEvent.VK_DELETE) {
            eliminarVencimiento();
        }
    }//GEN-LAST:event_tvencimientosKeyPressed

    private void tvencimientosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tvencimientosMouseClicked
        if (tvencimientos.getSelectedRowCount() != 0) {
            beliminarvencimiento.setEnabled(true);
        }
        if (tvencimientos.getSelectedRowCount() != 0) {
            bmodificarvencimiento.setEnabled(true);
        }

        if (evt.getClickCount() == 2) {
            visualizarVencimiento();
        }
    }//GEN-LAST:event_tvencimientosMouseClicked

    private void tplazosadelantadosKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tplazosadelantadosKeyPressed
        if (evt.getKeyChar() == KeyEvent.VK_ENTER) {
            visualizarPlazoAdelantado();
        } else if (evt.getKeyChar() == KeyEvent.VK_DELETE) {
            borrarPlazoAdelantado();
        }
    }//GEN-LAST:event_tplazosadelantadosKeyPressed

    private void tplazosadelantadosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tplazosadelantadosMouseClicked
        if (tplazosadelantados.getSelectedRowCount() != 0) {
            beliminarplazo.setEnabled(true);
        }
        if (tplazosadelantados.getSelectedRowCount() != 0) {
            bmodificarplazo.setEnabled(true);
        }

        if (evt.getClickCount() == 2) {
            visualizarPlazoAdelantado();
        }
    }//GEN-LAST:event_tplazosadelantadosMouseClicked

    private void bcrearplazoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bcrearplazoActionPerformed
        double importeParaPlazo = Double.valueOf(Util.convertirComaAPunto(this.lprecio_final.getText()));
        Plazo pl = new Plazo(importeParaPlazo, fp2, this);
        pl.setDefaultCloseOperation(Plazo.DISPOSE_ON_CLOSE);
        pl.setLocationRelativeTo(null);
        pl.setVisible(true);
    }//GEN-LAST:event_bcrearplazoActionPerformed

    private void bmodificarvencimientoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bmodificarvencimientoActionPerformed
        visualizarVencimiento();
    }

    private void visualizarVencimiento() {
        int indice = tvencimientos.getSelectedRow();
        if (indice >= 0) {
            String porcentaje = (String) tvencimientos.getValueAt(indice, 1);
            String tipoRecibo = (String) tvencimientos.getValueAt(indice, 3);
            String simporte = (String) tvencimientos.getValueAt(indice, 2);
            String fechaStr = (String) tvencimientos.getValueAt(indice, 4);
            double importe = Double.parseDouble(Util.convertirComaAPunto(simporte));
            String recibo;
            String cobrado;
            String emitido;
            String imputado;

            if (indice == 0) {
                recibo = fp2.getReciboVencimiento1();
                cobrado = fp2.getCobradoVencimiento1();
                emitido = fp2.getEmitidoVencimiento1();
                imputado = fp2.getImputadoVencimiento1();
            } else if (indice == 1) {
                recibo = fp2.getReciboVencimiento2();
                cobrado = fp2.getCobradoVencimiento2();
                emitido = fp2.getEmitidoVencimiento2();
                imputado = fp2.getImputadoVencimiento2();
            } else if (indice == 2) {
                recibo = fp2.getReciboVencimiento3();
                cobrado = fp2.getCobradoVencimiento3();
                emitido = fp2.getEmitidoVencimiento3();
                imputado = fp2.getImputadoVencimiento3();
            } else if (indice == 3) {
                recibo = fp2.getReciboVencimiento4();
                cobrado = fp2.getCobradoVencimiento4();
                emitido = fp2.getEmitidoVencimiento4();
                imputado = fp2.getImputadoVencimiento4();
            } else if (indice == 4) {
                recibo = fp2.getReciboVencimiento5();
                cobrado = fp2.getCobradoVencimiento5();
                emitido = fp2.getEmitidoVencimiento5();
                imputado = fp2.getImputadoVencimiento5();
            } else if (indice == 5) {
                recibo = fp2.getReciboVencimiento6();
                cobrado = fp2.getCobradoVencimiento6();
                emitido = fp2.getEmitidoVencimiento6();
                imputado = fp2.getImputadoVencimiento6();
            } else if (indice == 6) {
                recibo = fp2.getReciboVencimiento7();
                cobrado = fp2.getCobradoVencimiento7();
                emitido = fp2.getEmitidoVencimiento7();
                imputado = fp2.getImputadoVencimiento7();
            } else if (indice == 7) {
                recibo = fp2.getReciboVencimiento8();
                cobrado = fp2.getCobradoVencimiento8();
                emitido = fp2.getEmitidoVencimiento8();
                imputado = fp2.getImputadoVencimiento8();
            } else if (indice == 8) {
                recibo = fp2.getReciboVencimiento9();
                cobrado = fp2.getCobradoVencimiento9();
                emitido = fp2.getEmitidoVencimiento9();
                imputado = fp2.getImputadoVencimiento9();
            } else {
                recibo = fp2.getReciboVencimiento10();
                cobrado = fp2.getCobradoVencimiento10();
                emitido = fp2.getEmitidoVencimiento10();
                imputado = fp2.getImputadoVencimiento10();
            }

            double importeParaVencimiento = Double.valueOf(Util.convertirComaAPunto(this.lprecio_final.getText()));
            Vencimiento pl = new Vencimiento(indice, porcentaje, tipoRecibo, fechaStr, importeParaVencimiento, importe, fp2, recibo, this, tvencimientos.getRowCount() > 1, cobrado, emitido, imputado);
            pl.setDefaultCloseOperation(Plazo.DISPOSE_ON_CLOSE);
            pl.setLocationRelativeTo(null);
            pl.setVisible(true);
        }
    }//GEN-LAST:event_bmodificarvencimientoActionPerformed

    private void bmodificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bmodificarActionPerformed
        boolean enabled = true;
        if (bmodificar.getText().equals("Modificar")) {
            //Si el botón tiene el texto Modificar
            URL urlModificar = getClass().getResource("/iconos/buscar.gif");
            ImageIcon iconoModificar = new ImageIcon(urlModificar);
            bmodificar.setIcon(iconoModificar);
            bmodificar.setText("Visualizar");
            bmodificar.setToolTipText("Visualizar campos");
        } else {
            enabled = false;
            URL urlModificar = getClass().getResource("/iconos/editar.png");
            ImageIcon iconoModificar = new ImageIcon(urlModificar);
            bmodificar.setIcon(iconoModificar);
            //si el botón tiene el texto Visualizar
            bmodificar.setText("Modificar");
            bmodificar.setToolTipText("Modificar campos");
        }
        habilitarControles(enabled);
    }//GEN-LAST:event_bmodificarActionPerformed

    private void obtenerInterlocutorFormulas() {
        Empresa eH = BaseDatos.obtenerEmpresa((String) cInterlocutor.getSelectedItem());
        //Si es interlocutor es distinto a la empresa actual
        if (!eH.getIid().equals(e.getIid())) {
            i = BaseDatos.obtenerInterlocutor(eH, e);
            formulas = BaseDatos.obtenerInterFormulas(i);
            interCli = BaseDatos.obtenerAgenteByIid(i.getIidCliente().getIid());
        }
        lInterlocutor.setText(eH.getDesc_empresa());
    }

    public String obtenerFormula(FamiliaVenta fv) {
        String formula = "";
        if (formulas != null && !formulas.isEmpty()) {
            Iterator<InterlocutorFamiliaVenta> iF = formulas.iterator();
            InterlocutorFamiliaVenta ifv;
            while (iF.hasNext()) {
                ifv = iF.next();
                if (fv.getIid().equals(ifv.getFamiliaVenta().getIid())) {
                    formula = ifv.getFormula();
                    break;
                }
            }
        }
        return formula;
    }

    public Double descuentoInterlocutor(Articulo ar) {
        //Se ha de calcular el descuento segun la siguiente prioridad:
        //1.- Se usará el descuento que el cliente tenga para ese articulo
        //2.- Se usará el descuento que el cliente tenga para esa familia
        //3.- Se usará el descuento qeu el articulo tenga en si
        Double descuento = 0.0D;
        if (interCli != null) {
            String codigoAgente = interCli.getCod_agente();
            if (codigoAgente != null && !codigoAgente.equals("")) {
                Agentes ag = BaseDatos.obtenerAgentePorEmpresaYCodigo(e.getIid(), codigoAgente);
                if (ag != null) {
                    DescuentoClienteArticulo dca = BaseDatos.obtenerDescuentoClienteArticulo(ag.getIid(), ar.getIid());
                    if (dca != null) {
                        //Se toma el descuento del cliente
                        descuento = dca.getDescuento();
                    } else {
                        DescuentoClienteFamiliaVenta dcfv = BaseDatos.obtenerDescuentoClienteFamiliaVenta(ag.getIid(), ar.getIid_fam_venta().getIid());
                        if (dcfv != null) {
                            //Se toma el descuento de la familia
                            descuento = dcfv.getDescuento();
                        } else if (ar.getDescuento() != null) {
                            //Se toma el descuento del articulo
                            descuento = Double.parseDouble(ar.getDescuento().toString());
                        }
                    }
                } else if (ar.getDescuento() != null) {
                    //Se toma el descuento del articulo
                    descuento = Double.parseDouble(ar.getDescuento().toString());
                }
            } else if (ar.getDescuento() != null) {
                //Se toma el descuento del articulo;
                descuento = Double.parseDouble(ar.getDescuento().toString());
            }
        }
        descuento = descuento / 100;
        return descuento;
    }

    private void cInterlocutorItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_cInterlocutorItemStateChanged
        this.obtenerInterlocutorFormulas();
    }//GEN-LAST:event_cInterlocutorItemStateChanged

private void jMenuItemHojaMontajeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItemHojaMontajeActionPerformed
    if (rellenarDacMap != null && rellenarDacMap.size() > 0) {
        Integer claveI;
        RellenarDac rd;
        NuevaLineaPresupuesto nlp;
        HashMap parameters = new HashMap();
        LineaHojaTrabajoTotal lhtt;
        List<LineaHojaTrabajoTotal> llhtt = new ArrayList<LineaHojaTrabajoTotal>();
        String clave;
        String cantidadTemporal;
        String colorTemp;
        Float cantidad1;
        Colores col;
        String perfilS = "";
        Double perfilD;
        HashMap mapaArticulos = new HashMap();
        int numDac = rellenarDacMap.size();
        int numDacPintados = 0;

        parameters.put("numero", tnumero.getText());
        parameters.put("referencia", tReferencia.getText());
        parameters.put("codigoCliente", tCodCliente.getText());
        parameters.put("nombreCliente", tNombreCliente.getText());

        for (Iterator<Integer> it1 = rellenarDacMap.keySet().iterator(); it1.hasNext();) {
            claveI = it1.next();
            rd = (RellenarDac) rellenarDacMap.get(claveI);
            rd = getRellenarDac(claveI);
            nlp = (NuevaLineaPresupuesto) listaArticulos.get(claveI - 1);

            if (nlp.getTMedida1() != null && nlp.getTMedida1().length() > 0) {
                rd.setMedida1(nlp.getTMedida1());
            } else {
                rd.setMedida1("0");
            }

            if (nlp.getTMedida2() != null && nlp.getTMedida2().length() > 0) {
                rd.setMedida2(nlp.getTMedida2());
            } else {
                rd.setMedida2("0");
            }

            if (nlp.getTMedida3() != null && nlp.getTMedida3().length() > 0) {
                rd.setMedida3(nlp.getTMedida3());
            } else {
                rd.setMedida3("0");
            }

            if (nlp.getTMedida4() != null && nlp.getTMedida4().length() > 0) {
                rd.setMedida4(nlp.getTMedida4());
            } else {
                rd.setMedida4("0");
            }

            if (nlp.getTMedida5() != null && nlp.getTMedida5().length() > 0) {
                rd.setMedida5(nlp.getTMedida5());
            } else {
                rd.setMedida5("0");
            }
            rd.iniciarVariables();

            numDacPintados++;

            //Datos del DAC
            lhtt = new LineaHojaTrabajoTotal();
            lhtt.setCodigoGris("Código");
            lhtt.setDescripcionGris("Descripción");
            lhtt.setCantidadGris("Cantidad");
            lhtt.setColorGris("Dimensiones");
            lhtt.setMedidasGris("Medidas");
            lhtt.setImprimirLineaLateral("si");
            lhtt.setImprimirLineaSuperior("si");
            llhtt.add(lhtt);

            lhtt = new LineaHojaTrabajoTotal();
            lhtt.setCodigo(nlp.getTCodigo());
            lhtt.setDescripcion(nlp.getDescripcion());
            lhtt.setCantidad(nlp.getTcantidad());
            lhtt.setColor(nlp.getDimensionesStr());
            lhtt.setMedidas(nlp.getMedidasStrHT(rd));
            lhtt.setImprimirLineaLateral("si");
            lhtt.setImprimirLineaSuperior("si");
            llhtt.add(lhtt);

            lhtt = new LineaHojaTrabajoTotal();
            lhtt.setCodigo("");
            lhtt.setDescripcion("");
            lhtt.setCantidad("");
            lhtt.setColor("");
            lhtt.setMedidas("");
            lhtt.setImprimirLineaLateral("no");
            lhtt.setImprimirLineaSuperior("si");
            llhtt.add(lhtt);

            //Articulos del DAC
            List listaDesp;
            Iterator<Despiece> iter = rd.getListaDespiece().iterator();
            mapaArticulos = new HashMap();
            Articulo arTemp;
            Despiece desTemp;
            FamiliaVenta famTemp;

            while (iter.hasNext()) {
                desTemp = iter.next();
                arTemp = desTemp.getArticulo();
                arTemp = BaseDatos.obtenerArticuloPorIid(arTemp.getIid());
                famTemp = arTemp.getIid_fam_venta();
                famTemp = BaseDatos.obtenerFamiliaVentaPorIid(famTemp.getIid());

                if (mapaArticulos.get(famTemp.getNombre()) == null) {
                    listaDesp = new ArrayList();
                } else {
                    listaDesp = (List) mapaArticulos.get(famTemp.getNombre());
                }
                listaDesp.add(desTemp);
                mapaArticulos.put(famTemp.getNombre(), listaDesp);
            }

            cantidad1 = Float.parseFloat(Util.convertirComaAPunto(nlp.getTcantidad()));
            perfilS = "";

            lhtt = new LineaHojaTrabajoTotal();
            lhtt.setCodigoGris("Código");
            lhtt.setDescripcionGris("Descripción");
            lhtt.setColorGris("Color");
            lhtt.setCantidadGris("Cantidad");
            lhtt.setMedidasGris("Medidas");
            lhtt.setImprimirLineaLateral("si");
            lhtt.setImprimirLineaSuperior("si");
            llhtt.add(lhtt);

            for (Iterator it = mapaArticulos.keySet().iterator(); it.hasNext();) {
                clave = (String) it.next();
                listaDesp = (List) mapaArticulos.get(clave);
                iter = listaDesp.iterator();

                lhtt = new LineaHojaTrabajoTotal();
                lhtt.setDescripcion(clave);
                lhtt.setImprimirLineaLateral("si");
                lhtt.setImprimirLineaSuperior("si");
                llhtt.add(lhtt);

                while (iter.hasNext()) {
                    desTemp = iter.next();
                    arTemp = desTemp.getArticulo();
                    arTemp = BaseDatos.obtenerArticuloPorIid(arTemp.getIid());
                    if (desTemp.getFormulaCantidad() == null || desTemp.getFormulaCantidad().equals("")) {
                        cantidadTemporal = "0";
                    } else {
                        cantidadTemporal = Util.convertirPuntoAComa(String.valueOf(rd.evaluar(cantidad1 + "*(" + desTemp.getFormulaCantidad() + ")", desTemp.getRedondeo(), false)));
                    }
                    colorTemp = "";
                    perfilS = "";
                    perfilD = null;
                    if (desTemp.getColor() != null) {
                        col = desTemp.getColor();
                        col = BaseDatos.obtenerColorPorIid(col.getIid());
                        colorTemp = col.getDescripcion();
                    }

                    if (nlp.getIid() != null && desTemp.getIidInicial() != null) {
                        perfilD = BaseDatos.obtenerLongitudSeleccionadaPerfil(nlp.getIid(), desTemp.getIidInicial());
                        if (perfilD != null) {
                            perfilS = " (" + Util.convertirPuntoAComa(String.valueOf(perfilD)) + ")";
                        }
                    }

                    lhtt = new LineaHojaTrabajoTotal();
                    lhtt.setCodigo(arTemp.getCod_articulo());
                    lhtt.setDescripcion(arTemp.getDes_inf() + perfilS);
                    lhtt.setColor(colorTemp);
                    lhtt.setCantidad(cantidadTemporal);
                    lhtt.setMedidas(rd.calcularMedidasStr(desTemp));
                    lhtt.setImprimirLineaLateral("si");
                    lhtt.setImprimirLineaSuperior("si");
                    llhtt.add(lhtt);
                }
            }
            mapaArticulos.clear();

            if (numDacPintados < numDac) {
                lhtt = new LineaHojaTrabajoTotal();
                lhtt.setCodigo("");
                lhtt.setDescripcion("");
                lhtt.setCantidad("");
                lhtt.setColor("");
                lhtt.setMedidas("");
                lhtt.setImprimirLineaLateral("no");
                lhtt.setImprimirLineaSuperior("no");
                llhtt.add(lhtt);

                lhtt = new LineaHojaTrabajoTotal();
                lhtt.setCodigo("");
                lhtt.setDescripcion("");
                lhtt.setCantidad("");
                lhtt.setColor("");
                lhtt.setMedidas("");
                lhtt.setImprimirLineaLateral("no");
                lhtt.setImprimirLineaSuperior("no");
                llhtt.add(lhtt);

                lhtt = new LineaHojaTrabajoTotal();
                lhtt.setCodigo("");
                lhtt.setDescripcion("");
                lhtt.setCantidad("");
                lhtt.setColor("");
                lhtt.setMedidas("");
                lhtt.setImprimirLineaLateral("no");
                lhtt.setImprimirLineaSuperior("si");
                llhtt.add(lhtt);
            }
        }

        parameters.put("datosHojaTrabajoTotal", new JRBeanCollectionDataSource(llhtt));
        HojaTrabajoTotal.imprimirHojaTrabajoTotal(parameters);
    } else {
        JOptionPane.showMessageDialog(null, "Este documento no tiene artículos compuestos", "Información", JOptionPane.INFORMATION_MESSAGE);
    }
}//GEN-LAST:event_jMenuItemHojaMontajeActionPerformed

private void bInsertarArticuloAntesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bInsertarArticuloAntesActionPerformed
    lineaAntes();
}//GEN-LAST:event_bInsertarArticuloAntesActionPerformed

private void bInsertarArticuloDespuesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bInsertarArticuloDespuesActionPerformed
    lineaDespues();
}//GEN-LAST:event_bInsertarArticuloDespuesActionPerformed

private void bInsertarArticuloPrincipioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bInsertarArticuloPrincipioActionPerformed
    lineaPrincipio();
}//GEN-LAST:event_bInsertarArticuloPrincipioActionPerformed

private void bInsertarNotaDespuesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bInsertarNotaDespuesActionPerformed
    notaDespues();
}//GEN-LAST:event_bInsertarNotaDespuesActionPerformed

private void bInsertarNotaAntesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bInsertarNotaAntesActionPerformed
    notaAntes();
}//GEN-LAST:event_bInsertarNotaAntesActionPerformed

private void bInsertarArticuloFinalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bInsertarArticuloFinalActionPerformed
    lineaFinal();
}//GEN-LAST:event_bInsertarArticuloFinalActionPerformed

private void bInsertarNotaPrincipioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bInsertarNotaPrincipioActionPerformed
    notaPrincipio();
}//GEN-LAST:event_bInsertarNotaPrincipioActionPerformed

private void bInsertarNotaFinalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bInsertarNotaFinalActionPerformed
    notaFinal();
}//GEN-LAST:event_bInsertarNotaFinalActionPerformed

private void cbConfeccionadoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbConfeccionadoActionPerformed
    if (this.cbConfeccionado.isSelected()) {
        //No estaba seleccionado y se quiere seleccionar
        if (crear) {
            //El documento aun no está guardado
            JOptionPane.showMessageDialog(null, "El documento no ha sido guardado", "Error", JOptionPane.ERROR_MESSAGE);
            cbConfeccionado.setSelected(false);
        } else if (cortarLona() != 0) {
            cbConfeccionado.setSelected(false);
        }
    } else {
        //Estaba seleccionado y se quiere desseleccionar
        int eliminar = JOptionPane.showConfirmDialog(null, "Está seguro de que desea revertir el corte de lona?", "¿Deshacer corte de lona?", JOptionPane.YES_NO_OPTION);
        //eliminar = -1 ==> se ha pulsado la "x" de cancelar;
        //eliminar =  0 ==> se ha pulsado el "sÃ­"
        //eliminar =  1 ==> se ha pulsado el "no"
        if (eliminar == 0) {
            List<Integer> listaIidLineas = new ArrayList<Integer>();
            Iterator<NuevaLineaPresupuesto> iter = this.listaArticulos.iterator();
            while (iter.hasNext()) {
                listaIidLineas.add(iter.next().getIid());
            }

            boolean borradoCorrecto = BaseDatos.eliminarCorteLonaByLineasPresupuesto(listaIidLineas);
            if (borradoCorrecto) {
                cbConfeccionado.setSelected(false);
            } else {
                cbConfeccionado.setSelected(true);
                JOptionPane.showMessageDialog(null, "Ha habido problemas al eliminar los cortes de lona", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            cbConfeccionado.setSelected(true);
        }
    }
}//GEN-LAST:event_cbConfeccionadoActionPerformed

private void cbFabricadoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbFabricadoActionPerformed
    if (this.cbFabricado.isSelected()) {
        //No estaba seleccionado y se quiere seleccionar
        if (crear) {
            //El documento aun no estÃ¡ guardado
            JOptionPane.showMessageDialog(null, "El documento no ha sido guardado", "Error", JOptionPane.ERROR_MESSAGE);
            cbFabricado.setSelected(false);
        } else if (cortarPerfil() != 0) {
            cbFabricado.setSelected(false);
        }
    } else {
        //Estaba seleccionado y se quiere desseleccionar
        int eliminar = JOptionPane.showConfirmDialog(null, "Está seguro de que desea revertir el corte de perfil?", "¿Deshacer corte de perfil?", JOptionPane.YES_NO_OPTION);
        //eliminar = -1 ==> se ha pulsado la "x" de cancelar;
        //eliminar =  0 ==> se ha pulsado el "si"
        //eliminar =  1 ==> se ha pulsado el "no"
        if (eliminar == 0) {
            List<Integer> listaIidLineas = new ArrayList<Integer>();
            Iterator iter = this.listaArticulos.iterator();
            NuevaLineaPresupuesto lip;
            while (iter.hasNext()) {
                lip = (NuevaLineaPresupuesto) iter.next();
                listaIidLineas.add(lip.getIid());
            }

            boolean borradoCorrecto = BaseDatos.eliminarCortePerfilByLineasPresupuesto(listaIidLineas);
            if (borradoCorrecto) {
                cbFabricado.setSelected(false);
            } else {
                cbFabricado.setSelected(true);
                JOptionPane.showMessageDialog(null, "Ha habido problemas al eliminar los cortes de perfil", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            cbFabricado.setSelected(true);
        }
    }
}//GEN-LAST:event_cbFabricadoActionPerformed

    private void tCodClienteKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tCodClienteKeyPressed
        if (evt.getKeyChar() == KeyEvent.VK_ENTER) {
            Agentes ag = BaseDatos.obtenerAgentesPorCodigo(tCodCliente.getText(), "cli", e);
            if (ag != null) {
                rellenarCliente(ag);
            }
        }
    }//GEN-LAST:event_tCodClienteKeyPressed

    private void bMovimientoAlmacenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bMovimientoAlmacenActionPerformed
        ListaDeMovimientos frame = new ListaDeMovimientos(e, p.getIid());
        frame.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }//GEN-LAST:event_bMovimientoAlmacenActionPerformed

    private void bHayMontajeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bHayMontajeActionPerformed
        generarMontaje gM = new generarMontaje(e, u, p);
        gM.setDefaultCloseOperation(NuevoPresupuesto.DISPOSE_ON_CLOSE);
        gM.setLocationRelativeTo(null);
        gM.setVisible(true);
    }//GEN-LAST:event_bHayMontajeActionPerformed

private void tIvaKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tIvaKeyReleased
    int codigo = evt.getKeyCode();
    if(codigo != KeyEvent.VK_BACK_SPACE && codigo != KeyEvent.VK_ENTER && codigo != KeyEvent.VK_DELETE && codigo != KeyEvent.VK_LEFT && codigo != KeyEvent.VK_RIGHT){
        char c = evt.getKeyChar();
        int carePosition = tIva.getCaretPosition();
        String contenidoAntiguo = tIva.getText().replace(".", ",");
        int indiceComaPuntoUltimo = contenidoAntiguo.lastIndexOf(",");
        int indiceComaPuntoPrimero = contenidoAntiguo.indexOf(',');

        if (!(c >= '0' && c <= '9') && c != '.' && c != ',') {
            contenidoAntiguo = contenidoAntiguo.replace(String.valueOf(c), "");
            carePosition--;
        }

        if(indiceComaPuntoUltimo != indiceComaPuntoPrimero){
            contenidoAntiguo = contenidoAntiguo.replaceFirst(",", "");
            if(indiceComaPuntoUltimo <= carePosition) {
                carePosition--;
            }
        }
        
        if (carePosition > contenidoAntiguo.length()) {
            carePosition = contenidoAntiguo.length();
        }
        
        tIva.setText(contenidoAntiguo);
        tIva.setCaretPosition(carePosition);
        calcularPrecio(true);
    } else if (codigo == KeyEvent.VK_BACK_SPACE  || codigo == KeyEvent.VK_DELETE) {
        calcularPrecio(true);
    }
}//GEN-LAST:event_tIvaKeyReleased

//Si linea = true ==> se está insertando una linea de articulo
//Si linea = false ==> se está insertando una nota informativa
    private void insertarLineaNueva(int indice, boolean isLineaArticulo) {
        if (indice < 0) {
            indice = 0;
        } else if (indice > num_articulos) {
            indice = num_articulos;
        }

        NuevaLineaPresupuesto lip = new NuevaLineaPresupuesto(this, indice, e, isLineaArticulo, u);
        panel.add(lip, indice);
        panel.setVisible(true);
        panel.repaint();
        this.pack();
        Dimension dim = Util.getDimensiones(this.getSize());
        if (dim != null) {
            setResizable(true);
            setSize(dim);
            setResizable(false);
        }
        num_articulos++;
        listaArticulos.add(indice, lip);
        cambiarCodigosDac(indice + 1);
        cambiarCodigos();
        reCalcularLineasVacias();
    }

    public void setLineaActiva(int indice) {
        lineaActiva = indice;
    }

    private HashMap crearHashMapParametros() {
        HashMap parameters = new HashMap();
        parameters.put("e.cod_empresa", e.getCod_empresa());
        parameters.put("e.desc_empresa", e.getDesc_empresa());
        parameters.put("e.dire_empresa", e.getDire_empresa());
        parameters.put("e.pobla_empresa", e.getPobla_empresa());
        parameters.put("e.cp_empresa", e.getCp_empresa());
        parameters.put("e.cif", e.getCif());
        parameters.put("e.telefono", e.getTelefono());
        parameters.put("e.fax", e.getFax());
        parameters.put("e.email", e.getEmail());
        parameters.put("e.web", e.getUrlWeb());
        parameters.put("tipoDocumento", cd.getDescripcion());

        parameters.put("c.codigo", this.tCodCliente.getText());
        parameters.put("c.dni", this.tDniCliente.getText());
        parameters.put("c.nombreComercial", this.tNombreCliente.getText());
        parameters.put("c.direccion", this.tDireccionCliente.getText());
        parameters.put("c.cp", this.tCpCliente.getText());
        parameters.put("c.poblacion", this.tLocalidadCliente.getText());
        parameters.put("c.provincia", this.tProvinciaCliente.getText());
        parameters.put("c.telefono", this.tTelefonoCliente.getText());

        parameters.put("logo", new ByteArrayInputStream(e.getImagen()));
        parameters.put("referencia", tReferencia.getText());
        parameters.put("numero", tnumero.getText());
        parameters.put("fecha", tfecha.getText());

        HashMap hashPrecio = new HashMap();
        hashPrecio.put("precio_bruto", lprecio.getText());
        hashPrecio.put("precio_final", lprecio_final.getText());
        hashPrecio.put("precio_iva", limporte_iva.getText());
        hashPrecio.put("iva", tIva.getText());

        parameters.put("hashPrecio", hashPrecio);
        parameters.put("precio_bruto", lprecio.getText());
        parameters.put("precio_final", lprecio_final.getText());
        parameters.put("precio_iva", limporte_iva.getText());

        List<LineaPresupuesto> listaProducto = new ArrayList<LineaPresupuesto>();
        NuevaLineaPresupuesto nlip;
        Articulo arti;
        Iterator<NuevaLineaPresupuesto> it = listaArticulos.iterator();
        LineaPresupuesto lip;
        FamiliaVenta fve;
        TipoControl tco;
        TipoMedida tme;

        while (it.hasNext()) {
            nlip = it.next();
            arti = nlip.getArticulo();
            if (arti != null) {
                lip = new LineaPresupuesto();
                lip.setArticulo_iid(arti);
                fve = BaseDatos.obtenerFamiliaVentaPorIid(nlip.getArticulo().getIid_fam_venta().getIid());
                tco = BaseDatos.obtenerTipoControlPorIid(fve.getIid_tipo_control().getIid());
                tme = BaseDatos.obtenerTipoMedidaByIid(tco.getIid_tipo_medida().getIid());
                lip.setNummedidas(tme.getNum_dimensiones());
                lip.setCodigo(nlip.getCodigo());
                lip.setPrecio(nlip.getPrecio());
                lip.setPrecioStr(Util.convertirPuntoAComa(String.valueOf((nlip.getPrecio()))));
                lip.setManual((nlip.getManual()) ? "S" : "N");
                lip.setPresupuesto_iid(p);
                lip.setDescuento(nlip.getDescuento());
                lip.setCantidad(nlip.getCantidad());
                lip.setMedida1(nlip.getMedida1());
                lip.setMedida2(nlip.getMedida2());
                lip.setMedida3(nlip.getMedida3());
                lip.setMedida4(nlip.getMedida4());
                lip.setMedida5(nlip.getMedida5());
                lip.setMedidares(nlip.getMedidares());
                lip.setDescripcion(nlip.getDescripcion());
                lip.setImporte(nlip.getImporte());
                lip.setCantidadStr(Util.convertirPuntoAComa(String.valueOf((nlip.getCantidad()))));
                lip.setImporteStr(Util.convertirPuntoAComa(String.valueOf((nlip.getImporte()))));
                listaProducto.add(lip);
            } else if (!nlip.isLineaArticulo() && nlip.getDescripcion() != null && !nlip.getDescripcion().equals("")) {
                lip = new LineaPresupuesto();
                lip.setDescripcion(nlip.getDescripcion());
                listaProducto.add(lip);
            }
        }
        parameters.put("lineaPresupuesto", new JRBeanCollectionDataSource(listaProducto));

        List<Objeto2Elementos> lista = fp2.getPlazos();
        parameters.put("formaPago", new JRBeanCollectionDataSource(lista));
        parameters.put("formaPagoStr", fp2.getCodigo());

        return parameters;
    }

    private void convertirDocumento(String tipo) {
        if (crear) {
            JOptionPane.showMessageDialog(null, "El " + tipo + " aún no ha sido guardado", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            int eliminar = JOptionPane.showConfirmDialog(null, "Está seguro de que desea convertir el " + cd.getDescripcion(), "¿Convertir?", JOptionPane.YES_NO_OPTION);
            //hacerCambios = -1 ==> se ha pulsado la "x" de cancelar;
            //hacerCambios =  0 ==> se ha pulsado el "sí"
            //hacerCambios =  1 ==> se ha pulsado el "no"
            if (eliminar == 0) {
                DatosConversion sa = new DatosConversion(p, "directo", this.e, this.u);
                sa.setDefaultCloseOperation(DatosConversion.DISPOSE_ON_CLOSE);
                sa.setLocationRelativeTo(null);
                sa.setVisible(true);
                cerrarPresupuesto();
            }
        }
    }

    private void convertirAlbaran() {
        if (crear) {
            JOptionPane.showMessageDialog(null, "El documento aún no ha sido guardado", "Error", JOptionPane.ERROR_MESSAGE);
        } else if (((String) cSeries.getSelectedItem()).equals(Constantes.SERIE_SEC)) {
            JOptionPane.showMessageDialog(null, "Este tipo de Albarán (Serie Secundaria) no se puede pasar a Factura", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            int eliminar = JOptionPane.showConfirmDialog(null, "Está seguro de que desea convertir el " + cd.getDescripcion(), "¿Convertir?", JOptionPane.YES_NO_OPTION);
            //hacerCambios = -1 ==> se ha pulsado la "x" de cancelar;
            //hacerCambios =  0 ==> se ha pulsado el "sí"
            //hacerCambios =  1 ==> se ha pulsado el "no"
            if (eliminar == 0) {
                DatosConversion sa = new DatosConversion(p, "directo", this.e, this.u);
                sa.setDefaultCloseOperation(DatosConversion.DISPOSE_ON_CLOSE);
                sa.setLocationRelativeTo(null);
                sa.setVisible(true);
            }
        }
    }

    private void cargarLineasPresupuesto() {
        mapaNuevoClaves = new HashMap<Integer, Integer>();
        List lps = BaseDatos.getListaLineaPresupuesto(p.getIid());
        Iterator<LineaPresupuesto> it;
        for (it = lps.iterator(); it.hasNext();) {
            anadirLineaPresupuesto(it.next());
        }
        anadirLineaPresupuesto();
    }

    protected void limpiarVencimientos() {
        Modelo m = (Modelo) tvencimientos.getModel();
        int in,  j = m.getRowCount();
        for (in = 0; in < j; in++) {
            m.removeRow(0);
        }
    }

    protected void limpiarPlazosAdelantados() {
        Modelo m = (Modelo) tplazosadelantados.getModel();
        int ii,  j = m.getRowCount();
        for (ii = 0; ii < j; ii++) {
            m.removeRow(0);
        }
    }

    protected void rellenarVencimientos() {
        if (fp2 != null) {
            Modelo modelovencimientos = (Modelo) tvencimientos.getModel();
            int num_vencimientos = fp2.getNumplazosvencimiento();

            Agentes ag = new Agentes();
            Object[] agenteReducido = BaseDatos.obtenerAgentesPorCodigoReducido(tCodCliente.getText(), "", e);
            if (agenteReducido != null) {
                ag.setDiaCobro1((Integer) agenteReducido[0]);
                ag.setDiaCobro2((Integer) agenteReducido[1]);
                ag.setDiaCobro3((Integer) agenteReducido[2]);
            }

            List<Integer> listaDiasOrdenada = ag.ordenarDiasCobro();
            if (num_vencimientos == 1) {
                modelovencimientos.addRow(rellenarVencimiento1(listaDiasOrdenada));
            } else if (num_vencimientos == 2) {
                modelovencimientos.addRow(rellenarVencimiento1(listaDiasOrdenada));
                modelovencimientos.addRow(rellenarVencimiento2(listaDiasOrdenada));
            } else if (num_vencimientos == 3) {
                modelovencimientos.addRow(rellenarVencimiento1(listaDiasOrdenada));
                modelovencimientos.addRow(rellenarVencimiento2(listaDiasOrdenada));
                modelovencimientos.addRow(rellenarVencimiento3(listaDiasOrdenada));
            } else if (num_vencimientos == 4) {
                modelovencimientos.addRow(rellenarVencimiento1(listaDiasOrdenada));
                modelovencimientos.addRow(rellenarVencimiento2(listaDiasOrdenada));
                modelovencimientos.addRow(rellenarVencimiento3(listaDiasOrdenada));
                modelovencimientos.addRow(rellenarVencimiento4(listaDiasOrdenada));
            } else if (num_vencimientos == 5) {
                modelovencimientos.addRow(rellenarVencimiento1(listaDiasOrdenada));
                modelovencimientos.addRow(rellenarVencimiento2(listaDiasOrdenada));
                modelovencimientos.addRow(rellenarVencimiento3(listaDiasOrdenada));
                modelovencimientos.addRow(rellenarVencimiento4(listaDiasOrdenada));
                modelovencimientos.addRow(rellenarVencimiento5(listaDiasOrdenada));
            } else if (num_vencimientos == 6) {
                modelovencimientos.addRow(rellenarVencimiento1(listaDiasOrdenada));
                modelovencimientos.addRow(rellenarVencimiento2(listaDiasOrdenada));
                modelovencimientos.addRow(rellenarVencimiento3(listaDiasOrdenada));
                modelovencimientos.addRow(rellenarVencimiento4(listaDiasOrdenada));
                modelovencimientos.addRow(rellenarVencimiento5(listaDiasOrdenada));
                modelovencimientos.addRow(rellenarVencimiento6(listaDiasOrdenada));
            } else if (num_vencimientos == 7) {
                modelovencimientos.addRow(rellenarVencimiento1(listaDiasOrdenada));
                modelovencimientos.addRow(rellenarVencimiento2(listaDiasOrdenada));
                modelovencimientos.addRow(rellenarVencimiento3(listaDiasOrdenada));
                modelovencimientos.addRow(rellenarVencimiento4(listaDiasOrdenada));
                modelovencimientos.addRow(rellenarVencimiento5(listaDiasOrdenada));
                modelovencimientos.addRow(rellenarVencimiento6(listaDiasOrdenada));
                modelovencimientos.addRow(rellenarVencimiento7(listaDiasOrdenada));
            } else if (num_vencimientos == 8) {
                modelovencimientos.addRow(rellenarVencimiento1(listaDiasOrdenada));
                modelovencimientos.addRow(rellenarVencimiento2(listaDiasOrdenada));
                modelovencimientos.addRow(rellenarVencimiento3(listaDiasOrdenada));
                modelovencimientos.addRow(rellenarVencimiento4(listaDiasOrdenada));
                modelovencimientos.addRow(rellenarVencimiento5(listaDiasOrdenada));
                modelovencimientos.addRow(rellenarVencimiento6(listaDiasOrdenada));
                modelovencimientos.addRow(rellenarVencimiento7(listaDiasOrdenada));
                modelovencimientos.addRow(rellenarVencimiento8(listaDiasOrdenada));
            } else if (num_vencimientos == 9) {
                modelovencimientos.addRow(rellenarVencimiento1(listaDiasOrdenada));
                modelovencimientos.addRow(rellenarVencimiento2(listaDiasOrdenada));
                modelovencimientos.addRow(rellenarVencimiento3(listaDiasOrdenada));
                modelovencimientos.addRow(rellenarVencimiento4(listaDiasOrdenada));
                modelovencimientos.addRow(rellenarVencimiento5(listaDiasOrdenada));
                modelovencimientos.addRow(rellenarVencimiento6(listaDiasOrdenada));
                modelovencimientos.addRow(rellenarVencimiento7(listaDiasOrdenada));
                modelovencimientos.addRow(rellenarVencimiento8(listaDiasOrdenada));
                modelovencimientos.addRow(rellenarVencimiento9(listaDiasOrdenada));
            } else if (num_vencimientos == 10) {
                modelovencimientos.addRow(rellenarVencimiento1(listaDiasOrdenada));
                modelovencimientos.addRow(rellenarVencimiento2(listaDiasOrdenada));
                modelovencimientos.addRow(rellenarVencimiento3(listaDiasOrdenada));
                modelovencimientos.addRow(rellenarVencimiento4(listaDiasOrdenada));
                modelovencimientos.addRow(rellenarVencimiento5(listaDiasOrdenada));
                modelovencimientos.addRow(rellenarVencimiento6(listaDiasOrdenada));
                modelovencimientos.addRow(rellenarVencimiento7(listaDiasOrdenada));
                modelovencimientos.addRow(rellenarVencimiento8(listaDiasOrdenada));
                modelovencimientos.addRow(rellenarVencimiento9(listaDiasOrdenada));
                modelovencimientos.addRow(rellenarVencimiento10(listaDiasOrdenada));
            }
        }
    }

    private String calcularFecha(int diasSumar, List<Integer> listaDiasOrdenada) {
        Date fechaV = null;
        Date fechaError = null;
        SimpleDateFormat formatoFecha = new SimpleDateFormat("dd/MM/yyyy");
        try {
            Date fechaP = null;
            if (tfecha.getText().equals("")) {
                fechaP = formatoFecha.parse("01/01/1900");
            } else {
                fechaP = formatoFecha.parse(tfecha.getText());
            }
            fechaError = formatoFecha.parse("01/01/1900");

            if (diasSumar % 30 == 0 && fp2.getTipodecalculo().equals(Constantes.MESES_ENTEROS)) {
                Calendar c1 = Calendar.getInstance();
                c1.setTime(fechaP);
                c1.add(Calendar.MONTH, diasSumar / 30);

                if (listaDiasOrdenada != null && listaDiasOrdenada.get(0) != 32) {
                    if (c1.get(Calendar.DATE) <= listaDiasOrdenada.get(0)) {
                        c1.add(Calendar.DATE, listaDiasOrdenada.get(0) - c1.get(Calendar.DATE));
                    } else {
                        if (listaDiasOrdenada.get(1) != 32) {
                            if (listaDiasOrdenada.get(1) >= c1.get(Calendar.DATE)) {
                                c1.add(Calendar.DATE, listaDiasOrdenada.get(1) - c1.get(Calendar.DATE));
                            } else {
                                if (listaDiasOrdenada.get(2) != 32) {
                                    if (listaDiasOrdenada.get(2) >= c1.get(Calendar.DATE)) {
                                        c1.add(Calendar.DATE, listaDiasOrdenada.get(2) - c1.get(Calendar.DATE));
                                    } else {
                                        c1.set(Calendar.MONTH, c1.get(Calendar.MONTH) + 1);
                                        c1.set(Calendar.DATE, listaDiasOrdenada.get(0));
                                    }
                                } else {
                                    c1.set(Calendar.MONTH, c1.get(Calendar.MONTH) + 1);
                                    c1.set(Calendar.DATE, listaDiasOrdenada.get(0));
                                }
                            }
                        } else {
                            c1.set(Calendar.MONTH, c1.get(Calendar.MONTH) + 1);
                            c1.set(Calendar.DATE, listaDiasOrdenada.get(0));
                        }
                    }
                }
                fechaV = c1.getTime();
            } else {
                Calendar c1 = Calendar.getInstance();
                c1.setTime(fechaP);
                c1.add(Calendar.DATE, diasSumar);
                if (listaDiasOrdenada != null && listaDiasOrdenada.get(0) != 32) {
                    if (c1.get(Calendar.DATE) <= listaDiasOrdenada.get(0)) {
                        c1.add(Calendar.DATE, listaDiasOrdenada.get(0) - c1.get(Calendar.DATE));
                    } else {
                        if (listaDiasOrdenada.get(1) != 32) {
                            if (listaDiasOrdenada.get(1) >= c1.get(Calendar.DATE)) {
                                c1.add(Calendar.DATE, listaDiasOrdenada.get(1) - c1.get(Calendar.DATE));
                            } else {
                                if (listaDiasOrdenada.get(2) != 32) {
                                    if (listaDiasOrdenada.get(2) >= c1.get(Calendar.DATE)) {
                                        c1.add(Calendar.DATE, listaDiasOrdenada.get(2) - c1.get(Calendar.DATE));
                                    } else {
                                        c1.set(Calendar.MONTH, c1.get(Calendar.MONTH) + 1);
                                        c1.set(Calendar.DATE, listaDiasOrdenada.get(0));
                                    }
                                } else {
                                    c1.set(Calendar.MONTH, c1.get(Calendar.MONTH) + 1);
                                    c1.set(Calendar.DATE, listaDiasOrdenada.get(0));
                                }
                            }
                        } else {
                            c1.set(Calendar.MONTH, c1.get(Calendar.MONTH) + 1);
                            c1.set(Calendar.DATE, listaDiasOrdenada.get(0));
                        }
                    }
                }
                fechaV = c1.getTime();
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            fechaV = fechaError;
        }
        return formatoFecha.format(fechaV);
    }

    private Object[] rellenarVencimiento1(List<Integer> listaDiasOrdenada) {
        Object[] fila1 = new Object[5];
        fila1[0] = fp2.getPlazovm1();
        fila1[1] = Util.convertirPuntoAComa(String.valueOf(matematico.Matematico.redondear2decimales(fp2.getPlazopm1())));
        fila1[2] = matematico.Matematico.redondear2decimales(precio_final * fp2.getPlazopm1() / 100);
        fp2.setImportev1((Double) fila1[2]);
        fila1[2] = Util.convertirPuntoAComa(String.valueOf(matematico.Matematico.redondear2decimales(precio_final * fp2.getPlazopm1() / 100)));
        fila1[3] = fp2.getIid_tr_v1().getDescripcion();
        fila1[4] = calcularFecha(fp2.getPlazovm1(), listaDiasOrdenada);
        return fila1;
    }

    private Object[] rellenarVencimiento2(List<Integer> listaDiasOrdenada) {
        Object[] fila1 = new Object[5];
        fila1[0] = fp2.getPlazovm2();
        fila1[1] = Util.convertirPuntoAComa(String.valueOf(matematico.Matematico.redondear2decimales(fp2.getPlazopm2())));
        fila1[2] = matematico.Matematico.redondear2decimales(precio_final * fp2.getPlazopm2() / 100);
        fp2.setImportev2((Double) fila1[2]);
        fila1[2] = Util.convertirPuntoAComa(String.valueOf(matematico.Matematico.redondear2decimales(precio_final * fp2.getPlazopm2() / 100)));
        fila1[3] = fp2.getIid_tr_v2().getDescripcion();
        fila1[4] = calcularFecha(fp2.getPlazovm2(), listaDiasOrdenada);
        return fila1;
    }

    private Object[] rellenarVencimiento3(List<Integer> listaDiasOrdenada) {
        Object[] fila1 = new Object[5];
        fila1[0] = fp2.getPlazovm3();
        fila1[1] = Util.convertirPuntoAComa(String.valueOf(matematico.Matematico.redondear2decimales(fp2.getPlazopm3())));
        fila1[2] = matematico.Matematico.redondear2decimales(precio_final * fp2.getPlazopm3() / 100);
        fp2.setImportev3((Double) fila1[2]);
        fila1[2] = Util.convertirPuntoAComa(String.valueOf(matematico.Matematico.redondear2decimales(precio_final * fp2.getPlazopm3() / 100)));
        fila1[3] = fp2.getIid_tr_v3().getDescripcion();
        fila1[4] = calcularFecha(fp2.getPlazovm3(), listaDiasOrdenada);
        return fila1;
    }

    private Object[] rellenarVencimiento4(List<Integer> listaDiasOrdenada) {
        Object[] fila1 = new Object[5];
        fila1[0] = fp2.getPlazovm4();
        fila1[1] = Util.convertirPuntoAComa(String.valueOf(matematico.Matematico.redondear2decimales(fp2.getPlazopm4())));
        fila1[2] = matematico.Matematico.redondear2decimales(precio_final * fp2.getPlazopm4() / 100);
        fp2.setImportev4((Double) fila1[2]);
        fila1[2] = Util.convertirPuntoAComa(String.valueOf(matematico.Matematico.redondear2decimales(precio_final * fp2.getPlazopm4() / 100)));
        fila1[3] = fp2.getIid_tr_v4().getDescripcion();
        fila1[4] = calcularFecha(fp2.getPlazovm4(), listaDiasOrdenada);
        return fila1;
    }

    private Object[] rellenarVencimiento5(List<Integer> listaDiasOrdenada) {
        Object[] fila1 = new Object[5];
        fila1[0] = fp2.getPlazovm5();
        fila1[1] = Util.convertirPuntoAComa(String.valueOf(matematico.Matematico.redondear2decimales(fp2.getPlazopm5())));
        fila1[2] = matematico.Matematico.redondear2decimales(precio_final * fp2.getPlazopm5() / 100);
        fp2.setImportev5((Double) fila1[2]);
        fila1[2] = Util.convertirPuntoAComa(String.valueOf(matematico.Matematico.redondear2decimales(precio_final * fp2.getPlazopm5() / 100)));
        fila1[3] = fp2.getIid_tr_v5().getDescripcion();
        fila1[4] = calcularFecha(fp2.getPlazovm5(), listaDiasOrdenada);
        return fila1;
    }

    private Object[] rellenarVencimiento6(List<Integer> listaDiasOrdenada) {
        Object[] fila1 = new Object[5];
        fila1[0] = fp2.getPlazovm6();
        fila1[1] = Util.convertirPuntoAComa(String.valueOf(matematico.Matematico.redondear2decimales(fp2.getPlazopm6())));
        fila1[2] = matematico.Matematico.redondear2decimales(precio_final * fp2.getPlazopm6() / 100);
        fp2.setImportev6((Double) fila1[2]);
        fila1[2] = Util.convertirPuntoAComa(String.valueOf(matematico.Matematico.redondear2decimales(precio_final * fp2.getPlazopm6() / 100)));
        fila1[3] = fp2.getIid_tr_v6().getDescripcion();
        fila1[4] = calcularFecha(fp2.getPlazovm6(), listaDiasOrdenada);
        return fila1;
    }

    private Object[] rellenarVencimiento7(List<Integer> listaDiasOrdenada) {
        Object[] fila1 = new Object[5];
        fila1[0] = fp2.getPlazovm7();
        fila1[1] = Util.convertirPuntoAComa(String.valueOf(matematico.Matematico.redondear2decimales(fp2.getPlazopm7())));
        fila1[2] = matematico.Matematico.redondear2decimales(precio_final * fp2.getPlazopm7() / 100);
        fp2.setImportev7((Double) fila1[2]);
        fila1[2] = Util.convertirPuntoAComa(String.valueOf(matematico.Matematico.redondear2decimales(precio_final * fp2.getPlazopm7() / 100)));
        fila1[3] = fp2.getIid_tr_v7().getDescripcion();
        fila1[4] = calcularFecha(fp2.getPlazovm7(), listaDiasOrdenada);
        return fila1;
    }

    private Object[] rellenarVencimiento8(List<Integer> listaDiasOrdenada) {
        Object[] fila1 = new Object[5];
        fila1[0] = fp2.getPlazovm8();
        fila1[1] = Util.convertirPuntoAComa(String.valueOf(matematico.Matematico.redondear2decimales(fp2.getPlazopm8())));
        fila1[2] = matematico.Matematico.redondear2decimales(precio_final * fp2.getPlazopm8() / 100);
        fp2.setImportev8((Double) fila1[2]);
        fila1[2] = Util.convertirPuntoAComa(String.valueOf(matematico.Matematico.redondear2decimales(precio_final * fp2.getPlazopm8() / 100)));
        fila1[3] = fp2.getIid_tr_v8().getDescripcion();
        fila1[4] = calcularFecha(fp2.getPlazovm8(), listaDiasOrdenada);
        return fila1;
    }

    private Object[] rellenarVencimiento9(List<Integer> listaDiasOrdenada) {
        Object[] fila1 = new Object[5];
        fila1[0] = fp2.getPlazovm9();
        fila1[1] = Util.convertirPuntoAComa(String.valueOf(matematico.Matematico.redondear2decimales(fp2.getPlazopm9())));
        fila1[2] = matematico.Matematico.redondear2decimales(precio_final * fp2.getPlazopm9() / 100);
        fp2.setImportev9((Double) fila1[2]);
        fila1[2] = Util.convertirPuntoAComa(String.valueOf(matematico.Matematico.redondear2decimales(precio_final * fp2.getPlazopm9() / 100)));
        fila1[3] = fp2.getIid_tr_v9().getDescripcion();
        fila1[4] = calcularFecha(fp2.getPlazovm9(), listaDiasOrdenada);
        return fila1;
    }

    private Object[] rellenarVencimiento10(List<Integer> listaDiasOrdenada) {
        Object[] fila1 = new Object[5];
        fila1[0] = fp2.getPlazovm10();
        fila1[1] = Util.convertirPuntoAComa(String.valueOf(matematico.Matematico.redondear2decimales(fp2.getPlazopm10())));
        fila1[2] = matematico.Matematico.redondear2decimales(precio_final * fp2.getPlazopm10() / 100);
        fp2.setImportev10((Double) fila1[2]);
        fila1[2] = Util.convertirPuntoAComa(String.valueOf(matematico.Matematico.redondear2decimales(precio_final * fp2.getPlazopm10() / 100)));
        fila1[3] = fp2.getIid_tr_v10().getDescripcion();
        fila1[4] = calcularFecha(fp2.getPlazovm10(), listaDiasOrdenada);
        return fila1;
    }

    protected void rellenarPlazosAdelantados() {
        if (fp2 != null) {
            Modelo modeloplazosadelantados = (Modelo) tplazosadelantados.getModel();
            int num_plazos_adelantados = fp2.getNumplazosadelantados();

            if (num_plazos_adelantados == 1) {
                modeloplazosadelantados.addRow(rellenarPlazoAdelantado1());
            } else if (num_plazos_adelantados == 2) {
                modeloplazosadelantados.addRow(rellenarPlazoAdelantado1());
                modeloplazosadelantados.addRow(rellenarPlazoAdelantado2());
            } else if (num_plazos_adelantados == 3) {
                modeloplazosadelantados.addRow(rellenarPlazoAdelantado1());
                modeloplazosadelantados.addRow(rellenarPlazoAdelantado2());
                modeloplazosadelantados.addRow(rellenarPlazoAdelantado3());
            } else if (num_plazos_adelantados == 4) {
                modeloplazosadelantados.addRow(rellenarPlazoAdelantado1());
                modeloplazosadelantados.addRow(rellenarPlazoAdelantado2());
                modeloplazosadelantados.addRow(rellenarPlazoAdelantado3());
                modeloplazosadelantados.addRow(rellenarPlazoAdelantado4());
            } else if (num_plazos_adelantados == 5) {
                modeloplazosadelantados.addRow(rellenarPlazoAdelantado1());
                modeloplazosadelantados.addRow(rellenarPlazoAdelantado2());
                modeloplazosadelantados.addRow(rellenarPlazoAdelantado3());
                modeloplazosadelantados.addRow(rellenarPlazoAdelantado4());
                modeloplazosadelantados.addRow(rellenarPlazoAdelantado5());
            } else if (num_plazos_adelantados == 6) {
                modeloplazosadelantados.addRow(rellenarPlazoAdelantado1());
                modeloplazosadelantados.addRow(rellenarPlazoAdelantado2());
                modeloplazosadelantados.addRow(rellenarPlazoAdelantado3());
                modeloplazosadelantados.addRow(rellenarPlazoAdelantado4());
                modeloplazosadelantados.addRow(rellenarPlazoAdelantado5());
                modeloplazosadelantados.addRow(rellenarPlazoAdelantado6());
            } else if (num_plazos_adelantados == 7) {
                modeloplazosadelantados.addRow(rellenarPlazoAdelantado1());
                modeloplazosadelantados.addRow(rellenarPlazoAdelantado2());
                modeloplazosadelantados.addRow(rellenarPlazoAdelantado3());
                modeloplazosadelantados.addRow(rellenarPlazoAdelantado4());
                modeloplazosadelantados.addRow(rellenarPlazoAdelantado5());
                modeloplazosadelantados.addRow(rellenarPlazoAdelantado6());
                modeloplazosadelantados.addRow(rellenarPlazoAdelantado7());
            } else if (num_plazos_adelantados == 8) {
                modeloplazosadelantados.addRow(rellenarPlazoAdelantado1());
                modeloplazosadelantados.addRow(rellenarPlazoAdelantado2());
                modeloplazosadelantados.addRow(rellenarPlazoAdelantado3());
                modeloplazosadelantados.addRow(rellenarPlazoAdelantado4());
                modeloplazosadelantados.addRow(rellenarPlazoAdelantado5());
                modeloplazosadelantados.addRow(rellenarPlazoAdelantado6());
                modeloplazosadelantados.addRow(rellenarPlazoAdelantado7());
                modeloplazosadelantados.addRow(rellenarPlazoAdelantado8());
            } else if (num_plazos_adelantados == 9) {
                modeloplazosadelantados.addRow(rellenarPlazoAdelantado1());
                modeloplazosadelantados.addRow(rellenarPlazoAdelantado2());
                modeloplazosadelantados.addRow(rellenarPlazoAdelantado3());
                modeloplazosadelantados.addRow(rellenarPlazoAdelantado4());
                modeloplazosadelantados.addRow(rellenarPlazoAdelantado5());
                modeloplazosadelantados.addRow(rellenarPlazoAdelantado6());
                modeloplazosadelantados.addRow(rellenarPlazoAdelantado7());
                modeloplazosadelantados.addRow(rellenarPlazoAdelantado8());
                modeloplazosadelantados.addRow(rellenarPlazoAdelantado9());
            } else if (num_plazos_adelantados == 10) {
                modeloplazosadelantados.addRow(rellenarPlazoAdelantado1());
                modeloplazosadelantados.addRow(rellenarPlazoAdelantado2());
                modeloplazosadelantados.addRow(rellenarPlazoAdelantado3());
                modeloplazosadelantados.addRow(rellenarPlazoAdelantado4());
                modeloplazosadelantados.addRow(rellenarPlazoAdelantado5());
                modeloplazosadelantados.addRow(rellenarPlazoAdelantado6());
                modeloplazosadelantados.addRow(rellenarPlazoAdelantado7());
                modeloplazosadelantados.addRow(rellenarPlazoAdelantado8());
                modeloplazosadelantados.addRow(rellenarPlazoAdelantado9());
                modeloplazosadelantados.addRow(rellenarPlazoAdelantado10());
            }
        }
    }

    private Object[] rellenarPlazoAdelantado1() {
        Object[] fila1 = new Object[5];
        fila1[0] = fp2.getNombreplazo1();
        fila1[1] = Util.convertirPuntoAComa(String.valueOf(fp2.getPorcentajepago1()));
        fila1[2] = matematico.Matematico.redondear2decimales(precio_final * fp2.getPorcentajepago1() / 100);
        fp2.setImportep1((Double) fila1[2]);
        fila1[2] = Util.convertirPuntoAComa(String.valueOf(matematico.Matematico.redondear2decimales(precio_final * fp2.getPorcentajepago1() / 100)));
        fila1[3] = fp2.getIid_tr_p1().getDescripcion();
        fila1[4] = fp2.getCobrado1();
        return fila1;
    }

    private Object[] rellenarPlazoAdelantado2() {
        Object[] fila1 = new Object[5];
        fila1[0] = fp2.getNombreplazo2();
        fila1[1] = Util.convertirPuntoAComa(String.valueOf(fp2.getPorcentajepago2()));
        fila1[2] = matematico.Matematico.redondear2decimales(precio_final * fp2.getPorcentajepago2() / 100);
        fp2.setImportep2((Double) fila1[2]);
        fila1[2] = Util.convertirPuntoAComa(String.valueOf(matematico.Matematico.redondear2decimales(precio_final * fp2.getPorcentajepago2() / 100)));
        fila1[3] = fp2.getIid_tr_p2().getDescripcion();
        fila1[4] = fp2.getCobrado2();
        return fila1;
    }

    private Object[] rellenarPlazoAdelantado3() {
        Object[] fila1 = new Object[5];
        fila1[0] = fp2.getNombreplazo3();
        fila1[1] = Util.convertirPuntoAComa(String.valueOf(fp2.getPorcentajepago3()));
        fila1[2] = matematico.Matematico.redondear2decimales(precio_final * fp2.getPorcentajepago3() / 100);
        fp2.setImportep3((Double) fila1[2]);
        fila1[2] = Util.convertirPuntoAComa(String.valueOf(matematico.Matematico.redondear2decimales(precio_final * fp2.getPorcentajepago3() / 100)));
        fila1[3] = fp2.getIid_tr_p3().getDescripcion();
        fila1[4] = fp2.getCobrado3();
        return fila1;
    }

    private Object[] rellenarPlazoAdelantado4() {
        Object[] fila1 = new Object[5];
        fila1[0] = fp2.getNombreplazo4();
        fila1[1] = Util.convertirPuntoAComa(String.valueOf(fp2.getPorcentajepago4()));
        fila1[2] = matematico.Matematico.redondear2decimales(precio_final * fp2.getPorcentajepago4() / 100);
        fp2.setImportep4((Double) fila1[2]);
        fila1[2] = Util.convertirPuntoAComa(String.valueOf(matematico.Matematico.redondear2decimales(precio_final * fp2.getPorcentajepago4() / 100)));
        fila1[3] = fp2.getIid_tr_p4().getDescripcion();
        fila1[4] = fp2.getCobrado4();
        return fila1;
    }

    private Object[] rellenarPlazoAdelantado5() {
        Object[] fila1 = new Object[5];
        fila1[0] = fp2.getNombreplazo5();
        fila1[1] = Util.convertirPuntoAComa(String.valueOf(fp2.getPorcentajepago5()));
        fila1[2] = matematico.Matematico.redondear2decimales(precio_final * fp2.getPorcentajepago5() / 100);
        fp2.setImportep5((Double) fila1[2]);
        fila1[2] = Util.convertirPuntoAComa(String.valueOf(matematico.Matematico.redondear2decimales(precio_final * fp2.getPorcentajepago5() / 100)));
        fila1[3] = fp2.getIid_tr_p5().getDescripcion();
        fila1[4] = fp2.getCobrado5();
        return fila1;
    }

    private Object[] rellenarPlazoAdelantado6() {
        Object[] fila1 = new Object[5];
        fila1[0] = fp2.getNombreplazo6();
        fila1[1] = Util.convertirPuntoAComa(String.valueOf(fp2.getPorcentajepago6()));
        fila1[2] = matematico.Matematico.redondear2decimales(precio_final * fp2.getPorcentajepago6() / 100);
        fp2.setImportep6((Double) fila1[2]);
        fila1[2] = Util.convertirPuntoAComa(String.valueOf(matematico.Matematico.redondear2decimales(precio_final * fp2.getPorcentajepago6() / 100)));
        fila1[3] = fp2.getIid_tr_p6().getDescripcion();
        fila1[4] = fp2.getCobrado6();
        return fila1;
    }

    private Object[] rellenarPlazoAdelantado7() {
        Object[] fila1 = new Object[5];
        fila1[0] = fp2.getNombreplazo7();
        fila1[1] = Util.convertirPuntoAComa(String.valueOf(fp2.getPorcentajepago7()));
        fila1[2] = matematico.Matematico.redondear2decimales(precio_final * fp2.getPorcentajepago7() / 100);
        fp2.setImportep7((Double) fila1[2]);
        fila1[2] = Util.convertirPuntoAComa(String.valueOf(matematico.Matematico.redondear2decimales(precio_final * fp2.getPorcentajepago7() / 100)));
        fila1[3] = fp2.getIid_tr_p7().getDescripcion();
        fila1[4] = fp2.getCobrado7();
        return fila1;
    }

    private Object[] rellenarPlazoAdelantado8() {
        Object[] fila1 = new Object[5];
        fila1[0] = fp2.getNombreplazo8();
        fila1[1] = Util.convertirPuntoAComa(String.valueOf(fp2.getPorcentajepago8()));
        fila1[2] = matematico.Matematico.redondear2decimales(precio_final * fp2.getPorcentajepago8() / 100);
        fp2.setImportep8((Double) fila1[2]);
        fila1[2] = Util.convertirPuntoAComa(String.valueOf(matematico.Matematico.redondear2decimales(precio_final * fp2.getPorcentajepago8() / 100)));
        fila1[3] = fp2.getIid_tr_p8().getDescripcion();
        fila1[4] = fp2.getCobrado8();
        return fila1;
    }

    private Object[] rellenarPlazoAdelantado9() {
        Object[] fila1 = new Object[5];
        fila1[0] = fp2.getNombreplazo9();
        fila1[1] = Util.convertirPuntoAComa(String.valueOf(fp2.getPorcentajepago9()));
        fila1[2] = matematico.Matematico.redondear2decimales(precio_final * fp2.getPorcentajepago9() / 100);
        fp2.setImportep9((Double) fila1[2]);
        fila1[2] = Util.convertirPuntoAComa(String.valueOf(matematico.Matematico.redondear2decimales(precio_final * fp2.getPorcentajepago9() / 100)));
        fila1[3] = fp2.getIid_tr_p9().getDescripcion();
        fila1[4] = fp2.getCobrado9();
        return fila1 = new Object[5];
    }

    private Object[] rellenarPlazoAdelantado10() {
        Object[] fila1 = new Object[5];
        fila1[0] = fp2.getNombreplazo10();
        fila1[1] = Util.convertirPuntoAComa(String.valueOf(fp2.getPorcentajepago10()));
        fila1[2] = matematico.Matematico.redondear2decimales(precio_final * fp2.getPorcentajepago10() / 100);
        fp2.setImportep10((Double) fila1[2]);
        fila1[2] = Util.convertirPuntoAComa(String.valueOf(matematico.Matematico.redondear2decimales(precio_final * fp2.getPorcentajepago10() / 100)));
        fila1[3] = fp2.getIid_tr_p10().getDescripcion();
        fila1[4] = fp2.getCobrado10();
        return fila1;
    }

    protected void disminuirVencimientos(double porc) {
        double disminuir = matematico.Matematico.redondear2decimales(porc / fp2.getNumplazosvencimiento());
        int numPlazosVencimientos = fp2.getNumplazosvencimiento();

        if (numPlazosVencimientos == 1) {
            fp2.setPlazopm1(matematico.Matematico.redondear2decimales(fp2.getPlazopm1() - disminuir));
        } else if (numPlazosVencimientos == 2) {
            fp2.setPlazopm1(matematico.Matematico.redondear2decimales(fp2.getPlazopm1() - disminuir));
            fp2.setPlazopm2(matematico.Matematico.redondear2decimales(fp2.getPlazopm2() - porc + disminuir));
        } else if (numPlazosVencimientos == 3) {
            fp2.setPlazopm1(matematico.Matematico.redondear2decimales(fp2.getPlazopm1() - disminuir));
            fp2.setPlazopm2(matematico.Matematico.redondear2decimales(fp2.getPlazopm2() - disminuir));
            fp2.setPlazopm3(matematico.Matematico.redondear2decimales(fp2.getPlazopm3() - porc + disminuir + disminuir));
        } else if (numPlazosVencimientos == 4) {
            fp2.setPlazopm1(matematico.Matematico.redondear2decimales(fp2.getPlazopm1() - disminuir));
            fp2.setPlazopm2(matematico.Matematico.redondear2decimales(fp2.getPlazopm2() - disminuir));
            fp2.setPlazopm3(matematico.Matematico.redondear2decimales(fp2.getPlazopm3() - disminuir));
            fp2.setPlazopm4(matematico.Matematico.redondear2decimales(fp2.getPlazopm4() - porc + disminuir + disminuir + disminuir));
        } else if (numPlazosVencimientos == 5) {
            fp2.setPlazopm1(matematico.Matematico.redondear2decimales(fp2.getPlazopm1() - disminuir));
            fp2.setPlazopm2(matematico.Matematico.redondear2decimales(fp2.getPlazopm2() - disminuir));
            fp2.setPlazopm3(matematico.Matematico.redondear2decimales(fp2.getPlazopm3() - disminuir));
            fp2.setPlazopm4(matematico.Matematico.redondear2decimales(fp2.getPlazopm4() - disminuir));
            fp2.setPlazopm5(matematico.Matematico.redondear2decimales(fp2.getPlazopm5() - porc + disminuir + disminuir + disminuir + disminuir));
        } else if (numPlazosVencimientos == 6) {
            fp2.setPlazopm1(matematico.Matematico.redondear2decimales(fp2.getPlazopm1() - disminuir));
            fp2.setPlazopm2(matematico.Matematico.redondear2decimales(fp2.getPlazopm2() - disminuir));
            fp2.setPlazopm3(matematico.Matematico.redondear2decimales(fp2.getPlazopm3() - disminuir));
            fp2.setPlazopm4(matematico.Matematico.redondear2decimales(fp2.getPlazopm4() - disminuir));
            fp2.setPlazopm5(matematico.Matematico.redondear2decimales(fp2.getPlazopm5() - disminuir));
            fp2.setPlazopm6(matematico.Matematico.redondear2decimales(fp2.getPlazopm6() - porc + disminuir + disminuir + disminuir + disminuir + disminuir));
        } else if (numPlazosVencimientos == 7) {
            fp2.setPlazopm1(matematico.Matematico.redondear2decimales(fp2.getPlazopm1() - disminuir));
            fp2.setPlazopm2(matematico.Matematico.redondear2decimales(fp2.getPlazopm2() - disminuir));
            fp2.setPlazopm3(matematico.Matematico.redondear2decimales(fp2.getPlazopm3() - disminuir));
            fp2.setPlazopm4(matematico.Matematico.redondear2decimales(fp2.getPlazopm4() - disminuir));
            fp2.setPlazopm5(matematico.Matematico.redondear2decimales(fp2.getPlazopm5() - disminuir));
            fp2.setPlazopm6(matematico.Matematico.redondear2decimales(fp2.getPlazopm6() - disminuir));
            fp2.setPlazopm6(matematico.Matematico.redondear2decimales(fp2.getPlazopm7() - porc + disminuir + disminuir + disminuir + disminuir + disminuir + disminuir));
        } else if (numPlazosVencimientos == 8) {
            fp2.setPlazopm1(matematico.Matematico.redondear2decimales(fp2.getPlazopm1() - disminuir));
            fp2.setPlazopm2(matematico.Matematico.redondear2decimales(fp2.getPlazopm2() - disminuir));
            fp2.setPlazopm3(matematico.Matematico.redondear2decimales(fp2.getPlazopm3() - disminuir));
            fp2.setPlazopm4(matematico.Matematico.redondear2decimales(fp2.getPlazopm4() - disminuir));
            fp2.setPlazopm5(matematico.Matematico.redondear2decimales(fp2.getPlazopm5() - disminuir));
            fp2.setPlazopm6(matematico.Matematico.redondear2decimales(fp2.getPlazopm6() - disminuir));
            fp2.setPlazopm7(matematico.Matematico.redondear2decimales(fp2.getPlazopm7() - disminuir));
            fp2.setPlazopm6(matematico.Matematico.redondear2decimales(fp2.getPlazopm8() - porc + disminuir + disminuir + disminuir + disminuir + disminuir + disminuir + disminuir));
        } else if (numPlazosVencimientos == 9) {
            fp2.setPlazopm1(matematico.Matematico.redondear2decimales(fp2.getPlazopm1() - disminuir));
            fp2.setPlazopm2(matematico.Matematico.redondear2decimales(fp2.getPlazopm2() - disminuir));
            fp2.setPlazopm3(matematico.Matematico.redondear2decimales(fp2.getPlazopm3() - disminuir));
            fp2.setPlazopm4(matematico.Matematico.redondear2decimales(fp2.getPlazopm4() - disminuir));
            fp2.setPlazopm5(matematico.Matematico.redondear2decimales(fp2.getPlazopm5() - disminuir));
            fp2.setPlazopm6(matematico.Matematico.redondear2decimales(fp2.getPlazopm6() - disminuir));
            fp2.setPlazopm7(matematico.Matematico.redondear2decimales(fp2.getPlazopm7() - disminuir));
            fp2.setPlazopm8(matematico.Matematico.redondear2decimales(fp2.getPlazopm8() - disminuir));
            fp2.setPlazopm6(matematico.Matematico.redondear2decimales(fp2.getPlazopm9() - porc + disminuir + disminuir + disminuir + disminuir + disminuir + disminuir + disminuir + disminuir));
        } else if (numPlazosVencimientos == 10) {
            fp2.setPlazopm1(matematico.Matematico.redondear2decimales(fp2.getPlazopm1() - disminuir));
            fp2.setPlazopm2(matematico.Matematico.redondear2decimales(fp2.getPlazopm2() - disminuir));
            fp2.setPlazopm3(matematico.Matematico.redondear2decimales(fp2.getPlazopm3() - disminuir));
            fp2.setPlazopm4(matematico.Matematico.redondear2decimales(fp2.getPlazopm4() - disminuir));
            fp2.setPlazopm5(matematico.Matematico.redondear2decimales(fp2.getPlazopm5() - disminuir));
            fp2.setPlazopm6(matematico.Matematico.redondear2decimales(fp2.getPlazopm6() - disminuir));
            fp2.setPlazopm7(matematico.Matematico.redondear2decimales(fp2.getPlazopm7() - disminuir));
            fp2.setPlazopm8(matematico.Matematico.redondear2decimales(fp2.getPlazopm8() - disminuir));
            fp2.setPlazopm9(matematico.Matematico.redondear2decimales(fp2.getPlazopm9() - disminuir));
            fp2.setPlazopm6(matematico.Matematico.redondear2decimales(fp2.getPlazopm10() - porc + disminuir + disminuir + disminuir + disminuir + disminuir + disminuir + disminuir + disminuir + disminuir));
        }
    }

    protected void disminuirVencimientos(double porcentaje, double importe) {
        double disminuirPorcentaje = matematico.Matematico.redondear2decimales(porcentaje / fp2.getNumplazosvencimiento());
        double disminuirImporte = matematico.Matematico.redondear2decimales(importe / fp2.getNumplazosvencimiento());
        int numPlazosVencimientos = fp2.getNumplazosvencimiento();

        if (numPlazosVencimientos == 1) {
            fp2.setPlazopm1(matematico.Matematico.redondear2decimales(fp2.getPlazopm1() - disminuirPorcentaje));
            fp2.setImportev1(matematico.Matematico.redondear2decimales(fp2.getImportev1() - disminuirImporte));
        } else if (numPlazosVencimientos == 2) {
            fp2.setPlazopm1(matematico.Matematico.redondear2decimales(fp2.getPlazopm1() - disminuirPorcentaje));
            fp2.setPlazopm2(matematico.Matematico.redondear2decimales(fp2.getPlazopm2() - porcentaje + disminuirPorcentaje));

            fp2.setImportev1(matematico.Matematico.redondear2decimales(fp2.getImportev1() - disminuirImporte));
            fp2.setImportev2(matematico.Matematico.redondear2decimales(fp2.getImportev2() - importe + disminuirImporte));
        } else if (numPlazosVencimientos == 3) {
            fp2.setPlazopm1(matematico.Matematico.redondear2decimales(fp2.getPlazopm1() - disminuirPorcentaje));
            fp2.setPlazopm2(matematico.Matematico.redondear2decimales(fp2.getPlazopm2() - disminuirPorcentaje));
            fp2.setPlazopm3(matematico.Matematico.redondear2decimales(fp2.getPlazopm3() - porcentaje + disminuirPorcentaje + disminuirPorcentaje));

            fp2.setImportev1(matematico.Matematico.redondear2decimales(fp2.getImportev1() - disminuirImporte));
            fp2.setImportev2(matematico.Matematico.redondear2decimales(fp2.getImportev2() - disminuirImporte));
            fp2.setImportev3(matematico.Matematico.redondear2decimales(fp2.getImportev3() - importe + disminuirImporte + disminuirImporte));
        } else if (numPlazosVencimientos == 4) {
            fp2.setPlazopm1(matematico.Matematico.redondear2decimales(fp2.getPlazopm1() - disminuirPorcentaje));
            fp2.setPlazopm2(matematico.Matematico.redondear2decimales(fp2.getPlazopm2() - disminuirPorcentaje));
            fp2.setPlazopm3(matematico.Matematico.redondear2decimales(fp2.getPlazopm3() - disminuirPorcentaje));
            fp2.setPlazopm4(matematico.Matematico.redondear2decimales(fp2.getPlazopm4() - porcentaje + disminuirPorcentaje + disminuirPorcentaje + disminuirPorcentaje));

            fp2.setImportev1(matematico.Matematico.redondear2decimales(fp2.getImportev1() - disminuirImporte));
            fp2.setImportev2(matematico.Matematico.redondear2decimales(fp2.getImportev2() - disminuirImporte));
            fp2.setImportev3(matematico.Matematico.redondear2decimales(fp2.getImportev3() - disminuirImporte));
            fp2.setImportev4(matematico.Matematico.redondear2decimales(fp2.getImportev4() - importe + disminuirImporte + disminuirImporte + disminuirImporte));
        } else if (numPlazosVencimientos == 5) {
            fp2.setPlazopm1(matematico.Matematico.redondear2decimales(fp2.getPlazopm1() - disminuirPorcentaje));
            fp2.setPlazopm2(matematico.Matematico.redondear2decimales(fp2.getPlazopm2() - disminuirPorcentaje));
            fp2.setPlazopm3(matematico.Matematico.redondear2decimales(fp2.getPlazopm3() - disminuirPorcentaje));
            fp2.setPlazopm4(matematico.Matematico.redondear2decimales(fp2.getPlazopm4() - disminuirPorcentaje));
            fp2.setPlazopm5(matematico.Matematico.redondear2decimales(fp2.getPlazopm5() - porcentaje + disminuirPorcentaje + disminuirPorcentaje + disminuirPorcentaje + disminuirPorcentaje));

            fp2.setImportev1(matematico.Matematico.redondear2decimales(fp2.getImportev1() - disminuirImporte));
            fp2.setImportev2(matematico.Matematico.redondear2decimales(fp2.getImportev2() - disminuirImporte));
            fp2.setImportev3(matematico.Matematico.redondear2decimales(fp2.getImportev3() - disminuirImporte));
            fp2.setImportev4(matematico.Matematico.redondear2decimales(fp2.getImportev4() - disminuirImporte));
            fp2.setImportev5(matematico.Matematico.redondear2decimales(fp2.getImportev5() - importe + disminuirImporte + disminuirImporte + disminuirImporte + disminuirImporte));
        } else if (numPlazosVencimientos == 6) {
            fp2.setPlazopm1(matematico.Matematico.redondear2decimales(fp2.getPlazopm1() - disminuirPorcentaje));
            fp2.setPlazopm2(matematico.Matematico.redondear2decimales(fp2.getPlazopm2() - disminuirPorcentaje));
            fp2.setPlazopm3(matematico.Matematico.redondear2decimales(fp2.getPlazopm3() - disminuirPorcentaje));
            fp2.setPlazopm4(matematico.Matematico.redondear2decimales(fp2.getPlazopm4() - disminuirPorcentaje));
            fp2.setPlazopm5(matematico.Matematico.redondear2decimales(fp2.getPlazopm5() - disminuirPorcentaje));
            fp2.setPlazopm6(matematico.Matematico.redondear2decimales(fp2.getPlazopm6() - porcentaje + disminuirPorcentaje + disminuirPorcentaje + disminuirPorcentaje + disminuirPorcentaje + disminuirPorcentaje));

            fp2.setImportev1(matematico.Matematico.redondear2decimales(fp2.getImportev1() - disminuirImporte));
            fp2.setImportev2(matematico.Matematico.redondear2decimales(fp2.getImportev2() - disminuirImporte));
            fp2.setImportev3(matematico.Matematico.redondear2decimales(fp2.getImportev3() - disminuirImporte));
            fp2.setImportev4(matematico.Matematico.redondear2decimales(fp2.getImportev4() - disminuirImporte));
            fp2.setImportev5(matematico.Matematico.redondear2decimales(fp2.getImportev5() - disminuirImporte));
            fp2.setImportev6(matematico.Matematico.redondear2decimales(fp2.getImportev6() - importe + disminuirImporte + disminuirImporte + disminuirImporte + disminuirImporte + disminuirImporte));
        } else if (numPlazosVencimientos == 7) {
            fp2.setPlazopm1(matematico.Matematico.redondear2decimales(fp2.getPlazopm1() - disminuirPorcentaje));
            fp2.setPlazopm2(matematico.Matematico.redondear2decimales(fp2.getPlazopm2() - disminuirPorcentaje));
            fp2.setPlazopm3(matematico.Matematico.redondear2decimales(fp2.getPlazopm3() - disminuirPorcentaje));
            fp2.setPlazopm4(matematico.Matematico.redondear2decimales(fp2.getPlazopm4() - disminuirPorcentaje));
            fp2.setPlazopm5(matematico.Matematico.redondear2decimales(fp2.getPlazopm5() - disminuirPorcentaje));
            fp2.setPlazopm6(matematico.Matematico.redondear2decimales(fp2.getPlazopm6() - disminuirPorcentaje));
            fp2.setPlazopm6(matematico.Matematico.redondear2decimales(fp2.getPlazopm7() - porcentaje + disminuirPorcentaje + disminuirPorcentaje + disminuirPorcentaje + disminuirPorcentaje + disminuirPorcentaje + disminuirPorcentaje));

            fp2.setImportev1(matematico.Matematico.redondear2decimales(fp2.getImportev1() - disminuirImporte));
            fp2.setImportev2(matematico.Matematico.redondear2decimales(fp2.getImportev2() - disminuirImporte));
            fp2.setImportev3(matematico.Matematico.redondear2decimales(fp2.getImportev3() - disminuirImporte));
            fp2.setImportev4(matematico.Matematico.redondear2decimales(fp2.getImportev4() - disminuirImporte));
            fp2.setImportev5(matematico.Matematico.redondear2decimales(fp2.getImportev5() - disminuirImporte));
            fp2.setImportev6(matematico.Matematico.redondear2decimales(fp2.getImportev6() - disminuirImporte));
            fp2.setImportev7(matematico.Matematico.redondear2decimales(fp2.getImportev7() - importe + disminuirImporte + disminuirImporte + disminuirImporte + disminuirImporte + disminuirImporte + disminuirImporte));
        } else if (numPlazosVencimientos == 8) {
            fp2.setPlazopm1(matematico.Matematico.redondear2decimales(fp2.getPlazopm1() - disminuirPorcentaje));
            fp2.setPlazopm2(matematico.Matematico.redondear2decimales(fp2.getPlazopm2() - disminuirPorcentaje));
            fp2.setPlazopm3(matematico.Matematico.redondear2decimales(fp2.getPlazopm3() - disminuirPorcentaje));
            fp2.setPlazopm4(matematico.Matematico.redondear2decimales(fp2.getPlazopm4() - disminuirPorcentaje));
            fp2.setPlazopm5(matematico.Matematico.redondear2decimales(fp2.getPlazopm5() - disminuirPorcentaje));
            fp2.setPlazopm6(matematico.Matematico.redondear2decimales(fp2.getPlazopm6() - disminuirPorcentaje));
            fp2.setPlazopm7(matematico.Matematico.redondear2decimales(fp2.getPlazopm7() - disminuirPorcentaje));
            fp2.setPlazopm6(matematico.Matematico.redondear2decimales(fp2.getPlazopm8() - porcentaje + disminuirPorcentaje + disminuirPorcentaje + disminuirPorcentaje + disminuirPorcentaje + disminuirPorcentaje + disminuirPorcentaje + disminuirPorcentaje));

            fp2.setImportev1(matematico.Matematico.redondear2decimales(fp2.getImportev1() - disminuirImporte));
            fp2.setImportev2(matematico.Matematico.redondear2decimales(fp2.getImportev2() - disminuirImporte));
            fp2.setImportev3(matematico.Matematico.redondear2decimales(fp2.getImportev3() - disminuirImporte));
            fp2.setImportev4(matematico.Matematico.redondear2decimales(fp2.getImportev4() - disminuirImporte));
            fp2.setImportev5(matematico.Matematico.redondear2decimales(fp2.getImportev5() - disminuirImporte));
            fp2.setImportev6(matematico.Matematico.redondear2decimales(fp2.getImportev6() - disminuirImporte));
            fp2.setImportev7(matematico.Matematico.redondear2decimales(fp2.getImportev7() - disminuirImporte));
            fp2.setImportev8(matematico.Matematico.redondear2decimales(fp2.getImportev8() - importe + disminuirImporte + disminuirImporte + disminuirImporte + disminuirImporte + disminuirImporte + disminuirImporte + disminuirImporte));
        } else if (numPlazosVencimientos == 9) {
            fp2.setPlazopm1(matematico.Matematico.redondear2decimales(fp2.getPlazopm1() - disminuirPorcentaje));
            fp2.setPlazopm2(matematico.Matematico.redondear2decimales(fp2.getPlazopm2() - disminuirPorcentaje));
            fp2.setPlazopm3(matematico.Matematico.redondear2decimales(fp2.getPlazopm3() - disminuirPorcentaje));
            fp2.setPlazopm4(matematico.Matematico.redondear2decimales(fp2.getPlazopm4() - disminuirPorcentaje));
            fp2.setPlazopm5(matematico.Matematico.redondear2decimales(fp2.getPlazopm5() - disminuirPorcentaje));
            fp2.setPlazopm6(matematico.Matematico.redondear2decimales(fp2.getPlazopm6() - disminuirPorcentaje));
            fp2.setPlazopm7(matematico.Matematico.redondear2decimales(fp2.getPlazopm7() - disminuirPorcentaje));
            fp2.setPlazopm8(matematico.Matematico.redondear2decimales(fp2.getPlazopm8() - disminuirPorcentaje));
            fp2.setPlazopm6(matematico.Matematico.redondear2decimales(fp2.getPlazopm9() - porcentaje + disminuirPorcentaje + disminuirPorcentaje + disminuirPorcentaje + disminuirPorcentaje + disminuirPorcentaje + disminuirPorcentaje + disminuirPorcentaje + disminuirPorcentaje));

            fp2.setImportev1(matematico.Matematico.redondear2decimales(fp2.getImportev1() - disminuirImporte));
            fp2.setImportev2(matematico.Matematico.redondear2decimales(fp2.getImportev2() - disminuirImporte));
            fp2.setImportev3(matematico.Matematico.redondear2decimales(fp2.getImportev3() - disminuirImporte));
            fp2.setImportev4(matematico.Matematico.redondear2decimales(fp2.getImportev4() - disminuirImporte));
            fp2.setImportev5(matematico.Matematico.redondear2decimales(fp2.getImportev5() - disminuirImporte));
            fp2.setImportev6(matematico.Matematico.redondear2decimales(fp2.getImportev6() - disminuirImporte));
            fp2.setImportev7(matematico.Matematico.redondear2decimales(fp2.getImportev7() - disminuirImporte));
            fp2.setImportev8(matematico.Matematico.redondear2decimales(fp2.getImportev8() - disminuirImporte));
            fp2.setImportev9(matematico.Matematico.redondear2decimales(fp2.getImportev9() - importe + disminuirImporte + disminuirImporte + disminuirImporte + disminuirImporte + disminuirImporte + disminuirImporte + disminuirImporte + disminuirImporte));
        } else if (numPlazosVencimientos == 10) {
            fp2.setPlazopm1(matematico.Matematico.redondear2decimales(fp2.getPlazopm1() - disminuirPorcentaje));
            fp2.setPlazopm2(matematico.Matematico.redondear2decimales(fp2.getPlazopm2() - disminuirPorcentaje));
            fp2.setPlazopm3(matematico.Matematico.redondear2decimales(fp2.getPlazopm3() - disminuirPorcentaje));
            fp2.setPlazopm4(matematico.Matematico.redondear2decimales(fp2.getPlazopm4() - disminuirPorcentaje));
            fp2.setPlazopm5(matematico.Matematico.redondear2decimales(fp2.getPlazopm5() - disminuirPorcentaje));
            fp2.setPlazopm6(matematico.Matematico.redondear2decimales(fp2.getPlazopm6() - disminuirPorcentaje));
            fp2.setPlazopm7(matematico.Matematico.redondear2decimales(fp2.getPlazopm7() - disminuirPorcentaje));
            fp2.setPlazopm8(matematico.Matematico.redondear2decimales(fp2.getPlazopm8() - disminuirPorcentaje));
            fp2.setPlazopm9(matematico.Matematico.redondear2decimales(fp2.getPlazopm9() - disminuirPorcentaje));
            fp2.setPlazopm6(matematico.Matematico.redondear2decimales(fp2.getPlazopm10() - porcentaje + disminuirPorcentaje + disminuirPorcentaje + disminuirPorcentaje + disminuirPorcentaje + disminuirPorcentaje + disminuirPorcentaje + disminuirPorcentaje + disminuirPorcentaje + disminuirPorcentaje));

            fp2.setImportev1(matematico.Matematico.redondear2decimales(fp2.getImportev1() - disminuirImporte));
            fp2.setImportev2(matematico.Matematico.redondear2decimales(fp2.getImportev2() - disminuirImporte));
            fp2.setImportev3(matematico.Matematico.redondear2decimales(fp2.getImportev3() - disminuirImporte));
            fp2.setImportev4(matematico.Matematico.redondear2decimales(fp2.getImportev4() - disminuirImporte));
            fp2.setImportev5(matematico.Matematico.redondear2decimales(fp2.getImportev5() - disminuirImporte));
            fp2.setImportev6(matematico.Matematico.redondear2decimales(fp2.getImportev6() - disminuirImporte));
            fp2.setImportev7(matematico.Matematico.redondear2decimales(fp2.getImportev7() - disminuirImporte));
            fp2.setImportev8(matematico.Matematico.redondear2decimales(fp2.getImportev8() - disminuirImporte));
            fp2.setImportev9(matematico.Matematico.redondear2decimales(fp2.getImportev9() - disminuirImporte));
            fp2.setImportev10(matematico.Matematico.redondear2decimales(fp2.getImportev10() - importe + disminuirImporte + disminuirImporte + disminuirImporte + disminuirImporte + disminuirImporte + disminuirImporte + disminuirImporte + disminuirImporte + disminuirImporte));
        }
    }

    protected void disminuirVencimientosModificacion(double porcentaje, double importe) {
        double disminuirPorcentaje = porcentaje / (fp2.getNumplazosvencimiento() - 1);
        double disminuirImporte = importe / (fp2.getNumplazosvencimiento() - 1);

        fp2.setImportev1(matematico.Matematico.redondear2decimales(fp2.getImportev1() - disminuirImporte));
        fp2.setImportev2(matematico.Matematico.redondear2decimales(fp2.getImportev2() - disminuirImporte));
        fp2.setImportev3(matematico.Matematico.redondear2decimales(fp2.getImportev3() - disminuirImporte));
        fp2.setImportev4(matematico.Matematico.redondear2decimales(fp2.getImportev4() - disminuirImporte));
        fp2.setImportev5(matematico.Matematico.redondear2decimales(fp2.getImportev5() - disminuirImporte));
        fp2.setImportev6(matematico.Matematico.redondear2decimales(fp2.getImportev6() - disminuirImporte));
        fp2.setImportev7(matematico.Matematico.redondear2decimales(fp2.getImportev7() - disminuirImporte));
        fp2.setImportev8(matematico.Matematico.redondear2decimales(fp2.getImportev8() - disminuirImporte));
        fp2.setImportev9(matematico.Matematico.redondear2decimales(fp2.getImportev9() - disminuirImporte));
        fp2.setImportev10(matematico.Matematico.redondear2decimales(fp2.getImportev10() - disminuirImporte));

        fp2.setPlazopm1(matematico.Matematico.redondear2decimales(fp2.getPlazopm1() - disminuirPorcentaje));
        fp2.setPlazopm2(matematico.Matematico.redondear2decimales(fp2.getPlazopm2() - disminuirPorcentaje));
        fp2.setPlazopm3(matematico.Matematico.redondear2decimales(fp2.getPlazopm3() - disminuirPorcentaje));
        fp2.setPlazopm4(matematico.Matematico.redondear2decimales(fp2.getPlazopm4() - disminuirPorcentaje));
        fp2.setPlazopm5(matematico.Matematico.redondear2decimales(fp2.getPlazopm5() - disminuirPorcentaje));
        fp2.setPlazopm6(matematico.Matematico.redondear2decimales(fp2.getPlazopm6() - disminuirPorcentaje));
        fp2.setPlazopm7(matematico.Matematico.redondear2decimales(fp2.getPlazopm7() - disminuirPorcentaje));
        fp2.setPlazopm8(matematico.Matematico.redondear2decimales(fp2.getPlazopm8() - disminuirPorcentaje));
        fp2.setPlazopm9(matematico.Matematico.redondear2decimales(fp2.getPlazopm9() - disminuirPorcentaje));
        fp2.setPlazopm10(matematico.Matematico.redondear2decimales(fp2.getPlazopm10() - disminuirPorcentaje));
    }

    protected void rellenarCliente(Agentes cliente) {
        tCodCliente.setText(cliente.getCod_agente());
        lbTercero.setVisible(false);

        if (!cliente.getTerceros()) {
            tDniCliente.setText(cliente.getCif_nif());
            p.setClase_documento(BaseDatos.getClaseDocumentosByIid(p.getClase_documento().getIid()));
            if (p.getClase_documento().getDescripcion().equals(Constantes.FACTURA)) {
                tNombreCliente.setText(cliente.getNombre_fiscal());
                tDireccionCliente.setText(cliente.getDireccion_fiscal());
                tCpCliente.setText(String.valueOf(cliente.getCodigo_postal_fiscal()));
                tLocalidadCliente.setText(cliente.getPoblacion_fiscal());
                tProvinciaCliente.setText(cliente.getProvincia());
            } else {
                tNombreCliente.setText(cliente.getNombre_comercial());
                tDireccionCliente.setText(cliente.getDireccion());
                tCpCliente.setText(String.valueOf(cliente.getCodigo_postal()));
                tLocalidadCliente.setText(cliente.getPoblacion());
                tProvinciaCliente.setText(cliente.getProvincia());
            }

            tPaisCliente.setText(cliente.getPais());
            tTelefonoCliente.setText(cliente.getTelefono());
            tEmailCliente.setText(cliente.getEmail());
            calcularNuevoIva(cliente);
            FormaPago ffpp = cliente.getFormaPago();

            if (ffpp != null && ffpp.getIid() != null) {
                ffpp = BaseDatos.obtenerFormaPagoPorIid(ffpp.getIid());
                cformapago.setSelectedItem(ffpp.getCodigo());
            } else {
                cformapago.setSelectedItem(Constantes.VACIO);
                tformapago.setText("");
            }
        } else {
            tDniCliente.setText(cliente.getCif_nif());
            //Tiene subcliente, el código de cliente se mostrará
            String etiqueta = cliente.getNombre_comercial() + " (" + cliente.getCod_agente() + ")";
            lbTercero.setText(etiqueta);
            lbTercero.setVisible(true);

            tNombreCliente.setText("");
            tDireccionCliente.setText("");
            tCpCliente.setText("");
            tLocalidadCliente.setText("");
            tProvinciaCliente.setText("");
            tPaisCliente.setText("");
            tTelefonoCliente.setText("");
            tEmailCliente.setText("");

            calcularNuevoIva(cliente);
            FormaPago ffpp = cliente.getFormaPago();

            if (ffpp != null && ffpp.getIid() != null) {
                ffpp = BaseDatos.obtenerFormaPagoPorIid(ffpp.getIid());
                cformapago.setSelectedItem(ffpp.getCodigo());
            } else {
                cformapago.setSelectedItem(Constantes.VACIO);
                tformapago.setText("");
            }
        }
    }

    private void cambiarCodigosDac(int indice) {
        Integer clave;
        RellenarDac rdac;
        ArrayList<Integer> listaIndicesDac = new ArrayList<Integer>();

        for (Iterator<Integer> ite = rellenarDacMap.keySet().iterator(); ite.hasNext();) {
            clave = ite.next();
            if (clave >= indice) {
                listaIndicesDac.add(0, clave);
            }
        }

        Iterator<Integer> iter = listaIndicesDac.iterator();
        while (iter.hasNext()) {
            clave = iter.next();
            rdac = (RellenarDac) rellenarDacMap.get(clave);
            rellenarDacMap.remove(clave);
            rellenarDacMap.put(clave + 1, rdac);
        }
    }

    private void cambiarCodigosDacBorradoLinea(int indice) {
        Integer clave;
        RellenarDac rdac;
        ArrayList<Integer> listaIndicesDac = new ArrayList<Integer>();

        for (Iterator<Integer> ite = rellenarDacMap.keySet().iterator(); ite.hasNext();) {
            clave = ite.next();
            if (clave >= indice) {
                listaIndicesDac.add(0, clave);
            }
        }

        Iterator<Integer> iter = listaIndicesDac.iterator();
        while (iter.hasNext()) {
            clave = iter.next();
            rdac = (RellenarDac) rellenarDacMap.get(clave);
            rellenarDacMap.remove(clave);
            rellenarDacMap.put(clave - 1, rdac);
        }
    }

    private void cambiarCodigos() {
        Iterator<NuevaLineaPresupuesto> it;
        NuevaLineaPresupuesto lip;
        int ii = 1;
        for (it = listaArticulos.iterator(); it.hasNext();) {
            lip = it.next();
            lip.setCodigo(ii);
            ii++;
        }
    }

    public HashMap getRellenarDacMap() {
        return rellenarDacMap;
    }

    public RellenarDac getRellenarDac(int codigo) {
        return (RellenarDac) rellenarDacMap.get(codigo);
    }

    protected void anadirLineaPresupuesto() {
        NuevaLineaPresupuesto lip = new NuevaLineaPresupuesto(this, num_articulos, e, u);
        panel.add(lip);
        panel.setVisible(true);
        panel.repaint();
        this.pack();
        Dimension dim = Util.getDimensiones(this.getSize());
        if (dim != null) {
            setResizable(true);
            setSize(dim);
            setResizable(false);
        }
        num_articulos++;
        listaArticulos.add(lip);
        reCalcularLineasVacias();
    }

    protected void reCalcularLineasVacias() {
        Component[] lista = panel.getComponents();
        NuevaLineaPresupuesto np;
        Component temp;
        List<Integer> posicionesVacias = new ArrayList<Integer>();
        int indice = 0;
        int indiceLineas = 0;
        int maxIndice = lista.length;
        while (indice < maxIndice) {
            temp = (Component) lista[indice];
            if (temp instanceof NuevaLineaPresupuesto) {
                np = (NuevaLineaPresupuesto) temp;
                if (np.getLineaOculta()) {
                    posicionesVacias.add(0, indiceLineas);
                }
                indiceLineas++;
            }
            indice++;
        }

        for (int in = 0; in < posicionesVacias.size(); in++) {
            panel.remove(posicionesVacias.get(in));
        }

        this.lineasVacias = 0;

        while (panel.getComponentCount() < Constantes.NUM_LINEAS_DOCUMENTO) {
            anadirLineaPresupuestoVacia();
        }

        panel.repaint();
        this.pack();
        Dimension dim = Util.getDimensiones(this.getSize());
        if (dim != null) {
            setResizable(true);
            setSize(dim);
            setResizable(false);
        }
    }

    protected void anadirLineaPresupuestoVacia() {
        NuevaLineaPresupuesto lip = new NuevaLineaPresupuesto(this, -1, e, u);
        lip.ocultarTodo();
        panel.add(lip);
        panel.setVisible(true);
        panel.repaint();
        this.pack();
        Dimension dim = Util.getDimensiones(this.getSize());
        if (dim != null) {
            setResizable(true);
            setSize(dim);
            setResizable(false);
        }
        lineasVacias++;
    }

    protected RellenarDac anadirLineaPresupuestoAlbaran(LineaPresupuesto lp, Articulo ar, Caracteristica cara) {
        mapaNuevoClaves.put(lp.getCodigo(), num_articulos);
        NuevaLineaPresupuesto lip = new NuevaLineaPresupuesto(this, num_articulos, e, lp, lp.getLineaArticulo(), u);
        panel.add(lip);
        panel.setVisible(true);
        panel.repaint();
        this.pack();
        Dimension dim = Util.getDimensiones(this.getSize());
        if (dim != null) {
            setResizable(true);
            setSize(dim);
            setResizable(false);
        }
        RellenarDac rdac = null;

        Dac dac = BaseDatos.obtenerDacPorCodigoArticulo(ar.getCod_articulo(), e.getIid());
        if (dac != null) {
            //Hay que abrir la ventana con las cosas del dac
            rdac = new RellenarDac(lip, e, dac, cara, "Titulo");
            rdac.setDefaultCloseOperation(RellenarDac.DISPOSE_ON_CLOSE);
            rdac.setLocationRelativeTo(null);
        }

        num_articulos++;
        listaArticulos.add(lip);
        reCalcularLineasVacias();
        return rdac;
    }

    protected void anadirLineaPresupuesto(LineaPresupuesto lp) {
        mapaNuevoClaves.put(lp.getCodigo(), num_articulos);
        NuevaLineaPresupuesto lip = new NuevaLineaPresupuesto(this, num_articulos, e, lp, lp.getLineaArticulo(), u);
        panel.add(lip);
        panel.setVisible(true);
        panel.repaint();
        this.pack();
        Dimension dim = Util.getDimensiones(this.getSize());
        if (dim != null) {
            setResizable(true);
            setSize(dim);
            setResizable(false);
        }
        num_articulos++;
        listaArticulos.add(lip);
        reCalcularLineasVacias();
    }

    protected void borrarLineaDocumento(int codigo) {
        if (codigo != (num_articulos - 1)) {
            //Solo borramos el panel si no es el ultimo
            panel.remove(codigo - 1);
            panel.repaint();
            this.pack();
            Dimension dim = Util.getDimensiones(this.getSize());
            if (dim != null) {
                setResizable(true);
                setSize(dim);
                setResizable(false);
            }
            Integer iidNlp = ((NuevaLineaPresupuesto) listaArticulos.get(codigo - 1)).getIid();
            if (iidNlp != null) {
                BaseDatos.eliminarCorteLonaByLineaPresupuesto(iidNlp);
                BaseDatos.eliminarCortePerfilByLineaPresupuesto(iidNlp);
            }
            listaArticulos.remove(codigo - 1);
            this.rellenarDacMap.remove(codigo);
            cambiarCodigos();
            cambiarCodigosDacBorradoLinea(codigo);
            num_articulos--;
            calcularPrecio(false);
            reCalcularLineasVacias();
        }
    }

    public Double calcularPrecio(Boolean calcular) {
        Double precio = 0.0D;
        if (!calcularPre) {
            calcularPre = calcular;
        }
        if (calcularPre) {
            double precio_total = 0;
            Iterator<NuevaLineaPresupuesto> it;
            for (it = listaArticulos.iterator(); it.hasNext();) {
                precio_total += it.next().getImporte();
            }
            lPrecioTotalBruto.setText(Util.convertirPuntoAComa(String.valueOf(matematico.Matematico.redondear3decimales(precio_total))));
            importe_total = precio_total;

            String sDto = tdto.getText();
            if (sDto.length() == 0) {
                sDto = "0";
            }
                    
            dto = Float.parseFloat(Util.convertirComaAPunto(sDto));
            precio_dto = matematico.Matematico.redondear2decimales(importe_total * dto / 100);
            limporte_dto.setText(Util.convertirPuntoAComa(String.valueOf(precio_dto)));

            double precio_aux = importe_total * ((100 - Double.parseDouble(Util.convertirComaAPunto(tdto.getText()))) / 100);
            precio_aux = matematico.Matematico.redondear2decimales(precio_aux);
            lprecio.setText(Util.convertirPuntoAComa(String.valueOf(precio_aux)));
            importe_total_dto = precio_aux;

            String sIva = tIva.getText();
            if (sIva.length() == 0) {
                sIva = "0";
            }
            precio_iva = importe_total_dto * (Double.parseDouble(Util.convertirComaAPunto(sIva))) / 100;
            precio_iva = matematico.Matematico.redondear2decimales(precio_iva);
            limporte_iva.setText(Util.convertirPuntoAComa(String.valueOf(precio_iva)));

            precio_final = importe_total_dto * (100 + Double.parseDouble(Util.convertirComaAPunto(sIva))) / 100;
            precio_final = matematico.Matematico.redondear2decimales(precio_final);
            lprecio_final.setText(Util.convertirPuntoAComa(String.valueOf(precio_final)));

            limpiarPlazosAdelantados();
            limpiarVencimientos();
            rellenarPlazosAdelantados();
            rellenarVencimientos();
            precio = precio_final;
        }
        return precio;
    }

    protected int getNumArticulos() {
        return listaArticulos.size();
    }

    protected List getListaArticulos() {
        return listaArticulos;
    }

    public String getCodigoCliente() {
        String res = "";
        if (this.tCodCliente.getText() != null) {
            res = tCodCliente.getText();
        }
        return res;
    }

    public String getTipoDocumento() {
        return cd.getDescripcion();
    }

    public void insertarRDAC(int codigo, RellenarDac rdac) {
        rellenarDacMap.put(codigo, rdac);
    }

    public void borrarRDAC(int codigo) {
        rellenarDacMap.remove(codigo);
    }

    public String getNombreCliente() {
        String res = "";
        if (this.tNombreCliente.getText() != null) {
            res = tNombreCliente.getText();
        }
        return res;
    }

    public String getReferencia() {
        String res = "";
        if (this.tReferencia.getText() != null) {
            res = tReferencia.getText();
        }
        return res;
    }

    public String getNumero() {
        String res = "";
        if (this.tnumero.getText() != null) {
            res = tnumero.getText();
        }
        return res;
    }

    private void crearAcciones() {
        KeyStroke escapeKeyStroke = KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false);
        Action escapeAction = new AbstractAction() {
            public void actionPerformed(ActionEvent e) {
                cerrarPresupuesto();
            }
        };
        getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(escapeKeyStroke, "ESCAPE");
        getRootPane().getActionMap().put("ESCAPE", escapeAction);

        KeyStroke f9KeyStroke = KeyStroke.getKeyStroke(KeyEvent.VK_F9, 0, false);
        Action f9Action = new AbstractAction() {
            public void actionPerformed(ActionEvent ev) {
                teclaF9();
            }
        };
        getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(f9KeyStroke, "F9");
        getRootPane().getActionMap().put("F9", f9Action);

        Dimension dim = Util.getDimensiones(this.getSize());
        if (dim != null) {
            setResizable(true);
            setSize(dim);
            setResizable(false);
        }
    }

    private void crearIconosBotones() {
        URL url = getClass().getResource("/iconos/cancelar.gif");
        ImageIcon icono = new ImageIcon(url);
        bcancelar.setIcon(icono);

        url = getClass().getResource("/iconos/guardarYvolver.png");
        icono = new ImageIcon(url);
        baceptar.setIcon(icono);

        url = getClass().getResource("/iconos/editar.png");
        icono = new ImageIcon(url);
        bmodificar.setIcon(icono);
        this.bmodificarplazo.setIcon(icono);
        this.bmodificarvencimiento.setIcon(icono);

        url = getClass().getResource("/iconos/guardar.png");
        icono = new ImageIcon(url);
        this.bguardar.setIcon(icono);

        url = getClass().getResource("/iconos/anadir.png");
        icono = new ImageIcon(url);
        this.bcrearplazo.setIcon(icono);
        this.bCrearVencimiento.setIcon(icono);

        url = getClass().getResource("/iconos/eliminar.png");
        icono = new ImageIcon(url);
        this.beliminarplazo.setIcon(icono);
        this.beliminarvencimiento.setIcon(icono);

        url = getClass().getResource("/iconos/pdf.png");
        icono = new ImageIcon(url);
        this.bCrearPdf.setIcon(icono);
        this.jMenuPDF.setIcon(icono);

        url = getClass().getResource("/iconos/impresora.gif");
        icono = new ImageIcon(url);
        this.bImprimir.setIcon(icono);

        url = getClass().getResource("/iconos/mail.gif");
        icono = new ImageIcon(url);
        this.bMandarMail.setIcon(icono);

        url = getClass().getResource("/iconos/notaCliente.gif");
        icono = new ImageIcon(url);
        this.bVerNotasCliente.setIcon(icono);

        url = getClass().getResource("/iconos/gafas.gif");
        icono = new ImageIcon(url);
        this.bVerEntregas.setIcon(icono);
    }

    public Long getFechaLong() {
        SimpleDateFormat formatoFecha = new SimpleDateFormat("dd/MM/yyyy");
        Long fecha = 0L;
        try {
            fecha = formatoFecha.parse(tfecha.getText()).getTime();
        } catch (ParseException ex) {
            Logger.getLogger(NuevoPresupuesto.class.getName()).log(Level.SEVERE, null, ex);
        }
        return fecha;
    }

    public Almacen getAlmacen() {
        return p.getAlmacen();
    }

    public Presupuesto getPresupuesto() {
        return this.p;
    }

    private void crearDocInt() {
        //En el caso que estemos creado un albarán con interlocutor, se tiene que crear (y estemos creando
        if (cd.getDescripcion().equals(Constantes.ALBARAN) && crear) {
            if (i != null && i.getEmpresaHija().getIid() != e.getIid()) {
                Empresa eI = BaseDatos.obtenerEmpresaPorIid(i.getEmpresaHija().getIid());
                Agentes aI = BaseDatos.obtenerAgenteByIid(i.getIidCliente().getIid());
                DatosConversion dc = new DatosConversion(i, aI, eI, p, e);
                String numeroAi = dc.crearDocumentoInterS(p);

                //Si es un albaran y tiene interlocutor, creamos el documento correspondiente
                Boolean seguir = true;
                //Siempre será Albarán (Comprobar)
                Presupuesto pre = BaseDatos.obtenerPresupuestoPorNumeroPorClaseDocumento(numeroAi, cd.getDescripcion(), e, e.getIid());
                //ClaseDocumento cd = BaseDatos.getClaseDocumentosByDescripcion(claseDocumento);
                List listaArticulo = new ArrayList();
                List listaDac = BaseDatos.getlistaDacPresupuesto(p.getIid());
                Iterator it = listaDac.iterator();
                DacPresupuesto dp;
                DacPresupuesto dpCopiado;
                VariablePresupuesto vp;
                VariablePresupuesto vpCopiada;
                SeleccionPresupuesto sp;
                SeleccionPresupuesto spCopiada;
                DespiecePresupuesto desp;
                DespiecePresupuesto despCopiado;
                LineaPresupuesto lp;
                LineaPresupuesto lpCopiada;

                while (it.hasNext() && seguir) {
                    dp = (DacPresupuesto) it.next();
                    dpCopiado = dp.copiar();
                    dpCopiado.setPresupuesto(pre);
                    seguir = BaseDatos.insertarElemento(dpCopiado);

                    List listaVariable = BaseDatos.getListaVariablePresupuestoByDacPresupuesto(dp.getIid());
                    Iterator iter2 = listaVariable.iterator();
                    while (iter2.hasNext() && seguir) {
                        vp = (VariablePresupuesto) iter2.next();
                        vpCopiada = vp.copiar();
                        vpCopiada.setDacPresupuesto(dpCopiado);
                        seguir = BaseDatos.insertarElemento(vpCopiada);

                        List listaSeleccionPresupuesto = BaseDatos.getListaSeleccionPresupuestoByVariablePresupuesto(vp.getIid());
                        Iterator iter3 = listaSeleccionPresupuesto.iterator();

                        while (iter3.hasNext() && seguir) {
                            sp = (SeleccionPresupuesto) iter3.next();
                            spCopiada = sp.copiar();
                            spCopiada.setDacPresupuesto(dpCopiado);
                            spCopiada.setVariablePresupuesto(vpCopiada);
                            seguir = BaseDatos.insertarElemento(spCopiada);
                        }
                    }

                    List listaDespiece = BaseDatos.getListaDespiecePresupuestoByDacPresupuesto(dp.getIid());
                    iter2 = listaDespiece.iterator();
                    while (iter2.hasNext() && seguir) {
                        desp = (DespiecePresupuesto) iter2.next();
                        despCopiado = desp.copiar();
                        despCopiado.setDacPresupuesto(dpCopiado);
                        seguir = BaseDatos.insertarElemento(despCopiado);
                    }
                }

                seguir = true;
                List listaLp = BaseDatos.getListaLineaPresupuesto(p.getIid());
                it = listaLp.iterator();
                NuevoPresupuesto npC = null;

                while (it.hasNext() && seguir) {
                    lp = (LineaPresupuesto) it.next();
                    lpCopiada = new LineaPresupuesto();
                    lpCopiada = lp.copiar(pre);
                    lpCopiada = dc.calcularPrecioInterlocutor(pre, lpCopiada);
                    seguir = BaseDatos.insertarElemento(lpCopiada);
                    //Comprobar DAC para calcular precio
                    if (npC == null) {
                        npC = new NuevoPresupuesto(e, pre, this.u, null);
                    }
                    if (dc.calcularDAC(pre, lpCopiada, npC)) {
                        BaseDatos.modificarElemento(lpCopiada);
                    }
                    //Actulizar lineas
                    NuevaLineaPresupuesto nlpI = new NuevaLineaPresupuesto(npC, lpCopiada.getCodigo(), e, lpCopiada, true, u);
                    listaArticulo.add(nlpI);
                }
                //Actualizamos la lista de articulos
                npC.listaArticulos.clear();
                npC.listaArticulos.addAll(listaArticulo);

                //Obligar a calcular precio
                pre.setImporte_total(npC.calcularPrecio(true));

                BaseDatos.guardarDocumento(pre, npC.fp2, npC.cod_fp2, npC.fp2_aux, npC.listaArticulos, false, cd, npC.rellenarDacMap);
            }
        }
    }

    private void mensajesInternos() {
        String asunto;
        String cuerpo;
        //Comprobamos los estados.
        //Estado preparado
        if (p.getPreparado() && !preparadoAntiguo) {
            //Enviar mensaje de estado preparado 
            asunto = "Pedido preparado";
            cuerpo = "El pedido " + p.getNumero() + " ha pasado a estar preparado";
            BaseDatos.mandarMensaje(asunto, cuerpo, e, cd, p.getIid());
        }

        if (p.getFabricado() && !fabricadoAntiguo) {
            //Enviar mensaje de estado fabricado
            asunto = "Pedido fabricado";
            cuerpo = "El pedido " + p.getNumero() + " ha pasado a estar fabricado";
            BaseDatos.mandarMensaje(asunto, cuerpo, e, cd, p.getIid());
        }

        if (p.getConfeccionado() && !confeccionadoAntiguo) {
            //Enviar mensaje de estado confeccionado   
            asunto = "Pedido confeccionado";
            cuerpo = "El pedido " + p.getNumero() + " ha pasado a estar confeccionado";
            BaseDatos.mandarMensaje(asunto, cuerpo, e, cd, p.getIid());
        }

        if (p.getInstalado() && !finalizadoAntiguo) {
            //Enviar mensaje de estado finalizado
            asunto = "Pedido finalizado";
            cuerpo = "El pedido " + p.getNumero() + " ha pasado a estar finalizado";
            BaseDatos.mandarMensaje(asunto, cuerpo, e, cd, p.getIid());
        }
    }

    protected void setFabricado(boolean fabricado) {
        this.cbFabricado.setSelected(fabricado);
    }

    protected void setConfeccionado(boolean confeccion) {
        this.cbConfeccionado.setSelected(confeccion);
    }

    public void actualizarHayNotas() {
        if (p.getNota_documento() != null && p.getNota_documento().length() > 0) {
            URL urlExclamacion = getClass().getResource("/iconos/exclamacion.PNG");
            ImageIcon iconoExclamacion = new ImageIcon(urlExclamacion);
            bHayNotas.setIcon(iconoExclamacion);
            bHayNotas.setToolTipText("Hay notas");
            bHayNotas.setVisible(true);
        } else {
            bHayNotas.setVisible(false);
        }
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bAnadirNotas;
    private javax.swing.JButton bCrearPdf;
    private javax.swing.JButton bCrearVencimiento;
    private javax.swing.JButton bGuardarCliente;
    private javax.swing.JButton bHayMontaje;
    private javax.swing.JButton bHayNotas;
    private javax.swing.JButton bImprimir;
    private javax.swing.JButton bInsertarArticuloAntes;
    private javax.swing.JButton bInsertarArticuloDespues;
    private javax.swing.JButton bInsertarArticuloFinal;
    private javax.swing.JButton bInsertarArticuloPrincipio;
    private javax.swing.JButton bInsertarNotaAntes;
    private javax.swing.JButton bInsertarNotaDespues;
    private javax.swing.JButton bInsertarNotaFinal;
    private javax.swing.JButton bInsertarNotaPrincipio;
    private javax.swing.JButton bMandarMail;
    private javax.swing.JButton bMovimientoAlmacen;
    private javax.swing.JButton bVerEntregas;
    private javax.swing.JButton bVerNotas;
    private javax.swing.JButton bVerNotasCliente;
    private javax.swing.JButton baceptar;
    private javax.swing.JButton bcancelar;
    private javax.swing.JButton bcrearplazo;
    private javax.swing.JButton beliminarplazo;
    private javax.swing.JButton beliminarvencimiento;
    private javax.swing.JButton bguardar;
    private javax.swing.JButton binsertarCliente;
    private javax.swing.JButton bmodificar;
    private javax.swing.JButton bmodificarplazo;
    private javax.swing.JButton bmodificarvencimiento;
    private javax.swing.JComboBox cAlmacen;
    private javax.swing.JComboBox cComercial;
    private javax.swing.JComboBox cContactado;
    private com.toedter.calendar.JDateChooser cFechaEntrega;
    private javax.swing.JComboBox cInterlocutor;
    private javax.swing.JComboBox cSeries;
    private javax.swing.JCheckBox cbConfeccionado;
    private javax.swing.JCheckBox cbFabricado;
    private javax.swing.JCheckBox cbInstalado;
    private javax.swing.JCheckBox cbPreparado;
    private javax.swing.JComboBox cestado;
    private javax.swing.JComboBox cformapago;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JMenuItem jMenuAlbaran;
    private javax.swing.JMenuBar jMenuBar70;
    private javax.swing.JMenuItem jMenuImpagado;
    private javax.swing.JMenuItem jMenuImprimirRecibos;
    private javax.swing.JMenuItem jMenuItemCorteLona;
    private javax.swing.JMenuItem jMenuItemCortePerfil;
    private javax.swing.JMenuItem jMenuItemDescuentoUnidades;
    private javax.swing.JMenuItem jMenuItemHojaMontaje;
    private javax.swing.JMenuItem jMenuItemLineaAntes;
    private javax.swing.JMenuItem jMenuItemLineaDespues;
    private javax.swing.JMenuItem jMenuItemLineaFinal;
    private javax.swing.JMenuItem jMenuItemLineaPrincipio;
    private javax.swing.JMenuItem jMenuItemMontaje;
    private javax.swing.JMenuItem jMenuItemNotaAntes;
    private javax.swing.JMenuItem jMenuItemNotaDespues;
    private javax.swing.JMenuItem jMenuItemNotaFinal;
    private javax.swing.JMenuItem jMenuItemNotaPrincipio;
    private javax.swing.JMenuItem jMenuItemVerCorteLona;
    private javax.swing.JMenu jMenuOpciones69;
    private javax.swing.JMenuItem jMenuPDF;
    private javax.swing.JMenuItem jMenuPagado;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane14;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JLabel lAlmacen;
    private javax.swing.JLabel lCliente;
    private javax.swing.JLabel lCpCliente;
    private javax.swing.JLabel lEmailCliente;
    private javax.swing.JLabel lFechaEntrega;
    private javax.swing.JLabel lFechaEntrega1;
    private javax.swing.JLabel lInterlocutor;
    private javax.swing.JLabel lIva;
    private javax.swing.JLabel lLocalidad;
    private javax.swing.JLabel lObservaciones;
    private javax.swing.JLabel lPais;
    private javax.swing.JLabel lPrecioTotalBruto;
    private javax.swing.JLabel lReferencia;
    private javax.swing.JLabel lSubTotal;
    private javax.swing.JLabel lTotal;
    private javax.swing.JLabel lbTercero;
    private javax.swing.JLabel lcontactado;
    private javax.swing.JLabel lconvertido;
    private javax.swing.JLabel ldni;
    private javax.swing.JLabel ldomicilio;
    private javax.swing.JLabel ldto;
    private javax.swing.JLabel lestado;
    private javax.swing.JLabel lfecha;
    private javax.swing.JLabel lfecha1;
    private javax.swing.JLabel lformapago;
    private javax.swing.JLabel lformapago1;
    private javax.swing.JLabel lformapago2;
    private javax.swing.JLabel limporte_dto;
    private javax.swing.JLabel limporte_iva;
    private javax.swing.JLabel lnombre;
    private javax.swing.JLabel lnumero;
    private javax.swing.JLabel lprecio;
    private javax.swing.JLabel lprecio_final;
    private javax.swing.JLabel ltelefono;
    private javax.swing.JLabel ltotalbruto;
    private javax.swing.JPanel panel;
    private javax.swing.JTextField tCodCliente;
    private javax.swing.JTextField tCpCliente;
    private javax.swing.JTextField tDireccionCliente;
    private javax.swing.JTextField tDniCliente;
    private javax.swing.JTextField tEmailCliente;
    private javax.swing.JTextField tIva;
    private javax.swing.JTextField tLocalidadCliente;
    private javax.swing.JTextField tNombreCliente;
    private javax.swing.JTextArea tObservaciones;
    private javax.swing.JTextField tPaisCliente;
    private javax.swing.JLabel tProvincia;
    private javax.swing.JTextField tProvinciaCliente;
    private javax.swing.JTextField tRecomendadoPor;
    private javax.swing.JTextField tReferencia;
    private javax.swing.JTextField tTelefonoCliente;
    private javax.swing.JTextField tdto;
    private javax.swing.JTextField tfecha;
    private javax.swing.JTextField tformapago;
    private javax.swing.JTextField tnumero;
    private javax.swing.JTable tplazosadelantados;
    private javax.swing.JLabel ttitulo2;
    private javax.swing.JTable tvencimientos;
    // End of variables declaration//GEN-END:variables
}
