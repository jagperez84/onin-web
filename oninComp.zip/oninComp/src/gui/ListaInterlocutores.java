package gui;

import acceso.BaseDatos;
import bean.Empresa;
import bean.Interlocutor;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JOptionPane;
import javax.swing.KeyStroke;
import modelo.Modelo;

public class ListaInterlocutores extends javax.swing.JFrame {

    private Empresa e;
    private List<Interlocutor> listaInterlocutores;

    public ListaInterlocutores(Empresa e) {
        super("Interlocutores - Mantenimiento");
        this.e = e;
        listaInterlocutores = BaseDatos.obtenerlistaInterlocutoresReducida(e.getIid());
        initComponents();
        crearIconosBotones();
        crearAcciones();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        grupo = new javax.swing.ButtonGroup();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        pnombrecomercial = new javax.swing.JPanel();
        tbusqueda = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        Modelo modelo = new Modelo();
        tInterlocutor = new javax.swing.JTable(modelo);
        rCodigo = new javax.swing.JRadioButton();
        rDescripcion = new javax.swing.JRadioButton();
        rComercial = new javax.swing.JRadioButton();
        bcerrar = new javax.swing.JButton();
        bborrar = new javax.swing.JButton();
        bcrear = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        tbusqueda.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tbusquedaKeyReleased(evt);
            }
        });

        modelo.addColumn("Código");
        modelo.addColumn("Descripción");
        modelo.addColumn("N. Fiscal");
        Iterator it;

        if(listaInterlocutores != null){
            for (it = listaInterlocutores.iterator(); it.hasNext();) {
                modelo.addRow((Object[]) it.next());
            }
        }

        tInterlocutor.getColumnModel().getColumn(0).setPreferredWidth(120);
        tInterlocutor.getColumnModel().getColumn(1).setPreferredWidth(250);
        tInterlocutor.getColumnModel().getColumn(2).setPreferredWidth(250);
        tInterlocutor.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        tInterlocutor.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                tInterlocutorKeyPressed(evt);
            }
        });
        jScrollPane1.setViewportView(tInterlocutor);

        grupo.add(rCodigo);
        rCodigo.setText("Código");
        rCodigo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rCodigoActionPerformed(evt);
            }
        });

        grupo.add(rDescripcion);
        rDescripcion.setText("Descripción");
        rDescripcion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rDescripcionActionPerformed(evt);
            }
        });

        grupo.add(rComercial);
        rComercial.setText("N.Comercial");
        rComercial.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rComercialActionPerformed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout pnombrecomercialLayout = new org.jdesktop.layout.GroupLayout(pnombrecomercial);
        pnombrecomercial.setLayout(pnombrecomercialLayout);
        pnombrecomercialLayout.setHorizontalGroup(
            pnombrecomercialLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(pnombrecomercialLayout.createSequentialGroup()
                .addContainerGap()
                .add(tbusqueda, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 411, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(rCodigo)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(rDescripcion)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(rComercial)
                .addContainerGap(org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .add(jScrollPane1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 650, Short.MAX_VALUE)
        );
        pnombrecomercialLayout.setVerticalGroup(
            pnombrecomercialLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(pnombrecomercialLayout.createSequentialGroup()
                .addContainerGap()
                .add(pnombrecomercialLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(tbusqueda, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                    .add(rDescripcion)
                    .add(rCodigo)
                    .add(rComercial))
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(jScrollPane1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 336, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Búsqueda:", pnombrecomercial);

        bcerrar.setText("Cerrar");
        bcerrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bcerrarActionPerformed(evt);
            }
        });

        bborrar.setText("Borrar");
        bborrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bborrarActionPerformed(evt);
            }
        });

        bcrear.setText("Mantenimiento");
        bcrear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bcrearActionPerformed(evt);
            }
        });

        org.jdesktop.layout.GroupLayout layout = new org.jdesktop.layout.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, layout.createSequentialGroup()
                .addContainerGap(305, Short.MAX_VALUE)
                .add(bcrear, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 128, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                .add(bborrar, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 90, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.UNRELATED)
                .add(bcerrar, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 88, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
            .add(jTabbedPane1, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 641, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(org.jdesktop.layout.GroupLayout.TRAILING, layout.createSequentialGroup()
                .add(jTabbedPane1, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 401, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .add(layout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(bcerrar)
                    .add(bborrar)
                    .add(bcrear))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void crearAcciones() {
        KeyStroke escapeKeyStroke = KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0, false);
        Action escapeAction = new AbstractAction() {
            public void actionPerformed(ActionEvent e) {
                cerrarListado();
            }
        };
        getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(escapeKeyStroke, "ESCAPE");
        getRootPane().getActionMap().put("ESCAPE", escapeAction);

        KeyStroke f1KeyStroke = KeyStroke.getKeyStroke(KeyEvent.VK_F1, 0, false);
        Action f1Action = new AbstractAction() {
            public void actionPerformed(ActionEvent ev) {
                crearInterlocutor();
            }
        };
        getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(f1KeyStroke, "F1");
        getRootPane().getActionMap().put("F1", f1Action);
    }

    private void cerrarListado() {
        removeAll();
        dispose();
    }

    private void obtenerResultado() {
        if (rCodigo.isSelected()) {
            String codigo = tbusqueda.getText().toLowerCase();
            listaInterlocutores = BaseDatos.obtenerlistaInterlocutoresPorCodigo(e.getIid(), codigo);
        } else if (rDescripcion.isSelected()) {
            String descripcion = tbusqueda.getText().toLowerCase();
            listaInterlocutores = BaseDatos.obtenerlistaInterlocutoresPorDescripcion(e.getIid(), descripcion);
        }  else if (this.rComercial.isSelected()) {
            String nombreComercial = tbusqueda.getText().toLowerCase();
            listaInterlocutores = BaseDatos.obtenerlistaInterlocutoresPorNombreComercial(e.getIid(), nombreComercial);
        } else {
            listaInterlocutores = BaseDatos.obtenerlistaInterlocutores(e.getIid());
        }
        actualizarListadoInterlocutores(listaInterlocutores);
    }
    
private void bcrearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bcrearActionPerformed
    crearInterlocutor();
}//GEN-LAST:event_bcrearActionPerformed

private void bborrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bborrarActionPerformed
    borrarInterlocutor();
}//GEN-LAST:event_bborrarActionPerformed

    private void crearInterlocutor() {
        NuevoInterlocutor ni = new NuevoInterlocutor(e);
        ni.setDefaultCloseOperation(NuevoInterlocutor.DISPOSE_ON_CLOSE);
        ni.setLocationRelativeTo(null);
        ni.setVisible(true);
        cerrarListado();
    }

    private void borrarInterlocutor() {
        try {
            int indicePanel = this.jTabbedPane1.getSelectedIndex();
            int indiceFila = -1;

            if (indicePanel == 0) {
                indiceFila = this.tInterlocutor.getSelectedRow();
            }

            if (indiceFila >= 0) {

                int eliminar = 1;
                eliminar = JOptionPane.showConfirmDialog(null, "¿Está seguro de que desea eliminar el elemento seleccionado?", "¿Eliminar?", JOptionPane.YES_NO_OPTION);
                //hacerCambios = -1 ==> se ha pulsado la "x" de cancelar;
                //hacerCambios =  0 ==> se ha pulsado el "sí"
                //hacerCambios =  1 ==> se ha pulsado el "no"

                if (eliminar == 0) {

                    //obtenemos el codigo del cliente
                    String codigoEmpresaHija = "";
                    if (indicePanel == 0) {
                        codigoEmpresaHija = (String) tInterlocutor.getModel().getValueAt(indiceFila, 0);
                    }

                    if (BaseDatos.eliminarInterlocutor(e.getIid(), codigoEmpresaHija)) {
                        obtenerResultado();
                    } else {
                        JOptionPane.showMessageDialog(null, "No se ha podido eliminar el elemento seleccionado", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
            } else {
                JOptionPane.showMessageDialog(null, "No hay seleccionado ningún elemento", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Este elemento no se puede eliminar", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

private void bcerrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bcerrarActionPerformed
    cerrarListado();
}//GEN-LAST:event_bcerrarActionPerformed

private void rDescripcionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rDescripcionActionPerformed
    obtenerResultado();
}//GEN-LAST:event_rDescripcionActionPerformed

private void rCodigoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rCodigoActionPerformed
    obtenerResultado();
}//GEN-LAST:event_rCodigoActionPerformed

private void tbusquedaKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tbusquedaKeyReleased
    obtenerResultado();
}//GEN-LAST:event_tbusquedaKeyReleased

private void tInterlocutorKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tInterlocutorKeyPressed
    if (evt.getKeyChar() == KeyEvent.VK_DELETE) {
        borrarInterlocutor();
    }
}//GEN-LAST:event_tInterlocutorKeyPressed

private void rComercialActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rComercialActionPerformed
    obtenerResultado();
}//GEN-LAST:event_rComercialActionPerformed

    private void actualizarListadoInterlocutores(List lInterlocutores) {
        Modelo modelo = (Modelo) tInterlocutor.getModel();
        int i, j;

        //obtenemos el nº de filas;
        j = modelo.getRowCount();

        //eliminamos todas las filas
        for (i = 0; i < j; i++) {
            modelo.removeRow(0);
        }

        if (lInterlocutores == null) {
            lInterlocutores = new ArrayList();
        }

        Iterator it;

        if (lInterlocutores != null) {
            for (it = lInterlocutores.iterator(); it.hasNext();) {
                 modelo.addRow((Object[]) it.next());
            }
        }
    }

    private void crearIconosBotones() {
        URL urlBorrar = getClass().getResource("/iconos/eliminar.png");
        ImageIcon iconoBorrar = new ImageIcon(urlBorrar);
        bborrar.setIcon(iconoBorrar);

        URL urlCerrar = getClass().getResource("/iconos/cancelar.gif");
        ImageIcon iconoCerrar = new ImageIcon(urlCerrar);
        bcerrar.setIcon(iconoCerrar);

        URL urlCrear = getClass().getResource("/iconos/aceptar.png");
        ImageIcon iconoCrear = new ImageIcon(urlCrear);
        bcrear.setIcon(iconoCrear);
    }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bborrar;
    private javax.swing.JButton bcerrar;
    private javax.swing.JButton bcrear;
    private javax.swing.ButtonGroup grupo;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JPanel pnombrecomercial;
    private javax.swing.JRadioButton rCodigo;
    private javax.swing.JRadioButton rComercial;
    private javax.swing.JRadioButton rDescripcion;
    private javax.swing.JTable tInterlocutor;
    private javax.swing.JTextField tbusqueda;
    // End of variables declaration//GEN-END:variables
}
