package bean;

public class MedidasFamiliaVenta {

    private Integer iid;
    private FamiliaVenta iid_fam_venta;
    private Integer medida1;
    private Integer medida2;
    private Integer medida3;
    private Integer medida4;
    private Integer medida5;
    
    public MedidasFamiliaVenta() {
        
    }
    
    public MedidasFamiliaVenta copiar(){
        MedidasFamiliaVenta res = new MedidasFamiliaVenta();
        res.setIid(iid);
        res.setIid_fam_venta(iid_fam_venta);
        res.setMedida1(medida1);
        res.setMedida2(medida2);
        res.setMedida3(medida3);
        res.setMedida4(medida4);
        res.setMedida5(medida5);
        return res;
    }

    public Integer getIid() {
        return iid;
    }

    public void setIid(Integer iid) {
        this.iid = iid;
    }

    public FamiliaVenta getIid_fam_venta() {
        return iid_fam_venta;
    }

    public void setIid_fam_venta(FamiliaVenta iid_fam_venta) {
        this.iid_fam_venta = iid_fam_venta;
    }

    public Integer getMedida1() {
        return medida1;
    }

    public void setMedida1(Integer medida1) {
        this.medida1 = medida1;
    }

    public Integer getMedida2() {
        return medida2;
    }

    public void setMedida2(Integer medida2) {
        this.medida2 = medida2;
    }

    public Integer getMedida3() {
        return medida3;
    }

    public void setMedida3(Integer medida3) {
        this.medida3 = medida3;
    }

    public Integer getMedida4() {
        return medida4;
    }

    public void setMedida4(Integer medida4) {
        this.medida4 = medida4;
    }

    public Integer getMedida5() {
        return medida5;
    }

    public void setMedida5(Integer medida5) {
        this.medida5 = medida5;
    }

}
