package bean;

import java.util.Set;

public class TipoAgente {

    private String tipo;
    private String descripcion;
    private Set agentes;

    public TipoAgente() {
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public Set getAgentes() {
        return agentes;
    }

    public void setAgentes(Set agentes) {
        this.agentes = agentes;
    }
}
