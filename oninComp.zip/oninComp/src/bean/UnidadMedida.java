package bean;

public class UnidadMedida {
    private Integer iid;
    private String cod_unidad_medida;
    private String nombre;
    private String abreviacion;
    private Magnitud magnitud;
    private String unidad_base;
    private Float factor;
    private Float equivalencia_unidad_base;
    
    public UnidadMedida(){
        
    }

    public String getAbreviacion() {
        return abreviacion;
    }

    public void setAbreviacion(String abreviacion) {
        this.abreviacion = abreviacion;
    }

    public String getCod_unidad_medida() {
        return cod_unidad_medida;
    }

    public void setCod_unidad_medida(String cod_unidad_medida) {
        this.cod_unidad_medida = cod_unidad_medida;
    }

    public Float getEquivalencia_unidad_base() {
        return equivalencia_unidad_base;
    }

    public void setEquivalencia_unidad_base(Float equivalencia_unidad_base) {
        this.equivalencia_unidad_base = equivalencia_unidad_base;
    }

    public Float getFactor() {
        return factor;
    }

    public void setFactor(Float factor) {
        this.factor = factor;
    }

    public Integer getIid() {
        return iid;
    }

    public void setIid(Integer iid) {
        this.iid = iid;
    }

    public Magnitud getMagnitud() {
        return magnitud;
    }

    public void setMagnitud(Magnitud magnitud) {
        this.magnitud = magnitud;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getUnidad_base() {
        return unidad_base;
    }

    public void setUnidad_base(String unidad_base) {
        this.unidad_base = unidad_base;
    }
}
