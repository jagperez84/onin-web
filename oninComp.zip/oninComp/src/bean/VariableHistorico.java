package bean;

import acceso.BaseDatos;

public class VariableHistorico {
    private Integer iid;
    private String nombre;
    private String tipo;
    private Double valor;
    private String condicion;
    private Boolean activarPeticion;
    private Double valorMinimo;
    private Double valorMaximo;
    private Boolean activarMinimo;
    private Boolean activarMaximo;
    private String formula;
    private Boolean editarResultadoFormula;
    private TipoToldo tipoToldo;
    private Dac dac;
    private DacHistorico dacHistorico;
    
    public VariableHistorico(){
    }

    public VariableHistorico(VariablePresupuesto vp) {
        this.activarMaximo = vp.getActivarMaximo();
        this.activarMinimo = vp.getActivarMinimo();
        this.activarPeticion = vp.getActivarPeticion();
        this.condicion = vp.getCondicion();
        this.dac = vp.getDac();
        this.editarResultadoFormula = vp.getEditarResultadoFormula();
        this.formula = vp.getFormula();
        this.nombre = vp.getNombre();
        this.tipo = vp.getTipo();
        this.tipoToldo = vp.getTipoToldo();
        this.valor = vp.getValor();
        this.valorMaximo = vp.getValorMaximo();
        this.valorMinimo = vp.getValorMinimo();
    }

    public VariableHistorico copiar() {
        VariableHistorico res = new VariableHistorico();
        res.setActivarMaximo(activarMaximo);
        res.setActivarMinimo(activarMinimo);
        res.setActivarPeticion(activarPeticion);
        res.setCondicion(condicion);
        res.setDac(dac);
        res.setDacHistorico(dacHistorico);
        res.setEditarResultadoFormula(editarResultadoFormula);
        res.setFormula(formula);
        res.setNombre(nombre);
        res.setTipo(tipo);
        res.setTipoToldo(tipoToldo);
        res.setValor(valor);
        res.setValorMaximo(valorMaximo);
        res.setValorMinimo(valorMinimo);
        return res;
    }

    public Boolean getActivarMaximo() {
        return activarMaximo;
    }

    public void setActivarMaximo(Boolean activarMaximo) {
        this.activarMaximo = activarMaximo;
    }

    public Boolean getActivarMinimo() {
        return activarMinimo;
    }

    public void setActivarMinimo(Boolean activarMinimo) {
        this.activarMinimo = activarMinimo;
    }

    public Boolean getActivarPeticion() {
        return activarPeticion;
    }

    public void setActivarPeticion(Boolean activarPeticion) {
        this.activarPeticion = activarPeticion;
    }

    public String getCondicion() {
        return condicion;
    }

    public void setCondicion(String condicion) {
        this.condicion = condicion;
    }

    public Boolean getEditarResultadoFormula() {
        return editarResultadoFormula;
    }

    public void setEditarResultadoFormula(Boolean editarResultadoFormula) {
        this.editarResultadoFormula = editarResultadoFormula;
    }

    public String getFormula() {
        return formula;
    }

    public void setFormula(String formula) {
        this.formula = formula;
    }

    public Integer getIid() {
        return iid;
    }

    public void setIid(Integer iid) {
        this.iid = iid;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public TipoToldo getTipoToldo() {
        return tipoToldo;
    }

    public void setTipoToldo(TipoToldo tipoToldo) {
        this.tipoToldo = tipoToldo;
    }

    public Double getValor() {
        return valor;
    }

    public void setValor(Double valor) {
        this.valor = valor;
    }

    public Double getValorMinimo() {
        return valorMinimo;
    }

    public void setValorMinimo(Double valorMinimo) {
        this.valorMinimo = valorMinimo;
    }

    public Double getValorMaximo() {
        return valorMaximo;
    }

    public void setValorMaximo(Double valorMaximo) {
        this.valorMaximo = valorMaximo;
    }

    public Dac getDac() {
        return dac;
    }

    public void setDac(Dac dac) {
        this.dac = dac;
    }
    
    public boolean equals(Object o){
        boolean res = false;
        Variable v = (Variable)o;
        return nombre.equalsIgnoreCase(v.getNombre());
    }
    
    public Variable clonar(){
        Variable res = new Variable();
        res.setActivarMaximo(activarMaximo);
        res.setActivarMinimo(activarMinimo);
        res.setActivarPeticion(activarPeticion);
        res.setCondicion(condicion);
        res.setDac(BaseDatos.obtenerDacById(this.dac.getIid()));
        res.setEditarResultadoFormula(editarResultadoFormula);
        res.setFormula(formula);
        res.setNombre(nombre);
        res.setTipo(tipo);
        res.setTipoToldo(tipoToldo);
        res.setValor(valor);
        res.setValorMaximo(valorMaximo);
        res.setValorMinimo(valorMinimo);
        return res;
    }

    public DacHistorico getDacHistorico() {
        return dacHistorico;
    }

    public void setDacHistorico(DacHistorico dacHistorico) {
        this.dacHistorico = dacHistorico;
    }
}
