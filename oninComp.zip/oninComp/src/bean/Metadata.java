package bean;

public class Metadata {
    private Integer codigo;
    private String nombre;
    private String valor;
    private Empresa iid_empresa;

    public Metadata() {
    }
    
    public Metadata (String nombre, String valor, Empresa empresa) {
        this.nombre = nombre;
        this.valor = valor;
        this.iid_empresa = empresa;
    }

    public Integer getCodigo() {
        return codigo;
    }

    public void setCodigo(Integer codigo) {
        this.codigo = codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getValor() {
        return valor;
    }

    public void setValor(String valor) {
        this.valor = valor;
    }

   public Empresa getIid_empresa() {
        return iid_empresa;
    }

    public void setIid_empresa(Empresa iid_empresa) {
        this.iid_empresa = iid_empresa;
    }

}
