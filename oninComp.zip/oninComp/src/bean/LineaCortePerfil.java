package bean;

public class LineaCortePerfil {
    private Integer iid;
    private Presupuesto presupuesto;
    private Articulo articulo;
    private Caracteristica caracteristica;
    private Integer codigoLinea;
    private Double cantidad;
    private Double longitud;
    private Double longitudSeleccionada;
    private Boolean esDespiece;
    private LineaPresupuesto lineaPresupuesto;
    private DespiecePresupuesto despiece;

    public LineaCortePerfil() {
    }

    public Double getCantidad() {
        return cantidad;
    }

    public void setCantidad(Double cantidad) {
        this.cantidad = cantidad;
    }

    public Integer getCodigoLinea() {
        return codigoLinea;
    }

    public void setCodigoLinea(Integer codigoLinea) {
        this.codigoLinea = codigoLinea;
    }

    public Integer getIid() {
        return iid;
    }

    public void setIid(Integer iid) {
        this.iid = iid;
    }

    public DespiecePresupuesto getDespiece() {
        return despiece;
    }

    public void setDespiece(DespiecePresupuesto despiece) {
        this.despiece = despiece;
    }

    public Boolean getEsDespiece() {
        return esDespiece;
    }

    public void setEsDespiece(Boolean esDespiece) {
        this.esDespiece = esDespiece;
    }

    public LineaPresupuesto getLineaPresupuesto() {
        return lineaPresupuesto;
    }

    public void setLineaPresupuesto(LineaPresupuesto lineaPresupuesto) {
        this.lineaPresupuesto = lineaPresupuesto;
    }

    public Articulo getArticulo() {
        return articulo;
    }

    public void setArticulo(Articulo articulo) {
        this.articulo = articulo;
    }

    public Caracteristica getCaracteristica() {
        return caracteristica;
    }

    public void setCaracteristica(Caracteristica caracteristica) {
        this.caracteristica = caracteristica;
    }

    public Presupuesto getPresupuesto() {
        return presupuesto;
    }

    public void setPresupuesto(Presupuesto presupuesto) {
        this.presupuesto = presupuesto;
    }

    public Double getLongitud() {
        return longitud;
    }

    public void setLongitud(Double longitud) {
        this.longitud = longitud;
    }

    public Double getLongitudSeleccionada() {
        return longitudSeleccionada;
    }

    public void setLongitudSeleccionada(Double longitudSeleccionada) {
        this.longitudSeleccionada = longitudSeleccionada;
    }
    
}
