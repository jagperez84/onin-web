package bean;

import acceso.BaseDatos;

public class Despiece implements Comparable{
    private Integer iid;
    private Dac dac;
    private Articulo articulo;
    private String tipoArticulo;
    private String formulaCantidad, formulaMedida1, formulaMedida2, formulaMedida3, formulaMedida4, formulaMedida5;
    private Colores color;
    private Integer orden;
    private Integer ordenInicial;
    private Integer iidInicial;
    private String redondeo;
    private Boolean articuloBase;
    private Boolean anadirPvp;
    private Boolean anadirIncremento;
    private Caracteristica caracteristica;
    private Float precio;
    private Float coste;
    private String manual;
    private FamiliaVenta fv;
    private TipoControl tc;
    private TipoMedida tm;
    private int numeroDimensiones;
    
    public Despiece (Despiece d){
        this.iid = d.getIid();
        this.dac = d.getDac();
        this.articulo = d.getArticulo();
        this.tipoArticulo = d.getTipoArticulo();
        this.formulaCantidad = d.getFormulaCantidad();
        this.formulaMedida1 = d.getFormulaMedida1();
        this.formulaMedida2 = d.getFormulaMedida2();
        this.formulaMedida3 = d.getFormulaMedida3();
        this.formulaMedida4 = d.getFormulaMedida4();
        this.formulaMedida5 = d.getFormulaMedida5();
        this.anadirIncremento = d.getAnadirIncremento();
        this.anadirPvp = d.getAnadirPvp();
        this.articuloBase = d.getArticuloBase();
        this.color = d.getColor();
        this.orden = d.getOrden();
        this.redondeo = d.getRedondeo();
        this.caracteristica = d.getCaracteristica();
        this.ordenInicial = d.getOrdenInicial();
        this.iidInicial = d.getIidInicial();
        if (d.getPrecio()!= null) this.precio = d.getPrecio();
        this.caracteristica = d.getCaracteristica();
        this.manual = d.getManual();
        this.numeroDimensiones = -1;
        this.fv = null;
        this.tc = null;
        this.tm = null;
    }


    @Override
    public String toString(){
        String res = "";
        res += "[" + articulo.getCod_articulo() + " - " + tipoArticulo + "]";
        return res;
    }
    
    public Despiece (){
        numeroDimensiones = -1;
    }
    
    public Articulo getArticulo() {
        if (articulo == null) {
            articulo = BaseDatos.obtenerArticuloPorIid(articulo.getIid());
        }
        
        return articulo;
    }

    public void setArticulo(Articulo articulo) {
        this.articulo = articulo;
    }

    public Dac getDac() {
        return dac;
    }

    public void setDac(Dac dac) {
        this.dac = dac;
    }

    public Caracteristica getCaracteristica() {
        return caracteristica;
    }
    
    public void setCaracteristica(Caracteristica caracteristica) {
        this.caracteristica = caracteristica;
    }

    public String getFormulaCantidad() {
        return formulaCantidad;
    }

    public void setFormulaCantidad(String formulaCantidad) {
        this.formulaCantidad = formulaCantidad;
    }

    public String getFormulaMedida1() {
        return formulaMedida1;
    }

    public void setFormulaMedida1(String formulaMedida1) {
        this.formulaMedida1 = formulaMedida1;
    }

    public String getFormulaMedida2() {
        return formulaMedida2;
    }

    public void setFormulaMedida2(String formulaMedida2) {
        this.formulaMedida2 = formulaMedida2;
    }

    public String getFormulaMedida3() {
        return formulaMedida3;
    }

    public void setFormulaMedida3(String formulaMedida3) {
        this.formulaMedida3 = formulaMedida3;
    }

    public String getFormulaMedida4() {
        return formulaMedida4;
    }

    public void setFormulaMedida4(String formulaMedida4) {
        this.formulaMedida4 = formulaMedida4;
    }

    public String getFormulaMedida5() {
        return formulaMedida5;
    }

    public void setFormulaMedida5(String formulaMedida5) {
        this.formulaMedida5 = formulaMedida5;
    }

    public Integer getIid() {
        return iid;
    }

    public void setIid(Integer iid) {
        this.iid = iid;
    }

    public String getTipoArticulo() {
        return tipoArticulo;
    }

    public void setTipoArticulo(String tipoArticulo) {
        this.tipoArticulo = tipoArticulo;
    }
    
    public Colores getColor() {
        return color;
    }

    public void setColor(Colores color) {
        this.color = color;
    }

    public Integer getOrden() {
        return orden;
    }

    public void setOrden(Integer orden) {
        this.orden = orden;
    }
    
    public Boolean getAnadirIncremento() {
        return anadirIncremento;
    }

    public void setAnadirIncremento(Boolean anadirIncremento) {
        this.anadirIncremento = anadirIncremento;
    }

    public Boolean getAnadirPvp() {
        return anadirPvp;
    }

    public void setAnadirPvp(Boolean anadirPvp) {
        this.anadirPvp = anadirPvp;
    }

    public Boolean getArticuloBase() {
        return articuloBase;
    }

    public void setArticuloBase(Boolean articuloBase) {
        this.articuloBase = articuloBase;
    }

    public Integer getOrdenInicial() {
        return ordenInicial;
    }

    public void setOrdenInicial(Integer ordenInicial) {
        this.ordenInicial = ordenInicial;
    }

    public Integer getIidInicial() {
        return iidInicial;
    }

    public void setIidInicial(Integer iidInicial) {
        this.iidInicial = iidInicial;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Despiece other = (Despiece) obj;
        if (!this.tipoArticulo.equals(other.tipoArticulo) && (this.tipoArticulo == null || !this.tipoArticulo.equals(other.tipoArticulo))) {
            return false;
        }
        return true;
    }

    public String getRedondeo() {
        return redondeo;
    }

    public void setRedondeo(String redondeo) {
        this.redondeo = redondeo;
    }
    
    public FamiliaVenta getFamiliaVenta() {
        if (fv == null) {
            fv = BaseDatos.obtenerFamiliaVentaPorIid(articulo.getIid_fam_venta().getIid());
        }
        return fv;
    }
    
    public TipoControl getTipoControl() {
        if ( tc == null) {
            tc = BaseDatos.obtenerTipoControlPorIid(fv.getIid_tipo_control().getIid());
        }
        return tc;
    }
    
    public TipoMedida getTipoMedida() {
        if (tm == null) {
            tm = BaseDatos.obtenerTipoMedidaByIid(tc.getIid_tipo_medida().getIid());
            numeroDimensiones = tm.getNum_dimensiones();
        }
        return tm;
    }
    
    public int getNumeroDimensiones() {
        if(numeroDimensiones != -1) {
            return numeroDimensiones;
        }

        numeroDimensiones = 5;
        if (tm == null) {
            
            articulo = BaseDatos.obtenerArticuloPorIid(articulo.getIid());
            
            if (fv == null) {
                fv = BaseDatos.obtenerFamiliaVentaPorIid(articulo.getIid_fam_venta().getIid());
            }
            
            if (tc == null) {
                tc = BaseDatos.obtenerTipoControlPorIid(fv.getIid_tipo_control().getIid());
            }

            tm = BaseDatos.obtenerTipoMedidaByIid(tc.getIid_tipo_medida().getIid());
            numeroDimensiones = tm.getNum_dimensiones();
        }
        
        return numeroDimensiones;
    }


    public int compareTo(Object o) {
        Despiece d = (Despiece) o;
        return this.articulo.compareTo(d.getArticulo());
    }

    public Float getPrecio() {
        return precio;
    }

    public void setPrecio(Float precio) {
        this.precio = precio;
    }

    public Float getCoste() {
        return coste;
    }

    public void setCoste(Float coste) {
        this.coste = coste;
    }

    public String getManual() {
        return manual;
    }

    public void setManual(String manual) {
        this.manual = manual;
    }
}
