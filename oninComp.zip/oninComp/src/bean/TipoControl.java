package bean;

public class TipoControl {
    
    private Integer iid;
    private String codigo;
    private String nombre;
    private TipoMedida iid_tipo_medida;
    private UnidadMedida unidad1;
    private UnidadMedida unidad2;
    private UnidadMedida unidad3;
    private UnidadMedida unidad4;
    private UnidadMedida unidad5;
    private Integer ndec1;
    private Integer ndec2;
    private Integer ndec3;
    private Integer ndec4;
    private Integer ndec5;
    private UnidadMedida unidadResultado;
    private Integer ndecResultado;
    private String tipoRedondeo;
    
    public TipoControl(){
        
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public Integer getIid() {
        return iid;
    }

    public void setIid(Integer iid) {
        this.iid = iid;
    }

    public TipoMedida getIid_tipo_medida() {
        return iid_tipo_medida;
    }

    public void setIid_tipo_medida(TipoMedida iid_tipo_medida) {
        this.iid_tipo_medida = iid_tipo_medida;
    }

    public Integer getNdec1() {
        return ndec1;
    }

    public void setNdec1(Integer ndec1) {
        this.ndec1 = ndec1;
    }

    public Integer getNdec2() {
        return ndec2;
    }

    public void setNdec2(Integer ndec2) {
        this.ndec2 = ndec2;
    }

    public Integer getNdec3() {
        return ndec3;
    }

    public void setNdec3(Integer ndec3) {
        this.ndec3 = ndec3;
    }

    public Integer getNdec4() {
        return ndec4;
    }

    public void setNdec4(Integer ndec4) {
        this.ndec4 = ndec4;
    }

    public Integer getNdec5() {
        return ndec5;
    }

    public void setNdec5(Integer ndec5) {
        this.ndec5 = ndec5;
    }

    public Integer getNdecResultado() {
        return ndecResultado;
    }

    public void setNdecResultado(Integer ndecResultado) {
        this.ndecResultado = ndecResultado;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTipoRedondeo() {
        return tipoRedondeo;
    }

    public void setTipoRedondeo(String tipoRedondeo) {
        this.tipoRedondeo = tipoRedondeo;
    }

    public UnidadMedida getUnidad1() {
        return unidad1;
    }

    public void setUnidad1(UnidadMedida unidad1) {
        this.unidad1 = unidad1;
    }

    public UnidadMedida getUnidad2() {
        return unidad2;
    }

    public void setUnidad2(UnidadMedida unidad2) {
        this.unidad2 = unidad2;
    }

    public UnidadMedida getUnidad3() {
        return unidad3;
    }

    public void setUnidad3(UnidadMedida unidad3) {
        this.unidad3 = unidad3;
    }

    public UnidadMedida getUnidad4() {
        return unidad4;
    }

    public void setUnidad4(UnidadMedida unidad4) {
        this.unidad4 = unidad4;
    }

    public UnidadMedida getUnidad5() {
        return unidad5;
    }

    public void setUnidad5(UnidadMedida unidad5) {
        this.unidad5 = unidad5;
    }

    public UnidadMedida getUnidadResultado() {
        return unidadResultado;
    }

    public void setUnidadResultado(UnidadMedida unidadResultado) {
        this.unidadResultado = unidadResultado;
    }

}
