package bean;

public class Caracteristica {
    
    private Integer iid;
    private Articulo iid_articulo;
    private Empresa iid_empresa;
    private Integer cantidad_stock_minimo;
    private Colores iid_color;
    private Boolean stock_min;
    private Boolean Stock_max;
    private Float upc;
    private Float ptc;
    private Boolean cond_pedir;
    private Boolean escalado;
    private Float pvp;
    private Float precioIncremento;

    public Caracteristica(){
        
    }

    public Boolean getStock_max() {
        return Stock_max;
    }

    public void setStock_max(Boolean Stock_max) {
        this.Stock_max = Stock_max;
    }

    public Boolean getCond_pedir() {
        return cond_pedir;
    }

    public void setCond_pedir(Boolean cond_pedir) {
        this.cond_pedir = cond_pedir;
    }

    public Integer getIid() {
        return iid;
    }

    public void setIid(Integer iid) {
        this.iid = iid;
    }

    public Articulo getIid_articulo() {
        return iid_articulo;
    }

    public void setIid_articulo(Articulo iid_articulo) {
        this.iid_articulo = iid_articulo;
    }

    public Colores getIid_color() {
        return iid_color;
    }

    public void setIid_color(Colores iid_color) {
        this.iid_color = iid_color;
    }

    public Float getPtc() {
        return ptc;
    }

    public void setPtc(Float ptc) {
        this.ptc = ptc;
    }

    public Boolean getStock_min() {
        return stock_min;
    }

    public void setStock_min(Boolean stock_min) {
        this.stock_min = stock_min;
    }

    public Float getUpc() {
        return upc;
    }

    public void setUpc(Float upc) {
        this.upc = upc;
    }
    
    public Empresa getIid_empresa() {
        return iid_empresa;
    }

    public void setIid_empresa(Empresa iid_empresa) {
        this.iid_empresa = iid_empresa;
    }

    public Integer getCantidad_stock_minimo() {
        return cantidad_stock_minimo;
    }

    public void setCantidad_stock_minimo(Integer cantidad_stock_minimo) {
        this.cantidad_stock_minimo = cantidad_stock_minimo;
    }
    
    public Boolean getEscalado() {
        return escalado;
    }

    public void setEscalado(Boolean escalado) {
        this.escalado = escalado;
    }

    public Float getPvp() {
        return pvp;
    }

    public void setPvp(Float pvp) {
        this.pvp = pvp;
    }

    public Float getPrecioIncremento() {
        return precioIncremento;
    }

    public void setPrecioIncremento(Float precioIncremento) {
        this.precioIncremento = precioIncremento;
    }

    @Override
    public boolean equals (Object o){
        Caracteristica c = (Caracteristica) o;
        return this.getIid_color().equals(c.getIid_color());
    }
    
    public Caracteristica clonar(){
        Caracteristica res = new Caracteristica();
        res.setCantidad_stock_minimo(cantidad_stock_minimo);
        res.setCond_pedir(cond_pedir);
        res.setEscalado(escalado);
        res.setIid(iid);
        res.setIid_articulo(iid_articulo);
        res.setIid_color(iid_color);
        res.setIid_empresa(iid_empresa);
        res.setPtc(ptc);
        res.setStock_max(Stock_max);
        res.setStock_min(stock_min);
        res.setUpc(upc);
        res.setPvp(pvp);
        res.setPrecioIncremento(precioIncremento);
        return res;
    }
    
}
