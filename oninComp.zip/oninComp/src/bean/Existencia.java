package bean;

public class Existencia implements Comparable {

    private Integer iid;
    private Articulo articulo;
    private Caracteristica caracteristica;
    private Almacen almacen;
    private Float cantidad1;
    private Float cantidad2;
    private Float cantidad3;
    private Float cantidad4;
    private Float cantidad5;
    private Empresa empresa;
    private Float existencia;
    private Boolean esResto;
    private Boolean estaUsado;
    private UnidadMedida unidadMedida1;
    private UnidadMedida unidadMedidaTotal;
    private Integer unidadMedida2;
    private Integer unidadMedida3;
    private Integer unidadMedida4;
    private Integer unidadMedida5;
    

    public Existencia() {
    }

    public Almacen getAlmacen() {
        return almacen;
    }

    public void setAlmacen(Almacen almacen) {
        this.almacen = almacen;
    }

    public Articulo getArticulo() {
        return articulo;
    }

    public void setArticulo(Articulo articulo) {
        this.articulo = articulo;
    }

    public Float getCantidad1() {
        return cantidad1;
    }

    public void setCantidad1(Float cantidad1) {
        this.cantidad1 = cantidad1;
    }

    public Float getCantidad2() {
        return cantidad2;
    }

    public void setCantidad2(Float cantidad2) {
        this.cantidad2 = cantidad2;
    }

    public Float getCantidad3() {
        return cantidad3;
    }

    public void setCantidad3(Float cantidad3) {
        this.cantidad3 = cantidad3;
    }

    public Float getCantidad4() {
        return cantidad4;
    }

    public void setCantidad4(Float cantidad4) {
        this.cantidad4 = cantidad4;
    }

    public Float getCantidad5() {
        return cantidad5;
    }

    public void setCantidad5(Float cantidad5) {
        this.cantidad5 = cantidad5;
    }

    public Caracteristica getCaracteristica() {
        return caracteristica;
    }

    public void setCaracteristica(Caracteristica caracteristica) {
        this.caracteristica = caracteristica;
    }

    public Empresa getEmpresa() {
        return empresa;
    }

    public void setEmpresa(Empresa empresa) {
        this.empresa = empresa;
    }

    public Float getExistencia() {
        return existencia;
    }

    public void setExistencia(Float existencia) {
        this.existencia = existencia;
    }

    public Integer getIid() {
        return iid;
    }

    public void setIid(Integer iid) {
        this.iid = iid;
    }

    public boolean equalsMovimiento(MovimientoAlmacen m) {
        boolean res = false;
        int numMedidas = m.getArticulo().getIid_fam_venta().getIid_tipo_control().getIid_tipo_medida().getNum_dimensiones();

        res = this.almacen.getIid().equals(m.getAlmacen().getIid());

        if (m.getCaracteristica() != null) {
            res = res && this.caracteristica.equals(m.getCaracteristica());
        }

        if (numMedidas == 1) {
            res = res && this.getCantidad1().equals(m.getCantidad1());
        } else if (numMedidas == 2) {
            res = res && this.getCantidad1().equals(m.getCantidad1())
                    && this.getCantidad2().equals(m.getCantidad2());
        } else if (numMedidas == 3) {
            res = res && this.getCantidad1().equals(m.getCantidad1())
                    && this.getCantidad2().equals(m.getCantidad2())
                    && this.getCantidad3().equals(m.getCantidad3());
        } else if (numMedidas == 4) {
            res = res && this.getCantidad1().equals(m.getCantidad1())
                    && this.getCantidad2().equals(m.getCantidad2())
                    && this.getCantidad3().equals(m.getCantidad3())
                    && this.getCantidad4().equals(m.getCantidad4());
        } else if (numMedidas == 5) {
            res = res && this.getCantidad1().equals(m.getCantidad1())
                    && this.getCantidad2().equals(m.getCantidad2())
                    && this.getCantidad3().equals(m.getCantidad3())
                    && this.getCantidad4().equals(m.getCantidad4())
                    && this.getCantidad5().equals(m.getCantidad5());
        }

        return res;
    }

    public Boolean getEsResto() {
        return esResto;
    }

    public void setEsResto(Boolean esResto) {
        this.esResto = esResto;
    }

    public Boolean getEstaUsado() {
        return estaUsado;
    }

    public void setEstaUsado(Boolean estaUsado) {
        this.estaUsado = estaUsado;
    }

    public int compareTo(Object o) {
        Existencia otraExistencia = (Existencia) o;
        return cantidad1.compareTo(otraExistencia.getCantidad1());
    }

    public Existencia clonar() {
        Existencia res = new Existencia();

        res.setAlmacen(getAlmacen());
        res.setArticulo(getArticulo());
        res.setCantidad1(getCantidad1());
        res.setCantidad2(getCantidad2());
        res.setCantidad3(getCantidad3());
        res.setCantidad4(getCantidad4());
        res.setCantidad5(getCantidad5());
        res.setCaracteristica(getCaracteristica());
        res.setEmpresa(getEmpresa());
        res.setEsResto(getEsResto());
        res.setExistencia(getExistencia());
        res.setEstaUsado(getEstaUsado());
        res.setUnidadMedida1(getUnidadMedida1());
        res.setUnidadMedida2(getUnidadMedida2());
        res.setUnidadMedida3(getUnidadMedida3());
        res.setUnidadMedida4(getUnidadMedida4());
        res.setUnidadMedida5(getUnidadMedida5());
        res.setUnidadMedidaTotal(getUnidadMedidaTotal());
        return res;
    }

    public UnidadMedida getUnidadMedida1() {
        return unidadMedida1;
    }

    public void setUnidadMedida1(UnidadMedida unidadMedida1) {
        this.unidadMedida1 = unidadMedida1;
    }

    public UnidadMedida getUnidadMedidaTotal() {
        return unidadMedidaTotal;
    }

    public void setUnidadMedidaTotal(UnidadMedida unidadMedidaTotal) {
        this.unidadMedidaTotal = unidadMedidaTotal;
    }

    public Integer getUnidadMedida2() {
        return unidadMedida2;
    }

    public void setUnidadMedida2(Integer unidadMedida2) {
        this.unidadMedida2 = unidadMedida2;
    }

    public Integer getUnidadMedida3() {
        return unidadMedida3;
    }

    public void setUnidadMedida3(Integer unidadMedida3) {
        this.unidadMedida3 = unidadMedida3;
    }

    public Integer getUnidadMedida4() {
        return unidadMedida4;
    }

    public void setUnidadMedida4(Integer unidadMedida4) {
        this.unidadMedida4 = unidadMedida4;
    }

    public Integer getUnidadMedida5() {
        return unidadMedida5;
    }

    public void setUnidadMedida5(Integer unidadMedida5) {
        this.unidadMedida5 = unidadMedida5;
    }



}
