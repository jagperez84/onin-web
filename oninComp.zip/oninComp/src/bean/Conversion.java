package bean;

public class Conversion {
    private Integer iid;
    private Integer iidOrigen;
    private Integer iidDestino;
    private Integer flujo;
    
    public Conversion() {
    }


    public Integer getIid() {
        return iid;
    }

    public void setIid(Integer iid) {
        this.iid = iid;
    }

    public Integer getIidOrigen() {
        return iidOrigen;
    }

    public void setIidOrigen(Integer iidOrigen) {
        this.iidOrigen = iidOrigen;
    }

    public void setIidDestino(Integer iidDestino) {
        this.iidDestino = iidDestino;
    }

    public Integer getIidDestino() {
        return iidDestino;
    }

    public Integer getFlujo() {
        return flujo;
    }

    public void setFlujo(Integer flujo) {
        this.flujo = flujo;
    }
    
  
}
