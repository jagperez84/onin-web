package bean;

import acceso.BaseDatos;

public class SeleccionPresupuesto {
    private Integer iid;
    private String nombre;
    private Double valor;
    private String condicion;
    private VariablePresupuesto variablePresupuesto;
    private Boolean seleccionada;
    private DacPresupuesto dacPresupuesto;
    
    public SeleccionPresupuesto() {
    
    }

    public SeleccionPresupuesto(Integer iid, String nombre, Double valor, String condicion, VariablePresupuesto variablePresupuesto, Boolean seleccionada) {
        this.iid = iid;
        this.nombre = nombre;
        this.valor = valor;
        this.condicion = condicion;
        this.variablePresupuesto = variablePresupuesto;
        this.seleccionada = seleccionada;
    }

    public SeleccionPresupuesto copiar() {
        SeleccionPresupuesto res = new SeleccionPresupuesto();
        res.setCondicion(condicion);
        res.setDacPresupuesto(dacPresupuesto);
        res.setNombre(nombre);
        res.setSeleccionada(seleccionada);
        res.setValor(valor);
        res.setVariablePresupuesto(variablePresupuesto);
        return res;
    }

    public String getCondicion() {
        return condicion;
    }

    public void setCondicion(String condicion) {
        this.condicion = condicion;
    }

    public Integer getIid() {
        return iid;
    }

    public void setIid(Integer iid) {
        this.iid = iid;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Double getValor() {
        return valor;
    }

    public void setValor(Double valor) {
        this.valor = valor;
    }

    public VariablePresupuesto getVariablePresupuesto() {
        return variablePresupuesto;
    }

    public void setVariablePresupuesto(VariablePresupuesto variablePresupuesto) {
        this.variablePresupuesto = variablePresupuesto;
    }

    public Boolean getSeleccionada() {
        return seleccionada;
    }

    public void setSeleccionada(Boolean seleccionada) {
        this.seleccionada = seleccionada;
    }

    public DacPresupuesto getDacPresupuesto() {
        return dacPresupuesto;
    }

    public void setDacPresupuesto(DacPresupuesto dacPresupuesto) {
        this.dacPresupuesto = dacPresupuesto;
    }
    
    public Seleccion clonar(){
        Seleccion sel = new Seleccion();
        sel.setCondicion(condicion);
        sel.setNombre(nombre);
        sel.setSeleccionada(seleccionada);
        sel.setValor(valor);
        
        VariablePresupuesto vp = BaseDatos.obtenerVariablePresupuestoById(variablePresupuesto.getIid());
        Dac dac = (Dac) BaseDatos.obtenerElemento(Dac.class, vp.getDac().getIid());
        Variable variable = BaseDatos.ObtenerVariableByDacByNombre(dac.getIid(), vp.getNombre());
        sel.setVariable(variable);
        return sel;
    }

}
