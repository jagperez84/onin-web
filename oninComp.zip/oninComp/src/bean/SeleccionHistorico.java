package bean;

import acceso.BaseDatos;

public class SeleccionHistorico {
    private Integer iid;
    private String nombre;
    private Double valor;
    private String condicion;
    private VariableHistorico variableHistorico;
    private Boolean seleccionada;
    private DacHistorico dacHistorico;
    
    public SeleccionHistorico() {
    
    }
    
    public SeleccionHistorico(SeleccionPresupuesto sp){
        this.condicion = sp.getCondicion();
        this.nombre = sp.getNombre();
        this.seleccionada = sp.getSeleccionada();
        this.valor = sp.getValor();
    }

    public SeleccionHistorico(Integer iid, String nombre, Double valor, String condicion, VariableHistorico variableHistorico, Boolean seleccionada) {
        this.iid = iid;
        this.nombre = nombre;
        this.valor = valor;
        this.condicion = condicion;
        this.variableHistorico = variableHistorico;
        this.seleccionada = seleccionada;
    }

    public SeleccionHistorico copiar() {
        SeleccionHistorico res = new SeleccionHistorico();
        res.setCondicion(condicion);
        res.setDacHistorico(dacHistorico);
        res.setNombre(nombre);
        res.setSeleccionada(seleccionada);
        res.setValor(valor);
        res.setVariableHistorico(variableHistorico);
        return res;
    }

    public String getCondicion() {
        return condicion;
    }

    public void setCondicion(String condicion) {
        this.condicion = condicion;
    }

    public Integer getIid() {
        return iid;
    }

    public void setIid(Integer iid) {
        this.iid = iid;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Double getValor() {
        return valor;
    }

    public void setValor(Double valor) {
        this.valor = valor;
    }

    public VariableHistorico getVariableHistorico() {
        return variableHistorico;
    }

    public void setVariableHistorico(VariableHistorico variableHistorico) {
        this.variableHistorico = variableHistorico;
    }

    public Boolean getSeleccionada() {
        return seleccionada;
    }

    public void setSeleccionada(Boolean seleccionada) {
        this.seleccionada = seleccionada;
    }

    public DacHistorico getDacHistorico() {
        return dacHistorico;
    }

    public void setDacHistorico(DacHistorico dacHistorico) {
        this.dacHistorico = dacHistorico;
    }
    
    public Seleccion clonar(){
        Seleccion sel = new Seleccion();
        sel.setCondicion(condicion);
        sel.setNombre(nombre);
        sel.setSeleccionada(seleccionada);
        sel.setValor(valor);
        VariableHistorico vp = BaseDatos.obtenerVariableHistoricoById(variableHistorico.getIid());
        Dac dac = (Dac) BaseDatos.obtenerElemento(Dac.class, vp.getDac().getIid());
        Variable variable = BaseDatos.ObtenerVariableByDacByNombre(dac.getIid(), vp.getNombre());
        sel.setVariable(variable);
        return sel;
    }

}
