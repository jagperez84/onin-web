package bean;

public class precioFamilia {
    private Integer iid;
    private Integer iidEmpresa;
    private Integer iidFamilia;
    private String tipoRal;
    private Float pvp;
    private Float ptc;
    private Float upc;

    public Integer getIid() {
        return iid;
    }

    public void setIid(Integer iid) {
        this.iid = iid;
    }

    public Integer getIidEmpresa() {
        return iidEmpresa;
    }

    public void setIidEmpresa(Integer iidEmpresa) {
        this.iidEmpresa = iidEmpresa;
    }

    public Integer getIidFamilia() {
        return iidFamilia;
    }

    public void setIidFamilia(Integer iidFamilia) {
        this.iidFamilia = iidFamilia;
    }

    public String getTipoRal() {
        return tipoRal;
    }

    public void setTipoRal(String tipoRal) {
        this.tipoRal = tipoRal;
    }

    public Float getPvp() {
        return pvp;
    }

    public void setPvp(Float pvp) {
        this.pvp = pvp;
    }

    public Float getPtc() {
        return ptc;
    }

    public void setPtc(Float ptc) {
        this.ptc = ptc;
    }

    public Float getUpc() {
        return upc;
    }

    public void setUpc(Float upc) {
        this.upc = upc;
    }
    
 
   
}
