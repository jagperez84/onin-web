package bean;

import acceso.BaseDatos;

public class Articulo implements Comparable{

    private Integer iid;
    private Empresa iid_empresa;
    private String cod_articulo;
    private String des_tecnica;
    private String des_inf;
    private FamiliaVenta iid_fam_venta;
    private String cod_arb;
    private UnidadMedida iid_unidad_medida;
    private Moneda iid_moneda;
    private Float precio_v;
    private Float descuento;
    private String observaciones;
    private Boolean act_stock;
    private Boolean stock_neg;
    private Boolean stock_med;
    private Boolean stock_col;
    private Agentes prov_hab;
    private Boolean escalado;
    private Boolean escaladoCaracteristica;
    private Iva iva;
    private String enUso;
    private Float precioIncremento;
    private Float tamDescartable;
    private Float restoMinimo;
    private Integer stockMinimo;
    private Boolean corteLiso;
    private Float upc;
    private Float ptc;
    private Boolean monocromo;

    public Articulo() {
    }

    public Boolean getAct_stock() {
        return act_stock;
    }

    public void setAct_stock(Boolean act_stock) {
        this.act_stock = act_stock;
    }

    public String getCod_arb() {
        return cod_arb;
    }

    public void setCod_arb(String cod_arb) {
        this.cod_arb = cod_arb;
    }

    public String getCod_articulo() {
        return cod_articulo;
    }

    public void setCod_articulo(String cod_articulo) {
        this.cod_articulo = cod_articulo;
    }

    public String getDes_inf() {
        return des_inf;
    }

    public void setDes_inf(String des_inf) {
        this.des_inf = des_inf;
    }

    public String getDes_tecnica() {
        return des_tecnica;
    }

    public void setDes_tecnica(String des_tecnica) {
        this.des_tecnica = des_tecnica;
    }

    public Float getDescuento() {
        return descuento;
    }

    public void setDescuento(Float descuento) {
        this.descuento = descuento;
    }

    public Integer getIid() {
        return iid;
    }

    public void setIid(Integer iid) {
        this.iid = iid;
    }

    public Empresa getIid_empresa() {
        return iid_empresa;
    }

    public void setIid_empresa(Empresa iid_empresa) {
        this.iid_empresa = iid_empresa;
    }

    public FamiliaVenta getIid_fam_venta() {
        return iid_fam_venta;
    }

    public void setIid_fam_venta(FamiliaVenta iid_fam_venta) {
        this.iid_fam_venta = iid_fam_venta;
    }

    public Moneda getIid_moneda() {
        return iid_moneda;
    }

    public void setIid_moneda(Moneda iid_moneda) {
        this.iid_moneda = iid_moneda;
    }

    public UnidadMedida getIid_unidad_medida() {
        return iid_unidad_medida;
    }

    public void setIid_unidad_medida(UnidadMedida iid_unidad_medida) {
        this.iid_unidad_medida = iid_unidad_medida;
    }

    public String getObservaciones() {
        return observaciones;
    }

    public void setObservaciones(String observaciones) {
        this.observaciones = observaciones;
    }

    public Float getPrecio_v() {
        return precio_v;
    }

    public void setPrecio_v(Float precio_v) {
        this.precio_v = precio_v;
    }

    public Agentes getProv_hab() {
        return prov_hab;
    }

    public void setProv_hab(Agentes prov_hab) {
        this.prov_hab = prov_hab;
    }

    public Boolean getStock_col() {
        return stock_col;
    }

    public void setStock_col(Boolean stock_col) {
        this.stock_col = stock_col;
    }

    public Boolean getStock_med() {
        return stock_med;
    }

    public void setStock_med(Boolean stock_med) {
        this.stock_med = stock_med;
    }

    public Boolean getStock_neg() {
        return stock_neg;
    }

    public void setStock_neg(Boolean stock_neg) {
        this.stock_neg = stock_neg;
    }

    public Boolean getEscalado() {
        return escalado;
    }

    public void setEscalado(Boolean escalado) {
        this.escalado = escalado;
    }

    public Boolean getEscaladoCaracteristica() {
        return escaladoCaracteristica;
    }

    public void setEscaladoCaracteristica(Boolean escaladoCaracteristica) {
        this.escaladoCaracteristica = escaladoCaracteristica;
    }

    public Iva getIva() {
        return iva;
    }

    public void setIva(Iva iva) {
        this.iva = iva;
    }

    public String getEnUso() {
        return enUso;
    }

    public void setEnUso(String enUso) {
        this.enUso = enUso;
    }

    public Float getPrecioIncremento() {
        return precioIncremento;
    }

    public void setPrecioIncremento(Float precioIncremento) {
        this.precioIncremento = precioIncremento;
    }

    public Float getTamDescartable() {
        return tamDescartable;
    }

    public void setTamDescartable(Float tamDescartable) {
        this.tamDescartable = tamDescartable;
    }
    
    public int compareTo(Object o) {
        Articulo a = (Articulo) o;
        return this.cod_articulo.compareTo(a.getCod_articulo());
    }

    public Float getPtc() {
        return ptc;
    }

    public void setPtc(Float ptc) {
        this.ptc = ptc;
    }

    public Float getUpc() {
        return upc;
    }

    public void setUpc(Float upc) {
        this.upc = upc;
    }

    public Boolean getCorteLiso() {
        return corteLiso;
    }

    public void setCorteLiso(Boolean corteLiso) {
        this.corteLiso = corteLiso;
    }

    public Float getRestoMinimo() {
        return restoMinimo;
    }

    public void setRestoMinimo(Float restoMinimo) {
        this.restoMinimo = restoMinimo;
    }

    public Integer getStockMinimo() {
        return stockMinimo;
    }

    public void setStockMinimo(Integer stockMinimo) {
        this.stockMinimo = stockMinimo;
    }
    
    public Boolean getMonocromo() {
        return monocromo;
    }

    public void setMonocromo(Boolean monocromo) {
        this.monocromo = monocromo;
    }
    
    public Float calcularPrecioEscalado(Caracteristica car, Float fMedida1, Float fMedida2){
        Float res = 0F;
        
        if (getEscalado()) {
            res = BaseDatos.obtenerPrecioEscalado(iid, null, fMedida1.intValue(), fMedida2.intValue());
        } else if (getEscaladoCaracteristica()) {
            res = BaseDatos.obtenerPrecioEscalado(iid, car.getIid(), fMedida1.intValue(), fMedida2.intValue());
        } else {
            res = getPrecio_v();
        }
        return res;
    }
    
}
