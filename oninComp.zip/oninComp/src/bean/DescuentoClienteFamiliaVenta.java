package bean;

import acceso.BaseDatos;

public class DescuentoClienteFamiliaVenta {
    private Integer iid;
    private FamiliaVenta familiaVenta;
    private Double descuento;
    private Agentes cliente;

    public FamiliaVenta getFamiliaVenta() {
        return familiaVenta;
    }

    public Agentes getCliente() {
        return cliente;
    }

    public void setCliente(Agentes cliente) {
        this.cliente = cliente;
    }

    public void setFamiliaVenta(FamiliaVenta familiaVenta) {
        this.familiaVenta = familiaVenta;
    }

    public Integer getIid() {
        return iid;
    }

    public void setIid(Integer iid) {
        this.iid = iid;
    }
    
    public Double getDescuento() {
        return descuento;
    }

    public void setDescuento(Double descuento) {
        this.descuento = descuento;
    }
    
    public DescuentoClienteFamiliaVenta copiar(){
        DescuentoClienteFamiliaVenta res;
        res = new DescuentoClienteFamiliaVenta();
        
        if(this.iid != null){
            res.setIid(new Integer(this.iid));
        } else {
            res.setIid(null);
        }
        
        if(this.descuento != null){
            res.setDescuento(new Double (this.descuento));
        } else {
            res.setDescuento(null);
        }
        
        if(this.familiaVenta != null){
            res.setFamiliaVenta(BaseDatos.obtenerFamiliaVentaPorIid(this.familiaVenta.getIid()));
        } else {
            res.setFamiliaVenta(null);
        }

        return res;
    }

}
