package bean;

public class AgenteArticulo {
    private Integer iid;
    private Empresa iid_empresa;
    private Agentes iid_agente;
    private Caracteristica iid_caracteristica;
    private String referencia;
    private Integer plazo_entrega;
    private Float precio;
    private Articulo iid_articulo;
    

    public AgenteArticulo() {
    }

    public Integer getIid() {
        return iid;
    }

    public void setIid(Integer iid) {
        this.iid = iid;
    }

    public Agentes getIid_agente() {
        return iid_agente;
    }

    public void setIid_agente(Agentes iid_agente) {
        this.iid_agente = iid_agente;
    }

    public Caracteristica getIid_caracteristica() {
        return iid_caracteristica;
    }

    public void setIid_caracteristica(Caracteristica iid_caracteristica) {
        this.iid_caracteristica = iid_caracteristica;
    }

    public Empresa getIid_empresa() {
        return iid_empresa;
    }

    public void setIid_empresa(Empresa iid_empresa) {
        this.iid_empresa = iid_empresa;
    }

    public Integer getPlazo_entrega() {
        return plazo_entrega;
    }

    public void setPlazo_entrega(Integer plazo_entrega) {
        this.plazo_entrega = plazo_entrega;
    }

    public Float getPrecio() {
        return precio;
    }

    public void setPrecio(Float precio) {
        this.precio = precio;
    }

    public String getReferencia() {
        return referencia;
    }

    public void setReferencia(String referencia) {
        this.referencia = referencia;
    }

    public Articulo getIid_articulo() {
        return iid_articulo;
    }

    public void setIid_articulo(Articulo iid_articulo) {
        this.iid_articulo = iid_articulo;
    }
    
}
