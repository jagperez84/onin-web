package bean;

public class TipoMedida {
    
    private Integer iid;
    private String codigo;
    private String nombre;
    private Integer num_dimensiones;
    private String nombre_dim_1;
    private String nombre_dim_2;
    private String nombre_dim_3;
    private String nombre_dim_4;
    private String nombre_dim_5;
    private UnidadMedida unidad_dim_1; 
    private UnidadMedida unidad_dim_2;
    private UnidadMedida unidad_dim_3;
    private UnidadMedida unidad_dim_4;
    private UnidadMedida unidad_dim_5;
    private UnidadMedida unidad_resultado;
    private String tipo_calculo;
    private String formula;
        
    public TipoMedida(){
        
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getFormula() {
        return formula;
    }

    public void setFormula(String formula) {
        this.formula = formula;
    }

    public Integer getIid() {
        return iid;
    }

    public void setIid(Integer iid) {
        this.iid = iid;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre_dim_1() {
        return nombre_dim_1;
    }

    public void setNombre_dim_1(String nombre_dim_1) {
        this.nombre_dim_1 = nombre_dim_1;
    }

    public String getNombre_dim_2() {
        return nombre_dim_2;
    }

    public void setNombre_dim_2(String nombre_dim_2) {
        this.nombre_dim_2 = nombre_dim_2;
    }

    public String getNombre_dim_3() {
        return nombre_dim_3;
    }

    public void setNombre_dim_3(String nombre_dim_3) {
        this.nombre_dim_3 = nombre_dim_3;
    }

    public String getNombre_dim_4() {
        return nombre_dim_4;
    }

    public void setNombre_dim_4(String nombre_dim_4) {
        this.nombre_dim_4 = nombre_dim_4;
    }

    public String getNombre_dim_5() {
        return nombre_dim_5;
    }

    public void setNombre_dim_5(String nombre_dim_5) {
        this.nombre_dim_5 = nombre_dim_5;
    }

    public Integer getNum_dimensiones() {
        return num_dimensiones;
    }

    public void setNum_dimensiones(Integer num_dimensiones) {
        this.num_dimensiones = num_dimensiones;
    }

    public String getTipo_calculo() {
        return tipo_calculo;
    }

    public void setTipo_calculo(String tipo_calculo) {
        this.tipo_calculo = tipo_calculo;
    }

    public UnidadMedida getUnidad_dim_1() {
        return unidad_dim_1;
    }

    public void setUnidad_dim_1(UnidadMedida unidad_dim_1) {
        this.unidad_dim_1 = unidad_dim_1;
    }

    public UnidadMedida getUnidad_dim_2() {
        return unidad_dim_2;
    }

    public void setUnidad_dim_2(UnidadMedida unidad_dim_2) {
        this.unidad_dim_2 = unidad_dim_2;
    }

    public UnidadMedida getUnidad_dim_3() {
        return unidad_dim_3;
    }

    public void setUnidad_dim_3(UnidadMedida unidad_dim_3) {
        this.unidad_dim_3 = unidad_dim_3;
    }

    public UnidadMedida getUnidad_dim_4() {
        return unidad_dim_4;
    }

    public void setUnidad_dim_4(UnidadMedida unidad_dim_4) {
        this.unidad_dim_4 = unidad_dim_4;
    }

    public UnidadMedida getUnidad_dim_5() {
        return unidad_dim_5;
    }

    public void setUnidad_dim_5(UnidadMedida unidad_dim_5) {
        this.unidad_dim_5 = unidad_dim_5;
    }

    public UnidadMedida getUnidad_resultado() {
        return unidad_resultado;
    }

    public void setUnidad_resultado(UnidadMedida unidad_resultado) {
        this.unidad_resultado = unidad_resultado;
    }
}
