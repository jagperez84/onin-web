package bean;

import util.Util;

public class LineaPresupuesto {
    private Integer iid;
    private Integer codigo;
    private Articulo articulo_iid;
    private Integer nummedidas;
    private Double precio;
    private Double descuento;
    private Presupuesto presupuesto_iid;
    private Double cantidad;
    private Double medida1;
    private Double medida2;
    private Double medida3;
    private Double medida4;
    private Double medida5;
    private Double medidares;
    private Double importe;
    private String descripcion;
    private Double precioArticulo;
    private Caracteristica caracteristica;
    private Boolean lineaArticulo;
    private String importeStr;
    private String cantidadStr;
    private String manual;
    private Double cantidadRec;
    private String precioStr;
    
    public void setCantidadStr(String cantidadStr) {
        this.cantidadStr = cantidadStr;
    }
    public void setImporteStr(String importeStr) {
        this.importeStr = importeStr;
    }

    public String getCantidadStr() {
        return cantidadStr;
    }

    public String getImporteStr() {
        return importeStr;
    }

    public Articulo getArticulo_iid() {
        return articulo_iid;
    }

    public void setArticulo_iid(Articulo articulo_iid) {
        this.articulo_iid = articulo_iid;
    }

    public Integer getCodigo() {
        return codigo;
    }

    public void setCodigo(Integer codigo) {
        this.codigo = codigo;
    }

    public Caracteristica getCaracteristica() {
        return caracteristica;
    }

    public void setCaracteristica(Caracteristica caracteristica) {
        this.caracteristica = caracteristica;
    }

    public Integer getIid() {
        return iid;
    }

    public Double getDescuento() {
        return descuento;
    }

    public void setDescuento(Double descuento) {
        this.descuento = descuento;
    }

    public void setIid(Integer iid) {
        this.iid = iid;
    }

    public Integer getNummedidas() {
        return nummedidas;
    }

    public void setNummedidas(Integer nummedidas) {
        this.nummedidas = nummedidas;
    }

    public Double getPrecio() {
        return precio;
    }

    public void setPrecio(Double precio) {
        this.precio = precio;
    }

    public Presupuesto getPresupuesto_iid() {
        return presupuesto_iid;
    }

    public void setPresupuesto_iid(Presupuesto presupuesto_iid) {
        this.presupuesto_iid = presupuesto_iid;
    }

    public Double getCantidad() {
        return cantidad;
    }

    public void setCantidad(Double cantidad) {
        this.cantidad = cantidad;
    }

    public Double getMedida1() {
        return medida1;
    }

    public void setMedida1(Double medida1) {
        this.medida1 = medida1;
    }

    public Double getMedida2() {
        return medida2;
    }

    public void setMedida2(Double medida2) {
        this.medida2 = medida2;
    }

    public Double getMedida3() {
        return medida3;
    }

    public void setMedida3(Double medida3) {
        this.medida3 = medida3;
    }

    public Double getMedida4() {
        return medida4;
    }

    public void setMedida4(Double medida4) {
        this.medida4 = medida4;
    }

    public Double getMedida5() {
        return medida5;
    }

    public void setMedida5(Double medida5) {
        this.medida5 = medida5;
    }

    public Double getMedidares() {
        return medidares;
    }

   
    
    
    public String getMedidasStr(){
        
        String res = "";
        
        if(nummedidas == null){
            res = "";
        } else if(nummedidas == 1){
            res = Util.convertirPuntoAComa(medida1.toString());
        } else if(nummedidas == 2){
            res = Util.convertirPuntoAComa(medida1.toString()) + " x " + Util.convertirPuntoAComa(medida2.toString());
        } else if(nummedidas == 3){
            res = Util.convertirPuntoAComa(medida1.toString()) + " x " + Util.convertirPuntoAComa(medida2.toString()) + " x " + Util.convertirPuntoAComa(medida3.toString());
        } else if(nummedidas == 4){
            res = Util.convertirPuntoAComa(medida1.toString()) + " x " + Util.convertirPuntoAComa(medida2.toString()) + " x " + Util.convertirPuntoAComa(medida3.toString())+ " x " + Util.convertirPuntoAComa(medida4.toString());
        } else if(nummedidas == 5){
            res = Util.convertirPuntoAComa(medida1.toString()) + " x " + Util.convertirPuntoAComa(medida2.toString()) + " x " + Util.convertirPuntoAComa(medida3.toString())+ " x " + Util.convertirPuntoAComa(medida4.toString()) + Util.convertirPuntoAComa(medida5.toString());
        } else {
            res = "";
        }
        
        return res;
    }

    public void setMedidares(Double medidares) {
        this.medidares = medidares;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public Double getPrecioArticulo() {
        return precioArticulo;
    }

    public void setPrecioArticulo(Double precioArticulo) {
        this.precioArticulo = precioArticulo;
    }

    public Boolean getLineaArticulo() {
        boolean res = true;
        if(lineaArticulo != null){
            res = lineaArticulo;
        }
        return res;
    }

    public void setLineaArticulo(Boolean lineaArticulo) {
        this.lineaArticulo = lineaArticulo;
    }

    public Double getImporte() {
        return importe;
    }

    public void setImporte(Double importe) {
        this.importe = importe;
    }

    public String getManual() {
        return manual;
    }

    public void setManual(String manual) {
        this.manual = manual;
    }

    public Double getCantidadRec() {
        return cantidadRec;
    }

    public void setCantidadRec(Double cantidadRec) {
        this.cantidadRec = cantidadRec;
    }

    public String getPrecioStr() {
        return precioStr;
    }

    public void setPrecioStr(String precioStr) {
        this.precioStr = precioStr;
    }

    public LineaPresupuesto copiar(Presupuesto p){
        LineaPresupuesto res = new LineaPresupuesto();
        
        res.setCodigo(this.getCodigo());
        res.setArticulo_iid(this.getArticulo_iid());
        res.setNummedidas(this.getNummedidas());
        res.setPrecio(this.getPrecio());
        res.setDescuento(this.getDescuento());
        res.setPresupuesto_iid(p);
        res.setCantidad(this.getCantidad());
        res.setMedida1(this.getMedida1());
        res.setMedida2(this.getMedida2());
        res.setMedida3(this.getMedida3());
        res.setMedida4(this.getMedida4());
        res.setMedida5(this.getMedida5());
        res.setMedidares(this.getMedidares());
        res.setDescripcion(this.getDescripcion());
        res.setPrecioArticulo(this.precioArticulo);
        res.setCaracteristica(this.getCaracteristica());
        res.setLineaArticulo(this.getLineaArticulo());
        res.setCantidadRec(this.getCantidadRec());
        res.setImporte(this.getImporte());
        res.setManual(this.manual);
        res.setPrecioStr(this.getPrecioStr());
		res.setImporteStr(this.getImporteStr());
		res.setCantidadStr(this.getCantidadStr());
        return res;
    }
}
