package bean;

public class LineaPresupuestoHistorico {
    private Integer iid;
    private Integer codigo;
    private Articulo articulo;
    private Integer nummedidas;
    private Double precio;
    private Double descuento;
    private PresupuestoHistorico historico;
    private Double cantidad;
    private Double medida1;
    private Double medida2;
    private Double medida3;
    private Double medida4;
    private Double medida5;
    private Double medidares;
    private Double importe;
    private String descripcion;
    private Double precioArticulo;
    private Caracteristica caracteristica;
    private Boolean lineaArticulo;
    private String manual;

    public LineaPresupuestoHistorico(LineaPresupuesto lp) {
        this.articulo = lp.getArticulo_iid();
        this.cantidad = lp.getCantidad();
        this.caracteristica = lp.getCaracteristica();
        this.codigo = lp.getCodigo();
        this.descripcion = lp.getDescripcion();
        this.descuento = lp.getDescuento();
        this.lineaArticulo = lp.getLineaArticulo();
        this.medida1 = lp.getMedida1();
        this.medida2 = lp.getMedida2();
        this.medida3 = lp.getMedida3();
        this.medida4 = lp.getMedida4();
        this.medida5 = lp.getMedida5();
        this.medidares = lp.getMedidares();
        this.nummedidas = lp.getNummedidas();
        this.precio = lp.getPrecio();
        this.precioArticulo = lp.getPrecioArticulo();
        this.importe = lp.getImporte();
    }

    public LineaPresupuestoHistorico(){
        
    }
            
    public Articulo getArticulo() {
        return articulo;
    }

    public void setArticulo(Articulo articulo) {
        this.articulo = articulo;
    }

    public Integer getCodigo() {
        return codigo;
    }

    public void setCodigo(Integer codigo) {
        this.codigo = codigo;
    }

    public Caracteristica getCaracteristica() {
        return caracteristica;
    }

    public void setCaracteristica(Caracteristica caracteristica) {
        this.caracteristica = caracteristica;
    }

    public PresupuestoHistorico getHistorico() {
        return historico;
    }

    public void setHistorico(PresupuestoHistorico historico) {
        this.historico = historico;
    }

    public Integer getIid() {
        return iid;
    }

    public Double getDescuento() {
        return descuento;
    }

    public void setDescuento(Double descuento) {
        this.descuento = descuento;
    }

    public void setIid(Integer iid) {
        this.iid = iid;
    }

    public Integer getNummedidas() {
        return nummedidas;
    }

    public void setNummedidas(Integer nummedidas) {
        this.nummedidas = nummedidas;
    }

    public Double getPrecio() {
        return precio;
    }

    public void setPrecio(Double precio) {
        this.precio = precio;
    }

    public Double getCantidad() {
        return cantidad;
    }

    public void setCantidad(Double cantidad) {
        this.cantidad = cantidad;
    }

    public Double getMedida1() {
        return medida1;
    }

    public void setMedida1(Double medida1) {
        this.medida1 = medida1;
    }

    public Double getMedida2() {
        return medida2;
    }

    public void setMedida2(Double medida2) {
        this.medida2 = medida2;
    }

    public Double getMedida3() {
        return medida3;
    }

    public void setMedida3(Double medida3) {
        this.medida3 = medida3;
    }

    public Double getMedida4() {
        return medida4;
    }

    public void setMedida4(Double medida4) {
        this.medida4 = medida4;
    }

    public Double getMedida5() {
        return medida5;
    }

    public void setMedida5(Double medida5) {
        this.medida5 = medida5;
    }

    public Double getMedidares() {
        return medidares;
    }
    
    public String getMedidasStr(){
        
        String res = "";
        
        if(nummedidas == null){
            res = "";
        } else if(nummedidas == 1){
            res = medida1.toString();
        } else if(nummedidas == 2){
            res = medida1.toString() + " x " + medida2.toString();
        } else if(nummedidas == 3){
            res = medida1.toString() + " x " + medida2.toString() + " x " + medida3.toString();
        } else if(nummedidas == 4){
            res = medida1.toString() + " x " + medida2.toString() + " x " + medida3.toString()+ " x " + medida4.toString();
        } else if(nummedidas == 5){
            res = medida1.toString() + " x " + medida2.toString() + " x " + medida3.toString()+ " x " + medida4.toString() + medida5.toString();
        } else {
            res = "";
        }
        
        return res;
    }

    public void setMedidares(Double medidares) {
        this.medidares = medidares;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public Double getPrecioArticulo() {
        return precioArticulo;
    }

    public void setPrecioArticulo(Double precioArticulo) {
        this.precioArticulo = precioArticulo;
    }

    public Boolean getLineaArticulo() {
        boolean res = true;
        if(lineaArticulo != null){
            res = lineaArticulo;
        }
        return res;
    }

    public void setLineaArticulo(Boolean lineaArticulo) {
        this.lineaArticulo = lineaArticulo;
    }

    public Double getImporte() {
        return importe;
    }

    public void setImporte(Double importe) {
        this.importe = importe;
    }

    public String getManual() {
        return manual;
    }

    public void setManual(String manual) {
        this.manual = manual;
    }
    
    

    public LineaPresupuesto copiar(Presupuesto p){
        LineaPresupuesto res = new LineaPresupuesto();
        
        res.setCodigo(this.getCodigo());
        res.setArticulo_iid(this.getArticulo());
        res.setNummedidas(this.getNummedidas());
        res.setPrecio(this.getPrecio());
        res.setDescuento(this.getDescuento());
        res.setPresupuesto_iid(p);
        res.setCantidad(this.getCantidad());
        res.setMedida1(this.getMedida1());
        res.setMedida2(this.getMedida2());
        res.setMedida3(this.getMedida3());
        res.setMedida4(this.getMedida4());
        res.setMedida5(this.getMedida5());
        res.setMedidares(this.getMedidares());
        res.setDescripcion(this.getDescripcion());
        res.setPrecioArticulo(this.precioArticulo);
        res.setCaracteristica(this.getCaracteristica());
        res.setLineaArticulo(this.getLineaArticulo());
        res.setImporte(this.getImporte());
        res.setManual(manual);
        return res;
    }
}
