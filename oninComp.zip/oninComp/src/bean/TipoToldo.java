package bean;

public class TipoToldo {
    private Integer iid;
    private String codigo;
    private String descripcion;

    public TipoToldo() {
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public Integer getIid() {
        return iid;
    }

    public void setIid(Integer iid) {
        this.iid = iid;
    }
    
    @Override
    public boolean equals(Object o){
        TipoToldo other = (TipoToldo)o;
        return iid.equals(other.getIid());
    }
}
