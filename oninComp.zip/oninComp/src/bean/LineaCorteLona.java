package bean;

public class LineaCorteLona {
    private Integer iid;
    private Presupuesto presupuesto;
    private Articulo articulo;
    private Caracteristica caracteristica;
    private Integer codigoLinea;
    private Double cantidad;
    private Double linea;
    private Double salida;
    private String tipoCorteLona;
    private Boolean automatico;
    private Double dobladillo;
    private Double solape;
    private Double anchoSeleccionado;
    private Boolean esDespiece;
    private LineaPresupuesto lineaPresupuesto;
    private DespiecePresupuesto despiece;

    public LineaCorteLona() {
    }

    public Double getAnchoSeleccionado() {
        return anchoSeleccionado;
    }

    public void setAnchoSeleccionado(Double anchoSeleccionado) {
        this.anchoSeleccionado = anchoSeleccionado;
    }
    public Boolean getAutomatico() {
        return automatico;
    }

    public void setAutomatico(Boolean automatico) {
        this.automatico = automatico;
    }

    public Double getCantidad() {
        return cantidad;
    }

    public void setCantidad(Double cantidad) {
        this.cantidad = cantidad;
    }

    public Integer getCodigoLinea() {
        return codigoLinea;
    }

    public void setCodigoLinea(Integer codigoLinea) {
        this.codigoLinea = codigoLinea;
    }

    public Double getDobladillo() {
        return dobladillo;
    }

    public void setDobladillo(Double dobladillo) {
        this.dobladillo = dobladillo;
    }

    public Integer getIid() {
        return iid;
    }

    public void setIid(Integer iid) {
        this.iid = iid;
    }

    public Double getLinea() {
        return linea;
    }

    public void setLinea(Double linea) {
        this.linea = linea;
    }

    public Double getSalida() {
        return salida;
    }

    public void setSalida(Double salida) {
        this.salida = salida;
    }

    public Double getSolape() {
        return solape;
    }

    public void setSolape(Double solape) {
        this.solape = solape;
    }

    public String getTipoCorteLona() {
        return tipoCorteLona;
    }

    public void setTipoCorteLona(String tipoCorteLona) {
        this.tipoCorteLona = tipoCorteLona;
    }

    public DespiecePresupuesto getDespiece() {
        return despiece;
    }

    public void setDespiece(DespiecePresupuesto despiece) {
        this.despiece = despiece;
    }

    public Boolean getEsDespiece() {
        return esDespiece;
    }

    public void setEsDespiece(Boolean esDespiece) {
        this.esDespiece = esDespiece;
    }

    public LineaPresupuesto getLineaPresupuesto() {
        return lineaPresupuesto;
    }

    public void setLineaPresupuesto(LineaPresupuesto lineaPresupuesto) {
        this.lineaPresupuesto = lineaPresupuesto;
    }

    public Articulo getArticulo() {
        return articulo;
    }

    public void setArticulo(Articulo articulo) {
        this.articulo = articulo;
    }

    public Caracteristica getCaracteristica() {
        return caracteristica;
    }

    public void setCaracteristica(Caracteristica caracteristica) {
        this.caracteristica = caracteristica;
    }

    public Presupuesto getPresupuesto() {
        return presupuesto;
    }

    public void setPresupuesto(Presupuesto presupuesto) {
        this.presupuesto = presupuesto;
    }
    
}
