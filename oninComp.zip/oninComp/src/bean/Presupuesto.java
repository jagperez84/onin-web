package bean;

public class Presupuesto {
    private Integer iid;
    private String numero;
    private Long fecha;
    private FormaPago2 fp;
    private double importe_total;
    private EstadoDocumento estado;
    private String serie;
    private double dto;
    private Empresa empresa;
    private ClaseDocumento clase_documento;
    private Boolean desde_presupuesto;
    private Boolean convertido;
    private String nota_documento;
    private Iva iva;
    private String referencia;
    private String codigoCliente;
    private String nombreCliente;
    private String domicilioCliente;
    private String localidadCliente;
    private String provinciaCliente;
    private String telefonoCliente;
    private String cifCliente;
    private String cpCliente;
    private String paisCliente;
    private Boolean pagado;
    private Comercial comercial;
    private String contactado;
    private Boolean pagadoComercial;
    private Float porcentajeComercial;
    private String observaciones;
    private Long fechaEntrega;
    private String recomendadoPor;
    private String emailCliente;
    private Boolean preparado;
    private Boolean confeccionado;
    private Boolean fabricado;
    private Boolean instalado;
    private Boolean impagado;
    private Almacen almacen;
    private Integer medicion;
    private Integer interlocutor;
    private Float ivaDocumento;
    
    public Presupuesto() {
    
    }

    public Presupuesto(Presupuesto pAntiguo) {
        this.iid = pAntiguo.getIid();
        this.numero = pAntiguo.getNumero();
        this.fecha = pAntiguo.getFecha();
        this.fp = pAntiguo.getFp();
        this.importe_total = pAntiguo.getImporte_total();
        this.estado = pAntiguo.getEstado();
        this.serie = pAntiguo.getSerie();
        this.dto = pAntiguo.getDto();
        this.empresa = pAntiguo.getEmpresa();
        this.clase_documento = pAntiguo.getClase_documento();
        this.desde_presupuesto = pAntiguo.getDesde_presupuesto();
        this.convertido = pAntiguo.getConvertido();
        this.nota_documento = pAntiguo.getNota_documento();
        this.iva = pAntiguo.getIva();
        this.referencia = pAntiguo.getReferencia();
        this.codigoCliente = pAntiguo.getCodigoCliente();
        this.nombreCliente = pAntiguo.getNombreCliente();
        this.domicilioCliente = pAntiguo.getDomicilioCliente();
        this.localidadCliente = pAntiguo.getLocalidadCliente();
        this.provinciaCliente = pAntiguo.getProvinciaCliente();
        this.telefonoCliente  = pAntiguo.getTelefonoCliente();
        this.cifCliente = pAntiguo.getCifCliente();
        this.cpCliente = pAntiguo.getCpCliente();
        this.paisCliente = pAntiguo.getPaisCliente();
        this.pagado = pAntiguo.getPagado();
        this.comercial = pAntiguo.getComercial();
        this.contactado = pAntiguo.getContactado();
        this.pagadoComercial = pAntiguo.getPagadoComercial();
        this.porcentajeComercial = pAntiguo.getPorcentajeComercial();
        this.observaciones = pAntiguo.getObservaciones();
        this.fechaEntrega = pAntiguo.getFechaEntrega();
        this.recomendadoPor = pAntiguo.getRecomendadoPor();
        this.emailCliente = pAntiguo.getEmailCliente();
        this.preparado = pAntiguo.getPreparado();
        this.confeccionado = pAntiguo.getConfeccionado();
        this.fabricado = pAntiguo.getFabricado();
        this.instalado = pAntiguo.getInstalado();
        this.impagado = pAntiguo.getImpagado();
        this.almacen = pAntiguo.getAlmacen();
        this.medicion = pAntiguo.getMedicion();
        this.interlocutor = pAntiguo.getInterlocutor();
        this.ivaDocumento = pAntiguo.getIvaDocumento();
    }
    
    public double getDto() {
        return dto;
    }

    public void setDto(double dto) {
        this.dto = dto;
    }

    public EstadoDocumento getEstado() {
        return estado;
    }

    public void setEstado(EstadoDocumento estado) {
        this.estado = estado;
    }

    public Long getFecha() {
        return fecha;
    }

    public void setFecha(Long fecha) {
        this.fecha = fecha;
    }

    public FormaPago2 getFp() {
        return fp;
    }

    public void setFp(FormaPago2 fp) {
        this.fp = fp;
    }

    public Integer getIid() {
        return iid;
    }

    public void setIid(Integer iid) {
        this.iid = iid;
    }

    public double getImporte_total() {
        return importe_total;
    }

    public void setImporte_total(double importe_total) {
        this.importe_total = importe_total;
    }

    public String getSerie() {
        return serie;
    }

    public void setSerie(String serie) {
        this.serie = serie;
    }

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public Empresa getEmpresa() {
        return empresa;
    }

    public void setEmpresa(Empresa empresa) {
        this.empresa = empresa;
    }

    public ClaseDocumento getClase_documento() {
        return clase_documento;
    }

    public void setClase_documento(ClaseDocumento clase_documento) {
        this.clase_documento = clase_documento;
    }

    public Boolean getDesde_presupuesto() {
        return desde_presupuesto;
    }

    public void setDesde_presupuesto(Boolean desde_presupuesto) {
        this.desde_presupuesto = desde_presupuesto;
    }

    public Boolean getConvertido() {
        return convertido;
    }

    public void setConvertido(Boolean convertido) {
        this.convertido = convertido;
    }

    public String getNota_documento() {
        return nota_documento;
    }

    public void setNota_documento(String nota_documento) {
        this.nota_documento = nota_documento;
    }

    public Iva getIva() {
        return iva;
    }

    public void setIva(Iva iva) {
        this.iva = iva;
    }

    public String getReferencia() {
        return referencia;
    }

    public void setReferencia(String referencia) {
        this.referencia = referencia;
    }

    public String getCifCliente() {
        return cifCliente;
    }

    public void setCifCliente(String cifCliente) {
        this.cifCliente = cifCliente;
    }

    public String getCodigoCliente() {
        return codigoCliente;
    }

    public void setCodigoCliente(String codigoCliente) {
        this.codigoCliente = codigoCliente;
    }

    public String getCpCliente() {
        return cpCliente;
    }

    public void setCpCliente(String cpCliente) {
        this.cpCliente = cpCliente;
    }

    public String getDomicilioCliente() {
        return domicilioCliente;
    }

    public void setDomicilioCliente(String domicilioCliente) {
        this.domicilioCliente = domicilioCliente;
    }

    public String getLocalidadCliente() {
        return localidadCliente;
    }

    public void setLocalidadCliente(String localidadCliente) {
        this.localidadCliente = localidadCliente;
    }

    public String getNombreCliente() {
        return nombreCliente;
    }

    public void setNombreCliente(String nombreCliente) {
        this.nombreCliente = nombreCliente;
    }

    public String getPaisCliente() {
        return paisCliente;
    }

    public void setPaisCliente(String paisCliente) {
        this.paisCliente = paisCliente;
    }

    public String getProvinciaCliente() {
        return provinciaCliente;
    }

    public void setProvinciaCliente(String provinciaCliente) {
        this.provinciaCliente = provinciaCliente;
    }

    public String getTelefonoCliente() {
        return telefonoCliente;
    }

    public void setTelefonoCliente(String telefonoCliente) {
        this.telefonoCliente = telefonoCliente;
    }

    public Boolean getPagado() {
        return pagado;
    }

    public void setPagado(Boolean pagado) {
        this.pagado = pagado;
    }

    public Comercial getComercial() {
        return comercial;
    }

    public void setComercial(Comercial comercial) {
        this.comercial = comercial;
    }

    public String getContactado() {
        return contactado;
    }

    public void setContactado(String contactado) {
        this.contactado = contactado;
    }

    public Boolean getPagadoComercial() {
        return pagadoComercial;
    }

    public void setPagadoComercial(Boolean pagadoComercial) {
        this.pagadoComercial = pagadoComercial;
    }

    public Float getPorcentajeComercial() {
        return porcentajeComercial;
    }

    public void setPorcentajeComercial(Float porcentajeComercial) {
        this.porcentajeComercial = porcentajeComercial;
    }

    public String getObservaciones() {
        return observaciones;
    }

    public void setObservaciones(String observaciones) {
        this.observaciones = observaciones;
    }

    public Long getFechaEntrega() {
        return fechaEntrega;
    }

    public void setFechaEntrega(Long fechaEntrega) {
        this.fechaEntrega = fechaEntrega;
    }

    public String getRecomendadoPor() {
        return recomendadoPor;
    }

    public void setRecomendadoPor(String recomendadoPor) {
        this.recomendadoPor = recomendadoPor;
    }

    public String getEmailCliente() {
        return emailCliente;
    }

    public void setEmailCliente(String emailCliente) {
        this.emailCliente = emailCliente;
    }

    public Boolean getConfeccionado() {
        return confeccionado;
    }

    public void setConfeccionado(Boolean confeccionado) {
        this.confeccionado = confeccionado;
    }

    public Boolean getFabricado() {
        return fabricado;
    }

    public void setFabricado(Boolean fabricado) {
        this.fabricado = fabricado;
    }

    public Boolean getPreparado() {
        return preparado;
    }

    public void setPreparado(Boolean preparado) {
        this.preparado = preparado;
    }

    public Boolean getImpagado() {
        return impagado;
    }

    public void setImpagado(Boolean impagado) {
        this.impagado = impagado;
    }

    public Almacen getAlmacen() {
        return almacen;
    }

    public void setAlmacen(Almacen almacen) {
        this.almacen = almacen;
    }

    public Boolean getInstalado() {
        return instalado;
    }

    public void setInstalado(Boolean instalado) {
        this.instalado = instalado;
    }

    public Integer getMedicion() {
        return medicion;
    }

    public void setMedicion(Integer medicion) {
        this.medicion = medicion;
    }

    public Integer getInterlocutor() {
        return interlocutor;
    }

    public void setInterlocutor(Integer interlocutor) {
        this.interlocutor = interlocutor;
    }

    public Float getIvaDocumento() {
        return ivaDocumento;
    }

    public void setIvaDocumento(Float ivaDocumento) {
        this.ivaDocumento = ivaDocumento;
    }
}
