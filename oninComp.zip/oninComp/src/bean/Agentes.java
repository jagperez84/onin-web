package bean;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Agentes {
    private Integer iid;
    private String cif_nif;
    private TipoAgente tipo_agente;
    private String nombre_fiscal;
    private String nombre_comercial;
    private String cod_agente;
    private String direccion;
    private String poblacion;
    private String provincia;
    private String pais;
    private String telefono;
    private String telefono2;
    private String telefono3;
    private String fax;
    private String email;
    private Integer codigo_postal;
    private Iva iva;
    private Boolean exento_iva;
    private String contactar;
    private FormaPago formaPago;
    private Empresa iid_empresa;
    private String entidad;
    private String direc_ent;
    private String pob_ent;
    private String prov_ent;
    private String cp_ent;
    private String cuenta;
    private String observaciones;
    private Integer diaCobro1;
    private Integer diaCobro2;
    private Integer diaCobro3;
    private String direccion_fiscal;
    private String poblacion_fiscal;
    private String provincia_fiscal;
    private Integer codigo_postal_fiscal;
    private Boolean terceros;
    private String swift;

    public String getCp_ent() {
        return cp_ent;
    }

    public void setCp_ent(String cp_ent) {
        this.cp_ent = cp_ent;
    }

    public String getCuenta() {
        return cuenta;
    }

    public void setCuenta(String cuenta) {
        this.cuenta = cuenta;
    }

    public String getDirec_ent() {
        return direc_ent;
    }

    public void setDirec_ent(String direc_ent) {
        this.direc_ent = direc_ent;
    }

    public String getEntidad() {
        return entidad;
    }

    public void setEntidad(String entidad) {
        this.entidad = entidad;
    }

    public String getPob_ent() {
        return pob_ent;
    }

    public void setPob_ent(String pob_ent) {
        this.pob_ent = pob_ent;
    }

    public String getProv_ent() {
        return prov_ent;
    }

    public void setProv_ent(String prov_ent) {
        this.prov_ent = prov_ent;
    }

    public Agentes() {
    }

    public String getCif_nif() {
        return cif_nif;
    }

    public void setCif_nif(String cif_nif) {
        this.cif_nif = cif_nif;
    }

    public String getCod_agente() {
        return cod_agente;
    }

    public void setCod_agente(String cod_agente) {
        this.cod_agente = cod_agente;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getObservaciones() {
        return observaciones;
    }

    public void setObservaciones(String observaciones) {
        this.observaciones = observaciones;
    }
    
    public String getFax() {
        return fax;
    }

    public void setFax(String fax) {
        this.fax = fax;
    }

    public Integer getIid() {
        return iid;
    }

    public void setIid(Integer iid) {
        this.iid = iid;
    }

    public String getNombre_comercial() {
        return nombre_comercial;
    }

    public void setNombre_comercial(String nombre_comercial) {
        this.nombre_comercial = nombre_comercial;
    }

    public String getNombre_fiscal() {
        return nombre_fiscal;
    }

    public void setNombre_fiscal(String nombre_fiscal) {
        this.nombre_fiscal = nombre_fiscal;
    }

    public String getPais() {
        return pais;
    }

    public void setPais(String pais) {
        this.pais = pais;
    }

    public String getPoblacion() {
        return poblacion;
    }

    public void setPoblacion(String poblacion) {
        this.poblacion = poblacion;
    }

    public String getProvincia() {
        return provincia;
    }

    public void setProvincia(String provincia) {
        this.provincia = provincia;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getTelefono2() {
        return telefono2;
    }

    public void setTelefono2(String telefono2) {
        this.telefono2 = telefono2;
    }

    public String getTelefono3() {
        return telefono3;
    }

    public void setTelefono3(String telefono3) {
        this.telefono3 = telefono3;
    }

    public TipoAgente getTipo_agente() {
        return tipo_agente;
    }

    public void setTipo_agente(TipoAgente tipo_agente) {
        this.tipo_agente = tipo_agente;
    }

    public Integer getCodigo_postal() {
        return codigo_postal;
    }

    public void setCodigo_postal(Integer codigo_postal) {
        this.codigo_postal = codigo_postal;
    }

    public Iva getIva() {
        return iva;
    }

    public void setIva(Iva iva) {
        this.iva = iva;
    }

    public Boolean getExento_iva() {
        return exento_iva;
    }

    public void setExento_iva(Boolean exento_iva) {
        this.exento_iva = exento_iva;
    }

    public String getContactar() {
        return contactar;
    }

    public void setContactar(String contactar) {
        this.contactar = contactar;
    }

    public FormaPago getFormaPago() {
        return formaPago;
    }

    public void setFormaPago(FormaPago fp) {
        this.formaPago = fp;
    }

    public void setIid_empresa(Empresa iid_empresa) {
        this.iid_empresa = iid_empresa;
    }

    public Empresa getIid_empresa() {
        return iid_empresa;
    }

    public Integer getDiaCobro1() {
        return diaCobro1;
    }

    public void setDiaCobro1(Integer diaCobro1) {
        this.diaCobro1 = diaCobro1;
    }

    public Integer getDiaCobro2() {
        return diaCobro2;
    }

    public void setDiaCobro2(Integer diaCobro2) {
        this.diaCobro2 = diaCobro2;
    }

    public Integer getDiaCobro3() {
        return diaCobro3;
    }

    public void setDiaCobro3(Integer diaCobro3) {
        this.diaCobro3 = diaCobro3;
    }

    public String getSwift() {
        return swift;
    }

    public void setSwift(String swift) {
        this.swift = swift;
    }
    
    
    
    public List<Integer> ordenarDiasCobro(){
        List<Integer> res = new ArrayList<Integer>();
        res.add(32);
        res.add(32);
        res.add(32);

        
        if(diaCobro1 != null){
            res.set(0, diaCobro1);
        }
        
        if(diaCobro2 != null){
            res.set(1, diaCobro2);
        }
        
        if(diaCobro3 != null){
            res.set(2, diaCobro3);
        }
        
        Collections.sort(res);
        
        return res;
    }

    public String getDireccion_fiscal() {
        return direccion_fiscal;
    }

    public void setDireccion_fiscal(String direccion_fiscal) {
        this.direccion_fiscal = direccion_fiscal;
    }

    public String getPoblacion_fiscal() {
        return poblacion_fiscal;
    }

    public void setPoblacion_fiscal(String poblacion_fiscal) {
        this.poblacion_fiscal = poblacion_fiscal;
    }

    public String getProvincia_fiscal() {
        return provincia_fiscal;
    }

    public void setProvincia_fiscal(String provincia_fiscal) {
        this.provincia_fiscal = provincia_fiscal;
    }

    public Integer getCodigo_postal_fiscal() {
        return codigo_postal_fiscal;
    }

    public void setCodigo_postal_fiscal(Integer codigo_postal_fiscal) {
        this.codigo_postal_fiscal = codigo_postal_fiscal;
    }

    public Boolean getTerceros() {
        return terceros;
    }

    public void setTerceros(Boolean terceros) {
        this.terceros = terceros;
    }
    
    
  
    
}
