package bean;

public class Seleccion {
    private Integer iid;
    private String nombre;
    private Double valor;
    private String condicion;
    private Variable variable;
    private Boolean seleccionada;

    public Seleccion() {
    
    }

    public Seleccion(Integer iid, String nombre, Double valor, String condicion, Variable variable, Boolean seleccionada) {
        this.iid = iid;
        this.nombre = nombre;
        this.valor = valor;
        this.condicion = condicion;
        this.variable = variable;
        this.seleccionada = seleccionada;
    }

    public String getCondicion() {
        return condicion;
    }

    public void setCondicion(String condicion) {
        this.condicion = condicion;
    }

    public Integer getIid() {
        return iid;
    }

    public void setIid(Integer iid) {
        this.iid = iid;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Double getValor() {
        return valor;
    }

    public void setValor(Double valor) {
        this.valor = valor;
    }

    public Variable getVariable() {
        return variable;
    }

    public void setVariable(Variable variable) {
        this.variable = variable;
    }

    public Boolean getSeleccionada() {
        return seleccionada;
    }

    public void setSeleccionada(Boolean seleccionada) {
        this.seleccionada = seleccionada;
    }

    public Seleccion clonar() {
        return new Seleccion(this.iid, this.nombre, this.valor, this.condicion, this.variable, this.seleccionada);
    }
}
