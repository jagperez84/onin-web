package bean;

public class InterlocutorFamiliaVenta {

    private Integer iid;
    private Interlocutor interlocutor;
    private FamiliaVenta familiaVenta;
    private String formula;
    private Long   fecha;
    

    public InterlocutorFamiliaVenta() {
    
    }

    public FamiliaVenta getFamiliaVenta() {
        return familiaVenta;
    }

    public void setFamiliaVenta(FamiliaVenta familiaVenta) {
        this.familiaVenta = familiaVenta;
    }

    public String getFormula() {
        return formula;
    }

    public void setFormula(String formula) {
        this.formula = formula;
    }

    public Integer getIid() {
        return iid;
    }

    public void setIid(Integer iid) {
        this.iid = iid;
    }

    public Interlocutor getInterlocutor() {
        return interlocutor;
    }

    public void setInterlocutor(Interlocutor interlocutor) {
        this.interlocutor = interlocutor;
    }

    public Long getFecha() {
        return fecha;
    }

    public void setFecha(Long fecha) {
        this.fecha = fecha;
    }
    
    
}
