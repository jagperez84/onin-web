package bean;

public class Colores {
    private Integer iid;
    private String cod_color;
    private String descripcion;
    private Integer ral;

    public Colores() {
    }

    public String getCod_color() {
        return cod_color;
    }

    public void setCod_color(String cod_color) {
        this.cod_color = cod_color;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public Integer getIid() {
        return iid;
    }

    public void setIid(Integer iid) {
        this.iid = iid;
    }

     public Integer getRal() {
        return ral;
    }

    public void setRal(Integer ral) {
        this.ral = ral;
    }
    
    @Override
    public boolean equals (Object o){
        Colores c = (Colores) o;
        return this.getIid().equals(c.getIid());
    }

    
}
