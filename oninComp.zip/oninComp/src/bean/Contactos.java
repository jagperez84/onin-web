package bean;

public class Contactos {
    
    private Integer iid;
    private Agentes iid_agente;
    private String nombre;
    private String apellidos;
    private String cargo;
    private String departamento;
    private String telefono;
    private String movil;
    private String email;
    private String comentario;
  

    public Contactos() {
    }

    public String getNombre() {
        return nombre;
    }

    

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getCargo() {
        return cargo;
    }

    public void setCargo(String cargo) {
        this.cargo = cargo;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getDepartamento() {
        return departamento;
    }

    public void setDepartamento(String departamento) {
        this.departamento = departamento;
    }

    public Integer getIid() {
        return iid;
    }

    public void setIid(Integer iid) {
        this.iid = iid;
    }

    public String getComentarios() {
        return comentario;
    }

    public void setComentarios(String comentario) {
        this.comentario = comentario;
    }


    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getMovil() {
        return movil;
    }

    public void setMovil(String movil) {
        this.movil = movil;
    }

    public String getComentario() {
        return comentario;
    }

    public void setComentario(String comentario) {
        this.comentario = comentario;
    }

    public Agentes getIid_agente() {
        return iid_agente;
    }

    public void setIid_agente(Agentes iid_agente) {
        this.iid_agente = iid_agente;
    }
    
    @Override
    public boolean equals (Object o){
        Contactos c = (Contactos) o;
        
        String cadena1 = nombre + apellidos;
        String cadena2 = c.getNombre() + c.getApellidos();
        
        String cadena1SinBlancos = "";
        String cadena2SinBlancos = "";
        
        int x;
        for (x=0; x < cadena1.length(); x++) {
            if (cadena1.charAt(x) != ' ') {
                cadena1SinBlancos += cadena1.charAt(x);
            }
        }
        
        for (x=0; x < cadena2.length(); x++) {
            if (cadena2.charAt(x) != ' ') {
                cadena2SinBlancos += cadena2.charAt(x);
            }
        }

        return cadena1SinBlancos.equals(cadena2SinBlancos);
    }

    

}
