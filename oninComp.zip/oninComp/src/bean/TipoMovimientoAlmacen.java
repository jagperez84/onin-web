
package bean;

public class TipoMovimientoAlmacen {
    private Integer iid;
    private String nombre;
    private String descripcion;
    private ClaseInventario claseInventario;
    private TipoInventario tipoInventario;

    public TipoMovimientoAlmacen() {
    }

    public Integer getIid() {
        return iid;
    }

    public void setIid(Integer iid) {
        this.iid = iid;
    }

    public ClaseInventario getClaseInventario() {
        return claseInventario;
    }

    public void setClaseInventario(ClaseInventario claseInventario) {
        this.claseInventario = claseInventario;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public TipoInventario getTipoInventario() {
        return tipoInventario;
    }

    public void setTipoInventario(TipoInventario tipoInventario) {
        this.tipoInventario = tipoInventario;
    }

}
