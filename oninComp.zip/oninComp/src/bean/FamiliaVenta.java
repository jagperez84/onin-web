package bean;

public class FamiliaVenta {
    
    private Integer iid;
    private Empresa iid_empresa;
    private String cod_familia;
    private String nombre;
    private TipoProducto iid_tipo_producto;
    private TipoControl iid_tipo_control;
    private String tipoMontaje;
    private Boolean recortable;
    private Boolean confeccionable;
    private Float restoMinimo;
    
    public FamiliaVenta(){
        
    }

    public String getCod_familia() {
        return cod_familia;
    }

    public void setCod_familia(String cod_familia) {
        this.cod_familia = cod_familia;
    }

    public Integer getIid() {
        return iid;
    }

    public void setIid(Integer iid) {
        this.iid = iid;
    }

    public Empresa getIid_empresa() {
        return iid_empresa;
    }

    public void setIid_empresa(Empresa iid_empresa) {
        this.iid_empresa = iid_empresa;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public TipoControl getIid_tipo_control() {
        return iid_tipo_control;
    }

    public void setIid_tipo_control(TipoControl iid_tipo_control) {
        this.iid_tipo_control = iid_tipo_control;
    }

    public TipoProducto getIid_tipo_producto() {
        return iid_tipo_producto;
    }

    public void setIid_tipo_producto(TipoProducto iid_tipo_producto) {
        this.iid_tipo_producto = iid_tipo_producto;
    }

    public String getTipoMontaje() {
        return tipoMontaje;
    }

    public void setTipoMontaje(String tipoMontaje) {
        this.tipoMontaje = tipoMontaje;
    }

    public Boolean getConfeccionable() {
        return confeccionable;
    }

    public void setConfeccionable(Boolean confeccionable) {
        this.confeccionable = confeccionable;
    }

    public Float getRestoMinimo() {
        return restoMinimo;
    }

    public void setRestoMinimo(Float restoMinimo) {
        this.restoMinimo = restoMinimo;
    }

    public Boolean getRecortable() {
        return recortable;
    }

    public void setRecortable(Boolean recortable) {
        this.recortable = recortable;
    }
}
