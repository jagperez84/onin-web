package bean;

public class EstadoDocumento {
    
    private Integer iid;
    private TipoDocumento iid_tipo_documento;
    private String codigo;
    private String descripcion;
    
    
    public EstadoDocumento(){
        
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public TipoDocumento getIid_tipo_documento() {
        return iid_tipo_documento;
    }

    public void setIid_tipo_documento(TipoDocumento iid_tipo_documento) {
        this.iid_tipo_documento = iid_tipo_documento;
    }

    public Integer getIid() {
        return iid;
    }

    public void setIid(Integer iid) {
        this.iid = iid;
    }

    

}
