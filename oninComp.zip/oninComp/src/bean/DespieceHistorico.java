package bean;

import acceso.BaseDatos;

public class DespieceHistorico {
    private Integer iid;
    private DacHistorico dacHistorico;
    private Articulo articulo;
    private String tipoArticulo;
    private String formulaCantidad, formulaMedida1, formulaMedida2, formulaMedida3, formulaMedida4, formulaMedida5;
    private Colores color;
    private Integer orden;
    private String redondeo;
    private Boolean articuloBase;
    private Boolean anadirPvp;
    private Boolean anadirIncremento;
    private Caracteristica caracteristica;
    private Float precio;
    private Float coste;
    private String manual;
    
    public DespieceHistorico (DespieceHistorico d){
        this.iid = d.getIid();
        this.dacHistorico = d.getDacHistorico();
        this.articulo = d.getArticulo();
        this.tipoArticulo = d.getTipoArticulo();
        this.formulaCantidad = d.getFormulaCantidad();
        this.formulaMedida1 = d.getFormulaMedida1();
        this.formulaMedida2 = d.getFormulaMedida2();
        this.formulaMedida3 = d.getFormulaMedida3();
        this.formulaMedida4 = d.getFormulaMedida4();
        this.formulaMedida5 = d.getFormulaMedida5();
        this.anadirIncremento = d.getAnadirIncremento();
        this.anadirPvp = d.getAnadirPvp();
        this.articuloBase = d.getArticuloBase();
        this.color = d.getColor();
        this.orden = d.getOrden();
        this.redondeo = d.getRedondeo();
        this.caracteristica = d.getCaracteristica();
        if (d.getPrecio()!= null) this.precio = d.getPrecio();
        this.setManual(d.getManual());
    }
    
    public DespieceHistorico (DespiecePresupuesto d){
        this.articulo = d.getArticulo();
        this.tipoArticulo = d.getTipoArticulo();
        this.formulaCantidad = d.getFormulaCantidad();
        this.formulaMedida1 = d.getFormulaMedida1();
        this.formulaMedida2 = d.getFormulaMedida2();
        this.formulaMedida3 = d.getFormulaMedida3();
        this.formulaMedida4 = d.getFormulaMedida4();
        this.formulaMedida5 = d.getFormulaMedida5();
        this.anadirIncremento = d.getAnadirIncremento();
        this.anadirPvp = d.getAnadirPvp();
        this.articuloBase = d.getArticuloBase();
        this.color = d.getColor();
        this.orden = d.getOrden();
        this.redondeo = d.getRedondeo();
        this.caracteristica = d.getCaracteristica();
        this.manual = d.getManual();
    }


    
    public String toString(){
        String res = "";
        res += "[" + articulo.getCod_articulo() + " - " + tipoArticulo + "]";
        return res;
    }
    
    public DespieceHistorico (){
        
    }
    
    public Articulo getArticulo() {
        return articulo;
    }

    public void setArticulo(Articulo articulo) {
        this.articulo = articulo;
    }

    public Caracteristica getCaracteristica() {
        return caracteristica;
    }

    public void setCaracteristica(Caracteristica caracteristica) {
        this.caracteristica = caracteristica;
    }
    
    public String getFormulaCantidad() {
        return formulaCantidad;
    }

    public void setFormulaCantidad(String formulaCantidad) {
        this.formulaCantidad = formulaCantidad;
    }

    public String getFormulaMedida1() {
        return formulaMedida1;
    }

    public void setFormulaMedida1(String formulaMedida1) {
        this.formulaMedida1 = formulaMedida1;
    }

    public String getFormulaMedida2() {
        return formulaMedida2;
    }

    public void setFormulaMedida2(String formulaMedida2) {
        this.formulaMedida2 = formulaMedida2;
    }

    public String getFormulaMedida3() {
        return formulaMedida3;
    }

    public void setFormulaMedida3(String formulaMedida3) {
        this.formulaMedida3 = formulaMedida3;
    }

    public String getFormulaMedida4() {
        return formulaMedida4;
    }

    public void setFormulaMedida4(String formulaMedida4) {
        this.formulaMedida4 = formulaMedida4;
    }

    public String getFormulaMedida5() {
        return formulaMedida5;
    }

    public void setFormulaMedida5(String formulaMedida5) {
        this.formulaMedida5 = formulaMedida5;
    }

    public Integer getIid() {
        return iid;
    }

    public void setIid(Integer iid) {
        this.iid = iid;
    }

    public String getTipoArticulo() {
        return tipoArticulo;
    }

    public void setTipoArticulo(String tipoArticulo) {
        this.tipoArticulo = tipoArticulo;
    }
    
    public Colores getColor() {
        return color;
    }

    public void setColor(Colores color) {
        this.color = color;
    }

    public Integer getOrden() {
        return orden;
    }

    public void setOrden(Integer orden) {
        this.orden = orden;
    }
    
    public Boolean getAnadirIncremento() {
        return anadirIncremento;
    }

    public void setAnadirIncremento(Boolean anadirIncremento) {
        this.anadirIncremento = anadirIncremento;
    }

    public Boolean getAnadirPvp() {
        return anadirPvp;
    }

    public void setAnadirPvp(Boolean anadirPvp) {
        this.anadirPvp = anadirPvp;
    }

    public Boolean getArticuloBase() {
        return articuloBase;
    }

    public void setArticuloBase(Boolean articuloBase) {
        this.articuloBase = articuloBase;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final DespieceHistorico other = (DespieceHistorico) obj;
        if (this.tipoArticulo != other.tipoArticulo && (this.tipoArticulo == null || !this.tipoArticulo.equals(other.tipoArticulo))) {
            return false;
        }
        return true;
    }

    public String getRedondeo() {
        return redondeo;
    }

    public void setRedondeo(String redondeo) {
        this.redondeo = redondeo;
    }
    
    public int getNumeroDimensiones() {
        int numMedidas = 5;
        
        if(articulo != null){
            if(articulo.getIid() != null){
                articulo = BaseDatos.obtenerArticuloPorIid(articulo.getIid());
            }
            FamiliaVenta fv = articulo.getIid_fam_venta();
            fv = BaseDatos.obtenerFamiliaVenta(fv.getCod_familia(), articulo.getIid_empresa().getIid());

            if(fv != null){
                TipoControl tc = fv.getIid_tipo_control();
                tc = BaseDatos.obtenerTipoControl(tc.getCodigo());

                if(tc != null){
                    TipoMedida tm = tc.getIid_tipo_medida();
                    tm = BaseDatos.obtenerTipoMedidaByIid(tm.getIid());  
                    numMedidas = tm.getNum_dimensiones();
                }
            }
        }
        
        return numMedidas;
    }

    public DacHistorico getDacHistorico() {
        return dacHistorico;
    }

    public void setDacHistorico(DacHistorico dacHistorico) {
        this.dacHistorico = dacHistorico;
    }
    
    public Despiece clonar(){
        Despiece d = new Despiece();
        d.setArticulo(articulo);
        d.setColor(color);
        
        DacHistorico dp = BaseDatos.obtenerDacHistoricoById(dacHistorico.getIid());
        Dac dac = BaseDatos.obtenerDacById(dp.getDac().getIid());

        d.setDac(dac);
        d.setFormulaCantidad(formulaCantidad);
        d.setFormulaMedida1(formulaMedida1);
        d.setFormulaMedida2(formulaMedida2);
        d.setFormulaMedida3(formulaMedida3);
        d.setFormulaMedida4(formulaMedida4);
        d.setFormulaMedida5(formulaMedida5);
        d.setAnadirIncremento(anadirIncremento);
        d.setAnadirPvp(anadirPvp);
        d.setArticuloBase(articuloBase);
        d.setOrden(orden);
        d.setRedondeo(redondeo);
        d.setTipoArticulo(tipoArticulo);
        d.setCaracteristica(caracteristica);
        d.setManual(manual);
        return d;
    }
    
    public DespieceHistorico copiar(){
        DespieceHistorico res = new DespieceHistorico();
        res.setAnadirIncremento(anadirIncremento);
        res.setAnadirPvp(anadirPvp);
        res.setArticulo(articulo);
        res.setArticuloBase(articuloBase);
        res.setCaracteristica(caracteristica);
        res.setColor(color);
        res.setDacHistorico(dacHistorico);
        res.setFormulaCantidad(formulaCantidad);
        res.setFormulaMedida1(formulaMedida1);
        res.setFormulaMedida2(formulaMedida2);
        res.setFormulaMedida3(formulaMedida3);
        res.setFormulaMedida4(formulaMedida4);
        res.setFormulaMedida5(formulaMedida5);
        res.setOrden(orden);
        res.setRedondeo(redondeo);
        res.setTipoArticulo(tipoArticulo);
        res.setManual(manual);
        return res;
    }

    public Float getPrecio() {
        return precio;
    }

    public void setPrecio(Float precio) {
        this.precio = precio;
    }

    public Float getCoste() {
        return coste;
    }

    public void setCoste(Float coste) {
        this.coste = coste;
    }
    
        public String getManual() {
        return manual;
    }

    public void setManual(String manual) {
        this.manual = manual;
    }
    
      
}
