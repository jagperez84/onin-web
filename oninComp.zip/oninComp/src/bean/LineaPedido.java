package bean;

public class LineaPedido {
    private Integer iid;
    private Integer codigo;
    private Double precio;
    private Articulo articulo;
    private Caracteristica caracteristica;
    private Integer nummedidas;
    private Pedido pedido;
    private Double cantidad;
    private Double medida1;
    private Double medida2;
    private Double medida3;
    private Double medida4;
    private Double medida5;
    private Double descuento;
    private Double medidares;
    private Double importeReal;
  
    public LineaPedido() {
    
    }

    public Articulo getArticulo() {
        return articulo;
    }

    public void setArticulo(Articulo articulo) {
        this.articulo = articulo;
    }

    public Double getCantidad() {
        return cantidad;
    }

    public void setCantidad(Double cantidad) {
        this.cantidad = cantidad;
    }

    public Integer getCodigo() {
        return codigo;
    }

    public void setCodigo(Integer codigo) {
        this.codigo = codigo;
    }

    public Double getDescuento() {
        return descuento;
    }

    public void setDescuento(Double descuento) {
        this.descuento = descuento;
    }
    
    public Caracteristica getCaracteristica() {
        return caracteristica;
    }

    public void setCaracteristica(Caracteristica caracteristica) {
        this.caracteristica = caracteristica;
    }

    public Integer getIid() {
        return iid;
    }

    public void setIid(Integer iid) {
        this.iid = iid;
    }

    public Double getMedida1() {
        return medida1;
    }

    public void setMedida1(Double medida1) {
        this.medida1 = medida1;
    }

    public Double getMedida2() {
        return medida2;
    }

    public void setMedida2(Double medida2) {
        this.medida2 = medida2;
    }

    public Double getMedida3() {
        return medida3;
    }

    public void setMedida3(Double medida3) {
        this.medida3 = medida3;
    }

    public Double getMedida4() {
        return medida4;
    }

    public void setMedida4(Double medida4) {
        this.medida4 = medida4;
    }

    public Double getMedida5() {
        return medida5;
    }

    public void setMedida5(Double medida5) {
        this.medida5 = medida5;
    }

    public Double getMedidares() {
        return medidares;
    }

    public void setMedidares(Double medidares) {
        this.medidares = medidares;
    }

    public Integer getNummedidas() {
        return nummedidas;
    }

    public void setNummedidas(Integer nummedidas) {
        this.nummedidas = nummedidas;
    }

    public Pedido getPedido() {
        return pedido;
    }

    public void setPedido(Pedido pedido) {
        this.pedido = pedido;
    }

    public Double getPrecio() {
        return precio;
    }

    public void setPrecio(Double precio) {
        this.precio = precio;
    }

    public Double getImporteReal() {
        return importeReal;
    }

    public void setImporteReal(Double importeReal) {
        this.importeReal = importeReal;
    }
    
    

    public LineaPedido copiar(Pedido p){
        LineaPedido res = new LineaPedido();
        res.setArticulo(this.getArticulo());
        res.setCodigo(this.getCodigo());
        res.setCantidad(this.getCantidad());
        res.setDescuento(this.getDescuento());
        res.setMedida1(this.getMedida1());
        res.setMedida2(this.getMedida2());
        res.setMedida3(this.getMedida3());
        res.setMedida4(this.getMedida4());
        res.setMedida5(this.getMedida5());
        res.setMedidares(this.getMedidares());
        res.setNummedidas(this.getNummedidas());
        res.setPrecio(this.getPrecio());
        res.setImporteReal(this.getImporteReal());
        res.setPedido(p);
        return res;
    }
}
