package bean;

public class Variable {
    private Integer iid;
    private String nombre;
    private String tipo;
    private Double valor;
    private String condicion;
    private Boolean activarPeticion;
    private Double valorMinimo;
    private Double valorMaximo;
    private Boolean activarMinimo;
    private Boolean activarMaximo;
    private String formula;
    private Boolean editarResultadoFormula;
    private TipoToldo tipoToldo;
    private Dac dac;
    
    public Variable(){
    }

    public Boolean getActivarMaximo() {
        return activarMaximo;
    }

    public void setActivarMaximo(Boolean activarMaximo) {
        this.activarMaximo = activarMaximo;
    }

    public Boolean getActivarMinimo() {
        return activarMinimo;
    }

    public void setActivarMinimo(Boolean activarMinimo) {
        this.activarMinimo = activarMinimo;
    }

    public Boolean getActivarPeticion() {
        return activarPeticion;
    }

    public void setActivarPeticion(Boolean activarPeticion) {
        this.activarPeticion = activarPeticion;
    }

    public String getCondicion() {
        return condicion;
    }

    public void setCondicion(String condicion) {
        this.condicion = condicion;
    }

    public Boolean getEditarResultadoFormula() {
        return editarResultadoFormula;
    }

    public void setEditarResultadoFormula(Boolean editarResultadoFormula) {
        this.editarResultadoFormula = editarResultadoFormula;
    }

    public String getFormula() {
        return formula;
    }

    public void setFormula(String formula) {
        this.formula = formula;
    }

    public Integer getIid() {
        return iid;
    }

    public void setIid(Integer iid) {
        this.iid = iid;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public TipoToldo getTipoToldo() {
        return tipoToldo;
    }

    public void setTipoToldo(TipoToldo tipoToldo) {
        this.tipoToldo = tipoToldo;
    }

    public Double getValor() {
        return valor;
    }

    public void setValor(Double valor) {
        this.valor = valor;
    }

    public Double getValorMinimo() {
        return valorMinimo;
    }

    public void setValorMinimo(Double valorMinimo) {
        this.valorMinimo = valorMinimo;
    }

    public Double getValorMaximo() {
        return valorMaximo;
    }

    public void setValorMaximo(Double valorMaximo) {
        this.valorMaximo = valorMaximo;
    }

    public Dac getDac() {
        return dac;
    }

    public void setDac(Dac dac) {
        this.dac = dac;
    }
    
    public boolean equals(Object o){
        boolean res = false;
        Variable v = (Variable)o;
        return nombre.equalsIgnoreCase(v.getNombre());
    }
    
    public Variable clonar(){
        Variable res = new Variable();
        res.setActivarMaximo(activarMaximo);
        res.setActivarMinimo(activarMinimo);
        res.setActivarPeticion(activarPeticion);
        res.setCondicion(condicion);
        res.setEditarResultadoFormula(editarResultadoFormula);
        res.setFormula(formula);
        res.setIid(iid);
        res.setNombre(nombre);
        res.setTipo(tipo);
        res.setTipoToldo(tipoToldo);
        res.setValor(valor);
        res.setValorMaximo(valorMaximo);
        res.setValorMinimo(valorMinimo);
        return res;
    }
}
