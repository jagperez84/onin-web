package bean;

import java.util.Set;

public class TipoMontaje {

    private int iid;
    private Empresa iidEmpresa;
    private String descripcion;

    public int getIid() {
        return iid;
    }

    public void setIid(int iid) {
        this.iid = iid;
    }

   
    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public Empresa getIidEmpresa() {
        return iidEmpresa;
    }

    public void setIidEmpresa(Empresa iidEmpresa) {
        this.iidEmpresa = iidEmpresa;
    }
    
    

}
