package bean;

import acceso.BaseDatos;

public class DescuentoClienteArticulo {
    private Integer iid;
    private Agentes cliente;
    private Articulo articulo;
    private Double descuento;

    public Agentes getCliente() {
        return cliente;
    }

    public void setCliente(Agentes agente) {
        this.cliente = agente;
    }

    public Articulo getArticulo() {
        return articulo;
    }

    public void setArticulo(Articulo ar) {
        this.articulo = ar;
    }

    public Integer getIid() {
        return iid;
    }

    public void setIid(Integer iid) {
        this.iid = iid;
    }

    public Double getDescuento() {
        return descuento;
    }

    public void setDescuento(Double descuento) {
        this.descuento = descuento;
    }
    
    public DescuentoClienteArticulo copiar(){
        DescuentoClienteArticulo res;
        res = new DescuentoClienteArticulo();
        
        if(this.iid != null){
            res.setIid(new Integer(this.iid));
        } else {
            res.setIid(null);
        }
        
        if(this.descuento != null){
            res.setDescuento(new Double (this.descuento));
        } else {
            res.setDescuento(null);
        }
        
        if(this.articulo != null){
            res.setArticulo(BaseDatos.obtenerArticuloPorIid(this.articulo.getIid()));
        } else {
            res.setArticulo(null);
        }

        return res;
    }
    
}
