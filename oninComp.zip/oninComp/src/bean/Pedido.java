package bean;

public class Pedido {
    private Integer iid;
    private String numero;
    private String fecha;
    private Agentes proveedor;
    private FormaPago2 fp;
    private double dto;
    private double importe_total;
    private Empresa empresa;
    private Iva iva;

    public Pedido() {
    
    }

    public double getDto() {
        return dto;
    }

    public void setDto(double dto) {
        this.dto = dto;
    }

    public Empresa getEmpresa() {
        return empresa;
    }

    public void setEmpresa(Empresa empresa) {
        this.empresa = empresa;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public FormaPago2 getFp() {
        return fp;
    }

    public void setFp(FormaPago2 fp) {
        this.fp = fp;
    }

    public Integer getIid() {
        return iid;
    }

    public void setIid(Integer iid) {
        this.iid = iid;
    }

    public double getImporte_total() {
        return importe_total;
    }

    public void setImporte_total(double importe_total) {
        this.importe_total = importe_total;
    }

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public Agentes getProveedor() {
        return proveedor;
    }

    public void setProveedor(Agentes proveedor) {
        this.proveedor = proveedor;
    }

    public Iva getIva() {
        return iva;
    }

    public void setIva(Iva iva) {
        this.iva = iva;
    }
}
