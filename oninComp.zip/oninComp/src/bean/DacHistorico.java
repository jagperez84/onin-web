package bean;

public class DacHistorico {
    private Integer iid;
    private PresupuestoHistorico historico;
    private Articulo articulo;
    private Colores clacado;
    private Colores caccesorios;
    private Double medida1;
    private Double medida2;
    private Double medida3;
    private Double medida4;
    private Double medida5;
    private Double cantidad;
    private Dac dac;
    private Integer codigo;
    
    public DacHistorico(){
    }

    public DacHistorico copiar() {
        DacHistorico res = new DacHistorico();
        res.setArticulo(articulo);
        res.setCaccesorios(caccesorios);
        res.setCantidad(cantidad);
        res.setClacado(clacado);
        res.setCodigo(codigo);
        res.setDac(dac);
        res.setMedida1(medida1);
        res.setMedida2(medida2);
        res.setMedida3(medida3);
        res.setMedida4(medida4);
        res.setMedida5(medida5);
        res.setHistorico(historico);
        return res;
    }
    
    public DacHistorico (DacPresupuesto dp){
        this.articulo = dp.getArticulo();
        this.caccesorios = dp.getCaccesorios();
        this.cantidad = dp.getCantidad();
        this.clacado = dp.getClacado();
        this.codigo = dp.getCodigo();
        this.dac = dp.getDac();
        this.medida1 = dp.getMedida1();
        this.medida2 = dp.getMedida2();
        this.medida3 = dp.getMedida3();
        this.medida4 = dp.getMedida4();
        this.medida5 = dp.getMedida5();
    }

    public Integer getIid() {
        return iid;
    }

    public void setIid(Integer iid) {
        this.iid = iid;
    }

    public Articulo getArticulo() {
        return articulo;
    }

    public void setArticulo(Articulo articulo) {
        this.articulo = articulo;
    }

    public Colores getCaccesorios() {
        return caccesorios;
    }

    public void setCaccesorios(Colores caccesorios) {
        this.caccesorios = caccesorios;
    }

    public Colores getClacado() {
        return clacado;
    }

    public void setClacado(Colores clacado) {
        this.clacado = clacado;
    }

    public Double getMedida1() {
        return medida1;
    }

    public void setMedida1(Double medida1) {
        this.medida1 = medida1;
    }

    public Double getMedida2() {
        return medida2;
    }

    public void setMedida2(Double medida2) {
        this.medida2 = medida2;
    }

    public Double getMedida3() {
        return medida3;
    }

    public void setMedida3(Double medida3) {
        this.medida3 = medida3;
    }

    public Double getMedida4() {
        return medida4;
    }

    public void setMedida4(Double medida4) {
        this.medida4 = medida4;
    }

    public Double getMedida5() {
        return medida5;
    }

    public void setMedida5(Double medida5) {
        this.medida5 = medida5;
    }

    public Double getCantidad() {
        return cantidad;
    }

    public void setCantidad(Double cantidad) {
        this.cantidad = cantidad;
    }

    public PresupuestoHistorico getHistorico() {
        return historico;
    }

    public void setHistorico(PresupuestoHistorico historico) {
        this.historico = historico;
    }

    public Dac getDac() {
        return dac;
    }

    public void setDac(Dac dac) {
        this.dac = dac;
    }

    public Integer getCodigo() {
        return codigo;
    }

    public void setCodigo(Integer codigo) {
        this.codigo = codigo;
    }
    
    public Dac convertToDac(){
        Dac res = new Dac();
        res.setArticulo(articulo);
        res.setCaccesorios(caccesorios);
        res.setCantidad(cantidad);
        res.setClacado(clacado);
        res.setMedida1(medida1);
        res.setMedida2(medida2);
        res.setMedida2(medida3);
        res.setMedida2(medida4);
        res.setMedida2(medida5);
        return res;
    }
    
}
