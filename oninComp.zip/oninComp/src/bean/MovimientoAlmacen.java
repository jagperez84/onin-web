package bean;

import acceso.BaseDatos;

public class MovimientoAlmacen {
    
    private Integer iid;
    private Integer numero;
    private Long fecha;
    private TipoMovimientoAlmacen tipoMovimiento;
    private Articulo articulo;
    private Caracteristica caracteristica;
    private String concepto;
    private Almacen almacen;
    private Boolean iniciarMedidas;
    private Float cantidad1;
    private Float cantidad2;
    private Float cantidad3;
    private Float cantidad4;
    private Float cantidad5;
    private Float precio;
    private String valoracionPrecio;
    private Empresa empresa;
    private Float cantidad;
    private Boolean modificable;
    private Presupuesto presupuesto;
    private LineaCorteLona lineaCorteLona;
    private LineaCortePerfil lineaCortePerfil;
    private Integer lineaPresupuesto;
    private UnidadMedida unidadMedida1;
    private UnidadMedida unidadMedidaTotal;
    private Integer unidadMedida2;
    private Integer unidadMedida3;
    private Integer unidadMedida4;
    private Integer unidadMedida5;
    
    public MovimientoAlmacen(){
        
    }

    public Almacen getAlmacen() {
        return almacen;
    }

    public void setAlmacen(Almacen almacen) {
        this.almacen = almacen;
    }

    public Articulo getArticulo() {
        return articulo;
    }

    public void setArticulo(Articulo articulo) {
        this.articulo = articulo;
    }

    public Float getCantidad1() {
        return cantidad1;
    }

    public void setCantidad1(Float cantidad1) {
        this.cantidad1 = cantidad1;
    }

    public Float getCantidad2() {
        return cantidad2;
    }

    public void setCantidad2(Float cantidad2) {
        this.cantidad2 = cantidad2;
    }

    public Float getCantidad3() {
        return cantidad3;
    }

    public void setCantidad3(Float cantidad3) {
        this.cantidad3 = cantidad3;
    }

    public Float getCantidad4() {
        return cantidad4;
    }

    public void setCantidad4(Float cantidad4) {
        this.cantidad4 = cantidad4;
    }

    public Float getCantidad5() {
        return cantidad5;
    }

    public void setCantidad5(Float cantidad5) {
        this.cantidad5 = cantidad5;
    }

    public Caracteristica getCaracteristica() {
        return caracteristica;
    }

    public void setCaracteristica(Caracteristica caracteristica) {
        this.caracteristica = caracteristica;
    }

    public String getConcepto() {
        return concepto;
    }

    public void setConcepto(String concepto) {
        this.concepto = concepto;
    }

    public Empresa getEmpresa() {
        return empresa;
    }

    public void setEmpresa(Empresa empresa) {
        this.empresa = empresa;
    }

    public Long getFecha() {
        return fecha;
    }

    public void setFecha(Long fecha) {
        this.fecha = fecha;
    }

    public Integer getIid() {
        return iid;
    }

    public void setIid(Integer iid) {
        this.iid = iid;
    }

    public Boolean isIniciarMedidas() {
        return iniciarMedidas;
    }

    public void setIniciarMedidas(Boolean iniciarMedidas) {
        this.iniciarMedidas = iniciarMedidas;
    }

    public Float getPrecio() {
        return precio;
    }

    public void setPrecio(Float precio) {
        this.precio = precio;
    }

    public TipoMovimientoAlmacen getTipoMovimiento() {
        return tipoMovimiento;
    }

    public void setTipoMovimiento(TipoMovimientoAlmacen tipoMovimiento) {
        this.tipoMovimiento = tipoMovimiento;
    }

    public String getValoracionPrecio() {
        return valoracionPrecio;
    }

    public void setValoracionPrecio(String valoracionPrecio) {
        this.valoracionPrecio = valoracionPrecio;
    }

    public Integer getNumero() {
        return numero;
    }

    public void setNumero(Integer numero) {
        this.numero = numero;
    }

    public Float getCantidad() {
        return cantidad;
    }

    public void setCantidad(Float cantidad) {
        this.cantidad = cantidad;
    }

    public Boolean getModificable() {
        return modificable;
    }

    public void setModificable(Boolean modificable) {
        this.modificable = modificable;
    }

    public Presupuesto getPresupuesto() {
        return presupuesto;
    }

    public void setPresupuesto(Presupuesto presupuesto) {
        this.presupuesto = presupuesto;
    }

    public LineaCorteLona getLineaCorteLona() {
        return lineaCorteLona;
    }

    public void setLineaCorteLona(LineaCorteLona lineaCorteLona) {
        this.lineaCorteLona = lineaCorteLona;
    }
    
    public LineaCortePerfil getLineaCortePerfil() {
        return lineaCortePerfil;
    }

    public void setLineaCortePerfil(LineaCortePerfil lineaCortePerfil) {
        this.lineaCortePerfil = lineaCortePerfil;
    }
    
    public Integer getLineaPresupuesto() {
        return lineaPresupuesto;
    }

    public void setLineaPresupuesto(Integer lineaPresupuesto) {
        this.lineaPresupuesto = lineaPresupuesto;
    }

    public MovimientoAlmacen copiar(){
        MovimientoAlmacen mva =  new MovimientoAlmacen();
        mva.setAlmacen(almacen);
        mva.setArticulo(articulo);
        mva.setCantidad(cantidad);
        mva.setCantidad1(cantidad1);
        mva.setCantidad2(cantidad2);
        mva.setCantidad3(cantidad3);
        mva.setCantidad4(cantidad4);
        mva.setCantidad5(cantidad5);
        mva.setCaracteristica(caracteristica);
        mva.setConcepto(concepto);
        mva.setEmpresa(empresa);
        mva.setFecha(fecha);
        mva.setIniciarMedidas(iniciarMedidas);
        mva.setModificable(modificable);
        mva.setNumero(numero);
        mva.setPrecio(precio);
        mva.setTipoMovimiento(tipoMovimiento);
        mva.setValoracionPrecio(valoracionPrecio);
        mva.setPresupuesto(presupuesto);
        mva.setLineaCorteLona(lineaCorteLona);
        mva.setLineaCortePerfil(lineaCortePerfil);
        mva.setLineaPresupuesto(lineaPresupuesto);
        mva.setUnidadMedida1(unidadMedida1);
        mva.setUnidadMedida2(unidadMedida2);
        mva.setUnidadMedida3(unidadMedida3);
        mva.setUnidadMedida4(unidadMedida4);
        mva.setUnidadMedida5(unidadMedida5);
        mva.setUnidadMedidaTotal(unidadMedidaTotal);
        return mva;
    }

    @Override
    public boolean equals(Object o){
        boolean res = false;
        MovimientoAlmacen m = (MovimientoAlmacen)o;
        
        FamiliaVenta fv = BaseDatos.obtenerFamiliaVentaPorIid(m.getArticulo().getIid_fam_venta().getIid());
        TipoControl  tc = BaseDatos.obtenerTipoControlPorIid(fv.getIid_tipo_control().getIid());
        TipoMedida   tm = BaseDatos.obtenerTipoMedidaByIid(tc.getIid_tipo_medida().getIid());
        
        
        int numMedidas = tm.getNum_dimensiones();
        
        res =   this.fecha.equals(m.getFecha()) &&
                this.concepto.equals(m.getConcepto()) &&
                this.almacen.getIid().equals(m.getAlmacen().getIid()) &&
                this.tipoMovimiento.getIid().equals(m.getTipoMovimiento().getIid());
        
        if(m.getCaracteristica() != null && this.caracteristica != null){
            res = res & this.caracteristica.equals(m.getCaracteristica());
        }
        
        if(numMedidas == 1){
            res = res && this.getCantidad1().equals(m.getCantidad1());
        } else if(numMedidas == 2){
            res = res && this.getCantidad1().equals(m.getCantidad1()) &&
                         this.getCantidad2().equals(m.getCantidad2());
        } else if(numMedidas == 3){
            res = res && this.getCantidad1().equals(m.getCantidad1()) &&
                         this.getCantidad2().equals(m.getCantidad2()) &&
                         this.getCantidad3().equals(m.getCantidad3());
        } else if(numMedidas == 4){
            res = res && this.getCantidad1().equals(m.getCantidad1()) &&
                         this.getCantidad2().equals(m.getCantidad2()) &&
                         this.getCantidad3().equals(m.getCantidad3()) &&
                         this.getCantidad4().equals(m.getCantidad4()) ;
        } else if(numMedidas == 5){ 
            res = res && this.getCantidad1().equals(m.getCantidad1()) &&
                         this.getCantidad2().equals(m.getCantidad2()) &&
                         this.getCantidad3().equals(m.getCantidad3()) &&
                         this.getCantidad4().equals(m.getCantidad4()) &&
                         this.getCantidad5().equals(m.getCantidad5());
        }
        
        return res;
    }

    public UnidadMedida getUnidadMedida1() {
        return unidadMedida1;
    }

    public void setUnidadMedida1(UnidadMedida unidadMedida1) {
        this.unidadMedida1 = unidadMedida1;
    }

    public UnidadMedida getUnidadMedidaTotal() {
        return unidadMedidaTotal;
    }

    public void setUnidadMedidaTotal(UnidadMedida unidadMedidaTotal) {
        this.unidadMedidaTotal = unidadMedidaTotal;
    }

    public Integer getUnidadMedida2() {
        return unidadMedida2;
    }

    public void setUnidadMedida2(Integer unidadMedida2) {
        this.unidadMedida2 = unidadMedida2;
    }

    public Integer getUnidadMedida3() {
        return unidadMedida3;
    }

    public void setUnidadMedida3(Integer unidadMedida3) {
        this.unidadMedida3 = unidadMedida3;
    }

    public Integer getUnidadMedida4() {
        return unidadMedida4;
    }

    public void setUnidadMedida4(Integer unidadMedida4) {
        this.unidadMedida4 = unidadMedida4;
    }

    public Integer getUnidadMedida5() {
        return unidadMedida5;
    }

    public void setUnidadMedida5(Integer unidadMedida5) {
        this.unidadMedida5 = unidadMedida5;
    }
}
