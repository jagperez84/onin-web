package bean;

public class AgenteArticuloCodigo {

    private Integer iid;
    private Agentes iid_agente;
    private Articulo iid_articulo;
    private Integer iid_color;
    private String codigo;
    private Float precio;
    private Float descuento;
    private Boolean checkDto;
    private String tipoPrecio;
    private String descripcion;
    
    public AgenteArticuloCodigo(){
        
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public Integer getIid() {
        return iid;
    }

    public void setIid(Integer iid) {
        this.iid = iid;
    }

    public Agentes getIid_agente() {
        return iid_agente;
    }

    public void setIid_agente(Agentes iid_agente) {
        this.iid_agente = iid_agente;
    }

    public Articulo getIid_articulo() {
        return iid_articulo;
    }

    public void setIid_articulo(Articulo iid_articulo) {
        this.iid_articulo = iid_articulo;
    }

    public Float getDescuento() {
        return descuento;
    }

    public void setDescuento(Float descuento) {
        this.descuento = descuento;
    }

    public Float getPrecio() {
        return precio;
    }

    public void setPrecio(Float precio) {
        this.precio = precio;
    }

    public Boolean getCheckDto() {
        return checkDto;
    }

    public void setCheckDto(Boolean checkDto) {
        this.checkDto = checkDto;
    }

    public String getTipoPrecio() {
        return tipoPrecio;
    }

    public void setTipoPrecio(String tipoPrecio) {
        this.tipoPrecio = tipoPrecio;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public Integer getIid_color() {
        return iid_color;
    }

    public void setIid_color(Integer iid_color) {
        this.iid_color = iid_color;
    }

    
}
