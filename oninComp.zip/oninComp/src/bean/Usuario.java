package bean;

public class Usuario {
    private String nombre;
    private String contrasenha;
    private String departamento;
    //private Boolean administrador;
    private String tipo;
    private String email;
    private String pie;

    public Usuario() {
    }

    public String getContrasenha() {
        return contrasenha;
    }

    public void setContrasenha(String contrasenha) {
        this.contrasenha = contrasenha;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

      public String getDepartamento() {
        return departamento;
    }

    public void setDepartamento(String departamento) {
        this.departamento = departamento;
    }

//    public void setAdministrador(Boolean administrador) {
//        this.administrador = administrador;
//    }
//
//    public Boolean getAdministrador() {
//        return administrador;
//    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPie() {
        return pie;
    }

    public void setPie(String pie) {
        this.pie = pie;
    }
}
