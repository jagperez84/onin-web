package bean;

import acceso.BaseDatos;

public class Precios {

    private Integer  iid;
    private Empresa  iid_empresa;
    private Articulo iid_art;
    private Integer  iid_car;
    private Long     fecha;
    private Float    pvp;
    private Float    ptc;
    private Float    upc;
    private Float    pi;
    private String   accion;
    private String   usuario;

    public Precios() {
    }   

    public Integer getIid() {
        return iid;
    }

    public void setIid(Integer iid) {
        this.iid = iid;
    }

    public Empresa getIid_empresa() {
        return iid_empresa;
    }

    public void setIid_empresa(Empresa iid_empresa) {
        this.iid_empresa = iid_empresa;
    }

    public Articulo getIid_art() {
        return iid_art;
    }

    public void setIid_art(Articulo iid_art) {
        this.iid_art = iid_art;
    }

    public Integer getIid_car() {
        return iid_car;
    }

    public void setIid_car(Integer iid_car) {
        this.iid_car = iid_car;
    }

    public Long getFecha() {
        return fecha;
    }

    public void setFecha(Long fecha) {
        this.fecha = fecha;
    }

    public Float getPvp() {
        return pvp;
    }

    public void setPvp(Float pvp) {
        this.pvp = pvp;
    }

    public Float getPtc() {
        return ptc;
    }

    public void setPtc(Float ptc) {
        this.ptc = ptc;
    }

    public Float getUpc() {
        return upc;
    }

    public void setUpc(Float upc) {
        this.upc = upc;
    }

    public Float getPi() {
        return pi;
    }

    public void setPi(Float pi) {
        this.pi = pi;
    }

    public String getAccion() {
        return accion;
    }

    public void setAccion(String accion) {
        this.accion = accion;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }
    
    

   
}
