package bean;

public class MovimientoPresupuesto {
    
    private Integer iid;
    private Articulo articulo;
    private Caracteristica caracteristica;
    private Almacen almacen;
    private Presupuesto presupuesto;
    private Float medida1;
    private Float medida2;
    private Float medida3;
    private Float medida4;
    private Float medida5;
    private Existencia existencia;
    private Existencia existenciaResto;
    private LineaCorteLona lineaCorteLona;
    private Integer numRestos;
    private LineaCortePerfil lineaCortePerfil;
    private UnidadMedida unidadMedida1;
    private UnidadMedida unidadMedidaTotal;
    private Integer unidadMedida2;
    private Integer unidadMedida3;
    private Integer unidadMedida4;
    private Integer unidadMedida5;
    
    public MovimientoPresupuesto(){
        
    }

    public Almacen getAlmacen() {
        return almacen;
    }

    public void setAlmacen(Almacen almacen) {
        this.almacen = almacen;
    }

    public Articulo getArticulo() {
        return articulo;
    }

    public void setArticulo(Articulo articulo) {
        this.articulo = articulo;
    }

    public Caracteristica getCaracteristica() {
        return caracteristica;
    }

    public void setCaracteristica(Caracteristica caracteristica) {
        this.caracteristica = caracteristica;
    }

    public Integer getIid() {
        return iid;
    }

    public void setIid(Integer iid) {
        this.iid = iid;
    }

    public Float getMedida1() {
        return medida1;
    }

    public void setMedida1(Float medida1) {
        this.medida1 = medida1;
    }

    public Float getMedida2() {
        return medida2;
    }

    public void setMedida2(Float medida2) {
        this.medida2 = medida2;
    }

    public Float getMedida3() {
        return medida3;
    }

    public void setMedida3(Float medida3) {
        this.medida3 = medida3;
    }

    public Float getMedida4() {
        return medida4;
    }

    public void setMedida4(Float medida4) {
        this.medida4 = medida4;
    }

    public Presupuesto getPresupuesto() {
        return presupuesto;
    }

    public void setPresupuesto(Presupuesto presupuesto) {
        this.presupuesto = presupuesto;
    }

    public Float getMedida5() {
        return medida5;
    }

    public void setMedida5(Float medida5) {
        this.medida5 = medida5;
    }

    public Existencia getExistencia() {
        return existencia;
    }

    public void setExistencia(Existencia existencia) {
        this.existencia = existencia;
    }

    public Existencia getExistenciaResto() {
        return existenciaResto;
    }

    public void setExistenciaResto(Existencia existenciaResto) {
        this.existenciaResto = existenciaResto;
    }

    public LineaCorteLona getLineaCorteLona() {
        return lineaCorteLona;
    }

    public void setLineaCorteLona(LineaCorteLona lineaCorteLona) {
        this.lineaCorteLona = lineaCorteLona;
    }

    public Integer getNumRestos() {
        return numRestos;
    }

    public void setNumRestos(Integer numRestos) {
        this.numRestos = numRestos;
    }

    public LineaCortePerfil getLineaCortePerfil() {
        return lineaCortePerfil;
    }

    public void setLineaCortePerfil(LineaCortePerfil lineaCortePerfil) {
        this.lineaCortePerfil = lineaCortePerfil;
    }

    public UnidadMedida getUnidadMedida1() {
        return unidadMedida1;
    }

    public void setUnidadMedida1(UnidadMedida unidadMedida1) {
        this.unidadMedida1 = unidadMedida1;
    }

    public UnidadMedida getUnidadMedidaTotal() {
        return unidadMedidaTotal;
    }

    public void setUnidadMedidaTotal(UnidadMedida unidadMedidaTotal) {
        this.unidadMedidaTotal = unidadMedidaTotal;
    }

    public Integer getUnidadMedida2() {
        return unidadMedida2;
    }

    public void setUnidadMedida2(Integer unidadMedida2) {
        this.unidadMedida2 = unidadMedida2;
    }

    public Integer getUnidadMedida3() {
        return unidadMedida3;
    }

    public void setUnidadMedida3(Integer unidadMedida3) {
        this.unidadMedida3 = unidadMedida3;
    }

    public Integer getUnidadMedida4() {
        return unidadMedida4;
    }

    public void setUnidadMedida4(Integer unidadMedida4) {
        this.unidadMedida4 = unidadMedida4;
    }

    public Integer getUnidadMedida5() {
        return unidadMedida5;
    }

    public void setUnidadMedida5(Integer unidadMedida5) {
        this.unidadMedida5 = unidadMedida5;
    }
    
    
}
