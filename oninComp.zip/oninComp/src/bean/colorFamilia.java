package bean;

public class colorFamilia {
    private Integer iid;
    private Integer iidEmpresa;
    private Integer iidFamilia;
    private Integer iidColor;

    
    public colorFamilia(){
    }

    public Integer getIid() {
        return iid;
    }

    public void setIid(Integer iid) {
        this.iid = iid;
    }

    public Integer getIidEmpresa() {
        return iidEmpresa;
    }

    public void setIidEmpresa(Integer iidEmpresa) {
        this.iidEmpresa = iidEmpresa;
    }

    public Integer getIidFamilia() {
        return iidFamilia;
    }

    public void setIidFamilia(Integer iidFamilia) {
        this.iidFamilia = iidFamilia;
    }

    public Integer getIidColor() {
        return iidColor;
    }

    public void setIidColor(Integer iidColor) {
        this.iidColor = iidColor;
    }

    
    
   
}
