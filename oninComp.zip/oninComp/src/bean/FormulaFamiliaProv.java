package bean;

import acceso.BaseDatos;

public class FormulaFamiliaProv {
    
    private Integer iid;
    private Integer iidFamilia;
    private Integer iidProveedor;
    private Integer iidEmpresa;
    private String  formula;
    
    public Integer getIid() {
        return iid;
    }

    public void setIid(Integer iid) {
        this.iid = iid;
    }

    public Integer getIidFamilia() {
        return iidFamilia;
    }

    public void setIidFamilia(Integer iidFamilia) {
        this.iidFamilia = iidFamilia;
    }

    public Integer getIidProveedor() {
        return iidProveedor;
    }

    public void setIidProveedor(Integer iidProveedor) {
        this.iidProveedor = iidProveedor;
    }

    
    public Integer getIidEmpresa() {
        return iidEmpresa;
    }

    public void setIidEmpresa(Integer iidEmpresa) {
        this.iidEmpresa = iidEmpresa;
    }

    public String getFormula() {
        return formula;
    }

    public void setFormula(String formula) {
        this.formula = formula;
    }
 

}
