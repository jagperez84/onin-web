package bean;

public class Montaje {

    private int iid;
    private Empresa iidEmpresa;
    private Presupuesto iidPedido;
    private TipoMontaje iidTipo;
    private String hora;
    private String horaFin;
    private String duracionEst;
    private String duracionFin;
    private String observaciones;
    private String montador;
    private Long fechaEntrega;
    private String montado;

    public int getIid() {
        return iid;
    }

    public void setIid(int iid) {
        this.iid = iid;
    }

    public Empresa getIidEmpresa() {
        return iidEmpresa;
    }

    public void setIidEmpresa(Empresa iidEmpresa) {
        this.iidEmpresa = iidEmpresa;
    }

    public Presupuesto getIidPedido() {
        return iidPedido;
    }

    public void setIidPedido(Presupuesto iidPedido) {
        this.iidPedido = iidPedido;
    }

    public TipoMontaje getIidTipo() {
        return iidTipo;
    }

    public void setIidTipo(TipoMontaje iidTipo) {
        this.iidTipo = iidTipo;
    }

    public String getHora() {
        return hora;
    }

    public void setHora(String hora) {
        this.hora = hora;
    }

    public String getObservaciones() {
        return observaciones;
    }

    public void setObservaciones(String observaciones) {
        this.observaciones = observaciones;
    }

    public String getMontador() {
        return montador;
    }

    public void setMontador(String montador) {
        this.montador = montador;
    }

    public String getHoraFin() {
        return horaFin;
    }

    public void setHoraFin(String horaFin) {
        this.horaFin = horaFin;
    }

    public String getDuracionEst() {
        return duracionEst;
    }

    public void setDuracionEst(String duracionEst) {
        this.duracionEst = duracionEst;
    }

    public String getDuracionFin() {
        return duracionFin;
    }

    public void setDuracionFin(String duracionFin) {
        this.duracionFin = duracionFin;
    }

    public Long getFechaEntrega() {
        return fechaEntrega;
    }

    public void setFechaEntrega(Long fechaEntrega) {
        this.fechaEntrega = fechaEntrega;
    }

    public String getMontado() {
        return montado;
    }

    public void setMontado(String montado) {
        this.montado = montado;
    }
    
       
   }
