package bean;

import auxiliar.Objeto2Elementos;
import java.util.ArrayList;
import java.util.List;
import util.Util;

public class FormaPago2 {

    private Integer iid;
    private String codigo;
    private String descripcionidentificativa;
    private String descripcioncliente;
    private Double dtoprontopago = 0.0;
    private Integer numplazosadelantados = 0;
    private String tiporecibopago;
    private String nombreplazo1;
    private String nombreplazo2;
    private String nombreplazo3;
    private String nombreplazo4;
    private String nombreplazo5;
    private String nombreplazo6;
    private String nombreplazo7;
    private String nombreplazo8;
    private String nombreplazo9;
    private String nombreplazo10;
    private Double porcentajepago1 = 0.0;
    private Double porcentajepago2 = 0.0;
    private Double porcentajepago3 = 0.0;
    private Double porcentajepago4 = 0.0;
    private Double porcentajepago5 = 0.0;
    private Double porcentajepago6 = 0.0;
    private Double porcentajepago7 = 0.0;
    private Double porcentajepago8 = 0.0;
    private Double porcentajepago9 = 0.0;
    private Double porcentajepago10 = 0.0;
    private Integer numplazosvencimiento = 0;
    private String tiporecibovencimiento;
    private String tipodecalculo;
    private Double importeminimo = 0.0;
    private Integer diasprimerplazo = 0;
    private Integer diasentreplazos = 0;
    private Integer plazovm1 = 0;
    private Integer plazovm2 = 0;
    private Integer plazovm3 = 0;
    private Integer plazovm4 = 0;
    private Integer plazovm5 = 0;
    private Integer plazovm6 = 0;
    private Integer plazovm7 = 0;
    private Integer plazovm8 = 0;
    private Integer plazovm9 = 0;
    private Integer plazovm10 = 0;
    private Double plazopm1 = 0.0;
    private Double plazopm2 = 0.0;
    private Double plazopm3 = 0.0;
    private Double plazopm4 = 0.0;
    private Double plazopm5 = 0.0;
    private Double plazopm6 = 0.0;
    private Double plazopm7 = 0.0;
    private Double plazopm8 = 0.0;
    private Double plazopm9 = 0.0;
    private Double plazopm10 = 0.0;
    private Boolean calculovencimientoautomatico;
    private Boolean porcentajeautomatico;
    private TipoRecibo iid_tr_p1;
    private TipoRecibo iid_tr_p2;
    private TipoRecibo iid_tr_p3;
    private TipoRecibo iid_tr_p4;
    private TipoRecibo iid_tr_p5;
    private TipoRecibo iid_tr_p6;
    private TipoRecibo iid_tr_p7;
    private TipoRecibo iid_tr_p8;
    private TipoRecibo iid_tr_p9;
    private TipoRecibo iid_tr_p10;
    private TipoRecibo iid_tr_v1;
    private TipoRecibo iid_tr_v2;
    private TipoRecibo iid_tr_v3;
    private TipoRecibo iid_tr_v4;
    private TipoRecibo iid_tr_v5;
    private TipoRecibo iid_tr_v6;
    private TipoRecibo iid_tr_v7;
    private TipoRecibo iid_tr_v8;
    private TipoRecibo iid_tr_v9;
    private TipoRecibo iid_tr_v10;
    private String cobrado1;
    private String cobrado2;
    private String cobrado3;
    private String cobrado4;
    private String cobrado5;
    private String cobrado6;
    private String cobrado7;
    private String cobrado8;
    private String cobrado9;
    private String cobrado10;
    private Long fechap1;
    private Long fechap2;
    private Long fechap3;
    private Long fechap4;
    private Long fechap5;
    private Long fechap6;
    private Long fechap7;
    private Long fechap8;
    private Long fechap9;
    private Long fechap10;
    private Double importep1;
    private Double importep2;
    private Double importep3;
    private Double importep4;
    private Double importep5;
    private Double importep6;
    private Double importep7;
    private Double importep8;
    private Double importep9;
    private Double importep10;
    private Double importev1;
    private Double importev2;
    private Double importev3;
    private Double importev4;
    private Double importev5;
    private Double importev6;
    private Double importev7;
    private Double importev8;
    private Double importev9;
    private Double importev10;
    private String emitido1;
    private String emitido10;
    private String emitido2;
    private String emitido3;
    private String emitido4;
    private String emitido5;
    private String emitido6;
    private String emitido7;
    private String emitido8;
    private String emitido9;
    private String imputado1;
    private String recibo1;
    private String imputado2;
    private String recibo2;
    private String imputado3;
    private String recibo3;
    private String imputado4;
    private String recibo4;
    private String imputado5;
    private String recibo5;
    private String imputado6;
    private String recibo6;
    private String imputado7;
    private String recibo7;
    private String imputado8;
    private String recibo8;
    private String imputado9;
    private String recibo9;
    private String imputado10;
    private String recibo10;
    private String plazosStr;
    private String emitidoVencimiento1;
    private String emitidoVencimiento2;
    private String emitidoVencimiento3;
    private String emitidoVencimiento4;
    private String emitidoVencimiento5;
    private String emitidoVencimiento6;
    private String emitidoVencimiento7;
    private String emitidoVencimiento8;
    private String emitidoVencimiento9;
    private String emitidoVencimiento10;
    private String cobradoVencimiento1;
    private String cobradoVencimiento2;
    private String cobradoVencimiento3;
    private String cobradoVencimiento4;
    private String cobradoVencimiento5;
    private String cobradoVencimiento6;
    private String cobradoVencimiento7;
    private String cobradoVencimiento8;
    private String cobradoVencimiento9;
    private String cobradoVencimiento10;
    private String reciboVencimiento1;
    private String reciboVencimiento2;
    private String reciboVencimiento3;
    private String reciboVencimiento4;
    private String reciboVencimiento5;
    private String reciboVencimiento6;
    private String reciboVencimiento7;
    private String reciboVencimiento8;
    private String reciboVencimiento9;
    private String reciboVencimiento10;
    private String imputadoVencimiento1;
    private String imputadoVencimiento2;
    private String imputadoVencimiento3;
    private String imputadoVencimiento4;
    private String imputadoVencimiento5;
    private String imputadoVencimiento6;
    private String imputadoVencimiento7;
    private String imputadoVencimiento8;
    private String imputadoVencimiento9;
    private String imputadoVencimiento10;
    private Long fechaPlazo1;
    private Long fechaPlazo2;
    private Long fechaPlazo3;
    private Long fechaPlazo4;
    private Long fechaPlazo5;
    private Long fechaPlazo6;
    private Long fechaPlazo7;
    private Long fechaPlazo8;
    private Long fechaPlazo9;
    private Long fechaPlazo10;
    
    public List<Objeto2Elementos> getPlazos(){
        List<Objeto2Elementos> lres;
        lres = getPlazosAdelantados();
        lres.addAll(getPlazosVencimientos());
        return lres;
    }
    
    private List<Objeto2Elementos> getPlazosAdelantados(){
        
        List<Objeto2Elementos> lres = new ArrayList<Objeto2Elementos>();
        Objeto2Elementos o2e;
 
        if (numplazosadelantados == 1){
            o2e = new Objeto2Elementos(nombreplazo1.toString(),Util.convertirPuntoAComa(importep1.toString()));
            lres.add(o2e);
        } else if (numplazosadelantados == 2){
            o2e = new Objeto2Elementos(nombreplazo1.toString(),Util.convertirPuntoAComa(importep1.toString()));
            lres.add(o2e);
            o2e = new Objeto2Elementos(nombreplazo2.toString(),Util.convertirPuntoAComa(importep2.toString()));
            lres.add(o2e);
        } else if (numplazosadelantados == 3){
            o2e = new Objeto2Elementos(nombreplazo1.toString(),Util.convertirPuntoAComa(importep1.toString()));
            lres.add(o2e);
            o2e = new Objeto2Elementos(nombreplazo2.toString(),Util.convertirPuntoAComa(importep2.toString()));
            lres.add(o2e);
            o2e = new Objeto2Elementos(nombreplazo3.toString(),Util.convertirPuntoAComa(importep3.toString()));
            lres.add(o2e);
        } else if (numplazosadelantados == 4){
            o2e = new Objeto2Elementos(nombreplazo1.toString(),Util.convertirPuntoAComa(importep1.toString()));
            lres.add(o2e);
            o2e = new Objeto2Elementos(nombreplazo2.toString(),Util.convertirPuntoAComa(importep2.toString()));
            lres.add(o2e);
            o2e = new Objeto2Elementos(nombreplazo3.toString(),Util.convertirPuntoAComa(importep3.toString()));
            lres.add(o2e);
            o2e = new Objeto2Elementos(nombreplazo4.toString(),Util.convertirPuntoAComa(importep4.toString()));
            lres.add(o2e);
        } else if (numplazosadelantados == 5){
            o2e = new Objeto2Elementos(nombreplazo1.toString(),Util.convertirPuntoAComa(importep1.toString()));
            lres.add(o2e);
            o2e = new Objeto2Elementos(nombreplazo2.toString(),Util.convertirPuntoAComa(importep2.toString()));
            lres.add(o2e);
            o2e = new Objeto2Elementos(nombreplazo3.toString(),Util.convertirPuntoAComa(importep3.toString()));
            lres.add(o2e);
            o2e = new Objeto2Elementos(nombreplazo4.toString(),Util.convertirPuntoAComa(importep4.toString()));
            lres.add(o2e);
            o2e = new Objeto2Elementos(nombreplazo5.toString(),Util.convertirPuntoAComa(importep5.toString()));
            lres.add(o2e);
        }
        
        return lres;
    }
    
    private List<Objeto2Elementos> getPlazosVencimientos(){
        
        List<Objeto2Elementos> lres = new ArrayList<Objeto2Elementos>();
        Objeto2Elementos o2e;
        
        if (numplazosvencimiento == 1){
            o2e = new Objeto2Elementos(plazovm1.toString() + " Días",Util.convertirPuntoAComa(importev1.toString()));
            lres.add(o2e);
        } else if (numplazosvencimiento == 2){
            o2e = new Objeto2Elementos(plazovm1.toString() + " Días",Util.convertirPuntoAComa(importev1.toString()));
            lres.add(o2e);
            o2e = new Objeto2Elementos(plazovm2.toString() + " Días",Util.convertirPuntoAComa(importev2.toString()));
            lres.add(o2e);
        } else if (numplazosvencimiento == 3){
            o2e = new Objeto2Elementos(plazovm1.toString() + " Días",Util.convertirPuntoAComa(importev1.toString()));
            lres.add(o2e);
            o2e = new Objeto2Elementos(plazovm2.toString() + " Días",Util.convertirPuntoAComa(importev2.toString()));
            lres.add(o2e);
            o2e = new Objeto2Elementos(plazovm3.toString() + " Días",Util.convertirPuntoAComa(importev3.toString()));
            lres.add(o2e);
        } else if (numplazosvencimiento == 4){
            o2e = new Objeto2Elementos(plazovm1.toString() + " Días",Util.convertirPuntoAComa(importev1.toString()));
            lres.add(o2e);
            o2e = new Objeto2Elementos(plazovm2.toString() + " Días",Util.convertirPuntoAComa(importev2.toString()));
            lres.add(o2e);
            o2e = new Objeto2Elementos(plazovm3.toString() + " Días",Util.convertirPuntoAComa(importev3.toString()));
            lres.add(o2e);
            o2e = new Objeto2Elementos(plazovm4.toString() + " Días",Util.convertirPuntoAComa(importev4.toString()));
            lres.add(o2e);
        } else if(numplazosvencimiento == 5){
            o2e = new Objeto2Elementos(plazovm1.toString() + " Días",Util.convertirPuntoAComa(importev1.toString()));
            lres.add(o2e);
            o2e = new Objeto2Elementos(plazovm2.toString() + " Días",Util.convertirPuntoAComa(importev2.toString()));
            lres.add(o2e);
            o2e = new Objeto2Elementos(plazovm3.toString() + " Días",Util.convertirPuntoAComa(importev3.toString()));
            lres.add(o2e);
            o2e = new Objeto2Elementos(plazovm4.toString() + " Días",Util.convertirPuntoAComa(importev4.toString()));
            lres.add(o2e);
            o2e = new Objeto2Elementos(plazovm5.toString() + " Días",Util.convertirPuntoAComa(importev5.toString()));
            lres.add(o2e);
        }

        return lres;
    }
    
    public Double getPlazopm4() {
        return plazopm4;
    }

    public void setPlazopm4(Double Plazopm4) {
        this.plazopm4 = Plazopm4;
    }

    public Boolean getCalculovencimientoautomatico() {
        return calculovencimientoautomatico;
    }

    public void setCalculovencimientoautomatico(Boolean calculovencimientoautomatico) {
        this.calculovencimientoautomatico = calculovencimientoautomatico;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getDescripcioncliente() {
        return descripcioncliente;
    }

    public void setDescripcioncliente(String descripcioncliente) {
        this.descripcioncliente = descripcioncliente;
    }

    public String getDescripcionidentificativa() {
        return descripcionidentificativa;
    }

    public void setDescripcionidentificativa(String descripcionidentificativa) {
        this.descripcionidentificativa = descripcionidentificativa;
    }

    public Integer getDiasentreplazos() {
        return diasentreplazos;
    }

    public void setDiasentreplazos(Integer diasentreplazos) {
        this.diasentreplazos = diasentreplazos;
    }

    public Integer getDiasprimerplazo() {
        return diasprimerplazo;
    }

    public void setDiasprimerplazo(Integer diasprimerplazo) {
        this.diasprimerplazo = diasprimerplazo;
    }

    public Double getDtoprontopago() {
        return dtoprontopago;
    }

    public void setDtoprontopago(Double dtoprontopago) {
        this.dtoprontopago = dtoprontopago;
    }

    public Integer getIid() {
        return iid;
    }

    public void setIid(Integer iid) {
        this.iid = iid;
    }

    public Double getImporteminimo() {
        return importeminimo;
    }

    public void setImporteminimo(Double importeminimo) {
        this.importeminimo = importeminimo;
    }

    public String getNombreplazo1() {
        return nombreplazo1;
    }

    public void setNombreplazo1(String nombreplazo1) {
        this.nombreplazo1 = nombreplazo1;
    }

    public String getNombreplazo10() {
        return nombreplazo10;
    }

    public void setNombreplazo10(String nombreplazo10) {
        this.nombreplazo10 = nombreplazo10;
    }

    public String getNombreplazo2() {
        return nombreplazo2;
    }

    public void setNombreplazo2(String nombreplazo2) {
        this.nombreplazo2 = nombreplazo2;
    }

    public String getNombreplazo3() {
        return nombreplazo3;
    }

    public void setNombreplazo3(String nombreplazo3) {
        this.nombreplazo3 = nombreplazo3;
    }

    public String getNombreplazo4() {
        return nombreplazo4;
    }

    public void setNombreplazo4(String nombreplazo4) {
        this.nombreplazo4 = nombreplazo4;
    }

    public String getNombreplazo5() {
        return nombreplazo5;
    }

    public void setNombreplazo5(String nombreplazo5) {
        this.nombreplazo5 = nombreplazo5;
    }

    public String getNombreplazo6() {
        return nombreplazo6;
    }

    public void setNombreplazo6(String nombreplazo6) {
        this.nombreplazo6 = nombreplazo6;
    }

    public String getNombreplazo7() {
        return nombreplazo7;
    }

    public void setNombreplazo7(String nombreplazo7) {
        this.nombreplazo7 = nombreplazo7;
    }

    public String getNombreplazo8() {
        return nombreplazo8;
    }

    public void setNombreplazo8(String nombreplazo8) {
        this.nombreplazo8 = nombreplazo8;
    }

    public String getNombreplazo9() {
        return nombreplazo9;
    }

    public void setNombreplazo9(String nombreplazo9) {
        this.nombreplazo9 = nombreplazo9;
    }

    public Integer getNumplazosadelantados() {
        return numplazosadelantados;
    }

    public void setNumplazosadelantados(Integer numplazosadelantados) {
        this.numplazosadelantados = numplazosadelantados;
    }

    public Integer getNumplazosvencimiento() {
        return numplazosvencimiento;
    }

    public void setNumplazosvencimiento(Integer numplazosvencimiento) {
        this.numplazosvencimiento = numplazosvencimiento;
    }

    public Double getPlazopm1() {
        return plazopm1;
    }

    public void setPlazopm1(Double plazopm1) {
        this.plazopm1 = plazopm1;
    }

    public Double getPlazopm10() {
        return plazopm10;
    }

    public void setPlazopm10(Double plazopm10) {
        this.plazopm10 = plazopm10;
    }

    public Double getPlazopm2() {
        return plazopm2;
    }

    public void setPlazopm2(Double plazopm2) {
        this.plazopm2 = plazopm2;
    }

    public Double getPlazopm3() {
        return plazopm3;
    }

    public void setPlazopm3(Double plazopm3) {
        this.plazopm3 = plazopm3;
    }

    public Double getPlazopm5() {
        return plazopm5;
    }

    public void setPlazopm5(Double plazopm5) {
        this.plazopm5 = plazopm5;
    }

    public Double getPlazopm6() {
        return plazopm6;
    }

    public void setPlazopm6(Double plazopm6) {
        this.plazopm6 = plazopm6;
    }

    public Double getPlazopm7() {
        return plazopm7;
    }

    public void setPlazopm7(Double plazopm7) {
        this.plazopm7 = plazopm7;
    }

    public Double getPlazopm8() {
        return plazopm8;
    }

    public void setPlazopm8(Double plazopm8) {
        this.plazopm8 = plazopm8;
    }

    public Double getPlazopm9() {
        return plazopm9;
    }

    public void setPlazopm9(Double plazopm9) {
        this.plazopm9 = plazopm9;
    }

    public Integer getPlazovm1() {
        return plazovm1;
    }

    public void setPlazovm1(Integer plazovm1) {
        this.plazovm1 = plazovm1;
    }

    public Integer getPlazovm10() {
        return plazovm10;
    }

    public void setPlazovm10(Integer plazovm10) {
        this.plazovm10 = plazovm10;
    }

    public Integer getPlazovm2() {
        return plazovm2;
    }

    public void setPlazovm2(Integer plazovm2) {
        this.plazovm2 = plazovm2;
    }

    public Integer getPlazovm3() {
        return plazovm3;
    }

    public void setPlazovm3(Integer plazovm3) {
        this.plazovm3 = plazovm3;
    }

    public Integer getPlazovm4() {
        return plazovm4;
    }

    public void setPlazovm4(Integer plazovm4) {
        this.plazovm4 = plazovm4;
    }

    public Integer getPlazovm5() {
        return plazovm5;
    }

    public void setPlazovm5(Integer plazovm5) {
        this.plazovm5 = plazovm5;
    }

    public Integer getPlazovm6() {
        return plazovm6;
    }

    public void setPlazovm6(Integer plazovm6) {
        this.plazovm6 = plazovm6;
    }

    public Integer getPlazovm7() {
        return plazovm7;
    }

    public void setPlazovm7(Integer plazovm7) {
        this.plazovm7 = plazovm7;
    }

    public Integer getPlazovm8() {
        return plazovm8;
    }

    public void setPlazovm8(Integer plazovm8) {
        this.plazovm8 = plazovm8;
    }

    public Integer getPlazovm9() {
        return plazovm9;
    }

    public void setPlazovm9(Integer plazovm9) {
        this.plazovm9 = plazovm9;
    }

    public Boolean getPorcentajeautomatico() {
        return porcentajeautomatico;
    }

    public void setPorcentajeautomatico(Boolean porcentajeautomatico) {
        this.porcentajeautomatico = porcentajeautomatico;
    }

    public Double getPorcentajepago1() {
        return porcentajepago1;
    }

    public void setPorcentajepago1(Double porcentajepago1) {
        this.porcentajepago1 = porcentajepago1;
    }

    public Double getPorcentajepago10() {
        return porcentajepago10;
    }

    public void setPorcentajepago10(Double porcentajepago10) {
        this.porcentajepago10 = porcentajepago10;
    }

    public Double getPorcentajepago2() {
        return porcentajepago2;
    }

    public void setPorcentajepago2(Double porcentajepago2) {
        this.porcentajepago2 = porcentajepago2;
    }

    public Double getPorcentajepago3() {
        return porcentajepago3;
    }

    public void setPorcentajepago3(Double porcentajepago3) {
        this.porcentajepago3 = porcentajepago3;
    }

    public Double getPorcentajepago4() {
        return porcentajepago4;
    }

    public void setPorcentajepago4(Double porcentajepago4) {
        this.porcentajepago4 = porcentajepago4;
    }

    public Double getPorcentajepago5() {
        return porcentajepago5;
    }

    public void setPorcentajepago5(Double porcentajepago5) {
        this.porcentajepago5 = porcentajepago5;
    }

    public Double getPorcentajepago6() {
        return porcentajepago6;
    }

    public void setPorcentajepago6(Double porcentajepago6) {
        this.porcentajepago6 = porcentajepago6;
    }

    public Double getPorcentajepago7() {
        return porcentajepago7;
    }

    public void setPorcentajepago7(Double porcentajepago7) {
        this.porcentajepago7 = porcentajepago7;
    }

    public Double getPorcentajepago8() {
        return porcentajepago8;
    }

    public void setPorcentajepago8(Double porcentajepago8) {
        this.porcentajepago8 = porcentajepago8;
    }

    public Double getPorcentajepago9() {
        return porcentajepago9;
    }

    public void setPorcentajepago9(Double porcentajepago9) {
        this.porcentajepago9 = porcentajepago9;
    }

    public String getTipodecalculo() {
        return tipodecalculo;
    }

    public void setTipodecalculo(String tipodecalculo) {
        this.tipodecalculo = tipodecalculo;
    }

    public String getTiporecibopago() {
        return tiporecibopago;
    }

    public void setTiporecibopago(String tiporecibopago) {
        this.tiporecibopago = tiporecibopago;
    }

    public String getTiporecibovencimiento() {
        return tiporecibovencimiento;
    }

    public void setTiporecibovencimiento(String tiporecibovencimiento) {
        this.tiporecibovencimiento = tiporecibovencimiento;
    }

    public TipoRecibo getIid_tr_p1() {
        return iid_tr_p1;
    }

    public void setIid_tr_p1(TipoRecibo iid_tr_p1) {
        this.iid_tr_p1 = iid_tr_p1;
    }

    public TipoRecibo getIid_tr_p10() {
        return iid_tr_p10;
    }

    public void setIid_tr_p10(TipoRecibo iid_tr_p10) {
        this.iid_tr_p10 = iid_tr_p10;
    }

    public TipoRecibo getIid_tr_p2() {
        return iid_tr_p2;
    }

    public void setIid_tr_p2(TipoRecibo iid_tr_p2) {
        this.iid_tr_p2 = iid_tr_p2;
    }

    public TipoRecibo getIid_tr_p3() {
        return iid_tr_p3;
    }

    public void setIid_tr_p3(TipoRecibo iid_tr_p3) {
        this.iid_tr_p3 = iid_tr_p3;
    }

    public TipoRecibo getIid_tr_p4() {
        return iid_tr_p4;
    }

    public void setIid_tr_p4(TipoRecibo iid_tr_p4) {
        this.iid_tr_p4 = iid_tr_p4;
    }

    public TipoRecibo getIid_tr_p5() {
        return iid_tr_p5;
    }

    public void setIid_tr_p5(TipoRecibo iid_tr_p5) {
        this.iid_tr_p5 = iid_tr_p5;
    }

    public TipoRecibo getIid_tr_p6() {
        return iid_tr_p6;
    }

    public void setIid_tr_p6(TipoRecibo iid_tr_p6) {
        this.iid_tr_p6 = iid_tr_p6;
    }

    public TipoRecibo getIid_tr_p7() {
        return iid_tr_p7;
    }

    public void setIid_tr_p7(TipoRecibo iid_tr_p7) {
        this.iid_tr_p7 = iid_tr_p7;
    }

    public TipoRecibo getIid_tr_p8() {
        return iid_tr_p8;
    }

    public void setIid_tr_p8(TipoRecibo iid_tr_p8) {
        this.iid_tr_p8 = iid_tr_p8;
    }

    public TipoRecibo getIid_tr_p9() {
        return iid_tr_p9;
    }

    public void setIid_tr_p9(TipoRecibo iid_tr_p9) {
        this.iid_tr_p9 = iid_tr_p9;
    }

    public TipoRecibo getIid_tr_v1() {
        return iid_tr_v1;
    }

    public void setIid_tr_v1(TipoRecibo iid_tr_v1) {
        this.iid_tr_v1 = iid_tr_v1;
    }

    public TipoRecibo getIid_tr_v10() {
        return iid_tr_v10;
    }

    public void setIid_tr_v10(TipoRecibo iid_tr_v10) {
        this.iid_tr_v10 = iid_tr_v10;
    }

    public TipoRecibo getIid_tr_v2() {
        return iid_tr_v2;
    }

    public void setIid_tr_v2(TipoRecibo iid_tr_v2) {
        this.iid_tr_v2 = iid_tr_v2;
    }

    public TipoRecibo getIid_tr_v3() {
        return iid_tr_v3;
    }

    public void setIid_tr_v3(TipoRecibo iid_tr_v3) {
        this.iid_tr_v3 = iid_tr_v3;
    }

    public TipoRecibo getIid_tr_v4() {
        return iid_tr_v4;
    }

    public void setIid_tr_v4(TipoRecibo iid_tr_v4) {
        this.iid_tr_v4 = iid_tr_v4;
    }

    public TipoRecibo getIid_tr_v5() {
        return iid_tr_v5;
    }

    public void setIid_tr_v5(TipoRecibo iid_tr_v5) {
        this.iid_tr_v5 = iid_tr_v5;
    }

    public TipoRecibo getIid_tr_v6() {
        return iid_tr_v6;
    }

    public void setIid_tr_v6(TipoRecibo iid_tr_v6) {
        this.iid_tr_v6 = iid_tr_v6;
    }

    public TipoRecibo getIid_tr_v7() {
        return iid_tr_v7;
    }

    public void setIid_tr_v7(TipoRecibo iid_tr_v7) {
        this.iid_tr_v7 = iid_tr_v7;
    }

    public TipoRecibo getIid_tr_v8() {
        return iid_tr_v8;
    }

    public void setIid_tr_v8(TipoRecibo iid_tr_v8) {
        this.iid_tr_v8 = iid_tr_v8;
    }

    public TipoRecibo getIid_tr_v9() {
        return iid_tr_v9;
    }

    public void setIid_tr_v9(TipoRecibo iid_tr_v9) {
        this.iid_tr_v9 = iid_tr_v9;
    }

    public String getCobrado1() {
        return cobrado1;
    }

    public void setCobrado1(String cobrado1) {
        this.cobrado1 = cobrado1;
    }

    public String getCobrado10() {
        return cobrado10;
    }

    public void setCobrado10(String cobrado10) {
        this.cobrado10 = cobrado10;
    }

    public String getCobrado2() {
        return cobrado2;
    }

    public void setCobrado2(String cobrado2) {
        this.cobrado2 = cobrado2;
    }

    public String getCobrado3() {
        return cobrado3;
    }

    public void setCobrado3(String cobrado3) {
        this.cobrado3 = cobrado3;
    }

    public String getCobrado4() {
        return cobrado4;
    }

    public void setCobrado4(String cobrado4) {
        this.cobrado4 = cobrado4;
    }

    public String getCobrado5() {
        return cobrado5;
    }

    public void setCobrado5(String cobrado5) {
        this.cobrado5 = cobrado5;
    }

    public String getCobrado6() {
        return cobrado6;
    }

    public void setCobrado6(String cobrado6) {
        this.cobrado6 = cobrado6;
    }

    public String getCobrado7() {
        return cobrado7;
    }

    public void setCobrado7(String cobrado7) {
        this.cobrado7 = cobrado7;
    }

    public String getCobrado8() {
        return cobrado8;
    }

    public void setCobrado8(String cobrado8) {
        this.cobrado8 = cobrado8;
    }

    public String getCobrado9() {
        return cobrado9;
    }

    public void setCobrado9(String cobrado9) {
        this.cobrado9 = cobrado9;
    }
    
    public FormaPago2() {
        
    }

    public Double getImportep1() {
        return importep1;
    }

    public void setImportep1(Double importep1) {
        this.importep1 = importep1;
    }

    public Double getImportep10() {
        return importep10;
    }

    public void setImportep10(Double importep10) {
        this.importep10 = importep10;
    }

    public Double getImportep2() {
        return importep2;
    }

    public void setImportep2(Double importep2) {
        this.importep2 = importep2;
    }

    public Double getImportep3() {
        return importep3;
    }

    public void setImportep3(Double importep3) {
        this.importep3 = importep3;
    }

    public Double getImportep4() {
        return importep4;
    }

    public void setImportep4(Double importep4) {
        this.importep4 = importep4;
    }

    public Double getImportep5() {
        return importep5;
    }

    public void setImportep5(Double importep5) {
        this.importep5 = importep5;
    }

    public Double getImportep6() {
        return importep6;
    }

    public void setImportep6(Double importep6) {
        this.importep6 = importep6;
    }

    public Double getImportep7() {
        return importep7;
    }

    public void setImportep7(Double importep7) {
        this.importep7 = importep7;
    }

    public Double getImportep8() {
        return importep8;
    }

    public void setImportep8(Double importep8) {
        this.importep8 = importep8;
    }

    public Double getImportep9() {
        return importep9;
    }

    public void setImportep9(Double importep9) {
        this.importep9 = importep9;
    }

    public Double getImportev1() {
        return importev1;
    }

    public void setImportev1(Double importev1) {
        this.importev1 = importev1;
    }

    public Double getImportev10() {
        return importev10;
    }

    public void setImportev10(Double importev10) {
        this.importev10 = importev10;
    }

    public Double getImportev2() {
        return importev2;
    }

    public void setImportev2(Double importev2) {
        this.importev2 = importev2;
    }

    public Double getImportev3() {
        return importev3;
    }

    public void setImportev3(Double importev3) {
        this.importev3 = importev3;
    }

    public Double getImportev4() {
        return importev4;
    }

    public void setImportev4(Double importev4) {
        this.importev4 = importev4;
    }

    public Double getImportev5() {
        return importev5;
    }

    public void setImportev5(Double importev5) {
        this.importev5 = importev5;
    }

    public Double getImportev6() {
        return importev6;
    }

    public void setImportev6(Double importev6) {
        this.importev6 = importev6;
    }

    public Double getImportev7() {
        return importev7;
    }

    public void setImportev7(Double importev7) {
        this.importev7 = importev7;
    }

    public Double getImportev8() {
        return importev8;
    }

    public void setImportev8(Double importev8) {
        this.importev8 = importev8;
    }

    public Double getImportev9() {
        return importev9;
    }

    public void setImportev9(Double importev9) {
        this.importev9 = importev9;
    }

    public Long getFechap1() {
        return fechap1;
    }

    public void setFechap1(Long fechap1) {
        this.fechap1 = fechap1;
    }

    public Long getFechap10() {
        return fechap10;
    }

    public void setFechap10(Long fechap10) {
        this.fechap10 = fechap10;
    }

    public Long getFechap2() {
        return fechap2;
    }

    public void setFechap2(Long fechap2) {
        this.fechap2 = fechap2;
    }

    public Long getFechap3() {
        return fechap3;
    }

    public void setFechap3(Long fechap3) {
        this.fechap3 = fechap3;
    }

    public Long getFechap4() {
        return fechap4;
    }

    public void setFechap4(Long fechap4) {
        this.fechap4 = fechap4;
    }

    public Long getFechap5() {
        return fechap5;
    }

    public void setFechap5(Long fechap5) {
        this.fechap5 = fechap5;
    }

    public Long getFechap6() {
        return fechap6;
    }

    public void setFechap6(Long fechap6) {
        this.fechap6 = fechap6;
    }

    public Long getFechap7() {
        return fechap7;
    }

    public void setFechap7(Long fechap7) {
        this.fechap7 = fechap7;
    }

    public Long getFechap8() {
        return fechap8;
    }

    public void setFechap8(Long fechap8) {
        this.fechap8 = fechap8;
    }

    public Long getFechap9() {
        return fechap9;
    }

    public void setFechap9(Long fechap9) {
        this.fechap9 = fechap9;
    }
    
    public String getEmitido1() {
        return emitido1;
    }
    
    public void setEmitido1(String emitido1) {
        this.emitido1 = emitido1;
    }

    public String getEmitido10() {
        return emitido10;
    }

    public void setEmitido10(String emitido10) {
        this.emitido10 = emitido10;
    }

    public String getEmitido2() {
        return emitido2;
    }

    public void setEmitido2(String emitido2) {
        this.emitido2 = emitido2;
    }

    public String getEmitido3() {
        return emitido3;
    }

    public void setEmitido3(String emitido3) {
        this.emitido3 = emitido3;
    }

    public String getEmitido4() {
        return emitido4;
    }

    public void setEmitido4(String emitido4) {
        this.emitido4 = emitido4;
    }

    public String getEmitido5() {
        return emitido5;
    }

    public void setEmitido5(String emitido5) {
        this.emitido5 = emitido5;
    }

    public String getEmitido6() {
        return emitido6;
    }

    public void setEmitido6(String emitido6) {
        this.emitido6 = emitido6;
    }

    public String getEmitido7() {
        return emitido7;
    }

    public void setEmitido7(String emitido7) {
        this.emitido7 = emitido7;
    }

    public String getEmitido8() {
        return emitido8;
    }

    public void setEmitido8(String emitido8) {
        this.emitido8 = emitido8;
    }

    public String getEmitido9() {
        return emitido9;
    }

    public void setEmitido9(String emitido9) {
        this.emitido9 = emitido9;
    }

    public String getImputado1() {
        return imputado1;
    }

    public void setImputado1(String imputado1) {
        this.imputado1 = imputado1;
    }

    public String getImputado10() {
        return imputado10;
    }

    public void setImputado10(String imputado10) {
        this.imputado10 = imputado10;
    }

    public String getImputado2() {
        return imputado2;
    }

    public void setImputado2(String imputado2) {
        this.imputado2 = imputado2;
    }

    public String getImputado3() {
        return imputado3;
    }

    public void setImputado3(String imputado3) {
        this.imputado3 = imputado3;
    }

    public String getImputado4() {
        return imputado4;
    }

    public void setImputado4(String imputado4) {
        this.imputado4 = imputado4;
    }

    public String getImputado5() {
        return imputado5;
    }

    public void setImputado5(String imputado5) {
        this.imputado5 = imputado5;
    }

    public String getImputado6() {
        return imputado6;
    }

    public void setImputado6(String imputado6) {
        this.imputado6 = imputado6;
    }

    public String getImputado7() {
        return imputado7;
    }

    public void setImputado7(String imputado7) {
        this.imputado7 = imputado7;
    }

    public String getImputado8() {
        return imputado8;
    }

    public void setImputado8(String imputado8) {
        this.imputado8 = imputado8;
    }

    public String getImputado9() {
        return imputado9;
    }

    public void setImputado9(String imputado9) {
        this.imputado9 = imputado9;
    }

    public String getRecibo1() {
        return recibo1;
    }

    public void setRecibo1(String recibo1) {
        this.recibo1 = recibo1;
    }

    public String getRecibo10() {
        return recibo10;
    }

    public void setRecibo10(String recibo10) {
        this.recibo10 = recibo10;
    }

    public String getRecibo2() {
        return recibo2;
    }

    public void setRecibo2(String recibo2) {
        this.recibo2 = recibo2;
    }

    public String getRecibo3() {
        return recibo3;
    }

    public void setRecibo3(String recibo3) {
        this.recibo3 = recibo3;
    }

    public String getRecibo4() {
        return recibo4;
    }

    public void setRecibo4(String recibo4) {
        this.recibo4 = recibo4;
    }

    public String getRecibo5() {
        return recibo5;
    }

    public void setRecibo5(String recibo5) {
        this.recibo5 = recibo5;
    }

    public String getRecibo6() {
        return recibo6;
    }

    public void setRecibo6(String recibo6) {
        this.recibo6 = recibo6;
    }

    public String getRecibo7() {
        return recibo7;
    }

    public void setRecibo7(String recibo7) {
        this.recibo7 = recibo7;
    }

    public String getRecibo8() {
        return recibo8;
    }

    public void setRecibo8(String recibo8) {
        this.recibo8 = recibo8;
    }

    public String getRecibo9() {
        return recibo9;
    }

    public void setRecibo9(String recibo9) {
        this.recibo9 = recibo9;
    }

    public String getCobradoVencimiento1() {
        return cobradoVencimiento1;
    }

    public void setCobradoVencimiento1(String cobradoVencimiento1) {
        this.cobradoVencimiento1 = cobradoVencimiento1;
    }

    public String getCobradoVencimiento10() {
        return cobradoVencimiento10;
    }

    public void setCobradoVencimiento10(String cobradoVencimiento10) {
        this.cobradoVencimiento10 = cobradoVencimiento10;
    }

    public String getCobradoVencimiento2() {
        return cobradoVencimiento2;
    }

    public void setCobradoVencimiento2(String cobradoVencimiento2) {
        this.cobradoVencimiento2 = cobradoVencimiento2;
    }

    public String getCobradoVencimiento3() {
        return cobradoVencimiento3;
    }

    public void setCobradoVencimiento3(String cobradoVencimiento3) {
        this.cobradoVencimiento3 = cobradoVencimiento3;
    }

    public String getCobradoVencimiento4() {
        return cobradoVencimiento4;
    }

    public void setCobradoVencimiento4(String cobradoVencimiento4) {
        this.cobradoVencimiento4 = cobradoVencimiento4;
    }

    public String getCobradoVencimiento5() {
        return cobradoVencimiento5;
    }

    public void setCobradoVencimiento5(String cobradoVencimiento5) {
        this.cobradoVencimiento5 = cobradoVencimiento5;
    }

    public String getCobradoVencimiento6() {
        return cobradoVencimiento6;
    }

    public void setCobradoVencimiento6(String cobradoVencimiento6) {
        this.cobradoVencimiento6 = cobradoVencimiento6;
    }

    public String getCobradoVencimiento7() {
        return cobradoVencimiento7;
    }

    public void setCobradoVencimiento7(String cobradoVencimiento7) {
        this.cobradoVencimiento7 = cobradoVencimiento7;
    }

    public String getCobradoVencimiento8() {
        return cobradoVencimiento8;
    }

    public void setCobradoVencimiento8(String cobradoVencimiento8) {
        this.cobradoVencimiento8 = cobradoVencimiento8;
    }

    public String getCobradoVencimiento9() {
        return cobradoVencimiento9;
    }

    public void setCobradoVencimiento9(String cobradoVencimiento9) {
        this.cobradoVencimiento9 = cobradoVencimiento9;
    }

    public String getEmitidoVencimiento1() {
        return emitidoVencimiento1;
    }

    public void setEmitidoVencimiento1(String emitidoVencimiento1) {
        this.emitidoVencimiento1 = emitidoVencimiento1;
    }

    public String getEmitidoVencimiento10() {
        return emitidoVencimiento10;
    }

    public void setEmitidoVencimiento10(String emitidoVencimiento10) {
        this.emitidoVencimiento10 = emitidoVencimiento10;
    }

    public String getEmitidoVencimiento2() {
        return emitidoVencimiento2;
    }

    public void setEmitidoVencimiento2(String emitidoVencimiento2) {
        this.emitidoVencimiento2 = emitidoVencimiento2;
    }

    public String getEmitidoVencimiento3() {
        return emitidoVencimiento3;
    }

    public void setEmitidoVencimiento3(String emitidoVencimiento3) {
        this.emitidoVencimiento3 = emitidoVencimiento3;
    }

    public String getEmitidoVencimiento4() {
        return emitidoVencimiento4;
    }

    public void setEmitidoVencimiento4(String emitidoVencimiento4) {
        this.emitidoVencimiento4 = emitidoVencimiento4;
    }

    public String getEmitidoVencimiento5() {
        return emitidoVencimiento5;
    }

    public void setEmitidoVencimiento5(String emitidoVencimiento5) {
        this.emitidoVencimiento5 = emitidoVencimiento5;
    }

    public String getEmitidoVencimiento6() {
        return emitidoVencimiento6;
    }

    public void setEmitidoVencimiento6(String emitidoVencimiento6) {
        this.emitidoVencimiento6 = emitidoVencimiento6;
    }

    public String getEmitidoVencimiento7() {
        return emitidoVencimiento7;
    }

    public void setEmitidoVencimiento7(String emitidoVencimiento7) {
        this.emitidoVencimiento7 = emitidoVencimiento7;
    }

    public String getEmitidoVencimiento8() {
        return emitidoVencimiento8;
    }

    public void setEmitidoVencimiento8(String emitidoVencimiento8) {
        this.emitidoVencimiento8 = emitidoVencimiento8;
    }

    public String getEmitidoVencimiento9() {
        return emitidoVencimiento9;
    }

    public void setEmitidoVencimiento9(String emitidoVencimiento9) {
        this.emitidoVencimiento9 = emitidoVencimiento9;
    }

    public String getImputadoVencimiento1() {
        return imputadoVencimiento1;
    }

    public void setImputadoVencimiento1(String imputadoVencimiento1) {
        this.imputadoVencimiento1 = imputadoVencimiento1;
    }

    public String getImputadoVencimiento10() {
        return imputadoVencimiento10;
    }

    public void setImputadoVencimiento10(String imputadoVencimiento10) {
        this.imputadoVencimiento10 = imputadoVencimiento10;
    }

    public String getImputadoVencimiento2() {
        return imputadoVencimiento2;
    }

    public void setImputadoVencimiento2(String imputadoVencimiento2) {
        this.imputadoVencimiento2 = imputadoVencimiento2;
    }

    public String getImputadoVencimiento3() {
        return imputadoVencimiento3;
    }

    public void setImputadoVencimiento3(String imputadoVencimiento3) {
        this.imputadoVencimiento3 = imputadoVencimiento3;
    }

    public String getImputadoVencimiento4() {
        return imputadoVencimiento4;
    }

    public void setImputadoVencimiento4(String imputadoVencimiento4) {
        this.imputadoVencimiento4 = imputadoVencimiento4;
    }

    public String getImputadoVencimiento5() {
        return imputadoVencimiento5;
    }

    public void setImputadoVencimiento5(String imputadoVencimiento5) {
        this.imputadoVencimiento5 = imputadoVencimiento5;
    }

    public String getImputadoVencimiento6() {
        return imputadoVencimiento6;
    }

    public void setImputadoVencimiento6(String imputadoVencimiento6) {
        this.imputadoVencimiento6 = imputadoVencimiento6;
    }

    public String getImputadoVencimiento7() {
        return imputadoVencimiento7;
    }

    public void setImputadoVencimiento7(String imputadoVencimiento7) {
        this.imputadoVencimiento7 = imputadoVencimiento7;
    }

    public String getImputadoVencimiento8() {
        return imputadoVencimiento8;
    }

    public void setImputadoVencimiento8(String imputadoVencimiento8) {
        this.imputadoVencimiento8 = imputadoVencimiento8;
    }

    public String getImputadoVencimiento9() {
        return imputadoVencimiento9;
    }

    public void setImputadoVencimiento9(String imputadoVencimiento9) {
        this.imputadoVencimiento9 = imputadoVencimiento9;
    }

    public String getReciboVencimiento1() {
        return reciboVencimiento1;
    }

    public void setReciboVencimiento1(String reciboVencimiento1) {
        this.reciboVencimiento1 = reciboVencimiento1;
    }

    public String getReciboVencimiento10() {
        return reciboVencimiento10;
    }

    public void setReciboVencimiento10(String reciboVencimiento10) {
        this.reciboVencimiento10 = reciboVencimiento10;
    }

    public String getReciboVencimiento2() {
        return reciboVencimiento2;
    }

    public void setReciboVencimiento2(String reciboVencimiento2) {
        this.reciboVencimiento2 = reciboVencimiento2;
    }

    public String getReciboVencimiento3() {
        return reciboVencimiento3;
    }

    public void setReciboVencimiento3(String reciboVencimiento3) {
        this.reciboVencimiento3 = reciboVencimiento3;
    }

    public String getReciboVencimiento4() {
        return reciboVencimiento4;
    }

    public void setReciboVencimiento4(String reciboVencimiento4) {
        this.reciboVencimiento4 = reciboVencimiento4;
    }

    public String getReciboVencimiento5() {
        return reciboVencimiento5;
    }

    public void setReciboVencimiento5(String reciboVencimiento5) {
        this.reciboVencimiento5 = reciboVencimiento5;
    }

    public String getReciboVencimiento6() {
        return reciboVencimiento6;
    }

    public void setReciboVencimiento6(String reciboVencimiento6) {
        this.reciboVencimiento6 = reciboVencimiento6;
    }

    public String getReciboVencimiento7() {
        return reciboVencimiento7;
    }

    public void setReciboVencimiento7(String reciboVencimiento7) {
        this.reciboVencimiento7 = reciboVencimiento7;
    }

    public String getReciboVencimiento8() {
        return reciboVencimiento8;
    }

    public void setReciboVencimiento8(String reciboVencimiento8) {
        this.reciboVencimiento8 = reciboVencimiento8;
    }

    public String getReciboVencimiento9() {
        return reciboVencimiento9;
    }

    public void setReciboVencimiento9(String reciboVencimiento9) {
        this.reciboVencimiento9 = reciboVencimiento9;
    }

    
    public Long getFechaPlazo1() {
        return fechaPlazo1;
    }

    public void setFechaPlazo1(Long fechaPlazo) {
        this.fechaPlazo1 = fechaPlazo;
    }
    
    public Long getFechaPlazo2() {
        return fechaPlazo2;
    }

    public void setFechaPlazo2(Long fechaPlazo) {
        this.fechaPlazo2 = fechaPlazo;
    }
    public Long getFechaPlazo3() {
        return fechaPlazo3;
    }

    public void setFechaPlazo3(Long fechaPlazo) {
        this.fechaPlazo3 = fechaPlazo;
    }
    public Long getFechaPlazo4() {
        return fechaPlazo4;
    }

    public void setFechaPlazo4(Long fechaPlazo) {
        this.fechaPlazo4 = fechaPlazo;
    }
    public Long getFechaPlazo5() {
        return fechaPlazo5;
    }

    public void setFechaPlazo5(Long fechaPlazo) {
        this.fechaPlazo5 = fechaPlazo;
    }
    public Long getFechaPlazo6() {
        return fechaPlazo6;
    }

    public void setFechaPlazo6(Long fechaPlazo) {
        this.fechaPlazo6 = fechaPlazo;
    }
    public Long getFechaPlazo7() {
        return fechaPlazo7;
    }

    public void setFechaPlazo7(Long fechaPlazo) {
        this.fechaPlazo7 = fechaPlazo;
    }
    public Long getFechaPlazo8() {
        return fechaPlazo8;
    }

    public void setFechaPlazo8(Long fechaPlazo) {
        this.fechaPlazo8 = fechaPlazo;
    }
    public Long getFechaPlazo9() {
        return fechaPlazo9;
    }

    public void setFechaPlazo9(Long fechaPlazo) {
        this.fechaPlazo9 = fechaPlazo;
    }
    public Long getFechaPlazo10() {
        return fechaPlazo10;
    }

    public void setFechaPlazo10(Long fechaPlazo) {
        this.fechaPlazo10 = fechaPlazo;
    }


    public void modificar(FormaPago2 fp){
        codigo = fp.getCodigo();
        descripcionidentificativa = fp.getDescripcionidentificativa();
        descripcioncliente = fp.getDescripcioncliente();
        tiporecibopago = fp.getTiporecibopago();
        nombreplazo1 = fp.getNombreplazo1();
        nombreplazo2 = fp.getNombreplazo2();
        nombreplazo3 = fp.getNombreplazo3();
        nombreplazo4 = fp.getNombreplazo4();
        nombreplazo5 = fp.getNombreplazo5();
        nombreplazo6 = fp.getNombreplazo6();
        nombreplazo7 = fp.getNombreplazo7();
        nombreplazo8 = fp.getNombreplazo8();
        nombreplazo9 = fp.getNombreplazo9();
        nombreplazo10 = fp.getNombreplazo10();
        tiporecibovencimiento = fp.getTiporecibovencimiento();
        tipodecalculo = fp.getTipodecalculo();
        calculovencimientoautomatico = fp.getCalculovencimientoautomatico();
        porcentajeautomatico = fp.getPorcentajeautomatico();
        iid_tr_p1 = fp.getIid_tr_p1();
        iid_tr_p2 = fp.getIid_tr_p2();
        iid_tr_p3 = fp.getIid_tr_p3();
        iid_tr_p4 = fp.getIid_tr_p4();
        iid_tr_p5 = fp.getIid_tr_p5();
        iid_tr_p6 = fp.getIid_tr_p6();
        iid_tr_p7 = fp.getIid_tr_p7();
        iid_tr_p8 = fp.getIid_tr_p8();
        iid_tr_p9 = fp.getIid_tr_p9();
        iid_tr_p10 = fp.getIid_tr_p10();
        iid_tr_v1 = fp.getIid_tr_v1();
        iid_tr_v2 = fp.getIid_tr_v2();
        iid_tr_v3 = fp.getIid_tr_v3();
        iid_tr_v4 = fp.getIid_tr_v4();
        iid_tr_v5 = fp.getIid_tr_v5();
        iid_tr_v6 = fp.getIid_tr_v6();
        iid_tr_v7 = fp.getIid_tr_v7();
        iid_tr_v8 = fp.getIid_tr_v8();
        iid_tr_v9 = fp.getIid_tr_v9();
        iid_tr_v10 = fp.getIid_tr_v10();
        cobrado1 = fp.getCobrado1();
        cobrado2 = fp.getCobrado2();
        cobrado3 = fp.getCobrado3();
        cobrado4 = fp.getCobrado4();
        cobrado5 = fp.getCobrado5();
        cobrado6 = fp.getCobrado6();
        cobrado7 = fp.getCobrado7();
        cobrado8 = fp.getCobrado8();
        cobrado9 = fp.getCobrado9();
        cobrado10 = fp.getCobrado10();
        fechap1 = fp.getFechap1();
        fechap2 = fp.getFechap2();
        fechap3 = fp.getFechap3();
        fechap4 = fp.getFechap4();
        fechap5 = fp.getFechap5();
        fechap6 = fp.getFechap6();
        fechap7 = fp.getFechap7();
        fechap8 = fp.getFechap8();
        fechap9 = fp.getFechap9();
        fechap10 = fp.getFechap10();
        importep1 = fp.getImportep1();
        importep2 = fp.getImportep2();
        importep3 = fp.getImportep3();
        importep4 = fp.getImportep4();
        importep5 = fp.getImportep5();
        importep6 = fp.getImportep6();
        importep7 = fp.getImportep7();
        importep8 = fp.getImportep8();
        importep9 = fp.getImportep9();
        importep10 = fp.getImportep10();
        importev1 = fp.getImportev1();
        importev2 = fp.getImportev2();
        importev3 = fp.getImportev3();
        importev4 = fp.getImportev4();
        importev5 = fp.getImportev5();
        importev6 = fp.getImportev6();
        importev7 = fp.getImportev7();
        importev8 = fp.getImportev8();
        importev9 = fp.getImportev9();
        importev10 = fp.getImportev10();
        dtoprontopago = fp.getDtoprontopago();
        numplazosadelantados = fp.getNumplazosadelantados();
        numplazosvencimiento = fp.getNumplazosvencimiento();
        porcentajepago1 = fp.getPorcentajepago1();
        porcentajepago2 = fp.getPorcentajepago2();
        porcentajepago3 = fp.getPorcentajepago3();
        porcentajepago4 = fp.getPorcentajepago4();
        porcentajepago5 = fp.getPorcentajepago5();
        porcentajepago6 = fp.getPorcentajepago6();
        porcentajepago7 = fp.getPorcentajepago7();
        porcentajepago8 = fp.getPorcentajepago8();
        porcentajepago9 = fp.getPorcentajepago9();
        porcentajepago10 = fp.getPorcentajepago10();
        plazovm1 = fp.getPlazovm1();
        plazovm2 = fp.getPlazovm2();
        plazovm3 = fp.getPlazovm3();
        plazovm4 = fp.getPlazovm4();
        plazovm5 = fp.getPlazovm5();
        plazovm6 = fp.getPlazovm6();
        plazovm7 = fp.getPlazovm7();
        plazovm8 = fp.getPlazovm8();
        plazovm9 = fp.getPlazovm9();
        plazovm10 = fp.getPlazovm10();
        plazopm1 = fp.getPlazopm1();
        plazopm2 = fp.getPlazopm2();
        plazopm3 = fp.getPlazopm3();
        plazopm4 = fp.getPlazopm4();
        plazopm5 = fp.getPlazopm5();
        plazopm6 = fp.getPlazopm6();
        plazopm7 = fp.getPlazopm7();
        plazopm8 = fp.getPlazopm8();
        plazopm9 = fp.getPlazopm9();
        plazopm10 = fp.getPlazopm10();
        importeminimo = fp.getImporteminimo();
        diasprimerplazo = fp.getDiasprimerplazo();
        diasentreplazos = fp.getDiasentreplazos();
        
        cobradoVencimiento1 = fp.getCobradoVencimiento1();
        cobradoVencimiento2 = fp.getCobradoVencimiento2();
        cobradoVencimiento3 = fp.getCobradoVencimiento3();
        cobradoVencimiento4 = fp.getCobradoVencimiento4();
        cobradoVencimiento5 = fp.getCobradoVencimiento5();
        cobradoVencimiento6 = fp.getCobradoVencimiento6();
        cobradoVencimiento7 = fp.getCobradoVencimiento7();
        cobradoVencimiento8 = fp.getCobradoVencimiento8();
        cobradoVencimiento9 = fp.getCobradoVencimiento9();
        cobradoVencimiento10 = fp.getCobradoVencimiento10();
        
        emitidoVencimiento1 = fp.getEmitidoVencimiento1();
        emitidoVencimiento2 = fp.getEmitidoVencimiento2();
        emitidoVencimiento3 = fp.getEmitidoVencimiento3();
        emitidoVencimiento4 = fp.getEmitidoVencimiento4();
        emitidoVencimiento5 = fp.getEmitidoVencimiento5();
        emitidoVencimiento6 = fp.getEmitidoVencimiento6();
        emitidoVencimiento7 = fp.getEmitidoVencimiento7();
        emitidoVencimiento8 = fp.getEmitidoVencimiento8();
        emitidoVencimiento9 = fp.getEmitidoVencimiento9();
        emitidoVencimiento10 = fp.getEmitidoVencimiento10();
        
        reciboVencimiento1 = fp.getReciboVencimiento1();
        reciboVencimiento2 = fp.getReciboVencimiento2();
        reciboVencimiento3 = fp.getReciboVencimiento3();
        reciboVencimiento4 = fp.getReciboVencimiento4();
        reciboVencimiento5 = fp.getReciboVencimiento5();
        reciboVencimiento6 = fp.getReciboVencimiento6();
        reciboVencimiento7 = fp.getReciboVencimiento7();
        reciboVencimiento8 = fp.getReciboVencimiento8();
        reciboVencimiento9 = fp.getReciboVencimiento9();
        reciboVencimiento10 = fp.getReciboVencimiento10();
        
        imputadoVencimiento1 = fp.getImputadoVencimiento1();
        imputadoVencimiento2 = fp.getImputadoVencimiento2();
        imputadoVencimiento3 = fp.getImputadoVencimiento3();
        imputadoVencimiento4 = fp.getImputadoVencimiento4();
        imputadoVencimiento5 = fp.getImputadoVencimiento5();
        imputadoVencimiento6 = fp.getImputadoVencimiento6();
        imputadoVencimiento7 = fp.getImputadoVencimiento7();
        imputadoVencimiento8 = fp.getImputadoVencimiento8();
        imputadoVencimiento9 = fp.getImputadoVencimiento9();
        imputadoVencimiento10 = fp.getImputadoVencimiento10();
        
        fechaPlazo1 = fp.getFechaPlazo1();
        fechaPlazo2 = fp.getFechaPlazo2();
        fechaPlazo3 = fp.getFechaPlazo3();
        fechaPlazo4 = fp.getFechaPlazo4();
        fechaPlazo5 = fp.getFechaPlazo5();
        fechaPlazo6 = fp.getFechaPlazo6();
        fechaPlazo7 = fp.getFechaPlazo7();
        fechaPlazo8 = fp.getFechaPlazo8();
        fechaPlazo9 = fp.getFechaPlazo9();
        fechaPlazo10 = fp.getFechaPlazo10();
        
    }
    public FormaPago2(FormaPago fp) {
        codigo = fp.getCodigo();
        descripcionidentificativa = fp.getDescripcionidentificativa();
        descripcioncliente = fp.getDescripcioncliente();
        tiporecibopago = fp.getTiporecibopago();
        nombreplazo1 = fp.getNombreplazo1();
        nombreplazo2 = fp.getNombreplazo2();
        nombreplazo3 = fp.getNombreplazo3();
        nombreplazo4 = fp.getNombreplazo4();
        nombreplazo5 = fp.getNombreplazo5();
        nombreplazo6 = fp.getNombreplazo6();
        nombreplazo7 = fp.getNombreplazo7();
        nombreplazo8 = fp.getNombreplazo8();
        nombreplazo9 = fp.getNombreplazo9();
        nombreplazo10 = fp.getNombreplazo10();
        tiporecibovencimiento = fp.getTiporecibovencimiento();
        tipodecalculo = fp.getTipodecalculo();
        calculovencimientoautomatico = fp.getCalculovencimientoautomatico();
        porcentajeautomatico = fp.getPorcentajeautomatico();
        iid_tr_p1 = fp.getIid_tr_p1();
        iid_tr_p2 = fp.getIid_tr_p2();
        iid_tr_p3 = fp.getIid_tr_p3();
        iid_tr_p4 = fp.getIid_tr_p4();
        iid_tr_p5 = fp.getIid_tr_p5();
        iid_tr_p6 = fp.getIid_tr_p6();
        iid_tr_p7 = fp.getIid_tr_p7();
        iid_tr_p8 = fp.getIid_tr_p8();
        iid_tr_p9 = fp.getIid_tr_p9();
        iid_tr_p10 = fp.getIid_tr_p10();
        iid_tr_v1 = fp.getIid_tr_v1();
        iid_tr_v2 = fp.getIid_tr_v2();
        iid_tr_v3 = fp.getIid_tr_v3();
        iid_tr_v4 = fp.getIid_tr_v4();
        iid_tr_v5 = fp.getIid_tr_v5();
        iid_tr_v6 = fp.getIid_tr_v6();
        iid_tr_v7 = fp.getIid_tr_v7();
        iid_tr_v8 = fp.getIid_tr_v8();
        iid_tr_v9 = fp.getIid_tr_v9();
        iid_tr_v10 = fp.getIid_tr_v10();
        cobrado1 = fp.getCobrado1();
        cobrado2 = fp.getCobrado2();
        cobrado3 = fp.getCobrado3();
        cobrado4 = fp.getCobrado4();
        cobrado5 = fp.getCobrado5();
        cobrado6 = fp.getCobrado6();
        cobrado7 = fp.getCobrado7();
        cobrado8 = fp.getCobrado8();
        cobrado9 = fp.getCobrado9();
        cobrado10 = fp.getCobrado10();
        fechap1 = fp.getFechap1();
        fechap2 = fp.getFechap2();
        fechap3 = fp.getFechap3();
        fechap4 = fp.getFechap4();
        fechap5 = fp.getFechap5();
        fechap6 = fp.getFechap6();
        fechap7 = fp.getFechap7();
        fechap8 = fp.getFechap8();
        fechap9 = fp.getFechap9();
        fechap10 = fp.getFechap10();
        importep1 = fp.getImportep1();
        importep2 = fp.getImportep2();
        importep3 = fp.getImportep3();
        importep4 = fp.getImportep4();
        importep5 = fp.getImportep5();
        importep6 = fp.getImportep6();
        importep7 = fp.getImportep7();
        importep8 = fp.getImportep8();
        importep9 = fp.getImportep9();
        importep10 = fp.getImportep10();
        importev1 = fp.getImportev1();
        importev2 = fp.getImportev2();
        importev3 = fp.getImportev3();
        importev4 = fp.getImportev4();
        importev5 = fp.getImportev5();
        importev6 = fp.getImportev6();
        importev7 = fp.getImportev7();
        importev8 = fp.getImportev8();
        importev9 = fp.getImportev9();
        importev10 = fp.getImportev10();
        dtoprontopago = fp.getDtoprontopago();
        numplazosadelantados = fp.getNumplazosadelantados();
        numplazosvencimiento = fp.getNumplazosvencimiento();
        porcentajepago1 = fp.getPorcentajepago1();
        porcentajepago2 = fp.getPorcentajepago2();
        porcentajepago3 = fp.getPorcentajepago3();
        porcentajepago4 = fp.getPorcentajepago4();
        porcentajepago5 = fp.getPorcentajepago5();
        porcentajepago6 = fp.getPorcentajepago6();
        porcentajepago7 = fp.getPorcentajepago7();
        porcentajepago8 = fp.getPorcentajepago8();
        porcentajepago9 = fp.getPorcentajepago9();
        porcentajepago10 = fp.getPorcentajepago10();
        plazovm1 = fp.getPlazovm1();
        plazovm2 = fp.getPlazovm2();
        plazovm3 = fp.getPlazovm3();
        plazovm4 = fp.getPlazovm4();
        plazovm5 = fp.getPlazovm5();
        plazovm6 = fp.getPlazovm6();
        plazovm7 = fp.getPlazovm7();
        plazovm8 = fp.getPlazovm8();
        plazovm9 = fp.getPlazovm9();
        plazovm10 = fp.getPlazovm10();
        plazopm1 = fp.getPlazopm1();
        plazopm2 = fp.getPlazopm2();
        plazopm3 = fp.getPlazopm3();
        plazopm4 = fp.getPlazopm4();
        plazopm5 = fp.getPlazopm5();
        plazopm6 = fp.getPlazopm6();
        plazopm7 = fp.getPlazopm7();
        plazopm8 = fp.getPlazopm8();
        plazopm9 = fp.getPlazopm9();
        plazopm10 = fp.getPlazopm10();
        importeminimo = fp.getImporteminimo();
        diasprimerplazo = fp.getDiasprimerplazo();
        diasentreplazos = fp.getDiasentreplazos();
    }
    
    public FormaPago2 copiar(){
        FormaPago2 res = new FormaPago2();
        res.setCalculovencimientoautomatico(getCalculovencimientoautomatico());
        res.setCobrado1(getCobrado1());
        res.setCobrado2(getCobrado2());
        res.setCobrado3(getCobrado3());
        res.setCobrado4(getCobrado4());
        res.setCobrado5(getCobrado5());
        res.setCobrado6(getCobrado6());
        res.setCobrado7(getCobrado7());
        res.setCobrado8(getCobrado8());
        res.setCobrado9(getCobrado9());
        res.setCobrado10(getCobrado10());
        res.setCodigo(getCodigo());
        res.setDescripcioncliente(getDescripcioncliente());
        res.setDescripcionidentificativa(getDescripcionidentificativa());
        res.setDiasentreplazos(getDiasentreplazos());
        res.setDiasprimerplazo(getDiasprimerplazo());
        res.setDtoprontopago(getDtoprontopago());
        res.setEmitido1(getEmitido1());
        res.setEmitido2(getEmitido2());
        res.setEmitido3(getEmitido3());
        res.setEmitido4(getEmitido4());
        res.setEmitido5(getEmitido5());
        res.setEmitido6(getEmitido6());
        res.setEmitido7(getEmitido7());
        res.setEmitido8(getEmitido8());
        res.setEmitido9(getEmitido9());
        res.setEmitido10(getEmitido10());
        res.setFechap1(getFechap1());
        res.setFechap2(getFechap2());
        res.setFechap3(getFechap3());
        res.setFechap4(getFechap4());
        res.setFechap5(getFechap5());
        res.setFechap6(getFechap6());
        res.setFechap7(getFechap7());
        res.setFechap8(getFechap8());
        res.setFechap9(getFechap9());
        res.setFechap10(getFechap10());
        res.setIid_tr_p1(getIid_tr_p1());
        res.setIid_tr_p2(getIid_tr_p2());
        res.setIid_tr_p3(getIid_tr_p3());
        res.setIid_tr_p4(getIid_tr_p4());
        res.setIid_tr_p5(getIid_tr_p5());
        res.setIid_tr_p6(getIid_tr_p6());
        res.setIid_tr_p7(getIid_tr_p7());
        res.setIid_tr_p8(getIid_tr_p8());
        res.setIid_tr_p9(getIid_tr_p9());
        res.setIid_tr_p10(getIid_tr_p10());
        res.setIid_tr_v1(getIid_tr_v1());
        res.setIid_tr_v2(getIid_tr_v2());
        res.setIid_tr_v3(getIid_tr_v3());
        res.setIid_tr_v4(getIid_tr_v4());
        res.setIid_tr_v5(getIid_tr_v5());
        res.setIid_tr_v6(getIid_tr_v6());
        res.setIid_tr_v7(getIid_tr_v7());
        res.setIid_tr_v8(getIid_tr_v8());
        res.setIid_tr_v9(getIid_tr_v9());
        res.setIid_tr_v10(getIid_tr_v10());
        res.setImporteminimo(getImporteminimo());
        res.setImportep1(getImportep1());
        res.setImportep2(getImportep2());
        res.setImportep3(getImportep3());
        res.setImportep4(getImportep4());
        res.setImportep5(getImportep5());
        res.setImportep6(getImportep6());
        res.setImportep7(getImportep7());
        res.setImportep8(getImportep8());
        res.setImportep9(getImportep9());
        res.setImportep10(getImportep1());
        res.setImportev1(getImportev1());
        res.setImportev2(getImportev2());
        res.setImportev3(getImportev3());
        res.setImportev4(getImportev4());
        res.setImportev5(getImportev5());
        res.setImportev6(getImportev6());
        res.setImportev7(getImportev7());
        res.setImportev8(getImportev8());
        res.setImportev9(getImportev9());
        res.setImportev10(getImportev10());
        res.setImputado1(getImputado1());
        res.setImputado2(getImputado2());
        res.setImputado3(getImputado3());
        res.setImputado4(getImputado4());
        res.setImputado5(getImputado5());
        res.setImputado6(getImputado6());
        res.setImputado7(getImputado7());
        res.setImputado8(getImputado8());
        res.setImputado9(getImputado9());
        res.setImputado10(getImputado10());
        res.setNombreplazo1(getNombreplazo1());
        res.setNombreplazo2(getNombreplazo2());
        res.setNombreplazo3(getNombreplazo3());
        res.setNombreplazo4(getNombreplazo4());
        res.setNombreplazo5(getNombreplazo5());
        res.setNombreplazo6(getNombreplazo6());
        res.setNombreplazo7(getNombreplazo7());
        res.setNombreplazo8(getNombreplazo8());
        res.setNombreplazo9(getNombreplazo9());
        res.setNombreplazo10(getNombreplazo10());
        res.setNumplazosadelantados(getNumplazosadelantados());
        res.setNumplazosvencimiento(getNumplazosvencimiento());
        res.setPlazopm1(getPlazopm1());
        res.setPlazopm2(getPlazopm2());
        res.setPlazopm3(getPlazopm3());
        res.setPlazopm4(getPlazopm4());
        res.setPlazopm5(getPlazopm5());
        res.setPlazopm6(getPlazopm6());
        res.setPlazopm7(getPlazopm7());
        res.setPlazopm8(getPlazopm8());
        res.setPlazopm9(getPlazopm9());
        res.setPlazopm10(getPlazopm10());
        res.setPlazovm1(getPlazovm1());
        res.setPlazovm2(getPlazovm2());
        res.setPlazovm3(getPlazovm3());
        res.setPlazovm4(getPlazovm4());
        res.setPlazovm5(getPlazovm5());
        res.setPlazovm6(getPlazovm6());
        res.setPlazovm7(getPlazovm7());
        res.setPlazovm8(getPlazovm8());
        res.setPlazovm9(getPlazovm9());
        res.setPlazovm10(getPlazovm10());
        res.setPorcentajeautomatico(getPorcentajeautomatico());
        res.setPorcentajepago1(getPorcentajepago1());
        res.setPorcentajepago2(getPorcentajepago2());
        res.setPorcentajepago3(getPorcentajepago3());
        res.setPorcentajepago4(getPorcentajepago4());
        res.setPorcentajepago5(getPorcentajepago5());
        res.setPorcentajepago6(getPorcentajepago6());
        res.setPorcentajepago7(getPorcentajepago7());
        res.setPorcentajepago8(getPorcentajepago8());
        res.setPorcentajepago9(getPorcentajepago9());
        res.setPorcentajepago10(getPorcentajepago10());
        res.setRecibo1(getRecibo1());
        res.setRecibo2(getRecibo2());
        res.setRecibo3(getRecibo3());
        res.setRecibo4(getRecibo4());
        res.setRecibo5(getRecibo5());
        res.setRecibo6(getRecibo6());
        res.setRecibo7(getRecibo7());
        res.setRecibo8(getRecibo8());
        res.setRecibo9(getRecibo9());
        res.setRecibo10(getRecibo10());
        res.setTipodecalculo(getTipodecalculo());
        res.setTiporecibopago(getTiporecibopago());
        res.setTiporecibovencimiento(getTiporecibovencimiento());
        res.setCobradoVencimiento1(getCobradoVencimiento1());
        res.setCobradoVencimiento2(getCobradoVencimiento2());
        res.setCobradoVencimiento3(getCobradoVencimiento3());
        res.setCobradoVencimiento4(getCobradoVencimiento4());
        res.setCobradoVencimiento5(getCobradoVencimiento5());
        res.setCobradoVencimiento6(getCobradoVencimiento6());
        res.setCobradoVencimiento7(getCobradoVencimiento7());
        res.setCobradoVencimiento8(getCobradoVencimiento8());
        res.setCobradoVencimiento9(getCobradoVencimiento9());
        res.setCobradoVencimiento10(getCobradoVencimiento10());
        res.setEmitidoVencimiento1(getEmitidoVencimiento1());
        res.setEmitidoVencimiento2(getEmitidoVencimiento2());
        res.setEmitidoVencimiento3(getEmitidoVencimiento3());
        res.setEmitidoVencimiento4(getEmitidoVencimiento4());
        res.setEmitidoVencimiento5(getEmitidoVencimiento5());
        res.setEmitidoVencimiento6(getEmitidoVencimiento6());
        res.setEmitidoVencimiento7(getEmitidoVencimiento7());
        res.setEmitidoVencimiento8(getEmitidoVencimiento8());
        res.setEmitidoVencimiento9(getEmitidoVencimiento9());
        res.setEmitidoVencimiento10(getEmitidoVencimiento10());
        res.setImputadoVencimiento1(getImputadoVencimiento1());
        res.setImputadoVencimiento2(getImputadoVencimiento2());
        res.setImputadoVencimiento3(getImputadoVencimiento3());
        res.setImputadoVencimiento4(getImputadoVencimiento4());
        res.setImputadoVencimiento5(getImputadoVencimiento5());
        res.setImputadoVencimiento6(getImputadoVencimiento6());
        res.setImputadoVencimiento7(getImputadoVencimiento7());
        res.setImputadoVencimiento8(getImputadoVencimiento8());
        res.setImputadoVencimiento9(getImputadoVencimiento9());
        res.setImputadoVencimiento10(getImputadoVencimiento10());
        res.setReciboVencimiento1(getReciboVencimiento1());
        res.setReciboVencimiento2(getReciboVencimiento2());
        res.setReciboVencimiento3(getReciboVencimiento3());
        res.setReciboVencimiento4(getReciboVencimiento4());
        res.setReciboVencimiento5(getReciboVencimiento5());
        res.setReciboVencimiento6(getReciboVencimiento6());
        res.setReciboVencimiento7(getReciboVencimiento7());
        res.setReciboVencimiento8(getReciboVencimiento8());
        res.setReciboVencimiento9(getReciboVencimiento9());
        res.setReciboVencimiento10(getReciboVencimiento10());
        res.setFechaPlazo1(getFechaPlazo1());
        res.setFechaPlazo2(getFechaPlazo2());
        res.setFechaPlazo3(getFechaPlazo3());
        res.setFechaPlazo4(getFechaPlazo4());
        res.setFechaPlazo5(getFechaPlazo5());
        res.setFechaPlazo6(getFechaPlazo6());
        res.setFechaPlazo7(getFechaPlazo7());
        res.setFechaPlazo8(getFechaPlazo8());
        res.setFechaPlazo9(getFechaPlazo9());
        res.setFechaPlazo10(getFechaPlazo10());
        return res;
    }
    
}
