package bean;

public class TipoProducto {
    
    private Integer iid;
    private Empresa iid_empresa;
    private String cod_tipo;
    private String descripcion;
    private TipoControl iid_tipo_control;
    private Boolean act_stock;
    private Boolean stock_neg;
    private Boolean stock_medida;
    private Boolean stock_color;
    private Agentes iid_prov_hab;
    private FamiliaVenta iid_fam_venta;
    private Float iva;
    private Boolean activo;
    
    public TipoProducto(){
        
    }

    public Boolean getAct_stock() {
        return act_stock;
    }

    public void setAct_stock(Boolean act_stock) {
        this.act_stock = act_stock;
    }

    public String getCod_tipo() {
        return cod_tipo;
    }

    public void setCod_tipo(String cod_tipo) {
        this.cod_tipo = cod_tipo;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public Integer getIid() {
        return iid;
    }

    public void setIid(Integer iid) {
        this.iid = iid;
    }

    public Empresa getIid_empresa() {
        return iid_empresa;
    }

    public void setIid_empresa(Empresa iid_empresa) {
        this.iid_empresa = iid_empresa;
    }

    public FamiliaVenta getIid_fam_venta() {
        return iid_fam_venta;
    }

    public void setIid_fam_venta(FamiliaVenta iid_fam_venta) {
        this.iid_fam_venta = iid_fam_venta;
    }

    public Agentes getIid_prov_hab() {
        return iid_prov_hab;
    }

    public void setIid_prov_hab(Agentes iid_prov_hab) {
        this.iid_prov_hab = iid_prov_hab;
    }

    public TipoControl getIid_tipo_control() {
        return iid_tipo_control;
    }

    public void setIid_tipo_control(TipoControl iid_tipo_control) {
        this.iid_tipo_control = iid_tipo_control;
    }

    public Float getIva() {
        return iva;
    }

    public void setIva(Float iva) {
        this.iva = iva;
    }

    public Boolean getStock_color() {
        return stock_color;
    }

    public void setStock_color(Boolean stock_color) {
        this.stock_color = stock_color;
    }

    public Boolean getStock_medida() {
        return stock_medida;
    }

    public void setStock_medida(Boolean stock_medida) {
        this.stock_medida = stock_medida;
    }

    public Boolean getStock_neg() {
        return stock_neg;
    }

    public void setStock_neg(Boolean stock_neg) {
        this.stock_neg = stock_neg;
    }

    public Boolean getActivo() {
        return activo;
    }

    public void setActivo(Boolean activo) {
        this.activo = activo;
    }
}
