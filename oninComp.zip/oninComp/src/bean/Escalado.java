package bean;

public class Escalado {

    private Integer iid;
    private Integer dimension1;
    private Integer dimension2;
    private Float precio;
    private Articulo articulo;
    private Caracteristica caracteristica;

    public Articulo getArticulo() {
        return articulo;
    }

    public void setArticulo(Articulo articulo) {
        this.articulo = articulo;
    }

    public Caracteristica getCaracteristica() {
        return caracteristica;
    }

    public void setCaracteristica(Caracteristica caracteristica) {
        this.caracteristica = caracteristica;
    }

    public Integer getDimension1() {
        return dimension1;
    }

    public void setDimension1(Integer dimension1) {
        this.dimension1 = dimension1;
    }

    public Integer getDimension2() {
        return dimension2;
    }

    public void setDimension2(Integer dimension2) {
        this.dimension2 = dimension2;
    }

    public Integer getIid() {
        return iid;
    }

    public void setIid(Integer iid) {
        this.iid = iid;
    }

    public Float getPrecio() {
        return precio;
    }

    public void setPrecio(Float precio) {
        this.precio = precio;
    }
    
    @Override
    public boolean equals(Object o){
        Escalado e = (Escalado)o;
        if(e.getCaracteristica() == null){
            return this.getDimension1().equals(e.getDimension1()) && this.getDimension2().equals(e.getDimension2());
        } else {
            return this.getDimension1().equals(e.getDimension1()) && this.getDimension2().equals(e.getDimension2()) && this.getCaracteristica().getIid_color().equals(e.getCaracteristica().getIid_color());
        }
    }
}
