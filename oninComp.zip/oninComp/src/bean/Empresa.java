package bean;

public class Empresa {
    
    private Integer iid;
    private String cod_empresa;
    private String desc_empresa;
    private String dire_empresa;
    private String pobla_empresa;
    private String provi_empresa;
    private String cp_empresa;
    private String cuenta_empresa;
    private String logo;
    private String cif;
    private byte[] imagen;
    private String urlWeb;
    private String email;
    private String telefono;
    private String fax;
    
    public Empresa(){

    }

    public String getCod_empresa() {
        return cod_empresa;
    }

    public void setCod_empresa(String cod_empresa) {
        this.cod_empresa = cod_empresa;
    }

    public String getDesc_empresa() {
        return desc_empresa;
    }

    public void setDesc_empresa(String desc_empresa) {
        this.desc_empresa = desc_empresa;
    }

    public Integer getIid() {
        return iid;
    }

    public void setIid(Integer iid) {
        this.iid = iid;
    }

     public String getDire_empresa() {
        return dire_empresa;
    }

    public void setDire_empresa(String dire_empresa) {
        this.dire_empresa = dire_empresa;
    }

       public String getPobla_empresa() {
        return pobla_empresa;
    }

    public void setPobla_empresa(String pobla_empresa) {
        this.pobla_empresa = pobla_empresa;
    }

       public String getProvi_empresa() {
        return provi_empresa;
    }

    public void setProvi_empresa(String provi_empresa) {
        this.provi_empresa = provi_empresa;
    }

       public String getCp_empresa() {
        return cp_empresa;
    }

    public void setCp_empresa(String cp_empresa) {
        this.cp_empresa = cp_empresa;
    }

     public String getCuenta_empresa() {
        return cuenta_empresa;
    }

    public void setCuenta_empresa(String cuenta_empresa) {
        this.cuenta_empresa = cuenta_empresa;
    }

    public String getLogo() {
        return logo;
    }

    public void setLogo(String logo) {
        this.logo = logo;
    }

    public String getCif() {
        return cif;
    }

    public void setCif(String cif) {
        this.cif = cif;
    }

    public byte[] getImagen() {
        return imagen;
    }

    public void setImagen(byte[] imagen) {
        this.imagen = imagen;
    }

    public String getUrlWeb() {
        return urlWeb;
    }

    public void setUrlWeb(String urlWeb) {
        this.urlWeb = urlWeb;
    }
    
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getFax() {
        return fax;
    }

    public void setFax(String fax) {
        this.fax = fax;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }
 
}
