package bean;

import java.util.Date;

public class PresupuestoHistorico {
    private Integer iid;
    private String numero;
    private Date fecha;
    private FormaPago2 fp;
    private double importe_total;
    private EstadoDocumento estado;
    private String serie;
    private double dto;
    private Empresa empresa;
    private ClaseDocumento clase_documento;
    private Boolean desde_presupuesto;
    private Boolean convertido;
    private Integer documento;
    private String nota_documento;
    private Iva iva;
    private String referencia;
    private String codigoCliente;
    private String nombreCliente;
    private String domicilioCliente;
    private String localidadCliente;
    private String provinciaCliente;
    private String telefonoCliente;
    private String cifCliente;
    private String cpCliente;
    private String paisCliente;
    private Boolean pagado;
    private Comercial comercial;
    private String contactado;
    private Boolean pagadoComercial;
    private Float porcentajeComercial;
    private String observaciones;
    private Date fechaEntrega;
    private String recomendadoPor;
    private String emailCliente;
    private Boolean preparado;
    private Boolean confeccionado;
    private Boolean fabricado;
    private Boolean impagado;

    private Boolean instalado;
    private Almacen almacen;
    private Integer medicion;
    private Integer interlocutor;

    
    public PresupuestoHistorico() {
    
    }
    
    public PresupuestoHistorico(Presupuesto p){
        this.cifCliente = p.getCifCliente();
        this.clase_documento = p.getClase_documento();
        this.codigoCliente = p.getCodigoCliente();
        this.comercial = p.getComercial();
        this.confeccionado = p.getConfeccionado();
        this.contactado = p.getContactado();
        this.convertido = p.getConvertido();
        this.cpCliente = p.getCpCliente();
        this.desde_presupuesto = p.getDesde_presupuesto();
        this.domicilioCliente = p.getDomicilioCliente();
        this.dto = p.getDto();
        this.emailCliente = p.getEmailCliente();
        this.empresa = p.getEmpresa();
        this.estado = p.getEstado();
        this.fabricado = p.getFabricado();
        this.fecha = new Date(p.getFecha());
        this.fechaEntrega = new Date(p.getFechaEntrega());
        this.fp = p.getFp();
        this.importe_total = p.getImporte_total();
        this.iva = p.getIva();
        this.localidadCliente = p.getLocalidadCliente();
        this.nombreCliente = p.getNombreCliente();
        this.nota_documento = p.getNota_documento();
        this.numero = p.getNumero();
        this.observaciones = p.getObservaciones();
        this.pagado = p.getPagado();
        this.pagadoComercial = p.getPagadoComercial();
        this.paisCliente = p.getPaisCliente();
        this.porcentajeComercial = p.getPorcentajeComercial();
        this.preparado = p.getPreparado();
        this.provinciaCliente = p.getProvinciaCliente();
        this.recomendadoPor = p.getRecomendadoPor();
        this.referencia = p.getReferencia();
        this.serie = p.getSerie();
        this.telefonoCliente = p.getTelefonoCliente();
        this.impagado = p.getImpagado();

        //this.instalado = p.getInstalado();
        //this.almacen = p.getAlmacen();
        //this.medicion = p.getMedicion();
        //this.interlocutor = p.getInterlocutor();
    }

    public double getDto() {
        return dto;
    }

    public void setDto(double dto) {
        this.dto = dto;
    }

    public EstadoDocumento getEstado() {
        return estado;
    }

    public void setEstado(EstadoDocumento estado) {
        this.estado = estado;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public FormaPago2 getFp() {
        return fp;
    }

    public void setFp(FormaPago2 fp) {
        this.fp = fp;
    }

    public Integer getIid() {
        return iid;
    }

    public void setIid(Integer iid) {
        this.iid = iid;
    }

    public double getImporte_total() {
        return importe_total;
    }

    public void setImporte_total(double importe_total) {
        this.importe_total = importe_total;
    }

    public String getSerie() {
        return serie;
    }

    public void setSerie(String serie) {
        this.serie = serie;
    }

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public Empresa getEmpresa() {
        return empresa;
    }

    public void setEmpresa(Empresa empresa) {
        this.empresa = empresa;
    }

    public ClaseDocumento getClase_documento() {
        return clase_documento;
    }

    public void setClase_documento(ClaseDocumento clase_documento) {
        this.clase_documento = clase_documento;
    }

    public Boolean getDesde_presupuesto() {
        return desde_presupuesto;
    }

    public void setDesde_presupuesto(Boolean desde_presupuesto) {
        this.desde_presupuesto = desde_presupuesto;
    }

    public Boolean getConvertido() {
        return convertido;
    }

    public void setConvertido(Boolean convertido) {
        this.convertido = convertido;
    }

    public Integer getDocumento() {
        return documento;
    }

    public void setDocumento(Integer documento) {
        this.documento = documento;
    }

    public String getNota_documento() {
        return nota_documento;
    }

    public void setNota_documento(String nota_documento) {
        this.nota_documento = nota_documento;
    }

    public Iva getIva() {
        return iva;
    }

    public void setIva(Iva iva) {
        this.iva = iva;
    }

    public String getReferencia() {
        return referencia;
    }

    public void setReferencia(String referencia) {
        this.referencia = referencia;
    }

    public String getCifCliente() {
        return cifCliente;
    }

    public void setCifCliente(String cifCliente) {
        this.cifCliente = cifCliente;
    }

    public String getCodigoCliente() {
        return codigoCliente;
    }

    public void setCodigoCliente(String codigoCliente) {
        this.codigoCliente = codigoCliente;
    }

    public String getCpCliente() {
        return cpCliente;
    }

    public void setCpCliente(String cpCliente) {
        this.cpCliente = cpCliente;
    }

    public String getDomicilioCliente() {
        return domicilioCliente;
    }

    public void setDomicilioCliente(String domicilioCliente) {
        this.domicilioCliente = domicilioCliente;
    }

    public String getLocalidadCliente() {
        return localidadCliente;
    }

    public void setLocalidadCliente(String localidadCliente) {
        this.localidadCliente = localidadCliente;
    }

    public String getNombreCliente() {
        return nombreCliente;
    }

    public void setNombreCliente(String nombreCliente) {
        this.nombreCliente = nombreCliente;
    }

    public String getPaisCliente() {
        return paisCliente;
    }

    public void setPaisCliente(String paisCliente) {
        this.paisCliente = paisCliente;
    }

    public String getProvinciaCliente() {
        return provinciaCliente;
    }

    public void setProvinciaCliente(String provinciaCliente) {
        this.provinciaCliente = provinciaCliente;
    }

    public String getTelefonoCliente() {
        return telefonoCliente;
    }

    public void setTelefonoCliente(String telefonoCliente) {
        this.telefonoCliente = telefonoCliente;
    }

    public Boolean getPagado() {
        return pagado;
    }

    public void setPagado(Boolean pagado) {
        this.pagado = pagado;
    }

    public Comercial getComercial() {
        return comercial;
    }

    public void setComercial(Comercial comercial) {
        this.comercial = comercial;
    }

    public String getContactado() {
        return contactado;
    }

    public void setContactado(String contactado) {
        this.contactado = contactado;
    }

    public Boolean getPagadoComercial() {
        return pagadoComercial;
    }

    public void setPagadoComercial(Boolean pagadoComercial) {
        this.pagadoComercial = pagadoComercial;
    }

    public Float getPorcentajeComercial() {
        return porcentajeComercial;
    }

    public void setPorcentajeComercial(Float porcentajeComercial) {
        this.porcentajeComercial = porcentajeComercial;
    }

    public String getObservaciones() {
        return observaciones;
    }

    public void setObservaciones(String observaciones) {
        this.observaciones = observaciones;
    }

    public Date getFechaEntrega() {
        return fechaEntrega;
    }

    public void setFechaEntrega(Date fechaEntrega) {
        this.fechaEntrega = fechaEntrega;
    }

    public String getRecomendadoPor() {
        return recomendadoPor;
    }

    public void setRecomendadoPor(String recomendadoPor) {
        this.recomendadoPor = recomendadoPor;
    }

    public String getEmailCliente() {
        return emailCliente;
    }

    public void setEmailCliente(String emailCliente) {
        this.emailCliente = emailCliente;
    }

    public Boolean getConfeccionado() {
        return confeccionado;
    }

    public void setConfeccionado(Boolean confeccionado) {
        this.confeccionado = confeccionado;
    }

    public Boolean getFabricado() {
        return fabricado;
    }

    public void setFabricado(Boolean fabricado) {
        this.fabricado = fabricado;
    }

    public Boolean getPreparado() {
        return preparado;
    }

    public void setPreparado(Boolean preparado) {
        this.preparado = preparado;
    }

    public Boolean getImpagado() {
        return impagado;
    }

    public void setImpagado(Boolean impagado) {
        this.impagado = impagado;
    }

    public Almacen getAlmacen() {
        return almacen;
    }

    public void setAlmacen(Almacen almacen) {
        this.almacen = almacen;
    }

    public Boolean getInstalado() {
        return instalado;
    }

    public void setInstalado(Boolean instalado) {
        this.instalado = instalado;
    }

    public Integer getInterlocutor() {
        return interlocutor;
    }

    public void setInterlocutor(Integer interlocutor) {
        this.interlocutor = interlocutor;
    }

    public Integer getMedicion() {
        return medicion;
    }

    public void setMedicion(Integer medicion) {
        this.medicion = medicion;
    }
    
    
    
}
