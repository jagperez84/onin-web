package bean;

public class Mensajes {

    private int iid;
    private int iidEmpresa;
    private int iidDocumento;
    private int iidTipoDocumento;
    private String asunto;
    private String cuerpo;
    private Usuario usuario ;
    private String fecha;
    private String hora;
    private String leido;

    public int getIid() {
        return iid;
    }

    public void setIid(int iid) {
        this.iid = iid;
    }

    public int getIidEmpresa() {
        return iidEmpresa;
    }

    public void setIidEmpresa(int iidEmpresa) {
        this.iidEmpresa = iidEmpresa;
    }

    public String getAsunto() {
        return asunto;
    }

    public void setAsunto(String asunto) {
        this.asunto = asunto;
    }

    public String getCuerpo() {
        return cuerpo;
    }

    public void setCuerpo(String cuerpo) {
        this.cuerpo = cuerpo;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public String getHora() {
        return hora;
    }

    public void setHora(String hora) {
        this.hora = hora;
    }

    public String getLeido() {
        return leido;
    }

    public void setLeido(String leido) {
        this.leido = leido;
    }

    public int getIidDocumento() {
        return iidDocumento;
    }

    public void setIidDocumento(int iidDocumento) {
        this.iidDocumento = iidDocumento;
    }

    public int getIidTipoDocumento() {
        return iidTipoDocumento;
    }

    public void setIidTipoDocumento(int iidTipoDocumento) {
        this.iidTipoDocumento = iidTipoDocumento;
    }
    
    

         
   }
