package bean;

public class Interlocutor {
    private Integer iid;
    private Empresa empresaMadre;
    private Empresa empresaHija;
    private Agentes iidCliente;

    public Interlocutor() {
    
    }
    
    public Empresa getEmpresaHija() {
        return empresaHija;
    }

    public void setEmpresaHija(Empresa empresaHija) {
        this.empresaHija = empresaHija;
    }

    public Empresa getEmpresaMadre() {
        return empresaMadre;
    }

    public void setEmpresaMadre(Empresa empresaMadre) {
        this.empresaMadre = empresaMadre;
    }

    public Integer getIid() {
        return iid;
    }

    public void setIid(Integer iid) {
        this.iid = iid;
    }

    public Agentes getIidCliente() {
        return iidCliente;
    }

    public void setIidCliente(Agentes iidCliente) {
        this.iidCliente = iidCliente;
    }    

}
