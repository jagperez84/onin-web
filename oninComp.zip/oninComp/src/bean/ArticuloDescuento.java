package bean;

public class ArticuloDescuento {
    private Integer iid;
    private Articulo articulo;
    private TipoToldo tipoToldo;
    private Double largoLona;
    private Double anchoLona;
    private Double tuboEnrrollado;
    private Double perfilCarga;

    public Double getAnchoLona() {
        return anchoLona;
    }

    public void setAnchoLona(Double anchoLona) {
        this.anchoLona = anchoLona;
    }

    public Articulo getArticulo() {
        return articulo;
    }

    public void setArticulo(Articulo articulo) {
        this.articulo = articulo;
    }

    public Integer getIid() {
        return iid;
    }

    public void setIid(Integer iid) {
        this.iid = iid;
    }

    public Double getLargoLona() {
        return largoLona;
    }

    public void setLargoLona(Double largoLona) {
        this.largoLona = largoLona;
    }

    public Double getPerfilCarga() {
        return perfilCarga;
    }

    public void setPerfilCarga(Double perfilCarga) {
        this.perfilCarga = perfilCarga;
    }

    public TipoToldo getTipoToldo() {
        return tipoToldo;
    }

    public void setTipoToldo(TipoToldo tipoToldo) {
        this.tipoToldo = tipoToldo;
    }

    public Double getTuboEnrrollado() {
        return tuboEnrrollado;
    }

    public void setTuboEnrrollado(Double tuboEnrrollado) {
        this.tuboEnrrollado = tuboEnrrollado;
    }
    
    @Override
    public boolean equals(Object o){
        ArticuloDescuento ad = (ArticuloDescuento)o;
        return ad.getTipoToldo().getIid().equals(this.tipoToldo.getIid());
    }

    public ArticuloDescuento clonar (){
        ArticuloDescuento res = new ArticuloDescuento();
        res.setIid(iid);
        res.setArticulo(articulo);
        res.setTipoToldo(tipoToldo);
        res.setLargoLona(largoLona);
        res.setAnchoLona(anchoLona);
        res.setTuboEnrrollado(tuboEnrrollado);
        res.setPerfilCarga(perfilCarga);
        return res;
    }
}
