package bean;

import acceso.BaseDatos;

public class FormulaArticuloProv {
    private Integer iid;
    private Integer iidArticulo;
    private Integer iidEmpresa;
    private Integer iidProveedor;    
    private String  formula;

    public Integer getIid() {
        return iid;
    }

    public void setIid(Integer iid) {
        this.iid = iid;
    }
   

    public Integer getIidArticulo() {
        return iidArticulo;
    }

    public void setIidArticulo(Integer iidArticulo) {
        this.iidArticulo = iidArticulo;
    }

    public Integer getIidEmpresa() {
        return iidEmpresa;
    }

    public void setIidEmpresa(Integer iidEmpresa) {
        this.iidEmpresa = iidEmpresa;
    }

    public String getFormula() {
        return formula;
    }

    public void setFormula(String formula) {
        this.formula = formula;
    }

    public Integer getIidProveedor() {
        return iidProveedor;
    }

    public void setIidProveedor(Integer iidProveedor) {
        this.iidProveedor = iidProveedor;
    }
 
    

}
