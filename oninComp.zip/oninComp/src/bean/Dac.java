package bean;

public class Dac {
    private Integer iid;
    private Articulo articulo;
    private Colores clacado;
    private Colores caccesorios;
    private Double medida1;
    private Double medida2;
    private Double medida3;
    private Double medida4;
    private Double medida5;
    private Double cantidad;
    private String descripcion;
    
    private String tipoPlantilla;
    
    private Boolean casquillo;
    private Boolean soporte;
    private Boolean tapa;
    private Boolean maquina;
    private Boolean terminal;
    private Boolean poleaIzquierda;
    private Boolean poleaDerecha;
    private Boolean lona;
    private Boolean lonaDoble;
    
    private Boolean carruchaSimple, carruchaDoble, atacuerda, atacuerdaPared, tuboEnrrolle;
    private Boolean manivela, gancho, motor, cofre, forma, bambolina, perfil, brazo;
    
    private Boolean perfilCofre;
    
    public Dac(){
    }

    public Integer getIid() {
        return iid;
    }

    public void setIid(Integer iid) {
        this.iid = iid;
    }

    public Articulo getArticulo() {
        return articulo;
    }

    public void setArticulo(Articulo articulo) {
        this.articulo = articulo;
    }

    public Colores getCaccesorios() {
        return caccesorios;
    }

    public void setCaccesorios(Colores caccesorios) {
        this.caccesorios = caccesorios;
    }

    public Colores getClacado() {
        return clacado;
    }

    public void setClacado(Colores clacado) {
        this.clacado = clacado;
    }

    public Double getMedida1() {
        return medida1;
    }

    public void setMedida1(Double medida1) {
        this.medida1 = medida1;
    }

    public Double getMedida2() {
        return medida2;
    }

    public void setMedida2(Double medida2) {
        this.medida2 = medida2;
    }

    public Double getMedida3() {
        return medida3;
    }

    public void setMedida3(Double medida3) {
        this.medida3 = medida3;
    }

    public Double getMedida4() {
        return medida4;
    }

    public void setMedida4(Double medida4) {
        this.medida4 = medida4;
    }

    public Double getMedida5() {
        return medida5;
    }

    public void setMedida5(Double medida5) {
        this.medida5 = medida5;
    }

    public Double getCantidad() {
        return cantidad;
    }

    public void setCantidad(Double cantidad) {
        this.cantidad = cantidad;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getTipoPlantilla() {
        return tipoPlantilla;
    }

    public void setTipoPlantilla(String tipoPlantilla) {
        this.tipoPlantilla = tipoPlantilla;
    }

    public Boolean getCasquillo() {
        return casquillo;
    }

    public void setCasquillo(Boolean casquillo) {
        this.casquillo = casquillo;
    }

    public Boolean getLona() {
        return lona;
    }

    public void setLona(Boolean lona) {
        this.lona = lona;
    }

    public Boolean getLonaDoble() {
        return lonaDoble;
    }

    public void setLonaDoble(Boolean lonaDoble) {
        this.lonaDoble = lonaDoble;
    }

    public Boolean getMaquina() {
        return maquina;
    }

    public void setMaquina(Boolean maquina) {
        this.maquina = maquina;
    }

    public Boolean getPoleaDerecha() {
        return poleaDerecha;
    }

    public void setPoleaDerecha(Boolean poleaDerecha) {
        this.poleaDerecha = poleaDerecha;
    }

    public Boolean getPoleaIzquierda() {
        return poleaIzquierda;
    }

    public void setPoleaIzquierda(Boolean poleaIzquierda) {
        this.poleaIzquierda = poleaIzquierda;
    }

    public Boolean getSoporte() {
        return soporte;
    }

    public void setSoporte(Boolean soporte) {
        this.soporte = soporte;
    }

    public Boolean getTapa() {
        return tapa;
    }

    public void setTapa(Boolean tapa) {
        this.tapa = tapa;
    }

    public Boolean getTerminal() {
        return terminal;
    }

    public void setTerminal(Boolean terminal) {
        this.terminal = terminal;
    }

    public Boolean getAtacuerda() {
        return atacuerda;
    }

    public void setAtacuerda(Boolean atacuerda) {
        this.atacuerda = atacuerda;
    }

    public Boolean getAtacuerdaPared() {
        return atacuerdaPared;
    }

    public void setAtacuerdaPared(Boolean atacuerdaPared) {
        this.atacuerdaPared = atacuerdaPared;
    }

    public Boolean getBambolina() {
        return bambolina;
    }

    public void setBambolina(Boolean bambolina) {
        this.bambolina = bambolina;
    }

    public Boolean getBrazo() {
        return brazo;
    }

    public void setBrazo(Boolean brazo) {
        this.brazo = brazo;
    }

    public Boolean getCarruchaDoble() {
        return carruchaDoble;
    }

    public void setCarruchaDoble(Boolean carruchaDoble) {
        this.carruchaDoble = carruchaDoble;
    }

    public Boolean getCarruchaSimple() {
        return carruchaSimple;
    }

    public void setCarruchaSimple(Boolean carruchaSimple) {
        this.carruchaSimple = carruchaSimple;
    }

    public Boolean getCofre() {
        return cofre;
    }

    public void setCofre(Boolean cofre) {
        this.cofre = cofre;
    }

    public Boolean getForma() {
        return forma;
    }

    public void setForma(Boolean forma) {
        this.forma = forma;
    }

    public Boolean getGancho() {
        return gancho;
    }

    public void setGancho(Boolean gancho) {
        this.gancho = gancho;
    }

    public Boolean getManivela() {
        return manivela;
    }

    public void setManivela(Boolean manivela) {
        this.manivela = manivela;
    }

    public Boolean getMotor() {
        return motor;
    }

    public void setMotor(Boolean motor) {
        this.motor = motor;
    }

    public Boolean getPerfil() {
        return perfil;
    }

    public void setPerfil(Boolean perfil) {
        this.perfil = perfil;
    }

    public Boolean getTuboEnrrolle() {
        return tuboEnrrolle;
    }

    public void setTuboEnrrolle(Boolean tuboEnrrolle) {
        this.tuboEnrrolle = tuboEnrrolle;
    }
    
    public Boolean getPerfilCofre() {
        return perfilCofre;
    }

    public void setPerfilCofre(Boolean perfilCofre) {
        this.perfilCofre = perfilCofre;
    }
}
