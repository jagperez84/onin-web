package bean;

public class ClaseDocumento {
    private Integer iid;
    private String descripcion;
    
    public ClaseDocumento(){
        
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public Integer getIid() {
        return iid;
    }

    public void setIid(Integer iid) {
        this.iid = iid;
    }

   

}
