package bean;

public class Auditoria {

    private Integer iid;
    private String codigo_objeto;
    private String usuario;
    private String accion;
    private Long fecha;
    private String hora;
    private String empresa;

    public Auditoria() {
    }

    public String getcodigo_objeto() {
        return codigo_objeto;
    }

    public void setcodigo_objeto(String codigo_objeto) {
        this.codigo_objeto = codigo_objeto;
    }

     public Integer getiid() {
        return iid;
    }

    public void setiid(Integer iid) {
        this.iid = iid;
    }

    public String getusuario() {
        return usuario;
    }

    public void setusuario(String usuario) {
        this.usuario = usuario;
    }

    public String getaccion() {
        return accion;
    }

    public void setaccion(String accion) {
        this.accion = accion;
    }

    public Long getfecha() {
        return fecha;
    }

    public void setfecha(Long fecha) {
        this.fecha = fecha;
    }

    public String gethora() {
        return hora;
    }

    public void sethora(String hora) {
        this.hora = hora;
    }

        public String getempresa() {
        return empresa;
    }

    public void setempresa(String empresa) {
        this.empresa = empresa;
    }

}
