package bean;

public class FormaPago {

    private Integer iid;
    private String codigo;
    private String descripcionidentificativa;
    private String descripcioncliente;
    private Double dtoprontopago = 0.0;
    private Integer numplazosadelantados = 0;
    private String tiporecibopago;
    private String nombreplazo1;
    private String nombreplazo2;
    private String nombreplazo3;
    private String nombreplazo4;
    private String nombreplazo5;
    private String nombreplazo6;
    private String nombreplazo7;
    private String nombreplazo8;
    private String nombreplazo9;
    private String nombreplazo10;
    private Double porcentajepago1 = 0.0;
    private Double porcentajepago2 = 0.0;
    private Double porcentajepago3 = 0.0;
    private Double porcentajepago4 = 0.0;
    private Double porcentajepago5 = 0.0;
    private Double porcentajepago6 = 0.0;
    private Double porcentajepago7 = 0.0;
    private Double porcentajepago8 = 0.0;
    private Double porcentajepago9 = 0.0;
    private Double porcentajepago10 = 0.0;
    private Integer numplazosvencimiento = 0;
    private String tiporecibovencimiento;
    private String tipodecalculo;
    private Double importeminimo = 0.0;
    private Integer diasprimerplazo = 0;
    private Integer diasentreplazos = 0;
    private Integer plazovm1 = 0;
    private Integer plazovm2 = 0;
    private Integer plazovm3 = 0;
    private Integer plazovm4 = 0;
    private Integer plazovm5 = 0;
    private Integer plazovm6 = 0;
    private Integer plazovm7 = 0;
    private Integer plazovm8 = 0;
    private Integer plazovm9 = 0;
    private Integer plazovm10 = 0;
    private Double plazopm1 = 0.0;
    private Double plazopm2 = 0.0;
    private Double plazopm3 = 0.0;
    private Double plazopm4 = 0.0;
    private Double plazopm5 = 0.0;
    private Double plazopm6 = 0.0;
    private Double plazopm7 = 0.0;
    private Double plazopm8 = 0.0;
    private Double plazopm9 = 0.0;
    private Double plazopm10 = 0.0;
    private Boolean calculovencimientoautomatico;
    private Boolean porcentajeautomatico;
    private TipoRecibo iid_tr_p1;
    private TipoRecibo iid_tr_p2;
    private TipoRecibo iid_tr_p3;
    private TipoRecibo iid_tr_p4;
    private TipoRecibo iid_tr_p5;
    private TipoRecibo iid_tr_p6;
    private TipoRecibo iid_tr_p7;
    private TipoRecibo iid_tr_p8;
    private TipoRecibo iid_tr_p9;
    private TipoRecibo iid_tr_p10;
    private TipoRecibo iid_tr_v1;
    private TipoRecibo iid_tr_v2;
    private TipoRecibo iid_tr_v3;
    private TipoRecibo iid_tr_v4;
    private TipoRecibo iid_tr_v5;
    private TipoRecibo iid_tr_v6;
    private TipoRecibo iid_tr_v7;
    private TipoRecibo iid_tr_v8;
    private TipoRecibo iid_tr_v9;
    private TipoRecibo iid_tr_v10;
    private String cobrado1;
    private String cobrado2;
    private String cobrado3;
    private String cobrado4;
    private String cobrado5;
    private String cobrado6;
    private String cobrado7;
    private String cobrado8;
    private String cobrado9;
    private String cobrado10;
    private Long fechap1;
    private Long fechap2;
    private Long fechap3;
    private Long fechap4;
    private Long fechap5;
    private Long fechap6;
    private Long fechap7;
    private Long fechap8;
    private Long fechap9;
    private Long fechap10;
    private Double importep1;
    private Double importep2;
    private Double importep3;
    private Double importep4;
    private Double importep5;
    private Double importep6;
    private Double importep7;
    private Double importep8;
    private Double importep9;
    private Double importep10;
    private Double importev1;
    private Double importev2;
    private Double importev3;
    private Double importev4;
    private Double importev5;
    private Double importev6;
    private Double importev7;
    private Double importev8;
    private Double importev9;
    private Double importev10;

    public Double getPlazopm4() {
        return plazopm4;
    }

    public void setPlazopm4(Double Plazopm4) {
        this.plazopm4 = Plazopm4;
    }

    public Boolean getCalculovencimientoautomatico() {
        return calculovencimientoautomatico;
    }

    public void setCalculovencimientoautomatico(Boolean calculovencimientoautomatico) {
        this.calculovencimientoautomatico = calculovencimientoautomatico;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getDescripcioncliente() {
        return descripcioncliente;
    }

    public void setDescripcioncliente(String descripcioncliente) {
        this.descripcioncliente = descripcioncliente;
    }

    public String getDescripcionidentificativa() {
        return descripcionidentificativa;
    }

    public void setDescripcionidentificativa(String descripcionidentificativa) {
        this.descripcionidentificativa = descripcionidentificativa;
    }

    public Integer getDiasentreplazos() {
        return diasentreplazos;
    }

    public void setDiasentreplazos(Integer diasentreplazos) {
        this.diasentreplazos = diasentreplazos;
    }

    public Integer getDiasprimerplazo() {
        return diasprimerplazo;
    }

    public void setDiasprimerplazo(Integer diasprimerplazo) {
        this.diasprimerplazo = diasprimerplazo;
    }

    public Double getDtoprontopago() {
        return dtoprontopago;
    }

    public void setDtoprontopago(Double dtoprontopago) {
        this.dtoprontopago = dtoprontopago;
    }

    public Integer getIid() {
        return iid;
    }

    public void setIid(Integer iid) {
        this.iid = iid;
    }

    public Double getImporteminimo() {
        return importeminimo;
    }

    public void setImporteminimo(Double importeminimo) {
        this.importeminimo = importeminimo;
    }

    public String getNombreplazo1() {
        return nombreplazo1;
    }

    public void setNombreplazo1(String nombreplazo1) {
        this.nombreplazo1 = nombreplazo1;
    }

    public String getNombreplazo10() {
        return nombreplazo10;
    }

    public void setNombreplazo10(String nombreplazo10) {
        this.nombreplazo10 = nombreplazo10;
    }

    public String getNombreplazo2() {
        return nombreplazo2;
    }

    public void setNombreplazo2(String nombreplazo2) {
        this.nombreplazo2 = nombreplazo2;
    }

    public String getNombreplazo3() {
        return nombreplazo3;
    }

    public void setNombreplazo3(String nombreplazo3) {
        this.nombreplazo3 = nombreplazo3;
    }

    public String getNombreplazo4() {
        return nombreplazo4;
    }

    public void setNombreplazo4(String nombreplazo4) {
        this.nombreplazo4 = nombreplazo4;
    }

    public String getNombreplazo5() {
        return nombreplazo5;
    }

    public void setNombreplazo5(String nombreplazo5) {
        this.nombreplazo5 = nombreplazo5;
    }

    public String getNombreplazo6() {
        return nombreplazo6;
    }

    public void setNombreplazo6(String nombreplazo6) {
        this.nombreplazo6 = nombreplazo6;
    }

    public String getNombreplazo7() {
        return nombreplazo7;
    }

    public void setNombreplazo7(String nombreplazo7) {
        this.nombreplazo7 = nombreplazo7;
    }

    public String getNombreplazo8() {
        return nombreplazo8;
    }

    public void setNombreplazo8(String nombreplazo8) {
        this.nombreplazo8 = nombreplazo8;
    }

    public String getNombreplazo9() {
        return nombreplazo9;
    }

    public void setNombreplazo9(String nombreplazo9) {
        this.nombreplazo9 = nombreplazo9;
    }

    public Integer getNumplazosadelantados() {
        return numplazosadelantados;
    }

    public void setNumplazosadelantados(Integer numplazosadelantados) {
        this.numplazosadelantados = numplazosadelantados;
    }

    public Integer getNumplazosvencimiento() {
        return numplazosvencimiento;
    }

    public void setNumplazosvencimiento(Integer numplazosvencimiento) {
        this.numplazosvencimiento = numplazosvencimiento;
    }

    public Double getPlazopm1() {
        return plazopm1;
    }

    public void setPlazopm1(Double plazopm1) {
        this.plazopm1 = plazopm1;
    }

    public Double getPlazopm10() {
        return plazopm10;
    }

    public void setPlazopm10(Double plazopm10) {
        this.plazopm10 = plazopm10;
    }

    public Double getPlazopm2() {
        return plazopm2;
    }

    public void setPlazopm2(Double plazopm2) {
        this.plazopm2 = plazopm2;
    }

    public Double getPlazopm3() {
        return plazopm3;
    }

    public void setPlazopm3(Double plazopm3) {
        this.plazopm3 = plazopm3;
    }

    public Double getPlazopm5() {
        return plazopm5;
    }

    public void setPlazopm5(Double plazopm5) {
        this.plazopm5 = plazopm5;
    }

    public Double getPlazopm6() {
        return plazopm6;
    }

    public void setPlazopm6(Double plazopm6) {
        this.plazopm6 = plazopm6;
    }

    public Double getPlazopm7() {
        return plazopm7;
    }

    public void setPlazopm7(Double plazopm7) {
        this.plazopm7 = plazopm7;
    }

    public Double getPlazopm8() {
        return plazopm8;
    }

    public void setPlazopm8(Double plazopm8) {
        this.plazopm8 = plazopm8;
    }

    public Double getPlazopm9() {
        return plazopm9;
    }

    public void setPlazopm9(Double plazopm9) {
        this.plazopm9 = plazopm9;
    }

    public Integer getPlazovm1() {
        return plazovm1;
    }

    public void setPlazovm1(Integer plazovm1) {
        this.plazovm1 = plazovm1;
    }

    public Integer getPlazovm10() {
        return plazovm10;
    }

    public void setPlazovm10(Integer plazovm10) {
        this.plazovm10 = plazovm10;
    }

    public Integer getPlazovm2() {
        return plazovm2;
    }

    public void setPlazovm2(Integer plazovm2) {
        this.plazovm2 = plazovm2;
    }

    public Integer getPlazovm3() {
        return plazovm3;
    }

    public void setPlazovm3(Integer plazovm3) {
        this.plazovm3 = plazovm3;
    }

    public Integer getPlazovm4() {
        return plazovm4;
    }

    public void setPlazovm4(Integer plazovm4) {
        this.plazovm4 = plazovm4;
    }

    public Integer getPlazovm5() {
        return plazovm5;
    }

    public void setPlazovm5(Integer plazovm5) {
        this.plazovm5 = plazovm5;
    }

    public Integer getPlazovm6() {
        return plazovm6;
    }

    public void setPlazovm6(Integer plazovm6) {
        this.plazovm6 = plazovm6;
    }

    public Integer getPlazovm7() {
        return plazovm7;
    }

    public void setPlazovm7(Integer plazovm7) {
        this.plazovm7 = plazovm7;
    }

    public Integer getPlazovm8() {
        return plazovm8;
    }

    public void setPlazovm8(Integer plazovm8) {
        this.plazovm8 = plazovm8;
    }

    public Integer getPlazovm9() {
        return plazovm9;
    }

    public void setPlazovm9(Integer plazovm9) {
        this.plazovm9 = plazovm9;
    }

    public Boolean getPorcentajeautomatico() {
        return porcentajeautomatico;
    }

    public void setPorcentajeautomatico(Boolean porcentajeautomatico) {
        this.porcentajeautomatico = porcentajeautomatico;
    }

    public Double getPorcentajepago1() {
        return porcentajepago1;
    }

    public void setPorcentajepago1(Double porcentajepago1) {
        this.porcentajepago1 = porcentajepago1;
    }

    public Double getPorcentajepago10() {
        return porcentajepago10;
    }

    public void setPorcentajepago10(Double porcentajepago10) {
        this.porcentajepago10 = porcentajepago10;
    }

    public Double getPorcentajepago2() {
        return porcentajepago2;
    }

    public void setPorcentajepago2(Double porcentajepago2) {
        this.porcentajepago2 = porcentajepago2;
    }

    public Double getPorcentajepago3() {
        return porcentajepago3;
    }

    public void setPorcentajepago3(Double porcentajepago3) {
        this.porcentajepago3 = porcentajepago3;
    }

    public Double getPorcentajepago4() {
        return porcentajepago4;
    }

    public void setPorcentajepago4(Double porcentajepago4) {
        this.porcentajepago4 = porcentajepago4;
    }

    public Double getPorcentajepago5() {
        return porcentajepago5;
    }

    public void setPorcentajepago5(Double porcentajepago5) {
        this.porcentajepago5 = porcentajepago5;
    }

    public Double getPorcentajepago6() {
        return porcentajepago6;
    }

    public void setPorcentajepago6(Double porcentajepago6) {
        this.porcentajepago6 = porcentajepago6;
    }

    public Double getPorcentajepago7() {
        return porcentajepago7;
    }

    public void setPorcentajepago7(Double porcentajepago7) {
        this.porcentajepago7 = porcentajepago7;
    }

    public Double getPorcentajepago8() {
        return porcentajepago8;
    }

    public void setPorcentajepago8(Double porcentajepago8) {
        this.porcentajepago8 = porcentajepago8;
    }

    public Double getPorcentajepago9() {
        return porcentajepago9;
    }

    public void setPorcentajepago9(Double porcentajepago9) {
        this.porcentajepago9 = porcentajepago9;
    }

    public String getTipodecalculo() {
        return tipodecalculo;
    }

    public void setTipodecalculo(String tipodecalculo) {
        this.tipodecalculo = tipodecalculo;
    }

    public String getTiporecibopago() {
        return tiporecibopago;
    }

    public void setTiporecibopago(String tiporecibopago) {
        this.tiporecibopago = tiporecibopago;
    }

    public String getTiporecibovencimiento() {
        return tiporecibovencimiento;
    }

    public void setTiporecibovencimiento(String tiporecibovencimiento) {
        this.tiporecibovencimiento = tiporecibovencimiento;
    }

    public TipoRecibo getIid_tr_p1() {
        return iid_tr_p1;
    }

    public void setIid_tr_p1(TipoRecibo iid_tr_p1) {
        this.iid_tr_p1 = iid_tr_p1;
    }

    public TipoRecibo getIid_tr_p10() {
        return iid_tr_p10;
    }

    public void setIid_tr_p10(TipoRecibo iid_tr_p10) {
        this.iid_tr_p10 = iid_tr_p10;
    }

    public TipoRecibo getIid_tr_p2() {
        return iid_tr_p2;
    }

    public void setIid_tr_p2(TipoRecibo iid_tr_p2) {
        this.iid_tr_p2 = iid_tr_p2;
    }

    public TipoRecibo getIid_tr_p3() {
        return iid_tr_p3;
    }

    public void setIid_tr_p3(TipoRecibo iid_tr_p3) {
        this.iid_tr_p3 = iid_tr_p3;
    }

    public TipoRecibo getIid_tr_p4() {
        return iid_tr_p4;
    }

    public void setIid_tr_p4(TipoRecibo iid_tr_p4) {
        this.iid_tr_p4 = iid_tr_p4;
    }

    public TipoRecibo getIid_tr_p5() {
        return iid_tr_p5;
    }

    public void setIid_tr_p5(TipoRecibo iid_tr_p5) {
        this.iid_tr_p5 = iid_tr_p5;
    }

    public TipoRecibo getIid_tr_p6() {
        return iid_tr_p6;
    }

    public void setIid_tr_p6(TipoRecibo iid_tr_p6) {
        this.iid_tr_p6 = iid_tr_p6;
    }

    public TipoRecibo getIid_tr_p7() {
        return iid_tr_p7;
    }

    public void setIid_tr_p7(TipoRecibo iid_tr_p7) {
        this.iid_tr_p7 = iid_tr_p7;
    }

    public TipoRecibo getIid_tr_p8() {
        return iid_tr_p8;
    }

    public void setIid_tr_p8(TipoRecibo iid_tr_p8) {
        this.iid_tr_p8 = iid_tr_p8;
    }

    public TipoRecibo getIid_tr_p9() {
        return iid_tr_p9;
    }

    public void setIid_tr_p9(TipoRecibo iid_tr_p9) {
        this.iid_tr_p9 = iid_tr_p9;
    }

    public TipoRecibo getIid_tr_v1() {
        return iid_tr_v1;
    }

    public void setIid_tr_v1(TipoRecibo iid_tr_v1) {
        this.iid_tr_v1 = iid_tr_v1;
    }

    public TipoRecibo getIid_tr_v10() {
        return iid_tr_v10;
    }

    public void setIid_tr_v10(TipoRecibo iid_tr_v10) {
        this.iid_tr_v10 = iid_tr_v10;
    }

    public TipoRecibo getIid_tr_v2() {
        return iid_tr_v2;
    }

    public void setIid_tr_v2(TipoRecibo iid_tr_v2) {
        this.iid_tr_v2 = iid_tr_v2;
    }

    public TipoRecibo getIid_tr_v3() {
        return iid_tr_v3;
    }

    public void setIid_tr_v3(TipoRecibo iid_tr_v3) {
        this.iid_tr_v3 = iid_tr_v3;
    }

    public TipoRecibo getIid_tr_v4() {
        return iid_tr_v4;
    }

    public void setIid_tr_v4(TipoRecibo iid_tr_v4) {
        this.iid_tr_v4 = iid_tr_v4;
    }

    public TipoRecibo getIid_tr_v5() {
        return iid_tr_v5;
    }

    public void setIid_tr_v5(TipoRecibo iid_tr_v5) {
        this.iid_tr_v5 = iid_tr_v5;
    }

    public TipoRecibo getIid_tr_v6() {
        return iid_tr_v6;
    }

    public void setIid_tr_v6(TipoRecibo iid_tr_v6) {
        this.iid_tr_v6 = iid_tr_v6;
    }

    public TipoRecibo getIid_tr_v7() {
        return iid_tr_v7;
    }

    public void setIid_tr_v7(TipoRecibo iid_tr_v7) {
        this.iid_tr_v7 = iid_tr_v7;
    }

    public TipoRecibo getIid_tr_v8() {
        return iid_tr_v8;
    }

    public void setIid_tr_v8(TipoRecibo iid_tr_v8) {
        this.iid_tr_v8 = iid_tr_v8;
    }

    public TipoRecibo getIid_tr_v9() {
        return iid_tr_v9;
    }

    public void setIid_tr_v9(TipoRecibo iid_tr_v9) {
        this.iid_tr_v9 = iid_tr_v9;
    }

    public String getCobrado1() {
        return cobrado1;
    }

    public void setCobrado1(String cobrado1) {
        this.cobrado1 = cobrado1;
    }

    public String getCobrado10() {
        return cobrado10;
    }

    public void setCobrado10(String cobrado10) {
        this.cobrado10 = cobrado10;
    }

    public String getCobrado2() {
        return cobrado2;
    }

    public void setCobrado2(String cobrado2) {
        this.cobrado2 = cobrado2;
    }

    public String getCobrado3() {
        return cobrado3;
    }

    public void setCobrado3(String cobrado3) {
        this.cobrado3 = cobrado3;
    }

    public String getCobrado4() {
        return cobrado4;
    }

    public void setCobrado4(String cobrado4) {
        this.cobrado4 = cobrado4;
    }

    public String getCobrado5() {
        return cobrado5;
    }

    public void setCobrado5(String cobrado5) {
        this.cobrado5 = cobrado5;
    }

    public String getCobrado6() {
        return cobrado6;
    }

    public void setCobrado6(String cobrado6) {
        this.cobrado6 = cobrado6;
    }

    public String getCobrado7() {
        return cobrado7;
    }

    public void setCobrado7(String cobrado7) {
        this.cobrado7 = cobrado7;
    }

    public String getCobrado8() {
        return cobrado8;
    }

    public void setCobrado8(String cobrado8) {
        this.cobrado8 = cobrado8;
    }

    public String getCobrado9() {
        return cobrado9;
    }

    public void setCobrado9(String cobrado9) {
        this.cobrado9 = cobrado9;
    }
    
    public FormaPago() {
        
    }

    public Double getImportep1() {
        return importep1;
    }

    public void setImportep1(Double importep1) {
        this.importep1 = importep1;
    }

    public Double getImportep10() {
        return importep10;
    }

    public void setImportep10(Double importep10) {
        this.importep10 = importep10;
    }

    public Double getImportep2() {
        return importep2;
    }

    public void setImportep2(Double importep2) {
        this.importep2 = importep2;
    }

    public Double getImportep3() {
        return importep3;
    }

    public void setImportep3(Double importep3) {
        this.importep3 = importep3;
    }

    public Double getImportep4() {
        return importep4;
    }

    public void setImportep4(Double importep4) {
        this.importep4 = importep4;
    }

    public Double getImportep5() {
        return importep5;
    }

    public void setImportep5(Double importep5) {
        this.importep5 = importep5;
    }

    public Double getImportep6() {
        return importep6;
    }

    public void setImportep6(Double importep6) {
        this.importep6 = importep6;
    }

    public Double getImportep7() {
        return importep7;
    }

    public void setImportep7(Double importep7) {
        this.importep7 = importep7;
    }

    public Double getImportep8() {
        return importep8;
    }

    public void setImportep8(Double importep8) {
        this.importep8 = importep8;
    }

    public Double getImportep9() {
        return importep9;
    }

    public void setImportep9(Double importep9) {
        this.importep9 = importep9;
    }

    public Double getImportev1() {
        return importev1;
    }

    public void setImportev1(Double importev1) {
        this.importev1 = importev1;
    }

    public Double getImportev10() {
        return importev10;
    }

    public void setImportev10(Double importev10) {
        this.importev10 = importev10;
    }

    public Double getImportev2() {
        return importev2;
    }

    public void setImportev2(Double importev2) {
        this.importev2 = importev2;
    }

    public Double getImportev3() {
        return importev3;
    }

    public void setImportev3(Double importev3) {
        this.importev3 = importev3;
    }

    public Double getImportev4() {
        return importev4;
    }

    public void setImportev4(Double importev4) {
        this.importev4 = importev4;
    }

    public Double getImportev5() {
        return importev5;
    }

    public void setImportev5(Double importev5) {
        this.importev5 = importev5;
    }

    public Double getImportev6() {
        return importev6;
    }

    public void setImportev6(Double importev6) {
        this.importev6 = importev6;
    }

    public Double getImportev7() {
        return importev7;
    }

    public void setImportev7(Double importev7) {
        this.importev7 = importev7;
    }

    public Double getImportev8() {
        return importev8;
    }

    public void setImportev8(Double importev8) {
        this.importev8 = importev8;
    }

    public Double getImportev9() {
        return importev9;
    }

    public void setImportev9(Double importev9) {
        this.importev9 = importev9;
    }

    public Long getFechap1() {
        return fechap1;
    }

    public void setFechap1(Long fechap1) {
        this.fechap1 = fechap1;
    }

    public Long getFechap10() {
        return fechap10;
    }

    public void setFechap10(Long fechap10) {
        this.fechap10 = fechap10;
    }

    public Long getFechap2() {
        return fechap2;
    }

    public void setFechap2(Long fechap2) {
        this.fechap2 = fechap2;
    }

    public Long getFechap3() {
        return fechap3;
    }

    public void setFechap3(Long fechap3) {
        this.fechap3 = fechap3;
    }

    public Long getFechap4() {
        return fechap4;
    }

    public void setFechap4(Long fechap4) {
        this.fechap4 = fechap4;
    }

    public Long getFechap5() {
        return fechap5;
    }

    public void setFechap5(Long fechap5) {
        this.fechap5 = fechap5;
    }

    public Long getFechap6() {
        return fechap6;
    }

    public void setFechap6(Long fechap6) {
        this.fechap6 = fechap6;
    }

    public Long getFechap7() {
        return fechap7;
    }

    public void setFechap7(Long fechap7) {
        this.fechap7 = fechap7;
    }

    public Long getFechap8() {
        return fechap8;
    }

    public void setFechap8(Long fechap8) {
        this.fechap8 = fechap8;
    }

    public Long getFechap9() {
        return fechap9;
    }

    public void setFechap9(Long fechap9) {
        this.fechap9 = fechap9;
    }

}
