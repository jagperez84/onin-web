package bean;

public class RestosUsados {
    
    private Integer iid;
    private MovimientoPresupuesto movimientoPresupuesto;
    private Existencia existenciaResto;
    private Float cantidad1;
    private Float cantidad2;

    public RestosUsados() {
    }

    public Float getCantidad1() {
        return cantidad1;
    }

    public void setCantidad1(Float cantidad1) {
        this.cantidad1 = cantidad1;
    }

    public Float getCantidad2() {
        return cantidad2;
    }

    public void setCantidad2(Float cantidad2) {
        this.cantidad2 = cantidad2;
    }

    public Existencia getExistenciaResto() {
        return existenciaResto;
    }

    public void setExistenciaResto(Existencia existenciaResto) {
        this.existenciaResto = existenciaResto;
    }

    public Integer getIid() {
        return iid;
    }

    public void setIid(Integer iid) {
        this.iid = iid;
    }

    public MovimientoPresupuesto getMovimientoPresupuesto() {
        return movimientoPresupuesto;
    }

    public void setMovimientoPresupuesto(MovimientoPresupuesto movimientoPresupuesto) {
        this.movimientoPresupuesto = movimientoPresupuesto;
    }
    
   
}
